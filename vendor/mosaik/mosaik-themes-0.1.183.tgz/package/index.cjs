'use strict';

var chroma7 = require('chroma-js');
var mosaikElements = require('@pixel-brewery/mosaik-elements');

function _interopDefault (e) { return e && e.__esModule ? e : { default: e }; }

var chroma7__default = /*#__PURE__*/_interopDefault(chroma7);

var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
function adjust(color, amount) {
  return Math.min(255, Math.max(0, color + amount));
}
__name(adjust, "adjust");
function darken(hex, factor) {
  const [r, g, b] = chroma7__default.default(hex).rgb().map((x) => adjust(x, -factor));
  return chroma7__default.default(r, g, b, "rgb").hex();
}
__name(darken, "darken");
function lighten(hex, factor) {
  const [r, g, b] = chroma7__default.default(hex).rgb().map((x) => adjust(x, factor));
  return chroma7__default.default(r, g, b, "rgb").hex();
}
__name(lighten, "lighten");

// src/colors/common.ts
function hexToHSL(hex) {
  const r = parseInt(hex.slice(1, 3), 16) / 255;
  const g = parseInt(hex.slice(3, 5), 16) / 255;
  const b = parseInt(hex.slice(5, 7), 16) / 255;
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  let h = 0;
  let s = 0;
  const l = (max + min) / 2;
  if (max === min) {
    h = 0;
    s = 0;
  } else {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r:
        h = (g - b) / d + (g < b ? 6 : 0);
        break;
      case g:
        h = (b - r) / d + 2;
        break;
      case b:
        h = (r - g) / d + 4;
        break;
    }
    h /= 6;
  }
  return [
    h,
    s,
    l
  ];
}
__name(hexToHSL, "hexToHSL");
function hslToHex(h, s, l) {
  const hue2rgb = /* @__PURE__ */ __name((p, q, t) => {
    if (t < 0) {
      t += 1;
    }
    if (t > 1) {
      t -= 1;
    }
    if (t < 1 / 6) {
      return p + (q - p) * 6 * t;
    }
    if (t < 1 / 2) {
      return q;
    }
    if (t < 2 / 3) {
      return p + (q - p) * (2 / 3 - t) * 6;
    }
    return p;
  }, "hue2rgb");
  let r = 0;
  let g = 0;
  let b = 0;
  if (s === 0) {
    r = l;
    g = l;
    b = l;
  } else {
    const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
    const p = 2 * l - q;
    r = hue2rgb(p, q, h + 1 / 3);
    g = hue2rgb(p, q, h);
    b = hue2rgb(p, q, h - 1 / 3);
  }
  return `#${Math.round(r * 255).toString(16).padStart(2, "0")}${Math.round(g * 255).toString(16).padStart(2, "0")}${Math.round(b * 255).toString(16).padStart(2, "0")}`;
}
__name(hslToHex, "hslToHex");
function adjustHue(hsl, adjustment) {
  return [
    (hsl[0] + adjustment + 1) % 1,
    hsl[1],
    hsl[2]
  ];
}
__name(adjustHue, "adjustHue");

// src/colors/generators/analogous.ts
function generateAnalogousPalette(baseHex, adjustment) {
  const baseHSL = hexToHSL(baseHex);
  const adjustedHSL = adjustHue(baseHSL, adjustment);
  const palette = {};
  const steps = [
    0,
    50,
    100,
    200,
    300,
    400,
    500,
    600,
    700,
    800,
    900
  ];
  steps.forEach((step) => {
    let [h, s, l] = adjustedHSL;
    if (step === 0) {
      l = 1;
    } else {
      l = 1 - step / 1e3;
    }
    palette[`${step}`] = hslToHex(h, s, Math.max(0, Math.min(1, l)));
  });
  return palette;
}
__name(generateAnalogousPalette, "generateAnalogousPalette");
function generateAnalogousColor(baseHex, adjustment) {
  const baseHSL = hexToHSL(baseHex);
  const adjustedHSL = adjustHue(baseHSL, adjustment);
  const [h, s] = adjustedHSL;
  return hslToHex(h, s, 0.5);
}
__name(generateAnalogousColor, "generateAnalogousColor");
function generateMaterialPalette(hexColor) {
  const baseLight = chroma7__default.default("#ffffff");
  const baseDark = chroma7__default.default("#000000");
  const palette = {};
  const steps = [
    0,
    50,
    100,
    200,
    300,
    400,
    500,
    600,
    700,
    800,
    900
  ];
  const amounts = [
    0,
    12,
    30,
    50,
    70,
    85,
    100,
    87,
    70,
    54,
    25
  ];
  steps.forEach((step, i) => {
    const base = step <= 500 ? baseLight : baseDark;
    palette[`${step}`] = chroma7__default.default.mix(base, hexColor, amounts[i] / 100, "rgb").hex();
  });
  return palette;
}
__name(generateMaterialPalette, "generateMaterialPalette");

// src/colors/generators/complementary.ts
function generateComplementaryPalette(baseHex) {
  const [h, s, l] = chroma7__default.default(baseHex).hsl();
  const complementaryH = (h + 180) % 360;
  return generateMaterialPalette(chroma7__default.default.hsl(complementaryH, s, l).hex());
}
__name(generateComplementaryPalette, "generateComplementaryPalette");
function generateComplementaryColor(baseHex) {
  const [h, s, l] = chroma7__default.default(baseHex).hsl();
  const complementaryH = (h + 180) % 360;
  return chroma7__default.default.hsl(complementaryH, s, l).hex();
}
__name(generateComplementaryColor, "generateComplementaryColor");
function generateSplitComplementaryColors(baseHex) {
  const [h, s, l] = chroma7__default.default(baseHex).hsl();
  const splitH1 = (h + 150) % 360;
  const splitH2 = (h + 210) % 360;
  return [
    chroma7__default.default.hsl(splitH1, s, l).hex(),
    chroma7__default.default.hsl(splitH2, s, l).hex()
  ];
}
__name(generateSplitComplementaryColors, "generateSplitComplementaryColors");
function generateSplitComplementaryColor1(baseHex) {
  const [h, s, l] = chroma7__default.default(baseHex).hsl();
  const splitH = (h + 150) % 360;
  return chroma7__default.default.hsl(splitH, s, l).hex();
}
__name(generateSplitComplementaryColor1, "generateSplitComplementaryColor1");
function generateSplitComplementaryColor2(baseHex) {
  const [h, s, l] = chroma7__default.default(baseHex).hsl();
  const splitH = (h + 210) % 360;
  return chroma7__default.default.hsl(splitH, s, l).hex();
}
__name(generateSplitComplementaryColor2, "generateSplitComplementaryColor2");
function generateTetradicColors(baseHex) {
  const [h, s, l] = chroma7__default.default(baseHex).hsl();
  return [
    chroma7__default.default.hsl((h + 90) % 360, s, l).hex(),
    chroma7__default.default.hsl((h + 180) % 360, s, l).hex(),
    chroma7__default.default.hsl((h + 270) % 360, s, l).hex()
  ];
}
__name(generateTetradicColors, "generateTetradicColors");
function generateTetradicColor1(baseHex) {
  const [h, s, l] = chroma7__default.default(baseHex).hsl();
  return chroma7__default.default.hsl((h + 90) % 360, s, l).hex();
}
__name(generateTetradicColor1, "generateTetradicColor1");
function generateTetradicColor3(baseHex) {
  const [h, s, l] = chroma7__default.default(baseHex).hsl();
  return chroma7__default.default.hsl((h + 270) % 360, s, l).hex();
}
__name(generateTetradicColor3, "generateTetradicColor3");

// src/colors/generators/triadic.ts
function generateTriadicPalette(baseHex, adjustment) {
  const baseHSL = hexToHSL(baseHex);
  const triadicHSL = adjustHue(baseHSL, adjustment);
  const palette = {};
  const steps = [
    0,
    50,
    100,
    200,
    300,
    400,
    500,
    600,
    700,
    800,
    900
  ];
  steps.forEach((step) => {
    let [h, s, l] = triadicHSL;
    if (step === 0) {
      l = 1;
    } else {
      l = 1 - step / 1e3;
    }
    palette[`${step}`] = hslToHex(h, s, Math.max(0, Math.min(1, l)));
  });
  return palette;
}
__name(generateTriadicPalette, "generateTriadicPalette");
function generateTriadicColor(baseHex, adjustment) {
  const baseHSL = hexToHSL(baseHex);
  const triadicHSL = adjustHue(baseHSL, adjustment);
  const [h, s] = triadicHSL;
  return hslToHex(h, s, 0.5);
}
__name(generateTriadicColor, "generateTriadicColor");

// src/colors/index.ts
(function(Colors2) {
  Colors2.toDarken = darken;
  Colors2.toLighten = lighten;
  Colors2.toMaterialPalette = generateMaterialPalette;
  Colors2.toComplementaryPalette = generateComplementaryPalette;
  Colors2.toComplementaryColor = generateComplementaryColor;
  Colors2.toAnalogousPalette = generateAnalogousPalette;
  Colors2.toAnalogousColor = generateAnalogousColor;
  Colors2.toTriadicPalette = generateTriadicPalette;
  Colors2.toTriadicColor = generateTriadicColor;
  Colors2.toSplitComplementaryColors = generateSplitComplementaryColors;
  Colors2.toSplitComplementaryColor1 = generateSplitComplementaryColor1;
  Colors2.toSplitComplementaryColor2 = generateSplitComplementaryColor2;
  Colors2.toTetradicColors = generateTetradicColors;
  Colors2.toTetradicColor1 = generateTetradicColor1;
  Colors2.toTetradicColor3 = generateTetradicColor3;
})(exports.Colors || (exports.Colors = {}));
exports.Colors = void 0;

// src/theming/adapters/BrowserPlatformAdapter.ts
var BrowserPlatformAdapter = class {
  static {
    __name(this, "BrowserPlatformAdapter");
  }
  // #region Methods
  matchMedia(query) {
    return window.matchMedia(query).matches;
  }
  setDocumentAttribute(name, value) {
    document.documentElement.setAttribute(name, value);
  }
  getDocumentAttribute(name) {
    return document.documentElement.getAttribute(name);
  }
  observeDocumentAttributes(attributes, callback) {
    const observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        if (mutation.type === "attributes" && mutation.attributeName) {
          const newValue = document.documentElement.getAttribute(mutation.attributeName);
          callback(mutation.attributeName, newValue);
        }
      });
    });
    observer.observe(document.documentElement, {
      attributes: true,
      attributeFilter: attributes
    });
    return () => observer.disconnect();
  }
};

// src/theming/adapters/NodePlatformAdapter.ts
var NodePlatformAdapter = class {
  static {
    __name(this, "NodePlatformAdapter");
  }
  // #region Methods
  matchMedia(_query) {
    return false;
  }
  setDocumentAttribute(_name, _value) {
  }
  getDocumentAttribute(_name) {
    return null;
  }
  observeDocumentAttributes(_attributes, _callback) {
    return () => {
    };
  }
};

// src/theming/adapters/PlatformAdapterFactory.ts
var PlatformAdapterFactory = class {
  static {
    __name(this, "PlatformAdapterFactory");
  }
  // #region Methods
  /**
   * Creates the appropriate platform adapter based on the current environment.
   * Automatically detects if running in browser or Node.js.
   *
   * @public
   */
  static create() {
    if (typeof window !== "undefined" && typeof document !== "undefined") {
      return new BrowserPlatformAdapter();
    }
    return new NodePlatformAdapter();
  }
};

// src/theming/ThemeFactory.ts
var ThemeFactory = class {
  static {
    __name(this, "ThemeFactory");
  }
  /**
   * Creates a new theme.
   *
   * @public
   * @static
   */
  static create(init) {
    return {
      name: init.name,
      scheme: init.scheme,
      palette: init.palette,
      fontFamily: init.fontFamily,
      typography: init.typography,
      layout: init.layout,
      elevation: init.elevation,
      ...init.duration ? {
        duration: init.duration
      } : {}
    };
  }
  /**
   * Merges the given theme with the initial theme.
   *
   * @public
   * @static
   */
  static merge(init, theme) {
    return {
      name: init.name,
      scheme: {
        ...theme.scheme,
        ...init.scheme
      },
      palette: {
        ...theme.palette,
        ...init.palette
      },
      fontFamily: init.fontFamily.length > 0 ? init.fontFamily : theme.fontFamily,
      typography: {
        ...theme.typography,
        ...init.typography
      },
      layout: {
        ...theme.layout,
        ...init.layout
      },
      elevation: {
        ...theme.elevation,
        ...init.elevation
      },
      ...theme.duration || init.duration ? {
        duration: {
          ...theme.duration,
          ...init.duration
        }
      } : {}
    };
  }
};

// src/theming/tokens/CosmopolitanTokens.ts
var NAME = "cosmopolitan";
var FONT_FAMILY = "'Segoe UI', 'Noto Sans', sans-serif";
var LAYOUT_RADIUS = "2px";
var LAYOUT_SPACE = "8px";
var LAYOUT_THICKNESS = "1px";
var SCHEME_LIGHT_SURFACE = "#ffffff";
var SCHEME_LIGHT_CONTRAST = "#ffffff";
var SCHEME_LIGHT_BACKGROUND = "#ffffff";
var SCHEME_LIGHT_FOREGROUND = "#000000";
var SCHEME_LIGHT_HIGHLIGHT = "#e2e2e2";
var SCHEME_LIGHT_MIDDLELIGHT = "#8a8a8a";
var SCHEME_LIGHT_LOWLIGHT = "#4d4d4d";
var SCHEME_LIGHT_TRANSPARENT = "rgba(255, 255, 255, 0)";
var SCHEME_LIGHT_SEMI_TRANSPARENT = "rgba(255, 255, 255, 0.6666666666666666)";
var SCHEME_LIGHT_DISABLED = "#b2b2b2";
var SCHEME_LIGHT_SELECTION = "#c6e7f8";
var SCHEME_DARK_SURFACE = "#2b2b2b";
var SCHEME_DARK_CONTRAST = "#ffffff";
var SCHEME_DARK_BACKGROUND = "#1f1f1f";
var SCHEME_DARK_FOREGROUND = "#ffffff";
var SCHEME_DARK_HIGHLIGHT = "#4a4a4a";
var SCHEME_DARK_MIDDLELIGHT = "#959595";
var SCHEME_DARK_LOWLIGHT = "#c2c2c2";
var SCHEME_DARK_TRANSPARENT = "rgba(31, 31, 31, 0)";
var SCHEME_DARK_SEMI_TRANSPARENT = "rgba(31, 31, 31, 0.6666666666666666)";
var SCHEME_DARK_DISABLED = "#5e5e5e";
var SCHEME_DARK_SELECTION = "#0d5578";
var COLOR_LIGHT_PRIMARY_0 = "#ffffff";
var COLOR_LIGHT_PRIMARY_50 = "#e4f4fc";
var COLOR_LIGHT_PRIMARY_100 = "#bbe3f6";
var COLOR_LIGHT_PRIMARY_200 = "#8dd0f1";
var COLOR_LIGHT_PRIMARY_300 = "#5fbdeb";
var COLOR_LIGHT_PRIMARY_400 = "#3dafe6";
var COLOR_LIGHT_PRIMARY_500 = "#1ba1e2";
var COLOR_LIGHT_PRIMARY_600 = "#178cc5";
var COLOR_LIGHT_PRIMARY_700 = "#13719e";
var COLOR_LIGHT_PRIMARY_800 = "#0f577a";
var COLOR_LIGHT_PRIMARY_900 = "#072839";
var COLOR_LIGHT_SECONDARY_0 = "#ffffff";
var COLOR_LIGHT_SECONDARY_50 = "#fae0ee";
var COLOR_LIGHT_SECONDARY_100 = "#f3b3d5";
var COLOR_LIGHT_SECONDARY_200 = "#ec80b9";
var COLOR_LIGHT_SECONDARY_300 = "#e44d9d";
var COLOR_LIGHT_SECONDARY_400 = "#de2688";
var COLOR_LIGHT_SECONDARY_500 = "#d80073";
var COLOR_LIGHT_SECONDARY_600 = "#bc0064";
var COLOR_LIGHT_SECONDARY_700 = "#970051";
var COLOR_LIGHT_SECONDARY_800 = "#75003e";
var COLOR_LIGHT_SECONDARY_900 = "#36001d";
var COLOR_LIGHT_TERTIARY_0 = "#ffffff";
var COLOR_LIGHT_TERTIARY_50 = "#feede0";
var COLOR_LIGHT_TERTIARY_100 = "#fed2b3";
var COLOR_LIGHT_TERTIARY_200 = "#fdb480";
var COLOR_LIGHT_TERTIARY_300 = "#fc954d";
var COLOR_LIGHT_TERTIARY_400 = "#fb7f26";
var COLOR_LIGHT_TERTIARY_500 = "#fa6800";
var COLOR_LIGHT_TERTIARY_600 = "#da5a00";
var COLOR_LIGHT_TERTIARY_700 = "#af4900";
var COLOR_LIGHT_TERTIARY_800 = "#873800";
var COLOR_LIGHT_TERTIARY_900 = "#3f1a00";
var COLOR_LIGHT_INFO_0 = "#ffffff";
var COLOR_LIGHT_INFO_50 = "#e0eafd";
var COLOR_LIGHT_INFO_100 = "#b3cbfa";
var COLOR_LIGHT_INFO_200 = "#80a8f7";
var COLOR_LIGHT_INFO_300 = "#4d85f4";
var COLOR_LIGHT_INFO_400 = "#266af1";
var COLOR_LIGHT_INFO_500 = "#0050ef";
var COLOR_LIGHT_INFO_600 = "#0046d0";
var COLOR_LIGHT_INFO_700 = "#0038a7";
var COLOR_LIGHT_INFO_800 = "#002b81";
var COLOR_LIGHT_INFO_900 = "#00143c";
var COLOR_LIGHT_WARNING_0 = "#ffffff";
var COLOR_LIGHT_WARNING_50 = "#fdf4e2";
var COLOR_LIGHT_WARNING_100 = "#fbe3b6";
var COLOR_LIGHT_WARNING_200 = "#f8d185";
var COLOR_LIGHT_WARNING_300 = "#f5bf54";
var COLOR_LIGHT_WARNING_400 = "#f2b12f";
var COLOR_LIGHT_WARNING_500 = "#f0a30a";
var COLOR_LIGHT_WARNING_600 = "#d18e09";
var COLOR_LIGHT_WARNING_700 = "#a87207";
var COLOR_LIGHT_WARNING_800 = "#825805";
var COLOR_LIGHT_WARNING_900 = "#3c2903";
var COLOR_LIGHT_DANGER_0 = "#ffffff";
var COLOR_LIGHT_DANGER_50 = "#fce3e0";
var COLOR_LIGHT_DANGER_100 = "#f7b9b3";
var COLOR_LIGHT_DANGER_200 = "#f28a80";
var COLOR_LIGHT_DANGER_300 = "#ed5b4d";
var COLOR_LIGHT_DANGER_400 = "#e93726";
var COLOR_LIGHT_DANGER_500 = "#e51400";
var COLOR_LIGHT_DANGER_600 = "#c71100";
var COLOR_LIGHT_DANGER_700 = "#a00e00";
var COLOR_LIGHT_DANGER_800 = "#7c0b00";
var COLOR_LIGHT_DANGER_900 = "#390500";
var COLOR_LIGHT_SUCCESS_0 = "#ffffff";
var COLOR_LIGHT_SUCCESS_50 = "#e7f3e7";
var COLOR_LIGHT_SUCCESS_100 = "#c2e0c2";
var COLOR_LIGHT_SUCCESS_200 = "#99cc99";
var COLOR_LIGHT_SUCCESS_300 = "#70b870";
var COLOR_LIGHT_SUCCESS_400 = "#52a852";
var COLOR_LIGHT_SUCCESS_500 = "#339933";
var COLOR_LIGHT_SUCCESS_600 = "#2c852c";
var COLOR_LIGHT_SUCCESS_700 = "#246b24";
var COLOR_LIGHT_SUCCESS_800 = "#1c531c";
var COLOR_LIGHT_SUCCESS_900 = "#0d260d";
var COLOR_LIGHT_HIGHLIGHT_0 = "#ffffff";
var COLOR_LIGHT_HIGHLIGHT_50 = "#f5e0ff";
var COLOR_LIGHT_HIGHLIGHT_100 = "#e6b3ff";
var COLOR_LIGHT_HIGHLIGHT_200 = "#d580ff";
var COLOR_LIGHT_HIGHLIGHT_300 = "#c44dff";
var COLOR_LIGHT_HIGHLIGHT_400 = "#b726ff";
var COLOR_LIGHT_HIGHLIGHT_500 = "#aa00ff";
var COLOR_LIGHT_HIGHLIGHT_600 = "#9400de";
var COLOR_LIGHT_HIGHLIGHT_700 = "#7700b3";
var COLOR_LIGHT_HIGHLIGHT_800 = "#5c008a";
var COLOR_LIGHT_HIGHLIGHT_900 = "#2b0040";
var COLOR_LIGHT_NEUTRAL_0 = "#ffffff";
var COLOR_LIGHT_NEUTRAL_50 = "#eeeeee";
var COLOR_LIGHT_NEUTRAL_100 = "#d5d5d5";
var COLOR_LIGHT_NEUTRAL_200 = "#b9b9b9";
var COLOR_LIGHT_NEUTRAL_300 = "#9d9d9d";
var COLOR_LIGHT_NEUTRAL_400 = "#888888";
var COLOR_LIGHT_NEUTRAL_500 = "#737373";
var COLOR_LIGHT_NEUTRAL_600 = "#646464";
var COLOR_LIGHT_NEUTRAL_700 = "#515151";
var COLOR_LIGHT_NEUTRAL_800 = "#3e3e3e";
var COLOR_LIGHT_NEUTRAL_900 = "#1d1d1d";
var COLOR_DARK_PRIMARY_0 = "#000000";
var COLOR_DARK_PRIMARY_50 = "#041822";
var COLOR_DARK_PRIMARY_100 = "#083044";
var COLOR_DARK_PRIMARY_200 = "#0c4866";
var COLOR_DARK_PRIMARY_300 = "#106188";
var COLOR_DARK_PRIMARY_400 = "#1479aa";
var COLOR_DARK_PRIMARY_500 = "#1891cb";
var COLOR_DARK_PRIMARY_600 = "#1ba1e2";
var COLOR_DARK_PRIMARY_700 = "#5fbdeb";
var COLOR_DARK_PRIMARY_800 = "#84ccef";
var COLOR_DARK_PRIMARY_900 = "#c6e8f8";
var COLOR_DARK_SECONDARY_0 = "#000000";
var COLOR_DARK_SECONDARY_50 = "#200011";
var COLOR_DARK_SECONDARY_100 = "#410023";
var COLOR_DARK_SECONDARY_200 = "#610034";
var COLOR_DARK_SECONDARY_300 = "#820045";
var COLOR_DARK_SECONDARY_400 = "#a20056";
var COLOR_DARK_SECONDARY_500 = "#c20068";
var COLOR_DARK_SECONDARY_600 = "#d80073";
var COLOR_DARK_SECONDARY_700 = "#e44d9d";
var COLOR_DARK_SECONDARY_800 = "#ea75b3";
var COLOR_DARK_SECONDARY_900 = "#f5bfdc";
var COLOR_DARK_TERTIARY_0 = "#000000";
var COLOR_DARK_TERTIARY_50 = "#261000";
var COLOR_DARK_TERTIARY_100 = "#4b1f00";
var COLOR_DARK_TERTIARY_200 = "#712f00";
var COLOR_DARK_TERTIARY_300 = "#963e00";
var COLOR_DARK_TERTIARY_400 = "#bc4e00";
var COLOR_DARK_TERTIARY_500 = "#e15e00";
var COLOR_DARK_TERTIARY_600 = "#fa6800";
var COLOR_DARK_TERTIARY_700 = "#fc954d";
var COLOR_DARK_TERTIARY_800 = "#fcad75";
var COLOR_DARK_TERTIARY_900 = "#fed9bf";
var COLOR_DARK_INFO_0 = "#000000";
var COLOR_DARK_INFO_50 = "#000c24";
var COLOR_DARK_INFO_100 = "#001848";
var COLOR_DARK_INFO_200 = "#00246c";
var COLOR_DARK_INFO_300 = "#00308f";
var COLOR_DARK_INFO_400 = "#003cb3";
var COLOR_DARK_INFO_500 = "#0048d7";
var COLOR_DARK_INFO_600 = "#0050ef";
var COLOR_DARK_INFO_700 = "#4d85f4";
var COLOR_DARK_INFO_800 = "#75a1f6";
var COLOR_DARK_INFO_900 = "#bfd3fb";
var COLOR_DARK_WARNING_0 = "#000000";
var COLOR_DARK_WARNING_50 = "#241802";
var COLOR_DARK_WARNING_100 = "#483103";
var COLOR_DARK_WARNING_200 = "#6c4905";
var COLOR_DARK_WARNING_300 = "#906206";
var COLOR_DARK_WARNING_400 = "#b47a08";
var COLOR_DARK_WARNING_500 = "#d89309";
var COLOR_DARK_WARNING_600 = "#f0a30a";
var COLOR_DARK_WARNING_700 = "#f5bf54";
var COLOR_DARK_WARNING_800 = "#f7cd7b";
var COLOR_DARK_WARNING_900 = "#fbe8c2";
var COLOR_DARK_DANGER_0 = "#000000";
var COLOR_DARK_DANGER_50 = "#220300";
var COLOR_DARK_DANGER_100 = "#450600";
var COLOR_DARK_DANGER_200 = "#670900";
var COLOR_DARK_DANGER_300 = "#890c00";
var COLOR_DARK_DANGER_400 = "#ac0f00";
var COLOR_DARK_DANGER_500 = "#ce1200";
var COLOR_DARK_DANGER_600 = "#e51400";
var COLOR_DARK_DANGER_700 = "#ed5b4d";
var COLOR_DARK_DANGER_800 = "#f18075";
var COLOR_DARK_DANGER_900 = "#f9c4bf";
var COLOR_DARK_SUCCESS_0 = "#000000";
var COLOR_DARK_SUCCESS_50 = "#081708";
var COLOR_DARK_SUCCESS_100 = "#0f2e0f";
var COLOR_DARK_SUCCESS_200 = "#174517";
var COLOR_DARK_SUCCESS_300 = "#1f5c1f";
var COLOR_DARK_SUCCESS_400 = "#267326";
var COLOR_DARK_SUCCESS_500 = "#2e8a2e";
var COLOR_DARK_SUCCESS_600 = "#339933";
var COLOR_DARK_SUCCESS_700 = "#70b870";
var COLOR_DARK_SUCCESS_800 = "#91c891";
var COLOR_DARK_SUCCESS_900 = "#cce6cc";
var COLOR_DARK_HIGHLIGHT_0 = "#000000";
var COLOR_DARK_HIGHLIGHT_50 = "#1a0026";
var COLOR_DARK_HIGHLIGHT_100 = "#33004d";
var COLOR_DARK_HIGHLIGHT_200 = "#4d0073";
var COLOR_DARK_HIGHLIGHT_300 = "#660099";
var COLOR_DARK_HIGHLIGHT_400 = "#8000bf";
var COLOR_DARK_HIGHLIGHT_500 = "#9900e6";
var COLOR_DARK_HIGHLIGHT_600 = "#aa00ff";
var COLOR_DARK_HIGHLIGHT_700 = "#c44dff";
var COLOR_DARK_HIGHLIGHT_800 = "#d175ff";
var COLOR_DARK_HIGHLIGHT_900 = "#eabfff";
var COLOR_DARK_NEUTRAL_0 = "#000000";
var COLOR_DARK_NEUTRAL_50 = "#111111";
var COLOR_DARK_NEUTRAL_100 = "#232323";
var COLOR_DARK_NEUTRAL_200 = "#343434";
var COLOR_DARK_NEUTRAL_300 = "#454545";
var COLOR_DARK_NEUTRAL_400 = "#565656";
var COLOR_DARK_NEUTRAL_500 = "#686868";
var COLOR_DARK_NEUTRAL_600 = "#737373";
var COLOR_DARK_NEUTRAL_700 = "#9d9d9d";
var COLOR_DARK_NEUTRAL_800 = "#b3b3b3";
var COLOR_DARK_NEUTRAL_900 = "#dcdcdc";
var TYPOGRAPHY_HEADLINE1_FONT_FAMILY = "'Segoe UI', 'Noto Sans', sans-serif";
var TYPOGRAPHY_HEADLINE1_FONT_SIZE = "64px";
var TYPOGRAPHY_HEADLINE1_LINE_HEIGHT = "72px";
var TYPOGRAPHY_HEADLINE1_FONT_WEIGHT = "300";
var TYPOGRAPHY_HEADLINE1_LETTER_SPACING = "-1px";
var TYPOGRAPHY_HEADLINE1_TEXT_DECORATION = "none";
var TYPOGRAPHY_HEADLINE1_TEXT_TRANSFORM = "none";
var TYPOGRAPHY_HEADLINE2_FONT_FAMILY = "'Segoe UI', 'Noto Sans', sans-serif";
var TYPOGRAPHY_HEADLINE2_FONT_SIZE = "48px";
var TYPOGRAPHY_HEADLINE2_LINE_HEIGHT = "56px";
var TYPOGRAPHY_HEADLINE2_FONT_WEIGHT = "300";
var TYPOGRAPHY_HEADLINE2_LETTER_SPACING = "-0.5px";
var TYPOGRAPHY_HEADLINE2_TEXT_DECORATION = "none";
var TYPOGRAPHY_HEADLINE2_TEXT_TRANSFORM = "none";
var TYPOGRAPHY_HEADLINE3_FONT_FAMILY = "'Segoe UI', 'Noto Sans', sans-serif";
var TYPOGRAPHY_HEADLINE3_FONT_SIZE = "40px";
var TYPOGRAPHY_HEADLINE3_LINE_HEIGHT = "48px";
var TYPOGRAPHY_HEADLINE3_FONT_WEIGHT = "300";
var TYPOGRAPHY_HEADLINE3_LETTER_SPACING = "-0.25px";
var TYPOGRAPHY_HEADLINE3_TEXT_DECORATION = "none";
var TYPOGRAPHY_HEADLINE3_TEXT_TRANSFORM = "none";
var TYPOGRAPHY_HEADLINE4_FONT_FAMILY = "'Segoe UI', 'Noto Sans', sans-serif";
var TYPOGRAPHY_HEADLINE4_FONT_SIZE = "32px";
var TYPOGRAPHY_HEADLINE4_LINE_HEIGHT = "40px";
var TYPOGRAPHY_HEADLINE4_FONT_WEIGHT = "300";
var TYPOGRAPHY_HEADLINE4_LETTER_SPACING = "normal";
var TYPOGRAPHY_HEADLINE4_TEXT_DECORATION = "none";
var TYPOGRAPHY_HEADLINE4_TEXT_TRANSFORM = "none";
var TYPOGRAPHY_HEADLINE5_FONT_FAMILY = "'Segoe UI', 'Noto Sans', sans-serif";
var TYPOGRAPHY_HEADLINE5_FONT_SIZE = "24px";
var TYPOGRAPHY_HEADLINE5_LINE_HEIGHT = "32px";
var TYPOGRAPHY_HEADLINE5_FONT_WEIGHT = "300";
var TYPOGRAPHY_HEADLINE5_LETTER_SPACING = "normal";
var TYPOGRAPHY_HEADLINE5_TEXT_DECORATION = "none";
var TYPOGRAPHY_HEADLINE5_TEXT_TRANSFORM = "none";
var TYPOGRAPHY_HEADLINE6_FONT_FAMILY = "'Segoe UI', 'Noto Sans', sans-serif";
var TYPOGRAPHY_HEADLINE6_FONT_SIZE = "20px";
var TYPOGRAPHY_HEADLINE6_LINE_HEIGHT = "28px";
var TYPOGRAPHY_HEADLINE6_FONT_WEIGHT = "400";
var TYPOGRAPHY_HEADLINE6_LETTER_SPACING = "normal";
var TYPOGRAPHY_HEADLINE6_TEXT_DECORATION = "none";
var TYPOGRAPHY_HEADLINE6_TEXT_TRANSFORM = "none";
var TYPOGRAPHY_SUBTITLE1_FONT_FAMILY = "'Segoe UI', 'Noto Sans', sans-serif";
var TYPOGRAPHY_SUBTITLE1_FONT_SIZE = "16px";
var TYPOGRAPHY_SUBTITLE1_LINE_HEIGHT = "22px";
var TYPOGRAPHY_SUBTITLE1_FONT_WEIGHT = "400";
var TYPOGRAPHY_SUBTITLE1_LETTER_SPACING = "normal";
var TYPOGRAPHY_SUBTITLE1_TEXT_DECORATION = "none";
var TYPOGRAPHY_SUBTITLE1_TEXT_TRANSFORM = "none";
var TYPOGRAPHY_SUBTITLE2_FONT_FAMILY = "'Segoe UI', 'Noto Sans', sans-serif";
var TYPOGRAPHY_SUBTITLE2_FONT_SIZE = "14px";
var TYPOGRAPHY_SUBTITLE2_LINE_HEIGHT = "20px";
var TYPOGRAPHY_SUBTITLE2_FONT_WEIGHT = "600";
var TYPOGRAPHY_SUBTITLE2_LETTER_SPACING = "normal";
var TYPOGRAPHY_SUBTITLE2_TEXT_DECORATION = "none";
var TYPOGRAPHY_SUBTITLE2_TEXT_TRANSFORM = "none";
var TYPOGRAPHY_BODY1_FONT_FAMILY = "'Segoe UI', 'Noto Sans', sans-serif";
var TYPOGRAPHY_BODY1_FONT_SIZE = "16px";
var TYPOGRAPHY_BODY1_LINE_HEIGHT = "22px";
var TYPOGRAPHY_BODY1_FONT_WEIGHT = "400";
var TYPOGRAPHY_BODY1_LETTER_SPACING = "normal";
var TYPOGRAPHY_BODY1_TEXT_DECORATION = "none";
var TYPOGRAPHY_BODY1_TEXT_TRANSFORM = "none";
var TYPOGRAPHY_BODY2_FONT_FAMILY = "'Segoe UI', 'Noto Sans', sans-serif";
var TYPOGRAPHY_BODY2_FONT_SIZE = "14px";
var TYPOGRAPHY_BODY2_LINE_HEIGHT = "20px";
var TYPOGRAPHY_BODY2_FONT_WEIGHT = "400";
var TYPOGRAPHY_BODY2_LETTER_SPACING = "normal";
var TYPOGRAPHY_BODY2_TEXT_DECORATION = "none";
var TYPOGRAPHY_BODY2_TEXT_TRANSFORM = "none";
var TYPOGRAPHY_SUPPORTING_FONT_FAMILY = "'Segoe UI', 'Noto Sans', sans-serif";
var TYPOGRAPHY_SUPPORTING_FONT_SIZE = "12px";
var TYPOGRAPHY_SUPPORTING_LINE_HEIGHT = "16px";
var TYPOGRAPHY_SUPPORTING_FONT_WEIGHT = "400";
var TYPOGRAPHY_SUPPORTING_LETTER_SPACING = "normal";
var TYPOGRAPHY_SUPPORTING_TEXT_DECORATION = "none";
var TYPOGRAPHY_SUPPORTING_TEXT_TRANSFORM = "none";
var TYPOGRAPHY_CAPTION_FONT_FAMILY = "'Segoe UI', 'Noto Sans', sans-serif";
var TYPOGRAPHY_CAPTION_FONT_SIZE = "12px";
var TYPOGRAPHY_CAPTION_LINE_HEIGHT = "16px";
var TYPOGRAPHY_CAPTION_FONT_WEIGHT = "400";
var TYPOGRAPHY_CAPTION_LETTER_SPACING = "normal";
var TYPOGRAPHY_CAPTION_TEXT_DECORATION = "none";
var TYPOGRAPHY_CAPTION_TEXT_TRANSFORM = "none";
var TYPOGRAPHY_BUTTON_FONT_FAMILY = "'Segoe UI', 'Noto Sans', sans-serif";
var TYPOGRAPHY_BUTTON_FONT_SIZE = "13px";
var TYPOGRAPHY_BUTTON_LINE_HEIGHT = "16px";
var TYPOGRAPHY_BUTTON_FONT_WEIGHT = "700";
var TYPOGRAPHY_BUTTON_LETTER_SPACING = "0.5px";
var TYPOGRAPHY_BUTTON_TEXT_DECORATION = "none";
var TYPOGRAPHY_BUTTON_TEXT_TRANSFORM = "uppercase";
var TYPOGRAPHY_OVERLINE_FONT_FAMILY = "'Segoe UI', 'Noto Sans', sans-serif";
var TYPOGRAPHY_OVERLINE_FONT_SIZE = "11px";
var TYPOGRAPHY_OVERLINE_LINE_HEIGHT = "14px";
var TYPOGRAPHY_OVERLINE_FONT_WEIGHT = "600";
var TYPOGRAPHY_OVERLINE_LETTER_SPACING = "0.8px";
var TYPOGRAPHY_OVERLINE_TEXT_DECORATION = "none";
var TYPOGRAPHY_OVERLINE_TEXT_TRANSFORM = "uppercase";
var ELEVATION_NONE = "none";
var ELEVATION_LIGHT_LIGHT = "0px 0px 2px 0px rgba(0, 0, 0, 0.12), 0px 1px 2px 0px rgba(0, 0, 0, 0.14)";
var ELEVATION_LIGHT_SEMILIGHT = "0px 0px 2px 0px rgba(0, 0, 0, 0.12), 0px 2px 4px 0px rgba(0, 0, 0, 0.14)";
var ELEVATION_LIGHT_REGULAR = "0px 0px 2px 0px rgba(0, 0, 0, 0.12), 0px 4px 8px 0px rgba(0, 0, 0, 0.14)";
var ELEVATION_LIGHT_SEMIBOLD = "0px 0px 2px 0px rgba(0, 0, 0, 0.12), 0px 8px 16px 0px rgba(0, 0, 0, 0.14)";
var ELEVATION_LIGHT_BOLD = "0px 0px 8px 0px rgba(0, 0, 0, 0.12), 0px 14px 28px 0px rgba(0, 0, 0, 0.14)";
var ELEVATION_LIGHT_EXTRABOLD = "0px 0px 8px 0px rgba(0, 0, 0, 0.12), 0px 32px 64px 0px rgba(0, 0, 0, 0.14)";
var ELEVATION_DARK_LIGHT = "0px 0px 2px 0px rgba(0, 0, 0, 0.24), 0px 1px 2px 0px rgba(0, 0, 0, 0.28)";
var ELEVATION_DARK_SEMILIGHT = "0px 0px 2px 0px rgba(0, 0, 0, 0.24), 0px 2px 4px 0px rgba(0, 0, 0, 0.28)";
var ELEVATION_DARK_REGULAR = "0px 0px 2px 0px rgba(0, 0, 0, 0.24), 0px 4px 8px 0px rgba(0, 0, 0, 0.28)";
var ELEVATION_DARK_SEMIBOLD = "0px 0px 2px 0px rgba(0, 0, 0, 0.24), 0px 8px 16px 0px rgba(0, 0, 0, 0.28)";
var ELEVATION_DARK_BOLD = "0px 0px 8px 0px rgba(0, 0, 0, 0.24), 0px 14px 28px 0px rgba(0, 0, 0, 0.28)";
var ELEVATION_DARK_EXTRABOLD = "0px 0px 8px 0px rgba(0, 0, 0, 0.24), 0px 32px 64px 0px rgba(0, 0, 0, 0.28)";
var TYPOGRAPHY_KEY_HEADLINE1 = "headline1";
var TYPOGRAPHY_KEY_HEADLINE2 = "headline2";
var TYPOGRAPHY_KEY_HEADLINE3 = "headline3";
var TYPOGRAPHY_KEY_HEADLINE4 = "headline4";
var TYPOGRAPHY_KEY_HEADLINE5 = "headline5";
var TYPOGRAPHY_KEY_HEADLINE6 = "headline6";
var TYPOGRAPHY_KEY_BODY1 = "body1";
var TYPOGRAPHY_KEY_BODY2 = "body2";
var TYPOGRAPHY_KEY_BUTTON = "button";
var ELEVATION_KEY_LIGHT = "light";
var ELEVATION_KEY_SEMILIGHT = "semilight";
var ELEVATION_KEY_REGULAR = "regular";
var ELEVATION_KEY_SEMIBOLD = "semibold";
var ELEVATION_KEY_BOLD = "bold";
var ELEVATION_KEY_EXTRABOLD = "extrabold";
var VARIANT_PRIMARY = "primary";
var VARIANT_SECONDARY = "secondary";
var VARIANT_TERTIARY = "tertiary";
var DURATION_SHORT = "200ms";
var DURATION_MEDIUM = "400ms";
var DURATION_LONG = "600ms";

// src/theming/CosmopolitanTheme.ts
(function(CosmopolitanTheme2) {
  CosmopolitanTheme2.COSMOPOLITAN_THEME = ThemeFactory.create({
    name: NAME,
    scheme: {
      light: {
        surface: SCHEME_LIGHT_SURFACE,
        contrast: SCHEME_LIGHT_CONTRAST,
        background: SCHEME_LIGHT_BACKGROUND,
        foreground: SCHEME_LIGHT_FOREGROUND,
        highlight: SCHEME_LIGHT_HIGHLIGHT,
        middlelight: SCHEME_LIGHT_MIDDLELIGHT,
        lowlight: SCHEME_LIGHT_LOWLIGHT,
        transparent: SCHEME_LIGHT_TRANSPARENT,
        semiTransparent: SCHEME_LIGHT_SEMI_TRANSPARENT,
        disabled: SCHEME_LIGHT_DISABLED,
        selection: SCHEME_LIGHT_SELECTION
      },
      dark: {
        surface: SCHEME_DARK_SURFACE,
        contrast: SCHEME_DARK_CONTRAST,
        background: SCHEME_DARK_BACKGROUND,
        foreground: SCHEME_DARK_FOREGROUND,
        highlight: SCHEME_DARK_HIGHLIGHT,
        middlelight: SCHEME_DARK_MIDDLELIGHT,
        lowlight: SCHEME_DARK_LOWLIGHT,
        transparent: SCHEME_DARK_TRANSPARENT,
        semiTransparent: SCHEME_DARK_SEMI_TRANSPARENT,
        disabled: SCHEME_DARK_DISABLED,
        selection: SCHEME_DARK_SELECTION
      }
    },
    palette: {
      light: {
        primary: {
          0: COLOR_LIGHT_PRIMARY_0,
          50: COLOR_LIGHT_PRIMARY_50,
          100: COLOR_LIGHT_PRIMARY_100,
          200: COLOR_LIGHT_PRIMARY_200,
          300: COLOR_LIGHT_PRIMARY_300,
          400: COLOR_LIGHT_PRIMARY_400,
          500: COLOR_LIGHT_PRIMARY_500,
          600: COLOR_LIGHT_PRIMARY_600,
          700: COLOR_LIGHT_PRIMARY_700,
          800: COLOR_LIGHT_PRIMARY_800,
          900: COLOR_LIGHT_PRIMARY_900
        },
        secondary: {
          0: COLOR_LIGHT_SECONDARY_0,
          50: COLOR_LIGHT_SECONDARY_50,
          100: COLOR_LIGHT_SECONDARY_100,
          200: COLOR_LIGHT_SECONDARY_200,
          300: COLOR_LIGHT_SECONDARY_300,
          400: COLOR_LIGHT_SECONDARY_400,
          500: COLOR_LIGHT_SECONDARY_500,
          600: COLOR_LIGHT_SECONDARY_600,
          700: COLOR_LIGHT_SECONDARY_700,
          800: COLOR_LIGHT_SECONDARY_800,
          900: COLOR_LIGHT_SECONDARY_900
        },
        tertiary: {
          0: COLOR_LIGHT_TERTIARY_0,
          50: COLOR_LIGHT_TERTIARY_50,
          100: COLOR_LIGHT_TERTIARY_100,
          200: COLOR_LIGHT_TERTIARY_200,
          300: COLOR_LIGHT_TERTIARY_300,
          400: COLOR_LIGHT_TERTIARY_400,
          500: COLOR_LIGHT_TERTIARY_500,
          600: COLOR_LIGHT_TERTIARY_600,
          700: COLOR_LIGHT_TERTIARY_700,
          800: COLOR_LIGHT_TERTIARY_800,
          900: COLOR_LIGHT_TERTIARY_900
        },
        info: {
          0: COLOR_LIGHT_INFO_0,
          50: COLOR_LIGHT_INFO_50,
          100: COLOR_LIGHT_INFO_100,
          200: COLOR_LIGHT_INFO_200,
          300: COLOR_LIGHT_INFO_300,
          400: COLOR_LIGHT_INFO_400,
          500: COLOR_LIGHT_INFO_500,
          600: COLOR_LIGHT_INFO_600,
          700: COLOR_LIGHT_INFO_700,
          800: COLOR_LIGHT_INFO_800,
          900: COLOR_LIGHT_INFO_900
        },
        warning: {
          0: COLOR_LIGHT_WARNING_0,
          50: COLOR_LIGHT_WARNING_50,
          100: COLOR_LIGHT_WARNING_100,
          200: COLOR_LIGHT_WARNING_200,
          300: COLOR_LIGHT_WARNING_300,
          400: COLOR_LIGHT_WARNING_400,
          500: COLOR_LIGHT_WARNING_500,
          600: COLOR_LIGHT_WARNING_600,
          700: COLOR_LIGHT_WARNING_700,
          800: COLOR_LIGHT_WARNING_800,
          900: COLOR_LIGHT_WARNING_900
        },
        danger: {
          0: COLOR_LIGHT_DANGER_0,
          50: COLOR_LIGHT_DANGER_50,
          100: COLOR_LIGHT_DANGER_100,
          200: COLOR_LIGHT_DANGER_200,
          300: COLOR_LIGHT_DANGER_300,
          400: COLOR_LIGHT_DANGER_400,
          500: COLOR_LIGHT_DANGER_500,
          600: COLOR_LIGHT_DANGER_600,
          700: COLOR_LIGHT_DANGER_700,
          800: COLOR_LIGHT_DANGER_800,
          900: COLOR_LIGHT_DANGER_900
        },
        success: {
          0: COLOR_LIGHT_SUCCESS_0,
          50: COLOR_LIGHT_SUCCESS_50,
          100: COLOR_LIGHT_SUCCESS_100,
          200: COLOR_LIGHT_SUCCESS_200,
          300: COLOR_LIGHT_SUCCESS_300,
          400: COLOR_LIGHT_SUCCESS_400,
          500: COLOR_LIGHT_SUCCESS_500,
          600: COLOR_LIGHT_SUCCESS_600,
          700: COLOR_LIGHT_SUCCESS_700,
          800: COLOR_LIGHT_SUCCESS_800,
          900: COLOR_LIGHT_SUCCESS_900
        },
        highlight: {
          0: COLOR_LIGHT_HIGHLIGHT_0,
          50: COLOR_LIGHT_HIGHLIGHT_50,
          100: COLOR_LIGHT_HIGHLIGHT_100,
          200: COLOR_LIGHT_HIGHLIGHT_200,
          300: COLOR_LIGHT_HIGHLIGHT_300,
          400: COLOR_LIGHT_HIGHLIGHT_400,
          500: COLOR_LIGHT_HIGHLIGHT_500,
          600: COLOR_LIGHT_HIGHLIGHT_600,
          700: COLOR_LIGHT_HIGHLIGHT_700,
          800: COLOR_LIGHT_HIGHLIGHT_800,
          900: COLOR_LIGHT_HIGHLIGHT_900
        },
        neutral: {
          0: COLOR_LIGHT_NEUTRAL_0,
          50: COLOR_LIGHT_NEUTRAL_50,
          100: COLOR_LIGHT_NEUTRAL_100,
          200: COLOR_LIGHT_NEUTRAL_200,
          300: COLOR_LIGHT_NEUTRAL_300,
          400: COLOR_LIGHT_NEUTRAL_400,
          500: COLOR_LIGHT_NEUTRAL_500,
          600: COLOR_LIGHT_NEUTRAL_600,
          700: COLOR_LIGHT_NEUTRAL_700,
          800: COLOR_LIGHT_NEUTRAL_800,
          900: COLOR_LIGHT_NEUTRAL_900
        }
      },
      dark: {
        primary: {
          0: COLOR_DARK_PRIMARY_0,
          50: COLOR_DARK_PRIMARY_50,
          100: COLOR_DARK_PRIMARY_100,
          200: COLOR_DARK_PRIMARY_200,
          300: COLOR_DARK_PRIMARY_300,
          400: COLOR_DARK_PRIMARY_400,
          500: COLOR_DARK_PRIMARY_500,
          600: COLOR_DARK_PRIMARY_600,
          700: COLOR_DARK_PRIMARY_700,
          800: COLOR_DARK_PRIMARY_800,
          900: COLOR_DARK_PRIMARY_900
        },
        secondary: {
          0: COLOR_DARK_SECONDARY_0,
          50: COLOR_DARK_SECONDARY_50,
          100: COLOR_DARK_SECONDARY_100,
          200: COLOR_DARK_SECONDARY_200,
          300: COLOR_DARK_SECONDARY_300,
          400: COLOR_DARK_SECONDARY_400,
          500: COLOR_DARK_SECONDARY_500,
          600: COLOR_DARK_SECONDARY_600,
          700: COLOR_DARK_SECONDARY_700,
          800: COLOR_DARK_SECONDARY_800,
          900: COLOR_DARK_SECONDARY_900
        },
        tertiary: {
          0: COLOR_DARK_TERTIARY_0,
          50: COLOR_DARK_TERTIARY_50,
          100: COLOR_DARK_TERTIARY_100,
          200: COLOR_DARK_TERTIARY_200,
          300: COLOR_DARK_TERTIARY_300,
          400: COLOR_DARK_TERTIARY_400,
          500: COLOR_DARK_TERTIARY_500,
          600: COLOR_DARK_TERTIARY_600,
          700: COLOR_DARK_TERTIARY_700,
          800: COLOR_DARK_TERTIARY_800,
          900: COLOR_DARK_TERTIARY_900
        },
        info: {
          0: COLOR_DARK_INFO_0,
          50: COLOR_DARK_INFO_50,
          100: COLOR_DARK_INFO_100,
          200: COLOR_DARK_INFO_200,
          300: COLOR_DARK_INFO_300,
          400: COLOR_DARK_INFO_400,
          500: COLOR_DARK_INFO_500,
          600: COLOR_DARK_INFO_600,
          700: COLOR_DARK_INFO_700,
          800: COLOR_DARK_INFO_800,
          900: COLOR_DARK_INFO_900
        },
        warning: {
          0: COLOR_DARK_WARNING_0,
          50: COLOR_DARK_WARNING_50,
          100: COLOR_DARK_WARNING_100,
          200: COLOR_DARK_WARNING_200,
          300: COLOR_DARK_WARNING_300,
          400: COLOR_DARK_WARNING_400,
          500: COLOR_DARK_WARNING_500,
          600: COLOR_DARK_WARNING_600,
          700: COLOR_DARK_WARNING_700,
          800: COLOR_DARK_WARNING_800,
          900: COLOR_DARK_WARNING_900
        },
        danger: {
          0: COLOR_DARK_DANGER_0,
          50: COLOR_DARK_DANGER_50,
          100: COLOR_DARK_DANGER_100,
          200: COLOR_DARK_DANGER_200,
          300: COLOR_DARK_DANGER_300,
          400: COLOR_DARK_DANGER_400,
          500: COLOR_DARK_DANGER_500,
          600: COLOR_DARK_DANGER_600,
          700: COLOR_DARK_DANGER_700,
          800: COLOR_DARK_DANGER_800,
          900: COLOR_DARK_DANGER_900
        },
        success: {
          0: COLOR_DARK_SUCCESS_0,
          50: COLOR_DARK_SUCCESS_50,
          100: COLOR_DARK_SUCCESS_100,
          200: COLOR_DARK_SUCCESS_200,
          300: COLOR_DARK_SUCCESS_300,
          400: COLOR_DARK_SUCCESS_400,
          500: COLOR_DARK_SUCCESS_500,
          600: COLOR_DARK_SUCCESS_600,
          700: COLOR_DARK_SUCCESS_700,
          800: COLOR_DARK_SUCCESS_800,
          900: COLOR_DARK_SUCCESS_900
        },
        highlight: {
          0: COLOR_DARK_HIGHLIGHT_0,
          50: COLOR_DARK_HIGHLIGHT_50,
          100: COLOR_DARK_HIGHLIGHT_100,
          200: COLOR_DARK_HIGHLIGHT_200,
          300: COLOR_DARK_HIGHLIGHT_300,
          400: COLOR_DARK_HIGHLIGHT_400,
          500: COLOR_DARK_HIGHLIGHT_500,
          600: COLOR_DARK_HIGHLIGHT_600,
          700: COLOR_DARK_HIGHLIGHT_700,
          800: COLOR_DARK_HIGHLIGHT_800,
          900: COLOR_DARK_HIGHLIGHT_900
        },
        neutral: {
          0: COLOR_DARK_NEUTRAL_0,
          50: COLOR_DARK_NEUTRAL_50,
          100: COLOR_DARK_NEUTRAL_100,
          200: COLOR_DARK_NEUTRAL_200,
          300: COLOR_DARK_NEUTRAL_300,
          400: COLOR_DARK_NEUTRAL_400,
          500: COLOR_DARK_NEUTRAL_500,
          600: COLOR_DARK_NEUTRAL_600,
          700: COLOR_DARK_NEUTRAL_700,
          800: COLOR_DARK_NEUTRAL_800,
          900: COLOR_DARK_NEUTRAL_900
        }
      }
    },
    fontFamily: FONT_FAMILY,
    typography: {
      headline1: {
        fontFamily: TYPOGRAPHY_HEADLINE1_FONT_FAMILY,
        fontSize: TYPOGRAPHY_HEADLINE1_FONT_SIZE,
        lineHeight: TYPOGRAPHY_HEADLINE1_LINE_HEIGHT,
        fontWeight: TYPOGRAPHY_HEADLINE1_FONT_WEIGHT,
        letterSpacing: TYPOGRAPHY_HEADLINE1_LETTER_SPACING,
        textDecoration: TYPOGRAPHY_HEADLINE1_TEXT_DECORATION,
        textTransform: TYPOGRAPHY_HEADLINE1_TEXT_TRANSFORM
      },
      headline2: {
        fontFamily: TYPOGRAPHY_HEADLINE2_FONT_FAMILY,
        fontSize: TYPOGRAPHY_HEADLINE2_FONT_SIZE,
        lineHeight: TYPOGRAPHY_HEADLINE2_LINE_HEIGHT,
        fontWeight: TYPOGRAPHY_HEADLINE2_FONT_WEIGHT,
        letterSpacing: TYPOGRAPHY_HEADLINE2_LETTER_SPACING,
        textDecoration: TYPOGRAPHY_HEADLINE2_TEXT_DECORATION,
        textTransform: TYPOGRAPHY_HEADLINE2_TEXT_TRANSFORM
      },
      headline3: {
        fontFamily: TYPOGRAPHY_HEADLINE3_FONT_FAMILY,
        fontSize: TYPOGRAPHY_HEADLINE3_FONT_SIZE,
        lineHeight: TYPOGRAPHY_HEADLINE3_LINE_HEIGHT,
        fontWeight: TYPOGRAPHY_HEADLINE3_FONT_WEIGHT,
        letterSpacing: TYPOGRAPHY_HEADLINE3_LETTER_SPACING,
        textDecoration: TYPOGRAPHY_HEADLINE3_TEXT_DECORATION,
        textTransform: TYPOGRAPHY_HEADLINE3_TEXT_TRANSFORM
      },
      headline4: {
        fontFamily: TYPOGRAPHY_HEADLINE4_FONT_FAMILY,
        fontSize: TYPOGRAPHY_HEADLINE4_FONT_SIZE,
        lineHeight: TYPOGRAPHY_HEADLINE4_LINE_HEIGHT,
        fontWeight: TYPOGRAPHY_HEADLINE4_FONT_WEIGHT,
        letterSpacing: TYPOGRAPHY_HEADLINE4_LETTER_SPACING,
        textDecoration: TYPOGRAPHY_HEADLINE4_TEXT_DECORATION,
        textTransform: TYPOGRAPHY_HEADLINE4_TEXT_TRANSFORM
      },
      headline5: {
        fontFamily: TYPOGRAPHY_HEADLINE5_FONT_FAMILY,
        fontSize: TYPOGRAPHY_HEADLINE5_FONT_SIZE,
        lineHeight: TYPOGRAPHY_HEADLINE5_LINE_HEIGHT,
        fontWeight: TYPOGRAPHY_HEADLINE5_FONT_WEIGHT,
        letterSpacing: TYPOGRAPHY_HEADLINE5_LETTER_SPACING,
        textDecoration: TYPOGRAPHY_HEADLINE5_TEXT_DECORATION,
        textTransform: TYPOGRAPHY_HEADLINE5_TEXT_TRANSFORM
      },
      headline6: {
        fontFamily: TYPOGRAPHY_HEADLINE6_FONT_FAMILY,
        fontSize: TYPOGRAPHY_HEADLINE6_FONT_SIZE,
        lineHeight: TYPOGRAPHY_HEADLINE6_LINE_HEIGHT,
        fontWeight: TYPOGRAPHY_HEADLINE6_FONT_WEIGHT,
        letterSpacing: TYPOGRAPHY_HEADLINE6_LETTER_SPACING,
        textDecoration: TYPOGRAPHY_HEADLINE6_TEXT_DECORATION,
        textTransform: TYPOGRAPHY_HEADLINE6_TEXT_TRANSFORM
      },
      body1: {
        fontFamily: TYPOGRAPHY_BODY1_FONT_FAMILY,
        fontSize: TYPOGRAPHY_BODY1_FONT_SIZE,
        lineHeight: TYPOGRAPHY_BODY1_LINE_HEIGHT,
        fontWeight: TYPOGRAPHY_BODY1_FONT_WEIGHT,
        letterSpacing: TYPOGRAPHY_BODY1_LETTER_SPACING,
        textDecoration: TYPOGRAPHY_BODY1_TEXT_DECORATION,
        textTransform: TYPOGRAPHY_BODY1_TEXT_TRANSFORM
      },
      body2: {
        fontFamily: TYPOGRAPHY_BODY2_FONT_FAMILY,
        fontSize: TYPOGRAPHY_BODY2_FONT_SIZE,
        lineHeight: TYPOGRAPHY_BODY2_LINE_HEIGHT,
        fontWeight: TYPOGRAPHY_BODY2_FONT_WEIGHT,
        letterSpacing: TYPOGRAPHY_BODY2_LETTER_SPACING,
        textDecoration: TYPOGRAPHY_BODY2_TEXT_DECORATION,
        textTransform: TYPOGRAPHY_BODY2_TEXT_TRANSFORM
      },
      subtitle1: {
        fontFamily: TYPOGRAPHY_SUBTITLE1_FONT_FAMILY,
        fontSize: TYPOGRAPHY_SUBTITLE1_FONT_SIZE,
        lineHeight: TYPOGRAPHY_SUBTITLE1_LINE_HEIGHT,
        fontWeight: TYPOGRAPHY_SUBTITLE1_FONT_WEIGHT,
        letterSpacing: TYPOGRAPHY_SUBTITLE1_LETTER_SPACING,
        textDecoration: TYPOGRAPHY_SUBTITLE1_TEXT_DECORATION,
        textTransform: TYPOGRAPHY_SUBTITLE1_TEXT_TRANSFORM
      },
      subtitle2: {
        fontFamily: TYPOGRAPHY_SUBTITLE2_FONT_FAMILY,
        fontSize: TYPOGRAPHY_SUBTITLE2_FONT_SIZE,
        lineHeight: TYPOGRAPHY_SUBTITLE2_LINE_HEIGHT,
        fontWeight: TYPOGRAPHY_SUBTITLE2_FONT_WEIGHT,
        letterSpacing: TYPOGRAPHY_SUBTITLE2_LETTER_SPACING,
        textDecoration: TYPOGRAPHY_SUBTITLE2_TEXT_DECORATION,
        textTransform: TYPOGRAPHY_SUBTITLE2_TEXT_TRANSFORM
      },
      supporting: {
        fontFamily: TYPOGRAPHY_SUPPORTING_FONT_FAMILY,
        fontSize: TYPOGRAPHY_SUPPORTING_FONT_SIZE,
        lineHeight: TYPOGRAPHY_SUPPORTING_LINE_HEIGHT,
        fontWeight: TYPOGRAPHY_SUPPORTING_FONT_WEIGHT,
        letterSpacing: TYPOGRAPHY_SUPPORTING_LETTER_SPACING,
        textDecoration: TYPOGRAPHY_SUPPORTING_TEXT_DECORATION,
        textTransform: TYPOGRAPHY_SUPPORTING_TEXT_TRANSFORM
      },
      caption: {
        fontFamily: TYPOGRAPHY_CAPTION_FONT_FAMILY,
        fontSize: TYPOGRAPHY_CAPTION_FONT_SIZE,
        lineHeight: TYPOGRAPHY_CAPTION_LINE_HEIGHT,
        fontWeight: TYPOGRAPHY_CAPTION_FONT_WEIGHT,
        letterSpacing: TYPOGRAPHY_CAPTION_LETTER_SPACING,
        textDecoration: TYPOGRAPHY_CAPTION_TEXT_DECORATION,
        textTransform: TYPOGRAPHY_CAPTION_TEXT_TRANSFORM
      },
      overline: {
        fontFamily: TYPOGRAPHY_OVERLINE_FONT_FAMILY,
        fontSize: TYPOGRAPHY_OVERLINE_FONT_SIZE,
        lineHeight: TYPOGRAPHY_OVERLINE_LINE_HEIGHT,
        fontWeight: TYPOGRAPHY_OVERLINE_FONT_WEIGHT,
        letterSpacing: TYPOGRAPHY_OVERLINE_LETTER_SPACING,
        textDecoration: TYPOGRAPHY_OVERLINE_TEXT_DECORATION,
        textTransform: TYPOGRAPHY_OVERLINE_TEXT_TRANSFORM
      },
      button: {
        fontFamily: TYPOGRAPHY_BUTTON_FONT_FAMILY,
        fontSize: TYPOGRAPHY_BUTTON_FONT_SIZE,
        lineHeight: TYPOGRAPHY_BUTTON_LINE_HEIGHT,
        fontWeight: TYPOGRAPHY_BUTTON_FONT_WEIGHT,
        letterSpacing: TYPOGRAPHY_BUTTON_LETTER_SPACING,
        textDecoration: TYPOGRAPHY_BUTTON_TEXT_DECORATION,
        textTransform: TYPOGRAPHY_BUTTON_TEXT_TRANSFORM
      }
    },
    layout: {
      radius: LAYOUT_RADIUS,
      space: LAYOUT_SPACE,
      thickness: LAYOUT_THICKNESS
    },
    duration: {
      short: DURATION_SHORT,
      medium: DURATION_MEDIUM,
      long: DURATION_LONG
    },
    elevation: {
      light: {
        light: ELEVATION_LIGHT_LIGHT,
        semilight: ELEVATION_LIGHT_SEMILIGHT,
        regular: ELEVATION_LIGHT_REGULAR,
        semibold: ELEVATION_LIGHT_SEMIBOLD,
        bold: ELEVATION_LIGHT_BOLD,
        extrabold: ELEVATION_LIGHT_EXTRABOLD,
        none: ELEVATION_NONE
      },
      dark: {
        light: ELEVATION_DARK_LIGHT,
        semilight: ELEVATION_DARK_SEMILIGHT,
        regular: ELEVATION_DARK_REGULAR,
        semibold: ELEVATION_DARK_SEMIBOLD,
        bold: ELEVATION_DARK_BOLD,
        extrabold: ELEVATION_DARK_EXTRABOLD,
        none: ELEVATION_NONE
      }
    }
  });
  CosmopolitanTheme2.COSMOPOLITAN_THEME_PALETTES = [
    VARIANT_PRIMARY,
    VARIANT_SECONDARY,
    VARIANT_TERTIARY
  ];
  CosmopolitanTheme2.COSMOPOLITAN_THEME_PALETTE_VARIANTS = [
    "0",
    "50",
    "100",
    "200",
    "300",
    "400",
    "500",
    "600",
    "700",
    "800",
    "900"
  ];
  CosmopolitanTheme2.COSMOPOLITAN_THEME_SCHEMES = [
    "light",
    "dark"
  ];
  CosmopolitanTheme2.COSMOPOLITAN_THEME_SCHEME_VARIANTS = [
    "surface",
    "background",
    "foreground",
    "highlight",
    "middlelight",
    "lowlight",
    "transparent",
    "semiTransparent",
    "disabled",
    "contrast",
    "selection"
  ];
  CosmopolitanTheme2.COSMOPOLITAN_THEME_ELEVATION = [
    "light",
    "dark"
  ];
  CosmopolitanTheme2.COSMOPOLITAN_THEME_ELEVATION_VARIANTS = [
    ELEVATION_KEY_LIGHT,
    ELEVATION_KEY_SEMILIGHT,
    ELEVATION_KEY_REGULAR,
    ELEVATION_KEY_SEMIBOLD,
    ELEVATION_KEY_BOLD,
    ELEVATION_KEY_EXTRABOLD
  ];
  CosmopolitanTheme2.COSMOPOLITAN_THEME_TYPOGRAPHY = [
    TYPOGRAPHY_KEY_HEADLINE1,
    TYPOGRAPHY_KEY_HEADLINE2,
    TYPOGRAPHY_KEY_HEADLINE3,
    TYPOGRAPHY_KEY_HEADLINE4,
    TYPOGRAPHY_KEY_HEADLINE5,
    TYPOGRAPHY_KEY_HEADLINE6,
    TYPOGRAPHY_KEY_BODY1,
    TYPOGRAPHY_KEY_BODY2,
    TYPOGRAPHY_KEY_BUTTON
  ];
  CosmopolitanTheme2.COSMOPOLITAN_THEME_METADATA = {
    theme: CosmopolitanTheme2.COSMOPOLITAN_THEME,
    palettes: CosmopolitanTheme2.COSMOPOLITAN_THEME_PALETTES,
    paletteVariants: CosmopolitanTheme2.COSMOPOLITAN_THEME_PALETTE_VARIANTS,
    schemes: CosmopolitanTheme2.COSMOPOLITAN_THEME_SCHEMES,
    schemeVariants: CosmopolitanTheme2.COSMOPOLITAN_THEME_SCHEME_VARIANTS,
    elevation: CosmopolitanTheme2.COSMOPOLITAN_THEME_ELEVATION,
    elevationVariants: CosmopolitanTheme2.COSMOPOLITAN_THEME_ELEVATION_VARIANTS,
    typographies: CosmopolitanTheme2.COSMOPOLITAN_THEME_TYPOGRAPHY
  };
})(exports.CosmopolitanTheme || (exports.CosmopolitanTheme = {}));
exports.CosmopolitanTheme = void 0;

// src/theming/tokens/JoyTokens.ts
var NAME2 = "joy";
var FONT_FAMILY2 = "Nunito, sans-serif";
var LAYOUT_RADIUS2 = "12px";
var LAYOUT_SPACE2 = "8px";
var LAYOUT_THICKNESS2 = "2px";
var SCHEME_LIGHT_SURFACE2 = "#f5f5f5";
var SCHEME_LIGHT_BACKGROUND2 = "#eaeaea";
var SCHEME_LIGHT_FOREGROUND2 = "#3c454f";
var SCHEME_LIGHT_HIGHLIGHT2 = "#d1d1d1";
var SCHEME_LIGHT_MIDDLELIGHT2 = "#8a8a8a";
var SCHEME_LIGHT_LOWLIGHT2 = "#5c5c5c";
var SCHEME_LIGHT_TRANSPARENT2 = "rgba(255, 255, 255, 0)";
var SCHEME_LIGHT_SEMI_TRANSPARENT2 = "rgba(255, 255, 255, 0.6666666666666666)";
var SCHEME_LIGHT_DISABLED2 = "#686868";
var SCHEME_LIGHT_CONTRAST2 = "#ffffff";
var SCHEME_LIGHT_SELECTION2 = "rgba(204, 204, 204, 0.4392156862745098)";
var SCHEME_DARK_SURFACE2 = "#1e1e1e";
var SCHEME_DARK_BACKGROUND2 = "#151515";
var SCHEME_DARK_FOREGROUND2 = "#c3bab0";
var SCHEME_DARK_HIGHLIGHT2 = "#2e2e2e";
var SCHEME_DARK_MIDDLELIGHT2 = "#757575";
var SCHEME_DARK_LOWLIGHT2 = "#a3a3a3";
var SCHEME_DARK_TRANSPARENT2 = "rgba(255, 255, 255, 0)";
var SCHEME_DARK_SEMI_TRANSPARENT2 = "rgba(255, 255, 255, 0.03137254901960784)";
var SCHEME_DARK_DISABLED2 = "#474747";
var SCHEME_DARK_CONTRAST2 = "#000000";
var SCHEME_DARK_SELECTION2 = "rgba(204, 204, 204, 0.4392156862745098)";
var COLOR_LIGHT_PRIMARY_02 = "#ffffff";
var COLOR_LIGHT_PRIMARY_502 = "#fce4ec";
var COLOR_LIGHT_PRIMARY_1002 = "#f8bcd0";
var COLOR_LIGHT_PRIMARY_2002 = "#f48fb1";
var COLOR_LIGHT_PRIMARY_3002 = "#f06292";
var COLOR_LIGHT_PRIMARY_4002 = "#ec407a";
var COLOR_LIGHT_PRIMARY_5002 = "#e91e63";
var COLOR_LIGHT_PRIMARY_6002 = "#cb1a56";
var COLOR_LIGHT_PRIMARY_7002 = "#a31545";
var COLOR_LIGHT_PRIMARY_8002 = "#7e1035";
var COLOR_LIGHT_PRIMARY_9002 = "#3a0819";
var COLOR_LIGHT_SECONDARY_02 = "#ffffff";
var COLOR_LIGHT_SECONDARY_502 = "#e6f6e9";
var COLOR_LIGHT_SECONDARY_1002 = "#c3e8c9";
var COLOR_LIGHT_SECONDARY_2002 = "#9bd9a7";
var COLOR_LIGHT_SECONDARY_3002 = "#70cb83";
var COLOR_LIGHT_SECONDARY_4002 = "#4dbf68";
var COLOR_LIGHT_SECONDARY_5002 = "#21b34d";
var COLOR_LIGHT_SECONDARY_6002 = "#16a444";
var COLOR_LIGHT_SECONDARY_7002 = "#009238";
var COLOR_LIGHT_SECONDARY_8002 = "#00812d";
var COLOR_LIGHT_SECONDARY_9002 = "#006218";
var COLOR_LIGHT_TERTIARY_02 = "#ffffff";
var COLOR_LIGHT_TERTIARY_502 = "#e1f5fc";
var COLOR_LIGHT_TERTIARY_1002 = "#b4e6f7";
var COLOR_LIGHT_TERTIARY_2002 = "#84d5f3";
var COLOR_LIGHT_TERTIARY_3002 = "#56c5ee";
var COLOR_LIGHT_TERTIARY_4002 = "#35b8eb";
var COLOR_LIGHT_TERTIARY_5002 = "#19ace9";
var COLOR_LIGHT_TERTIARY_6002 = "#139edb";
var COLOR_LIGHT_TERTIARY_7002 = "#098bc7";
var COLOR_LIGHT_TERTIARY_8002 = "#087ab4";
var COLOR_LIGHT_TERTIARY_9002 = "#005a92";
var COLOR_LIGHT_INFO_02 = "#ffffff";
var COLOR_LIGHT_INFO_502 = "#f4faff";
var COLOR_LIGHT_INFO_1002 = "#ddf1ff";
var COLOR_LIGHT_INFO_2002 = "#addbff";
var COLOR_LIGHT_INFO_3002 = "#6fb6ff";
var COLOR_LIGHT_INFO_4002 = "#3990ff";
var COLOR_LIGHT_INFO_5002 = "#096bde";
var COLOR_LIGHT_INFO_6002 = "#054da7";
var COLOR_LIGHT_INFO_7002 = "#02367d";
var COLOR_LIGHT_INFO_8002 = "#072859";
var COLOR_LIGHT_INFO_9002 = "#00153c";
var COLOR_LIGHT_WARNING_02 = "#ffffff";
var COLOR_LIGHT_WARNING_502 = "#fff8c5";
var COLOR_LIGHT_WARNING_1002 = "#fae17d";
var COLOR_LIGHT_WARNING_2002 = "#eac54f";
var COLOR_LIGHT_WARNING_3002 = "#d4a72c";
var COLOR_LIGHT_WARNING_4002 = "#bf8700";
var COLOR_LIGHT_WARNING_5002 = "#9a6700";
var COLOR_LIGHT_WARNING_6002 = "#7d4e00";
var COLOR_LIGHT_WARNING_7002 = "#633c01";
var COLOR_LIGHT_WARNING_8002 = "#4d2d00";
var COLOR_LIGHT_WARNING_9002 = "#3b2300";
var COLOR_LIGHT_DANGER_02 = "#ffffff";
var COLOR_LIGHT_DANGER_502 = "#fff8f6";
var COLOR_LIGHT_DANGER_1002 = "#ffe9e8";
var COLOR_LIGHT_DANGER_2002 = "#ffc7c5";
var COLOR_LIGHT_DANGER_3002 = "#ff9192";
var COLOR_LIGHT_DANGER_4002 = "#fa5255";
var COLOR_LIGHT_DANGER_5002 = "#d3232f";
var COLOR_LIGHT_DANGER_6002 = "#a10e25";
var COLOR_LIGHT_DANGER_7002 = "#77061b";
var COLOR_LIGHT_DANGER_8002 = "#580013";
var COLOR_LIGHT_DANGER_9002 = "#39000d";
var COLOR_LIGHT_SUCCESS_02 = "#ffffff";
var COLOR_LIGHT_SUCCESS_502 = "#f3fef5";
var COLOR_LIGHT_SUCCESS_1002 = "#d7f5dd";
var COLOR_LIGHT_SUCCESS_2002 = "#77ec95";
var COLOR_LIGHT_SUCCESS_3002 = "#4cc76e";
var COLOR_LIGHT_SUCCESS_4002 = "#2ca24d";
var COLOR_LIGHT_SUCCESS_5002 = "#1a7d36";
var COLOR_LIGHT_SUCCESS_6002 = "#0f5d26";
var COLOR_LIGHT_SUCCESS_7002 = "#034318";
var COLOR_LIGHT_SUCCESS_8002 = "#002f0f";
var COLOR_LIGHT_SUCCESS_9002 = "#001d09";
var COLOR_LIGHT_HIGHLIGHT_02 = "#ffffff";
var COLOR_LIGHT_HIGHLIGHT_502 = "#fdf7ff";
var COLOR_LIGHT_HIGHLIGHT_1002 = "#f4eaff";
var COLOR_LIGHT_HIGHLIGHT_2002 = "#e1cbff";
var COLOR_LIGHT_HIGHLIGHT_3002 = "#c69eff";
var COLOR_LIGHT_HIGHLIGHT_4002 = "#a374f9";
var COLOR_LIGHT_HIGHLIGHT_5002 = "#814dde";
var COLOR_LIGHT_HIGHLIGHT_6002 = "#5f35ae";
var COLOR_LIGHT_HIGHLIGHT_7002 = "#452382";
var COLOR_LIGHT_HIGHLIGHT_8002 = "#301761";
var COLOR_LIGHT_HIGHLIGHT_9002 = "#1d0a42";
var COLOR_LIGHT_NEUTRAL_02 = "#ffffff";
var COLOR_LIGHT_NEUTRAL_502 = "#f7f7f8";
var COLOR_LIGHT_NEUTRAL_1002 = "#ebebef";
var COLOR_LIGHT_NEUTRAL_2002 = "#d8d8df";
var COLOR_LIGHT_NEUTRAL_3002 = "#b9b9c6";
var COLOR_LIGHT_NEUTRAL_4002 = "#8f8fa3";
var COLOR_LIGHT_NEUTRAL_5002 = "#73738c";
var COLOR_LIGHT_NEUTRAL_6002 = "#5a5a72";
var COLOR_LIGHT_NEUTRAL_7002 = "#434356";
var COLOR_LIGHT_NEUTRAL_8002 = "#25252d";
var COLOR_LIGHT_NEUTRAL_9002 = "#131318";
var COLOR_DARK_PRIMARY_02 = "#000000";
var COLOR_DARK_PRIMARY_502 = "#3a0819";
var COLOR_DARK_PRIMARY_1002 = "#7e1035";
var COLOR_DARK_PRIMARY_2002 = "#a31545";
var COLOR_DARK_PRIMARY_3002 = "#cb1a56";
var COLOR_DARK_PRIMARY_4002 = "#e91e63";
var COLOR_DARK_PRIMARY_5002 = "#ec407a";
var COLOR_DARK_PRIMARY_6002 = "#f06292";
var COLOR_DARK_PRIMARY_7002 = "#f48fb1";
var COLOR_DARK_PRIMARY_8002 = "#f8bcd0";
var COLOR_DARK_PRIMARY_9002 = "#fce4ec";
var COLOR_DARK_SECONDARY_02 = "#000000";
var COLOR_DARK_SECONDARY_502 = "#006218";
var COLOR_DARK_SECONDARY_1002 = "#00812d";
var COLOR_DARK_SECONDARY_2002 = "#009238";
var COLOR_DARK_SECONDARY_3002 = "#16a444";
var COLOR_DARK_SECONDARY_4002 = "#21b34d";
var COLOR_DARK_SECONDARY_5002 = "#4dbf68";
var COLOR_DARK_SECONDARY_6002 = "#70cb83";
var COLOR_DARK_SECONDARY_7002 = "#9bd9a7";
var COLOR_DARK_SECONDARY_8002 = "#c3e8c9";
var COLOR_DARK_SECONDARY_9002 = "#e6f6e9";
var COLOR_DARK_TERTIARY_02 = "#000000";
var COLOR_DARK_TERTIARY_502 = "#005a92";
var COLOR_DARK_TERTIARY_1002 = "#087ab4";
var COLOR_DARK_TERTIARY_2002 = "#098bc7";
var COLOR_DARK_TERTIARY_3002 = "#139edb";
var COLOR_DARK_TERTIARY_4002 = "#19ace9";
var COLOR_DARK_TERTIARY_5002 = "#35b8eb";
var COLOR_DARK_TERTIARY_6002 = "#56c5ee";
var COLOR_DARK_TERTIARY_7002 = "#84d5f3";
var COLOR_DARK_TERTIARY_8002 = "#b4e6f7";
var COLOR_DARK_TERTIARY_9002 = "#e1f5fc";
var COLOR_DARK_INFO_02 = "#000000";
var COLOR_DARK_INFO_502 = "#00153c";
var COLOR_DARK_INFO_1002 = "#072859";
var COLOR_DARK_INFO_2002 = "#02367d";
var COLOR_DARK_INFO_3002 = "#054da7";
var COLOR_DARK_INFO_4002 = "#096bde";
var COLOR_DARK_INFO_5002 = "#3990ff";
var COLOR_DARK_INFO_6002 = "#6fb6ff";
var COLOR_DARK_INFO_7002 = "#addbff";
var COLOR_DARK_INFO_8002 = "#ddf1ff";
var COLOR_DARK_INFO_9002 = "#f4faff";
var COLOR_DARK_WARNING_02 = "#000000";
var COLOR_DARK_WARNING_502 = "#3b2300";
var COLOR_DARK_WARNING_1002 = "#4d2d00";
var COLOR_DARK_WARNING_2002 = "#633c01";
var COLOR_DARK_WARNING_3002 = "#7d4e00";
var COLOR_DARK_WARNING_4002 = "#9a6700";
var COLOR_DARK_WARNING_5002 = "#bf8700";
var COLOR_DARK_WARNING_6002 = "#d4a72c";
var COLOR_DARK_WARNING_7002 = "#eac54f";
var COLOR_DARK_WARNING_8002 = "#fae17d";
var COLOR_DARK_WARNING_9002 = "#fff8c5";
var COLOR_DARK_DANGER_02 = "#000000";
var COLOR_DARK_DANGER_502 = "#39000d";
var COLOR_DARK_DANGER_1002 = "#580013";
var COLOR_DARK_DANGER_2002 = "#77061b";
var COLOR_DARK_DANGER_3002 = "#a10e25";
var COLOR_DARK_DANGER_4002 = "#d3232f";
var COLOR_DARK_DANGER_5002 = "#fa5255";
var COLOR_DARK_DANGER_6002 = "#ff9192";
var COLOR_DARK_DANGER_7002 = "#ffc7c5";
var COLOR_DARK_DANGER_8002 = "#ffe9e8";
var COLOR_DARK_DANGER_9002 = "#fff8f6";
var COLOR_DARK_SUCCESS_02 = "#000000";
var COLOR_DARK_SUCCESS_502 = "#001d09";
var COLOR_DARK_SUCCESS_1002 = "#002f0f";
var COLOR_DARK_SUCCESS_2002 = "#034318";
var COLOR_DARK_SUCCESS_3002 = "#0f5d26";
var COLOR_DARK_SUCCESS_4002 = "#1a7d36";
var COLOR_DARK_SUCCESS_5002 = "#2ca24d";
var COLOR_DARK_SUCCESS_6002 = "#4cc76e";
var COLOR_DARK_SUCCESS_7002 = "#77ec95";
var COLOR_DARK_SUCCESS_8002 = "#d7f5dd";
var COLOR_DARK_SUCCESS_9002 = "#f3fef5";
var COLOR_DARK_HIGHLIGHT_02 = "#000000";
var COLOR_DARK_HIGHLIGHT_502 = "#1d0a42";
var COLOR_DARK_HIGHLIGHT_1002 = "#301761";
var COLOR_DARK_HIGHLIGHT_2002 = "#452382";
var COLOR_DARK_HIGHLIGHT_3002 = "#5f35ae";
var COLOR_DARK_HIGHLIGHT_4002 = "#814dde";
var COLOR_DARK_HIGHLIGHT_5002 = "#a374f9";
var COLOR_DARK_HIGHLIGHT_6002 = "#c69eff";
var COLOR_DARK_HIGHLIGHT_7002 = "#e1cbff";
var COLOR_DARK_HIGHLIGHT_8002 = "#f4eaff";
var COLOR_DARK_HIGHLIGHT_9002 = "#fdf7ff";
var COLOR_DARK_NEUTRAL_02 = "#000000";
var COLOR_DARK_NEUTRAL_502 = "#131318";
var COLOR_DARK_NEUTRAL_1002 = "#25252d";
var COLOR_DARK_NEUTRAL_2002 = "#434356";
var COLOR_DARK_NEUTRAL_3002 = "#5a5a72";
var COLOR_DARK_NEUTRAL_4002 = "#73738c";
var COLOR_DARK_NEUTRAL_5002 = "#8f8fa3";
var COLOR_DARK_NEUTRAL_6002 = "#b9b9c6";
var COLOR_DARK_NEUTRAL_7002 = "#d8d8df";
var COLOR_DARK_NEUTRAL_8002 = "#ebebef";
var COLOR_DARK_NEUTRAL_9002 = "#f7f7f8";
var TYPOGRAPHY_HEADLINE1_FONT_FAMILY2 = "Nunito, sans-serif";
var TYPOGRAPHY_HEADLINE1_FONT_SIZE2 = "96px";
var TYPOGRAPHY_HEADLINE1_LINE_HEIGHT2 = "100px";
var TYPOGRAPHY_HEADLINE1_FONT_WEIGHT2 = "300";
var TYPOGRAPHY_HEADLINE1_LETTER_SPACING2 = "-0.25px";
var TYPOGRAPHY_HEADLINE1_TEXT_DECORATION2 = "none";
var TYPOGRAPHY_HEADLINE1_TEXT_TRANSFORM2 = "none";
var TYPOGRAPHY_HEADLINE2_FONT_FAMILY2 = "Nunito, sans-serif";
var TYPOGRAPHY_HEADLINE2_FONT_SIZE2 = "60px";
var TYPOGRAPHY_HEADLINE2_LINE_HEIGHT2 = "64px";
var TYPOGRAPHY_HEADLINE2_FONT_WEIGHT2 = "300";
var TYPOGRAPHY_HEADLINE2_LETTER_SPACING2 = "-0.13333333333333333px";
var TYPOGRAPHY_HEADLINE2_TEXT_DECORATION2 = "none";
var TYPOGRAPHY_HEADLINE2_TEXT_TRANSFORM2 = "none";
var TYPOGRAPHY_HEADLINE3_FONT_FAMILY2 = "Nunito, sans-serif";
var TYPOGRAPHY_HEADLINE3_FONT_SIZE2 = "48px";
var TYPOGRAPHY_HEADLINE3_LINE_HEIGHT2 = "52px";
var TYPOGRAPHY_HEADLINE3_FONT_WEIGHT2 = "400";
var TYPOGRAPHY_HEADLINE3_LETTER_SPACING2 = "normal";
var TYPOGRAPHY_HEADLINE3_TEXT_DECORATION2 = "none";
var TYPOGRAPHY_HEADLINE3_TEXT_TRANSFORM2 = "none";
var TYPOGRAPHY_HEADLINE4_FONT_FAMILY2 = "Nunito, sans-serif";
var TYPOGRAPHY_HEADLINE4_FONT_SIZE2 = "34px";
var TYPOGRAPHY_HEADLINE4_LINE_HEIGHT2 = "38px";
var TYPOGRAPHY_HEADLINE4_FONT_WEIGHT2 = "400";
var TYPOGRAPHY_HEADLINE4_LETTER_SPACING2 = "0.11764705882352941px";
var TYPOGRAPHY_HEADLINE4_TEXT_DECORATION2 = "none";
var TYPOGRAPHY_HEADLINE4_TEXT_TRANSFORM2 = "none";
var TYPOGRAPHY_HEADLINE5_FONT_FAMILY2 = "Nunito, sans-serif";
var TYPOGRAPHY_HEADLINE5_FONT_SIZE2 = "24px";
var TYPOGRAPHY_HEADLINE5_LINE_HEIGHT2 = "28px";
var TYPOGRAPHY_HEADLINE5_FONT_WEIGHT2 = "400";
var TYPOGRAPHY_HEADLINE5_LETTER_SPACING2 = "normal";
var TYPOGRAPHY_HEADLINE5_TEXT_DECORATION2 = "none";
var TYPOGRAPHY_HEADLINE5_TEXT_TRANSFORM2 = "none";
var TYPOGRAPHY_HEADLINE6_FONT_FAMILY2 = "Nunito, sans-serif";
var TYPOGRAPHY_HEADLINE6_FONT_SIZE2 = "20px";
var TYPOGRAPHY_HEADLINE6_LINE_HEIGHT2 = "24px";
var TYPOGRAPHY_HEADLINE6_FONT_WEIGHT2 = "500";
var TYPOGRAPHY_HEADLINE6_LETTER_SPACING2 = "0.2px";
var TYPOGRAPHY_HEADLINE6_TEXT_DECORATION2 = "none";
var TYPOGRAPHY_HEADLINE6_TEXT_TRANSFORM2 = "none";
var TYPOGRAPHY_SUBTITLE1_FONT_FAMILY2 = "Nunito, sans-serif";
var TYPOGRAPHY_SUBTITLE1_FONT_SIZE2 = "16px";
var TYPOGRAPHY_SUBTITLE1_LINE_HEIGHT2 = "20px";
var TYPOGRAPHY_SUBTITLE1_FONT_WEIGHT2 = "400";
var TYPOGRAPHY_SUBTITLE1_LETTER_SPACING2 = "0.15px";
var TYPOGRAPHY_SUBTITLE1_TEXT_DECORATION2 = "none";
var TYPOGRAPHY_SUBTITLE1_TEXT_TRANSFORM2 = "none";
var TYPOGRAPHY_SUBTITLE2_FONT_FAMILY2 = "Nunito, sans-serif";
var TYPOGRAPHY_SUBTITLE2_FONT_SIZE2 = "14px";
var TYPOGRAPHY_SUBTITLE2_LINE_HEIGHT2 = "18px";
var TYPOGRAPHY_SUBTITLE2_FONT_WEIGHT2 = "500";
var TYPOGRAPHY_SUBTITLE2_LETTER_SPACING2 = "0.1142857142857143px";
var TYPOGRAPHY_SUBTITLE2_TEXT_DECORATION2 = "none";
var TYPOGRAPHY_SUBTITLE2_TEXT_TRANSFORM2 = "none";
var TYPOGRAPHY_BODY1_FONT_FAMILY2 = "Nunito, sans-serif";
var TYPOGRAPHY_BODY1_FONT_SIZE2 = "16px";
var TYPOGRAPHY_BODY1_LINE_HEIGHT2 = "20px";
var TYPOGRAPHY_BODY1_FONT_WEIGHT2 = "400";
var TYPOGRAPHY_BODY1_LETTER_SPACING2 = "0.5px";
var TYPOGRAPHY_BODY1_TEXT_DECORATION2 = "none";
var TYPOGRAPHY_BODY1_TEXT_TRANSFORM2 = "none";
var TYPOGRAPHY_BODY2_FONT_FAMILY2 = "Nunito, sans-serif";
var TYPOGRAPHY_BODY2_FONT_SIZE2 = "14px";
var TYPOGRAPHY_BODY2_LINE_HEIGHT2 = "18px";
var TYPOGRAPHY_BODY2_FONT_WEIGHT2 = "400";
var TYPOGRAPHY_BODY2_LETTER_SPACING2 = "0.2857142857142857px";
var TYPOGRAPHY_BODY2_TEXT_DECORATION2 = "none";
var TYPOGRAPHY_BODY2_TEXT_TRANSFORM2 = "none";
var TYPOGRAPHY_SUPPORTING_FONT_FAMILY2 = "Nunito, sans-serif";
var TYPOGRAPHY_SUPPORTING_FONT_SIZE2 = "12px";
var TYPOGRAPHY_SUPPORTING_LINE_HEIGHT2 = "14px";
var TYPOGRAPHY_SUPPORTING_FONT_WEIGHT2 = "400";
var TYPOGRAPHY_SUPPORTING_LETTER_SPACING2 = "0.2857142857142857px";
var TYPOGRAPHY_SUPPORTING_TEXT_DECORATION2 = "none";
var TYPOGRAPHY_SUPPORTING_TEXT_TRANSFORM2 = "none";
var TYPOGRAPHY_CAPTION_FONT_FAMILY2 = "Nunito, sans-serif";
var TYPOGRAPHY_CAPTION_FONT_SIZE2 = "12px";
var TYPOGRAPHY_CAPTION_LINE_HEIGHT2 = "16px";
var TYPOGRAPHY_CAPTION_FONT_WEIGHT2 = "400";
var TYPOGRAPHY_CAPTION_LETTER_SPACING2 = "0.5333333333333333px";
var TYPOGRAPHY_CAPTION_TEXT_DECORATION2 = "none";
var TYPOGRAPHY_CAPTION_TEXT_TRANSFORM2 = "none";
var TYPOGRAPHY_BUTTON_FONT_FAMILY2 = "Nunito, sans-serif";
var TYPOGRAPHY_BUTTON_FONT_SIZE2 = "14px";
var TYPOGRAPHY_BUTTON_LINE_HEIGHT2 = "18px";
var TYPOGRAPHY_BUTTON_FONT_WEIGHT2 = "700";
var TYPOGRAPHY_BUTTON_LETTER_SPACING2 = "1.4285714285714286px";
var TYPOGRAPHY_BUTTON_TEXT_DECORATION2 = "none";
var TYPOGRAPHY_BUTTON_TEXT_TRANSFORM2 = "none";
var TYPOGRAPHY_OVERLINE_FONT_FAMILY2 = "Nunito, sans-serif";
var TYPOGRAPHY_OVERLINE_FONT_SIZE2 = "12px";
var TYPOGRAPHY_OVERLINE_LINE_HEIGHT2 = "16px";
var TYPOGRAPHY_OVERLINE_FONT_WEIGHT2 = "500";
var TYPOGRAPHY_OVERLINE_LETTER_SPACING2 = "2.6666666666666665px";
var TYPOGRAPHY_OVERLINE_TEXT_DECORATION2 = "none";
var TYPOGRAPHY_OVERLINE_TEXT_TRANSFORM2 = "none";
var ELEVATION_LIGHT_LIGHT2 = "0px 2px 2px -2px rgba(0, 0, 0, 0.17)";
var ELEVATION_LIGHT_SEMILIGHT2 = "0px 4px 4px -2px rgba(0, 0, 0, 0.17)";
var ELEVATION_LIGHT_REGULAR2 = "0px 6px 6px -2px rgba(0, 0, 0, 0.17)";
var ELEVATION_LIGHT_SEMIBOLD2 = "0px 8px 8px -2px rgba(0, 0, 0, 0.17)";
var ELEVATION_LIGHT_BOLD2 = "0px 10px 10px -2px rgba(0, 0, 0, 0.17)";
var ELEVATION_LIGHT_EXTRABOLD2 = "0px 12px 12px -2px rgba(0, 0, 0, 0.17)";
var ELEVATION_DARK_LIGHT2 = "0px 2px 2px -2px rgba(0, 0, 0, 0.24)";
var ELEVATION_DARK_SEMILIGHT2 = "0px 4px 4px -2px rgba(0, 0, 0, 0.24)";
var ELEVATION_DARK_REGULAR2 = "0px 6px 6px -2px rgba(0, 0, 0, 0.24)";
var ELEVATION_DARK_SEMIBOLD2 = "0px 8px 8px -2px rgba(0, 0, 0, 0.24)";
var ELEVATION_DARK_BOLD2 = "0px 10px 10px -2px rgba(0, 0, 0, 0.24)";
var ELEVATION_DARK_EXTRABOLD2 = "0px 12px 12px -2px rgba(0, 0, 0, 0.24)";
var TYPOGRAPHY_KEY_HEADLINE12 = "headline1";
var TYPOGRAPHY_KEY_HEADLINE22 = "headline2";
var TYPOGRAPHY_KEY_HEADLINE32 = "headline3";
var TYPOGRAPHY_KEY_HEADLINE42 = "headline4";
var TYPOGRAPHY_KEY_HEADLINE52 = "headline5";
var TYPOGRAPHY_KEY_HEADLINE62 = "headline6";
var TYPOGRAPHY_KEY_SUBTITLE1 = "subtitle1";
var TYPOGRAPHY_KEY_SUBTITLE2 = "subtitle2";
var TYPOGRAPHY_KEY_BODY12 = "body1";
var TYPOGRAPHY_KEY_BODY22 = "body2";
var TYPOGRAPHY_KEY_SUPPORTING = "supporting";
var TYPOGRAPHY_KEY_CAPTION = "caption";
var TYPOGRAPHY_KEY_BUTTON2 = "button";
var TYPOGRAPHY_KEY_OVERLINE = "overline";
var ELEVATION_KEY_LIGHT2 = "light";
var ELEVATION_KEY_SEMILIGHT2 = "semilight";
var ELEVATION_KEY_REGULAR2 = "regular";
var ELEVATION_KEY_SEMIBOLD2 = "semibold";
var ELEVATION_KEY_BOLD2 = "bold";
var ELEVATION_KEY_EXTRABOLD2 = "extrabold";
var VARIANT_PRIMARY2 = "primary";
var VARIANT_SECONDARY2 = "secondary";
var VARIANT_TERTIARY2 = "tertiary";
var VARIANT_DANGER = "danger";
var VARIANT_WARNING = "warning";
var VARIANT_SUCCESS = "success";
var VARIANT_INFO = "info";
var VARIANT_HIGHLIGHT = "highlight";
var VARIANT_NEUTRAL = "neutral";
var DURATION_SHORT2 = "200ms";
var DURATION_MEDIUM2 = "400ms";
var DURATION_LONG2 = "600ms";

// src/theming/JoyTheme.ts
(function(JoyTheme2) {
  JoyTheme2.JOY_THEME = ThemeFactory.create({
    name: NAME2,
    scheme: {
      light: {
        surface: SCHEME_LIGHT_SURFACE2,
        background: SCHEME_LIGHT_BACKGROUND2,
        foreground: SCHEME_LIGHT_FOREGROUND2,
        highlight: SCHEME_LIGHT_HIGHLIGHT2,
        middlelight: SCHEME_LIGHT_MIDDLELIGHT2,
        lowlight: SCHEME_LIGHT_LOWLIGHT2,
        transparent: SCHEME_LIGHT_TRANSPARENT2,
        semiTransparent: SCHEME_LIGHT_SEMI_TRANSPARENT2,
        disabled: SCHEME_LIGHT_DISABLED2,
        contrast: SCHEME_LIGHT_CONTRAST2,
        selection: SCHEME_LIGHT_SELECTION2
      },
      dark: {
        surface: SCHEME_DARK_SURFACE2,
        background: SCHEME_DARK_BACKGROUND2,
        foreground: SCHEME_DARK_FOREGROUND2,
        highlight: SCHEME_DARK_HIGHLIGHT2,
        middlelight: SCHEME_DARK_MIDDLELIGHT2,
        lowlight: SCHEME_DARK_LOWLIGHT2,
        transparent: SCHEME_DARK_TRANSPARENT2,
        semiTransparent: SCHEME_DARK_SEMI_TRANSPARENT2,
        disabled: SCHEME_DARK_DISABLED2,
        contrast: SCHEME_DARK_CONTRAST2,
        selection: SCHEME_DARK_SELECTION2
      }
    },
    palette: {
      light: {
        primary: {
          0: COLOR_LIGHT_PRIMARY_02,
          50: COLOR_LIGHT_PRIMARY_502,
          100: COLOR_LIGHT_PRIMARY_1002,
          200: COLOR_LIGHT_PRIMARY_2002,
          300: COLOR_LIGHT_PRIMARY_3002,
          400: COLOR_LIGHT_PRIMARY_4002,
          500: COLOR_LIGHT_PRIMARY_5002,
          600: COLOR_LIGHT_PRIMARY_6002,
          700: COLOR_LIGHT_PRIMARY_7002,
          800: COLOR_LIGHT_PRIMARY_8002,
          900: COLOR_LIGHT_PRIMARY_9002
        },
        secondary: {
          0: COLOR_LIGHT_SECONDARY_02,
          50: COLOR_LIGHT_SECONDARY_502,
          100: COLOR_LIGHT_SECONDARY_1002,
          200: COLOR_LIGHT_SECONDARY_2002,
          300: COLOR_LIGHT_SECONDARY_3002,
          400: COLOR_LIGHT_SECONDARY_4002,
          500: COLOR_LIGHT_SECONDARY_5002,
          600: COLOR_LIGHT_SECONDARY_6002,
          700: COLOR_LIGHT_SECONDARY_7002,
          800: COLOR_LIGHT_SECONDARY_8002,
          900: COLOR_LIGHT_SECONDARY_9002
        },
        tertiary: {
          0: COLOR_LIGHT_TERTIARY_02,
          50: COLOR_LIGHT_TERTIARY_502,
          100: COLOR_LIGHT_TERTIARY_1002,
          200: COLOR_LIGHT_TERTIARY_2002,
          300: COLOR_LIGHT_TERTIARY_3002,
          400: COLOR_LIGHT_TERTIARY_4002,
          500: COLOR_LIGHT_TERTIARY_5002,
          600: COLOR_LIGHT_TERTIARY_6002,
          700: COLOR_LIGHT_TERTIARY_7002,
          800: COLOR_LIGHT_TERTIARY_8002,
          900: COLOR_LIGHT_TERTIARY_9002
        },
        info: {
          0: COLOR_LIGHT_INFO_02,
          50: COLOR_LIGHT_INFO_502,
          100: COLOR_LIGHT_INFO_1002,
          200: COLOR_LIGHT_INFO_2002,
          300: COLOR_LIGHT_INFO_3002,
          400: COLOR_LIGHT_INFO_4002,
          500: COLOR_LIGHT_INFO_5002,
          600: COLOR_LIGHT_INFO_6002,
          700: COLOR_LIGHT_INFO_7002,
          800: COLOR_LIGHT_INFO_8002,
          900: COLOR_LIGHT_INFO_9002
        },
        warning: {
          0: COLOR_LIGHT_WARNING_02,
          50: COLOR_LIGHT_WARNING_502,
          100: COLOR_LIGHT_WARNING_1002,
          200: COLOR_LIGHT_WARNING_2002,
          300: COLOR_LIGHT_WARNING_3002,
          400: COLOR_LIGHT_WARNING_4002,
          500: COLOR_LIGHT_WARNING_5002,
          600: COLOR_LIGHT_WARNING_6002,
          700: COLOR_LIGHT_WARNING_7002,
          800: COLOR_LIGHT_WARNING_8002,
          900: COLOR_LIGHT_WARNING_9002
        },
        danger: {
          0: COLOR_LIGHT_DANGER_02,
          50: COLOR_LIGHT_DANGER_502,
          100: COLOR_LIGHT_DANGER_1002,
          200: COLOR_LIGHT_DANGER_2002,
          300: COLOR_LIGHT_DANGER_3002,
          400: COLOR_LIGHT_DANGER_4002,
          500: COLOR_LIGHT_DANGER_5002,
          600: COLOR_LIGHT_DANGER_6002,
          700: COLOR_LIGHT_DANGER_7002,
          800: COLOR_LIGHT_DANGER_8002,
          900: COLOR_LIGHT_DANGER_9002
        },
        success: {
          0: COLOR_LIGHT_SUCCESS_02,
          50: COLOR_LIGHT_SUCCESS_502,
          100: COLOR_LIGHT_SUCCESS_1002,
          200: COLOR_LIGHT_SUCCESS_2002,
          300: COLOR_LIGHT_SUCCESS_3002,
          400: COLOR_LIGHT_SUCCESS_4002,
          500: COLOR_LIGHT_SUCCESS_5002,
          600: COLOR_LIGHT_SUCCESS_6002,
          700: COLOR_LIGHT_SUCCESS_7002,
          800: COLOR_LIGHT_SUCCESS_8002,
          900: COLOR_LIGHT_SUCCESS_9002
        },
        highlight: {
          0: COLOR_LIGHT_HIGHLIGHT_02,
          50: COLOR_LIGHT_HIGHLIGHT_502,
          100: COLOR_LIGHT_HIGHLIGHT_1002,
          200: COLOR_LIGHT_HIGHLIGHT_2002,
          300: COLOR_LIGHT_HIGHLIGHT_3002,
          400: COLOR_LIGHT_HIGHLIGHT_4002,
          500: COLOR_LIGHT_HIGHLIGHT_5002,
          600: COLOR_LIGHT_HIGHLIGHT_6002,
          700: COLOR_LIGHT_HIGHLIGHT_7002,
          800: COLOR_LIGHT_HIGHLIGHT_8002,
          900: COLOR_LIGHT_HIGHLIGHT_9002
        },
        neutral: {
          0: COLOR_LIGHT_NEUTRAL_02,
          50: COLOR_LIGHT_NEUTRAL_502,
          100: COLOR_LIGHT_NEUTRAL_1002,
          200: COLOR_LIGHT_NEUTRAL_2002,
          300: COLOR_LIGHT_NEUTRAL_3002,
          400: COLOR_LIGHT_NEUTRAL_4002,
          500: COLOR_LIGHT_NEUTRAL_5002,
          600: COLOR_LIGHT_NEUTRAL_6002,
          700: COLOR_LIGHT_NEUTRAL_7002,
          800: COLOR_LIGHT_NEUTRAL_8002,
          900: COLOR_LIGHT_NEUTRAL_9002
        }
      },
      dark: {
        primary: {
          0: COLOR_DARK_PRIMARY_02,
          50: COLOR_DARK_PRIMARY_502,
          100: COLOR_DARK_PRIMARY_1002,
          200: COLOR_DARK_PRIMARY_2002,
          300: COLOR_DARK_PRIMARY_3002,
          400: COLOR_DARK_PRIMARY_4002,
          500: COLOR_DARK_PRIMARY_5002,
          600: COLOR_DARK_PRIMARY_6002,
          700: COLOR_DARK_PRIMARY_7002,
          800: COLOR_DARK_PRIMARY_8002,
          900: COLOR_DARK_PRIMARY_9002
        },
        secondary: {
          0: COLOR_DARK_SECONDARY_02,
          50: COLOR_DARK_SECONDARY_502,
          100: COLOR_DARK_SECONDARY_1002,
          200: COLOR_DARK_SECONDARY_2002,
          300: COLOR_DARK_SECONDARY_3002,
          400: COLOR_DARK_SECONDARY_4002,
          500: COLOR_DARK_SECONDARY_5002,
          600: COLOR_DARK_SECONDARY_6002,
          700: COLOR_DARK_SECONDARY_7002,
          800: COLOR_DARK_SECONDARY_8002,
          900: COLOR_DARK_SECONDARY_9002
        },
        tertiary: {
          0: COLOR_DARK_TERTIARY_02,
          50: COLOR_DARK_TERTIARY_502,
          100: COLOR_DARK_TERTIARY_1002,
          200: COLOR_DARK_TERTIARY_2002,
          300: COLOR_DARK_TERTIARY_3002,
          400: COLOR_DARK_TERTIARY_4002,
          500: COLOR_DARK_TERTIARY_5002,
          600: COLOR_DARK_TERTIARY_6002,
          700: COLOR_DARK_TERTIARY_7002,
          800: COLOR_DARK_TERTIARY_8002,
          900: COLOR_DARK_TERTIARY_9002
        },
        info: {
          0: COLOR_DARK_INFO_02,
          50: COLOR_DARK_INFO_502,
          100: COLOR_DARK_INFO_1002,
          200: COLOR_DARK_INFO_2002,
          300: COLOR_DARK_INFO_3002,
          400: COLOR_DARK_INFO_4002,
          500: COLOR_DARK_INFO_5002,
          600: COLOR_DARK_INFO_6002,
          700: COLOR_DARK_INFO_7002,
          800: COLOR_DARK_INFO_8002,
          900: COLOR_DARK_INFO_9002
        },
        warning: {
          0: COLOR_DARK_WARNING_02,
          50: COLOR_DARK_WARNING_502,
          100: COLOR_DARK_WARNING_1002,
          200: COLOR_DARK_WARNING_2002,
          300: COLOR_DARK_WARNING_3002,
          400: COLOR_DARK_WARNING_4002,
          500: COLOR_DARK_WARNING_5002,
          600: COLOR_DARK_WARNING_6002,
          700: COLOR_DARK_WARNING_7002,
          800: COLOR_DARK_WARNING_8002,
          900: COLOR_DARK_WARNING_9002
        },
        danger: {
          0: COLOR_DARK_DANGER_02,
          50: COLOR_DARK_DANGER_502,
          100: COLOR_DARK_DANGER_1002,
          200: COLOR_DARK_DANGER_2002,
          300: COLOR_DARK_DANGER_3002,
          400: COLOR_DARK_DANGER_4002,
          500: COLOR_DARK_DANGER_5002,
          600: COLOR_DARK_DANGER_6002,
          700: COLOR_DARK_DANGER_7002,
          800: COLOR_DARK_DANGER_8002,
          900: COLOR_DARK_DANGER_9002
        },
        success: {
          0: COLOR_DARK_SUCCESS_02,
          50: COLOR_DARK_SUCCESS_502,
          100: COLOR_DARK_SUCCESS_1002,
          200: COLOR_DARK_SUCCESS_2002,
          300: COLOR_DARK_SUCCESS_3002,
          400: COLOR_DARK_SUCCESS_4002,
          500: COLOR_DARK_SUCCESS_5002,
          600: COLOR_DARK_SUCCESS_6002,
          700: COLOR_DARK_SUCCESS_7002,
          800: COLOR_DARK_SUCCESS_8002,
          900: COLOR_DARK_SUCCESS_9002
        },
        highlight: {
          0: COLOR_DARK_HIGHLIGHT_02,
          50: COLOR_DARK_HIGHLIGHT_502,
          100: COLOR_DARK_HIGHLIGHT_1002,
          200: COLOR_DARK_HIGHLIGHT_2002,
          300: COLOR_DARK_HIGHLIGHT_3002,
          400: COLOR_DARK_HIGHLIGHT_4002,
          500: COLOR_DARK_HIGHLIGHT_5002,
          600: COLOR_DARK_HIGHLIGHT_6002,
          700: COLOR_DARK_HIGHLIGHT_7002,
          800: COLOR_DARK_HIGHLIGHT_8002,
          900: COLOR_DARK_HIGHLIGHT_9002
        },
        neutral: {
          0: COLOR_DARK_NEUTRAL_02,
          50: COLOR_DARK_NEUTRAL_502,
          100: COLOR_DARK_NEUTRAL_1002,
          200: COLOR_DARK_NEUTRAL_2002,
          300: COLOR_DARK_NEUTRAL_3002,
          400: COLOR_DARK_NEUTRAL_4002,
          500: COLOR_DARK_NEUTRAL_5002,
          600: COLOR_DARK_NEUTRAL_6002,
          700: COLOR_DARK_NEUTRAL_7002,
          800: COLOR_DARK_NEUTRAL_8002,
          900: COLOR_DARK_NEUTRAL_9002
        }
      }
    },
    fontFamily: FONT_FAMILY2,
    typography: {
      headline1: {
        fontFamily: TYPOGRAPHY_HEADLINE1_FONT_FAMILY2,
        fontSize: TYPOGRAPHY_HEADLINE1_FONT_SIZE2,
        lineHeight: TYPOGRAPHY_HEADLINE1_LINE_HEIGHT2,
        fontWeight: TYPOGRAPHY_HEADLINE1_FONT_WEIGHT2,
        letterSpacing: TYPOGRAPHY_HEADLINE1_LETTER_SPACING2,
        textDecoration: TYPOGRAPHY_HEADLINE1_TEXT_DECORATION2,
        textTransform: TYPOGRAPHY_HEADLINE1_TEXT_TRANSFORM2
      },
      headline2: {
        fontFamily: TYPOGRAPHY_HEADLINE2_FONT_FAMILY2,
        fontSize: TYPOGRAPHY_HEADLINE2_FONT_SIZE2,
        lineHeight: TYPOGRAPHY_HEADLINE2_LINE_HEIGHT2,
        fontWeight: TYPOGRAPHY_HEADLINE2_FONT_WEIGHT2,
        letterSpacing: TYPOGRAPHY_HEADLINE2_LETTER_SPACING2,
        textDecoration: TYPOGRAPHY_HEADLINE2_TEXT_DECORATION2,
        textTransform: TYPOGRAPHY_HEADLINE2_TEXT_TRANSFORM2
      },
      headline3: {
        fontFamily: TYPOGRAPHY_HEADLINE3_FONT_FAMILY2,
        fontSize: TYPOGRAPHY_HEADLINE3_FONT_SIZE2,
        lineHeight: TYPOGRAPHY_HEADLINE3_LINE_HEIGHT2,
        fontWeight: TYPOGRAPHY_HEADLINE3_FONT_WEIGHT2,
        letterSpacing: TYPOGRAPHY_HEADLINE3_LETTER_SPACING2,
        textDecoration: TYPOGRAPHY_HEADLINE3_TEXT_DECORATION2,
        textTransform: TYPOGRAPHY_HEADLINE3_TEXT_TRANSFORM2
      },
      headline4: {
        fontFamily: TYPOGRAPHY_HEADLINE4_FONT_FAMILY2,
        fontSize: TYPOGRAPHY_HEADLINE4_FONT_SIZE2,
        lineHeight: TYPOGRAPHY_HEADLINE4_LINE_HEIGHT2,
        fontWeight: TYPOGRAPHY_HEADLINE4_FONT_WEIGHT2,
        letterSpacing: TYPOGRAPHY_HEADLINE4_LETTER_SPACING2,
        textDecoration: TYPOGRAPHY_HEADLINE4_TEXT_DECORATION2,
        textTransform: TYPOGRAPHY_HEADLINE4_TEXT_TRANSFORM2
      },
      headline5: {
        fontFamily: TYPOGRAPHY_HEADLINE5_FONT_FAMILY2,
        fontSize: TYPOGRAPHY_HEADLINE5_FONT_SIZE2,
        lineHeight: TYPOGRAPHY_HEADLINE5_LINE_HEIGHT2,
        fontWeight: TYPOGRAPHY_HEADLINE5_FONT_WEIGHT2,
        letterSpacing: TYPOGRAPHY_HEADLINE5_LETTER_SPACING2,
        textDecoration: TYPOGRAPHY_HEADLINE5_TEXT_DECORATION2,
        textTransform: TYPOGRAPHY_HEADLINE5_TEXT_TRANSFORM2
      },
      headline6: {
        fontFamily: TYPOGRAPHY_HEADLINE6_FONT_FAMILY2,
        fontSize: TYPOGRAPHY_HEADLINE6_FONT_SIZE2,
        lineHeight: TYPOGRAPHY_HEADLINE6_LINE_HEIGHT2,
        fontWeight: TYPOGRAPHY_HEADLINE6_FONT_WEIGHT2,
        letterSpacing: TYPOGRAPHY_HEADLINE6_LETTER_SPACING2,
        textDecoration: TYPOGRAPHY_HEADLINE6_TEXT_DECORATION2,
        textTransform: TYPOGRAPHY_HEADLINE6_TEXT_TRANSFORM2
      },
      subtitle1: {
        fontFamily: TYPOGRAPHY_SUBTITLE1_FONT_FAMILY2,
        fontSize: TYPOGRAPHY_SUBTITLE1_FONT_SIZE2,
        lineHeight: TYPOGRAPHY_SUBTITLE1_LINE_HEIGHT2,
        fontWeight: TYPOGRAPHY_SUBTITLE1_FONT_WEIGHT2,
        letterSpacing: TYPOGRAPHY_SUBTITLE1_LETTER_SPACING2,
        textDecoration: TYPOGRAPHY_SUBTITLE1_TEXT_DECORATION2,
        textTransform: TYPOGRAPHY_SUBTITLE1_TEXT_TRANSFORM2
      },
      subtitle2: {
        fontFamily: TYPOGRAPHY_SUBTITLE2_FONT_FAMILY2,
        fontSize: TYPOGRAPHY_SUBTITLE2_FONT_SIZE2,
        lineHeight: TYPOGRAPHY_SUBTITLE2_LINE_HEIGHT2,
        fontWeight: TYPOGRAPHY_SUBTITLE2_FONT_WEIGHT2,
        letterSpacing: TYPOGRAPHY_SUBTITLE2_LETTER_SPACING2,
        textDecoration: TYPOGRAPHY_SUBTITLE2_TEXT_DECORATION2,
        textTransform: TYPOGRAPHY_SUBTITLE2_TEXT_TRANSFORM2
      },
      body1: {
        fontFamily: TYPOGRAPHY_BODY1_FONT_FAMILY2,
        fontSize: TYPOGRAPHY_BODY1_FONT_SIZE2,
        lineHeight: TYPOGRAPHY_BODY1_LINE_HEIGHT2,
        fontWeight: TYPOGRAPHY_BODY1_FONT_WEIGHT2,
        letterSpacing: TYPOGRAPHY_BODY1_LETTER_SPACING2,
        textDecoration: TYPOGRAPHY_BODY1_TEXT_DECORATION2,
        textTransform: TYPOGRAPHY_BODY1_TEXT_TRANSFORM2
      },
      body2: {
        fontFamily: TYPOGRAPHY_BODY2_FONT_FAMILY2,
        fontSize: TYPOGRAPHY_BODY2_FONT_SIZE2,
        lineHeight: TYPOGRAPHY_BODY2_LINE_HEIGHT2,
        fontWeight: TYPOGRAPHY_BODY2_FONT_WEIGHT2,
        letterSpacing: TYPOGRAPHY_BODY2_LETTER_SPACING2,
        textDecoration: TYPOGRAPHY_BODY2_TEXT_DECORATION2,
        textTransform: TYPOGRAPHY_BODY2_TEXT_TRANSFORM2
      },
      supporting: {
        fontFamily: TYPOGRAPHY_SUPPORTING_FONT_FAMILY2,
        fontSize: TYPOGRAPHY_SUPPORTING_FONT_SIZE2,
        lineHeight: TYPOGRAPHY_SUPPORTING_LINE_HEIGHT2,
        fontWeight: TYPOGRAPHY_SUPPORTING_FONT_WEIGHT2,
        letterSpacing: TYPOGRAPHY_SUPPORTING_LETTER_SPACING2,
        textDecoration: TYPOGRAPHY_SUPPORTING_TEXT_DECORATION2,
        textTransform: TYPOGRAPHY_SUPPORTING_TEXT_TRANSFORM2
      },
      caption: {
        fontFamily: TYPOGRAPHY_CAPTION_FONT_FAMILY2,
        fontSize: TYPOGRAPHY_CAPTION_FONT_SIZE2,
        lineHeight: TYPOGRAPHY_CAPTION_LINE_HEIGHT2,
        fontWeight: TYPOGRAPHY_CAPTION_FONT_WEIGHT2,
        letterSpacing: TYPOGRAPHY_CAPTION_LETTER_SPACING2,
        textDecoration: TYPOGRAPHY_CAPTION_TEXT_DECORATION2,
        textTransform: TYPOGRAPHY_CAPTION_TEXT_TRANSFORM2
      },
      overline: {
        fontFamily: TYPOGRAPHY_OVERLINE_FONT_FAMILY2,
        fontSize: TYPOGRAPHY_OVERLINE_FONT_SIZE2,
        lineHeight: TYPOGRAPHY_OVERLINE_LINE_HEIGHT2,
        fontWeight: TYPOGRAPHY_OVERLINE_FONT_WEIGHT2,
        letterSpacing: TYPOGRAPHY_OVERLINE_LETTER_SPACING2,
        textDecoration: TYPOGRAPHY_OVERLINE_TEXT_DECORATION2,
        textTransform: TYPOGRAPHY_OVERLINE_TEXT_TRANSFORM2
      },
      button: {
        fontFamily: TYPOGRAPHY_BUTTON_FONT_FAMILY2,
        fontSize: TYPOGRAPHY_BUTTON_FONT_SIZE2,
        lineHeight: TYPOGRAPHY_BUTTON_LINE_HEIGHT2,
        fontWeight: TYPOGRAPHY_BUTTON_FONT_WEIGHT2,
        letterSpacing: TYPOGRAPHY_BUTTON_LETTER_SPACING2,
        textDecoration: TYPOGRAPHY_BUTTON_TEXT_DECORATION2,
        textTransform: TYPOGRAPHY_BUTTON_TEXT_TRANSFORM2
      }
    },
    layout: {
      radius: LAYOUT_RADIUS2,
      space: LAYOUT_SPACE2,
      thickness: LAYOUT_THICKNESS2
    },
    duration: {
      short: DURATION_SHORT2,
      medium: DURATION_MEDIUM2,
      long: DURATION_LONG2
    },
    elevation: {
      light: {
        light: ELEVATION_LIGHT_LIGHT2,
        semilight: ELEVATION_LIGHT_SEMILIGHT2,
        regular: ELEVATION_LIGHT_REGULAR2,
        semibold: ELEVATION_LIGHT_SEMIBOLD2,
        bold: ELEVATION_LIGHT_BOLD2,
        extrabold: ELEVATION_LIGHT_EXTRABOLD2
      },
      dark: {
        light: ELEVATION_DARK_LIGHT2,
        semilight: ELEVATION_DARK_SEMILIGHT2,
        regular: ELEVATION_DARK_REGULAR2,
        semibold: ELEVATION_DARK_SEMIBOLD2,
        bold: ELEVATION_DARK_BOLD2,
        extrabold: ELEVATION_DARK_EXTRABOLD2
      }
    }
  });
  JoyTheme2.JOY_THEME_PALETTES = [
    VARIANT_PRIMARY2,
    VARIANT_SECONDARY2,
    VARIANT_TERTIARY2,
    VARIANT_DANGER,
    VARIANT_INFO,
    VARIANT_WARNING,
    VARIANT_SUCCESS,
    VARIANT_HIGHLIGHT,
    VARIANT_NEUTRAL
  ];
  JoyTheme2.JOY_THEME_PALETTE_VARIANTS = [
    "0",
    "50",
    "100",
    "200",
    "300",
    "400",
    "500",
    "600",
    "700",
    "800",
    "900"
  ];
  JoyTheme2.JOY_THEME_SCHEMES = [
    "light",
    "dark"
  ];
  JoyTheme2.JOY_THEME_SCHEME_VARIANTS = [
    "surface",
    "background",
    "foreground",
    "highlight",
    "middlelight",
    "lowlight",
    "transparent",
    "semiTransparent",
    "disabled",
    "contrast",
    "selection"
  ];
  JoyTheme2.JOY_THEME_ELEVATION = [
    "light",
    "dark"
  ];
  JoyTheme2.JOY_THEME_ELEVATION_VARIANTS = [
    ELEVATION_KEY_LIGHT2,
    ELEVATION_KEY_SEMILIGHT2,
    ELEVATION_KEY_REGULAR2,
    ELEVATION_KEY_SEMIBOLD2,
    ELEVATION_KEY_BOLD2,
    ELEVATION_KEY_EXTRABOLD2
  ];
  JoyTheme2.JOY_THEME_TYPOGRAPHY = [
    TYPOGRAPHY_KEY_HEADLINE12,
    TYPOGRAPHY_KEY_HEADLINE22,
    TYPOGRAPHY_KEY_HEADLINE32,
    TYPOGRAPHY_KEY_HEADLINE42,
    TYPOGRAPHY_KEY_HEADLINE52,
    TYPOGRAPHY_KEY_HEADLINE62,
    TYPOGRAPHY_KEY_SUBTITLE1,
    TYPOGRAPHY_KEY_SUBTITLE2,
    TYPOGRAPHY_KEY_BODY12,
    TYPOGRAPHY_KEY_BODY22,
    TYPOGRAPHY_KEY_CAPTION,
    TYPOGRAPHY_KEY_OVERLINE,
    TYPOGRAPHY_KEY_BUTTON2,
    TYPOGRAPHY_KEY_SUPPORTING
  ];
  JoyTheme2.JOY_THEME_METADATA = {
    theme: JoyTheme2.JOY_THEME,
    palettes: JoyTheme2.JOY_THEME_PALETTES,
    paletteVariants: JoyTheme2.JOY_THEME_PALETTE_VARIANTS,
    schemes: JoyTheme2.JOY_THEME_SCHEMES,
    schemeVariants: JoyTheme2.JOY_THEME_SCHEME_VARIANTS,
    elevation: JoyTheme2.JOY_THEME_ELEVATION,
    elevationVariants: JoyTheme2.JOY_THEME_ELEVATION_VARIANTS,
    typographies: JoyTheme2.JOY_THEME_TYPOGRAPHY
  };
})(exports.JoyTheme || (exports.JoyTheme = {}));
exports.JoyTheme = void 0;

// src/theming/tokens/MemphisTokens.ts
var NAME3 = "memphis";
var FONT_FAMILY3 = "'Space Grotesk', 'Helvetica Neue', Arial, sans-serif";
var LAYOUT_RADIUS3 = "8px";
var LAYOUT_SPACE3 = "10px";
var LAYOUT_THICKNESS3 = "2px";
var SCHEME_LIGHT_SURFACE3 = "#ffffff";
var SCHEME_LIGHT_BACKGROUND3 = "#fdf3e3";
var SCHEME_LIGHT_FOREGROUND3 = "#111111";
var SCHEME_LIGHT_HIGHLIGHT3 = "#ede2cf";
var SCHEME_LIGHT_MIDDLELIGHT3 = "#a19b90";
var SCHEME_LIGHT_LOWLIGHT3 = "#56524b";
var SCHEME_LIGHT_TRANSPARENT3 = "rgba(253, 243, 227, 0)";
var SCHEME_LIGHT_SEMI_TRANSPARENT3 = "rgba(253, 243, 227, 0.6666666666666666)";
var SCHEME_LIGHT_DISABLED3 = "#9a958b";
var SCHEME_LIGHT_CONTRAST3 = "#111111";
var SCHEME_LIGHT_SELECTION3 = "#fde68a";
var SCHEME_DARK_SURFACE3 = "#22222c";
var SCHEME_DARK_BACKGROUND3 = "#16161d";
var SCHEME_DARK_FOREGROUND3 = "#fdf3e3";
var SCHEME_DARK_HIGHLIGHT3 = "#34343f";
var SCHEME_DARK_MIDDLELIGHT3 = "#787684";
var SCHEME_DARK_LOWLIGHT3 = "#c9c3b6";
var SCHEME_DARK_TRANSPARENT3 = "rgba(22, 22, 29, 0)";
var SCHEME_DARK_SEMI_TRANSPARENT3 = "rgba(22, 22, 29, 0.6666666666666666)";
var SCHEME_DARK_DISABLED3 = "#6c6a77";
var SCHEME_DARK_CONTRAST3 = "#fdf3e3";
var SCHEME_DARK_SELECTION3 = "#5b4a9e";
var COLOR_LIGHT_PRIMARY_03 = "#ffffff";
var COLOR_LIGHT_PRIMARY_503 = "#f1ebfe";
var COLOR_LIGHT_PRIMARY_1003 = "#dccefc";
var COLOR_LIGHT_PRIMARY_2003 = "#c5aefb";
var COLOR_LIGHT_PRIMARY_3003 = "#ae8df9";
var COLOR_LIGHT_PRIMARY_4003 = "#9c74f7";
var COLOR_LIGHT_PRIMARY_5003 = "#8b5cf6";
var COLOR_LIGHT_PRIMARY_6003 = "#7950d6";
var COLOR_LIGHT_PRIMARY_7003 = "#6140ac";
var COLOR_LIGHT_PRIMARY_8003 = "#4b3285";
var COLOR_LIGHT_PRIMARY_9003 = "#23173e";
var COLOR_LIGHT_SECONDARY_03 = "#ffffff";
var COLOR_LIGHT_SECONDARY_503 = "#fde9f3";
var COLOR_LIGHT_SECONDARY_1003 = "#f9c8e0";
var COLOR_LIGHT_SECONDARY_2003 = "#f6a4cc";
var COLOR_LIGHT_SECONDARY_3003 = "#f27fb8";
var COLOR_LIGHT_SECONDARY_4003 = "#ef63a8";
var COLOR_LIGHT_SECONDARY_5003 = "#ec4899";
var COLOR_LIGHT_SECONDARY_6003 = "#cd3f85";
var COLOR_LIGHT_SECONDARY_7003 = "#a5326b";
var COLOR_LIGHT_SECONDARY_8003 = "#7f2753";
var COLOR_LIGHT_SECONDARY_9003 = "#3b1226";
var COLOR_LIGHT_TERTIARY_03 = "#ffffff";
var COLOR_LIGHT_TERTIARY_503 = "#fef9e3";
var COLOR_LIGHT_TERTIARY_1003 = "#fef0b9";
var COLOR_LIGHT_TERTIARY_2003 = "#fde68a";
var COLOR_LIGHT_TERTIARY_3003 = "#fcdb5b";
var COLOR_LIGHT_TERTIARY_4003 = "#fbd438";
var COLOR_LIGHT_TERTIARY_5003 = "#facc15";
var COLOR_LIGHT_TERTIARY_6003 = "#dab112";
var COLOR_LIGHT_TERTIARY_7003 = "#af8f0f";
var COLOR_LIGHT_TERTIARY_8003 = "#876e0b";
var COLOR_LIGHT_TERTIARY_9003 = "#3f3305";
var COLOR_LIGHT_INFO_03 = "#ffffff";
var COLOR_LIGHT_INFO_503 = "#e7f0fe";
var COLOR_LIGHT_INFO_1003 = "#c4dafc";
var COLOR_LIGHT_INFO_2003 = "#9dc1fb";
var COLOR_LIGHT_INFO_3003 = "#76a8f9";
var COLOR_LIGHT_INFO_4003 = "#5895f7";
var COLOR_LIGHT_INFO_5003 = "#3b82f6";
var COLOR_LIGHT_INFO_6003 = "#3371d6";
var COLOR_LIGHT_INFO_7003 = "#295bac";
var COLOR_LIGHT_INFO_8003 = "#204685";
var COLOR_LIGHT_INFO_9003 = "#0f213e";
var COLOR_LIGHT_WARNING_03 = "#ffffff";
var COLOR_LIGHT_WARNING_503 = "#feeee3";
var COLOR_LIGHT_WARNING_1003 = "#fdd5b9";
var COLOR_LIGHT_WARNING_2003 = "#fcb98b";
var COLOR_LIGHT_WARNING_3003 = "#fb9d5c";
var COLOR_LIGHT_WARNING_4003 = "#fa8839";
var COLOR_LIGHT_WARNING_5003 = "#f97316";
var COLOR_LIGHT_WARNING_6003 = "#d96413";
var COLOR_LIGHT_WARNING_7003 = "#ae510f";
var COLOR_LIGHT_WARNING_8003 = "#863e0c";
var COLOR_LIGHT_WARNING_9003 = "#3e1d06";
var COLOR_LIGHT_DANGER_03 = "#ffffff";
var COLOR_LIGHT_DANGER_503 = "#fde9e9";
var COLOR_LIGHT_DANGER_1003 = "#fac7c7";
var COLOR_LIGHT_DANGER_2003 = "#f7a2a2";
var COLOR_LIGHT_DANGER_3003 = "#f47c7c";
var COLOR_LIGHT_DANGER_4003 = "#f16060";
var COLOR_LIGHT_DANGER_5003 = "#ef4444";
var COLOR_LIGHT_DANGER_6003 = "#d03b3b";
var COLOR_LIGHT_DANGER_7003 = "#a73030";
var COLOR_LIGHT_DANGER_8003 = "#812525";
var COLOR_LIGHT_DANGER_9003 = "#3c1111";
var COLOR_LIGHT_SUCCESS_03 = "#ffffff";
var COLOR_LIGHT_SUCCESS_503 = "#e4f8ec";
var COLOR_LIGHT_SUCCESS_1003 = "#bdeecf";
var COLOR_LIGHT_SUCCESS_2003 = "#91e2af";
var COLOR_LIGHT_SUCCESS_3003 = "#64d68e";
var COLOR_LIGHT_SUCCESS_4003 = "#43ce76";
var COLOR_LIGHT_SUCCESS_5003 = "#22c55e";
var COLOR_LIGHT_SUCCESS_6003 = "#1eab52";
var COLOR_LIGHT_SUCCESS_7003 = "#188a42";
var COLOR_LIGHT_SUCCESS_8003 = "#126a33";
var COLOR_LIGHT_SUCCESS_9003 = "#093118";
var COLOR_LIGHT_HIGHLIGHT_03 = "#ffffff";
var COLOR_LIGHT_HIGHLIGHT_503 = "#e3f6f4";
var COLOR_LIGHT_HIGHLIGHT_1003 = "#b9eae4";
var COLOR_LIGHT_HIGHLIGHT_2003 = "#8adcd3";
var COLOR_LIGHT_HIGHLIGHT_3003 = "#5bcdc1";
var COLOR_LIGHT_HIGHLIGHT_4003 = "#37c3b3";
var COLOR_LIGHT_HIGHLIGHT_5003 = "#14b8a6";
var COLOR_LIGHT_HIGHLIGHT_6003 = "#11a090";
var COLOR_LIGHT_HIGHLIGHT_7003 = "#0e8174";
var COLOR_LIGHT_HIGHLIGHT_8003 = "#0b635a";
var COLOR_LIGHT_HIGHLIGHT_9003 = "#052e2a";
var COLOR_LIGHT_NEUTRAL_03 = "#ffffff";
var COLOR_LIGHT_NEUTRAL_503 = "#efeeed";
var COLOR_LIGHT_NEUTRAL_1003 = "#d7d4d3";
var COLOR_LIGHT_NEUTRAL_2003 = "#bcb8b6";
var COLOR_LIGHT_NEUTRAL_3003 = "#a19c98";
var COLOR_LIGHT_NEUTRAL_4003 = "#8c8682";
var COLOR_LIGHT_NEUTRAL_5003 = "#78716c";
var COLOR_LIGHT_NEUTRAL_6003 = "#68625e";
var COLOR_LIGHT_NEUTRAL_7003 = "#544f4c";
var COLOR_LIGHT_NEUTRAL_8003 = "#413d3a";
var COLOR_LIGHT_NEUTRAL_9003 = "#1e1c1b";
var COLOR_DARK_PRIMARY_03 = "#000000";
var COLOR_DARK_PRIMARY_503 = "#150e25";
var COLOR_DARK_PRIMARY_1003 = "#2a1c4a";
var COLOR_DARK_PRIMARY_2003 = "#3f296f";
var COLOR_DARK_PRIMARY_3003 = "#533794";
var COLOR_DARK_PRIMARY_4003 = "#6845b9";
var COLOR_DARK_PRIMARY_5003 = "#7d53dd";
var COLOR_DARK_PRIMARY_6003 = "#8b5cf6";
var COLOR_DARK_PRIMARY_7003 = "#ae8df9";
var COLOR_DARK_PRIMARY_8003 = "#c0a7fa";
var COLOR_DARK_PRIMARY_9003 = "#e2d6fd";
var COLOR_DARK_SECONDARY_03 = "#000000";
var COLOR_DARK_SECONDARY_503 = "#230b17";
var COLOR_DARK_SECONDARY_1003 = "#47162e";
var COLOR_DARK_SECONDARY_2003 = "#6a2045";
var COLOR_DARK_SECONDARY_3003 = "#8e2b5c";
var COLOR_DARK_SECONDARY_4003 = "#b13673";
var COLOR_DARK_SECONDARY_5003 = "#d4418a";
var COLOR_DARK_SECONDARY_6003 = "#ec4899";
var COLOR_DARK_SECONDARY_7003 = "#f27fb8";
var COLOR_DARK_SECONDARY_8003 = "#f59cc8";
var COLOR_DARK_SECONDARY_9003 = "#fad1e6";
var COLOR_DARK_TERTIARY_03 = "#000000";
var COLOR_DARK_TERTIARY_503 = "#261f03";
var COLOR_DARK_TERTIARY_1003 = "#4b3d06";
var COLOR_DARK_TERTIARY_2003 = "#715c09";
var COLOR_DARK_TERTIARY_3003 = "#967a0d";
var COLOR_DARK_TERTIARY_4003 = "#bc9910";
var COLOR_DARK_TERTIARY_5003 = "#e1b813";
var COLOR_DARK_TERTIARY_6003 = "#facc15";
var COLOR_DARK_TERTIARY_7003 = "#fcdb5b";
var COLOR_DARK_TERTIARY_8003 = "#fce381";
var COLOR_DARK_TERTIARY_9003 = "#fef2c5";
var COLOR_DARK_INFO_03 = "#000000";
var COLOR_DARK_INFO_503 = "#091425";
var COLOR_DARK_INFO_1003 = "#12274a";
var COLOR_DARK_INFO_2003 = "#1b3b6f";
var COLOR_DARK_INFO_3003 = "#234e94";
var COLOR_DARK_INFO_4003 = "#2c62b9";
var COLOR_DARK_INFO_5003 = "#3575dd";
var COLOR_DARK_INFO_6003 = "#3b82f6";
var COLOR_DARK_INFO_7003 = "#76a8f9";
var COLOR_DARK_INFO_8003 = "#95bcfa";
var COLOR_DARK_INFO_9003 = "#cee0fd";
var COLOR_DARK_WARNING_03 = "#000000";
var COLOR_DARK_WARNING_503 = "#251103";
var COLOR_DARK_WARNING_1003 = "#4b2307";
var COLOR_DARK_WARNING_2003 = "#70340a";
var COLOR_DARK_WARNING_3003 = "#95450d";
var COLOR_DARK_WARNING_4003 = "#bb5611";
var COLOR_DARK_WARNING_5003 = "#e06814";
var COLOR_DARK_WARNING_6003 = "#f97316";
var COLOR_DARK_WARNING_7003 = "#fb9d5c";
var COLOR_DARK_WARNING_8003 = "#fcb381";
var COLOR_DARK_WARNING_9003 = "#fedcc5";
var COLOR_DARK_DANGER_03 = "#000000";
var COLOR_DARK_DANGER_503 = "#240a0a";
var COLOR_DARK_DANGER_1003 = "#481414";
var COLOR_DARK_DANGER_2003 = "#6c1f1f";
var COLOR_DARK_DANGER_3003 = "#8f2929";
var COLOR_DARK_DANGER_4003 = "#b33333";
var COLOR_DARK_DANGER_5003 = "#d73d3d";
var COLOR_DARK_DANGER_6003 = "#ef4444";
var COLOR_DARK_DANGER_7003 = "#f47c7c";
var COLOR_DARK_DANGER_8003 = "#f69a9a";
var COLOR_DARK_DANGER_9003 = "#fbd0d0";
var COLOR_DARK_SUCCESS_03 = "#000000";
var COLOR_DARK_SUCCESS_503 = "#051e0e";
var COLOR_DARK_SUCCESS_1003 = "#0a3b1c";
var COLOR_DARK_SUCCESS_2003 = "#0f592a";
var COLOR_DARK_SUCCESS_3003 = "#147638";
var COLOR_DARK_SUCCESS_4003 = "#1a9447";
var COLOR_DARK_SUCCESS_5003 = "#1fb155";
var COLOR_DARK_SUCCESS_6003 = "#22c55e";
var COLOR_DARK_SUCCESS_7003 = "#64d68e";
var COLOR_DARK_SUCCESS_8003 = "#88e0a8";
var COLOR_DARK_SUCCESS_9003 = "#c8f1d7";
var COLOR_DARK_HIGHLIGHT_03 = "#000000";
var COLOR_DARK_HIGHLIGHT_503 = "#031c19";
var COLOR_DARK_HIGHLIGHT_1003 = "#063732";
var COLOR_DARK_HIGHLIGHT_2003 = "#09534b";
var COLOR_DARK_HIGHLIGHT_3003 = "#0c6e64";
var COLOR_DARK_HIGHLIGHT_4003 = "#0f8a7d";
var COLOR_DARK_HIGHLIGHT_5003 = "#12a695";
var COLOR_DARK_HIGHLIGHT_6003 = "#14b8a6";
var COLOR_DARK_HIGHLIGHT_7003 = "#5bcdc1";
var COLOR_DARK_HIGHLIGHT_8003 = "#80d9cf";
var COLOR_DARK_HIGHLIGHT_9003 = "#c4ede9";
var COLOR_DARK_NEUTRAL_03 = "#000000";
var COLOR_DARK_NEUTRAL_503 = "#121110";
var COLOR_DARK_NEUTRAL_1003 = "#242220";
var COLOR_DARK_NEUTRAL_2003 = "#363331";
var COLOR_DARK_NEUTRAL_3003 = "#484441";
var COLOR_DARK_NEUTRAL_4003 = "#5a5551";
var COLOR_DARK_NEUTRAL_5003 = "#6c6661";
var COLOR_DARK_NEUTRAL_6003 = "#78716c";
var COLOR_DARK_NEUTRAL_7003 = "#a19c98";
var COLOR_DARK_NEUTRAL_8003 = "#b6b2b0";
var COLOR_DARK_NEUTRAL_9003 = "#dddcda";
var TYPOGRAPHY_HEADLINE1_FONT_FAMILY3 = "'Space Grotesk', 'Helvetica Neue', Arial, sans-serif";
var TYPOGRAPHY_HEADLINE1_FONT_SIZE3 = "64px";
var TYPOGRAPHY_HEADLINE1_LINE_HEIGHT3 = "68px";
var TYPOGRAPHY_HEADLINE1_FONT_WEIGHT3 = "700";
var TYPOGRAPHY_HEADLINE1_LETTER_SPACING3 = "-1.5px";
var TYPOGRAPHY_HEADLINE1_TEXT_DECORATION3 = "none";
var TYPOGRAPHY_HEADLINE1_TEXT_TRANSFORM3 = "none";
var TYPOGRAPHY_HEADLINE2_FONT_FAMILY3 = "'Space Grotesk', 'Helvetica Neue', Arial, sans-serif";
var TYPOGRAPHY_HEADLINE2_FONT_SIZE3 = "48px";
var TYPOGRAPHY_HEADLINE2_LINE_HEIGHT3 = "52px";
var TYPOGRAPHY_HEADLINE2_FONT_WEIGHT3 = "700";
var TYPOGRAPHY_HEADLINE2_LETTER_SPACING3 = "-1px";
var TYPOGRAPHY_HEADLINE2_TEXT_DECORATION3 = "none";
var TYPOGRAPHY_HEADLINE2_TEXT_TRANSFORM3 = "none";
var TYPOGRAPHY_HEADLINE3_FONT_FAMILY3 = "'Space Grotesk', 'Helvetica Neue', Arial, sans-serif";
var TYPOGRAPHY_HEADLINE3_FONT_SIZE3 = "36px";
var TYPOGRAPHY_HEADLINE3_LINE_HEIGHT3 = "40px";
var TYPOGRAPHY_HEADLINE3_FONT_WEIGHT3 = "700";
var TYPOGRAPHY_HEADLINE3_LETTER_SPACING3 = "-0.5px";
var TYPOGRAPHY_HEADLINE3_TEXT_DECORATION3 = "none";
var TYPOGRAPHY_HEADLINE3_TEXT_TRANSFORM3 = "none";
var TYPOGRAPHY_HEADLINE4_FONT_FAMILY3 = "'Space Grotesk', 'Helvetica Neue', Arial, sans-serif";
var TYPOGRAPHY_HEADLINE4_FONT_SIZE3 = "28px";
var TYPOGRAPHY_HEADLINE4_LINE_HEIGHT3 = "32px";
var TYPOGRAPHY_HEADLINE4_FONT_WEIGHT3 = "700";
var TYPOGRAPHY_HEADLINE4_LETTER_SPACING3 = "-0.25px";
var TYPOGRAPHY_HEADLINE4_TEXT_DECORATION3 = "none";
var TYPOGRAPHY_HEADLINE4_TEXT_TRANSFORM3 = "none";
var TYPOGRAPHY_HEADLINE5_FONT_FAMILY3 = "'Space Grotesk', 'Helvetica Neue', Arial, sans-serif";
var TYPOGRAPHY_HEADLINE5_FONT_SIZE3 = "22px";
var TYPOGRAPHY_HEADLINE5_LINE_HEIGHT3 = "28px";
var TYPOGRAPHY_HEADLINE5_FONT_WEIGHT3 = "700";
var TYPOGRAPHY_HEADLINE5_LETTER_SPACING3 = "normal";
var TYPOGRAPHY_HEADLINE5_TEXT_DECORATION3 = "none";
var TYPOGRAPHY_HEADLINE5_TEXT_TRANSFORM3 = "none";
var TYPOGRAPHY_HEADLINE6_FONT_FAMILY3 = "'Space Grotesk', 'Helvetica Neue', Arial, sans-serif";
var TYPOGRAPHY_HEADLINE6_FONT_SIZE3 = "18px";
var TYPOGRAPHY_HEADLINE6_LINE_HEIGHT3 = "24px";
var TYPOGRAPHY_HEADLINE6_FONT_WEIGHT3 = "700";
var TYPOGRAPHY_HEADLINE6_LETTER_SPACING3 = "normal";
var TYPOGRAPHY_HEADLINE6_TEXT_DECORATION3 = "none";
var TYPOGRAPHY_HEADLINE6_TEXT_TRANSFORM3 = "none";
var TYPOGRAPHY_SUBTITLE1_FONT_FAMILY3 = "'Space Grotesk', 'Helvetica Neue', Arial, sans-serif";
var TYPOGRAPHY_SUBTITLE1_FONT_SIZE3 = "16px";
var TYPOGRAPHY_SUBTITLE1_LINE_HEIGHT3 = "22px";
var TYPOGRAPHY_SUBTITLE1_FONT_WEIGHT3 = "600";
var TYPOGRAPHY_SUBTITLE1_LETTER_SPACING3 = "normal";
var TYPOGRAPHY_SUBTITLE1_TEXT_DECORATION3 = "none";
var TYPOGRAPHY_SUBTITLE1_TEXT_TRANSFORM3 = "none";
var TYPOGRAPHY_SUBTITLE2_FONT_FAMILY3 = "'Space Grotesk', 'Helvetica Neue', Arial, sans-serif";
var TYPOGRAPHY_SUBTITLE2_FONT_SIZE3 = "14px";
var TYPOGRAPHY_SUBTITLE2_LINE_HEIGHT3 = "20px";
var TYPOGRAPHY_SUBTITLE2_FONT_WEIGHT3 = "600";
var TYPOGRAPHY_SUBTITLE2_LETTER_SPACING3 = "normal";
var TYPOGRAPHY_SUBTITLE2_TEXT_DECORATION3 = "none";
var TYPOGRAPHY_SUBTITLE2_TEXT_TRANSFORM3 = "none";
var TYPOGRAPHY_BODY1_FONT_FAMILY3 = "'Space Grotesk', 'Helvetica Neue', Arial, sans-serif";
var TYPOGRAPHY_BODY1_FONT_SIZE3 = "16px";
var TYPOGRAPHY_BODY1_LINE_HEIGHT3 = "24px";
var TYPOGRAPHY_BODY1_FONT_WEIGHT3 = "400";
var TYPOGRAPHY_BODY1_LETTER_SPACING3 = "normal";
var TYPOGRAPHY_BODY1_TEXT_DECORATION3 = "none";
var TYPOGRAPHY_BODY1_TEXT_TRANSFORM3 = "none";
var TYPOGRAPHY_BODY2_FONT_FAMILY3 = "'Space Grotesk', 'Helvetica Neue', Arial, sans-serif";
var TYPOGRAPHY_BODY2_FONT_SIZE3 = "14px";
var TYPOGRAPHY_BODY2_LINE_HEIGHT3 = "20px";
var TYPOGRAPHY_BODY2_FONT_WEIGHT3 = "400";
var TYPOGRAPHY_BODY2_LETTER_SPACING3 = "normal";
var TYPOGRAPHY_BODY2_TEXT_DECORATION3 = "none";
var TYPOGRAPHY_BODY2_TEXT_TRANSFORM3 = "none";
var TYPOGRAPHY_SUPPORTING_FONT_FAMILY3 = "'Space Grotesk', 'Helvetica Neue', Arial, sans-serif";
var TYPOGRAPHY_SUPPORTING_FONT_SIZE3 = "12px";
var TYPOGRAPHY_SUPPORTING_LINE_HEIGHT3 = "16px";
var TYPOGRAPHY_SUPPORTING_FONT_WEIGHT3 = "500";
var TYPOGRAPHY_SUPPORTING_LETTER_SPACING3 = "normal";
var TYPOGRAPHY_SUPPORTING_TEXT_DECORATION3 = "none";
var TYPOGRAPHY_SUPPORTING_TEXT_TRANSFORM3 = "none";
var TYPOGRAPHY_CAPTION_FONT_FAMILY3 = "'Space Grotesk', 'Helvetica Neue', Arial, sans-serif";
var TYPOGRAPHY_CAPTION_FONT_SIZE3 = "12px";
var TYPOGRAPHY_CAPTION_LINE_HEIGHT3 = "16px";
var TYPOGRAPHY_CAPTION_FONT_WEIGHT3 = "500";
var TYPOGRAPHY_CAPTION_LETTER_SPACING3 = "0.2px";
var TYPOGRAPHY_CAPTION_TEXT_DECORATION3 = "none";
var TYPOGRAPHY_CAPTION_TEXT_TRANSFORM3 = "none";
var TYPOGRAPHY_BUTTON_FONT_FAMILY3 = "'Space Grotesk', 'Helvetica Neue', Arial, sans-serif";
var TYPOGRAPHY_BUTTON_FONT_SIZE3 = "15px";
var TYPOGRAPHY_BUTTON_LINE_HEIGHT3 = "20px";
var TYPOGRAPHY_BUTTON_FONT_WEIGHT3 = "700";
var TYPOGRAPHY_BUTTON_LETTER_SPACING3 = "0.2px";
var TYPOGRAPHY_BUTTON_TEXT_DECORATION3 = "none";
var TYPOGRAPHY_BUTTON_TEXT_TRANSFORM3 = "none";
var TYPOGRAPHY_OVERLINE_FONT_FAMILY3 = "'Space Grotesk', 'Helvetica Neue', Arial, sans-serif";
var TYPOGRAPHY_OVERLINE_FONT_SIZE3 = "11px";
var TYPOGRAPHY_OVERLINE_LINE_HEIGHT3 = "16px";
var TYPOGRAPHY_OVERLINE_FONT_WEIGHT3 = "700";
var TYPOGRAPHY_OVERLINE_LETTER_SPACING3 = "1.5px";
var TYPOGRAPHY_OVERLINE_TEXT_DECORATION3 = "none";
var TYPOGRAPHY_OVERLINE_TEXT_TRANSFORM3 = "uppercase";
var ELEVATION_LIGHT_LIGHT3 = "2px 2px 0px 0px #111111";
var ELEVATION_LIGHT_SEMILIGHT3 = "3px 3px 0px 0px #111111";
var ELEVATION_LIGHT_REGULAR3 = "4px 4px 0px 0px #111111";
var ELEVATION_LIGHT_SEMIBOLD3 = "5px 5px 0px 0px #111111";
var ELEVATION_LIGHT_BOLD3 = "6px 6px 0px 0px #111111";
var ELEVATION_LIGHT_EXTRABOLD3 = "8px 8px 0px 0px #111111";
var ELEVATION_DARK_LIGHT3 = "2px 2px 0px 0px #fdf3e3";
var ELEVATION_DARK_SEMILIGHT3 = "3px 3px 0px 0px #fdf3e3";
var ELEVATION_DARK_REGULAR3 = "4px 4px 0px 0px #fdf3e3";
var ELEVATION_DARK_SEMIBOLD3 = "5px 5px 0px 0px #fdf3e3";
var ELEVATION_DARK_BOLD3 = "6px 6px 0px 0px #fdf3e3";
var ELEVATION_DARK_EXTRABOLD3 = "8px 8px 0px 0px #fdf3e3";
var TYPOGRAPHY_KEY_HEADLINE13 = "headline1";
var TYPOGRAPHY_KEY_HEADLINE23 = "headline2";
var TYPOGRAPHY_KEY_HEADLINE33 = "headline3";
var TYPOGRAPHY_KEY_HEADLINE43 = "headline4";
var TYPOGRAPHY_KEY_HEADLINE53 = "headline5";
var TYPOGRAPHY_KEY_HEADLINE63 = "headline6";
var TYPOGRAPHY_KEY_SUBTITLE12 = "subtitle1";
var TYPOGRAPHY_KEY_SUBTITLE22 = "subtitle2";
var TYPOGRAPHY_KEY_BODY13 = "body1";
var TYPOGRAPHY_KEY_BODY23 = "body2";
var TYPOGRAPHY_KEY_CAPTION2 = "caption";
var TYPOGRAPHY_KEY_BUTTON3 = "button";
var TYPOGRAPHY_KEY_OVERLINE2 = "overline";
var ELEVATION_KEY_LIGHT3 = "light";
var ELEVATION_KEY_SEMILIGHT3 = "semilight";
var ELEVATION_KEY_REGULAR3 = "regular";
var ELEVATION_KEY_SEMIBOLD3 = "semibold";
var ELEVATION_KEY_BOLD3 = "bold";
var ELEVATION_KEY_EXTRABOLD3 = "extrabold";
var VARIANT_PRIMARY3 = "primary";
var VARIANT_SECONDARY3 = "secondary";
var VARIANT_DANGER2 = "danger";
var VARIANT_WARNING2 = "warning";
var VARIANT_SUCCESS2 = "success";
var VARIANT_INFO2 = "info";
var VARIANT_NEUTRAL2 = "neutral";
var DURATION_SHORT3 = "200ms";
var DURATION_MEDIUM3 = "400ms";
var DURATION_LONG3 = "600ms";

// src/theming/MemphisTheme.ts
(function(MemphisTheme2) {
  MemphisTheme2.MEMPHIS_THEME = ThemeFactory.create({
    name: NAME3,
    scheme: {
      light: {
        surface: SCHEME_LIGHT_SURFACE3,
        background: SCHEME_LIGHT_BACKGROUND3,
        foreground: SCHEME_LIGHT_FOREGROUND3,
        highlight: SCHEME_LIGHT_HIGHLIGHT3,
        middlelight: SCHEME_LIGHT_MIDDLELIGHT3,
        lowlight: SCHEME_LIGHT_LOWLIGHT3,
        transparent: SCHEME_LIGHT_TRANSPARENT3,
        semiTransparent: SCHEME_LIGHT_SEMI_TRANSPARENT3,
        disabled: SCHEME_LIGHT_DISABLED3,
        contrast: SCHEME_LIGHT_CONTRAST3,
        selection: SCHEME_LIGHT_SELECTION3
      },
      dark: {
        surface: SCHEME_DARK_SURFACE3,
        background: SCHEME_DARK_BACKGROUND3,
        foreground: SCHEME_DARK_FOREGROUND3,
        highlight: SCHEME_DARK_HIGHLIGHT3,
        middlelight: SCHEME_DARK_MIDDLELIGHT3,
        lowlight: SCHEME_DARK_LOWLIGHT3,
        transparent: SCHEME_DARK_TRANSPARENT3,
        semiTransparent: SCHEME_DARK_SEMI_TRANSPARENT3,
        disabled: SCHEME_DARK_DISABLED3,
        contrast: SCHEME_DARK_CONTRAST3,
        selection: SCHEME_DARK_SELECTION3
      }
    },
    palette: {
      light: {
        primary: {
          0: COLOR_LIGHT_PRIMARY_03,
          50: COLOR_LIGHT_PRIMARY_503,
          100: COLOR_LIGHT_PRIMARY_1003,
          200: COLOR_LIGHT_PRIMARY_2003,
          300: COLOR_LIGHT_PRIMARY_3003,
          400: COLOR_LIGHT_PRIMARY_4003,
          500: COLOR_LIGHT_PRIMARY_5003,
          600: COLOR_LIGHT_PRIMARY_6003,
          700: COLOR_LIGHT_PRIMARY_7003,
          800: COLOR_LIGHT_PRIMARY_8003,
          900: COLOR_LIGHT_PRIMARY_9003
        },
        secondary: {
          0: COLOR_LIGHT_SECONDARY_03,
          50: COLOR_LIGHT_SECONDARY_503,
          100: COLOR_LIGHT_SECONDARY_1003,
          200: COLOR_LIGHT_SECONDARY_2003,
          300: COLOR_LIGHT_SECONDARY_3003,
          400: COLOR_LIGHT_SECONDARY_4003,
          500: COLOR_LIGHT_SECONDARY_5003,
          600: COLOR_LIGHT_SECONDARY_6003,
          700: COLOR_LIGHT_SECONDARY_7003,
          800: COLOR_LIGHT_SECONDARY_8003,
          900: COLOR_LIGHT_SECONDARY_9003
        },
        tertiary: {
          0: COLOR_LIGHT_TERTIARY_03,
          50: COLOR_LIGHT_TERTIARY_503,
          100: COLOR_LIGHT_TERTIARY_1003,
          200: COLOR_LIGHT_TERTIARY_2003,
          300: COLOR_LIGHT_TERTIARY_3003,
          400: COLOR_LIGHT_TERTIARY_4003,
          500: COLOR_LIGHT_TERTIARY_5003,
          600: COLOR_LIGHT_TERTIARY_6003,
          700: COLOR_LIGHT_TERTIARY_7003,
          800: COLOR_LIGHT_TERTIARY_8003,
          900: COLOR_LIGHT_TERTIARY_9003
        },
        info: {
          0: COLOR_LIGHT_INFO_03,
          50: COLOR_LIGHT_INFO_503,
          100: COLOR_LIGHT_INFO_1003,
          200: COLOR_LIGHT_INFO_2003,
          300: COLOR_LIGHT_INFO_3003,
          400: COLOR_LIGHT_INFO_4003,
          500: COLOR_LIGHT_INFO_5003,
          600: COLOR_LIGHT_INFO_6003,
          700: COLOR_LIGHT_INFO_7003,
          800: COLOR_LIGHT_INFO_8003,
          900: COLOR_LIGHT_INFO_9003
        },
        warning: {
          0: COLOR_LIGHT_WARNING_03,
          50: COLOR_LIGHT_WARNING_503,
          100: COLOR_LIGHT_WARNING_1003,
          200: COLOR_LIGHT_WARNING_2003,
          300: COLOR_LIGHT_WARNING_3003,
          400: COLOR_LIGHT_WARNING_4003,
          500: COLOR_LIGHT_WARNING_5003,
          600: COLOR_LIGHT_WARNING_6003,
          700: COLOR_LIGHT_WARNING_7003,
          800: COLOR_LIGHT_WARNING_8003,
          900: COLOR_LIGHT_WARNING_9003
        },
        danger: {
          0: COLOR_LIGHT_DANGER_03,
          50: COLOR_LIGHT_DANGER_503,
          100: COLOR_LIGHT_DANGER_1003,
          200: COLOR_LIGHT_DANGER_2003,
          300: COLOR_LIGHT_DANGER_3003,
          400: COLOR_LIGHT_DANGER_4003,
          500: COLOR_LIGHT_DANGER_5003,
          600: COLOR_LIGHT_DANGER_6003,
          700: COLOR_LIGHT_DANGER_7003,
          800: COLOR_LIGHT_DANGER_8003,
          900: COLOR_LIGHT_DANGER_9003
        },
        success: {
          0: COLOR_LIGHT_SUCCESS_03,
          50: COLOR_LIGHT_SUCCESS_503,
          100: COLOR_LIGHT_SUCCESS_1003,
          200: COLOR_LIGHT_SUCCESS_2003,
          300: COLOR_LIGHT_SUCCESS_3003,
          400: COLOR_LIGHT_SUCCESS_4003,
          500: COLOR_LIGHT_SUCCESS_5003,
          600: COLOR_LIGHT_SUCCESS_6003,
          700: COLOR_LIGHT_SUCCESS_7003,
          800: COLOR_LIGHT_SUCCESS_8003,
          900: COLOR_LIGHT_SUCCESS_9003
        },
        highlight: {
          0: COLOR_LIGHT_HIGHLIGHT_03,
          50: COLOR_LIGHT_HIGHLIGHT_503,
          100: COLOR_LIGHT_HIGHLIGHT_1003,
          200: COLOR_LIGHT_HIGHLIGHT_2003,
          300: COLOR_LIGHT_HIGHLIGHT_3003,
          400: COLOR_LIGHT_HIGHLIGHT_4003,
          500: COLOR_LIGHT_HIGHLIGHT_5003,
          600: COLOR_LIGHT_HIGHLIGHT_6003,
          700: COLOR_LIGHT_HIGHLIGHT_7003,
          800: COLOR_LIGHT_HIGHLIGHT_8003,
          900: COLOR_LIGHT_HIGHLIGHT_9003
        },
        neutral: {
          0: COLOR_LIGHT_NEUTRAL_03,
          50: COLOR_LIGHT_NEUTRAL_503,
          100: COLOR_LIGHT_NEUTRAL_1003,
          200: COLOR_LIGHT_NEUTRAL_2003,
          300: COLOR_LIGHT_NEUTRAL_3003,
          400: COLOR_LIGHT_NEUTRAL_4003,
          500: COLOR_LIGHT_NEUTRAL_5003,
          600: COLOR_LIGHT_NEUTRAL_6003,
          700: COLOR_LIGHT_NEUTRAL_7003,
          800: COLOR_LIGHT_NEUTRAL_8003,
          900: COLOR_LIGHT_NEUTRAL_9003
        }
      },
      dark: {
        primary: {
          0: COLOR_DARK_PRIMARY_03,
          50: COLOR_DARK_PRIMARY_503,
          100: COLOR_DARK_PRIMARY_1003,
          200: COLOR_DARK_PRIMARY_2003,
          300: COLOR_DARK_PRIMARY_3003,
          400: COLOR_DARK_PRIMARY_4003,
          500: COLOR_DARK_PRIMARY_5003,
          600: COLOR_DARK_PRIMARY_6003,
          700: COLOR_DARK_PRIMARY_7003,
          800: COLOR_DARK_PRIMARY_8003,
          900: COLOR_DARK_PRIMARY_9003
        },
        secondary: {
          0: COLOR_DARK_SECONDARY_03,
          50: COLOR_DARK_SECONDARY_503,
          100: COLOR_DARK_SECONDARY_1003,
          200: COLOR_DARK_SECONDARY_2003,
          300: COLOR_DARK_SECONDARY_3003,
          400: COLOR_DARK_SECONDARY_4003,
          500: COLOR_DARK_SECONDARY_5003,
          600: COLOR_DARK_SECONDARY_6003,
          700: COLOR_DARK_SECONDARY_7003,
          800: COLOR_DARK_SECONDARY_8003,
          900: COLOR_DARK_SECONDARY_9003
        },
        tertiary: {
          0: COLOR_DARK_TERTIARY_03,
          50: COLOR_DARK_TERTIARY_503,
          100: COLOR_DARK_TERTIARY_1003,
          200: COLOR_DARK_TERTIARY_2003,
          300: COLOR_DARK_TERTIARY_3003,
          400: COLOR_DARK_TERTIARY_4003,
          500: COLOR_DARK_TERTIARY_5003,
          600: COLOR_DARK_TERTIARY_6003,
          700: COLOR_DARK_TERTIARY_7003,
          800: COLOR_DARK_TERTIARY_8003,
          900: COLOR_DARK_TERTIARY_9003
        },
        info: {
          0: COLOR_DARK_INFO_03,
          50: COLOR_DARK_INFO_503,
          100: COLOR_DARK_INFO_1003,
          200: COLOR_DARK_INFO_2003,
          300: COLOR_DARK_INFO_3003,
          400: COLOR_DARK_INFO_4003,
          500: COLOR_DARK_INFO_5003,
          600: COLOR_DARK_INFO_6003,
          700: COLOR_DARK_INFO_7003,
          800: COLOR_DARK_INFO_8003,
          900: COLOR_DARK_INFO_9003
        },
        warning: {
          0: COLOR_DARK_WARNING_03,
          50: COLOR_DARK_WARNING_503,
          100: COLOR_DARK_WARNING_1003,
          200: COLOR_DARK_WARNING_2003,
          300: COLOR_DARK_WARNING_3003,
          400: COLOR_DARK_WARNING_4003,
          500: COLOR_DARK_WARNING_5003,
          600: COLOR_DARK_WARNING_6003,
          700: COLOR_DARK_WARNING_7003,
          800: COLOR_DARK_WARNING_8003,
          900: COLOR_DARK_WARNING_9003
        },
        danger: {
          0: COLOR_DARK_DANGER_03,
          50: COLOR_DARK_DANGER_503,
          100: COLOR_DARK_DANGER_1003,
          200: COLOR_DARK_DANGER_2003,
          300: COLOR_DARK_DANGER_3003,
          400: COLOR_DARK_DANGER_4003,
          500: COLOR_DARK_DANGER_5003,
          600: COLOR_DARK_DANGER_6003,
          700: COLOR_DARK_DANGER_7003,
          800: COLOR_DARK_DANGER_8003,
          900: COLOR_DARK_DANGER_9003
        },
        success: {
          0: COLOR_DARK_SUCCESS_03,
          50: COLOR_DARK_SUCCESS_503,
          100: COLOR_DARK_SUCCESS_1003,
          200: COLOR_DARK_SUCCESS_2003,
          300: COLOR_DARK_SUCCESS_3003,
          400: COLOR_DARK_SUCCESS_4003,
          500: COLOR_DARK_SUCCESS_5003,
          600: COLOR_DARK_SUCCESS_6003,
          700: COLOR_DARK_SUCCESS_7003,
          800: COLOR_DARK_SUCCESS_8003,
          900: COLOR_DARK_SUCCESS_9003
        },
        highlight: {
          0: COLOR_DARK_HIGHLIGHT_03,
          50: COLOR_DARK_HIGHLIGHT_503,
          100: COLOR_DARK_HIGHLIGHT_1003,
          200: COLOR_DARK_HIGHLIGHT_2003,
          300: COLOR_DARK_HIGHLIGHT_3003,
          400: COLOR_DARK_HIGHLIGHT_4003,
          500: COLOR_DARK_HIGHLIGHT_5003,
          600: COLOR_DARK_HIGHLIGHT_6003,
          700: COLOR_DARK_HIGHLIGHT_7003,
          800: COLOR_DARK_HIGHLIGHT_8003,
          900: COLOR_DARK_HIGHLIGHT_9003
        },
        neutral: {
          0: COLOR_DARK_NEUTRAL_03,
          50: COLOR_DARK_NEUTRAL_503,
          100: COLOR_DARK_NEUTRAL_1003,
          200: COLOR_DARK_NEUTRAL_2003,
          300: COLOR_DARK_NEUTRAL_3003,
          400: COLOR_DARK_NEUTRAL_4003,
          500: COLOR_DARK_NEUTRAL_5003,
          600: COLOR_DARK_NEUTRAL_6003,
          700: COLOR_DARK_NEUTRAL_7003,
          800: COLOR_DARK_NEUTRAL_8003,
          900: COLOR_DARK_NEUTRAL_9003
        }
      }
    },
    fontFamily: FONT_FAMILY3,
    typography: {
      headline1: {
        fontFamily: TYPOGRAPHY_HEADLINE1_FONT_FAMILY3,
        fontSize: TYPOGRAPHY_HEADLINE1_FONT_SIZE3,
        lineHeight: TYPOGRAPHY_HEADLINE1_LINE_HEIGHT3,
        fontWeight: TYPOGRAPHY_HEADLINE1_FONT_WEIGHT3,
        letterSpacing: TYPOGRAPHY_HEADLINE1_LETTER_SPACING3,
        textDecoration: TYPOGRAPHY_HEADLINE1_TEXT_DECORATION3,
        textTransform: TYPOGRAPHY_HEADLINE1_TEXT_TRANSFORM3
      },
      headline2: {
        fontFamily: TYPOGRAPHY_HEADLINE2_FONT_FAMILY3,
        fontSize: TYPOGRAPHY_HEADLINE2_FONT_SIZE3,
        lineHeight: TYPOGRAPHY_HEADLINE2_LINE_HEIGHT3,
        fontWeight: TYPOGRAPHY_HEADLINE2_FONT_WEIGHT3,
        letterSpacing: TYPOGRAPHY_HEADLINE2_LETTER_SPACING3,
        textDecoration: TYPOGRAPHY_HEADLINE2_TEXT_DECORATION3,
        textTransform: TYPOGRAPHY_HEADLINE2_TEXT_TRANSFORM3
      },
      headline3: {
        fontFamily: TYPOGRAPHY_HEADLINE3_FONT_FAMILY3,
        fontSize: TYPOGRAPHY_HEADLINE3_FONT_SIZE3,
        lineHeight: TYPOGRAPHY_HEADLINE3_LINE_HEIGHT3,
        fontWeight: TYPOGRAPHY_HEADLINE3_FONT_WEIGHT3,
        letterSpacing: TYPOGRAPHY_HEADLINE3_LETTER_SPACING3,
        textDecoration: TYPOGRAPHY_HEADLINE3_TEXT_DECORATION3,
        textTransform: TYPOGRAPHY_HEADLINE3_TEXT_TRANSFORM3
      },
      headline4: {
        fontFamily: TYPOGRAPHY_HEADLINE4_FONT_FAMILY3,
        fontSize: TYPOGRAPHY_HEADLINE4_FONT_SIZE3,
        lineHeight: TYPOGRAPHY_HEADLINE4_LINE_HEIGHT3,
        fontWeight: TYPOGRAPHY_HEADLINE4_FONT_WEIGHT3,
        letterSpacing: TYPOGRAPHY_HEADLINE4_LETTER_SPACING3,
        textDecoration: TYPOGRAPHY_HEADLINE4_TEXT_DECORATION3,
        textTransform: TYPOGRAPHY_HEADLINE4_TEXT_TRANSFORM3
      },
      headline5: {
        fontFamily: TYPOGRAPHY_HEADLINE5_FONT_FAMILY3,
        fontSize: TYPOGRAPHY_HEADLINE5_FONT_SIZE3,
        lineHeight: TYPOGRAPHY_HEADLINE5_LINE_HEIGHT3,
        fontWeight: TYPOGRAPHY_HEADLINE5_FONT_WEIGHT3,
        letterSpacing: TYPOGRAPHY_HEADLINE5_LETTER_SPACING3,
        textDecoration: TYPOGRAPHY_HEADLINE5_TEXT_DECORATION3,
        textTransform: TYPOGRAPHY_HEADLINE5_TEXT_TRANSFORM3
      },
      headline6: {
        fontFamily: TYPOGRAPHY_HEADLINE6_FONT_FAMILY3,
        fontSize: TYPOGRAPHY_HEADLINE6_FONT_SIZE3,
        lineHeight: TYPOGRAPHY_HEADLINE6_LINE_HEIGHT3,
        fontWeight: TYPOGRAPHY_HEADLINE6_FONT_WEIGHT3,
        letterSpacing: TYPOGRAPHY_HEADLINE6_LETTER_SPACING3,
        textDecoration: TYPOGRAPHY_HEADLINE6_TEXT_DECORATION3,
        textTransform: TYPOGRAPHY_HEADLINE6_TEXT_TRANSFORM3
      },
      subtitle1: {
        fontFamily: TYPOGRAPHY_SUBTITLE1_FONT_FAMILY3,
        fontSize: TYPOGRAPHY_SUBTITLE1_FONT_SIZE3,
        lineHeight: TYPOGRAPHY_SUBTITLE1_LINE_HEIGHT3,
        fontWeight: TYPOGRAPHY_SUBTITLE1_FONT_WEIGHT3,
        letterSpacing: TYPOGRAPHY_SUBTITLE1_LETTER_SPACING3,
        textDecoration: TYPOGRAPHY_SUBTITLE1_TEXT_DECORATION3,
        textTransform: TYPOGRAPHY_SUBTITLE1_TEXT_TRANSFORM3
      },
      subtitle2: {
        fontFamily: TYPOGRAPHY_SUBTITLE2_FONT_FAMILY3,
        fontSize: TYPOGRAPHY_SUBTITLE2_FONT_SIZE3,
        lineHeight: TYPOGRAPHY_SUBTITLE2_LINE_HEIGHT3,
        fontWeight: TYPOGRAPHY_SUBTITLE2_FONT_WEIGHT3,
        letterSpacing: TYPOGRAPHY_SUBTITLE2_LETTER_SPACING3,
        textDecoration: TYPOGRAPHY_SUBTITLE2_TEXT_DECORATION3,
        textTransform: TYPOGRAPHY_SUBTITLE2_TEXT_TRANSFORM3
      },
      body1: {
        fontFamily: TYPOGRAPHY_BODY1_FONT_FAMILY3,
        fontSize: TYPOGRAPHY_BODY1_FONT_SIZE3,
        lineHeight: TYPOGRAPHY_BODY1_LINE_HEIGHT3,
        fontWeight: TYPOGRAPHY_BODY1_FONT_WEIGHT3,
        letterSpacing: TYPOGRAPHY_BODY1_LETTER_SPACING3,
        textDecoration: TYPOGRAPHY_BODY1_TEXT_DECORATION3,
        textTransform: TYPOGRAPHY_BODY1_TEXT_TRANSFORM3
      },
      body2: {
        fontFamily: TYPOGRAPHY_BODY2_FONT_FAMILY3,
        fontSize: TYPOGRAPHY_BODY2_FONT_SIZE3,
        lineHeight: TYPOGRAPHY_BODY2_LINE_HEIGHT3,
        fontWeight: TYPOGRAPHY_BODY2_FONT_WEIGHT3,
        letterSpacing: TYPOGRAPHY_BODY2_LETTER_SPACING3,
        textDecoration: TYPOGRAPHY_BODY2_TEXT_DECORATION3,
        textTransform: TYPOGRAPHY_BODY2_TEXT_TRANSFORM3
      },
      caption: {
        fontFamily: TYPOGRAPHY_CAPTION_FONT_FAMILY3,
        fontSize: TYPOGRAPHY_CAPTION_FONT_SIZE3,
        lineHeight: TYPOGRAPHY_CAPTION_LINE_HEIGHT3,
        fontWeight: TYPOGRAPHY_CAPTION_FONT_WEIGHT3,
        letterSpacing: TYPOGRAPHY_CAPTION_LETTER_SPACING3,
        textDecoration: TYPOGRAPHY_CAPTION_TEXT_DECORATION3,
        textTransform: TYPOGRAPHY_CAPTION_TEXT_TRANSFORM3
      },
      overline: {
        fontFamily: TYPOGRAPHY_OVERLINE_FONT_FAMILY3,
        fontSize: TYPOGRAPHY_OVERLINE_FONT_SIZE3,
        lineHeight: TYPOGRAPHY_OVERLINE_LINE_HEIGHT3,
        fontWeight: TYPOGRAPHY_OVERLINE_FONT_WEIGHT3,
        letterSpacing: TYPOGRAPHY_OVERLINE_LETTER_SPACING3,
        textDecoration: TYPOGRAPHY_OVERLINE_TEXT_DECORATION3,
        textTransform: TYPOGRAPHY_OVERLINE_TEXT_TRANSFORM3
      },
      supporting: {
        fontFamily: TYPOGRAPHY_SUPPORTING_FONT_FAMILY3,
        fontSize: TYPOGRAPHY_SUPPORTING_FONT_SIZE3,
        lineHeight: TYPOGRAPHY_SUPPORTING_LINE_HEIGHT3,
        fontWeight: TYPOGRAPHY_SUPPORTING_FONT_WEIGHT3,
        letterSpacing: TYPOGRAPHY_SUPPORTING_LETTER_SPACING3,
        textDecoration: TYPOGRAPHY_SUPPORTING_TEXT_DECORATION3,
        textTransform: TYPOGRAPHY_SUPPORTING_TEXT_TRANSFORM3
      },
      button: {
        fontFamily: TYPOGRAPHY_BUTTON_FONT_FAMILY3,
        fontSize: TYPOGRAPHY_BUTTON_FONT_SIZE3,
        lineHeight: TYPOGRAPHY_BUTTON_LINE_HEIGHT3,
        fontWeight: TYPOGRAPHY_BUTTON_FONT_WEIGHT3,
        letterSpacing: TYPOGRAPHY_BUTTON_LETTER_SPACING3,
        textDecoration: TYPOGRAPHY_BUTTON_TEXT_DECORATION3,
        textTransform: TYPOGRAPHY_BUTTON_TEXT_TRANSFORM3
      }
    },
    layout: {
      radius: LAYOUT_RADIUS3,
      space: LAYOUT_SPACE3,
      thickness: LAYOUT_THICKNESS3
    },
    duration: {
      short: DURATION_SHORT3,
      medium: DURATION_MEDIUM3,
      long: DURATION_LONG3
    },
    elevation: {
      light: {
        light: ELEVATION_LIGHT_LIGHT3,
        semilight: ELEVATION_LIGHT_SEMILIGHT3,
        regular: ELEVATION_LIGHT_REGULAR3,
        semibold: ELEVATION_LIGHT_SEMIBOLD3,
        bold: ELEVATION_LIGHT_BOLD3,
        extrabold: ELEVATION_LIGHT_EXTRABOLD3
      },
      dark: {
        light: ELEVATION_DARK_LIGHT3,
        semilight: ELEVATION_DARK_SEMILIGHT3,
        regular: ELEVATION_DARK_REGULAR3,
        semibold: ELEVATION_DARK_SEMIBOLD3,
        bold: ELEVATION_DARK_BOLD3,
        extrabold: ELEVATION_DARK_EXTRABOLD3
      }
    }
  });
  MemphisTheme2.MEMPHIS_THEME_PALETTES = [
    VARIANT_PRIMARY3,
    VARIANT_SECONDARY3,
    VARIANT_DANGER2,
    VARIANT_INFO2,
    VARIANT_NEUTRAL2,
    VARIANT_SUCCESS2,
    VARIANT_WARNING2
  ];
  MemphisTheme2.MEMPHIS_THEME_PALETTE_VARIANTS = [
    "0",
    "50",
    "100",
    "200",
    "300",
    "400",
    "500",
    "600",
    "700",
    "800",
    "900"
  ];
  MemphisTheme2.MEMPHIS_THEME_SCHEMES = [
    "light",
    "dark"
  ];
  MemphisTheme2.MEMPHIS_THEME_SCHEME_VARIANTS = [
    "surface",
    "background",
    "foreground",
    "highlight",
    "middlelight",
    "lowlight",
    "transparent",
    "semiTransparent",
    "disabled",
    "contrast",
    "selection"
  ];
  MemphisTheme2.MEMPHIS_THEME_ELEVATION = [
    "light",
    "dark"
  ];
  MemphisTheme2.MEMPHIS_THEME_ELEVATION_VARIANTS = [
    ELEVATION_KEY_LIGHT3,
    ELEVATION_KEY_SEMILIGHT3,
    ELEVATION_KEY_REGULAR3,
    ELEVATION_KEY_SEMIBOLD3,
    ELEVATION_KEY_BOLD3,
    ELEVATION_KEY_EXTRABOLD3
  ];
  MemphisTheme2.MEMPHIS_THEME_TYPOGRAPHY = [
    TYPOGRAPHY_KEY_HEADLINE13,
    TYPOGRAPHY_KEY_HEADLINE23,
    TYPOGRAPHY_KEY_HEADLINE33,
    TYPOGRAPHY_KEY_HEADLINE43,
    TYPOGRAPHY_KEY_HEADLINE53,
    TYPOGRAPHY_KEY_HEADLINE63,
    TYPOGRAPHY_KEY_SUBTITLE12,
    TYPOGRAPHY_KEY_SUBTITLE22,
    TYPOGRAPHY_KEY_BODY13,
    TYPOGRAPHY_KEY_BODY23,
    TYPOGRAPHY_KEY_CAPTION2,
    TYPOGRAPHY_KEY_OVERLINE2,
    TYPOGRAPHY_KEY_BUTTON3
  ];
  MemphisTheme2.MEMPHIS_THEME_METADATA = {
    theme: MemphisTheme2.MEMPHIS_THEME,
    palettes: MemphisTheme2.MEMPHIS_THEME_PALETTES,
    paletteVariants: MemphisTheme2.MEMPHIS_THEME_PALETTE_VARIANTS,
    schemes: MemphisTheme2.MEMPHIS_THEME_SCHEMES,
    schemeVariants: MemphisTheme2.MEMPHIS_THEME_SCHEME_VARIANTS,
    elevation: MemphisTheme2.MEMPHIS_THEME_ELEVATION,
    elevationVariants: MemphisTheme2.MEMPHIS_THEME_ELEVATION_VARIANTS,
    typographies: MemphisTheme2.MEMPHIS_THEME_TYPOGRAPHY
  };
})(exports.MemphisTheme || (exports.MemphisTheme = {}));
exports.MemphisTheme = void 0;

// src/theming/tokens/SohoTokens.ts
var NAME4 = "soho";
var FONT_FAMILY4 = "'Inter', ui-sans-serif, system-ui, sans-serif";
var LAYOUT_RADIUS4 = "10px";
var LAYOUT_SPACE4 = "8px";
var LAYOUT_THICKNESS4 = "1px";
var SCHEME_LIGHT_SURFACE4 = "#ffffff";
var SCHEME_LIGHT_CONTRAST4 = "#fafafa";
var SCHEME_LIGHT_BACKGROUND4 = "#ffffff";
var SCHEME_LIGHT_FOREGROUND4 = "#0a0a0a";
var SCHEME_LIGHT_HIGHLIGHT4 = "#e5e5e5";
var SCHEME_LIGHT_MIDDLELIGHT4 = "#737373";
var SCHEME_LIGHT_LOWLIGHT4 = "#525252";
var SCHEME_LIGHT_TRANSPARENT4 = "rgba(255, 255, 255, 0)";
var SCHEME_LIGHT_SEMI_TRANSPARENT4 = "rgba(0, 0, 0, 0.5019607843137255)";
var SCHEME_LIGHT_DISABLED4 = "#a1a1a1";
var SCHEME_LIGHT_SELECTION4 = "#d4d4d4";
var SCHEME_DARK_SURFACE4 = "#171717";
var SCHEME_DARK_CONTRAST4 = "#171717";
var SCHEME_DARK_BACKGROUND4 = "#0a0a0a";
var SCHEME_DARK_FOREGROUND4 = "#fafafa";
var SCHEME_DARK_HIGHLIGHT4 = "rgba(255, 255, 255, 0.10196078431372549)";
var SCHEME_DARK_MIDDLELIGHT4 = "#a1a1a1";
var SCHEME_DARK_LOWLIGHT4 = "#d4d4d4";
var SCHEME_DARK_TRANSPARENT4 = "rgba(10, 10, 10, 0)";
var SCHEME_DARK_SEMI_TRANSPARENT4 = "rgba(0, 0, 0, 0.5019607843137255)";
var SCHEME_DARK_DISABLED4 = "#525252";
var SCHEME_DARK_SELECTION4 = "#404040";
var COLOR_LIGHT_PRIMARY_04 = "#fafafa";
var COLOR_LIGHT_PRIMARY_504 = "#fafafa";
var COLOR_LIGHT_PRIMARY_1004 = "#f5f5f5";
var COLOR_LIGHT_PRIMARY_2004 = "#e5e5e5";
var COLOR_LIGHT_PRIMARY_3004 = "#d4d4d4";
var COLOR_LIGHT_PRIMARY_4004 = "#737373";
var COLOR_LIGHT_PRIMARY_5004 = "#171717";
var COLOR_LIGHT_PRIMARY_6004 = "#171717";
var COLOR_LIGHT_PRIMARY_7004 = "#0a0a0a";
var COLOR_LIGHT_PRIMARY_8004 = "#050505";
var COLOR_LIGHT_PRIMARY_9004 = "#000000";
var COLOR_LIGHT_SECONDARY_04 = "#ffffff";
var COLOR_LIGHT_SECONDARY_504 = "#f0fdfa";
var COLOR_LIGHT_SECONDARY_1004 = "#cbfbf1";
var COLOR_LIGHT_SECONDARY_2004 = "#96f7e4";
var COLOR_LIGHT_SECONDARY_3004 = "#46ecd5";
var COLOR_LIGHT_SECONDARY_4004 = "#009689";
var COLOR_LIGHT_SECONDARY_5004 = "#00786f";
var COLOR_LIGHT_SECONDARY_6004 = "#005f5a";
var COLOR_LIGHT_SECONDARY_7004 = "#0b4f4a";
var COLOR_LIGHT_SECONDARY_8004 = "#0b4f4a";
var COLOR_LIGHT_SECONDARY_9004 = "#022f2e";
var COLOR_LIGHT_TERTIARY_04 = "#ffffff";
var COLOR_LIGHT_TERTIARY_504 = "#fff7ed";
var COLOR_LIGHT_TERTIARY_1004 = "#ffedd4";
var COLOR_LIGHT_TERTIARY_2004 = "#ffd6a7";
var COLOR_LIGHT_TERTIARY_3004 = "#ffb86a";
var COLOR_LIGHT_TERTIARY_4004 = "#f54900";
var COLOR_LIGHT_TERTIARY_5004 = "#ca3500";
var COLOR_LIGHT_TERTIARY_6004 = "#9f2d00";
var COLOR_LIGHT_TERTIARY_7004 = "#7e2a0c";
var COLOR_LIGHT_TERTIARY_8004 = "#7e2a0c";
var COLOR_LIGHT_TERTIARY_9004 = "#441306";
var COLOR_LIGHT_INFO_04 = "#ffffff";
var COLOR_LIGHT_INFO_504 = "#eff6ff";
var COLOR_LIGHT_INFO_1004 = "#dbeafe";
var COLOR_LIGHT_INFO_2004 = "#bedbff";
var COLOR_LIGHT_INFO_3004 = "#8ec5ff";
var COLOR_LIGHT_INFO_4004 = "#2b7fff";
var COLOR_LIGHT_INFO_5004 = "#155dfc";
var COLOR_LIGHT_INFO_6004 = "#1447e6";
var COLOR_LIGHT_INFO_7004 = "#193cb8";
var COLOR_LIGHT_INFO_8004 = "#1c398e";
var COLOR_LIGHT_INFO_9004 = "#162456";
var COLOR_LIGHT_WARNING_04 = "#ffffff";
var COLOR_LIGHT_WARNING_504 = "#fffbeb";
var COLOR_LIGHT_WARNING_1004 = "#fef3c6";
var COLOR_LIGHT_WARNING_2004 = "#fee685";
var COLOR_LIGHT_WARNING_3004 = "#ffd230";
var COLOR_LIGHT_WARNING_4004 = "#e17100";
var COLOR_LIGHT_WARNING_5004 = "#bb4d00";
var COLOR_LIGHT_WARNING_6004 = "#973c00";
var COLOR_LIGHT_WARNING_7004 = "#7b3306";
var COLOR_LIGHT_WARNING_8004 = "#7b3306";
var COLOR_LIGHT_WARNING_9004 = "#461901";
var COLOR_LIGHT_DANGER_04 = "#ffffff";
var COLOR_LIGHT_DANGER_504 = "#fef2f2";
var COLOR_LIGHT_DANGER_1004 = "#ffe2e2";
var COLOR_LIGHT_DANGER_2004 = "#ffc9c9";
var COLOR_LIGHT_DANGER_3004 = "#ffa2a2";
var COLOR_LIGHT_DANGER_4004 = "#fb2c36";
var COLOR_LIGHT_DANGER_5004 = "#e7000b";
var COLOR_LIGHT_DANGER_6004 = "#e7000b";
var COLOR_LIGHT_DANGER_7004 = "#9f0712";
var COLOR_LIGHT_DANGER_8004 = "#82181a";
var COLOR_LIGHT_DANGER_9004 = "#460809";
var COLOR_LIGHT_SUCCESS_04 = "#ffffff";
var COLOR_LIGHT_SUCCESS_504 = "#f0fdf4";
var COLOR_LIGHT_SUCCESS_1004 = "#dcfce7";
var COLOR_LIGHT_SUCCESS_2004 = "#b9f8cf";
var COLOR_LIGHT_SUCCESS_3004 = "#7bf1a8";
var COLOR_LIGHT_SUCCESS_4004 = "#00a63e";
var COLOR_LIGHT_SUCCESS_5004 = "#008236";
var COLOR_LIGHT_SUCCESS_6004 = "#016630";
var COLOR_LIGHT_SUCCESS_7004 = "#0d542b";
var COLOR_LIGHT_SUCCESS_8004 = "#0d542b";
var COLOR_LIGHT_SUCCESS_9004 = "#032e15";
var COLOR_LIGHT_HIGHLIGHT_04 = "#ffffff";
var COLOR_LIGHT_HIGHLIGHT_504 = "#f5f3ff";
var COLOR_LIGHT_HIGHLIGHT_1004 = "#ede9fe";
var COLOR_LIGHT_HIGHLIGHT_2004 = "#ddd6ff";
var COLOR_LIGHT_HIGHLIGHT_3004 = "#c4b4ff";
var COLOR_LIGHT_HIGHLIGHT_4004 = "#8e51ff";
var COLOR_LIGHT_HIGHLIGHT_5004 = "#7f22fe";
var COLOR_LIGHT_HIGHLIGHT_6004 = "#7008e7";
var COLOR_LIGHT_HIGHLIGHT_7004 = "#5d0ec0";
var COLOR_LIGHT_HIGHLIGHT_8004 = "#4d179a";
var COLOR_LIGHT_HIGHLIGHT_9004 = "#2f0d68";
var COLOR_LIGHT_NEUTRAL_04 = "#ffffff";
var COLOR_LIGHT_NEUTRAL_504 = "#fafafa";
var COLOR_LIGHT_NEUTRAL_1004 = "#f5f5f5";
var COLOR_LIGHT_NEUTRAL_2004 = "#e5e5e5";
var COLOR_LIGHT_NEUTRAL_3004 = "#d4d4d4";
var COLOR_LIGHT_NEUTRAL_4004 = "#a1a1a1";
var COLOR_LIGHT_NEUTRAL_5004 = "#737373";
var COLOR_LIGHT_NEUTRAL_6004 = "#525252";
var COLOR_LIGHT_NEUTRAL_7004 = "#404040";
var COLOR_LIGHT_NEUTRAL_8004 = "#262626";
var COLOR_LIGHT_NEUTRAL_9004 = "#171717";
var COLOR_DARK_PRIMARY_04 = "#171717";
var COLOR_DARK_PRIMARY_504 = "#0a0a0a";
var COLOR_DARK_PRIMARY_1004 = "#171717";
var COLOR_DARK_PRIMARY_2004 = "#262626";
var COLOR_DARK_PRIMARY_3004 = "#404040";
var COLOR_DARK_PRIMARY_4004 = "#a1a1a1";
var COLOR_DARK_PRIMARY_5004 = "#e5e5e5";
var COLOR_DARK_PRIMARY_6004 = "#e5e5e5";
var COLOR_DARK_PRIMARY_7004 = "#f5f5f5";
var COLOR_DARK_PRIMARY_8004 = "#fafafa";
var COLOR_DARK_PRIMARY_9004 = "#ffffff";
var COLOR_DARK_SECONDARY_04 = "#022f2e";
var COLOR_DARK_SECONDARY_504 = "#022f2e";
var COLOR_DARK_SECONDARY_1004 = "#0b4f4a";
var COLOR_DARK_SECONDARY_2004 = "#005f5a";
var COLOR_DARK_SECONDARY_3004 = "#00786f";
var COLOR_DARK_SECONDARY_4004 = "#00bba7";
var COLOR_DARK_SECONDARY_5004 = "#00d5be";
var COLOR_DARK_SECONDARY_6004 = "#46ecd5";
var COLOR_DARK_SECONDARY_7004 = "#96f7e4";
var COLOR_DARK_SECONDARY_8004 = "#cbfbf1";
var COLOR_DARK_SECONDARY_9004 = "#f0fdfa";
var COLOR_DARK_TERTIARY_04 = "#441306";
var COLOR_DARK_TERTIARY_504 = "#441306";
var COLOR_DARK_TERTIARY_1004 = "#7e2a0c";
var COLOR_DARK_TERTIARY_2004 = "#9f2d00";
var COLOR_DARK_TERTIARY_3004 = "#ca3500";
var COLOR_DARK_TERTIARY_4004 = "#ff6900";
var COLOR_DARK_TERTIARY_5004 = "#ff8904";
var COLOR_DARK_TERTIARY_6004 = "#ffb86a";
var COLOR_DARK_TERTIARY_7004 = "#ffd6a7";
var COLOR_DARK_TERTIARY_8004 = "#ffedd4";
var COLOR_DARK_TERTIARY_9004 = "#fff7ed";
var COLOR_DARK_INFO_04 = "#162456";
var COLOR_DARK_INFO_504 = "#162456";
var COLOR_DARK_INFO_1004 = "#1c398e";
var COLOR_DARK_INFO_2004 = "#193cb8";
var COLOR_DARK_INFO_3004 = "#1447e6";
var COLOR_DARK_INFO_4004 = "#2b7fff";
var COLOR_DARK_INFO_5004 = "#51a2ff";
var COLOR_DARK_INFO_6004 = "#8ec5ff";
var COLOR_DARK_INFO_7004 = "#bedbff";
var COLOR_DARK_INFO_8004 = "#dbeafe";
var COLOR_DARK_INFO_9004 = "#eff6ff";
var COLOR_DARK_WARNING_04 = "#461901";
var COLOR_DARK_WARNING_504 = "#461901";
var COLOR_DARK_WARNING_1004 = "#7b3306";
var COLOR_DARK_WARNING_2004 = "#973c00";
var COLOR_DARK_WARNING_3004 = "#bb4d00";
var COLOR_DARK_WARNING_4004 = "#fe9a00";
var COLOR_DARK_WARNING_5004 = "#ffb900";
var COLOR_DARK_WARNING_6004 = "#ffd230";
var COLOR_DARK_WARNING_7004 = "#fee685";
var COLOR_DARK_WARNING_8004 = "#fef3c6";
var COLOR_DARK_WARNING_9004 = "#fffbeb";
var COLOR_DARK_DANGER_04 = "#ffffff";
var COLOR_DARK_DANGER_504 = "#460809";
var COLOR_DARK_DANGER_1004 = "#82181a";
var COLOR_DARK_DANGER_2004 = "#9f0712";
var COLOR_DARK_DANGER_3004 = "#c10007";
var COLOR_DARK_DANGER_4004 = "#fb2c36";
var COLOR_DARK_DANGER_5004 = "#9d4042";
var COLOR_DARK_DANGER_6004 = "#ff6467";
var COLOR_DARK_DANGER_7004 = "#ffc9c9";
var COLOR_DARK_DANGER_8004 = "#ffe2e2";
var COLOR_DARK_DANGER_9004 = "#fef2f2";
var COLOR_DARK_SUCCESS_04 = "#032e15";
var COLOR_DARK_SUCCESS_504 = "#032e15";
var COLOR_DARK_SUCCESS_1004 = "#0d542b";
var COLOR_DARK_SUCCESS_2004 = "#016630";
var COLOR_DARK_SUCCESS_3004 = "#008236";
var COLOR_DARK_SUCCESS_4004 = "#00c950";
var COLOR_DARK_SUCCESS_5004 = "#05df72";
var COLOR_DARK_SUCCESS_6004 = "#7bf1a8";
var COLOR_DARK_SUCCESS_7004 = "#b9f8cf";
var COLOR_DARK_SUCCESS_8004 = "#dcfce7";
var COLOR_DARK_SUCCESS_9004 = "#f0fdf4";
var COLOR_DARK_HIGHLIGHT_04 = "#2f0d68";
var COLOR_DARK_HIGHLIGHT_504 = "#2f0d68";
var COLOR_DARK_HIGHLIGHT_1004 = "#4d179a";
var COLOR_DARK_HIGHLIGHT_2004 = "#5d0ec0";
var COLOR_DARK_HIGHLIGHT_3004 = "#7008e7";
var COLOR_DARK_HIGHLIGHT_4004 = "#8e51ff";
var COLOR_DARK_HIGHLIGHT_5004 = "#a684ff";
var COLOR_DARK_HIGHLIGHT_6004 = "#c4b4ff";
var COLOR_DARK_HIGHLIGHT_7004 = "#ddd6ff";
var COLOR_DARK_HIGHLIGHT_8004 = "#ede9fe";
var COLOR_DARK_HIGHLIGHT_9004 = "#f5f3ff";
var COLOR_DARK_NEUTRAL_04 = "#000000";
var COLOR_DARK_NEUTRAL_504 = "#171717";
var COLOR_DARK_NEUTRAL_1004 = "#262626";
var COLOR_DARK_NEUTRAL_2004 = "#404040";
var COLOR_DARK_NEUTRAL_3004 = "#525252";
var COLOR_DARK_NEUTRAL_4004 = "#737373";
var COLOR_DARK_NEUTRAL_5004 = "#a1a1a1";
var COLOR_DARK_NEUTRAL_6004 = "#d4d4d4";
var COLOR_DARK_NEUTRAL_7004 = "#e5e5e5";
var COLOR_DARK_NEUTRAL_8004 = "#f5f5f5";
var COLOR_DARK_NEUTRAL_9004 = "#fafafa";
var TYPOGRAPHY_HEADLINE1_FONT_FAMILY4 = "'Inter', ui-sans-serif, system-ui, sans-serif";
var TYPOGRAPHY_HEADLINE1_FONT_SIZE4 = "48px";
var TYPOGRAPHY_HEADLINE1_LINE_HEIGHT4 = "48px";
var TYPOGRAPHY_HEADLINE1_FONT_WEIGHT4 = "700";
var TYPOGRAPHY_HEADLINE1_LETTER_SPACING4 = "-1.2px";
var TYPOGRAPHY_HEADLINE1_TEXT_DECORATION4 = "none";
var TYPOGRAPHY_HEADLINE1_TEXT_TRANSFORM4 = "none";
var TYPOGRAPHY_HEADLINE2_FONT_FAMILY4 = "'Inter', ui-sans-serif, system-ui, sans-serif";
var TYPOGRAPHY_HEADLINE2_FONT_SIZE4 = "36px";
var TYPOGRAPHY_HEADLINE2_LINE_HEIGHT4 = "40px";
var TYPOGRAPHY_HEADLINE2_FONT_WEIGHT4 = "800";
var TYPOGRAPHY_HEADLINE2_LETTER_SPACING4 = "-0.9px";
var TYPOGRAPHY_HEADLINE2_TEXT_DECORATION4 = "none";
var TYPOGRAPHY_HEADLINE2_TEXT_TRANSFORM4 = "none";
var TYPOGRAPHY_HEADLINE3_FONT_FAMILY4 = "'Inter', ui-sans-serif, system-ui, sans-serif";
var TYPOGRAPHY_HEADLINE3_FONT_SIZE4 = "30px";
var TYPOGRAPHY_HEADLINE3_LINE_HEIGHT4 = "36px";
var TYPOGRAPHY_HEADLINE3_FONT_WEIGHT4 = "600";
var TYPOGRAPHY_HEADLINE3_LETTER_SPACING4 = "-0.75px";
var TYPOGRAPHY_HEADLINE3_TEXT_DECORATION4 = "none";
var TYPOGRAPHY_HEADLINE3_TEXT_TRANSFORM4 = "none";
var TYPOGRAPHY_HEADLINE4_FONT_FAMILY4 = "'Inter', ui-sans-serif, system-ui, sans-serif";
var TYPOGRAPHY_HEADLINE4_FONT_SIZE4 = "24px";
var TYPOGRAPHY_HEADLINE4_LINE_HEIGHT4 = "32px";
var TYPOGRAPHY_HEADLINE4_FONT_WEIGHT4 = "600";
var TYPOGRAPHY_HEADLINE4_LETTER_SPACING4 = "-0.6px";
var TYPOGRAPHY_HEADLINE4_TEXT_DECORATION4 = "none";
var TYPOGRAPHY_HEADLINE4_TEXT_TRANSFORM4 = "none";
var TYPOGRAPHY_HEADLINE5_FONT_FAMILY4 = "'Inter', ui-sans-serif, system-ui, sans-serif";
var TYPOGRAPHY_HEADLINE5_FONT_SIZE4 = "20px";
var TYPOGRAPHY_HEADLINE5_LINE_HEIGHT4 = "28px";
var TYPOGRAPHY_HEADLINE5_FONT_WEIGHT4 = "600";
var TYPOGRAPHY_HEADLINE5_LETTER_SPACING4 = "-0.5px";
var TYPOGRAPHY_HEADLINE5_TEXT_DECORATION4 = "none";
var TYPOGRAPHY_HEADLINE5_TEXT_TRANSFORM4 = "none";
var TYPOGRAPHY_HEADLINE6_FONT_FAMILY4 = "'Inter', ui-sans-serif, system-ui, sans-serif";
var TYPOGRAPHY_HEADLINE6_FONT_SIZE4 = "18px";
var TYPOGRAPHY_HEADLINE6_LINE_HEIGHT4 = "28px";
var TYPOGRAPHY_HEADLINE6_FONT_WEIGHT4 = "600";
var TYPOGRAPHY_HEADLINE6_LETTER_SPACING4 = "normal";
var TYPOGRAPHY_HEADLINE6_TEXT_DECORATION4 = "none";
var TYPOGRAPHY_HEADLINE6_TEXT_TRANSFORM4 = "none";
var TYPOGRAPHY_SUBTITLE1_FONT_FAMILY4 = "'Inter', ui-sans-serif, system-ui, sans-serif";
var TYPOGRAPHY_SUBTITLE1_FONT_SIZE4 = "16px";
var TYPOGRAPHY_SUBTITLE1_LINE_HEIGHT4 = "24px";
var TYPOGRAPHY_SUBTITLE1_FONT_WEIGHT4 = "500";
var TYPOGRAPHY_SUBTITLE1_LETTER_SPACING4 = "normal";
var TYPOGRAPHY_SUBTITLE1_TEXT_DECORATION4 = "none";
var TYPOGRAPHY_SUBTITLE1_TEXT_TRANSFORM4 = "none";
var TYPOGRAPHY_SUBTITLE2_FONT_FAMILY4 = "'Inter', ui-sans-serif, system-ui, sans-serif";
var TYPOGRAPHY_SUBTITLE2_FONT_SIZE4 = "14px";
var TYPOGRAPHY_SUBTITLE2_LINE_HEIGHT4 = "20px";
var TYPOGRAPHY_SUBTITLE2_FONT_WEIGHT4 = "500";
var TYPOGRAPHY_SUBTITLE2_LETTER_SPACING4 = "normal";
var TYPOGRAPHY_SUBTITLE2_TEXT_DECORATION4 = "none";
var TYPOGRAPHY_SUBTITLE2_TEXT_TRANSFORM4 = "none";
var TYPOGRAPHY_BODY1_FONT_FAMILY4 = "'Inter', ui-sans-serif, system-ui, sans-serif";
var TYPOGRAPHY_BODY1_FONT_SIZE4 = "16px";
var TYPOGRAPHY_BODY1_LINE_HEIGHT4 = "24px";
var TYPOGRAPHY_BODY1_FONT_WEIGHT4 = "400";
var TYPOGRAPHY_BODY1_LETTER_SPACING4 = "normal";
var TYPOGRAPHY_BODY1_TEXT_DECORATION4 = "none";
var TYPOGRAPHY_BODY1_TEXT_TRANSFORM4 = "none";
var TYPOGRAPHY_BODY2_FONT_FAMILY4 = "'Inter', ui-sans-serif, system-ui, sans-serif";
var TYPOGRAPHY_BODY2_FONT_SIZE4 = "14px";
var TYPOGRAPHY_BODY2_LINE_HEIGHT4 = "20px";
var TYPOGRAPHY_BODY2_FONT_WEIGHT4 = "400";
var TYPOGRAPHY_BODY2_LETTER_SPACING4 = "normal";
var TYPOGRAPHY_BODY2_TEXT_DECORATION4 = "none";
var TYPOGRAPHY_BODY2_TEXT_TRANSFORM4 = "none";
var TYPOGRAPHY_SUPPORTING_FONT_FAMILY4 = "'Inter', ui-sans-serif, system-ui, sans-serif";
var TYPOGRAPHY_SUPPORTING_FONT_SIZE4 = "14px";
var TYPOGRAPHY_SUPPORTING_LINE_HEIGHT4 = "20px";
var TYPOGRAPHY_SUPPORTING_FONT_WEIGHT4 = "400";
var TYPOGRAPHY_SUPPORTING_LETTER_SPACING4 = "normal";
var TYPOGRAPHY_SUPPORTING_TEXT_DECORATION4 = "none";
var TYPOGRAPHY_SUPPORTING_TEXT_TRANSFORM4 = "none";
var TYPOGRAPHY_CAPTION_FONT_FAMILY4 = "'Inter', ui-sans-serif, system-ui, sans-serif";
var TYPOGRAPHY_CAPTION_FONT_SIZE4 = "12px";
var TYPOGRAPHY_CAPTION_LINE_HEIGHT4 = "16px";
var TYPOGRAPHY_CAPTION_FONT_WEIGHT4 = "400";
var TYPOGRAPHY_CAPTION_LETTER_SPACING4 = "normal";
var TYPOGRAPHY_CAPTION_TEXT_DECORATION4 = "none";
var TYPOGRAPHY_CAPTION_TEXT_TRANSFORM4 = "none";
var TYPOGRAPHY_BUTTON_FONT_FAMILY4 = "'Inter', ui-sans-serif, system-ui, sans-serif";
var TYPOGRAPHY_BUTTON_FONT_SIZE4 = "14px";
var TYPOGRAPHY_BUTTON_LINE_HEIGHT4 = "20px";
var TYPOGRAPHY_BUTTON_FONT_WEIGHT4 = "500";
var TYPOGRAPHY_BUTTON_LETTER_SPACING4 = "normal";
var TYPOGRAPHY_BUTTON_TEXT_DECORATION4 = "none";
var TYPOGRAPHY_BUTTON_TEXT_TRANSFORM4 = "none";
var TYPOGRAPHY_OVERLINE_FONT_FAMILY4 = "'Inter', ui-sans-serif, system-ui, sans-serif";
var TYPOGRAPHY_OVERLINE_FONT_SIZE4 = "12px";
var TYPOGRAPHY_OVERLINE_LINE_HEIGHT4 = "16px";
var TYPOGRAPHY_OVERLINE_FONT_WEIGHT4 = "500";
var TYPOGRAPHY_OVERLINE_LETTER_SPACING4 = "normal";
var TYPOGRAPHY_OVERLINE_TEXT_DECORATION4 = "none";
var TYPOGRAPHY_OVERLINE_TEXT_TRANSFORM4 = "none";
var ELEVATION_NONE2 = "none";
var ELEVATION_LIGHT_LIGHT4 = "0px 1px 2px 0px rgba(0, 0, 0, 0.05), 0px 0px 0px 0px rgba(0, 0, 0, 0)";
var ELEVATION_LIGHT_SEMILIGHT4 = "0px 1px 3px 0px rgba(0, 0, 0, 0.1), 0px 1px 2px -1px rgba(0, 0, 0, 0.1)";
var ELEVATION_LIGHT_REGULAR4 = "0px 4px 6px -1px rgba(0, 0, 0, 0.1), 0px 2px 4px -2px rgba(0, 0, 0, 0.1)";
var ELEVATION_LIGHT_SEMIBOLD4 = "0px 10px 15px -3px rgba(0, 0, 0, 0.1), 0px 4px 6px -4px rgba(0, 0, 0, 0.1)";
var ELEVATION_LIGHT_BOLD4 = "0px 20px 25px -5px rgba(0, 0, 0, 0.1), 0px 8px 10px -6px rgba(0, 0, 0, 0.1)";
var ELEVATION_LIGHT_EXTRABOLD4 = "0px 25px 50px -12px rgba(0, 0, 0, 0.25), 0px 0px 0px 0px rgba(0, 0, 0, 0)";
var ELEVATION_DARK_LIGHT4 = "0px 1px 2px 0px rgba(0, 0, 0, 0.05), 0px 0px 0px 0px rgba(0, 0, 0, 0)";
var ELEVATION_DARK_SEMILIGHT4 = "0px 1px 3px 0px rgba(0, 0, 0, 0.1), 0px 1px 2px -1px rgba(0, 0, 0, 0.1)";
var ELEVATION_DARK_REGULAR4 = "0px 4px 6px -1px rgba(0, 0, 0, 0.1), 0px 2px 4px -2px rgba(0, 0, 0, 0.1)";
var ELEVATION_DARK_SEMIBOLD4 = "0px 10px 15px -3px rgba(0, 0, 0, 0.1), 0px 4px 6px -4px rgba(0, 0, 0, 0.1)";
var ELEVATION_DARK_BOLD4 = "0px 20px 25px -5px rgba(0, 0, 0, 0.1), 0px 8px 10px -6px rgba(0, 0, 0, 0.1)";
var ELEVATION_DARK_EXTRABOLD4 = "0px 25px 50px -12px rgba(0, 0, 0, 0.25), 0px 0px 0px 0px rgba(0, 0, 0, 0)";
var TYPOGRAPHY_KEY_HEADLINE14 = "headline1";
var TYPOGRAPHY_KEY_HEADLINE24 = "headline2";
var TYPOGRAPHY_KEY_HEADLINE34 = "headline3";
var TYPOGRAPHY_KEY_HEADLINE44 = "headline4";
var TYPOGRAPHY_KEY_HEADLINE54 = "headline5";
var TYPOGRAPHY_KEY_HEADLINE64 = "headline6";
var TYPOGRAPHY_KEY_BODY14 = "body1";
var TYPOGRAPHY_KEY_BODY24 = "body2";
var TYPOGRAPHY_KEY_BUTTON4 = "button";
var ELEVATION_KEY_LIGHT4 = "light";
var ELEVATION_KEY_SEMILIGHT4 = "semilight";
var ELEVATION_KEY_REGULAR4 = "regular";
var ELEVATION_KEY_SEMIBOLD4 = "semibold";
var ELEVATION_KEY_BOLD4 = "bold";
var ELEVATION_KEY_EXTRABOLD4 = "extrabold";
var VARIANT_PRIMARY4 = "primary";
var VARIANT_SECONDARY4 = "secondary";
var VARIANT_TERTIARY3 = "tertiary";
var DURATION_SHORT4 = "150ms";
var DURATION_MEDIUM4 = "200ms";
var DURATION_LONG4 = "300ms";

// src/theming/SohoTheme.ts
(function(SohoTheme2) {
  SohoTheme2.SOHO_THEME = ThemeFactory.create({
    name: NAME4,
    scheme: {
      light: {
        surface: SCHEME_LIGHT_SURFACE4,
        contrast: SCHEME_LIGHT_CONTRAST4,
        background: SCHEME_LIGHT_BACKGROUND4,
        foreground: SCHEME_LIGHT_FOREGROUND4,
        highlight: SCHEME_LIGHT_HIGHLIGHT4,
        middlelight: SCHEME_LIGHT_MIDDLELIGHT4,
        lowlight: SCHEME_LIGHT_LOWLIGHT4,
        transparent: SCHEME_LIGHT_TRANSPARENT4,
        semiTransparent: SCHEME_LIGHT_SEMI_TRANSPARENT4,
        disabled: SCHEME_LIGHT_DISABLED4,
        selection: SCHEME_LIGHT_SELECTION4
      },
      dark: {
        surface: SCHEME_DARK_SURFACE4,
        contrast: SCHEME_DARK_CONTRAST4,
        background: SCHEME_DARK_BACKGROUND4,
        foreground: SCHEME_DARK_FOREGROUND4,
        highlight: SCHEME_DARK_HIGHLIGHT4,
        middlelight: SCHEME_DARK_MIDDLELIGHT4,
        lowlight: SCHEME_DARK_LOWLIGHT4,
        transparent: SCHEME_DARK_TRANSPARENT4,
        semiTransparent: SCHEME_DARK_SEMI_TRANSPARENT4,
        disabled: SCHEME_DARK_DISABLED4,
        selection: SCHEME_DARK_SELECTION4
      }
    },
    palette: {
      light: {
        primary: {
          0: COLOR_LIGHT_PRIMARY_04,
          50: COLOR_LIGHT_PRIMARY_504,
          100: COLOR_LIGHT_PRIMARY_1004,
          200: COLOR_LIGHT_PRIMARY_2004,
          300: COLOR_LIGHT_PRIMARY_3004,
          400: COLOR_LIGHT_PRIMARY_4004,
          500: COLOR_LIGHT_PRIMARY_5004,
          600: COLOR_LIGHT_PRIMARY_6004,
          700: COLOR_LIGHT_PRIMARY_7004,
          800: COLOR_LIGHT_PRIMARY_8004,
          900: COLOR_LIGHT_PRIMARY_9004
        },
        secondary: {
          0: COLOR_LIGHT_SECONDARY_04,
          50: COLOR_LIGHT_SECONDARY_504,
          100: COLOR_LIGHT_SECONDARY_1004,
          200: COLOR_LIGHT_SECONDARY_2004,
          300: COLOR_LIGHT_SECONDARY_3004,
          400: COLOR_LIGHT_SECONDARY_4004,
          500: COLOR_LIGHT_SECONDARY_5004,
          600: COLOR_LIGHT_SECONDARY_6004,
          700: COLOR_LIGHT_SECONDARY_7004,
          800: COLOR_LIGHT_SECONDARY_8004,
          900: COLOR_LIGHT_SECONDARY_9004
        },
        tertiary: {
          0: COLOR_LIGHT_TERTIARY_04,
          50: COLOR_LIGHT_TERTIARY_504,
          100: COLOR_LIGHT_TERTIARY_1004,
          200: COLOR_LIGHT_TERTIARY_2004,
          300: COLOR_LIGHT_TERTIARY_3004,
          400: COLOR_LIGHT_TERTIARY_4004,
          500: COLOR_LIGHT_TERTIARY_5004,
          600: COLOR_LIGHT_TERTIARY_6004,
          700: COLOR_LIGHT_TERTIARY_7004,
          800: COLOR_LIGHT_TERTIARY_8004,
          900: COLOR_LIGHT_TERTIARY_9004
        },
        info: {
          0: COLOR_LIGHT_INFO_04,
          50: COLOR_LIGHT_INFO_504,
          100: COLOR_LIGHT_INFO_1004,
          200: COLOR_LIGHT_INFO_2004,
          300: COLOR_LIGHT_INFO_3004,
          400: COLOR_LIGHT_INFO_4004,
          500: COLOR_LIGHT_INFO_5004,
          600: COLOR_LIGHT_INFO_6004,
          700: COLOR_LIGHT_INFO_7004,
          800: COLOR_LIGHT_INFO_8004,
          900: COLOR_LIGHT_INFO_9004
        },
        warning: {
          0: COLOR_LIGHT_WARNING_04,
          50: COLOR_LIGHT_WARNING_504,
          100: COLOR_LIGHT_WARNING_1004,
          200: COLOR_LIGHT_WARNING_2004,
          300: COLOR_LIGHT_WARNING_3004,
          400: COLOR_LIGHT_WARNING_4004,
          500: COLOR_LIGHT_WARNING_5004,
          600: COLOR_LIGHT_WARNING_6004,
          700: COLOR_LIGHT_WARNING_7004,
          800: COLOR_LIGHT_WARNING_8004,
          900: COLOR_LIGHT_WARNING_9004
        },
        danger: {
          0: COLOR_LIGHT_DANGER_04,
          50: COLOR_LIGHT_DANGER_504,
          100: COLOR_LIGHT_DANGER_1004,
          200: COLOR_LIGHT_DANGER_2004,
          300: COLOR_LIGHT_DANGER_3004,
          400: COLOR_LIGHT_DANGER_4004,
          500: COLOR_LIGHT_DANGER_5004,
          600: COLOR_LIGHT_DANGER_6004,
          700: COLOR_LIGHT_DANGER_7004,
          800: COLOR_LIGHT_DANGER_8004,
          900: COLOR_LIGHT_DANGER_9004
        },
        success: {
          0: COLOR_LIGHT_SUCCESS_04,
          50: COLOR_LIGHT_SUCCESS_504,
          100: COLOR_LIGHT_SUCCESS_1004,
          200: COLOR_LIGHT_SUCCESS_2004,
          300: COLOR_LIGHT_SUCCESS_3004,
          400: COLOR_LIGHT_SUCCESS_4004,
          500: COLOR_LIGHT_SUCCESS_5004,
          600: COLOR_LIGHT_SUCCESS_6004,
          700: COLOR_LIGHT_SUCCESS_7004,
          800: COLOR_LIGHT_SUCCESS_8004,
          900: COLOR_LIGHT_SUCCESS_9004
        },
        highlight: {
          0: COLOR_LIGHT_HIGHLIGHT_04,
          50: COLOR_LIGHT_HIGHLIGHT_504,
          100: COLOR_LIGHT_HIGHLIGHT_1004,
          200: COLOR_LIGHT_HIGHLIGHT_2004,
          300: COLOR_LIGHT_HIGHLIGHT_3004,
          400: COLOR_LIGHT_HIGHLIGHT_4004,
          500: COLOR_LIGHT_HIGHLIGHT_5004,
          600: COLOR_LIGHT_HIGHLIGHT_6004,
          700: COLOR_LIGHT_HIGHLIGHT_7004,
          800: COLOR_LIGHT_HIGHLIGHT_8004,
          900: COLOR_LIGHT_HIGHLIGHT_9004
        },
        neutral: {
          0: COLOR_LIGHT_NEUTRAL_04,
          50: COLOR_LIGHT_NEUTRAL_504,
          100: COLOR_LIGHT_NEUTRAL_1004,
          200: COLOR_LIGHT_NEUTRAL_2004,
          300: COLOR_LIGHT_NEUTRAL_3004,
          400: COLOR_LIGHT_NEUTRAL_4004,
          500: COLOR_LIGHT_NEUTRAL_5004,
          600: COLOR_LIGHT_NEUTRAL_6004,
          700: COLOR_LIGHT_NEUTRAL_7004,
          800: COLOR_LIGHT_NEUTRAL_8004,
          900: COLOR_LIGHT_NEUTRAL_9004
        }
      },
      dark: {
        primary: {
          0: COLOR_DARK_PRIMARY_04,
          50: COLOR_DARK_PRIMARY_504,
          100: COLOR_DARK_PRIMARY_1004,
          200: COLOR_DARK_PRIMARY_2004,
          300: COLOR_DARK_PRIMARY_3004,
          400: COLOR_DARK_PRIMARY_4004,
          500: COLOR_DARK_PRIMARY_5004,
          600: COLOR_DARK_PRIMARY_6004,
          700: COLOR_DARK_PRIMARY_7004,
          800: COLOR_DARK_PRIMARY_8004,
          900: COLOR_DARK_PRIMARY_9004
        },
        secondary: {
          0: COLOR_DARK_SECONDARY_04,
          50: COLOR_DARK_SECONDARY_504,
          100: COLOR_DARK_SECONDARY_1004,
          200: COLOR_DARK_SECONDARY_2004,
          300: COLOR_DARK_SECONDARY_3004,
          400: COLOR_DARK_SECONDARY_4004,
          500: COLOR_DARK_SECONDARY_5004,
          600: COLOR_DARK_SECONDARY_6004,
          700: COLOR_DARK_SECONDARY_7004,
          800: COLOR_DARK_SECONDARY_8004,
          900: COLOR_DARK_SECONDARY_9004
        },
        tertiary: {
          0: COLOR_DARK_TERTIARY_04,
          50: COLOR_DARK_TERTIARY_504,
          100: COLOR_DARK_TERTIARY_1004,
          200: COLOR_DARK_TERTIARY_2004,
          300: COLOR_DARK_TERTIARY_3004,
          400: COLOR_DARK_TERTIARY_4004,
          500: COLOR_DARK_TERTIARY_5004,
          600: COLOR_DARK_TERTIARY_6004,
          700: COLOR_DARK_TERTIARY_7004,
          800: COLOR_DARK_TERTIARY_8004,
          900: COLOR_DARK_TERTIARY_9004
        },
        info: {
          0: COLOR_DARK_INFO_04,
          50: COLOR_DARK_INFO_504,
          100: COLOR_DARK_INFO_1004,
          200: COLOR_DARK_INFO_2004,
          300: COLOR_DARK_INFO_3004,
          400: COLOR_DARK_INFO_4004,
          500: COLOR_DARK_INFO_5004,
          600: COLOR_DARK_INFO_6004,
          700: COLOR_DARK_INFO_7004,
          800: COLOR_DARK_INFO_8004,
          900: COLOR_DARK_INFO_9004
        },
        warning: {
          0: COLOR_DARK_WARNING_04,
          50: COLOR_DARK_WARNING_504,
          100: COLOR_DARK_WARNING_1004,
          200: COLOR_DARK_WARNING_2004,
          300: COLOR_DARK_WARNING_3004,
          400: COLOR_DARK_WARNING_4004,
          500: COLOR_DARK_WARNING_5004,
          600: COLOR_DARK_WARNING_6004,
          700: COLOR_DARK_WARNING_7004,
          800: COLOR_DARK_WARNING_8004,
          900: COLOR_DARK_WARNING_9004
        },
        danger: {
          0: COLOR_DARK_DANGER_04,
          50: COLOR_DARK_DANGER_504,
          100: COLOR_DARK_DANGER_1004,
          200: COLOR_DARK_DANGER_2004,
          300: COLOR_DARK_DANGER_3004,
          400: COLOR_DARK_DANGER_4004,
          500: COLOR_DARK_DANGER_5004,
          600: COLOR_DARK_DANGER_6004,
          700: COLOR_DARK_DANGER_7004,
          800: COLOR_DARK_DANGER_8004,
          900: COLOR_DARK_DANGER_9004
        },
        success: {
          0: COLOR_DARK_SUCCESS_04,
          50: COLOR_DARK_SUCCESS_504,
          100: COLOR_DARK_SUCCESS_1004,
          200: COLOR_DARK_SUCCESS_2004,
          300: COLOR_DARK_SUCCESS_3004,
          400: COLOR_DARK_SUCCESS_4004,
          500: COLOR_DARK_SUCCESS_5004,
          600: COLOR_DARK_SUCCESS_6004,
          700: COLOR_DARK_SUCCESS_7004,
          800: COLOR_DARK_SUCCESS_8004,
          900: COLOR_DARK_SUCCESS_9004
        },
        highlight: {
          0: COLOR_DARK_HIGHLIGHT_04,
          50: COLOR_DARK_HIGHLIGHT_504,
          100: COLOR_DARK_HIGHLIGHT_1004,
          200: COLOR_DARK_HIGHLIGHT_2004,
          300: COLOR_DARK_HIGHLIGHT_3004,
          400: COLOR_DARK_HIGHLIGHT_4004,
          500: COLOR_DARK_HIGHLIGHT_5004,
          600: COLOR_DARK_HIGHLIGHT_6004,
          700: COLOR_DARK_HIGHLIGHT_7004,
          800: COLOR_DARK_HIGHLIGHT_8004,
          900: COLOR_DARK_HIGHLIGHT_9004
        },
        neutral: {
          0: COLOR_DARK_NEUTRAL_04,
          50: COLOR_DARK_NEUTRAL_504,
          100: COLOR_DARK_NEUTRAL_1004,
          200: COLOR_DARK_NEUTRAL_2004,
          300: COLOR_DARK_NEUTRAL_3004,
          400: COLOR_DARK_NEUTRAL_4004,
          500: COLOR_DARK_NEUTRAL_5004,
          600: COLOR_DARK_NEUTRAL_6004,
          700: COLOR_DARK_NEUTRAL_7004,
          800: COLOR_DARK_NEUTRAL_8004,
          900: COLOR_DARK_NEUTRAL_9004
        }
      }
    },
    fontFamily: FONT_FAMILY4,
    typography: {
      headline1: {
        fontFamily: TYPOGRAPHY_HEADLINE1_FONT_FAMILY4,
        fontSize: TYPOGRAPHY_HEADLINE1_FONT_SIZE4,
        lineHeight: TYPOGRAPHY_HEADLINE1_LINE_HEIGHT4,
        fontWeight: TYPOGRAPHY_HEADLINE1_FONT_WEIGHT4,
        letterSpacing: TYPOGRAPHY_HEADLINE1_LETTER_SPACING4,
        textDecoration: TYPOGRAPHY_HEADLINE1_TEXT_DECORATION4,
        textTransform: TYPOGRAPHY_HEADLINE1_TEXT_TRANSFORM4
      },
      headline2: {
        fontFamily: TYPOGRAPHY_HEADLINE2_FONT_FAMILY4,
        fontSize: TYPOGRAPHY_HEADLINE2_FONT_SIZE4,
        lineHeight: TYPOGRAPHY_HEADLINE2_LINE_HEIGHT4,
        fontWeight: TYPOGRAPHY_HEADLINE2_FONT_WEIGHT4,
        letterSpacing: TYPOGRAPHY_HEADLINE2_LETTER_SPACING4,
        textDecoration: TYPOGRAPHY_HEADLINE2_TEXT_DECORATION4,
        textTransform: TYPOGRAPHY_HEADLINE2_TEXT_TRANSFORM4
      },
      headline3: {
        fontFamily: TYPOGRAPHY_HEADLINE3_FONT_FAMILY4,
        fontSize: TYPOGRAPHY_HEADLINE3_FONT_SIZE4,
        lineHeight: TYPOGRAPHY_HEADLINE3_LINE_HEIGHT4,
        fontWeight: TYPOGRAPHY_HEADLINE3_FONT_WEIGHT4,
        letterSpacing: TYPOGRAPHY_HEADLINE3_LETTER_SPACING4,
        textDecoration: TYPOGRAPHY_HEADLINE3_TEXT_DECORATION4,
        textTransform: TYPOGRAPHY_HEADLINE3_TEXT_TRANSFORM4
      },
      headline4: {
        fontFamily: TYPOGRAPHY_HEADLINE4_FONT_FAMILY4,
        fontSize: TYPOGRAPHY_HEADLINE4_FONT_SIZE4,
        lineHeight: TYPOGRAPHY_HEADLINE4_LINE_HEIGHT4,
        fontWeight: TYPOGRAPHY_HEADLINE4_FONT_WEIGHT4,
        letterSpacing: TYPOGRAPHY_HEADLINE4_LETTER_SPACING4,
        textDecoration: TYPOGRAPHY_HEADLINE4_TEXT_DECORATION4,
        textTransform: TYPOGRAPHY_HEADLINE4_TEXT_TRANSFORM4
      },
      headline5: {
        fontFamily: TYPOGRAPHY_HEADLINE5_FONT_FAMILY4,
        fontSize: TYPOGRAPHY_HEADLINE5_FONT_SIZE4,
        lineHeight: TYPOGRAPHY_HEADLINE5_LINE_HEIGHT4,
        fontWeight: TYPOGRAPHY_HEADLINE5_FONT_WEIGHT4,
        letterSpacing: TYPOGRAPHY_HEADLINE5_LETTER_SPACING4,
        textDecoration: TYPOGRAPHY_HEADLINE5_TEXT_DECORATION4,
        textTransform: TYPOGRAPHY_HEADLINE5_TEXT_TRANSFORM4
      },
      headline6: {
        fontFamily: TYPOGRAPHY_HEADLINE6_FONT_FAMILY4,
        fontSize: TYPOGRAPHY_HEADLINE6_FONT_SIZE4,
        lineHeight: TYPOGRAPHY_HEADLINE6_LINE_HEIGHT4,
        fontWeight: TYPOGRAPHY_HEADLINE6_FONT_WEIGHT4,
        letterSpacing: TYPOGRAPHY_HEADLINE6_LETTER_SPACING4,
        textDecoration: TYPOGRAPHY_HEADLINE6_TEXT_DECORATION4,
        textTransform: TYPOGRAPHY_HEADLINE6_TEXT_TRANSFORM4
      },
      body1: {
        fontFamily: TYPOGRAPHY_BODY1_FONT_FAMILY4,
        fontSize: TYPOGRAPHY_BODY1_FONT_SIZE4,
        lineHeight: TYPOGRAPHY_BODY1_LINE_HEIGHT4,
        fontWeight: TYPOGRAPHY_BODY1_FONT_WEIGHT4,
        letterSpacing: TYPOGRAPHY_BODY1_LETTER_SPACING4,
        textDecoration: TYPOGRAPHY_BODY1_TEXT_DECORATION4,
        textTransform: TYPOGRAPHY_BODY1_TEXT_TRANSFORM4
      },
      body2: {
        fontFamily: TYPOGRAPHY_BODY2_FONT_FAMILY4,
        fontSize: TYPOGRAPHY_BODY2_FONT_SIZE4,
        lineHeight: TYPOGRAPHY_BODY2_LINE_HEIGHT4,
        fontWeight: TYPOGRAPHY_BODY2_FONT_WEIGHT4,
        letterSpacing: TYPOGRAPHY_BODY2_LETTER_SPACING4,
        textDecoration: TYPOGRAPHY_BODY2_TEXT_DECORATION4,
        textTransform: TYPOGRAPHY_BODY2_TEXT_TRANSFORM4
      },
      subtitle1: {
        fontFamily: TYPOGRAPHY_SUBTITLE1_FONT_FAMILY4,
        fontSize: TYPOGRAPHY_SUBTITLE1_FONT_SIZE4,
        lineHeight: TYPOGRAPHY_SUBTITLE1_LINE_HEIGHT4,
        fontWeight: TYPOGRAPHY_SUBTITLE1_FONT_WEIGHT4,
        letterSpacing: TYPOGRAPHY_SUBTITLE1_LETTER_SPACING4,
        textDecoration: TYPOGRAPHY_SUBTITLE1_TEXT_DECORATION4,
        textTransform: TYPOGRAPHY_SUBTITLE1_TEXT_TRANSFORM4
      },
      subtitle2: {
        fontFamily: TYPOGRAPHY_SUBTITLE2_FONT_FAMILY4,
        fontSize: TYPOGRAPHY_SUBTITLE2_FONT_SIZE4,
        lineHeight: TYPOGRAPHY_SUBTITLE2_LINE_HEIGHT4,
        fontWeight: TYPOGRAPHY_SUBTITLE2_FONT_WEIGHT4,
        letterSpacing: TYPOGRAPHY_SUBTITLE2_LETTER_SPACING4,
        textDecoration: TYPOGRAPHY_SUBTITLE2_TEXT_DECORATION4,
        textTransform: TYPOGRAPHY_SUBTITLE2_TEXT_TRANSFORM4
      },
      supporting: {
        fontFamily: TYPOGRAPHY_SUPPORTING_FONT_FAMILY4,
        fontSize: TYPOGRAPHY_SUPPORTING_FONT_SIZE4,
        lineHeight: TYPOGRAPHY_SUPPORTING_LINE_HEIGHT4,
        fontWeight: TYPOGRAPHY_SUPPORTING_FONT_WEIGHT4,
        letterSpacing: TYPOGRAPHY_SUPPORTING_LETTER_SPACING4,
        textDecoration: TYPOGRAPHY_SUPPORTING_TEXT_DECORATION4,
        textTransform: TYPOGRAPHY_SUPPORTING_TEXT_TRANSFORM4
      },
      caption: {
        fontFamily: TYPOGRAPHY_CAPTION_FONT_FAMILY4,
        fontSize: TYPOGRAPHY_CAPTION_FONT_SIZE4,
        lineHeight: TYPOGRAPHY_CAPTION_LINE_HEIGHT4,
        fontWeight: TYPOGRAPHY_CAPTION_FONT_WEIGHT4,
        letterSpacing: TYPOGRAPHY_CAPTION_LETTER_SPACING4,
        textDecoration: TYPOGRAPHY_CAPTION_TEXT_DECORATION4,
        textTransform: TYPOGRAPHY_CAPTION_TEXT_TRANSFORM4
      },
      overline: {
        fontFamily: TYPOGRAPHY_OVERLINE_FONT_FAMILY4,
        fontSize: TYPOGRAPHY_OVERLINE_FONT_SIZE4,
        lineHeight: TYPOGRAPHY_OVERLINE_LINE_HEIGHT4,
        fontWeight: TYPOGRAPHY_OVERLINE_FONT_WEIGHT4,
        letterSpacing: TYPOGRAPHY_OVERLINE_LETTER_SPACING4,
        textDecoration: TYPOGRAPHY_OVERLINE_TEXT_DECORATION4,
        textTransform: TYPOGRAPHY_OVERLINE_TEXT_TRANSFORM4
      },
      button: {
        fontFamily: TYPOGRAPHY_BUTTON_FONT_FAMILY4,
        fontSize: TYPOGRAPHY_BUTTON_FONT_SIZE4,
        lineHeight: TYPOGRAPHY_BUTTON_LINE_HEIGHT4,
        fontWeight: TYPOGRAPHY_BUTTON_FONT_WEIGHT4,
        letterSpacing: TYPOGRAPHY_BUTTON_LETTER_SPACING4,
        textDecoration: TYPOGRAPHY_BUTTON_TEXT_DECORATION4,
        textTransform: TYPOGRAPHY_BUTTON_TEXT_TRANSFORM4
      }
    },
    layout: {
      radius: LAYOUT_RADIUS4,
      space: LAYOUT_SPACE4,
      thickness: LAYOUT_THICKNESS4
    },
    duration: {
      short: DURATION_SHORT4,
      medium: DURATION_MEDIUM4,
      long: DURATION_LONG4
    },
    elevation: {
      light: {
        light: ELEVATION_LIGHT_LIGHT4,
        semilight: ELEVATION_LIGHT_SEMILIGHT4,
        regular: ELEVATION_LIGHT_REGULAR4,
        semibold: ELEVATION_LIGHT_SEMIBOLD4,
        bold: ELEVATION_LIGHT_BOLD4,
        extrabold: ELEVATION_LIGHT_EXTRABOLD4,
        none: ELEVATION_NONE2
      },
      dark: {
        light: ELEVATION_DARK_LIGHT4,
        semilight: ELEVATION_DARK_SEMILIGHT4,
        regular: ELEVATION_DARK_REGULAR4,
        semibold: ELEVATION_DARK_SEMIBOLD4,
        bold: ELEVATION_DARK_BOLD4,
        extrabold: ELEVATION_DARK_EXTRABOLD4,
        none: ELEVATION_NONE2
      }
    }
  });
  SohoTheme2.SOHO_THEME_PALETTES = [
    VARIANT_PRIMARY4,
    VARIANT_SECONDARY4,
    VARIANT_TERTIARY3
  ];
  SohoTheme2.SOHO_THEME_PALETTE_VARIANTS = [
    "0",
    "50",
    "100",
    "200",
    "300",
    "400",
    "500",
    "600",
    "700",
    "800",
    "900"
  ];
  SohoTheme2.SOHO_THEME_SCHEMES = [
    "light",
    "dark"
  ];
  SohoTheme2.SOHO_THEME_SCHEME_VARIANTS = [
    "surface",
    "background",
    "foreground",
    "highlight",
    "middlelight",
    "lowlight",
    "transparent",
    "semiTransparent",
    "disabled",
    "contrast",
    "selection"
  ];
  SohoTheme2.SOHO_THEME_ELEVATION = [
    "light",
    "dark"
  ];
  SohoTheme2.SOHO_THEME_ELEVATION_VARIANTS = [
    ELEVATION_KEY_LIGHT4,
    ELEVATION_KEY_SEMILIGHT4,
    ELEVATION_KEY_REGULAR4,
    ELEVATION_KEY_SEMIBOLD4,
    ELEVATION_KEY_BOLD4,
    ELEVATION_KEY_EXTRABOLD4
  ];
  SohoTheme2.SOHO_THEME_TYPOGRAPHY = [
    TYPOGRAPHY_KEY_HEADLINE14,
    TYPOGRAPHY_KEY_HEADLINE24,
    TYPOGRAPHY_KEY_HEADLINE34,
    TYPOGRAPHY_KEY_HEADLINE44,
    TYPOGRAPHY_KEY_HEADLINE54,
    TYPOGRAPHY_KEY_HEADLINE64,
    TYPOGRAPHY_KEY_BODY14,
    TYPOGRAPHY_KEY_BODY24,
    TYPOGRAPHY_KEY_BUTTON4
  ];
  SohoTheme2.SOHO_THEME_METADATA = {
    theme: SohoTheme2.SOHO_THEME,
    palettes: SohoTheme2.SOHO_THEME_PALETTES,
    paletteVariants: SohoTheme2.SOHO_THEME_PALETTE_VARIANTS,
    schemes: SohoTheme2.SOHO_THEME_SCHEMES,
    schemeVariants: SohoTheme2.SOHO_THEME_SCHEME_VARIANTS,
    elevation: SohoTheme2.SOHO_THEME_ELEVATION,
    elevationVariants: SohoTheme2.SOHO_THEME_ELEVATION_VARIANTS,
    typographies: SohoTheme2.SOHO_THEME_TYPOGRAPHY
  };
})(exports.SohoTheme || (exports.SohoTheme = {}));
exports.SohoTheme = void 0;
var HslThemeGeneratorStrategy = class _HslThemeGeneratorStrategy {
  static {
    __name(this, "HslThemeGeneratorStrategy");
  }
  // #region Fields
  static _LIGHTNESS_THRESHOLD = 0.5;
  // #endregion
  // #region Methods
  /**
   * Determines whether a color naturally belongs to the given mode's HSL lightness range.
   *
   * @remarks
   * A color with HSL lightness > 0.5 is considered "light"; ≤ 0.5 is considered "dark".
   *
   * @public
   * @param color - The color to check
   * @param mode - The target color mode ('dark' | 'light')
   * @returns `true` if the color is naturally compatible with the given mode
   */
  isColorInModeSpectrum(color, mode) {
    const [, , l] = chroma7__default.default(color).hsl();
    return mode === "light" ? l > _HslThemeGeneratorStrategy._LIGHTNESS_THRESHOLD : l <= _HslThemeGeneratorStrategy._LIGHTNESS_THRESHOLD;
  }
  /**
   * Adapts a color to the opposite mode by symmetrically inverting its HSL lightness
   * (`L → 1 - L`) while preserving hue and saturation.
   *
   * @remarks
   * The inversion is symmetric: a light color becomes dark and vice-versa, regardless
   * of the direction. Therefore no target mode parameter is required.
   *
   * The inverted lightness is clamped to [0.05, 0.95] to avoid pure black / pure white.
   * Subclasses may override this method for theme-specific post-processing.
   *
   * @public
   * @param color - The color to adapt
   * @returns The adapted color with inverted lightness
   */
  adaptColorToMode(color) {
    const c = chroma7__default.default(color);
    const [h, s, l] = c.hsl();
    const invertedL = Math.min(Math.max(1 - l, 0.05), 0.95);
    return chroma7__default.default.hsl(isNaN(h) ? 0 : h, s, invertedL).hex();
  }
  /**
   * Generates a palette of shades based on a base/accent color using HSL interpolation.
   *
   * @public
   * @param baseColor - The base/accent color (e.g. "#3498db")
   * @param mode - 'light' or 'dark' mode: determines how light or dark the palette extremes are.
   * @returns The generated theme palette with shade steps 0–900
   */
  generatePalette(baseColor, mode) {
    const steps = [
      0,
      50,
      100,
      200,
      300,
      400,
      500,
      600,
      700,
      800,
      900
    ];
    const base = chroma7__default.default(baseColor);
    const [h, s] = base.hsl();
    const palette = {};
    steps.forEach((step, idx) => {
      const t = idx / (steps.length - 1);
      const lightness = mode === "light" ? 0.95 - t * 0.6 : 0.15 + t * 0.6;
      const col = chroma7__default.default.hsl(h, s, lightness);
      palette[step.toString()] = col.hex();
    });
    return {
      "0": palette["0"],
      "50": palette["50"],
      "100": palette["100"],
      "200": palette["200"],
      "300": palette["300"],
      "400": palette["400"],
      "500": palette["500"],
      "600": palette["600"],
      "700": palette["700"],
      "800": palette["800"],
      "900": palette["900"]
    };
  }
  /**
   * Generates a semantic color scheme for UI usage, based on the generated palette.
   *
   * @public
   * @param baseColor - The base/accent color
   * @param mode - 'light' or 'dark'
   * @returns The generated theme scheme with semantic color roles
   */
  generateScheme(baseColor, mode) {
    const p = this.generatePalette(baseColor, mode);
    return {
      background: p["50"],
      foreground: p["900"],
      disabled: p["300"],
      contrast: p["900"],
      highlight: p["700"],
      lowlight: p["300"],
      middlelight: p["500"],
      selection: p["500"],
      semiTransparent: chroma7__default.default(p["500"]).alpha(0.5).hex(),
      surface: p["50"],
      transparent: chroma7__default.default(p["500"]).alpha(0).hex()
    };
  }
};
var LchThemeGeneratorStrategy = class _LchThemeGeneratorStrategy {
  static {
    __name(this, "LchThemeGeneratorStrategy");
  }
  // #region Fields
  static _LUMINANCE_THRESHOLD = 0.5;
  static _MIN_BACKGROUND_CONTRAST = 4.5;
  static _MIN_LOWLIGHT_CONTRAST = 4.5;
  static _MIN_MIDDLELIGHT_CONTRAST = 3;
  static _DARK_BACKGROUND_LIGHTNESS = 7;
  static _DARK_BACKGROUND_MAX_CHROMA = 10;
  static _LIGHT_BACKGROUND_LIGHTNESS = 97;
  static _LIGHT_BACKGROUND_MAX_CHROMA = 4;
  // #endregion
  // #region Methods
  /**
   * Determines whether a color naturally belongs to the given mode's luminance range.
   *
   * @remarks
   * Uses WCAG relative luminance (0 = black, 1 = white).
   * A color with luminance > 0.5 is considered "light"; ≤ 0.5 is considered "dark".
   *
   * @public
   * @param color - The color to check
   * @param mode - The target color mode ('dark' | 'light')
   * @returns `true` if the color is naturally compatible with the given mode
   */
  isColorInModeSpectrum(color, mode) {
    const luminance = chroma7__default.default(color).luminance();
    return mode === "light" ? luminance > _LchThemeGeneratorStrategy._LUMINANCE_THRESHOLD : luminance <= _LchThemeGeneratorStrategy._LUMINANCE_THRESHOLD;
  }
  /**
   * Adapts a color to the opposite mode by symmetrically inverting its perceptual
   * lightness in the LCH color space (`L* → 100 - L*`) while preserving hue and chroma.
   *
   * @remarks
   * The inversion is symmetric: a light color becomes dark and vice-versa, regardless
   * of the direction. Therefore no target mode parameter is required.
   *
   * The inverted lightness is clamped to [5, 95] to avoid pure black / pure white,
   * which cannot carry chromatic information.
   * Subclasses may override this method to apply theme-specific post-processing
   * (e.g., chroma reduction for muted palettes).
   *
   * @public
   * @param color - The color to adapt
   * @returns The adapted color with inverted lightness
   */
  adaptColorToMode(color) {
    const c = chroma7__default.default(color);
    const [l, chromaVal, h] = c.lch();
    const invertedL = Math.min(Math.max(100 - l, 5), 95);
    return chroma7__default.default.lch(invertedL, chromaVal, isNaN(h) ? 0 : h).hex();
  }
  /**
   * Generates a color palette from a base color for the given mode.
   *
   * @public
   * @param baseColor - The base/accent color
   * @param mode - 'light' or 'dark' mode
   * @returns The generated theme palette with shade steps 0–900
   */
  generatePalette(baseColor, mode) {
    if (mode === "light") {
      const baseLight2 = chroma7__default.default("#ffffff");
      const baseDark2 = chroma7__default.default("#000000");
      const palette2 = {};
      const steps2 = [
        0,
        50,
        100,
        200,
        300,
        400,
        500,
        600,
        700,
        800,
        900
      ];
      const amounts2 = [
        0,
        12,
        30,
        50,
        70,
        85,
        100,
        87,
        70,
        54,
        25
      ];
      steps2.forEach((step, i) => {
        const base = step <= 500 ? baseLight2 : baseDark2;
        palette2[`${step}`] = chroma7__default.default.mix(base, baseColor, amounts2[i] / 100, "rgb").hex();
      });
      return {
        "0": palette2["0"],
        "50": palette2["50"],
        "100": palette2["100"],
        "200": palette2["200"],
        "300": palette2["300"],
        "400": palette2["400"],
        "500": palette2["500"],
        "600": palette2["600"],
        "700": palette2["700"],
        "800": palette2["800"],
        "900": palette2["900"]
      };
    }
    const baseLight = chroma7__default.default("#ffffff");
    const baseDark = chroma7__default.default("#000000");
    const palette = {};
    const steps = [
      0,
      50,
      100,
      200,
      300,
      400,
      500,
      600,
      700,
      800,
      900
    ];
    const amounts = [
      0,
      15,
      30,
      45,
      60,
      75,
      90,
      100,
      70,
      54,
      25
    ];
    steps.forEach((step, i) => {
      const base = step <= 600 ? baseDark : baseLight;
      palette[`${step}`] = chroma7__default.default.mix(base, baseColor, amounts[i] / 100, "rgb").hex();
    });
    return {
      "0": palette["0"],
      "50": palette["50"],
      "100": palette["100"],
      "200": palette["200"],
      "300": palette["300"],
      "400": palette["400"],
      "500": palette["500"],
      "600": palette["600"],
      "700": palette["700"],
      "800": palette["800"],
      "900": palette["900"]
    };
  }
  /**
   * Generates a semantic color scheme based on a base color and mode.
   *
   * @remarks
   * The base color is the background of the scheme when it gives the foreground of the mode a contrast of at
   * least 4.5:1. Otherwise - a light base in dark mode, a dark base in light mode - the background is derived
   * from it: the same hue, a limited chroma and the lightness of the mode. Every other role follows the
   * background, except `contrast`: the text on the brand colors is the theme's own (see `generateContrast`),
   * because the brand fills do not change with the background.
   *
   * The lowlight keeps a contrast of at least 4.5:1 and the middlelight one of at least 3:1 on the background, and
   * the surface of a light scheme is never darker than its background.
   *
   * @public
   * @param baseColor - The base/accent color
   * @param mode - 'light' or 'dark' mode
   * @returns The generated theme scheme with semantic color roles
   */
  generateScheme(baseColor, mode) {
    const baseChroma = chroma7__default.default(baseColor);
    const adjustColor = /* @__PURE__ */ __name((color, amount, minLuminance = 0.02, maxLuminance = 0.98) => {
      const c = chroma7__default.default(color);
      const factor = Math.abs(amount) / 25.5;
      let result = amount > 0 ? c.brighten(factor) : c.darken(factor);
      const resultLuminance = result.luminance();
      if (resultLuminance < minLuminance) {
        result = chroma7__default.default(result).luminance(minLuminance);
      } else if (resultLuminance > maxLuminance) {
        result = chroma7__default.default(result).luminance(maxLuminance);
      }
      return result.hex();
    }, "adjustColor");
    const generateForeground = /* @__PURE__ */ __name(() => {
      if (mode === "light") {
        const darkened = baseChroma.darken(4).saturate(-0.3);
        const targetLuminance2 = Math.min(darkened.luminance(), 0.08);
        return chroma7__default.default(darkened).luminance(targetLuminance2).hex();
      }
      const lightened = baseChroma.brighten(4).saturate(-0.3);
      const targetLuminance = Math.max(lightened.luminance(), 0.85);
      return chroma7__default.default(lightened).luminance(targetLuminance).hex();
    }, "generateForeground");
    const foreground = generateForeground();
    const background = this.generateBackground(baseColor, mode, foreground);
    const backgroundLuminance = chroma7__default.default(background).luminance();
    const generateSurface = /* @__PURE__ */ __name(() => {
      if (mode === "light") {
        return adjustColor(background, 8, 0.02, Math.max(0.98, backgroundLuminance));
      }
      return adjustColor(background, 15);
    }, "generateSurface");
    const generateHighlight = /* @__PURE__ */ __name(() => mode === "light" ? adjustColor(background, -15, 0.05, 0.95) : adjustColor(background, 20, 0.05, 0.95), "generateHighlight");
    const generateMiddlelight = /* @__PURE__ */ __name(() => this.ensureContrast(mode === "light" ? adjustColor(background, -30, 0.1, 0.9) : adjustColor(background, 35, 0.1, 0.9), background, mode, _LchThemeGeneratorStrategy._MIN_MIDDLELIGHT_CONTRAST), "generateMiddlelight");
    const generateLowlight = /* @__PURE__ */ __name(() => this.ensureContrast(mode === "light" ? adjustColor(background, -50, 0.15, 0.85) : adjustColor(background, 55, 0.15, 0.85), background, mode, _LchThemeGeneratorStrategy._MIN_LOWLIGHT_CONTRAST), "generateLowlight");
    const generateDisabled = /* @__PURE__ */ __name(() => {
      const desaturated = chroma7__default.default(background).desaturate(2);
      return mode === "light" ? chroma7__default.default(desaturated).darken(0.5).hex() : chroma7__default.default(desaturated).brighten(0.5).hex();
    }, "generateDisabled");
    return {
      surface: generateSurface(),
      background,
      foreground,
      highlight: generateHighlight(),
      middlelight: generateMiddlelight(),
      lowlight: generateLowlight(),
      transparent: chroma7__default.default(background).alpha(0).hex(),
      semiTransparent: chroma7__default.default(background).alpha(0.67).hex(),
      disabled: generateDisabled(),
      contrast: this.generateContrast(mode),
      selection: generateHighlight()
    };
  }
  /**
   * Returns the text color on the brand colors (`contrast`) of the theme for a mode. It belongs to the brand fills
   * (`primary` and the other variants), not to the background, so a generated scheme keeps it.
   * Defaults to white in light mode and black in dark mode, the contrast of the Joy reference theme; a theme with
   * other brand fills overrides it.
   *
   * @protected
   * @param mode - 'light' or 'dark' mode
   * @returns The contrast color of the mode
   */
  generateContrast(mode) {
    return mode === "light" ? "#ffffff" : "#000000";
  }
  /**
   * Returns the color itself when it reaches the minimum contrast on the background, otherwise the same color moved
   * away from the background (darker in light mode, lighter in dark mode) until it does.
   *
   * @private
   * @param color - The color of the role
   * @param background - The background of the scheme
   * @param mode - 'light' or 'dark' mode
   * @param minimum - The minimum contrast ratio
   * @returns The color with at least the minimum contrast on the background
   */
  ensureContrast(color, background, mode, minimum) {
    if (chroma7__default.default.contrast(color, background) >= minimum) {
      return color;
    }
    const backgroundLuminance = chroma7__default.default(background).luminance();
    let target = mode === "light" ? (backgroundLuminance + 0.05) / minimum - 0.05 : minimum * (backgroundLuminance + 0.05) - 0.05;
    let result = color;
    for (let attempt = 0; attempt < 20 && chroma7__default.default.contrast(result, background) < minimum; attempt++) {
      target = Math.min(Math.max(target, 0), 1);
      result = chroma7__default.default(color).luminance(target).hex();
      target += mode === "light" ? -2e-3 : 2e-3;
    }
    return result;
  }
  /**
   * Returns the background of a scheme: the base color when the foreground reaches a contrast of 4.5:1 on it,
   * otherwise a color of the same hue with a limited chroma at the lightness of the mode - a near-black tint
   * in dark mode, a near-white tint in light mode.
   *
   * @private
   * @param baseColor - The base color of the scheme
   * @param mode - 'light' or 'dark' mode
   * @param foreground - The foreground of the scheme
   * @returns The background color
   */
  generateBackground(baseColor, mode, foreground) {
    if (chroma7__default.default.contrast(baseColor, foreground) >= _LchThemeGeneratorStrategy._MIN_BACKGROUND_CONTRAST) {
      return baseColor;
    }
    const [, chromaVal, h] = chroma7__default.default(baseColor).lch();
    const hue = isNaN(h) ? 0 : h;
    if (mode === "dark") {
      const darkChroma = Math.min(chromaVal, _LchThemeGeneratorStrategy._DARK_BACKGROUND_MAX_CHROMA);
      return chroma7__default.default.lch(_LchThemeGeneratorStrategy._DARK_BACKGROUND_LIGHTNESS, darkChroma, hue).hex();
    }
    const lightChroma = Math.min(chromaVal, _LchThemeGeneratorStrategy._LIGHT_BACKGROUND_MAX_CHROMA);
    return chroma7__default.default.lch(_LchThemeGeneratorStrategy._LIGHT_BACKGROUND_LIGHTNESS, lightChroma, hue).hex();
  }
};
var CosmopolitanThemeGeneratorStrategy = class _CosmopolitanThemeGeneratorStrategy extends LchThemeGeneratorStrategy {
  static {
    __name(this, "CosmopolitanThemeGeneratorStrategy");
  }
  // #region Fields
  static _CHROMA_REDUCTION_FACTOR = 0.9;
  // #endregion
  // #region Methods
  /**
   * Adapts a color to the target mode by inverting its perceptual lightness (LCH L*)
   * with a slight chroma reduction for the Cosmopolitan's muted aesthetic.
   *
   * @override
   * @public
   * @param color - The color to adapt
   * @returns The adapted color with inverted lightness and reduced chroma
   */
  adaptColorToMode(color) {
    const c = chroma7__default.default(color);
    const [l, chromaVal, h] = c.lch();
    const invertedL = Math.min(Math.max(100 - l, 5), 95);
    const reducedChroma = chromaVal * _CosmopolitanThemeGeneratorStrategy._CHROMA_REDUCTION_FACTOR;
    return chroma7__default.default.lch(invertedL, reducedChroma, isNaN(h) ? 0 : h).hex();
  }
  /**
   * Returns the text color on the brand colors of the Cosmopolitan theme, which a generated scheme keeps.
   *
   * @override
   * @protected
   * @param mode - 'light' or 'dark' mode
   * @returns The contrast color of the mode
   */
  generateContrast(mode) {
    return mode === "light" ? SCHEME_LIGHT_CONTRAST : SCHEME_DARK_CONTRAST;
  }
};
function createCosmopolitanTheme() {
  const strategy = new CosmopolitanThemeGeneratorStrategy();
  return () => strategy;
}
__name(createCosmopolitanTheme, "createCosmopolitanTheme");

// src/theming/strategies/surface/JoyThemeGeneratorStrategy.ts
var JoyThemeGeneratorStrategy = class extends LchThemeGeneratorStrategy {
  static {
    __name(this, "JoyThemeGeneratorStrategy");
  }
  // #region Methods
  /**
   * Returns the text color on the brand colors of the Joy theme, which a generated scheme keeps.
   *
   * @override
   * @protected
   * @param mode - 'light' or 'dark' mode
   * @returns The contrast color of the mode
   */
  generateContrast(mode) {
    return mode === "light" ? SCHEME_LIGHT_CONTRAST2 : SCHEME_DARK_CONTRAST2;
  }
};
function createJoyTheme() {
  const strategy = new JoyThemeGeneratorStrategy();
  return () => strategy;
}
__name(createJoyTheme, "createJoyTheme");

// src/theming/strategies/surface/MemphisThemeGeneratorStrategy.ts
var MemphisThemeGeneratorStrategy = class extends LchThemeGeneratorStrategy {
  static {
    __name(this, "MemphisThemeGeneratorStrategy");
  }
  // #region Methods
  /**
   * Returns the text color on the brand colors of the Memphis theme, which a generated scheme keeps.
   *
   * @override
   * @protected
   * @param mode - 'light' or 'dark' mode
   * @returns The contrast color of the mode
   */
  generateContrast(mode) {
    return mode === "light" ? SCHEME_LIGHT_CONTRAST3 : SCHEME_DARK_CONTRAST3;
  }
};
function createMemphisTheme() {
  const strategy = new MemphisThemeGeneratorStrategy();
  return () => strategy;
}
__name(createMemphisTheme, "createMemphisTheme");

// src/theming/strategies/surface/SohoThemeGeneratorStrategy.ts
var SohoThemeGeneratorStrategy = class extends LchThemeGeneratorStrategy {
  static {
    __name(this, "SohoThemeGeneratorStrategy");
  }
  // #region Methods
  /**
   * Returns the text color on the brand colors of the Soho theme, which a generated scheme keeps.
   *
   * @override
   * @protected
   * @param mode - 'light' or 'dark' mode
   * @returns The contrast color of the mode
   */
  generateContrast(mode) {
    return mode === "light" ? SCHEME_LIGHT_CONTRAST4 : SCHEME_DARK_CONTRAST4;
  }
};
function createSohoTheme() {
  const strategy = new SohoThemeGeneratorStrategy();
  return () => strategy;
}
__name(createSohoTheme, "createSohoTheme");

// src/theming/ThemeGenerator.ts
var ThemeGenerator = class {
  static {
    __name(this, "ThemeGenerator");
  }
  // #region Fields
  _strategies;
  _platformAdapter;
  // #endregion
  // #region Ctor
  /**
   * @public
   * @param platformAdapter - Optional platform adapter. Auto-detects if not provided.
   */
  constructor(platformAdapter) {
    this._strategies = /* @__PURE__ */ new Map([
      [
        "joy",
        new JoyThemeGeneratorStrategy()
      ],
      [
        "memphis",
        new MemphisThemeGeneratorStrategy()
      ],
      [
        "cosmopolitan",
        new CosmopolitanThemeGeneratorStrategy()
      ],
      [
        "soho",
        new SohoThemeGeneratorStrategy()
      ]
    ]);
    this._platformAdapter = platformAdapter ?? PlatformAdapterFactory.create();
  }
  // #endregion
  // #region Methods
  /**
   * Generates a complete theme palette (shades 0–900) for the given theme.
   *
   * @remarks
   * 1. If `mode` is `'system'`, it is resolved to `'dark'` or `'light'` via the
   *    platform adapter's `prefers-color-scheme` media query.
   * 2. The base color is forwarded as-is to the theme-specific strategy which
   *    produces 11 shade steps from lightest (0) to darkest (900).
   *
   * No automatic color adaptation is performed. Callers who need mode-compatible
   * colors can use {@link IThemeGeneratorStrategy.isColorInModeSpectrum} and
   * {@link IThemeGeneratorStrategy.adaptColorToMode} explicitly before calling
   * this method.
   *
   * @public
   * @param themeName - The name of the theme (`'joy'`, `'memphis'`, `'cosmopolitan'`, `'soho'`).
   * @param baseColor - The base accent color (any valid CSS color value).
   * @param mode - The target mode (`'dark'`, `'light'`, or `'system'`).
   * @returns A fully populated palette with shade keys `0`–`900`.
   * @throws Error if `themeName` is not a registered theme.
   */
  generatePalette(themeName, baseColor, mode) {
    const resolvedMode = this.resolveMode(mode);
    const strategy = this.getStrategy(themeName);
    return strategy.generatePalette(baseColor, resolvedMode);
  }
  /**
   * Generates a semantic color scheme (surface, foreground, highlight, …) for the given theme.
   *
   * @remarks
   * 1. If `mode` is `'system'`, it is resolved to `'dark'` or `'light'` via the
   *    platform adapter's `prefers-color-scheme` media query.
   * 2. The base color is forwarded to the theme-specific strategy which
   *    maps it to semantic roles such as `surface`, `foreground`, `highlight`,
   *    `contrast`, `disabled`, etc.
   * 3. The base color becomes the background when the foreground of the mode reaches
   *    a contrast of at least 4.5:1 on it. A base that does not suit the mode - a light
   *    base in dark mode, a dark base in light mode - yields a background of the same
   *    hue at the lightness of the mode, and every other role follows that background.
   * 4. `contrast`, the text on the brand colors, stays the theme's own for the mode; the
   *    lowlight reaches at least 4.5:1 and the middlelight at least 3:1 on the background,
   *    and a light surface is never darker than its background.
   *
   * @public
   * @param themeName - The name of the theme (`'joy'`, `'memphis'`, `'cosmopolitan'`, `'soho'`).
   * @param baseColor - The base background color (any valid CSS color value).
   * @param mode - The target mode (`'dark'`, `'light'`, or `'system'`).
   * @returns A fully populated scheme with all semantic color roles.
   * @throws Error if `themeName` is not a registered theme.
   */
  generateScheme(themeName, baseColor, mode) {
    const resolvedMode = this.resolveMode(mode);
    const strategy = this.getStrategy(themeName);
    return strategy.generateScheme(baseColor, resolvedMode);
  }
  /**
   * Resolves the theme mode, converting 'system' to 'dark' or 'light' based on platform settings.
   *
   * @private
   * @param mode The theme mode to resolve.
   * @returns The resolved theme mode.
   */
  resolveMode(mode) {
    if (mode === "system") {
      const isDark = this._platformAdapter.matchMedia("(prefers-color-scheme: dark)");
      return isDark ? "dark" : "light";
    }
    return mode;
  }
  /**
   * Gets the theme generator strategy for the specified theme name.
   *
   * @private
   * @param themeName The name of the theme ('joy', 'memphis', 'cosmopolitan', 'soho').
   * @returns The theme generator strategy.
   */
  getStrategy(themeName) {
    const strategy = this._strategies.get(themeName);
    if (!strategy) {
      throw new Error(`Theme '${themeName}' is not supported.`);
    }
    return strategy;
  }
};
var ThemeGeneratorServiceLocator = class _ThemeGeneratorServiceLocator {
  static {
    __name(this, "ThemeGeneratorServiceLocator");
  }
  // #region Fields
  static _current = null;
  // #endregion
  // #region Properties
  static get current() {
    if (!_ThemeGeneratorServiceLocator.isSet()) {
      throw new Error("'ThemeGenerator' not set.");
    }
    return _ThemeGeneratorServiceLocator._current;
  }
  // #endregion
  // #region Methods
  static isSet() {
    return _ThemeGeneratorServiceLocator._current !== null;
  }
  static set(current) {
    _ThemeGeneratorServiceLocator._current = current;
  }
};
ThemeGeneratorServiceLocator.set(new ThemeGenerator());
function isThemeMode(value) {
  return value === "dark" || value === "light";
}
__name(isThemeMode, "isThemeMode");
var ThemeObserver = class {
  static {
    __name(this, "ThemeObserver");
  }
  // #region Fields
  _themeChanged;
  _themeModeChanged;
  _platformAdapter;
  _currentTheme;
  _currentThemeMode;
  _unsubscribe;
  // #region Ctor
  /**
   * Constructs a new instance of the `ThemeObserver` class.
   *
   * @param platformAdapter - Optional platform adapter. Auto-detects if not provided.
   * @public
   */
  constructor(platformAdapter) {
    this._themeChanged = new mosaikElements.PureEventEmitter();
    this._themeModeChanged = new mosaikElements.PureEventEmitter();
    this._platformAdapter = platformAdapter ?? PlatformAdapterFactory.create();
    this._currentTheme = null;
    this._currentThemeMode = null;
    this.observe({
      themeChange: /* @__PURE__ */ __name((theme) => this._themeChanged.emit(theme), "themeChange"),
      themeModeChange: /* @__PURE__ */ __name((themeMode) => this._themeModeChanged.emit(themeMode), "themeModeChange")
    });
  }
  // #endregion
  // #region Properties
  /**
   * Fires when the theme changes.
   *
   * @public
   * @readonly
   */
  get themeChanged() {
    return this._themeChanged;
  }
  /**
   * Fires when the theme mode changes.
   *
   * @public
   * @readonly
   */
  get themeModeChanged() {
    return this._themeModeChanged;
  }
  // #endregion
  // #region Methods
  /**
   * Applies the given theme and theme mode to the document.
   *
   * @public
   * @param theme - The theme to apply (joy, cosmopolitan, memphis or soho).
   * @param themeMode - The theme mode to apply.
   */
  applyTheme(theme, themeMode) {
    this._platformAdapter.setDocumentAttribute("theme", theme);
    switch (themeMode) {
      case "dark":
      case "light":
        this._platformAdapter.setDocumentAttribute("theme-mode", themeMode);
        break;
      case "system":
      default: {
        const isDark = this._platformAdapter.matchMedia("(prefers-color-scheme: dark)");
        this._platformAdapter.setDocumentAttribute("theme-mode", isDark ? "dark" : "light");
        break;
      }
    }
  }
  /**
   * Stops observing document attribute changes and releases the underlying listener.
   *
   * @remarks
   * Safe to call multiple times — subsequent calls are no-ops.
   *
   * @public
   */
  dispose() {
    if (this._unsubscribe) {
      this._unsubscribe();
      this._unsubscribe = void 0;
    }
  }
  observe(cb) {
    this._currentTheme = this._platformAdapter.getDocumentAttribute("theme");
    this._currentThemeMode = this._platformAdapter.getDocumentAttribute("theme-mode");
    this._unsubscribe = this._platformAdapter.observeDocumentAttributes([
      "theme",
      "theme-mode"
    ], (attributeName, newValue) => {
      if (attributeName === "theme" && newValue) {
        const theme = newValue;
        if (this._currentTheme !== theme) {
          this._currentTheme = theme;
          cb.themeChange(theme);
        }
      }
      if (attributeName === "theme-mode") {
        if (newValue === null) {
          this._currentThemeMode = null;
          return;
        }
        if (!isThemeMode(newValue)) {
          throw new Error(`Invalid theme mode: ${newValue}`);
        }
        if (this._currentThemeMode !== newValue) {
          this._currentThemeMode = newValue;
          cb.themeModeChange(newValue);
        }
      }
    });
  }
};
var ThemeObserverServiceLocator = class _ThemeObserverServiceLocator {
  static {
    __name(this, "ThemeObserverServiceLocator");
  }
  // #region Fields
  static _current = null;
  // #endregion
  // #region Properties
  static get current() {
    if (!_ThemeObserverServiceLocator.isSet()) {
      throw new Error("'ThemeObserver' not set.");
    }
    return _ThemeObserverServiceLocator._current;
  }
  // #endregion
  // #region Methods
  static isSet() {
    return _ThemeObserverServiceLocator._current !== null;
  }
  static set(current) {
    _ThemeObserverServiceLocator._current = current;
  }
};
ThemeObserverServiceLocator.set(new ThemeObserver());

// src/theming/utils/CssAspectRatio.ts
(function(CssAspectRatio2) {
  function isCssAspectRatio(value) {
    if (typeof value === "string") {
      if (value.trim() === "") {
        return false;
      }
      if (value === "auto") {
        return true;
      }
      const ratioParts = value.split("/");
      if (ratioParts.length === 1) {
        return !isNaN(Number(ratioParts[0])) && Number(ratioParts[0]) >= 0;
      }
      if (ratioParts.length === 2) {
        return !isNaN(Number(ratioParts[0])) && Number(ratioParts[0]) >= 0 && !isNaN(Number(ratioParts[1])) && Number(ratioParts[1]) >= 0;
      }
    }
    return false;
  }
  __name(isCssAspectRatio, "isCssAspectRatio");
  CssAspectRatio2.isCssAspectRatio = isCssAspectRatio;
})(exports.CssAspectRatio || (exports.CssAspectRatio = {}));
exports.CssAspectRatio = void 0;

// src/theming/utils/CssColor.ts
(function(CssColor2) {
  function isCssColor(value) {
    if (typeof value !== "string") {
      return false;
    }
    if (value.trim() === "") {
      return false;
    }
    const rgbRegex = /^rgb\(\d{1,3},\s*\d{1,3},\s*\d{1,3}\)$/;
    const rgbaRegex = /^rgba\(\d{1,3},\s*\d{1,3},\s*\d{1,3},\s*(0(\.\d+)?|1(\.0+)?)\)$/;
    const hexRegex = /^#[0-9a-fA-F]{3,6}$/;
    return rgbRegex.test(value) || rgbaRegex.test(value) || hexRegex.test(value);
  }
  __name(isCssColor, "isCssColor");
  CssColor2.isCssColor = isCssColor;
})(exports.CssColor || (exports.CssColor = {}));
exports.CssColor = void 0;

// src/theming/utils/CssLength.ts
(function(CssLength2) {
  function isCssLength(value) {
    if (typeof value === "number" || value === "auto") {
      return true;
    }
    if (typeof value !== "string") {
      return false;
    }
    if (value.trim() === "") {
      return false;
    }
    const lengthRegex = /^-?\d+(\.\d+)?(em|ex|ch|rem|vh|vw|vmin|vmax|svw|svh|dvw|dvh|lvw|lvh|px|mm|cm|in|pt|pc|mozmm|%)/;
    return lengthRegex.test(value);
  }
  __name(isCssLength, "isCssLength");
  CssLength2.isCssLength = isCssLength;
  function isAuto(value) {
    return value === "auto";
  }
  __name(isAuto, "isAuto");
  CssLength2.isAuto = isAuto;
  function isPercentage(value) {
    if (typeof value !== "string") {
      return false;
    }
    if (value.trim() === "") {
      return false;
    }
    const percentageRegex = /^-?\d+(\.\d+)?%/;
    return percentageRegex.test(value);
  }
  __name(isPercentage, "isPercentage");
  CssLength2.isPercentage = isPercentage;
  function isLength(value) {
    if (typeof value !== "string") {
      return false;
    }
    if (value.trim() === "") {
      return false;
    }
    const lengthRegex = /^-?\d+(\.\d+)?(em|ex|ch|rem|vh|vw|vmin|vmax|svw|svh|dvw|dvh|lvw|lvh|px|mm|cm|in|pt|pc|mozmm)/;
    return lengthRegex.test(value);
  }
  __name(isLength, "isLength");
  CssLength2.isLength = isLength;
  function toNumber(value) {
    if (typeof value === "number") {
      return value;
    }
    if (value === "auto") {
      throw new Error('Cannot convert "auto" to a number.');
    }
    const match = /^-?\d*\.?\d+/.exec(value);
    if (!match) {
      throw new Error(`Invalid CSS length: ${value}`);
    }
    return parseFloat(match[0]);
  }
  __name(toNumber, "toNumber");
  CssLength2.toNumber = toNumber;
  function toString(value, defaultUnit = "px") {
    if (value === void 0 || value === null) {
      return "";
    }
    if (typeof value === "number") {
      return `${value}${defaultUnit}`;
    }
    return value;
  }
  __name(toString, "toString");
  CssLength2.toString = toString;
  function extractUnit(cssLength) {
    const match = /[a-z%]+$/i.exec(cssLength);
    const lengt = match ? match[0] : null;
    if (lengt === null) {
      throw new Error(`Invalid value: ${cssLength}`);
    }
    return lengt;
  }
  __name(extractUnit, "extractUnit");
  CssLength2.extractUnit = extractUnit;
  function extractValue(cssLength) {
    const match = /^-?\d*\.?\d+/.exec(cssLength);
    const value = match ? parseFloat(match[0]) : null;
    if (value === null) {
      throw new Error(`Invalid value: ${cssLength}`);
    }
    return value;
  }
  __name(extractValue, "extractValue");
  CssLength2.extractValue = extractValue;
  function pxToRem(pixel) {
    const value = extractValue(pixel);
    const baseSize = 16;
    const sizeInRem = `${value / baseSize}rem`;
    return sizeInRem;
  }
  __name(pxToRem, "pxToRem");
  CssLength2.pxToRem = pxToRem;
  function tryParse(value, defaultUnit = "px") {
    if (value === void 0 || value === null) {
      return void 0;
    }
    if (typeof value === "string") {
      if (isLength(value)) {
        return value;
      }
      if (value.trim() === "") {
        return void 0;
      }
      const num = parseFloat(value);
      return isNaN(num) ? void 0 : `${num}${defaultUnit}`;
    }
    if (typeof value === "number") {
      return `${String(value)}${defaultUnit}`;
    }
    return void 0;
  }
  __name(tryParse, "tryParse");
  CssLength2.tryParse = tryParse;
})(exports.CssLength || (exports.CssLength = {}));
exports.CssLength = void 0;

// src/theming/utils/CssShadow.ts
(function(CssShadow2) {
  function isCssShadow(value) {
    if (typeof value !== "string") {
      return false;
    }
    if (value.trim() === "") {
      return false;
    }
    if (value === "none") {
      return true;
    }
    const shadows = value.split(/\s*,\s*/);
    return shadows.every(isCssShadowSingle);
  }
  __name(isCssShadow, "isCssShadow");
  CssShadow2.isCssShadow = isCssShadow;
  function isCssShadowSingle(value) {
    const shadowRegex = new RegExp("^(inset\\s+)?(-?\\d+(\\.\\d+)?(px|em|rem|vh|vw|%)?)\\s+(-?\\d+(\\.\\d+)?(px|em|rem|vh|vw|%)?)\\s+(-?\\d+(\\.\\d+)?(px|em|rem|vh|vw|%)?)?\\s*(-?\\d+(\\.\\d+)?(px|em|rem|vh|vw|%)?)?\\s*(rgba?\\(\\d{1,3},\\s*\\d{1,3},\\s*\\d{1,3}(,\\s*(0|1|0?\\.\\d+))?\\)|#[0-9a-fA-F]{3,6})$", "i");
    return shadowRegex.test(value);
  }
  __name(isCssShadowSingle, "isCssShadowSingle");
})(exports.CssShadow || (exports.CssShadow = {}));
exports.CssShadow = void 0;

// src/theming/utils/CssTime.ts
(function(CssTime2) {
  function isCssTime(value) {
    if (typeof value === "number" || value === 0) {
      return true;
    }
    if (typeof value !== "string") {
      return false;
    }
    if (value.trim() === "") {
      return false;
    }
    const timeRegex = /^-?\d+(\.\d+)?(s|ms)/;
    return timeRegex.test(value);
  }
  __name(isCssTime, "isCssTime");
  CssTime2.isCssTime = isCssTime;
})(exports.CssTime || (exports.CssTime = {}));
exports.CssTime = void 0;

// src/theming/utils/ThemePalette.ts
(function(ThemePalette2) {
  const THEME_SHADE_NAMES = [
    "0",
    "50",
    "100",
    "200",
    "300",
    "400",
    "500",
    "600",
    "700",
    "800",
    "900"
  ];
  function isThemeShadeName(value) {
    return THEME_SHADE_NAMES.includes(value);
  }
  __name(isThemeShadeName, "isThemeShadeName");
  function isThemePalette(value) {
    if (typeof value !== "object" || value === null) {
      return false;
    }
    return Object.keys(value).every((key) => isThemeShadeName(key) && typeof value[key] === "string");
  }
  __name(isThemePalette, "isThemePalette");
  ThemePalette2.isThemePalette = isThemePalette;
})(exports.ThemePalette || (exports.ThemePalette = {}));
exports.ThemePalette = void 0;

// src/theming/utils/ITheme.ts
(function(ITheme2) {
  function getScheme(theme, mode) {
    return theme.scheme[mode];
  }
  __name(getScheme, "getScheme");
  ITheme2.getScheme = getScheme;
  function getPalette(theme, mode, semanticColor) {
    const paletteEntry = theme.palette[mode][semanticColor];
    if (!exports.ThemePalette.isThemePalette(paletteEntry)) {
      throw new Error(`Palette '${semanticColor}' is not a valid theme palette for mode '${mode}'.`);
    }
    return paletteEntry;
  }
  __name(getPalette, "getPalette");
  ITheme2.getPalette = getPalette;
  function getSchemeColor(theme, mode, role) {
    const scheme = theme.scheme[mode];
    const color = scheme[role];
    if (typeof color !== "string") {
      throw new Error(`Scheme color '${role}' is not defined for mode '${mode}'.`);
    }
    return color;
  }
  __name(getSchemeColor, "getSchemeColor");
  ITheme2.getSchemeColor = getSchemeColor;
  function getPaletteColor(theme, mode, semanticColor, shade) {
    const palette = getPalette(theme, mode, semanticColor);
    const color = palette[shade];
    if (typeof color !== "string") {
      throw new Error(`Shade '${shade}' is not defined in palette '${semanticColor}' for mode '${mode}'.`);
    }
    return color;
  }
  __name(getPaletteColor, "getPaletteColor");
  ITheme2.getPaletteColor = getPaletteColor;
  function getElevationShadow(theme, mode, key) {
    return theme.elevation[mode][key];
  }
  __name(getElevationShadow, "getElevationShadow");
  ITheme2.getElevationShadow = getElevationShadow;
})(exports.ITheme || (exports.ITheme = {}));
exports.ITheme = void 0;

// src/theming/utils/ThemeMode.ts
var THEME_MODES = [
  "dark",
  "light"
];

// src/theming/utils/ThemeScheme.ts
(function(ThemeScheme2) {
  const ROLES = [
    "surface",
    "background",
    "foreground",
    "highlight",
    "middlelight",
    "lowlight",
    "transparent",
    "semiTransparent",
    "disabled",
    "contrast",
    "selection"
  ];
  function isRole(value) {
    return ROLES.includes(value);
  }
  __name(isRole, "isRole");
  function isThemeScheme(value) {
    if (typeof value !== "object" || value === null) {
      return false;
    }
    return Object.entries(value).every(([key, color]) => isRole(key) && typeof color === "string");
  }
  __name(isThemeScheme, "isThemeScheme");
  ThemeScheme2.isThemeScheme = isThemeScheme;
})(exports.ThemeScheme || (exports.ThemeScheme = {}));
exports.ThemeScheme = void 0;

exports.BrowserPlatformAdapter = BrowserPlatformAdapter;
exports.CosmopolitanThemeGeneratorStrategy = CosmopolitanThemeGeneratorStrategy;
exports.HslThemeGeneratorStrategy = HslThemeGeneratorStrategy;
exports.JoyThemeGeneratorStrategy = JoyThemeGeneratorStrategy;
exports.LchThemeGeneratorStrategy = LchThemeGeneratorStrategy;
exports.MemphisThemeGeneratorStrategy = MemphisThemeGeneratorStrategy;
exports.NodePlatformAdapter = NodePlatformAdapter;
exports.PlatformAdapterFactory = PlatformAdapterFactory;
exports.SohoThemeGeneratorStrategy = SohoThemeGeneratorStrategy;
exports.THEME_MODES = THEME_MODES;
exports.ThemeGenerator = ThemeGenerator;
exports.ThemeGeneratorServiceLocator = ThemeGeneratorServiceLocator;
exports.ThemeObserver = ThemeObserver;
exports.ThemeObserverServiceLocator = ThemeObserverServiceLocator;
exports.createCosmopolitanTheme = createCosmopolitanTheme;
exports.createJoyTheme = createJoyTheme;
exports.createMemphisTheme = createMemphisTheme;
exports.createSohoTheme = createSohoTheme;
//# sourceMappingURL=index.cjs.map
//# sourceMappingURL=index.cjs.map