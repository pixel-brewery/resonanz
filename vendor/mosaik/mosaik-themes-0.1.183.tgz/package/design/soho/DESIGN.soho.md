---
version: 'alpha'
name: 'Mosaik Soho'
description: 'Light-mode value snapshot of the Soho theme, the visual references of shadcn/ui (style Vega, Neutral) in the Mosaik architecture: Inter, a 10px radius scale, 1px borders and hairline rings, neutral fills and the 3px focus ring. Consume the --mosaik-* custom properties, never these literals.'
colors:
  primary: '{colors.mosaik-color-primary-500}'
  mosaik-scheme-surface: '#ffffff'
  mosaik-scheme-background: '#ffffff'
  mosaik-scheme-foreground: '#0a0a0a'
  mosaik-scheme-highlight: '#e5e5e5'
  mosaik-scheme-middlelight: '#737373'
  mosaik-scheme-lowlight: '#525252'
  mosaik-scheme-transparent: 'rgba(255, 255, 255, 0)'
  mosaik-scheme-semi-transparent: 'rgba(0, 0, 0, 0.5019607843137255)'
  mosaik-scheme-disabled: '#a1a1a1'
  mosaik-scheme-contrast: '#fafafa'
  mosaik-scheme-selection: '#d4d4d4'
  mosaik-color-primary-0: '#fafafa'
  mosaik-color-primary-50: '#fafafa'
  mosaik-color-primary-100: '#f5f5f5'
  mosaik-color-primary-200: '#e5e5e5'
  mosaik-color-primary-300: '#d4d4d4'
  mosaik-color-primary-400: '#737373'
  mosaik-color-primary-500: '#171717'
  mosaik-color-primary-600: '#171717'
  mosaik-color-primary-700: '#0a0a0a'
  mosaik-color-primary-800: '#050505'
  mosaik-color-primary-900: '#000000'
  mosaik-color-secondary-0: '#ffffff'
  mosaik-color-secondary-50: '#f0fdfa'
  mosaik-color-secondary-100: '#cbfbf1'
  mosaik-color-secondary-200: '#96f7e4'
  mosaik-color-secondary-300: '#46ecd5'
  mosaik-color-secondary-400: '#009689'
  mosaik-color-secondary-500: '#00786f'
  mosaik-color-secondary-600: '#005f5a'
  mosaik-color-secondary-700: '#0b4f4a'
  mosaik-color-secondary-800: '#0b4f4a'
  mosaik-color-secondary-900: '#022f2e'
  mosaik-color-tertiary-0: '#ffffff'
  mosaik-color-tertiary-50: '#fff7ed'
  mosaik-color-tertiary-100: '#ffedd4'
  mosaik-color-tertiary-200: '#ffd6a7'
  mosaik-color-tertiary-300: '#ffb86a'
  mosaik-color-tertiary-400: '#f54900'
  mosaik-color-tertiary-500: '#ca3500'
  mosaik-color-tertiary-600: '#9f2d00'
  mosaik-color-tertiary-700: '#7e2a0c'
  mosaik-color-tertiary-800: '#7e2a0c'
  mosaik-color-tertiary-900: '#441306'
  mosaik-color-info-0: '#ffffff'
  mosaik-color-info-50: '#eff6ff'
  mosaik-color-info-100: '#dbeafe'
  mosaik-color-info-200: '#bedbff'
  mosaik-color-info-300: '#8ec5ff'
  mosaik-color-info-400: '#2b7fff'
  mosaik-color-info-500: '#155dfc'
  mosaik-color-info-600: '#1447e6'
  mosaik-color-info-700: '#193cb8'
  mosaik-color-info-800: '#1c398e'
  mosaik-color-info-900: '#162456'
  mosaik-color-warning-0: '#ffffff'
  mosaik-color-warning-50: '#fffbeb'
  mosaik-color-warning-100: '#fef3c6'
  mosaik-color-warning-200: '#fee685'
  mosaik-color-warning-300: '#ffd230'
  mosaik-color-warning-400: '#e17100'
  mosaik-color-warning-500: '#bb4d00'
  mosaik-color-warning-600: '#973c00'
  mosaik-color-warning-700: '#7b3306'
  mosaik-color-warning-800: '#7b3306'
  mosaik-color-warning-900: '#461901'
  mosaik-color-danger-0: '#ffffff'
  mosaik-color-danger-50: '#fef2f2'
  mosaik-color-danger-100: '#ffe2e2'
  mosaik-color-danger-200: '#ffc9c9'
  mosaik-color-danger-300: '#ffa2a2'
  mosaik-color-danger-400: '#fb2c36'
  mosaik-color-danger-500: '#e7000b'
  mosaik-color-danger-600: '#e7000b'
  mosaik-color-danger-700: '#9f0712'
  mosaik-color-danger-800: '#82181a'
  mosaik-color-danger-900: '#460809'
  mosaik-color-success-0: '#ffffff'
  mosaik-color-success-50: '#f0fdf4'
  mosaik-color-success-100: '#dcfce7'
  mosaik-color-success-200: '#b9f8cf'
  mosaik-color-success-300: '#7bf1a8'
  mosaik-color-success-400: '#00a63e'
  mosaik-color-success-500: '#008236'
  mosaik-color-success-600: '#016630'
  mosaik-color-success-700: '#0d542b'
  mosaik-color-success-800: '#0d542b'
  mosaik-color-success-900: '#032e15'
  mosaik-color-highlight-0: '#ffffff'
  mosaik-color-highlight-50: '#f5f3ff'
  mosaik-color-highlight-100: '#ede9fe'
  mosaik-color-highlight-200: '#ddd6ff'
  mosaik-color-highlight-300: '#c4b4ff'
  mosaik-color-highlight-400: '#8e51ff'
  mosaik-color-highlight-500: '#7f22fe'
  mosaik-color-highlight-600: '#7008e7'
  mosaik-color-highlight-700: '#5d0ec0'
  mosaik-color-highlight-800: '#4d179a'
  mosaik-color-highlight-900: '#2f0d68'
  mosaik-color-neutral-0: '#ffffff'
  mosaik-color-neutral-50: '#fafafa'
  mosaik-color-neutral-100: '#f5f5f5'
  mosaik-color-neutral-200: '#e5e5e5'
  mosaik-color-neutral-300: '#d4d4d4'
  mosaik-color-neutral-400: '#a1a1a1'
  mosaik-color-neutral-500: '#737373'
  mosaik-color-neutral-600: '#525252'
  mosaik-color-neutral-700: '#404040'
  mosaik-color-neutral-800: '#262626'
  mosaik-color-neutral-900: '#171717'
typography:
  mosaik-typography-headline1:
    fontFamily: '''Inter'', ui-sans-serif, system-ui, sans-serif'
    fontSize: '48px'
    fontWeight: 700
    lineHeight: '48px'
    letterSpacing: '-1.2px'
  mosaik-typography-headline2:
    fontFamily: '''Inter'', ui-sans-serif, system-ui, sans-serif'
    fontSize: '36px'
    fontWeight: 800
    lineHeight: '40px'
    letterSpacing: '-0.9px'
  mosaik-typography-headline3:
    fontFamily: '''Inter'', ui-sans-serif, system-ui, sans-serif'
    fontSize: '30px'
    fontWeight: 600
    lineHeight: '36px'
    letterSpacing: '-0.75px'
  mosaik-typography-headline4:
    fontFamily: '''Inter'', ui-sans-serif, system-ui, sans-serif'
    fontSize: '24px'
    fontWeight: 600
    lineHeight: '32px'
    letterSpacing: '-0.6px'
  mosaik-typography-headline5:
    fontFamily: '''Inter'', ui-sans-serif, system-ui, sans-serif'
    fontSize: '20px'
    fontWeight: 600
    lineHeight: '28px'
    letterSpacing: '-0.5px'
  mosaik-typography-headline6:
    fontFamily: '''Inter'', ui-sans-serif, system-ui, sans-serif'
    fontSize: '18px'
    fontWeight: 600
    lineHeight: '28px'
  mosaik-typography-subtitle1:
    fontFamily: '''Inter'', ui-sans-serif, system-ui, sans-serif'
    fontSize: '16px'
    fontWeight: 500
    lineHeight: '24px'
  mosaik-typography-subtitle2:
    fontFamily: '''Inter'', ui-sans-serif, system-ui, sans-serif'
    fontSize: '14px'
    fontWeight: 500
    lineHeight: '20px'
  mosaik-typography-body1:
    fontFamily: '''Inter'', ui-sans-serif, system-ui, sans-serif'
    fontSize: '16px'
    fontWeight: 400
    lineHeight: '24px'
  mosaik-typography-body2:
    fontFamily: '''Inter'', ui-sans-serif, system-ui, sans-serif'
    fontSize: '14px'
    fontWeight: 400
    lineHeight: '20px'
  mosaik-typography-supporting:
    fontFamily: '''Inter'', ui-sans-serif, system-ui, sans-serif'
    fontSize: '14px'
    fontWeight: 400
    lineHeight: '20px'
  mosaik-typography-caption:
    fontFamily: '''Inter'', ui-sans-serif, system-ui, sans-serif'
    fontSize: '12px'
    fontWeight: 400
    lineHeight: '16px'
  mosaik-typography-overline:
    fontFamily: '''Inter'', ui-sans-serif, system-ui, sans-serif'
    fontSize: '12px'
    fontWeight: 500
    lineHeight: '16px'
  mosaik-typography-button:
    fontFamily: '''Inter'', ui-sans-serif, system-ui, sans-serif'
    fontSize: '14px'
    fontWeight: 500
    lineHeight: '20px'
rounded:
  mosaik-layout-radius: '10px'
spacing:
  mosaik-layout-space: '8px'
  mosaik-layout-thickness: '1px'
  mosaik-size-tiny: '2px'
  mosaik-size-small: '4px'
  mosaik-size-medium: '8px'
  mosaik-size-large: '16px'
  mosaik-size-giant: '32px'
components:
  button:
    backgroundColor: '{colors.mosaik-scheme-surface}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '8px'
    height: '36px'
    typography: '{typography.mosaik-typography-button}'
  button-checked:
    textColor: '{colors.mosaik-scheme-foreground}'
  button-default-hover:
    textColor: '{colors.mosaik-scheme-foreground}'
  button-hover:
    textColor: '{colors.mosaik-scheme-foreground}'
  button-outline-hover:
    textColor: '{colors.mosaik-scheme-foreground}'
  button-plain:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
  button-plain-hover:
    textColor: '{colors.mosaik-scheme-foreground}'
  button-selected:
    textColor: '{colors.mosaik-scheme-foreground}'
  button-soft:
    textColor: '{colors.mosaik-scheme-foreground}'
  toggle-button:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '8px'
    typography: '{typography.mosaik-typography-button}'
  toggle-button-checked:
    textColor: '{colors.mosaik-scheme-foreground}'
  toggle-button-checked-hover:
    textColor: '{colors.mosaik-scheme-foreground}'
  toggle-button-hover:
    textColor: '{colors.mosaik-scheme-foreground}'
  anchor:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-color-primary-600}'
    typography: '{typography.mosaik-typography-button}'
  badge:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '26px'
    typography: '{typography.mosaik-typography-caption}'
  badge-plain:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
  badge-soft:
    textColor: '{colors.mosaik-scheme-foreground}'
  chip:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '26px'
    height: '20px'
    typography: '{typography.mosaik-typography-overline}'
  chip-plain-hover:
    textColor: '{colors.mosaik-scheme-middlelight}'
  avatar:
    backgroundColor: '{colors.mosaik-color-neutral-100}'
    textColor: '{colors.mosaik-scheme-middlelight}'
    rounded: '9990px'
    typography: '{typography.mosaik-typography-body2}'
  avatar-outline:
    backgroundColor: '{colors.mosaik-scheme-surface}'
    textColor: '{colors.mosaik-scheme-foreground}'
  avatar-outline-primary:
    backgroundColor: '{colors.mosaik-scheme-surface}'
  avatar-plain:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
  avatar-plain-primary:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  avatar-soft:
    textColor: '{colors.mosaik-scheme-foreground}'
  persona:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '9990px'
    typography: '{typography.mosaik-typography-body2}'
  card:
    backgroundColor: '{colors.mosaik-scheme-surface}'
    textColor: '{colors.mosaik-scheme-foreground}'
    typography: '{typography.mosaik-typography-body2}'
  card-plain:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  textbox:
    backgroundColor: '{colors.mosaik-scheme-surface}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '8px'
    height: '36px'
    typography: '{typography.mosaik-typography-body2}'
  textbox-outline:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  textbox-plain:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  textbox-solid:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
  searchbox:
    backgroundColor: '{colors.mosaik-scheme-surface}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '8px'
    height: '36px'
    typography: '{typography.mosaik-typography-body2}'
  searchbox-outline:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  searchbox-plain:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  searchbox-solid:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
  select:
    backgroundColor: '{colors.mosaik-scheme-surface}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '8px'
    height: '36px'
    typography: '{typography.mosaik-typography-body2}'
  select-outline:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  select-plain:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  select-solid:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
  select-item:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '6px'
    typography: '{typography.mosaik-typography-body2}'
  checkbox:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '4px'
    typography: '{typography.mosaik-typography-subtitle2}'
  radio:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '9990px'
    typography: '{typography.mosaik-typography-subtitle2}'
  toggle-switch:
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '9990px'
    typography: '{typography.mosaik-typography-subtitle2}'
  slider:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '9990px'
    typography: '{typography.mosaik-typography-body2}'
  list:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '8px'
    padding: '{spacing.mosaik-layout-space}'
    typography: '{typography.mosaik-typography-body2}'
  list-item:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '8px'
    typography: '{typography.mosaik-typography-body2}'
  menu:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '8px'
    padding: '4px'
    typography: '{typography.mosaik-typography-body2}'
  menu-item:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '6px'
    height: '32px'
    typography: '{typography.mosaik-typography-body2}'
  tab:
    backgroundColor: '{colors.mosaik-scheme-surface}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '14px'
    typography: '{typography.mosaik-typography-body2}'
  tab-plain:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  tab-item:
    rounded: '{rounded.mosaik-layout-radius}'
  tooltip:
    backgroundColor: '{colors.mosaik-scheme-foreground}'
    textColor: '{colors.mosaik-scheme-background}'
    rounded: '8px'
    typography: '{typography.mosaik-typography-caption}'
  dialog:
    backgroundColor: '{colors.mosaik-scheme-surface}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '14px'
    padding: '24px'
    typography: '{typography.mosaik-typography-body2}'
  drawer:
    backgroundColor: '{colors.mosaik-scheme-surface}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '14px'
    width: '384px'
    padding: '16px'
    typography: '{typography.mosaik-typography-body2}'
  toast:
    backgroundColor: '{colors.mosaik-scheme-surface}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '18px'
    padding: '16px'
    typography: '{typography.mosaik-typography-body2}'
  banner:
    backgroundColor: '{colors.mosaik-scheme-surface}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    typography: '{typography.mosaik-typography-body2}'
  banner-plain:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  divider:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
    textColor: '{colors.mosaik-scheme-foreground}'
    typography: '{typography.mosaik-typography-body2}'
  skeleton:
    backgroundColor: '{colors.mosaik-color-neutral-100}'
    rounded: '8px'
  expander:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
    typography: '{typography.mosaik-typography-body2}'
  breadcrumb-item:
    textColor: '{colors.mosaik-scheme-middlelight}'
  breadcrumb-item-active:
    textColor: '{colors.mosaik-scheme-foreground}'
  breadcrumb-item-hover:
    textColor: '{colors.mosaik-scheme-foreground}'
  app-header:
    backgroundColor: '{colors.mosaik-scheme-background}'
    textColor: '{colors.mosaik-scheme-foreground}'
    typography: '{typography.mosaik-typography-subtitle1}'
  text:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '0px'
    typography: '{typography.mosaik-typography-body1}'
  text-disabled:
    textColor: '{colors.mosaik-scheme-disabled}'
  text-readonly:
    textColor: '{colors.mosaik-scheme-middlelight}'
---

<!--
The YAML frontmatter and every `design-md:*` region of this file are generated by
libs/mosaik-themes/bin/design-md.mjs from the soho token sources. Build the themes
package, then run `yarn nx run mosaik-themes:design-md`; `yarn nx run mosaik-themes:design-md:check`
fails while the generated parts have drifted. All other prose is hand-authored and must not be
generated away.

Format: DESIGN.md (https://github.com/google-labs-code/design.md), linted with @google/design.md.
-->

# Mosaik Soho

## Overview

**Soho — Mosaik-Theme auf Basis der visuellen Referenzen von shadcn/ui.**

Soho is Mosaik's **shadcn/ui** theme: a faithful translation of the visual language of shadcn/ui
(style **Vega** - shadcn's current classic look, preset `radix-vega`: radix base, base colour Neutral,
`registry/bases/radix/ui` + `styles/style-vega.css` at `shadcn-ui/ui@a2e305c`; the older New York is a legacy
style there) into the Mosaik architecture. A white canvas, near-black text and a near-black primary action,
quiet neutral fills for secondary actions and hover states, 1px borders in a light grey on controls,
surfaces framed by a 1px ring of the foreground at 10 %, a 10px base radius with the shadcn radius steps,
**Inter** type at `text-sm` for every control, small soft shadows (`xs`
on controls, `sm` on cards, `md` on floating surfaces, `lg` on dialogs) and the characteristic
**3px focus ring** at half the ring colour. Nothing moves, nothing glows.

Soho renders shadcn's components where Mosaik has a counterpart (button, input, select, checkbox,
radio, switch, slider, tabs, card, alert, badge, dialog, sheet, popover, menus, tooltip, table,
calendar, ...) and derives every other component from the same foundations ("Ableitung" in the
inventory). Colours always come from the Mosaik theme variables: the scheme roles and the nine
ramps carry the shadcn Neutral values by default, and every Mosaik colour scheme applies on top of
them. Icons use the Mosaik `reicon` set (a deliberate deviation from Lucide). Treat this document as
the contract for the values and for the anatomy.

Mosaik **is** the design system. Only the **names** are fixed: a product overrides values through
`provideTheme()` / `Theme2` and every component follows, because components never read literals,
only tokens. Soho is one of the four value sets Mosaik ships for that vocabulary.

Two token layers are fixed for this theme and captured in this document:

1. **The global set** from `tokens/themes/soho/soho.json` (merged with
   `tokens/themes/tokens.json`): scheme roles, nine color ramps, fourteen typography roles, layout
   rhythm, elevation, durations and the enum vocabularies, published as `--mosaik-*` custom
   properties and listed in the frontmatter as a light-mode snapshot.
2. **The component set**: one token file per component under
   `tokens/themes/soho/components/`, expanded with the shared mixins. Every entry becomes a
   `--<component>-<token>` custom property on the component's shadow host and is public styling
   API. The complete export, resolved to literals, is [COMPONENTS.soho.md](COMPONENTS.soho.md); the core
   atoms are also projected into the `components` block of the frontmatter.

Consumers never address a theme by its own prefix. The outward contract is the `--mosaik-*`
family: `ThemeService`, driven by `Theme2` or `provideTheme()`, remaps it onto the active theme's
internal `--<theme>-*` properties, which is what lets every theme, and every product built on one,
be used generically from outside.

Use this precedence whenever sources disagree:

1. The token sources in `libs/mosaik-themes/tokens/` and the component theme stylesheets.
2. The compiled artifacts (`dist/themes/___soho-tokens.css`, `soho-style()`) and
   the runtime `--mosaik-*` / `--soho-*` properties.
3. This document and [COMPONENTS.soho.md](COMPONENTS.soho.md).

### At a glance

<!-- design-md:stats -->

| Layer | Count | Source |
|---|---|---|
| Global tokens (compiled) | 507 | `dist/themes/___soho-tokens.css` |
| Runtime custom properties (light) | 653 | `soho-style()` and `ThemeService` |
| Components with a token file | 378 | `tokens/themes/soho/components/` |
| Component tokens (mixins expanded) | 11128 | `src/themes/soho/_components/` |
| Component tokens that do not resolve | 2 | [Known gaps](#known-gaps) |
<!-- /design-md:stats -->

### Activating the theme

The theme is selected by the `theme` attribute on `<html>` and the mode by `theme-mode`; both have
to be in place before any element module evaluates. Soho is set in **Inter** (Vega's font); code uses
Vega's `font-mono`, the system monospace stack. Load Inter from Google Fonts, nothing in the theme ships a
`@font-face`.

```html
<html lang="en" theme="soho" theme-mode="light">
  <head>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet" />
    <script type="module">
      import { SohoTheme, ThemeObserverServiceLocator } from 'https://esm.run/@pixel-brewery/mosaik-themes';
      const root = document.documentElement;
      ThemeObserverServiceLocator.current.applyTheme(root.getAttribute('theme') ?? 'soho', root.getAttribute('theme-mode') ?? 'light');
      await customElements.whenDefined('mosaik-theme2');
      document.querySelector('mosaik-theme2').theme = SohoTheme.SOHO_THEME;
    </script>
    <script type="module" src="https://esm.run/@pixel-brewery/mosaik-elements-foundation"></script>
  </head>
  <body>
    <mosaik-theme2>
      <mosaik-button label="Subscribe" variant="primary" appearance="solid"></mosaik-button>
    </mosaik-theme2>
  </body>
</html>
```

In a framework app the same happens through `provideTheme()` (Angular) or
`<Theme2 theme={sohoTheme} global>` (React). Your own markup gets no font or color by
default: set `font-family: var(--mosaik-font-family)`, `color: var(--mosaik-scheme-foreground)` and
`background: var(--mosaik-scheme-background)` on `body`.

## Colors

Soho is **Neutral**, the base colour of shadcn/ui. Light: a white page and white cards (`background`,
`surface`), near-black text (`foreground`, `#0a0a0a`), a light grey border (`highlight`, `#e5e5e5`,
shadcn `border` / `input`), `middlelight` as shadcn's `muted-foreground` (`#737373`) for secondary
text and placeholders, and `contrast` as `primary-foreground`. Dark: a `#0a0a0a` page, `#171717`
cards, near-white text, a white/10 border and `#a1a1a1` muted text.

The ramps put shadcn's roles on fixed stops in both modes: **`500` is the fill** (`primary` =
`#171717` in light and `#e5e5e5` in dark; `danger` = shadcn `destructive`), **`0` the text on it**
(`primary-foreground`), **`600` the variant colour as text** (`text-destructive`), and the
`neutral` ramp carries `sidebar` (`50`), `secondary` / `muted` / `accent` (`100`), `ring` (`400`)
and `muted-foreground` (`500`) on the same stop in light and dark. The other families (`secondary`
teal, `tertiary` orange, `info` blue, `warning` amber, `success` green, `highlight` violet) are
derivations from the Tailwind palette with the same stop rules. A Mosaik colour scheme regenerates
the ramps, and every component follows.

### Scheme roles

<!-- design-md:scheme -->

| Role | Custom property | Light | Dark | Purpose |
|---|---|---|---|---|
| `surface` | `--mosaik-scheme-surface` | `#ffffff` | `#171717` | Elevated surfaces: cards, dialogs, panels. |
| `background` | `--mosaik-scheme-background` | `#ffffff` | `#0a0a0a` | Page canvas and the default component fill. |
| `foreground` | `--mosaik-scheme-foreground` | `#0a0a0a` | `#fafafa` | Default text and icon color. |
| `highlight` | `--mosaik-scheme-highlight` | `#e5e5e5` | `rgba(255, 255, 255, 0.10196078431372549)` | Borders, dividers, hover fills. |
| `middlelight` | `--mosaik-scheme-middlelight` | `#737373` | `#a1a1a1` | Medium contrast - strokes, dividers, inactive marks and quiet fills. |
| `lowlight` | `--mosaik-scheme-lowlight` | `#525252` | `#d4d4d4` | The stronger secondary grey - secondary text, placeholders, captions and hints. |
| `transparent` | `--mosaik-scheme-transparent` | `rgba(255, 255, 255, 0)` | `rgba(10, 10, 10, 0)` | Fully transparent fill. |
| `semi-transparent` | `--mosaik-scheme-semi-transparent` | `rgba(0, 0, 0, 0.5019607843137255)` | `rgba(0, 0, 0, 0.5019607843137255)` | Glass-like overlays and backdrops. |
| `disabled` | `--mosaik-scheme-disabled` | `#a1a1a1` | `#525252` | Disabled text and controls. |
| `contrast` | `--mosaik-scheme-contrast` | `#fafafa` | `#171717` | Content on strongly colored surfaces. |
| `selection` | `--mosaik-scheme-selection` | `#d4d4d4` | `#404040` | Text selection background. |
<!-- /design-md:scheme -->

### Color ramps

<!-- design-md:palette -->

Light mode (`--mosaik-color-<family>-<stop>` resolves to these while `theme-mode="light"`):

| Family | 0 | 50 | 100 | 200 | 300 | 400 | 500 | 600 | 700 | 800 | 900 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| `primary` | `#fafafa` | `#fafafa` | `#f5f5f5` | `#e5e5e5` | `#d4d4d4` | `#737373` | `#171717` | `#171717` | `#0a0a0a` | `#050505` | `#000000` |
| `secondary` | `#ffffff` | `#f0fdfa` | `#cbfbf1` | `#96f7e4` | `#46ecd5` | `#009689` | `#00786f` | `#005f5a` | `#0b4f4a` | `#0b4f4a` | `#022f2e` |
| `tertiary` | `#ffffff` | `#fff7ed` | `#ffedd4` | `#ffd6a7` | `#ffb86a` | `#f54900` | `#ca3500` | `#9f2d00` | `#7e2a0c` | `#7e2a0c` | `#441306` |
| `info` | `#ffffff` | `#eff6ff` | `#dbeafe` | `#bedbff` | `#8ec5ff` | `#2b7fff` | `#155dfc` | `#1447e6` | `#193cb8` | `#1c398e` | `#162456` |
| `warning` | `#ffffff` | `#fffbeb` | `#fef3c6` | `#fee685` | `#ffd230` | `#e17100` | `#bb4d00` | `#973c00` | `#7b3306` | `#7b3306` | `#461901` |
| `danger` | `#ffffff` | `#fef2f2` | `#ffe2e2` | `#ffc9c9` | `#ffa2a2` | `#fb2c36` | `#e7000b` | `#e7000b` | `#9f0712` | `#82181a` | `#460809` |
| `success` | `#ffffff` | `#f0fdf4` | `#dcfce7` | `#b9f8cf` | `#7bf1a8` | `#00a63e` | `#008236` | `#016630` | `#0d542b` | `#0d542b` | `#032e15` |
| `highlight` | `#ffffff` | `#f5f3ff` | `#ede9fe` | `#ddd6ff` | `#c4b4ff` | `#8e51ff` | `#7f22fe` | `#7008e7` | `#5d0ec0` | `#4d179a` | `#2f0d68` |
| `neutral` | `#ffffff` | `#fafafa` | `#f5f5f5` | `#e5e5e5` | `#d4d4d4` | `#a1a1a1` | `#737373` | `#525252` | `#404040` | `#262626` | `#171717` |

Dark mode (the same names resolve to these while `theme-mode="dark"`):

| Family | 0 | 50 | 100 | 200 | 300 | 400 | 500 | 600 | 700 | 800 | 900 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| `primary` | `#171717` | `#0a0a0a` | `#171717` | `#262626` | `#404040` | `#a1a1a1` | `#e5e5e5` | `#e5e5e5` | `#f5f5f5` | `#fafafa` | `#ffffff` |
| `secondary` | `#022f2e` | `#022f2e` | `#0b4f4a` | `#005f5a` | `#00786f` | `#00bba7` | `#00d5be` | `#46ecd5` | `#96f7e4` | `#cbfbf1` | `#f0fdfa` |
| `tertiary` | `#441306` | `#441306` | `#7e2a0c` | `#9f2d00` | `#ca3500` | `#ff6900` | `#ff8904` | `#ffb86a` | `#ffd6a7` | `#ffedd4` | `#fff7ed` |
| `info` | `#162456` | `#162456` | `#1c398e` | `#193cb8` | `#1447e6` | `#2b7fff` | `#51a2ff` | `#8ec5ff` | `#bedbff` | `#dbeafe` | `#eff6ff` |
| `warning` | `#461901` | `#461901` | `#7b3306` | `#973c00` | `#bb4d00` | `#fe9a00` | `#ffb900` | `#ffd230` | `#fee685` | `#fef3c6` | `#fffbeb` |
| `danger` | `#ffffff` | `#460809` | `#82181a` | `#9f0712` | `#c10007` | `#fb2c36` | `#9d4042` | `#ff6467` | `#ffc9c9` | `#ffe2e2` | `#fef2f2` |
| `success` | `#032e15` | `#032e15` | `#0d542b` | `#016630` | `#008236` | `#00c950` | `#05df72` | `#7bf1a8` | `#b9f8cf` | `#dcfce7` | `#f0fdf4` |
| `highlight` | `#2f0d68` | `#2f0d68` | `#4d179a` | `#5d0ec0` | `#7008e7` | `#8e51ff` | `#a684ff` | `#c4b4ff` | `#ddd6ff` | `#ede9fe` | `#f5f3ff` |
| `neutral` | `#000000` | `#171717` | `#262626` | `#404040` | `#525252` | `#737373` | `#a1a1a1` | `#d4d4d4` | `#e5e5e5` | `#f5f5f5` | `#fafafa` |
<!-- /design-md:palette -->

### How variant and appearance pick a stop

The mapping is the button's (`ButtonElement.Soho.scss`) and every button-like control follows it:
the `default` appearance and `outline` are shadcn's `outline` button (1px border, page fill,
`shadow-xs`, `accent` fill on hover); `solid` is shadcn's `default` (`primary` fill, hover at 90 %)
and `solid danger` its `destructive`; `soft` is `secondary` (`muted` fill, hover at 80 %); `plain` is
`ghost` (transparent, `accent` on hover); a link-like control is `link` (primary text, underline on
hover). A variant on `outline`, `plain` and `soft` colours the text with the variant (`600`) and the
soft fill with a 10 % tint of it - a derivation, shadcn has no coloured outline. Disabled controls
keep their colours at half opacity and stop reacting. Nothing moves.

Fields are shadcn inputs: 36px high, a 1px `input` border, a transparent fill, `shadow-xs`, `text-sm`
and muted placeholders; on keyboard focus the border takes the ring colour and the 3px ring at
50 % appears outside; invalid fields use `destructive` for both.

### Naming rules

- `--mosaik-scheme-<role>` and `--mosaik-color-<family>-<stop>` are the consumer contract, aliases
  that `ThemeService` writes on `<html>` pointing at the `--soho-*` originals with the
  literal as fallback.
- Mode-specific names exist only under the theme prefix. Never introduce `dark-*` token names.
- Contrast: near-black on white for text; variant text uses stop `600`; white or `0` text only on
  `500` fills.

## Typography

Soho speaks **Inter** (`'Inter', ui-sans-serif, system-ui, sans-serif` - Vega's font) on the Tailwind type scale
shadcn uses: controls, menus, tables and descriptions in `text-sm` (`body2`, 14/20), labels and
buttons in `text-sm` medium (`button`, `subtitle2`), small print in `text-xs` (`caption`, 12/16).
Headlines are semibold with tight tracking: `headline2` is shadcn's `h1` (36/40, extrabold),
`headline3` `h2` (30/36), `headline4` `h3` (24/32), `headline5` `h4` (20/28), `headline6` `large`
(18/28). Nothing is uppercase; `overline` is a small medium label. Code uses Vega's `font-mono` (the system monospace stack).

The fourteen role names are the complete vocabulary; a product may change their values but must
not rename them or add roles. Each role publishes `--mosaik-typography-<role>` as a `font`
shorthand plus the individual parts, and per-role families default to `var(--font-family)`.

<!-- design-md:typography -->

| Role | Custom property | Family | Size | Line height | Weight | Letter spacing | Transform |
|---|---|---|---|---|---|---|---|
| `headline1` | `--mosaik-typography-headline1` | `'Inter', ui-sans-serif, system-ui, sans-serif` | `48px` | `48px` | `700` | `-1.2px` | `none` |
| `headline2` | `--mosaik-typography-headline2` | `'Inter', ui-sans-serif, system-ui, sans-serif` | `36px` | `40px` | `800` | `-0.9px` | `none` |
| `headline3` | `--mosaik-typography-headline3` | `'Inter', ui-sans-serif, system-ui, sans-serif` | `30px` | `36px` | `600` | `-0.75px` | `none` |
| `headline4` | `--mosaik-typography-headline4` | `'Inter', ui-sans-serif, system-ui, sans-serif` | `24px` | `32px` | `600` | `-0.6px` | `none` |
| `headline5` | `--mosaik-typography-headline5` | `'Inter', ui-sans-serif, system-ui, sans-serif` | `20px` | `28px` | `600` | `-0.5px` | `none` |
| `headline6` | `--mosaik-typography-headline6` | `'Inter', ui-sans-serif, system-ui, sans-serif` | `18px` | `28px` | `600` | `normal` | `none` |
| `subtitle1` | `--mosaik-typography-subtitle1` | `'Inter', ui-sans-serif, system-ui, sans-serif` | `16px` | `24px` | `500` | `normal` | `none` |
| `subtitle2` | `--mosaik-typography-subtitle2` | `'Inter', ui-sans-serif, system-ui, sans-serif` | `14px` | `20px` | `500` | `normal` | `none` |
| `body1` | `--mosaik-typography-body1` | `'Inter', ui-sans-serif, system-ui, sans-serif` | `16px` | `24px` | `400` | `normal` | `none` |
| `body2` | `--mosaik-typography-body2` | `'Inter', ui-sans-serif, system-ui, sans-serif` | `14px` | `20px` | `400` | `normal` | `none` |
| `supporting` | `--mosaik-typography-supporting` | `'Inter', ui-sans-serif, system-ui, sans-serif` | `14px` | `20px` | `400` | `normal` | `none` |
| `caption` | `--mosaik-typography-caption` | `'Inter', ui-sans-serif, system-ui, sans-serif` | `12px` | `16px` | `400` | `normal` | `none` |
| `overline` | `--mosaik-typography-overline` | `'Inter', ui-sans-serif, system-ui, sans-serif` | `12px` | `16px` | `500` | `normal` | `none` |
| `button` | `--mosaik-typography-button` | `'Inter', ui-sans-serif, system-ui, sans-serif` | `14px` | `20px` | `500` | `normal` | `none` |
<!-- /design-md:typography -->

## Layout

Soho uses an **8px** layout unit with Tailwind's 4px spacing steps as halves of it (`h-9` = 4.5
units = 36px), a **1px** stroke and a **10px** radius (`0.625rem`, shadcn's `--radius`). Every
padding, gap and margin is a `calc()` multiple of `layout.space`, every border `layout.thickness`
wide in the `highlight` grey.

<!-- design-md:layout -->

| Token | Custom property | Value | Role |
|---|---|---|---|
| `layout.space` | `--mosaik-layout-space` | `8px` | Base unit of every padding, gap and margin; components scale it with `calc()`. |
| `layout.radius` | `--mosaik-layout-radius` | `10px` | Corner radius of every rectangular surface. |
| `layout.thickness` | `--mosaik-layout-thickness` | `1px` | Border width of controls, dividers and indicators. |

The size vocabulary components accept as `size`, `gap` or `iconSize` (values from `tokens/themes/tokens.json`; these are enum steps, not runtime custom properties):

| Key | Value |
|---|---|
| `tiny` | `2px` |
| `small` | `4px` |
| `medium` | `8px` |
| `large` | `16px` |
| `giant` | `32px` |
<!-- /design-md:layout -->

Layout is composed with `mosaik-stack` and `mosaik-grid`, never with margins. Tailwind consumers
layer `@pixel-brewery/mosaik-themes/tailwind/v4/soho`.

## Elevation & Depth

Depth is **small and soft**, Tailwind's shadow scale: `light` = `shadow-xs` (controls), `semilight`
= `shadow-sm` (cards, the active tab), `regular` = `shadow-md` (popovers, menus, select lists),
`semibold` = `shadow-lg` (dialogs, sheets), `bold` = `shadow-xl`, `extrabold` = `shadow-2xl`. Every
level stacks two layers of black at 5-25 %, the same in dark mode, where borders carry the depth.

<!-- design-md:elevation -->

Every level is a stack of 2 shadow layers. `--mosaik-elevation-<level>` carries the complete `box-shadow` value; `--mosaik-elevation-<level>-{offset-x,offset-y,blur,spread,color}` expose the primary layer.

| Level | Light | Dark |
|---|---|---|
| `none` | `none` | `none` |
| `light` | `0px 1px 2px 0px rgba(0, 0, 0, 0.05), 0px 0px 0px 0px rgba(0, 0, 0, 0)` | `0px 1px 2px 0px rgba(0, 0, 0, 0.05), 0px 0px 0px 0px rgba(0, 0, 0, 0)` |
| `semilight` | `0px 1px 3px 0px rgba(0, 0, 0, 0.1), 0px 1px 2px -1px rgba(0, 0, 0, 0.1)` | `0px 1px 3px 0px rgba(0, 0, 0, 0.1), 0px 1px 2px -1px rgba(0, 0, 0, 0.1)` |
| `regular` | `0px 4px 6px -1px rgba(0, 0, 0, 0.1), 0px 2px 4px -2px rgba(0, 0, 0, 0.1)` | `0px 4px 6px -1px rgba(0, 0, 0, 0.1), 0px 2px 4px -2px rgba(0, 0, 0, 0.1)` |
| `semibold` | `0px 10px 15px -3px rgba(0, 0, 0, 0.1), 0px 4px 6px -4px rgba(0, 0, 0, 0.1)` | `0px 10px 15px -3px rgba(0, 0, 0, 0.1), 0px 4px 6px -4px rgba(0, 0, 0, 0.1)` |
| `bold` | `0px 20px 25px -5px rgba(0, 0, 0, 0.1), 0px 8px 10px -6px rgba(0, 0, 0, 0.1)` | `0px 20px 25px -5px rgba(0, 0, 0, 0.1), 0px 8px 10px -6px rgba(0, 0, 0, 0.1)` |
| `extrabold` | `0px 25px 50px -12px rgba(0, 0, 0, 0.25), 0px 0px 0px 0px rgba(0, 0, 0, 0)` | `0px 25px 50px -12px rgba(0, 0, 0, 0.25), 0px 0px 0px 0px rgba(0, 0, 0, 0)` |
<!-- /design-md:elevation -->

Components expose the scale as the named `elevation` prop; an explicit elevation lifts any surface.

## Shapes

Soho geometry follows the shadcn radius steps, all derived from the 10px `layout.radius`: `sm` 6px,
`md` 8px (buttons, inputs, selects, toggles, menus, popovers, tooltips), `lg` 10px (dialogs, tab
lists, alerts), `xl` 14px (cards), `full` for switches, radios, avatars and badges. Borders are 1px
in `highlight`; a coloured border is a state (focus ring, invalid).

Focus is the shadcn ring: the border takes the ring colour (`neutral-400` / `500`) and a 3px ring at
50 % opacity surrounds the control (`destructive` at 30 % when invalid). No outline, no offset.

## Motion

Soho motion is **quiet**: colour, border and shadow transitions over `duration.short` (150ms, the
Tailwind default); overlays fade and zoom from 95 % over `duration.medium` (200ms). Nothing
translates on hover or press.

<!-- design-md:motion -->

| Token | Custom property | Value | Role |
|---|---|---|---|
| `duration.short` | `--mosaik-duration-short` | `0.15s` | Hover, focus and color transitions; the default `transition-duration` of components. |
| `duration.medium` | `--mosaik-duration-medium` | `0.2s` | Expand, collapse and reveal. |
| `duration.long` | `--mosaik-duration-long` | `0.3s` | Page-level and staged motion. |
<!-- /design-md:motion -->

Components honour `prefers-reduced-motion` by collapsing durations to `0.01ms`.

## Components

Mosaik components are Lit web components; the framework packages are thin wrappers over the same
custom elements. The public language is expressed as **props, not classes**:

| Prop         | Values                                                                                                             |
| ------------ | ------------------------------------------------------------------------------------------------------------------ |
| `variant`    | `default`, `primary`, `secondary`, `tertiary`, `danger`, `warning`, `success`, `info`, `highlight`, `neutral`       |
| `appearance` | `default`, `outline`, `plain`, `soft`, `solid`                                                                     |
| `size`       | `tiny`, `small`, `medium`, `large`, `giant`                                                                        |
| `elevation`  | `none`, `light`, `semilight`, `regular`, `semibold`, `bold`, `extrabold`                                            |
| others       | `inset`, `fit`, `orientation`, `disabled`, `isBusy`, `isSelected` for spacing, sizing, direction and state          |

Not every component accepts all of them; the component's typings are authoritative. Text travels
through attributes (`label`, `text`, `header`), and containers only project their own sub
components.

### The component token contract

Each component owns one token file. The base skeleton (`tokens/themes/components.json`) gives
every component sixteen `unset` slots for font, padding, gap, transition and translate; mixins add
opt-in groups through `$includes`, and the component file sets the values that differ, always as
references to the global tokens. The merged map is declared on the shadow host as
`--<prefix>-<token>` custom properties, documented as `@cssprop` in the component's TSDoc, and any
of them can be overridden from outside:

```css
mosaik-button { --button-border-radius: 0px; }
mosaik-card   { --card-border-color: var(--mosaik-scheme-highlight); }
```

The mixin catalogue is the one shared by all themes; Soho differs in the values it assigns. Notable
Soho defaults: the button is shadcn's 36px control with `text-sm` medium labels and the `md` radius;
fields are 36px inputs with a 1px border and `shadow-xs`; cards are `xl` with `shadow-sm`; the
focus ring is the 3px ring at 50 %.

The frontmatter `components` block projects the core atoms into the DESIGN.md schema: the bare key
(`button`) is the token default, and related keys carry the overrides the theme stylesheet applies
(`button-primary`, `button-primary-hover`, `button-tiny`). Only `backgroundColor`, `textColor`,
`typography`, `rounded`, `padding`, `height` and `width` can be expressed there; everything else is
in [COMPONENTS.soho.md](COMPONENTS.soho.md).

### Runtime custom properties

<!-- design-md:runtime -->

A page with a `Theme2` / `provideTheme()` provider carries 653 custom properties in light mode: the 537 the compiled `soho-style()` stylesheet declares on `:root`, overlaid by what `ThemeService` writes from the theme object (dark mode redeclares the mode-dependent ones).

| Family | Properties |
|---|---|
| `--soho-color-*` | 297 |
| `--soho-duration-*` | 3 |
| `--soho-elevation-*` | 200 |
| `--soho-font-*` | 1 |
| `--soho-layout-*` | 4 |
| `--soho-scheme-*` | 33 |
| `--soho-typography-*` | 112 |
<!-- /design-md:runtime -->

`ThemeService` mirrors the scheme, color, font, typography, layout and elevation families as
`--mosaik-*` aliases; durations are aliased by the stylesheet itself. Soho additionally
declares `--soho-layout-transition`, which several component tokens use as their
transition duration.

### Component index

Every component with a token file, its tag and the number of tokens it exports. The prefix of a
component's custom properties is its tag without `mosaik-` (`mosaik-textbox` declares `--textbox-*`). The
full tables, with a link to each component's reference documentation, are in [COMPONENTS.soho.md](COMPONENTS.soho.md).

<!-- design-md:component-index -->

| Token file | Tag | Tokens |
|---|---|---|
| [absolute](COMPONENTS.soho.md#absolute) | `mosaik-absolute` | 22 |
| [absoluteItem](COMPONENTS.soho.md#absolute-item) | `mosaik-absolute-item` | 22 |
| [accordion](COMPONENTS.soho.md#accordion) | `mosaik-accordion` | 22 |
| [actionbar-group](COMPONENTS.soho.md#actionbar-group) | `mosaik-actionbar-group` | 25 |
| [actionbar-item](COMPONENTS.soho.md#actionbar-item) | `mosaik-actionbar-item` | 26 |
| [actionbar-separator](COMPONENTS.soho.md#actionbar-separator) | `mosaik-actionbar-separator` | 24 |
| [actionbar](COMPONENTS.soho.md#actionbar) | `mosaik-actionbar` | 29 |
| [alert](COMPONENTS.soho.md#alert) | `mosaik-alert` | 22 |
| [anchor](COMPONENTS.soho.md#anchor) | `mosaik-anchor` | 25 |
| [app](COMPONENTS.soho.md#app) | `mosaik-app` | 36 |
| [appHeader](COMPONENTS.soho.md#app-header) | `mosaik-app-header` | 31 |
| [audio](COMPONENTS.soho.md#audio) | `mosaik-audio` | 36 |
| [autoCompleteBox](COMPONENTS.soho.md#autocompletebox) | `mosaik-autocompletebox` | 33 |
| [avatar](COMPONENTS.soho.md#avatar) | `mosaik-avatar` | 34 |
| [avatarGroup](COMPONENTS.soho.md#avatar-group) | `mosaik-avatar-group` | 28 |
| [backTop](COMPONENTS.soho.md#back-top) | `mosaik-back-top` | 22 |
| [backdrop](COMPONENTS.soho.md#backdrop) | `mosaik-backdrop` | 24 |
| [badge](COMPONENTS.soho.md#badge) | `mosaik-badge` | 34 |
| [banner](COMPONENTS.soho.md#banner) | `mosaik-banner` | 34 |
| [bannerGroup](COMPONENTS.soho.md#banner-group) | `mosaik-banner-group` | 31 |
| [bannerHeader](COMPONENTS.soho.md#banner-header) | `mosaik-banner-header` | 24 |
| [bannerSubHeader](COMPONENTS.soho.md#banner-sub-header) | `mosaik-banner-sub-header` | 24 |
| [box](COMPONENTS.soho.md#box) | `mosaik-box` | 30 |
| [breadcrumb](COMPONENTS.soho.md#breadcrumb) | `mosaik-breadcrumb` | 22 |
| [breadcrumbItem](COMPONENTS.soho.md#breadcrumb-item) | `mosaik-breadcrumb-item` | 25 |
| [bubbles](COMPONENTS.soho.md#bubbles) | `mosaik-bubbles` | 23 |
| [busyState](COMPONENTS.soho.md#busy-state) | `mosaik-busy-state` | 30 |
| [button](COMPONENTS.soho.md#button) | `mosaik-button` | 41 |
| [buttonGroup](COMPONENTS.soho.md#button-group) | `mosaik-button-group` | 28 |
| [calendar](COMPONENTS.soho.md#calendar) | `mosaik-calendar` | 29 |
| [calendarDaysView](COMPONENTS.soho.md#calendar-days-view) | `mosaik-calendar-days-view` | 22 |
| [calendarHeader](COMPONENTS.soho.md#calendar-header) | `mosaik-calendar-header` | 28 |
| [calendarItem](COMPONENTS.soho.md#calendar-item) | `mosaik-calendar-item` | 41 |
| [calendarMonthsView](COMPONENTS.soho.md#calendar-months-view) | `mosaik-calendar-months-view` | 22 |
| [calendarSubHeader](COMPONENTS.soho.md#calendar-sub-header) | `mosaik-calendar-sub-header` | 30 |
| [calendarYearsView](COMPONENTS.soho.md#calendar-years-view) | `mosaik-calendar-years-view` | 22 |
| [camera](COMPONENTS.soho.md#camera) | `mosaik-camera` | 25 |
| [card](COMPONENTS.soho.md#card) | `mosaik-card` | 29 |
| [cardActions](COMPONENTS.soho.md#card-actions) | `mosaik-card-actions` | 22 |
| [cardContent](COMPONENTS.soho.md#card-content) | `mosaik-card-content` | 22 |
| [cardFooter](COMPONENTS.soho.md#card-footer) | `mosaik-card-footer` | 22 |
| [cardHeader](COMPONENTS.soho.md#card-header) | `mosaik-card-header` | 22 |
| [cardStack](COMPONENTS.soho.md#card-stack) | `mosaik-card-stack` | 21 |
| [cardSubTitle](COMPONENTS.soho.md#card-sub-title) | `mosaik-card-sub-title` | 25 |
| [cardTitle](COMPONENTS.soho.md#card-title) | `mosaik-card-title` | 25 |
| [carousel](COMPONENTS.soho.md#carousel) | `mosaik-carousel` | 42 |
| [carouselItem](COMPONENTS.soho.md#carousel-item) | `mosaik-carousel-item` | 22 |
| [cell](COMPONENTS.soho.md#cell) | `mosaik-cell` | 30 |
| [cellGroup](COMPONENTS.soho.md#cell-group) | `mosaik-cell-group` | 28 |
| [chart](COMPONENTS.soho.md#chart) | `mosaik-chart` | 24 |
| [chartToolbox](COMPONENTS.soho.md#chart-toolbox) | `mosaik-chart-toolbox` | 23 |
| [chat](COMPONENTS.soho.md#chat) | `mosaik-chat` | 30 |
| [chatHeader](COMPONENTS.soho.md#chat-header) | `mosaik-chat-header` | 23 |
| [chatMarker](COMPONENTS.soho.md#chat-marker) | `mosaik-chat-marker` | 28 |
| [chatMessage](COMPONENTS.soho.md#chat-message) | `mosaik-chat-message` | 29 |
| [chatMessageAvatar](COMPONENTS.soho.md#chat-message-avatar) | `mosaik-chat-message-avatar` | 34 |
| [chatMessageDivider](COMPONENTS.soho.md#chat-message-divider) | `mosaik-chat-message-divider` | 23 |
| [chatMessageReaction](COMPONENTS.soho.md#chat-message-reaction) | `mosaik-chat-message-reaction` | 23 |
| [checkBox](COMPONENTS.soho.md#checkbox) | `mosaik-checkbox` | 28 |
| [checkBoxGroup](COMPONENTS.soho.md#checkbox-group) | `mosaik-checkbox-group` | 28 |
| [checkmark](COMPONENTS.soho.md#checkmark) | `mosaik-checkmark` | 36 |
| [chip](COMPONENTS.soho.md#chip) | `mosaik-chip` | 35 |
| [chipBox](COMPONENTS.soho.md#chipbox) | `mosaik-chipbox` | 43 |
| [chipGroup](COMPONENTS.soho.md#chip-group) | `mosaik-chip-group` | 28 |
| [choice](COMPONENTS.soho.md#choice) | `mosaik-choice` | 32 |
| [choiceGroup](COMPONENTS.soho.md#choice-group) | `mosaik-choice-group` | 28 |
| [choiceGroupHeader](COMPONENTS.soho.md#choice-group-header) | `mosaik-choice-group-header` | 28 |
| [clickable](COMPONENTS.soho.md#clickable) | `mosaik-clickable` | 33 |
| [code](COMPONENTS.soho.md#code) | `mosaik-code` | 23 |
| [codeEditor](COMPONENTS.soho.md#code-editor) | `mosaik-code-editor` | 78 |
| [colorArea](COMPONENTS.soho.md#color-area) | `mosaik-color-area` | 22 |
| [colorBox](COMPONENTS.soho.md#colorbox) | `mosaik-colorbox` | 41 |
| [colorEditor](COMPONENTS.soho.md#color-editor) | `mosaik-color-editor` | 34 |
| [colorEditorAlphaSlider](COMPONENTS.soho.md#color-editor-alpha-slider) | `mosaik-color-editor-alpha-slider` | 41 |
| [colorEditorArea](COMPONENTS.soho.md#color-editor-area) | `mosaik-color-editor-area` | 39 |
| [colorEditorHueSlider](COMPONENTS.soho.md#color-editor-hue-slider) | `mosaik-color-editor-hue-slider` | 40 |
| [colorEditorInputs](COMPONENTS.soho.md#color-editor-inputs) | `mosaik-color-editor-inputs` | 37 |
| [colorEditorPalette](COMPONENTS.soho.md#color-editor-palette) | `mosaik-color-editor-palette` | 36 |
| [colorEditorShadeSlider](COMPONENTS.soho.md#color-editor-shade-slider) | `mosaik-color-editor-shade-slider` | 40 |
| [colorEditorSwatch](COMPONENTS.soho.md#color-editor-swatch) | `mosaik-color-editor-swatch` | 31 |
| [colorPicker](COMPONENTS.soho.md#color-picker) | `mosaik-color-picker` | 29 |
| [colorSlider](COMPONENTS.soho.md#color-slider) | `mosaik-color-slider` | 28 |
| [colorSwatch](COMPONENTS.soho.md#color-swatch) | `mosaik-color-swatch` | 29 |
| [colorSwatchGroup](COMPONENTS.soho.md#color-swatch-group) | `mosaik-color-swatch-group` | 28 |
| [colorThumb](COMPONENTS.soho.md#color-thumb) | `mosaik-color-thumb` | 29 |
| [combo](COMPONENTS.soho.md#combo) | `mosaik-combo` | 36 |
| [comboItem](COMPONENTS.soho.md#combo-item) | `mosaik-combo-item` | 34 |
| [comboItemGroup](COMPONENTS.soho.md#combo-item-group) | `mosaik-combo-item-group` | 39 |
| [comboItemVisual](COMPONENTS.soho.md#combo-item-visual) | `mosaik-combo-item-visual` | 22 |
| [comment](COMPONENTS.soho.md#comment) | `mosaik-comment` | 25 |
| [compoundButton](COMPONENTS.soho.md#compound-button) | `mosaik-compound-button` | 41 |
| [content](COMPONENTS.soho.md#content) | `mosaik-content` | 22 |
| [cookiesConsent](COMPONENTS.soho.md#cookie-consent) | `mosaik-cookie-consent` | 22 |
| [cursorEffect](COMPONENTS.soho.md#cursor-effect) | `mosaik-cursor-effect` | 21 |
| [dataList](COMPONENTS.soho.md#data-list) | `mosaik-data-list` | 22 |
| [dataTable](COMPONENTS.soho.md#data-table) | `mosaik-data-table` | 24 |
| [dateBox](COMPONENTS.soho.md#datebox) | `mosaik-datebox` | 41 |
| [dateTimeBox](COMPONENTS.soho.md#datetimebox) | `mosaik-datetimebox` | 41 |
| [designer](COMPONENTS.soho.md#designer) | `mosaik-designer` | 22 |
| [designerCanvas](COMPONENTS.soho.md#designer-canvas) | `mosaik-designer-canvas` | 26 |
| [designerConnector](COMPONENTS.soho.md#designer-connector) | `mosaik-designer-connector` | 27 |
| [designerContent](COMPONENTS.soho.md#designer-content) | `mosaik-designer-content` | 22 |
| [designerFrame](COMPONENTS.soho.md#designer-frame) | `mosaik-designer-frame` | 34 |
| [dialog](COMPONENTS.soho.md#dialog) | `mosaik-dialog` | 29 |
| [dialogActions](COMPONENTS.soho.md#dialog-actions) | `mosaik-dialog-actions` | 22 |
| [dialogContent](COMPONENTS.soho.md#dialog-content) | `mosaik-dialog-content` | 22 |
| [dialogFooter](COMPONENTS.soho.md#dialog-footer) | `mosaik-dialog-footer` | 22 |
| [dialogHeader](COMPONENTS.soho.md#dialog-header) | `mosaik-dialog-header` | 22 |
| [dialogHeaderSubText](COMPONENTS.soho.md#dialog-header-sub-text) | `mosaik-dialog-header-sub-text` | 25 |
| [dialogHeaderText](COMPONENTS.soho.md#dialog-header-text) | `mosaik-dialog-header-text` | 25 |
| [disclosure](COMPONENTS.soho.md#disclosure) | `mosaik-disclosure` | 32 |
| [dismiss](COMPONENTS.soho.md#dismiss) | `mosaik-dismiss` | 22 |
| [divider](COMPONENTS.soho.md#divider) | `mosaik-divider` | 25 |
| [dockPanel](COMPONENTS.soho.md#dock-panel) | `mosaik-dock-panel` | 22 |
| [dot](COMPONENTS.soho.md#dot) | `mosaik-dot` | 29 |
| [dotGroup](COMPONENTS.soho.md#dot-group) | `mosaik-dot-group` | 28 |
| [drawer](COMPONENTS.soho.md#drawer) | `mosaik-drawer` | 33 |
| [drawerActions](COMPONENTS.soho.md#drawer-actions) | `mosaik-drawer-actions` | 22 |
| [drawerContainer](COMPONENTS.soho.md#drawer-container) | `mosaik-drawer-container` | 23 |
| [drawerContent](COMPONENTS.soho.md#drawer-content) | `mosaik-drawer-content` | 26 |
| [drawerFooter](COMPONENTS.soho.md#drawer-footer) | `mosaik-drawer-footer` | 22 |
| [drawerHeader](COMPONENTS.soho.md#drawer-header) | `mosaik-drawer-header` | 22 |
| [drawerHeaderSubText](COMPONENTS.soho.md#drawer-header-sub-text) | `mosaik-drawer-header-sub-text` | 25 |
| [drawerHeaderText](COMPONENTS.soho.md#drawer-header-text) | `mosaik-drawer-header-text` | 25 |
| [drawerRail](COMPONENTS.soho.md#drawer-rail) | `mosaik-drawer-rail` | 25 |
| [dropDownButton](COMPONENTS.soho.md#dropdown-button) | `mosaik-dropdown-button` | 44 |
| [dropZone](COMPONENTS.soho.md#drop-zone) | `mosaik-drop-zone` | 27 |
| [dropdown](COMPONENTS.soho.md#dropdown) | `mosaik-dropdown` | 42 |
| [durationBox](COMPONENTS.soho.md#durationbox) | `mosaik-durationbox` | 41 |
| [elevation](COMPONENTS.soho.md#elevation) | `mosaik-elevation` | 22 |
| [emoji](COMPONENTS.soho.md#emoji) | `mosaik-emoji` | 23 |
| [emptyState](COMPONENTS.soho.md#empty-state) | `mosaik-empty-state` | 30 |
| [epg](COMPONENTS.soho.md#epg) | `mosaik-epg` | 28 |
| [epgChannel](COMPONENTS.soho.md#epg-channel) | `mosaik-epg-channel` | 28 |
| [epgMinimap](COMPONENTS.soho.md#epg-minimap) | `mosaik-epg-minimap` | 28 |
| [epgNowLine](COMPONENTS.soho.md#epg-now-line) | `mosaik-epg-now-line` | 26 |
| [epgProgram](COMPONENTS.soho.md#epg-program) | `mosaik-epg-program` | 28 |
| [epgTimeline](COMPONENTS.soho.md#epg-timeline) | `mosaik-epg-timeline` | 28 |
| [error](COMPONENTS.soho.md#error) | `mosaik-error` | 28 |
| [errorState](COMPONENTS.soho.md#error-state) | `mosaik-error-state` | 29 |
| [expandable](COMPONENTS.soho.md#expandable) | `mosaik-expandable` | 22 |
| [expander](COMPONENTS.soho.md#expander) | `mosaik-expander` | 31 |
| [expanderGroup](COMPONENTS.soho.md#expander-group) | `mosaik-expander-group` | 28 |
| [expanderHeader](COMPONENTS.soho.md#expander-header) | `mosaik-expander-header` | 25 |
| [expanderSubHeader](COMPONENTS.soho.md#expander-sub-header) | `mosaik-expander-sub-header` | 25 |
| [fileBox](COMPONENTS.soho.md#filebox) | `mosaik-filebox` | 41 |
| [filePicker](COMPONENTS.soho.md#file-picker) | `mosaik-file-picker` | 28 |
| [fileUpload](COMPONENTS.soho.md#file-upload) | `mosaik-file-upload` | 37 |
| [fileUploadItem](COMPONENTS.soho.md#file-upload-item) | `mosaik-file-upload-item` | 28 |
| [flip](COMPONENTS.soho.md#flip) | `mosaik-flip` | 22 |
| [floating](COMPONENTS.soho.md#floating) | `mosaik-floating` | 31 |
| [floatingActionButton](COMPONENTS.soho.md#fab) | `mosaik-fab` | 39 |
| [floatingActionButtonGroup](COMPONENTS.soho.md#fab-group) | `mosaik-fab-group` | 22 |
| [floatingTrigger](COMPONENTS.soho.md#floating-trigger) | `mosaik-floating-trigger` | 22 |
| [flow](COMPONENTS.soho.md#flow) | `mosaik-flow` | 33 |
| [flowBoard](COMPONENTS.soho.md#flow-board) | `mosaik-flow-board` | 24 |
| [flowBoardColumn](COMPONENTS.soho.md#flow-board-column) | `mosaik-flow-board-column` | 44 |
| [flowBoardColumnComposer](COMPONENTS.soho.md#flow-board-column-composer) | `mosaik-flow-board-column-composer` | 30 |
| [flowBoardColumnItem](COMPONENTS.soho.md#flow-board-column-item) | `mosaik-flow-board-column-item` | 37 |
| [flowBoardColumnItemComposer](COMPONENTS.soho.md#flow-board-column-item-composer) | `mosaik-flow-board-column-item-composer` | 30 |
| [flowBoardColumnItemGroup](COMPONENTS.soho.md#flow-board-column-item-group) | `mosaik-flow-board-column-item-group` | 36 |
| [flowControls](COMPONENTS.soho.md#flow-controls) | `mosaik-flow-controls` | 37 |
| [flowEdge](COMPONENTS.soho.md#flow-edge) | `mosaik-flow-edge` | 39 |
| [flowMinimap](COMPONENTS.soho.md#flow-minimap) | `mosaik-flow-minimap` | 42 |
| [flowNode](COMPONENTS.soho.md#flow-node) | `mosaik-flow-node` | 47 |
| [focusRing](COMPONENTS.soho.md#focus-ring) | `mosaik-focus-ring` | 35 |
| [fontEditor](COMPONENTS.soho.md#font-editor) | `mosaik-font-editor` | 56 |
| [footer](COMPONENTS.soho.md#footer) | `mosaik-footer` | 29 |
| [footerItem](COMPONENTS.soho.md#footer-item) | `mosaik-footer-item` | 22 |
| [footerItemGroup](COMPONENTS.soho.md#footer-item-group) | `mosaik-footer-item-group` | 22 |
| [form](COMPONENTS.soho.md#form) | `mosaik-form` | 23 |
| [formField](COMPONENTS.soho.md#form-field) | `mosaik-form-field` | 23 |
| [gauge](COMPONENTS.soho.md#gauge) | `mosaik-gauge` | 28 |
| [gaugeArc](COMPONENTS.soho.md#gauge-arc) | `mosaik-gauge-arc` | 25 |
| [gaugeControl](COMPONENTS.soho.md#gauge-control) | `mosaik-gauge-control` | 28 |
| [gaugeDot](COMPONENTS.soho.md#gauge-dot) | `mosaik-gauge-dot` | 27 |
| [gaugeHub](COMPONENTS.soho.md#gauge-hub) | `mosaik-gauge-hub` | 25 |
| [gaugeInset](COMPONENTS.soho.md#gauge-inset) | `mosaik-gauge-inset` | 22 |
| [gaugeMarks](COMPONENTS.soho.md#gauge-marks) | `mosaik-gauge-marks` | 26 |
| [gaugeNeedle](COMPONENTS.soho.md#gauge-needle) | `mosaik-gauge-needle` | 25 |
| [gaugeStack](COMPONENTS.soho.md#gauge-stack) | `mosaik-gauge-stack` | 25 |
| [gaugeText](COMPONENTS.soho.md#gauge-text) | `mosaik-gauge-text` | 26 |
| [gaugeTickLabels](COMPONENTS.soho.md#gauge-tick-labels) | `mosaik-gauge-tick-labels` | 26 |
| [gaugeTicks](COMPONENTS.soho.md#gauge-ticks) | `mosaik-gauge-ticks` | 26 |
| [gaugeTooltip](COMPONENTS.soho.md#gauge-tooltip) | `mosaik-gauge-tooltip` | 29 |
| [gaugeTrack](COMPONENTS.soho.md#gauge-track) | `mosaik-gauge-track` | 25 |
| [gaugeValue](COMPONENTS.soho.md#gauge-value) | `mosaik-gauge-value` | 26 |
| [gaugeZones](COMPONENTS.soho.md#gauge-zones) | `mosaik-gauge-zones` | 25 |
| [ghost](COMPONENTS.soho.md#ghost) | `mosaik-ghost` | 27 |
| [globe](COMPONENTS.soho.md#globe) | `mosaik-globe` | 24 |
| [grid](COMPONENTS.soho.md#grid) | `mosaik-grid` | 22 |
| [gridItem](COMPONENTS.soho.md#grid-item) | `mosaik-grid-item` | 22 |
| [helmet](COMPONENTS.soho.md#helmet) | `mosaik-helmet` | 22 |
| [hint](COMPONENTS.soho.md#hint) | `mosaik-hint` | 28 |
| [icon](COMPONENTS.soho.md#icon) | `mosaik-icon` | 28 |
| [image](COMPONENTS.soho.md#image) | `mosaik-image` | 39 |
| [indicator](COMPONENTS.soho.md#indicator) | `mosaik-indicator` | 28 |
| [inkBar](COMPONENTS.soho.md#ink-bar) | `mosaik-ink-bar` | 25 |
| [jumbotron](COMPONENTS.soho.md#jumbotron) | `mosaik-jumbotron` | 28 |
| [jumbotronHeader](COMPONENTS.soho.md#jumbotron-header) | `mosaik-jumbotron-header` | 25 |
| [jumbotronSubHeader](COMPONENTS.soho.md#jumbotron-sub-header) | `mosaik-jumbotron-sub-header` | 25 |
| [kbd](COMPONENTS.soho.md#kbd) | `mosaik-kbd` | 28 |
| [kbdShortcut](COMPONENTS.soho.md#kbd-shortcut) | `mosaik-kbd-shortcut` | 22 |
| [knob](COMPONENTS.soho.md#knob) | `mosaik-knob` | 41 |
| [lightChain](COMPONENTS.soho.md#light-chain) | `mosaik-light-chain` | 22 |
| [list](COMPONENTS.soho.md#list) | `mosaik-list` | 29 |
| [listItem](COMPONENTS.soho.md#list-item) | `mosaik-list-item` | 34 |
| [listItemGroup](COMPONENTS.soho.md#list-item-group) | `mosaik-list-item-group` | 39 |
| [listing](COMPONENTS.soho.md#listing) | `mosaik-listing` | 24 |
| [listingItem](COMPONENTS.soho.md#listing-item) | `mosaik-listing-item` | 24 |
| [listingItemMarker](COMPONENTS.soho.md#listing-item-marker) | `mosaik-listing-item-marker` | 29 |
| [map](COMPONENTS.soho.md#map) | `mosaik-map` | 22 |
| [marquee](COMPONENTS.soho.md#marquee) | `mosaik-marquee` | 25 |
| [masonry](COMPONENTS.soho.md#masonry) | `mosaik-masonry` | 23 |
| [mention](COMPONENTS.soho.md#mention) | `mosaik-mention` | 32 |
| [menu](COMPONENTS.soho.md#menu) | `mosaik-menu` | 28 |
| [menuItem](COMPONENTS.soho.md#menu-item) | `mosaik-menu-item` | 38 |
| [menuItemGroup](COMPONENTS.soho.md#menu-item-group) | `mosaik-menu-item-group` | 39 |
| [message](COMPONENTS.soho.md#message) | `mosaik-message` | 28 |
| [messageBox](COMPONENTS.soho.md#message-box) | `mosaik-message-box` | 45 |
| [meterBar](COMPONENTS.soho.md#meter-bar) | `mosaik-meter-bar` | 26 |
| [meterRing](COMPONENTS.soho.md#meter-ring) | `mosaik-meter-ring` | 36 |
| [number](COMPONENTS.soho.md#number) | `mosaik-number` | 24 |
| [numberBox](COMPONENTS.soho.md#numberbox) | `mosaik-numberbox` | 41 |
| [numberCounter](COMPONENTS.soho.md#number-counter) | `mosaik-number-counter` | 24 |
| [numberTicker](COMPONENTS.soho.md#number-ticker) | `mosaik-number-ticker` | 16 |
| [orbit](COMPONENTS.soho.md#orbit) | `mosaik-orbit` | 19 |
| [page](COMPONENTS.soho.md#page) | `mosaik-page` | 22 |
| [pageContent](COMPONENTS.soho.md#page-content) | `mosaik-page-content` | 23 |
| [pageHeader](COMPONENTS.soho.md#page-header) | `mosaik-page-header` | 48 |
| [pageMenu](COMPONENTS.soho.md#page-menu) | `mosaik-page-menu` | 30 |
| [pagePreContent](COMPONENTS.soho.md#page-pre-content) | `mosaik-page-pre-content` | 23 |
| [pagePreHeader](COMPONENTS.soho.md#page-pre-header) | `mosaik-page-pre-header` | 23 |
| [paginator](COMPONENTS.soho.md#paginator) | `mosaik-paginator` | 23 |
| [parallax](COMPONENTS.soho.md#parallax) | `mosaik-parallax` | 16 |
| [passwordBox](COMPONENTS.soho.md#passwordbox) | `mosaik-passwordbox` | 41 |
| [pattern](COMPONENTS.soho.md#pattern) | `mosaik-pattern` | 23 |
| [persona](COMPONENTS.soho.md#persona) | `mosaik-persona` | 28 |
| [perspective](COMPONENTS.soho.md#perspective) | `mosaik-perspective` | 22 |
| [pinBox](COMPONENTS.soho.md#pinbox) | `mosaik-pinbox` | 34 |
| [pip](COMPONENTS.soho.md#pip) | `mosaik-pip` | 34 |
| [placeholder](COMPONENTS.soho.md#placeholder) | `mosaik-placeholder` | 27 |
| [popup](COMPONENTS.soho.md#popup) | `mosaik-popup` | 28 |
| [portal](COMPONENTS.soho.md#portal) | `mosaik-portal` | 22 |
| [portalHost](COMPONENTS.soho.md#portal-host) | `mosaik-portal-host` | 22 |
| [portalProjection](COMPONENTS.soho.md#portal-projection) | `mosaik-portal-projection` | 22 |
| [pressButton](COMPONENTS.soho.md#press-button) | `mosaik-press-button` | 44 |
| [progressBar](COMPONENTS.soho.md#progress-bar) | `mosaik-progress-bar` | 22 |
| [progressRing](COMPONENTS.soho.md#progress-ring) | `mosaik-progress-ring` | 31 |
| [promptBox](COMPONENTS.soho.md#prompt-box) | `mosaik-prompt-box` | 40 |
| [promptBoxAttachmentList](COMPONENTS.soho.md#prompt-box-attachment-list) | `mosaik-prompt-box-attachment-list` | 29 |
| [promptBoxQueue](COMPONENTS.soho.md#prompt-box-queue) | `mosaik-prompt-box-queue` | 29 |
| [promptBoxVoiceRecorderTool](COMPONENTS.soho.md#prompt-box-voice-recorder-tool) | `mosaik-prompt-box-voice-recorder-tool` | 22 |
| [pulse](COMPONENTS.soho.md#pulse) | `mosaik-pulse` | 18 |
| [qrCode](COMPONENTS.soho.md#qrcode) | `mosaik-qrcode` | 24 |
| [radio](COMPONENTS.soho.md#radio) | `mosaik-radio` | 28 |
| [radioGroup](COMPONENTS.soho.md#radio-group) | `mosaik-radio-group` | 28 |
| [rating](COMPONENTS.soho.md#rating) | `mosaik-rating` | 28 |
| [region](COMPONENTS.soho.md#region) | `mosaik-region` | 22 |
| [regionView](COMPONENTS.soho.md#region-view) | `mosaik-region-view` | 22 |
| [repeatButton](COMPONENTS.soho.md#repeat-button) | `mosaik-repeat-button` | 43 |
| [resize](COMPONENTS.soho.md#resize) | `mosaik-resize` | 22 |
| [resizeAdorner](COMPONENTS.soho.md#resize-adorner) | `mosaik-resize-adorner` | 28 |
| [resizeThumb](COMPONENTS.soho.md#resize-thumb) | `mosaik-resize-thumb` | 28 |
| [reveal](COMPONENTS.soho.md#reveal) | `mosaik-reveal` | 20 |
| [ribbon](COMPONENTS.soho.md#ribbon) | `mosaik-ribbon` | 30 |
| [richTextBox](COMPONENTS.soho.md#richtextbox) | `mosaik-richtextbox` | 70 |
| [richTextBoxToolbox](COMPONENTS.soho.md#richtextbox-toolbox) | `mosaik-richtextbox-toolbox` | 34 |
| [ripple](COMPONENTS.soho.md#ripple) | `mosaik-ripple` | 23 |
| [router](COMPONENTS.soho.md#router) | `mosaik-router` | 22 |
| [routerAnchor](COMPONENTS.soho.md#router-anchor) | `mosaik-router-anchor` | 25 |
| [routerLink](COMPONENTS.soho.md#router-link) | `mosaik-router-link` | 22 |
| [routerOutlet](COMPONENTS.soho.md#router-outlet) | `mosaik-router-outlet` | 22 |
| [scale](COMPONENTS.soho.md#scale) | `mosaik-scale` | 22 |
| [scheduler](COMPONENTS.soho.md#scheduler) | `mosaik-scheduler` | 73 |
| [schedulerAgendaView](COMPONENTS.soho.md#scheduler-agenda-view) | `mosaik-scheduler-agenda-view` | 40 |
| [schedulerDatescale](COMPONENTS.soho.md#scheduler-datescale) | `mosaik-scheduler-datescale` | 41 |
| [schedulerEvent](COMPONENTS.soho.md#scheduler-event) | `mosaik-scheduler-event` | 54 |
| [schedulerMonthView](COMPONENTS.soho.md#scheduler-month-view) | `mosaik-scheduler-month-view` | 58 |
| [schedulerNowIndicator](COMPONENTS.soho.md#scheduler-now-indicator) | `mosaik-scheduler-now-indicator` | 25 |
| [schedulerTimeGridView](COMPONENTS.soho.md#scheduler-time-grid-view) | `mosaik-scheduler-time-grid-view` | 67 |
| [schedulerTimelineView](COMPONENTS.soho.md#scheduler-timeline-view) | `mosaik-scheduler-timeline-view` | 66 |
| [schedulerTimescale](COMPONENTS.soho.md#scheduler-timescale) | `mosaik-scheduler-timescale` | 34 |
| [scroll](COMPONENTS.soho.md#scroll) | `mosaik-scroll` | 24 |
| [scrubSlider](COMPONENTS.soho.md#scrub-slider) | `mosaik-scrub-slider` | 64 |
| [searchBox](COMPONENTS.soho.md#searchbox) | `mosaik-searchbox` | 34 |
| [segment](COMPONENTS.soho.md#segment) | `mosaik-segment` | 35 |
| [segmentBar](COMPONENTS.soho.md#segment-bar) | `mosaik-segment-bar` | 25 |
| [segmentItem](COMPONENTS.soho.md#segment-item) | `mosaik-segment-item` | 34 |
| [segmentLegend](COMPONENTS.soho.md#segment-legend) | `mosaik-segment-legend` | 22 |
| [segmentLegendItem](COMPONENTS.soho.md#segment-legend-item) | `mosaik-segment-legend-item` | 25 |
| [segmentRing](COMPONENTS.soho.md#segment-ring) | `mosaik-segment-ring` | 25 |
| [select](COMPONENTS.soho.md#select) | `mosaik-select` | 36 |
| [selectItem](COMPONENTS.soho.md#select-item) | `mosaik-select-item` | 34 |
| [selectItemGroup](COMPONENTS.soho.md#select-item-group) | `mosaik-select-item-group` | 39 |
| [selectItemVisual](COMPONENTS.soho.md#select-item-visual) | `mosaik-select-item-visual` | 22 |
| [sheet](COMPONENTS.soho.md#sheet) | `mosaik-sheet` | 41 |
| [sheetContent](COMPONENTS.soho.md#sheet-content) | `mosaik-sheet-content` | 22 |
| [sheetFooter](COMPONENTS.soho.md#sheet-footer) | `mosaik-sheet-footer` | 22 |
| [sheetHeader](COMPONENTS.soho.md#sheet-header) | `mosaik-sheet-header` | 22 |
| [sheetHeaderSubText](COMPONENTS.soho.md#sheet-header-sub-text) | `mosaik-sheet-header-sub-text` | 25 |
| [sheetHeaderText](COMPONENTS.soho.md#sheet-header-text) | `mosaik-sheet-header-text` | 25 |
| [signaturePad](COMPONENTS.soho.md#signaturepad) | `mosaik-signaturepad` | 33 |
| [skeleton](COMPONENTS.soho.md#skeleton) | `mosaik-skeleton` | 29 |
| [slider](COMPONENTS.soho.md#slider) | `mosaik-slider` | 65 |
| [slider2](COMPONENTS.soho.md#slider2) | `mosaik-slider2` | 22 |
| [slider2Thumb](COMPONENTS.soho.md#slider2-thumb) | `mosaik-slider2-thumb` | 23 |
| [spacer](COMPONENTS.soho.md#spacer) | `mosaik-spacer` | 22 |
| [spline](COMPONENTS.soho.md#spline) | `mosaik-spline` | 20 |
| [split](COMPONENTS.soho.md#split) | `mosaik-split` | 30 |
| [splitButton](COMPONENTS.soho.md#split-button) | `mosaik-split-button` | 43 |
| [stack](COMPONENTS.soho.md#stack) | `mosaik-stack` | 22 |
| [stepper](COMPONENTS.soho.md#stepper) | `mosaik-stepper` | 40 |
| [stepperItem](COMPONENTS.soho.md#stepper-item) | `mosaik-stepper-item` | 25 |
| [sticky](COMPONENTS.soho.md#sticky) | `mosaik-sticky` | 24 |
| [successState](COMPONENTS.soho.md#success-state) | `mosaik-success-state` | 29 |
| [suggestionMenu](COMPONENTS.soho.md#suggestion-menu) | `mosaik-suggestion-menu` | 25 |
| [summary](COMPONENTS.soho.md#summary) | `mosaik-summary` | 22 |
| [swipe](COMPONENTS.soho.md#swipe) | `mosaik-swipe` | 22 |
| [tab](COMPONENTS.soho.md#tab) | `mosaik-tab` | 36 |
| [tabItem](COMPONENTS.soho.md#tab-item) | `mosaik-tab-item` | 25 |
| [tabPanel](COMPONENTS.soho.md#tab-panel) | `mosaik-tab-panel` | 23 |
| [tabStrip](COMPONENTS.soho.md#tab-strip) | `mosaik-tab-strip` | 28 |
| [tabStripItem](COMPONENTS.soho.md#tab-strip-item) | `mosaik-tab-strip-item` | 36 |
| [table](COMPONENTS.soho.md#table) | `mosaik-table` | 38 |
| [tableBody](COMPONENTS.soho.md#table-body) | `mosaik-table-body` | 28 |
| [tableBodyCell](COMPONENTS.soho.md#table-body-cell) | `mosaik-table-body-cell` | 28 |
| [tableBodyRow](COMPONENTS.soho.md#table-body-row) | `mosaik-table-body-row` | 27 |
| [tableColumnEditor](COMPONENTS.soho.md#table-column-editor) | `mosaik-table-column-editor` | 32 |
| [tableFooter](COMPONENTS.soho.md#table-footer) | `mosaik-table-footer` | 28 |
| [tableFooterCell](COMPONENTS.soho.md#table-footer-cell) | `mosaik-table-footer-cell` | 27 |
| [tableFooterRow](COMPONENTS.soho.md#table-footer-row) | `mosaik-table-footer-row` | 28 |
| [tableHeader](COMPONENTS.soho.md#table-header) | `mosaik-table-header` | 28 |
| [tableHeaderCell](COMPONENTS.soho.md#table-header-cell) | `mosaik-table-header-cell` | 31 |
| [tableHeaderRow](COMPONENTS.soho.md#table-header-row) | `mosaik-table-header-row` | 28 |
| [text](COMPONENTS.soho.md#text) | `mosaik-text` | 34 |
| [textBox](COMPONENTS.soho.md#textbox) | `mosaik-textbox` | 67 |
| [textEffect](COMPONENTS.soho.md#text-effect) | `mosaik-text-effect` | 19 |
| [textFormat](COMPONENTS.soho.md#text-format) | `mosaik-text-format` | 22 |
| [thumb](COMPONENTS.soho.md#thumb) | `mosaik-thumb` | 27 |
| [thumbnail](COMPONENTS.soho.md#thumbnail) | `mosaik-thumbnail` | 23 |
| [tickBar](COMPONENTS.soho.md#tick-bar) | `mosaik-tick-bar` | 32 |
| [tile](COMPONENTS.soho.md#tile) | `mosaik-tile` | 34 |
| [tileList](COMPONENTS.soho.md#tile-list) | `mosaik-tile-list` | 23 |
| [tileListItem](COMPONENTS.soho.md#tile-list-item) | `mosaik-tile-list-item` | 29 |
| [tileManager](COMPONENTS.soho.md#tile-manager) | `mosaik-tile-manager` | 23 |
| [tileManagerTile](COMPONENTS.soho.md#tile-manager-tile) | `mosaik-tile-manager-tile` | 52 |
| [timeBox](COMPONENTS.soho.md#timebox) | `mosaik-timebox` | 41 |
| [timeline](COMPONENTS.soho.md#timeline) | `mosaik-timeline` | 31 |
| [timelineContent](COMPONENTS.soho.md#timeline-content) | `mosaik-timeline-content` | 23 |
| [timelineItem](COMPONENTS.soho.md#timeline-item) | `mosaik-timeline-item` | 30 |
| [timelineMarker](COMPONENTS.soho.md#timeline-marker) | `mosaik-timeline-marker` | 27 |
| [timelineOpposite](COMPONENTS.soho.md#timeline-opposite) | `mosaik-timeline-opposite` | 23 |
| [timelineSeparator](COMPONENTS.soho.md#timeline-separator) | `mosaik-timeline-separator` | 25 |
| [titleBar](COMPONENTS.soho.md#title-bar) | `mosaik-title-bar` | 22 |
| [titleLayout](COMPONENTS.soho.md#title-layout) | `mosaik-title-layout` | 23 |
| [toast](COMPONENTS.soho.md#toast) | `mosaik-toast` | 42 |
| [toastActions](COMPONENTS.soho.md#toast-actions) | `mosaik-toast-actions` | 22 |
| [toggleButton](COMPONENTS.soho.md#toggle-button) | `mosaik-toggle-button` | 42 |
| [toggleButtonGroup](COMPONENTS.soho.md#toggle-button-group) | `mosaik-toggle-button-group` | 28 |
| [toggleSwitch](COMPONENTS.soho.md#toggle-switch) | `mosaik-toggle-switch` | 27 |
| [toggletip](COMPONENTS.soho.md#toggletip) | `mosaik-toggletip` | 24 |
| [toolbar](COMPONENTS.soho.md#toolbar) | `mosaik-toolbar` | 30 |
| [tooltip](COMPONENTS.soho.md#tooltip) | `mosaik-tooltip` | 29 |
| [tour](COMPONENTS.soho.md#tour) | `mosaik-tour` | 30 |
| [tourAnchor](COMPONENTS.soho.md#tour-anchor) | `mosaik-tour-anchor` | 24 |
| [tourNav](COMPONENTS.soho.md#tour-nav) | `mosaik-tour-nav` | 31 |
| [tourStep](COMPONENTS.soho.md#tour-step) | `mosaik-tour-step` | 34 |
| [tree](COMPONENTS.soho.md#tree) | `mosaik-tree` | 22 |
| [treeItem](COMPONENTS.soho.md#tree-item) | `mosaik-tree-item` | 31 |
| [upDownSpinner](COMPONENTS.soho.md#updown-spinner) | `mosaik-updown-spinner` | 22 |
| [video](COMPONENTS.soho.md#video) | `mosaik-video` | 36 |
| [virtualize](COMPONENTS.soho.md#virtualize) | `mosaik-virtualize` | 22 |
| [walletCard](COMPONENTS.soho.md#wallet-card) | `mosaik-wallet-card` | 53 |
| [wheelPicker](COMPONENTS.soho.md#wheel-picker) | `mosaik-wheel-picker` | 29 |
| [wizard](COMPONENTS.soho.md#wizard) | `mosaik-wizard` | 23 |
| [wizardStep](COMPONENTS.soho.md#wizard-step) | `mosaik-wizard-step` | 22 |
| [wrap](COMPONENTS.soho.md#wrap) | `mosaik-wrap` | 22 |
<!-- /design-md:component-index -->

## Do's and Don'ts

### Do

- Consume `--mosaik-*` custom properties for anything you paint yourself; never copy a literal.
- Change a value in `libs/mosaik-themes/tokens/`, not in a component stylesheet, and add a new
  token to all four themes at once.
- Take shadcn values through the Soho helpers (`get-space()`, `get-radius()`, `get-shadow()`,
  `get-focus-ring()`, `get-alpha()`), never as literals.
- Keep one primary (solid) action per view; use outline, soft and plain for the rest.
- Load Inter on every page that renders Soho (code uses the system monospace stack).

### Don't

- Don't add gradients, glows or coloured shadows; shadcn surfaces are flat.
- Don't move anything on hover or press.
- Don't uppercase labels or use heavy weights for controls; `text-sm` medium is the control voice.
- Don't pass numbers to `size` or `elevation`.
- Don't hard-code a color, spacing, radius, border or shadow.

### Named anti-patterns

- **Joy in disguise**: warm grey canvases, 2px borders and ripple blobs under the Soho name.
- **Mixed styles**: values from shadcn's other styles (Nova, Maia, Lyra, Mira, Luma, Sera, Rhea) or the
  legacy New York - Soho is Vega only.
- **Coloured chrome**: tinting borders, shadows or the page with the primary colour.

## Known gaps

Generated from the same sources as the tables above; a finding here is a finding about the theme,
not about this document. The per-component status (shadcn reference or derivation, checked states,
remaining deviations) is tracked in [INVENTORY.soho.md](INVENTORY.soho.md).

<!-- design-md:gaps -->

### Theme references that resolve to nothing (0)

Component tokens pointing at theme properties that neither the compiled stylesheet nor `ThemeService` declares. The property is empty at runtime and the browser falls back to its initial value.

_none_

### References into other components (2)

These resolve only when the referenced component provides the property at runtime (a list item inside a list, a thumb inside a slider). Outside that context they are empty.

`--data-table-cell-height` (1), `--pulse-ring-color` (1)

### Stylesheet properties the reference theme declares and this one does not (0 families)

Compared between the compiled `<theme>-style()` stylesheets; Joy is the reference theme, and Joy itself is compared against the names Memphis and Cosmopolitan agree on. With a `Theme2` / `provideTheme()` provider `ThemeService` writes these names from the theme object anyway; a page that loads only the stylesheet has them empty.

_none_

### Token files without a consuming component

`tokens/themes/soho/components/accordion.json`, `tokens/themes/soho/components/alert.json`, `tokens/themes/soho/components/cardStack.json`, `tokens/themes/soho/components/dotGroup.json`, `tokens/themes/soho/components/gaugeInset.json`, `tokens/themes/soho/components/numberTicker.json`, `tokens/themes/soho/components/orbit.json`, `tokens/themes/soho/components/pulse.json`, `tokens/themes/soho/components/router.json`, `tokens/themes/soho/components/routerAnchor.json`, `tokens/themes/soho/components/routerLink.json`, `tokens/themes/soho/components/routerOutlet.json`, `tokens/themes/soho/components/slider2Thumb.json`, `tokens/themes/soho/components/textEffect.json` define tokens no foundation component reads through its theme stylesheet.

### Token files consumed by more than one component

`tokens/themes/soho/components/text.json` is read by 2 components; the export uses the `mosaik-text` prefix.

### Token files that feed the same custom property prefix

_none_

### Enum tokens missing from the theme file

_none_
<!-- /design-md:gaps -->

## Sources

| What                       | Where                                                                                                   |
| -------------------------- | ------------------------------------------------------------------------------------------------------- |
| Global tokens              | `libs/mosaik-themes/tokens/themes/soho/soho.json`, `tokens/themes/tokens.json`          |
| Component tokens           | `libs/mosaik-themes/tokens/themes/soho/components/*.json`, mixins in `tokens/mixins/`          |
| Component anatomy          | `libs/mosaik-elements-foundation/src/controls/components/**/themes/*.Soho.scss`                |
| Compiled tokens            | `libs/mosaik-themes/dist/themes/___soho-tokens.css`, `dist/themes/soho.scss`           |
| Runtime aliases            | `libs/mosaik-elements-foundation/src/theming/ThemeService.ts`                                           |
| Token model                | `.docs/design/tokens.md`, `.docs/design/tokens/1.token-schema-reference.md`                             |
| Component reference        | `apps/frontend/mosaik-showcase/public/llms/mosaik-<tag>.md`                                             |
| Regenerate                 | `yarn nx run mosaik-themes:build && yarn nx run mosaik-themes:design-md`                                |
| Verify                     | `yarn nx run mosaik-themes:design-md:check`                                                             |
