---
version: 'alpha'
name: 'Mosaik Cosmopolitan'
description: 'Light-mode value snapshot of the Cosmopolitan theme: modern Metro with a cyan accent, light Segoe UI display type, hairlines and matte dark-to-light gradients on controls, two-layer ambient shadows on overlays. Consume the --mosaik-* custom properties, never these literals.'
colors:
  primary: '{colors.mosaik-color-primary-500}'
  mosaik-scheme-surface: '#ffffff'
  mosaik-scheme-background: '#ffffff'
  mosaik-scheme-foreground: '#000000'
  mosaik-scheme-highlight: '#e2e2e2'
  mosaik-scheme-middlelight: '#8a8a8a'
  mosaik-scheme-lowlight: '#4d4d4d'
  mosaik-scheme-transparent: 'rgba(255, 255, 255, 0)'
  mosaik-scheme-semi-transparent: 'rgba(255, 255, 255, 0.6666666666666666)'
  mosaik-scheme-disabled: '#b2b2b2'
  mosaik-scheme-contrast: '#ffffff'
  mosaik-scheme-selection: '#c6e7f8'
  mosaik-color-primary-0: '#ffffff'
  mosaik-color-primary-50: '#e4f4fc'
  mosaik-color-primary-100: '#bbe3f6'
  mosaik-color-primary-200: '#8dd0f1'
  mosaik-color-primary-300: '#5fbdeb'
  mosaik-color-primary-400: '#3dafe6'
  mosaik-color-primary-500: '#1ba1e2'
  mosaik-color-primary-600: '#178cc5'
  mosaik-color-primary-700: '#13719e'
  mosaik-color-primary-800: '#0f577a'
  mosaik-color-primary-900: '#072839'
  mosaik-color-secondary-0: '#ffffff'
  mosaik-color-secondary-50: '#fae0ee'
  mosaik-color-secondary-100: '#f3b3d5'
  mosaik-color-secondary-200: '#ec80b9'
  mosaik-color-secondary-300: '#e44d9d'
  mosaik-color-secondary-400: '#de2688'
  mosaik-color-secondary-500: '#d80073'
  mosaik-color-secondary-600: '#bc0064'
  mosaik-color-secondary-700: '#970051'
  mosaik-color-secondary-800: '#75003e'
  mosaik-color-secondary-900: '#36001d'
  mosaik-color-tertiary-0: '#ffffff'
  mosaik-color-tertiary-50: '#feede0'
  mosaik-color-tertiary-100: '#fed2b3'
  mosaik-color-tertiary-200: '#fdb480'
  mosaik-color-tertiary-300: '#fc954d'
  mosaik-color-tertiary-400: '#fb7f26'
  mosaik-color-tertiary-500: '#fa6800'
  mosaik-color-tertiary-600: '#da5a00'
  mosaik-color-tertiary-700: '#af4900'
  mosaik-color-tertiary-800: '#873800'
  mosaik-color-tertiary-900: '#3f1a00'
  mosaik-color-info-0: '#ffffff'
  mosaik-color-info-50: '#e0eafd'
  mosaik-color-info-100: '#b3cbfa'
  mosaik-color-info-200: '#80a8f7'
  mosaik-color-info-300: '#4d85f4'
  mosaik-color-info-400: '#266af1'
  mosaik-color-info-500: '#0050ef'
  mosaik-color-info-600: '#0046d0'
  mosaik-color-info-700: '#0038a7'
  mosaik-color-info-800: '#002b81'
  mosaik-color-info-900: '#00143c'
  mosaik-color-warning-0: '#ffffff'
  mosaik-color-warning-50: '#fdf4e2'
  mosaik-color-warning-100: '#fbe3b6'
  mosaik-color-warning-200: '#f8d185'
  mosaik-color-warning-300: '#f5bf54'
  mosaik-color-warning-400: '#f2b12f'
  mosaik-color-warning-500: '#f0a30a'
  mosaik-color-warning-600: '#d18e09'
  mosaik-color-warning-700: '#a87207'
  mosaik-color-warning-800: '#825805'
  mosaik-color-warning-900: '#3c2903'
  mosaik-color-danger-0: '#ffffff'
  mosaik-color-danger-50: '#fce3e0'
  mosaik-color-danger-100: '#f7b9b3'
  mosaik-color-danger-200: '#f28a80'
  mosaik-color-danger-300: '#ed5b4d'
  mosaik-color-danger-400: '#e93726'
  mosaik-color-danger-500: '#e51400'
  mosaik-color-danger-600: '#c71100'
  mosaik-color-danger-700: '#a00e00'
  mosaik-color-danger-800: '#7c0b00'
  mosaik-color-danger-900: '#390500'
  mosaik-color-success-0: '#ffffff'
  mosaik-color-success-50: '#e7f3e7'
  mosaik-color-success-100: '#c2e0c2'
  mosaik-color-success-200: '#99cc99'
  mosaik-color-success-300: '#70b870'
  mosaik-color-success-400: '#52a852'
  mosaik-color-success-500: '#339933'
  mosaik-color-success-600: '#2c852c'
  mosaik-color-success-700: '#246b24'
  mosaik-color-success-800: '#1c531c'
  mosaik-color-success-900: '#0d260d'
  mosaik-color-highlight-0: '#ffffff'
  mosaik-color-highlight-50: '#f5e0ff'
  mosaik-color-highlight-100: '#e6b3ff'
  mosaik-color-highlight-200: '#d580ff'
  mosaik-color-highlight-300: '#c44dff'
  mosaik-color-highlight-400: '#b726ff'
  mosaik-color-highlight-500: '#aa00ff'
  mosaik-color-highlight-600: '#9400de'
  mosaik-color-highlight-700: '#7700b3'
  mosaik-color-highlight-800: '#5c008a'
  mosaik-color-highlight-900: '#2b0040'
  mosaik-color-neutral-0: '#ffffff'
  mosaik-color-neutral-50: '#eeeeee'
  mosaik-color-neutral-100: '#d5d5d5'
  mosaik-color-neutral-200: '#b9b9b9'
  mosaik-color-neutral-300: '#9d9d9d'
  mosaik-color-neutral-400: '#888888'
  mosaik-color-neutral-500: '#737373'
  mosaik-color-neutral-600: '#646464'
  mosaik-color-neutral-700: '#515151'
  mosaik-color-neutral-800: '#3e3e3e'
  mosaik-color-neutral-900: '#1d1d1d'
typography:
  mosaik-typography-headline1:
    fontFamily: '''Segoe UI'', ''Noto Sans'', sans-serif'
    fontSize: '64px'
    fontWeight: 300
    lineHeight: '72px'
    letterSpacing: '-1px'
  mosaik-typography-headline2:
    fontFamily: '''Segoe UI'', ''Noto Sans'', sans-serif'
    fontSize: '48px'
    fontWeight: 300
    lineHeight: '56px'
    letterSpacing: '-0.5px'
  mosaik-typography-headline3:
    fontFamily: '''Segoe UI'', ''Noto Sans'', sans-serif'
    fontSize: '40px'
    fontWeight: 300
    lineHeight: '48px'
    letterSpacing: '-0.25px'
  mosaik-typography-headline4:
    fontFamily: '''Segoe UI'', ''Noto Sans'', sans-serif'
    fontSize: '32px'
    fontWeight: 300
    lineHeight: '40px'
  mosaik-typography-headline5:
    fontFamily: '''Segoe UI'', ''Noto Sans'', sans-serif'
    fontSize: '24px'
    fontWeight: 300
    lineHeight: '32px'
  mosaik-typography-headline6:
    fontFamily: '''Segoe UI'', ''Noto Sans'', sans-serif'
    fontSize: '20px'
    fontWeight: 400
    lineHeight: '28px'
  mosaik-typography-subtitle1:
    fontFamily: '''Segoe UI'', ''Noto Sans'', sans-serif'
    fontSize: '16px'
    fontWeight: 400
    lineHeight: '22px'
  mosaik-typography-subtitle2:
    fontFamily: '''Segoe UI'', ''Noto Sans'', sans-serif'
    fontSize: '14px'
    fontWeight: 600
    lineHeight: '20px'
  mosaik-typography-body1:
    fontFamily: '''Segoe UI'', ''Noto Sans'', sans-serif'
    fontSize: '16px'
    fontWeight: 400
    lineHeight: '22px'
  mosaik-typography-body2:
    fontFamily: '''Segoe UI'', ''Noto Sans'', sans-serif'
    fontSize: '14px'
    fontWeight: 400
    lineHeight: '20px'
  mosaik-typography-supporting:
    fontFamily: '''Segoe UI'', ''Noto Sans'', sans-serif'
    fontSize: '12px'
    fontWeight: 400
    lineHeight: '16px'
  mosaik-typography-caption:
    fontFamily: '''Segoe UI'', ''Noto Sans'', sans-serif'
    fontSize: '12px'
    fontWeight: 400
    lineHeight: '16px'
  mosaik-typography-overline:
    fontFamily: '''Segoe UI'', ''Noto Sans'', sans-serif'
    fontSize: '11px'
    fontWeight: 600
    lineHeight: '14px'
    letterSpacing: '0.8px'
  mosaik-typography-button:
    fontFamily: '''Segoe UI'', ''Noto Sans'', sans-serif'
    fontSize: '13px'
    fontWeight: 700
    lineHeight: '16px'
    letterSpacing: '0.5px'
rounded:
  mosaik-layout-radius: '2px'
spacing:
  mosaik-layout-space: '8px'
  mosaik-layout-thickness: '1px'
  mosaik-size-tiny: '2px'
  mosaik-size-small: '4px'
  mosaik-size-medium: '8px'
  mosaik-size-large: '16px'
  mosaik-size-giant: '32px'
components:
  button:
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    height: '40px'
    typography: '{typography.mosaik-typography-button}'
  button-disabled:
    textColor: '{colors.mosaik-scheme-disabled}'
  button-outline:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
  button-outline-active:
    backgroundColor: '{colors.mosaik-color-neutral-200}'
  button-outline-disabled:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  button-outline-hover:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
  button-plain:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
  button-plain-active:
    backgroundColor: '{colors.mosaik-color-neutral-200}'
  button-plain-disabled:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  button-plain-hover:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
  button-soft:
    textColor: '{colors.mosaik-scheme-foreground}'
  button-solid:
    textColor: '{colors.mosaik-scheme-surface}'
  toggle-button:
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    typography: '{typography.mosaik-typography-button}'
  toggle-button-disabled:
    textColor: '{colors.mosaik-scheme-disabled}'
  toggle-button-outline:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
  toggle-button-outline-active:
    backgroundColor: '{colors.mosaik-color-neutral-200}'
  toggle-button-outline-disabled:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  toggle-button-outline-hover:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
  toggle-button-plain:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
  toggle-button-plain-active:
    backgroundColor: '{colors.mosaik-color-neutral-200}'
  toggle-button-plain-disabled:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  toggle-button-plain-hover:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
  toggle-button-soft:
    textColor: '{colors.mosaik-scheme-foreground}'
  toggle-button-solid:
    textColor: '{colors.mosaik-scheme-surface}'
  anchor:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-color-primary-700}'
    typography: '{typography.mosaik-typography-body2}'
  anchor-active:
    textColor: '{colors.mosaik-color-primary-800}'
  anchor-disabled:
    textColor: '{colors.mosaik-scheme-disabled}'
  anchor-primary-active:
    textColor: '{colors.mosaik-color-primary-800}'
  badge:
    backgroundColor: '{colors.mosaik-scheme-background}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    typography: '{typography.mosaik-typography-overline}'
  badge-disabled:
    textColor: '{colors.mosaik-scheme-disabled}'
  badge-outline:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-color-neutral-700}'
  badge-outline-primary:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  badge-plain:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-color-neutral-700}'
  badge-plain-primary:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  badge-soft:
    backgroundColor: '{colors.mosaik-color-neutral-100}'
    textColor: '{colors.mosaik-color-neutral-700}'
  badge-soft-primary:
    backgroundColor: '{colors.mosaik-color-primary-50}'
  badge-solid:
    backgroundColor: '{colors.mosaik-scheme-foreground}'
    textColor: '{colors.mosaik-scheme-background}'
  badge-tiny:
    padding: '4px'
  chip:
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    height: '28px'
    typography: '{typography.mosaik-typography-body2}'
  chip-disabled:
    textColor: '{colors.mosaik-scheme-disabled}'
  chip-outline:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  chip-outline-disabled:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  chip-plain:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  chip-plain-disabled:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  chip-soft:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
  chip-solid:
    backgroundColor: '{colors.mosaik-scheme-foreground}'
    textColor: '{colors.mosaik-scheme-surface}'
  avatar:
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '1998px'
  avatar-disabled:
    textColor: '{colors.mosaik-scheme-disabled}'
  avatar-plain:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  avatar-plain-disabled:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  persona:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '1998px'
  card:
    backgroundColor: '{colors.mosaik-scheme-surface}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    typography: '{typography.mosaik-typography-body1}'
  card-disabled:
    textColor: '{colors.mosaik-scheme-disabled}'
  card-plain:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  card-plain-disabled:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  card-header:
    padding: '16px'
  card-content:
    padding: '16px'
  textbox:
    backgroundColor: '{colors.mosaik-scheme-surface}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    height: '40px'
    typography: '{typography.mosaik-typography-body1}'
  textbox-disabled:
    textColor: '{colors.mosaik-scheme-disabled}'
  textbox-outline:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  textbox-plain:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  textbox-plain-disabled:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  textbox-plain-readonly:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  textbox-soft-primary:
    backgroundColor: '{colors.mosaik-color-primary-50}'
  textbox-solid:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
  textbox-solid-primary:
    backgroundColor: '{colors.mosaik-color-primary-100}'
  searchbox:
    backgroundColor: '{colors.mosaik-scheme-surface}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    height: '40px'
    typography: '{typography.mosaik-typography-body1}'
  searchbox-disabled:
    textColor: '{colors.mosaik-scheme-disabled}'
  searchbox-outline:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  searchbox-plain:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  searchbox-plain-disabled:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  searchbox-plain-readonly:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  searchbox-soft-primary:
    backgroundColor: '{colors.mosaik-color-primary-50}'
  searchbox-solid:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
  searchbox-solid-primary:
    backgroundColor: '{colors.mosaik-color-primary-100}'
  select:
    backgroundColor: '{colors.mosaik-scheme-surface}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    height: '40px'
    typography: '{typography.mosaik-typography-body1}'
  select-disabled:
    textColor: '{colors.mosaik-scheme-disabled}'
  select-outline:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  select-plain:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  select-plain-disabled:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  select-soft-primary:
    backgroundColor: '{colors.mosaik-color-primary-50}'
  select-solid:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
  select-solid-primary:
    backgroundColor: '{colors.mosaik-color-primary-100}'
  select-item:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '0px'
    typography: '{typography.mosaik-typography-body2}'
  select-item-active:
    backgroundColor: '{colors.mosaik-color-primary-50}'
    textColor: '{colors.mosaik-color-primary-700}'
  select-item-active-hover:
    backgroundColor: '{colors.mosaik-color-primary-100}'
  select-item-disabled:
    textColor: '{colors.mosaik-scheme-disabled}'
  select-item-primary-active:
    backgroundColor: '{colors.mosaik-color-primary-50}'
  select-item-primary-active-hover:
    backgroundColor: '{colors.mosaik-color-primary-100}'
  select-item-primary-selected:
    backgroundColor: '{colors.mosaik-color-primary-50}'
  select-item-primary-selected-hover:
    backgroundColor: '{colors.mosaik-color-primary-100}'
  select-item-selected:
    backgroundColor: '{colors.mosaik-color-primary-50}'
    textColor: '{colors.mosaik-color-primary-700}'
  select-item-selected-hover:
    backgroundColor: '{colors.mosaik-color-primary-100}'
  checkbox:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    typography: '{typography.mosaik-typography-body1}'
  radio:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '1998px'
    typography: '{typography.mosaik-typography-body1}'
  toggle-switch:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    padding: '2px'
    typography: '{typography.mosaik-typography-body1}'
  slider:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    padding: '0px'
    typography: '{typography.mosaik-typography-body1}'
  list:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    typography: '{typography.mosaik-typography-body1}'
  list-item:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    typography: '{typography.mosaik-typography-body1}'
  list-item-active:
    backgroundColor: '{colors.mosaik-color-primary-50}'
    textColor: '{colors.mosaik-scheme-foreground}'
  list-item-active-hover:
    backgroundColor: '{colors.mosaik-color-primary-100}'
  list-item-checked:
    backgroundColor: '{colors.mosaik-color-primary-50}'
    textColor: '{colors.mosaik-scheme-foreground}'
  list-item-checked-hover:
    backgroundColor: '{colors.mosaik-color-primary-100}'
  list-item-disabled:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-disabled}'
  list-item-primary-active:
    backgroundColor: '{colors.mosaik-color-primary-50}'
  list-item-primary-active-hover:
    backgroundColor: '{colors.mosaik-color-primary-100}'
  list-item-primary-checked:
    backgroundColor: '{colors.mosaik-color-primary-50}'
  list-item-primary-checked-hover:
    backgroundColor: '{colors.mosaik-color-primary-100}'
  list-item-primary-selected:
    backgroundColor: '{colors.mosaik-color-primary-50}'
  list-item-primary-selected-hover:
    backgroundColor: '{colors.mosaik-color-primary-100}'
  list-item-selected:
    backgroundColor: '{colors.mosaik-color-primary-50}'
    textColor: '{colors.mosaik-scheme-foreground}'
  list-item-selected-hover:
    backgroundColor: '{colors.mosaik-color-primary-100}'
  menu:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    padding: '4px'
    typography: '{typography.mosaik-typography-body1}'
  menu-item:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    height: '40px'
    typography: '{typography.mosaik-typography-body1}'
  menu-item-active:
    backgroundColor: '{colors.mosaik-color-primary-50}'
    textColor: '{colors.mosaik-scheme-foreground}'
  menu-item-active-hover:
    backgroundColor: '{colors.mosaik-color-primary-100}'
  menu-item-checked:
    backgroundColor: '{colors.mosaik-color-primary-50}'
    textColor: '{colors.mosaik-scheme-foreground}'
  menu-item-checked-hover:
    backgroundColor: '{colors.mosaik-color-primary-100}'
  menu-item-disabled:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-disabled}'
  menu-item-plain-primary-hover:
    backgroundColor: '{colors.mosaik-color-primary-50}'
  menu-item-primary-active:
    backgroundColor: '{colors.mosaik-color-primary-50}'
  menu-item-primary-active-hover:
    backgroundColor: '{colors.mosaik-color-primary-100}'
  menu-item-primary-checked:
    backgroundColor: '{colors.mosaik-color-primary-50}'
  menu-item-primary-checked-hover:
    backgroundColor: '{colors.mosaik-color-primary-100}'
  menu-item-primary-selected:
    backgroundColor: '{colors.mosaik-color-primary-50}'
  menu-item-primary-selected-hover:
    backgroundColor: '{colors.mosaik-color-primary-100}'
  menu-item-selected:
    backgroundColor: '{colors.mosaik-color-primary-50}'
    textColor: '{colors.mosaik-scheme-foreground}'
  menu-item-selected-hover:
    backgroundColor: '{colors.mosaik-color-primary-100}'
  tab:
    backgroundColor: '{colors.mosaik-scheme-surface}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    typography: '{typography.mosaik-typography-body1}'
  tab-disabled:
    textColor: '{colors.mosaik-scheme-disabled}'
  tab-outline:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  tab-plain:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  tab-solid:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
  tab-item:
    rounded: '{rounded.mosaik-layout-radius}'
  tooltip:
    backgroundColor: '{colors.mosaik-scheme-surface}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    typography: '{typography.mosaik-typography-caption}'
  dialog:
    backgroundColor: '{colors.mosaik-scheme-surface}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    typography: '{typography.mosaik-typography-body1}'
  drawer:
    backgroundColor: '{colors.mosaik-scheme-surface}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    width: '320px'
    padding: '16px'
    typography: '{typography.mosaik-typography-body1}'
  toast:
    backgroundColor: '{colors.mosaik-scheme-surface}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    typography: '{typography.mosaik-typography-body1}'
  toast-outline:
    backgroundColor: '{colors.mosaik-scheme-surface}'
    textColor: '{colors.mosaik-scheme-foreground}'
  toast-plain:
    backgroundColor: '{colors.mosaik-scheme-surface}'
    textColor: '{colors.mosaik-scheme-foreground}'
  toast-soft:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
    textColor: '{colors.mosaik-scheme-foreground}'
  toast-soft-primary:
    backgroundColor: '{colors.mosaik-color-primary-100}'
  toast-solid:
    backgroundColor: '{colors.mosaik-scheme-foreground}'
    textColor: '{colors.mosaik-scheme-background}'
  banner:
    backgroundColor: '{colors.mosaik-scheme-surface}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    typography: '{typography.mosaik-typography-body1}'
  banner-disabled:
    textColor: '{colors.mosaik-scheme-disabled}'
  banner-plain:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  banner-plain-disabled:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  divider:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
    textColor: '{colors.mosaik-scheme-foreground}'
    typography: '{typography.mosaik-typography-supporting}'
  skeleton:
    rounded: '{rounded.mosaik-layout-radius}'
  expander:
    backgroundColor: '{colors.mosaik-scheme-surface}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    typography: '{typography.mosaik-typography-body1}'
  expander-disabled:
    textColor: '{colors.mosaik-scheme-disabled}'
  expander-plain:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  breadcrumb-item:
    textColor: '{colors.mosaik-color-primary-700}'
    padding: '0px'
    typography: '{typography.mosaik-typography-body2}'
  breadcrumb-item-active:
    textColor: '{colors.mosaik-scheme-foreground}'
  breadcrumb-item-disabled:
    textColor: '{colors.mosaik-scheme-disabled}'
  app-header:
    backgroundColor: '{colors.mosaik-scheme-surface}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    typography: '{typography.mosaik-typography-headline6}'
  text:
    backgroundColor: 'transparent'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '0px'
    padding: '0px'
    typography: '{typography.mosaik-typography-body1}'
  text-disabled:
    textColor: '{colors.mosaik-scheme-disabled}'
---

<!--
The YAML frontmatter and every `design-md:*` region of this file are generated by
libs/mosaik-themes/bin/design-md.mjs from the cosmopolitan token sources. Build the themes
package, then run `yarn nx run mosaik-themes:design-md`; `yarn nx run mosaik-themes:design-md:check`
fails while the generated parts have drifted. All other prose is hand-authored and must not be
generated away.

Format: DESIGN.md (https://github.com/google-labs-code/design.md), linted with @google/design.md.
-->

# Mosaik Cosmopolitan

## Overview

Cosmopolitan is Mosaik's **modern Metro** theme, the next evolution of the classic WPF
"Cosmopolitan" theme: a white canvas, a **cyan accent**, large **light** Segoe-style display type,
bold uppercase button labels, 1px hairlines and square-ish corners. Its identity detail is the
**dark-to-light gradient**: buttons, check boxes, radios, switches, slider thumbs and calendar navigation
buttons carry a soft diagonal sheen that is slightly darker at the top left and slightly lighter at
the bottom right - always from dark to light, faint and matte, never glossy - brighter on hover and
deeper when pressed. Surfaces stay flat and hairline-framed; only overlays
float on an ambient shadow. Where Joy is warm and Memphis is loud, Cosmopolitan is calm and precise,
for business applications, dashboards and content-heavy products.

Cosmopolitan carries its own component anatomy in the `*.Cosmopolitan.scss` theme stylesheets at
the same coverage as Joy: every component has its hover, pressed, focus, selected and disabled
states and renders every variant and appearance, in light and dark mode. The sheen is a translucent
layer over a token colour, built by the helpers in the theme bundle
(`src/themes/cosmopolitan/_Sheen.scss`), so it follows every variant, both modes and custom
palettes. Treat this document as the contract for the values and for the anatomy.

Mosaik **is** the design system. Only the **names** are fixed: a product overrides values through
`provideTheme()` / `Theme2` and every component follows, because components never read literals,
only tokens. Cosmopolitan is one of the three value sets Mosaik ships for that vocabulary.

Two token layers are fixed for this theme and captured in this document:

1. **The global set** from `tokens/themes/cosmopolitan/cosmopolitan.json` (merged with
   `tokens/themes/tokens.json`): scheme roles, nine color ramps, fourteen typography roles, layout
   rhythm, elevation, durations and the enum vocabularies, published as `--mosaik-*` custom
   properties and listed in the frontmatter as a light-mode snapshot.
2. **The component set**: one token file per component under
   `tokens/themes/cosmopolitan/components/`, expanded with the shared mixins. Every entry becomes a
   `--<component>-<token>` custom property on the component's shadow host and is public styling
   API. The complete export, resolved to literals, is [COMPONENTS.cosmopolitan.md](COMPONENTS.cosmopolitan.md); the core
   atoms are also projected into the `components` block of the frontmatter.

Consumers never address a theme by its own prefix. The outward contract is the `--mosaik-*`
family: `ThemeService`, driven by `Theme2` or `provideTheme()`, remaps it onto the active theme's
internal `--<theme>-*` properties, which is what lets every theme, and every product built on one,
be used generically from outside.

Use this precedence whenever sources disagree:

1. The token sources in `libs/mosaik-themes/tokens/` and the component theme stylesheets.
2. The compiled artifacts (`dist/themes/___cosmopolitan-tokens.css`, `cosmopolitan-style()`) and
   the runtime `--mosaik-*` / `--cosmopolitan-*` properties.
3. This document and [COMPONENTS.cosmopolitan.md](COMPONENTS.cosmopolitan.md).

### At a glance

<!-- design-md:stats -->

| Layer | Count | Source |
|---|---|---|
| Global tokens (compiled) | 507 | `dist/themes/___cosmopolitan-tokens.css` |
| Runtime custom properties (light) | 653 | `cosmopolitan-style()` and `ThemeService` |
| Components with a token file | 378 | `tokens/themes/cosmopolitan/components/` |
| Component tokens (mixins expanded) | 11097 | `src/themes/cosmopolitan/_components/` |
| Component tokens that do not resolve | 3 | [Known gaps](#known-gaps) |
<!-- /design-md:stats -->

### Activating the theme

The theme is selected by the `theme` attribute on `<html>` and the mode by `theme-mode`; both have
to be in place before any element module evaluates. Cosmopolitan is set in **Segoe UI** where it
is installed and falls back to **Noto Sans**; load Noto Sans (weights 300-700) for every other
platform, nothing in the theme ships a `@font-face`.

```html
<html lang="en" theme="cosmopolitan" theme-mode="light">
  <head>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans:wght@300;400;500;700&display=swap" rel="stylesheet" />
    <script type="module">
      import { CosmopolitanTheme, ThemeObserverServiceLocator } from 'https://esm.run/@pixel-brewery/mosaik-themes';
      const root = document.documentElement;
      ThemeObserverServiceLocator.current.applyTheme(root.getAttribute('theme') ?? 'cosmopolitan', root.getAttribute('theme-mode') ?? 'light');
      await customElements.whenDefined('mosaik-theme2');
      document.querySelector('mosaik-theme2').theme = CosmopolitanTheme.COSMOPOLITAN_THEME;
    </script>
    <script type="module" src="https://esm.run/@pixel-brewery/mosaik-elements-foundation"></script>
  </head>
  <body>
    <mosaik-theme2>
      <mosaik-button label="Subscribe" variant="primary" appearance="solid"></mosaik-button>
    </mosaik-theme2>
  </body>
</html>
```

In a framework app the same happens through `provideTheme()` (Angular) or
`<Theme2 theme={cosmopolitanTheme} global>` (React). Your own markup gets no font or color by
default: set `font-family: var(--mosaik-font-family)`, `color: var(--mosaik-scheme-foreground)` and
`background: var(--mosaik-scheme-background)` on `body`.

## Colors

Cosmopolitan is **white and cyan**. The page and panels are white (`background`, `surface`), text
is true black, separation comes from a light grey hairline (`highlight`, `#e2e2e2`), secondary text
is `middlelight` (`#8a8a8a`), tertiary text `lowlight` (`#4d4d4d`) and disabled content a light grey
(`#b2b2b2`). The text selection is a pale cyan (`#c6e7f8`). Dark mode is charcoal: a `#1f1f1f` page,
`#2b2b2b` panels, white text, a lifted `#4a4a4a` hairline and a deep cyan selection.

The nine ramps follow the Metro palette: **cyan `primary`** (`#1ba1e2`), magenta `secondary`,
orange `tertiary`, cobalt `info`, amber `warning`, red `danger`, green `success`, violet `highlight`
and a grey `neutral`, mixed from their `500` seed with the same algorithm the ThemeGenerator uses for
custom palettes (the dark palette is inverted). Accent fills (solid buttons, checked marks, the
selected item, progress) read the **light** palette through `get-accent()` and keep their colour in
dark mode, as in Metro.

### Scheme roles

<!-- design-md:scheme -->

| Role | Custom property | Light | Dark | Purpose |
|---|---|---|---|---|
| `surface` | `--mosaik-scheme-surface` | `#ffffff` | `#2b2b2b` | Elevated surfaces: cards, dialogs, panels. |
| `background` | `--mosaik-scheme-background` | `#ffffff` | `#1f1f1f` | Page canvas and the default component fill. |
| `foreground` | `--mosaik-scheme-foreground` | `#000000` | `#ffffff` | Default text and icon color. |
| `highlight` | `--mosaik-scheme-highlight` | `#e2e2e2` | `#4a4a4a` | Borders, dividers, hover fills. |
| `middlelight` | `--mosaik-scheme-middlelight` | `#8a8a8a` | `#959595` | Medium contrast - strokes, dividers, inactive marks and quiet fills. |
| `lowlight` | `--mosaik-scheme-lowlight` | `#4d4d4d` | `#c2c2c2` | The stronger secondary grey - secondary text, placeholders, captions and hints. |
| `transparent` | `--mosaik-scheme-transparent` | `rgba(255, 255, 255, 0)` | `rgba(31, 31, 31, 0)` | Fully transparent fill. |
| `semi-transparent` | `--mosaik-scheme-semi-transparent` | `rgba(255, 255, 255, 0.6666666666666666)` | `rgba(31, 31, 31, 0.6666666666666666)` | Glass-like overlays and backdrops. |
| `disabled` | `--mosaik-scheme-disabled` | `#b2b2b2` | `#5e5e5e` | Disabled text and controls. |
| `contrast` | `--mosaik-scheme-contrast` | `#ffffff` | `#ffffff` | Content on strongly colored surfaces. |
| `selection` | `--mosaik-scheme-selection` | `#c6e7f8` | `#0d5578` | Text selection background. |
<!-- /design-md:scheme -->

### Color ramps

<!-- design-md:palette -->

Light mode (`--mosaik-color-<family>-<stop>` resolves to these while `theme-mode="light"`):

| Family | 0 | 50 | 100 | 200 | 300 | 400 | 500 | 600 | 700 | 800 | 900 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| `primary` | `#ffffff` | `#e4f4fc` | `#bbe3f6` | `#8dd0f1` | `#5fbdeb` | `#3dafe6` | `#1ba1e2` | `#178cc5` | `#13719e` | `#0f577a` | `#072839` |
| `secondary` | `#ffffff` | `#fae0ee` | `#f3b3d5` | `#ec80b9` | `#e44d9d` | `#de2688` | `#d80073` | `#bc0064` | `#970051` | `#75003e` | `#36001d` |
| `tertiary` | `#ffffff` | `#feede0` | `#fed2b3` | `#fdb480` | `#fc954d` | `#fb7f26` | `#fa6800` | `#da5a00` | `#af4900` | `#873800` | `#3f1a00` |
| `info` | `#ffffff` | `#e0eafd` | `#b3cbfa` | `#80a8f7` | `#4d85f4` | `#266af1` | `#0050ef` | `#0046d0` | `#0038a7` | `#002b81` | `#00143c` |
| `warning` | `#ffffff` | `#fdf4e2` | `#fbe3b6` | `#f8d185` | `#f5bf54` | `#f2b12f` | `#f0a30a` | `#d18e09` | `#a87207` | `#825805` | `#3c2903` |
| `danger` | `#ffffff` | `#fce3e0` | `#f7b9b3` | `#f28a80` | `#ed5b4d` | `#e93726` | `#e51400` | `#c71100` | `#a00e00` | `#7c0b00` | `#390500` |
| `success` | `#ffffff` | `#e7f3e7` | `#c2e0c2` | `#99cc99` | `#70b870` | `#52a852` | `#339933` | `#2c852c` | `#246b24` | `#1c531c` | `#0d260d` |
| `highlight` | `#ffffff` | `#f5e0ff` | `#e6b3ff` | `#d580ff` | `#c44dff` | `#b726ff` | `#aa00ff` | `#9400de` | `#7700b3` | `#5c008a` | `#2b0040` |
| `neutral` | `#ffffff` | `#eeeeee` | `#d5d5d5` | `#b9b9b9` | `#9d9d9d` | `#888888` | `#737373` | `#646464` | `#515151` | `#3e3e3e` | `#1d1d1d` |

Dark mode (the same names resolve to these while `theme-mode="dark"`):

| Family | 0 | 50 | 100 | 200 | 300 | 400 | 500 | 600 | 700 | 800 | 900 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| `primary` | `#000000` | `#041822` | `#083044` | `#0c4866` | `#106188` | `#1479aa` | `#1891cb` | `#1ba1e2` | `#5fbdeb` | `#84ccef` | `#c6e8f8` |
| `secondary` | `#000000` | `#200011` | `#410023` | `#610034` | `#820045` | `#a20056` | `#c20068` | `#d80073` | `#e44d9d` | `#ea75b3` | `#f5bfdc` |
| `tertiary` | `#000000` | `#261000` | `#4b1f00` | `#712f00` | `#963e00` | `#bc4e00` | `#e15e00` | `#fa6800` | `#fc954d` | `#fcad75` | `#fed9bf` |
| `info` | `#000000` | `#000c24` | `#001848` | `#00246c` | `#00308f` | `#003cb3` | `#0048d7` | `#0050ef` | `#4d85f4` | `#75a1f6` | `#bfd3fb` |
| `warning` | `#000000` | `#241802` | `#483103` | `#6c4905` | `#906206` | `#b47a08` | `#d89309` | `#f0a30a` | `#f5bf54` | `#f7cd7b` | `#fbe8c2` |
| `danger` | `#000000` | `#220300` | `#450600` | `#670900` | `#890c00` | `#ac0f00` | `#ce1200` | `#e51400` | `#ed5b4d` | `#f18075` | `#f9c4bf` |
| `success` | `#000000` | `#081708` | `#0f2e0f` | `#174517` | `#1f5c1f` | `#267326` | `#2e8a2e` | `#339933` | `#70b870` | `#91c891` | `#cce6cc` |
| `highlight` | `#000000` | `#1a0026` | `#33004d` | `#4d0073` | `#660099` | `#8000bf` | `#9900e6` | `#aa00ff` | `#c44dff` | `#d175ff` | `#eabfff` |
| `neutral` | `#000000` | `#111111` | `#232323` | `#343434` | `#454545` | `#565656` | `#686868` | `#737373` | `#9d9d9d` | `#b3b3b3` | `#dcdcdc` |
<!-- /design-md:palette -->

### How variant and appearance pick a stop

Chroma is rare: the `default` appearance ignores the variant, like Joy, and only the focus ring
takes the variant colour. The mapping is the button's (`ButtonElement.Cosmopolitan.scss`) and the
other button-like controls follow it; the frontmatter `components` block carries the projected
values for `primary`, and the same stops apply to every other variant. "Sheen" is the dark-to-light
gradient layer of `get-gradient()`; outline and plain stay flat.

| Appearance | Neutral (no variant)                                         | With a variant `v`                                        |
| ---------- | ------------------------------------------------------------ | --------------------------------------------------------- |
| `default`  | sheen over the control grey, `highlight` hairline, black bold uppercase label | as neutral (the variant only colours the focus ring) |
| `solid`    | sheen over `foreground` (black), `surface` text               | sheen over the accent `v-500`, white text, `v-600` line   |
| `soft`     | sheen over `highlight`, `foreground` text                     | sheen over `v-50`, text `v-700`, `v-200` line            |
| `outline`  | transparent, `middlelight` hairline, `foreground` text        | `v-500` hairline, text `v-700`                            |
| `plain`    | transparent, `foreground` text                                | text `v-700`                                              |

Hover brightens the sheen and darkens the hairline to `middlelight`; pressing inverts the sheen
(darker at the top), and a solid control drops to its `600` base. Outline and plain controls get a
flat `v-50` / `highlight` fill instead. Checked and selected controls take the accent (the variant,
or cyan `primary`) with white text. Disabled controls are flat: the control grey, a `highlight`
hairline and `disabled` text, without sheen. Nothing moves.

Fields are hairline boxes and stay flat: `highlight` at rest, `middlelight` on hover, and on focus
the line turns cyan (`primary-500`, or `v-500`) and is doubled by an inner 1px line, so the active
field reads as a crisp 2px frame. Fields read compact, as in Metro. Invalid fields use
`danger-500`, readonly fields the flat control grey, and `plain` fields keep only the bottom
hairline.

### Naming rules

- `--mosaik-scheme-<role>` and `--mosaik-color-<family>-<stop>` are the consumer contract, aliases
  that `ThemeService` writes on `<html>` pointing at the `--cosmopolitan-*` originals with the
  literal as fallback.
- Mode-specific names exist only under the theme prefix. Never introduce `dark-*` token names.
- Contrast: black on white is maximal. Text drawn in a variant colour on paper uses stop `700`;
  `500`/`600` are for fills, lines and rings. White on the Metro accents is the theme's reference
  look; keep it to buttons, tiles and badges.

## Typography

Cosmopolitan speaks **Segoe UI** (`'Segoe UI', 'Noto Sans', sans-serif`: Segoe on Windows, Noto
Sans elsewhere) in a Metro scale: **light (300)** headlines from a 64px `headline1` down to a 24px
`headline5`, used large and generously, with a regular 20px `headline6`. `body1` and `body2` are a
regular 16px and 14px, `subtitle2` is semibold, `caption` 12px. `button` is a **bold 13px,
uppercase** with 0.5px tracking, and `overline` the tiny uppercase caption above control groups
("TEXTBOX", "BUTTON"). Navigation reads as large light words.

The fourteen role names are the complete vocabulary; a product may change their values but must
not rename them or add roles. Each role publishes `--mosaik-typography-<role>` as a `font`
shorthand plus the individual parts, and per-role families default to `var(--font-family)`.

<!-- design-md:typography -->

| Role | Custom property | Family | Size | Line height | Weight | Letter spacing | Transform |
|---|---|---|---|---|---|---|---|
| `headline1` | `--mosaik-typography-headline1` | `'Segoe UI', 'Noto Sans', sans-serif` | `64px` | `72px` | `300` | `-1px` | `none` |
| `headline2` | `--mosaik-typography-headline2` | `'Segoe UI', 'Noto Sans', sans-serif` | `48px` | `56px` | `300` | `-0.5px` | `none` |
| `headline3` | `--mosaik-typography-headline3` | `'Segoe UI', 'Noto Sans', sans-serif` | `40px` | `48px` | `300` | `-0.25px` | `none` |
| `headline4` | `--mosaik-typography-headline4` | `'Segoe UI', 'Noto Sans', sans-serif` | `32px` | `40px` | `300` | `normal` | `none` |
| `headline5` | `--mosaik-typography-headline5` | `'Segoe UI', 'Noto Sans', sans-serif` | `24px` | `32px` | `300` | `normal` | `none` |
| `headline6` | `--mosaik-typography-headline6` | `'Segoe UI', 'Noto Sans', sans-serif` | `20px` | `28px` | `400` | `normal` | `none` |
| `subtitle1` | `--mosaik-typography-subtitle1` | `'Segoe UI', 'Noto Sans', sans-serif` | `16px` | `22px` | `400` | `normal` | `none` |
| `subtitle2` | `--mosaik-typography-subtitle2` | `'Segoe UI', 'Noto Sans', sans-serif` | `14px` | `20px` | `600` | `normal` | `none` |
| `body1` | `--mosaik-typography-body1` | `'Segoe UI', 'Noto Sans', sans-serif` | `16px` | `22px` | `400` | `normal` | `none` |
| `body2` | `--mosaik-typography-body2` | `'Segoe UI', 'Noto Sans', sans-serif` | `14px` | `20px` | `400` | `normal` | `none` |
| `supporting` | `--mosaik-typography-supporting` | `'Segoe UI', 'Noto Sans', sans-serif` | `12px` | `16px` | `400` | `normal` | `none` |
| `caption` | `--mosaik-typography-caption` | `'Segoe UI', 'Noto Sans', sans-serif` | `12px` | `16px` | `400` | `normal` | `none` |
| `overline` | `--mosaik-typography-overline` | `'Segoe UI', 'Noto Sans', sans-serif` | `11px` | `14px` | `600` | `0.8px` | `uppercase` |
| `button` | `--mosaik-typography-button` | `'Segoe UI', 'Noto Sans', sans-serif` | `13px` | `16px` | `700` | `0.5px` | `uppercase` |
<!-- /design-md:typography -->

## Layout

Cosmopolitan is **fine-lined**: an 8px base unit, a 1px stroke and a 2px radius. Every padding,
gap and margin is a `calc()` multiple of `layout.space`; every border, divider and indicator is
`layout.thickness` wide, which at 1px asks for the hairline to be drawn in a neutral grey and never
in a saturated color, except as a state (focus, selection, invalid).

<!-- design-md:layout -->

| Token | Custom property | Value | Role |
|---|---|---|---|
| `layout.space` | `--mosaik-layout-space` | `8px` | Base unit of every padding, gap and margin; components scale it with `calc()`. |
| `layout.radius` | `--mosaik-layout-radius` | `2px` | Corner radius of every rectangular surface. |
| `layout.thickness` | `--mosaik-layout-thickness` | `1px` | Border width of controls, dividers and indicators. |

The size vocabulary components accept as `size`, `gap` or `iconSize` (values from `tokens/themes/tokens.json`; these are enum steps, not runtime custom properties):

| Key | Value |
|---|---|
| `tiny` | `2px` |
| `small` | `4px` |
| `medium` | `8px` |
| `large` | `16px` |
| `giant` | `32px` |
<!-- /design-md:layout -->

Layout is composed with `mosaik-stack` and `mosaik-grid`, never with margins. Tailwind consumers
layer `@pixel-brewery/mosaik-themes/tailwind/v4/cosmopolitan`, which pins Tailwind's `--spacing`
to the 8px unit.

## Elevation & Depth

Depth is **ambient and reserved for what floats**. Every level stacks two shadows: a tight 12%
ambient layer around the surface and a directional 14% key layer whose offset and blur grow from
`1px / 2px` (`light`) to `32px / 64px` (`extrabold`); in dark mode both alphas double. Resting
surfaces (cards, panels, expanders, tables) are flat and hairline-framed, as on the Metro canvas;
menus, popups and tooltips float on `regular`, dialogs, drawers and sheets on `bold`.

<!-- design-md:elevation -->

Every level is a stack of 2 shadow layers. `--mosaik-elevation-<level>` carries the complete `box-shadow` value; `--mosaik-elevation-<level>-{offset-x,offset-y,blur,spread,color}` expose the primary layer.

| Level | Light | Dark |
|---|---|---|
| `none` | `none` | `none` |
| `light` | `0px 0px 2px 0px rgba(0, 0, 0, 0.12), 0px 1px 2px 0px rgba(0, 0, 0, 0.14)` | `0px 0px 2px 0px rgba(0, 0, 0, 0.24), 0px 1px 2px 0px rgba(0, 0, 0, 0.28)` |
| `semilight` | `0px 0px 2px 0px rgba(0, 0, 0, 0.12), 0px 2px 4px 0px rgba(0, 0, 0, 0.14)` | `0px 0px 2px 0px rgba(0, 0, 0, 0.24), 0px 2px 4px 0px rgba(0, 0, 0, 0.28)` |
| `regular` | `0px 0px 2px 0px rgba(0, 0, 0, 0.12), 0px 4px 8px 0px rgba(0, 0, 0, 0.14)` | `0px 0px 2px 0px rgba(0, 0, 0, 0.24), 0px 4px 8px 0px rgba(0, 0, 0, 0.28)` |
| `semibold` | `0px 0px 2px 0px rgba(0, 0, 0, 0.12), 0px 8px 16px 0px rgba(0, 0, 0, 0.14)` | `0px 0px 2px 0px rgba(0, 0, 0, 0.24), 0px 8px 16px 0px rgba(0, 0, 0, 0.28)` |
| `bold` | `0px 0px 8px 0px rgba(0, 0, 0, 0.12), 0px 14px 28px 0px rgba(0, 0, 0, 0.14)` | `0px 0px 8px 0px rgba(0, 0, 0, 0.24), 0px 14px 28px 0px rgba(0, 0, 0, 0.28)` |
| `extrabold` | `0px 0px 8px 0px rgba(0, 0, 0, 0.12), 0px 32px 64px 0px rgba(0, 0, 0, 0.14)` | `0px 0px 8px 0px rgba(0, 0, 0, 0.24), 0px 32px 64px 0px rgba(0, 0, 0, 0.28)` |
<!-- /design-md:elevation -->

Components expose the scale as the named `elevation` prop; an explicit elevation lifts any surface.

## Shapes

Cosmopolitan geometry is **square-ish**. `layout.radius` is 2px: corners that do not look cut, and
not rounded either. Buttons, inputs, cards, chips and menus share it; radios and the calendar's
navigation buttons are round, and circles stay circles where a component defines them. Borders are
1px hairlines in `highlight`; a 1px border in a saturated color is a state, not a default.

Focus is the old dotted rectangle, modernised: a crisp, opaque ring of twice the stroke in cyan
(`primary-500`, or the variant's `500` stop) with a gap of twice the stroke that follows the
radius; fields draw focus with their own line.

## Motion

Cosmopolitan motion is **understated**: color, line and shadow transitions over `duration.short`
with an `ease` curve. Nothing translates. The sheen changes with the state (brighter on hover,
inverted when pressed); gradients switch instantly, since background images do not interpolate.

<!-- design-md:motion -->

| Token | Custom property | Value | Role |
|---|---|---|---|
| `duration.short` | `--mosaik-duration-short` | `0.2s` | Hover, focus and color transitions; the default `transition-duration` of components. |
| `duration.medium` | `--mosaik-duration-medium` | `0.4s` | Expand, collapse and reveal. |
| `duration.long` | `--mosaik-duration-long` | `0.6s` | Page-level and staged motion. |
<!-- /design-md:motion -->

Components honour `prefers-reduced-motion` by collapsing durations to `0.01ms`.

## Components

Mosaik components are Lit web components; the framework packages are thin wrappers over the same
custom elements. The public language is expressed as **props, not classes**:

| Prop         | Values                                                                                                             |
| ------------ | ------------------------------------------------------------------------------------------------------------------ |
| `variant`    | `default`, `primary`, `secondary`, `tertiary`, `danger`, `warning`, `success`, `info`, `highlight`, `neutral`       |
| `appearance` | `default`, `outline`, `plain`, `soft`, `solid`                                                                     |
| `size`       | `tiny`, `small`, `medium`, `large`, `giant`                                                                        |
| `elevation`  | `none`, `light`, `semilight`, `regular`, `semibold`, `bold`, `extrabold`                                            |
| others       | `inset`, `fit`, `orientation`, `disabled`, `isBusy`, `isSelected` for spacing, sizing, direction and state          |

Not every component accepts all of them; the component's typings are authoritative. Text travels
through attributes (`label`, `text`, `header`), and containers only project their own sub
components.

### The component token contract

Each component owns one token file. The base skeleton (`tokens/themes/components.json`) gives
every component sixteen `unset` slots for font, padding, gap, transition and translate; mixins add
opt-in groups through `$includes`, and the component file sets the values that differ, always as
references to the global tokens. The merged map is declared on the shadow host as
`--<prefix>-<token>` custom properties, documented as `@cssprop` in the component's TSDoc, and any
of them can be overridden from outside:

```css
mosaik-button { --button-border-radius: 0px; }
mosaik-card   { --card-border-color: var(--mosaik-scheme-highlight); }
```

The mixin catalogue is the one shared by all themes; Cosmopolitan differs in the values it
assigns. Notable Cosmopolitan defaults: the button carries the dark-to-light sheen over the control grey,
a `highlight` hairline, `2 x space` side padding and the bold uppercase 13px label, and its shadow
tokens stay transparent (Metro controls do not float); fields are compact hairline boxes; the focus
ring is cyan at twice the stroke.

| Mixin          | Tokens it contributes                                                                                          |
| -------------- | -------------------------------------------------------------------------------------------------------------- |
| `border`       | `borderColor`, `borderRadius`, `borderStyle` (`solid`), `borderWidth`                                          |
| `color:<role>` | `<role>Color`, used as `color:background` and `color:foreground`                                               |
| `dimensions`   | `width`, `height`                                                                                              |
| `minDimensions`| `minWidth`, `minHeight`                                                                                        |
| `padding`      | `paddingTop`, `paddingRight`, `paddingBottom`, `paddingLeft`                                                   |
| `inset`        | `insetTop`, `insetRight`, `insetBottom`, `insetLeft`                                                           |
| `gap`          | `gap`                                                                                                          |
| `font`         | `fontFamily`, `fontSize`, `fontWeight`, `fontLineHeight`, `fontLetterSpacing`, `fontTextDecoration`, `fontTextTransform`; `font:<part>` prefixes them |
| `floatingLabel`| `floatingLabelFontSize` (12px), `floatingLabelLineHeight` (12px)                                               |
| `shadow`       | `shadowOffsetX`, `shadowOffsetY`, `shadowBlur`, `shadowSpread`, `shadowColor` and the composed `shadow`         |
| `focusRing`    | `focusRingColor`, `focusRingInwardOffset` (2px), `focusRingOutwardOffset` (2px), `focusRingActiveWidth` (8px)  |
| `ripple`       | `rippleColor`, `rippleDuration` (200ms)                                                                        |
| `transition`   | `transitionDuration`, `transitionMode`, `transitionProperty`                                                   |
| `translate`    | `translate` (`none`)                                                                                           |
| `progressRing` | `progressRingWidth` (2px)                                                                                      |
| `prefix`, `suffix` | `prefixIconSize`, `suffixIconSize` (20px)                                                                  |
| `thumb`        | `thumbBackgroundColor`, `thumbBorderColor`, `thumbBorderRadius`                                                |
| `line`         | `lineThickness`                                                                                                |
| `stack`        | `stackTranslateStep`, `stackScaleStep`, `stackOpacityStep`, `stackRotationStep`, `stackGap`, `stackTransitionDuration`, `stackTransitionTimingFunction`, `stackIndent`, `stackExpandedScale` |

The frontmatter `components` block projects the core atoms into the DESIGN.md schema: the bare key
(`button`) is the token default, and related keys carry the overrides the theme stylesheet applies
(`button-primary`, `button-primary-hover`, `button-tiny`). Only `backgroundColor`, `textColor`,
`typography`, `rounded`, `padding`, `height` and `width` can be expressed there; everything else is
in [COMPONENTS.cosmopolitan.md](COMPONENTS.cosmopolitan.md).

### Runtime custom properties

<!-- design-md:runtime -->

A page with a `Theme2` / `provideTheme()` provider carries 653 custom properties in light mode: the 537 the compiled `cosmopolitan-style()` stylesheet declares on `:root`, overlaid by what `ThemeService` writes from the theme object (dark mode redeclares the mode-dependent ones).

| Family | Properties |
|---|---|
| `--cosmopolitan-color-*` | 297 |
| `--cosmopolitan-duration-*` | 3 |
| `--cosmopolitan-elevation-*` | 200 |
| `--cosmopolitan-font-*` | 1 |
| `--cosmopolitan-layout-*` | 4 |
| `--cosmopolitan-scheme-*` | 33 |
| `--cosmopolitan-typography-*` | 112 |
<!-- /design-md:runtime -->

`ThemeService` mirrors the scheme, color, font, typography, layout and elevation families as
`--mosaik-*` aliases; durations are aliased by the stylesheet itself. Cosmopolitan additionally
declares `--cosmopolitan-layout-transition`, which several component tokens use as their
transition duration.

### Component index

Every component with a token file, its tag and the number of tokens it exports. The prefix of a
component's custom properties is its tag without `mosaik-` (`mosaik-textbox` declares `--textbox-*`). The
full tables, with a link to each component's reference documentation, are in [COMPONENTS.cosmopolitan.md](COMPONENTS.cosmopolitan.md).

<!-- design-md:component-index -->

| Token file | Tag | Tokens |
|---|---|---|
| [absolute](COMPONENTS.cosmopolitan.md#absolute) | `mosaik-absolute` | 22 |
| [absoluteItem](COMPONENTS.cosmopolitan.md#absolute-item) | `mosaik-absolute-item` | 22 |
| [accordion](COMPONENTS.cosmopolitan.md#accordion) | `mosaik-accordion` | 22 |
| [actionbar-group](COMPONENTS.cosmopolitan.md#actionbar-group) | `mosaik-actionbar-group` | 19 |
| [actionbar-item](COMPONENTS.cosmopolitan.md#actionbar-item) | `mosaik-actionbar-item` | 20 |
| [actionbar-separator](COMPONENTS.cosmopolitan.md#actionbar-separator) | `mosaik-actionbar-separator` | 18 |
| [actionbar](COMPONENTS.cosmopolitan.md#actionbar) | `mosaik-actionbar` | 23 |
| [alert](COMPONENTS.cosmopolitan.md#alert) | `mosaik-alert` | 22 |
| [anchor](COMPONENTS.cosmopolitan.md#anchor) | `mosaik-anchor` | 25 |
| [app](COMPONENTS.cosmopolitan.md#app) | `mosaik-app` | 36 |
| [appHeader](COMPONENTS.cosmopolitan.md#app-header) | `mosaik-app-header` | 31 |
| [audio](COMPONENTS.cosmopolitan.md#audio) | `mosaik-audio` | 36 |
| [autoCompleteBox](COMPONENTS.cosmopolitan.md#autocompletebox) | `mosaik-autocompletebox` | 33 |
| [avatar](COMPONENTS.cosmopolitan.md#avatar) | `mosaik-avatar` | 34 |
| [avatarGroup](COMPONENTS.cosmopolitan.md#avatar-group) | `mosaik-avatar-group` | 28 |
| [backTop](COMPONENTS.cosmopolitan.md#back-top) | `mosaik-back-top` | 22 |
| [backdrop](COMPONENTS.cosmopolitan.md#backdrop) | `mosaik-backdrop` | 24 |
| [badge](COMPONENTS.cosmopolitan.md#badge) | `mosaik-badge` | 34 |
| [banner](COMPONENTS.cosmopolitan.md#banner) | `mosaik-banner` | 34 |
| [bannerGroup](COMPONENTS.cosmopolitan.md#banner-group) | `mosaik-banner-group` | 31 |
| [bannerHeader](COMPONENTS.cosmopolitan.md#banner-header) | `mosaik-banner-header` | 25 |
| [bannerSubHeader](COMPONENTS.cosmopolitan.md#banner-sub-header) | `mosaik-banner-sub-header` | 25 |
| [box](COMPONENTS.cosmopolitan.md#box) | `mosaik-box` | 30 |
| [breadcrumb](COMPONENTS.cosmopolitan.md#breadcrumb) | `mosaik-breadcrumb` | 22 |
| [breadcrumbItem](COMPONENTS.cosmopolitan.md#breadcrumb-item) | `mosaik-breadcrumb-item` | 25 |
| [bubbles](COMPONENTS.cosmopolitan.md#bubbles) | `mosaik-bubbles` | 23 |
| [busyState](COMPONENTS.cosmopolitan.md#busy-state) | `mosaik-busy-state` | 30 |
| [button](COMPONENTS.cosmopolitan.md#button) | `mosaik-button` | 41 |
| [buttonGroup](COMPONENTS.cosmopolitan.md#button-group) | `mosaik-button-group` | 28 |
| [calendar](COMPONENTS.cosmopolitan.md#calendar) | `mosaik-calendar` | 29 |
| [calendarDaysView](COMPONENTS.cosmopolitan.md#calendar-days-view) | `mosaik-calendar-days-view` | 22 |
| [calendarHeader](COMPONENTS.cosmopolitan.md#calendar-header) | `mosaik-calendar-header` | 28 |
| [calendarItem](COMPONENTS.cosmopolitan.md#calendar-item) | `mosaik-calendar-item` | 41 |
| [calendarMonthsView](COMPONENTS.cosmopolitan.md#calendar-months-view) | `mosaik-calendar-months-view` | 22 |
| [calendarSubHeader](COMPONENTS.cosmopolitan.md#calendar-sub-header) | `mosaik-calendar-sub-header` | 30 |
| [calendarYearsView](COMPONENTS.cosmopolitan.md#calendar-years-view) | `mosaik-calendar-years-view` | 22 |
| [camera](COMPONENTS.cosmopolitan.md#camera) | `mosaik-camera` | 25 |
| [card](COMPONENTS.cosmopolitan.md#card) | `mosaik-card` | 29 |
| [cardActions](COMPONENTS.cosmopolitan.md#card-actions) | `mosaik-card-actions` | 22 |
| [cardContent](COMPONENTS.cosmopolitan.md#card-content) | `mosaik-card-content` | 22 |
| [cardFooter](COMPONENTS.cosmopolitan.md#card-footer) | `mosaik-card-footer` | 22 |
| [cardHeader](COMPONENTS.cosmopolitan.md#card-header) | `mosaik-card-header` | 22 |
| [cardStack](COMPONENTS.cosmopolitan.md#card-stack) | `mosaik-card-stack` | 21 |
| [cardSubTitle](COMPONENTS.cosmopolitan.md#card-sub-title) | `mosaik-card-sub-title` | 25 |
| [cardTitle](COMPONENTS.cosmopolitan.md#card-title) | `mosaik-card-title` | 25 |
| [carousel](COMPONENTS.cosmopolitan.md#carousel) | `mosaik-carousel` | 42 |
| [carouselItem](COMPONENTS.cosmopolitan.md#carousel-item) | `mosaik-carousel-item` | 22 |
| [cell](COMPONENTS.cosmopolitan.md#cell) | `mosaik-cell` | 30 |
| [cellGroup](COMPONENTS.cosmopolitan.md#cell-group) | `mosaik-cell-group` | 28 |
| [chart](COMPONENTS.cosmopolitan.md#chart) | `mosaik-chart` | 24 |
| [chartToolbox](COMPONENTS.cosmopolitan.md#chart-toolbox) | `mosaik-chart-toolbox` | 17 |
| [chat](COMPONENTS.cosmopolitan.md#chat) | `mosaik-chat` | 31 |
| [chatHeader](COMPONENTS.cosmopolitan.md#chat-header) | `mosaik-chat-header` | 23 |
| [chatMarker](COMPONENTS.cosmopolitan.md#chat-marker) | `mosaik-chat-marker` | 28 |
| [chatMessage](COMPONENTS.cosmopolitan.md#chat-message) | `mosaik-chat-message` | 29 |
| [chatMessageAvatar](COMPONENTS.cosmopolitan.md#chat-message-avatar) | `mosaik-chat-message-avatar` | 34 |
| [chatMessageDivider](COMPONENTS.cosmopolitan.md#chat-message-divider) | `mosaik-chat-message-divider` | 23 |
| [chatMessageReaction](COMPONENTS.cosmopolitan.md#chat-message-reaction) | `mosaik-chat-message-reaction` | 23 |
| [checkBox](COMPONENTS.cosmopolitan.md#checkbox) | `mosaik-checkbox` | 28 |
| [checkBoxGroup](COMPONENTS.cosmopolitan.md#checkbox-group) | `mosaik-checkbox-group` | 28 |
| [checkmark](COMPONENTS.cosmopolitan.md#checkmark) | `mosaik-checkmark` | 36 |
| [chip](COMPONENTS.cosmopolitan.md#chip) | `mosaik-chip` | 35 |
| [chipBox](COMPONENTS.cosmopolitan.md#chipbox) | `mosaik-chipbox` | 43 |
| [chipGroup](COMPONENTS.cosmopolitan.md#chip-group) | `mosaik-chip-group` | 28 |
| [choice](COMPONENTS.cosmopolitan.md#choice) | `mosaik-choice` | 32 |
| [choiceGroup](COMPONENTS.cosmopolitan.md#choice-group) | `mosaik-choice-group` | 28 |
| [choiceGroupHeader](COMPONENTS.cosmopolitan.md#choice-group-header) | `mosaik-choice-group-header` | 28 |
| [clickable](COMPONENTS.cosmopolitan.md#clickable) | `mosaik-clickable` | 27 |
| [code](COMPONENTS.cosmopolitan.md#code) | `mosaik-code` | 23 |
| [codeEditor](COMPONENTS.cosmopolitan.md#code-editor) | `mosaik-code-editor` | 78 |
| [colorArea](COMPONENTS.cosmopolitan.md#color-area) | `mosaik-color-area` | 22 |
| [colorBox](COMPONENTS.cosmopolitan.md#colorbox) | `mosaik-colorbox` | 41 |
| [colorEditor](COMPONENTS.cosmopolitan.md#color-editor) | `mosaik-color-editor` | 34 |
| [colorEditorAlphaSlider](COMPONENTS.cosmopolitan.md#color-editor-alpha-slider) | `mosaik-color-editor-alpha-slider` | 41 |
| [colorEditorArea](COMPONENTS.cosmopolitan.md#color-editor-area) | `mosaik-color-editor-area` | 39 |
| [colorEditorHueSlider](COMPONENTS.cosmopolitan.md#color-editor-hue-slider) | `mosaik-color-editor-hue-slider` | 40 |
| [colorEditorInputs](COMPONENTS.cosmopolitan.md#color-editor-inputs) | `mosaik-color-editor-inputs` | 37 |
| [colorEditorPalette](COMPONENTS.cosmopolitan.md#color-editor-palette) | `mosaik-color-editor-palette` | 36 |
| [colorEditorShadeSlider](COMPONENTS.cosmopolitan.md#color-editor-shade-slider) | `mosaik-color-editor-shade-slider` | 40 |
| [colorEditorSwatch](COMPONENTS.cosmopolitan.md#color-editor-swatch) | `mosaik-color-editor-swatch` | 31 |
| [colorPicker](COMPONENTS.cosmopolitan.md#color-picker) | `mosaik-color-picker` | 29 |
| [colorSlider](COMPONENTS.cosmopolitan.md#color-slider) | `mosaik-color-slider` | 28 |
| [colorSwatch](COMPONENTS.cosmopolitan.md#color-swatch) | `mosaik-color-swatch` | 29 |
| [colorSwatchGroup](COMPONENTS.cosmopolitan.md#color-swatch-group) | `mosaik-color-swatch-group` | 28 |
| [colorThumb](COMPONENTS.cosmopolitan.md#color-thumb) | `mosaik-color-thumb` | 29 |
| [combo](COMPONENTS.cosmopolitan.md#combo) | `mosaik-combo` | 36 |
| [comboItem](COMPONENTS.cosmopolitan.md#combo-item) | `mosaik-combo-item` | 34 |
| [comboItemGroup](COMPONENTS.cosmopolitan.md#combo-item-group) | `mosaik-combo-item-group` | 39 |
| [comboItemVisual](COMPONENTS.cosmopolitan.md#combo-item-visual) | `mosaik-combo-item-visual` | 22 |
| [comment](COMPONENTS.cosmopolitan.md#comment) | `mosaik-comment` | 25 |
| [compoundButton](COMPONENTS.cosmopolitan.md#compound-button) | `mosaik-compound-button` | 41 |
| [content](COMPONENTS.cosmopolitan.md#content) | `mosaik-content` | 22 |
| [cookiesConsent](COMPONENTS.cosmopolitan.md#cookie-consent) | `mosaik-cookie-consent` | 22 |
| [cursorEffect](COMPONENTS.cosmopolitan.md#cursor-effect) | `mosaik-cursor-effect` | 21 |
| [dataList](COMPONENTS.cosmopolitan.md#data-list) | `mosaik-data-list` | 22 |
| [dataTable](COMPONENTS.cosmopolitan.md#data-table) | `mosaik-data-table` | 24 |
| [dateBox](COMPONENTS.cosmopolitan.md#datebox) | `mosaik-datebox` | 41 |
| [dateTimeBox](COMPONENTS.cosmopolitan.md#datetimebox) | `mosaik-datetimebox` | 44 |
| [designer](COMPONENTS.cosmopolitan.md#designer) | `mosaik-designer` | 16 |
| [designerCanvas](COMPONENTS.cosmopolitan.md#designer-canvas) | `mosaik-designer-canvas` | 20 |
| [designerConnector](COMPONENTS.cosmopolitan.md#designer-connector) | `mosaik-designer-connector` | 27 |
| [designerContent](COMPONENTS.cosmopolitan.md#designer-content) | `mosaik-designer-content` | 16 |
| [designerFrame](COMPONENTS.cosmopolitan.md#designer-frame) | `mosaik-designer-frame` | 34 |
| [dialog](COMPONENTS.cosmopolitan.md#dialog) | `mosaik-dialog` | 29 |
| [dialogActions](COMPONENTS.cosmopolitan.md#dialog-actions) | `mosaik-dialog-actions` | 22 |
| [dialogContent](COMPONENTS.cosmopolitan.md#dialog-content) | `mosaik-dialog-content` | 22 |
| [dialogFooter](COMPONENTS.cosmopolitan.md#dialog-footer) | `mosaik-dialog-footer` | 22 |
| [dialogHeader](COMPONENTS.cosmopolitan.md#dialog-header) | `mosaik-dialog-header` | 22 |
| [dialogHeaderSubText](COMPONENTS.cosmopolitan.md#dialog-header-sub-text) | `mosaik-dialog-header-sub-text` | 25 |
| [dialogHeaderText](COMPONENTS.cosmopolitan.md#dialog-header-text) | `mosaik-dialog-header-text` | 25 |
| [disclosure](COMPONENTS.cosmopolitan.md#disclosure) | `mosaik-disclosure` | 32 |
| [dismiss](COMPONENTS.cosmopolitan.md#dismiss) | `mosaik-dismiss` | 22 |
| [divider](COMPONENTS.cosmopolitan.md#divider) | `mosaik-divider` | 29 |
| [dockPanel](COMPONENTS.cosmopolitan.md#dock-panel) | `mosaik-dock-panel` | 22 |
| [dot](COMPONENTS.cosmopolitan.md#dot) | `mosaik-dot` | 29 |
| [dotGroup](COMPONENTS.cosmopolitan.md#dot-group) | `mosaik-dot-group` | 28 |
| [drawer](COMPONENTS.cosmopolitan.md#drawer) | `mosaik-drawer` | 33 |
| [drawerActions](COMPONENTS.cosmopolitan.md#drawer-actions) | `mosaik-drawer-actions` | 22 |
| [drawerContainer](COMPONENTS.cosmopolitan.md#drawer-container) | `mosaik-drawer-container` | 23 |
| [drawerContent](COMPONENTS.cosmopolitan.md#drawer-content) | `mosaik-drawer-content` | 26 |
| [drawerFooter](COMPONENTS.cosmopolitan.md#drawer-footer) | `mosaik-drawer-footer` | 22 |
| [drawerHeader](COMPONENTS.cosmopolitan.md#drawer-header) | `mosaik-drawer-header` | 22 |
| [drawerHeaderSubText](COMPONENTS.cosmopolitan.md#drawer-header-sub-text) | `mosaik-drawer-header-sub-text` | 25 |
| [drawerHeaderText](COMPONENTS.cosmopolitan.md#drawer-header-text) | `mosaik-drawer-header-text` | 25 |
| [drawerRail](COMPONENTS.cosmopolitan.md#drawer-rail) | `mosaik-drawer-rail` | 25 |
| [dropDownButton](COMPONENTS.cosmopolitan.md#dropdown-button) | `mosaik-dropdown-button` | 44 |
| [dropZone](COMPONENTS.cosmopolitan.md#drop-zone) | `mosaik-drop-zone` | 27 |
| [dropdown](COMPONENTS.cosmopolitan.md#dropdown) | `mosaik-dropdown` | 42 |
| [durationBox](COMPONENTS.cosmopolitan.md#durationbox) | `mosaik-durationbox` | 41 |
| [elevation](COMPONENTS.cosmopolitan.md#elevation) | `mosaik-elevation` | 22 |
| [emoji](COMPONENTS.cosmopolitan.md#emoji) | `mosaik-emoji` | 23 |
| [emptyState](COMPONENTS.cosmopolitan.md#empty-state) | `mosaik-empty-state` | 30 |
| [epg](COMPONENTS.cosmopolitan.md#epg) | `mosaik-epg` | 28 |
| [epgChannel](COMPONENTS.cosmopolitan.md#epg-channel) | `mosaik-epg-channel` | 28 |
| [epgMinimap](COMPONENTS.cosmopolitan.md#epg-minimap) | `mosaik-epg-minimap` | 28 |
| [epgNowLine](COMPONENTS.cosmopolitan.md#epg-now-line) | `mosaik-epg-now-line` | 26 |
| [epgProgram](COMPONENTS.cosmopolitan.md#epg-program) | `mosaik-epg-program` | 28 |
| [epgTimeline](COMPONENTS.cosmopolitan.md#epg-timeline) | `mosaik-epg-timeline` | 28 |
| [error](COMPONENTS.cosmopolitan.md#error) | `mosaik-error` | 28 |
| [errorState](COMPONENTS.cosmopolitan.md#error-state) | `mosaik-error-state` | 30 |
| [expandable](COMPONENTS.cosmopolitan.md#expandable) | `mosaik-expandable` | 22 |
| [expander](COMPONENTS.cosmopolitan.md#expander) | `mosaik-expander` | 31 |
| [expanderGroup](COMPONENTS.cosmopolitan.md#expander-group) | `mosaik-expander-group` | 28 |
| [expanderHeader](COMPONENTS.cosmopolitan.md#expander-header) | `mosaik-expander-header` | 25 |
| [expanderSubHeader](COMPONENTS.cosmopolitan.md#expander-sub-header) | `mosaik-expander-sub-header` | 25 |
| [fileBox](COMPONENTS.cosmopolitan.md#filebox) | `mosaik-filebox` | 41 |
| [filePicker](COMPONENTS.cosmopolitan.md#file-picker) | `mosaik-file-picker` | 28 |
| [fileUpload](COMPONENTS.cosmopolitan.md#file-upload) | `mosaik-file-upload` | 37 |
| [fileUploadItem](COMPONENTS.cosmopolitan.md#file-upload-item) | `mosaik-file-upload-item` | 28 |
| [flip](COMPONENTS.cosmopolitan.md#flip) | `mosaik-flip` | 22 |
| [floating](COMPONENTS.cosmopolitan.md#floating) | `mosaik-floating` | 31 |
| [floatingActionButton](COMPONENTS.cosmopolitan.md#fab) | `mosaik-fab` | 39 |
| [floatingActionButtonGroup](COMPONENTS.cosmopolitan.md#fab-group) | `mosaik-fab-group` | 22 |
| [floatingTrigger](COMPONENTS.cosmopolitan.md#floating-trigger) | `mosaik-floating-trigger` | 22 |
| [flow](COMPONENTS.cosmopolitan.md#flow) | `mosaik-flow` | 33 |
| [flowBoard](COMPONENTS.cosmopolitan.md#flow-board) | `mosaik-flow-board` | 24 |
| [flowBoardColumn](COMPONENTS.cosmopolitan.md#flow-board-column) | `mosaik-flow-board-column` | 48 |
| [flowBoardColumnComposer](COMPONENTS.cosmopolitan.md#flow-board-column-composer) | `mosaik-flow-board-column-composer` | 30 |
| [flowBoardColumnItem](COMPONENTS.cosmopolitan.md#flow-board-column-item) | `mosaik-flow-board-column-item` | 37 |
| [flowBoardColumnItemComposer](COMPONENTS.cosmopolitan.md#flow-board-column-item-composer) | `mosaik-flow-board-column-item-composer` | 30 |
| [flowBoardColumnItemGroup](COMPONENTS.cosmopolitan.md#flow-board-column-item-group) | `mosaik-flow-board-column-item-group` | 30 |
| [flowControls](COMPONENTS.cosmopolitan.md#flow-controls) | `mosaik-flow-controls` | 37 |
| [flowEdge](COMPONENTS.cosmopolitan.md#flow-edge) | `mosaik-flow-edge` | 39 |
| [flowMinimap](COMPONENTS.cosmopolitan.md#flow-minimap) | `mosaik-flow-minimap` | 42 |
| [flowNode](COMPONENTS.cosmopolitan.md#flow-node) | `mosaik-flow-node` | 47 |
| [focusRing](COMPONENTS.cosmopolitan.md#focus-ring) | `mosaik-focus-ring` | 35 |
| [fontEditor](COMPONENTS.cosmopolitan.md#font-editor) | `mosaik-font-editor` | 56 |
| [footer](COMPONENTS.cosmopolitan.md#footer) | `mosaik-footer` | 29 |
| [footerItem](COMPONENTS.cosmopolitan.md#footer-item) | `mosaik-footer-item` | 22 |
| [footerItemGroup](COMPONENTS.cosmopolitan.md#footer-item-group) | `mosaik-footer-item-group` | 22 |
| [form](COMPONENTS.cosmopolitan.md#form) | `mosaik-form` | 24 |
| [formField](COMPONENTS.cosmopolitan.md#form-field) | `mosaik-form-field` | 23 |
| [gauge](COMPONENTS.cosmopolitan.md#gauge) | `mosaik-gauge` | 28 |
| [gaugeArc](COMPONENTS.cosmopolitan.md#gauge-arc) | `mosaik-gauge-arc` | 25 |
| [gaugeControl](COMPONENTS.cosmopolitan.md#gauge-control) | `mosaik-gauge-control` | 28 |
| [gaugeDot](COMPONENTS.cosmopolitan.md#gauge-dot) | `mosaik-gauge-dot` | 27 |
| [gaugeHub](COMPONENTS.cosmopolitan.md#gauge-hub) | `mosaik-gauge-hub` | 25 |
| [gaugeInset](COMPONENTS.cosmopolitan.md#gauge-inset) | `mosaik-gauge-inset` | 22 |
| [gaugeMarks](COMPONENTS.cosmopolitan.md#gauge-marks) | `mosaik-gauge-marks` | 26 |
| [gaugeNeedle](COMPONENTS.cosmopolitan.md#gauge-needle) | `mosaik-gauge-needle` | 25 |
| [gaugeStack](COMPONENTS.cosmopolitan.md#gauge-stack) | `mosaik-gauge-stack` | 25 |
| [gaugeText](COMPONENTS.cosmopolitan.md#gauge-text) | `mosaik-gauge-text` | 26 |
| [gaugeTickLabels](COMPONENTS.cosmopolitan.md#gauge-tick-labels) | `mosaik-gauge-tick-labels` | 26 |
| [gaugeTicks](COMPONENTS.cosmopolitan.md#gauge-ticks) | `mosaik-gauge-ticks` | 26 |
| [gaugeTooltip](COMPONENTS.cosmopolitan.md#gauge-tooltip) | `mosaik-gauge-tooltip` | 29 |
| [gaugeTrack](COMPONENTS.cosmopolitan.md#gauge-track) | `mosaik-gauge-track` | 25 |
| [gaugeValue](COMPONENTS.cosmopolitan.md#gauge-value) | `mosaik-gauge-value` | 26 |
| [gaugeZones](COMPONENTS.cosmopolitan.md#gauge-zones) | `mosaik-gauge-zones` | 25 |
| [ghost](COMPONENTS.cosmopolitan.md#ghost) | `mosaik-ghost` | 27 |
| [globe](COMPONENTS.cosmopolitan.md#globe) | `mosaik-globe` | 24 |
| [grid](COMPONENTS.cosmopolitan.md#grid) | `mosaik-grid` | 22 |
| [gridItem](COMPONENTS.cosmopolitan.md#grid-item) | `mosaik-grid-item` | 22 |
| [helmet](COMPONENTS.cosmopolitan.md#helmet) | `mosaik-helmet` | 22 |
| [hint](COMPONENTS.cosmopolitan.md#hint) | `mosaik-hint` | 28 |
| [icon](COMPONENTS.cosmopolitan.md#icon) | `mosaik-icon` | 29 |
| [image](COMPONENTS.cosmopolitan.md#image) | `mosaik-image` | 39 |
| [indicator](COMPONENTS.cosmopolitan.md#indicator) | `mosaik-indicator` | 28 |
| [inkBar](COMPONENTS.cosmopolitan.md#ink-bar) | `mosaik-ink-bar` | 27 |
| [jumbotron](COMPONENTS.cosmopolitan.md#jumbotron) | `mosaik-jumbotron` | 28 |
| [jumbotronHeader](COMPONENTS.cosmopolitan.md#jumbotron-header) | `mosaik-jumbotron-header` | 25 |
| [jumbotronSubHeader](COMPONENTS.cosmopolitan.md#jumbotron-sub-header) | `mosaik-jumbotron-sub-header` | 25 |
| [kbd](COMPONENTS.cosmopolitan.md#kbd) | `mosaik-kbd` | 28 |
| [kbdShortcut](COMPONENTS.cosmopolitan.md#kbd-shortcut) | `mosaik-kbd-shortcut` | 22 |
| [knob](COMPONENTS.cosmopolitan.md#knob) | `mosaik-knob` | 41 |
| [lightChain](COMPONENTS.cosmopolitan.md#light-chain) | `mosaik-light-chain` | 22 |
| [list](COMPONENTS.cosmopolitan.md#list) | `mosaik-list` | 29 |
| [listItem](COMPONENTS.cosmopolitan.md#list-item) | `mosaik-list-item` | 34 |
| [listItemGroup](COMPONENTS.cosmopolitan.md#list-item-group) | `mosaik-list-item-group` | 39 |
| [listing](COMPONENTS.cosmopolitan.md#listing) | `mosaik-listing` | 24 |
| [listingItem](COMPONENTS.cosmopolitan.md#listing-item) | `mosaik-listing-item` | 24 |
| [listingItemMarker](COMPONENTS.cosmopolitan.md#listing-item-marker) | `mosaik-listing-item-marker` | 29 |
| [map](COMPONENTS.cosmopolitan.md#map) | `mosaik-map` | 22 |
| [marquee](COMPONENTS.cosmopolitan.md#marquee) | `mosaik-marquee` | 25 |
| [masonry](COMPONENTS.cosmopolitan.md#masonry) | `mosaik-masonry` | 23 |
| [mention](COMPONENTS.cosmopolitan.md#mention) | `mosaik-mention` | 32 |
| [menu](COMPONENTS.cosmopolitan.md#menu) | `mosaik-menu` | 28 |
| [menuItem](COMPONENTS.cosmopolitan.md#menu-item) | `mosaik-menu-item` | 38 |
| [menuItemGroup](COMPONENTS.cosmopolitan.md#menu-item-group) | `mosaik-menu-item-group` | 39 |
| [message](COMPONENTS.cosmopolitan.md#message) | `mosaik-message` | 28 |
| [messageBox](COMPONENTS.cosmopolitan.md#message-box) | `mosaik-message-box` | 45 |
| [meterBar](COMPONENTS.cosmopolitan.md#meter-bar) | `mosaik-meter-bar` | 27 |
| [meterRing](COMPONENTS.cosmopolitan.md#meter-ring) | `mosaik-meter-ring` | 36 |
| [number](COMPONENTS.cosmopolitan.md#number) | `mosaik-number` | 25 |
| [numberBox](COMPONENTS.cosmopolitan.md#numberbox) | `mosaik-numberbox` | 41 |
| [numberCounter](COMPONENTS.cosmopolitan.md#number-counter) | `mosaik-number-counter` | 30 |
| [numberTicker](COMPONENTS.cosmopolitan.md#number-ticker) | `mosaik-number-ticker` | 16 |
| [orbit](COMPONENTS.cosmopolitan.md#orbit) | `mosaik-orbit` | 19 |
| [page](COMPONENTS.cosmopolitan.md#page) | `mosaik-page` | 22 |
| [pageContent](COMPONENTS.cosmopolitan.md#page-content) | `mosaik-page-content` | 26 |
| [pageHeader](COMPONENTS.cosmopolitan.md#page-header) | `mosaik-page-header` | 48 |
| [pageMenu](COMPONENTS.cosmopolitan.md#page-menu) | `mosaik-page-menu` | 30 |
| [pagePreContent](COMPONENTS.cosmopolitan.md#page-pre-content) | `mosaik-page-pre-content` | 23 |
| [pagePreHeader](COMPONENTS.cosmopolitan.md#page-pre-header) | `mosaik-page-pre-header` | 23 |
| [paginator](COMPONENTS.cosmopolitan.md#paginator) | `mosaik-paginator` | 23 |
| [parallax](COMPONENTS.cosmopolitan.md#parallax) | `mosaik-parallax` | 16 |
| [passwordBox](COMPONENTS.cosmopolitan.md#passwordbox) | `mosaik-passwordbox` | 41 |
| [pattern](COMPONENTS.cosmopolitan.md#pattern) | `mosaik-pattern` | 23 |
| [persona](COMPONENTS.cosmopolitan.md#persona) | `mosaik-persona` | 29 |
| [perspective](COMPONENTS.cosmopolitan.md#perspective) | `mosaik-perspective` | 22 |
| [pinBox](COMPONENTS.cosmopolitan.md#pinbox) | `mosaik-pinbox` | 34 |
| [pip](COMPONENTS.cosmopolitan.md#pip) | `mosaik-pip` | 34 |
| [placeholder](COMPONENTS.cosmopolitan.md#placeholder) | `mosaik-placeholder` | 27 |
| [popup](COMPONENTS.cosmopolitan.md#popup) | `mosaik-popup` | 28 |
| [portal](COMPONENTS.cosmopolitan.md#portal) | `mosaik-portal` | 22 |
| [portalHost](COMPONENTS.cosmopolitan.md#portal-host) | `mosaik-portal-host` | 22 |
| [portalProjection](COMPONENTS.cosmopolitan.md#portal-projection) | `mosaik-portal-projection` | 22 |
| [pressButton](COMPONENTS.cosmopolitan.md#press-button) | `mosaik-press-button` | 44 |
| [progressBar](COMPONENTS.cosmopolitan.md#progress-bar) | `mosaik-progress-bar` | 23 |
| [progressRing](COMPONENTS.cosmopolitan.md#progress-ring) | `mosaik-progress-ring` | 31 |
| [promptBox](COMPONENTS.cosmopolitan.md#prompt-box) | `mosaik-prompt-box` | 40 |
| [promptBoxAttachmentList](COMPONENTS.cosmopolitan.md#prompt-box-attachment-list) | `mosaik-prompt-box-attachment-list` | 29 |
| [promptBoxQueue](COMPONENTS.cosmopolitan.md#prompt-box-queue) | `mosaik-prompt-box-queue` | 29 |
| [promptBoxVoiceRecorderTool](COMPONENTS.cosmopolitan.md#prompt-box-voice-recorder-tool) | `mosaik-prompt-box-voice-recorder-tool` | 22 |
| [pulse](COMPONENTS.cosmopolitan.md#pulse) | `mosaik-pulse` | 18 |
| [qrCode](COMPONENTS.cosmopolitan.md#qrcode) | `mosaik-qrcode` | 24 |
| [radio](COMPONENTS.cosmopolitan.md#radio) | `mosaik-radio` | 28 |
| [radioGroup](COMPONENTS.cosmopolitan.md#radio-group) | `mosaik-radio-group` | 28 |
| [rating](COMPONENTS.cosmopolitan.md#rating) | `mosaik-rating` | 28 |
| [region](COMPONENTS.cosmopolitan.md#region) | `mosaik-region` | 22 |
| [regionView](COMPONENTS.cosmopolitan.md#region-view) | `mosaik-region-view` | 22 |
| [repeatButton](COMPONENTS.cosmopolitan.md#repeat-button) | `mosaik-repeat-button` | 43 |
| [resize](COMPONENTS.cosmopolitan.md#resize) | `mosaik-resize` | 22 |
| [resizeAdorner](COMPONENTS.cosmopolitan.md#resize-adorner) | `mosaik-resize-adorner` | 28 |
| [resizeThumb](COMPONENTS.cosmopolitan.md#resize-thumb) | `mosaik-resize-thumb` | 28 |
| [reveal](COMPONENTS.cosmopolitan.md#reveal) | `mosaik-reveal` | 20 |
| [ribbon](COMPONENTS.cosmopolitan.md#ribbon) | `mosaik-ribbon` | 30 |
| [richTextBox](COMPONENTS.cosmopolitan.md#richtextbox) | `mosaik-richtextbox` | 71 |
| [richTextBoxToolbox](COMPONENTS.cosmopolitan.md#richtextbox-toolbox) | `mosaik-richtextbox-toolbox` | 35 |
| [ripple](COMPONENTS.cosmopolitan.md#ripple) | `mosaik-ripple` | 23 |
| [router](COMPONENTS.cosmopolitan.md#router) | `mosaik-router` | 22 |
| [routerAnchor](COMPONENTS.cosmopolitan.md#router-anchor) | `mosaik-router-anchor` | 25 |
| [routerLink](COMPONENTS.cosmopolitan.md#router-link) | `mosaik-router-link` | 22 |
| [routerOutlet](COMPONENTS.cosmopolitan.md#router-outlet) | `mosaik-router-outlet` | 22 |
| [scale](COMPONENTS.cosmopolitan.md#scale) | `mosaik-scale` | 22 |
| [scheduler](COMPONENTS.cosmopolitan.md#scheduler) | `mosaik-scheduler` | 73 |
| [schedulerAgendaView](COMPONENTS.cosmopolitan.md#scheduler-agenda-view) | `mosaik-scheduler-agenda-view` | 40 |
| [schedulerDatescale](COMPONENTS.cosmopolitan.md#scheduler-datescale) | `mosaik-scheduler-datescale` | 41 |
| [schedulerEvent](COMPONENTS.cosmopolitan.md#scheduler-event) | `mosaik-scheduler-event` | 54 |
| [schedulerMonthView](COMPONENTS.cosmopolitan.md#scheduler-month-view) | `mosaik-scheduler-month-view` | 58 |
| [schedulerNowIndicator](COMPONENTS.cosmopolitan.md#scheduler-now-indicator) | `mosaik-scheduler-now-indicator` | 25 |
| [schedulerTimeGridView](COMPONENTS.cosmopolitan.md#scheduler-time-grid-view) | `mosaik-scheduler-time-grid-view` | 67 |
| [schedulerTimelineView](COMPONENTS.cosmopolitan.md#scheduler-timeline-view) | `mosaik-scheduler-timeline-view` | 66 |
| [schedulerTimescale](COMPONENTS.cosmopolitan.md#scheduler-timescale) | `mosaik-scheduler-timescale` | 34 |
| [scroll](COMPONENTS.cosmopolitan.md#scroll) | `mosaik-scroll` | 24 |
| [scrubSlider](COMPONENTS.cosmopolitan.md#scrub-slider) | `mosaik-scrub-slider` | 69 |
| [searchBox](COMPONENTS.cosmopolitan.md#searchbox) | `mosaik-searchbox` | 34 |
| [segment](COMPONENTS.cosmopolitan.md#segment) | `mosaik-segment` | 36 |
| [segmentBar](COMPONENTS.cosmopolitan.md#segment-bar) | `mosaik-segment-bar` | 25 |
| [segmentItem](COMPONENTS.cosmopolitan.md#segment-item) | `mosaik-segment-item` | 34 |
| [segmentLegend](COMPONENTS.cosmopolitan.md#segment-legend) | `mosaik-segment-legend` | 16 |
| [segmentLegendItem](COMPONENTS.cosmopolitan.md#segment-legend-item) | `mosaik-segment-legend-item` | 19 |
| [segmentRing](COMPONENTS.cosmopolitan.md#segment-ring) | `mosaik-segment-ring` | 25 |
| [select](COMPONENTS.cosmopolitan.md#select) | `mosaik-select` | 36 |
| [selectItem](COMPONENTS.cosmopolitan.md#select-item) | `mosaik-select-item` | 34 |
| [selectItemGroup](COMPONENTS.cosmopolitan.md#select-item-group) | `mosaik-select-item-group` | 39 |
| [selectItemVisual](COMPONENTS.cosmopolitan.md#select-item-visual) | `mosaik-select-item-visual` | 22 |
| [sheet](COMPONENTS.cosmopolitan.md#sheet) | `mosaik-sheet` | 41 |
| [sheetContent](COMPONENTS.cosmopolitan.md#sheet-content) | `mosaik-sheet-content` | 22 |
| [sheetFooter](COMPONENTS.cosmopolitan.md#sheet-footer) | `mosaik-sheet-footer` | 22 |
| [sheetHeader](COMPONENTS.cosmopolitan.md#sheet-header) | `mosaik-sheet-header` | 22 |
| [sheetHeaderSubText](COMPONENTS.cosmopolitan.md#sheet-header-sub-text) | `mosaik-sheet-header-sub-text` | 25 |
| [sheetHeaderText](COMPONENTS.cosmopolitan.md#sheet-header-text) | `mosaik-sheet-header-text` | 25 |
| [signaturePad](COMPONENTS.cosmopolitan.md#signaturepad) | `mosaik-signaturepad` | 33 |
| [skeleton](COMPONENTS.cosmopolitan.md#skeleton) | `mosaik-skeleton` | 29 |
| [slider](COMPONENTS.cosmopolitan.md#slider) | `mosaik-slider` | 65 |
| [slider2](COMPONENTS.cosmopolitan.md#slider2) | `mosaik-slider2` | 22 |
| [slider2Thumb](COMPONENTS.cosmopolitan.md#slider2-thumb) | `mosaik-slider2-thumb` | 23 |
| [spacer](COMPONENTS.cosmopolitan.md#spacer) | `mosaik-spacer` | 22 |
| [spline](COMPONENTS.cosmopolitan.md#spline) | `mosaik-spline` | 20 |
| [split](COMPONENTS.cosmopolitan.md#split) | `mosaik-split` | 30 |
| [splitButton](COMPONENTS.cosmopolitan.md#split-button) | `mosaik-split-button` | 43 |
| [stack](COMPONENTS.cosmopolitan.md#stack) | `mosaik-stack` | 22 |
| [stepper](COMPONENTS.cosmopolitan.md#stepper) | `mosaik-stepper` | 40 |
| [stepperItem](COMPONENTS.cosmopolitan.md#stepper-item) | `mosaik-stepper-item` | 25 |
| [sticky](COMPONENTS.cosmopolitan.md#sticky) | `mosaik-sticky` | 24 |
| [successState](COMPONENTS.cosmopolitan.md#success-state) | `mosaik-success-state` | 30 |
| [suggestionMenu](COMPONENTS.cosmopolitan.md#suggestion-menu) | `mosaik-suggestion-menu` | 25 |
| [summary](COMPONENTS.cosmopolitan.md#summary) | `mosaik-summary` | 22 |
| [swipe](COMPONENTS.cosmopolitan.md#swipe) | `mosaik-swipe` | 22 |
| [tab](COMPONENTS.cosmopolitan.md#tab) | `mosaik-tab` | 36 |
| [tabItem](COMPONENTS.cosmopolitan.md#tab-item) | `mosaik-tab-item` | 25 |
| [tabPanel](COMPONENTS.cosmopolitan.md#tab-panel) | `mosaik-tab-panel` | 23 |
| [tabStrip](COMPONENTS.cosmopolitan.md#tab-strip) | `mosaik-tab-strip` | 28 |
| [tabStripItem](COMPONENTS.cosmopolitan.md#tab-strip-item) | `mosaik-tab-strip-item` | 36 |
| [table](COMPONENTS.cosmopolitan.md#table) | `mosaik-table` | 38 |
| [tableBody](COMPONENTS.cosmopolitan.md#table-body) | `mosaik-table-body` | 28 |
| [tableBodyCell](COMPONENTS.cosmopolitan.md#table-body-cell) | `mosaik-table-body-cell` | 29 |
| [tableBodyRow](COMPONENTS.cosmopolitan.md#table-body-row) | `mosaik-table-body-row` | 27 |
| [tableColumnEditor](COMPONENTS.cosmopolitan.md#table-column-editor) | `mosaik-table-column-editor` | 26 |
| [tableFooter](COMPONENTS.cosmopolitan.md#table-footer) | `mosaik-table-footer` | 28 |
| [tableFooterCell](COMPONENTS.cosmopolitan.md#table-footer-cell) | `mosaik-table-footer-cell` | 28 |
| [tableFooterRow](COMPONENTS.cosmopolitan.md#table-footer-row) | `mosaik-table-footer-row` | 28 |
| [tableHeader](COMPONENTS.cosmopolitan.md#table-header) | `mosaik-table-header` | 28 |
| [tableHeaderCell](COMPONENTS.cosmopolitan.md#table-header-cell) | `mosaik-table-header-cell` | 32 |
| [tableHeaderRow](COMPONENTS.cosmopolitan.md#table-header-row) | `mosaik-table-header-row` | 28 |
| [text](COMPONENTS.cosmopolitan.md#text) | `mosaik-text` | 34 |
| [textBox](COMPONENTS.cosmopolitan.md#textbox) | `mosaik-textbox` | 67 |
| [textEffect](COMPONENTS.cosmopolitan.md#text-effect) | `mosaik-text-effect` | 19 |
| [textFormat](COMPONENTS.cosmopolitan.md#text-format) | `mosaik-text-format` | 22 |
| [thumb](COMPONENTS.cosmopolitan.md#thumb) | `mosaik-thumb` | 27 |
| [thumbnail](COMPONENTS.cosmopolitan.md#thumbnail) | `mosaik-thumbnail` | 23 |
| [tickBar](COMPONENTS.cosmopolitan.md#tick-bar) | `mosaik-tick-bar` | 32 |
| [tile](COMPONENTS.cosmopolitan.md#tile) | `mosaik-tile` | 34 |
| [tileList](COMPONENTS.cosmopolitan.md#tile-list) | `mosaik-tile-list` | 23 |
| [tileListItem](COMPONENTS.cosmopolitan.md#tile-list-item) | `mosaik-tile-list-item` | 29 |
| [tileManager](COMPONENTS.cosmopolitan.md#tile-manager) | `mosaik-tile-manager` | 23 |
| [tileManagerTile](COMPONENTS.cosmopolitan.md#tile-manager-tile) | `mosaik-tile-manager-tile` | 52 |
| [timeBox](COMPONENTS.cosmopolitan.md#timebox) | `mosaik-timebox` | 43 |
| [timeline](COMPONENTS.cosmopolitan.md#timeline) | `mosaik-timeline` | 31 |
| [timelineContent](COMPONENTS.cosmopolitan.md#timeline-content) | `mosaik-timeline-content` | 23 |
| [timelineItem](COMPONENTS.cosmopolitan.md#timeline-item) | `mosaik-timeline-item` | 30 |
| [timelineMarker](COMPONENTS.cosmopolitan.md#timeline-marker) | `mosaik-timeline-marker` | 27 |
| [timelineOpposite](COMPONENTS.cosmopolitan.md#timeline-opposite) | `mosaik-timeline-opposite` | 23 |
| [timelineSeparator](COMPONENTS.cosmopolitan.md#timeline-separator) | `mosaik-timeline-separator` | 25 |
| [titleBar](COMPONENTS.cosmopolitan.md#title-bar) | `mosaik-title-bar` | 22 |
| [titleLayout](COMPONENTS.cosmopolitan.md#title-layout) | `mosaik-title-layout` | 23 |
| [toast](COMPONENTS.cosmopolitan.md#toast) | `mosaik-toast` | 42 |
| [toastActions](COMPONENTS.cosmopolitan.md#toast-actions) | `mosaik-toast-actions` | 22 |
| [toggleButton](COMPONENTS.cosmopolitan.md#toggle-button) | `mosaik-toggle-button` | 42 |
| [toggleButtonGroup](COMPONENTS.cosmopolitan.md#toggle-button-group) | `mosaik-toggle-button-group` | 28 |
| [toggleSwitch](COMPONENTS.cosmopolitan.md#toggle-switch) | `mosaik-toggle-switch` | 28 |
| [toggletip](COMPONENTS.cosmopolitan.md#toggletip) | `mosaik-toggletip` | 24 |
| [toolbar](COMPONENTS.cosmopolitan.md#toolbar) | `mosaik-toolbar` | 30 |
| [tooltip](COMPONENTS.cosmopolitan.md#tooltip) | `mosaik-tooltip` | 29 |
| [tour](COMPONENTS.cosmopolitan.md#tour) | `mosaik-tour` | 30 |
| [tourAnchor](COMPONENTS.cosmopolitan.md#tour-anchor) | `mosaik-tour-anchor` | 24 |
| [tourNav](COMPONENTS.cosmopolitan.md#tour-nav) | `mosaik-tour-nav` | 31 |
| [tourStep](COMPONENTS.cosmopolitan.md#tour-step) | `mosaik-tour-step` | 34 |
| [tree](COMPONENTS.cosmopolitan.md#tree) | `mosaik-tree` | 22 |
| [treeItem](COMPONENTS.cosmopolitan.md#tree-item) | `mosaik-tree-item` | 31 |
| [upDownSpinner](COMPONENTS.cosmopolitan.md#updown-spinner) | `mosaik-updown-spinner` | 22 |
| [video](COMPONENTS.cosmopolitan.md#video) | `mosaik-video` | 36 |
| [virtualize](COMPONENTS.cosmopolitan.md#virtualize) | `mosaik-virtualize` | 22 |
| [walletCard](COMPONENTS.cosmopolitan.md#wallet-card) | `mosaik-wallet-card` | 53 |
| [wheelPicker](COMPONENTS.cosmopolitan.md#wheel-picker) | `mosaik-wheel-picker` | 29 |
| [wizard](COMPONENTS.cosmopolitan.md#wizard) | `mosaik-wizard` | 23 |
| [wizardStep](COMPONENTS.cosmopolitan.md#wizard-step) | `mosaik-wizard-step` | 22 |
| [wrap](COMPONENTS.cosmopolitan.md#wrap) | `mosaik-wrap` | 22 |
<!-- /design-md:component-index -->

## Do's and Don'ts

### Do

- Consume `--mosaik-*` custom properties for anything you paint yourself; never copy a literal.
- Change a value in `libs/mosaik-themes/tokens/`, not in a component stylesheet, and add a new
  token to all three themes at once.
- Give controls the dark-to-light sheen through the helpers (`get-gradient()`), never a hand-made
  gradient; keep outline and plain controls flat.
- Separate resting surfaces with a `highlight` hairline; reserve the ambient shadow for what floats.
- Use cyan for links, focus, selection and the one primary action of a view.
- Load Noto Sans on every page that renders Cosmopolitan outside Windows.

### Don't

- Don't draw hairlines in a saturated color; a colored 1px border is a focus, `invalid` or
  `selected` state.
- Don't round corners beyond the radius token; pills and 12px radii belong to Joy.
- Don't put gradients on fields, surfaces or outline/plain controls.
- Don't move anything on hover or press; Metro feedback is light, line and colour.
- Don't pass numbers to `size` or `elevation`.
- Don't hard-code a color, spacing, radius, border or shadow.

### Named anti-patterns

- **Joy in disguise**: warm gray canvases, 12px radii and pills under the Cosmopolitan name.
- **Glossy overload**: strong, multi-stop gradients or a light top edge; the sheen runs softly and
  diagonally from dark at the top left to light at the bottom right and stays matte - not a gel button.
- **Bold everywhere**: Metro headlines are light; the bold uppercase `button` role is the only loud
  type.

## Known gaps

Generated from the same sources as the tables above; a finding here is a finding about the theme,
not about this document. Every component's anatomy is specialised in the modern Metro language:
hover, pressed, focus, selected and disabled states in every variant and appearance, light and
dark. The lists below are what remains at the token level.

<!-- design-md:gaps -->

### Theme references that resolve to nothing (0)

Component tokens pointing at theme properties that neither the compiled stylesheet nor `ThemeService` declares. The property is empty at runtime and the browser falls back to its initial value.

_none_

### References into other components (3)

These resolve only when the referenced component provides the property at runtime (a list item inside a list, a thumb inside a slider). Outside that context they are empty.

`--avatar-font-size` (1), `--data-table-cell-height` (1), `--pulse-ring-color` (1)

### Stylesheet properties the reference theme declares and this one does not (0 families)

Compared between the compiled `<theme>-style()` stylesheets; Joy is the reference theme, and Joy itself is compared against the names Memphis and Cosmopolitan agree on. With a `Theme2` / `provideTheme()` provider `ThemeService` writes these names from the theme object anyway; a page that loads only the stylesheet has them empty.

_none_

### Token files without a consuming component

`tokens/themes/cosmopolitan/components/accordion.json`, `tokens/themes/cosmopolitan/components/alert.json`, `tokens/themes/cosmopolitan/components/cardStack.json`, `tokens/themes/cosmopolitan/components/dotGroup.json`, `tokens/themes/cosmopolitan/components/gaugeInset.json`, `tokens/themes/cosmopolitan/components/numberTicker.json`, `tokens/themes/cosmopolitan/components/orbit.json`, `tokens/themes/cosmopolitan/components/pulse.json`, `tokens/themes/cosmopolitan/components/router.json`, `tokens/themes/cosmopolitan/components/routerAnchor.json`, `tokens/themes/cosmopolitan/components/routerLink.json`, `tokens/themes/cosmopolitan/components/routerOutlet.json`, `tokens/themes/cosmopolitan/components/slider2Thumb.json`, `tokens/themes/cosmopolitan/components/textEffect.json` define tokens no foundation component reads through its theme stylesheet.

### Token files consumed by more than one component

`tokens/themes/cosmopolitan/components/text.json` is read by 2 components; the export uses the `mosaik-text` prefix.

### Token files that feed the same custom property prefix

_none_

### Enum tokens missing from the theme file

_none_
<!-- /design-md:gaps -->

## Sources

| What                       | Where                                                                                                   |
| -------------------------- | ------------------------------------------------------------------------------------------------------- |
| Global tokens              | `libs/mosaik-themes/tokens/themes/cosmopolitan/cosmopolitan.json`, `tokens/themes/tokens.json`          |
| Component tokens           | `libs/mosaik-themes/tokens/themes/cosmopolitan/components/*.json`, mixins in `tokens/mixins/`          |
| Component anatomy          | `libs/mosaik-elements-foundation/src/controls/components/**/themes/*.Cosmopolitan.scss`                |
| Compiled tokens            | `libs/mosaik-themes/dist/themes/___cosmopolitan-tokens.css`, `dist/themes/cosmopolitan.scss`           |
| Runtime aliases            | `libs/mosaik-elements-foundation/src/theming/ThemeService.ts`                                           |
| Token model                | `.docs/design/tokens.md`, `.docs/design/tokens/1.token-schema-reference.md`                             |
| Component reference        | `apps/frontend/mosaik-showcase/public/llms/mosaik-<tag>.md`                                             |
| Regenerate                 | `yarn nx run mosaik-themes:build && yarn nx run mosaik-themes:design-md`                                |
| Verify                     | `yarn nx run mosaik-themes:design-md:check`                                                             |
