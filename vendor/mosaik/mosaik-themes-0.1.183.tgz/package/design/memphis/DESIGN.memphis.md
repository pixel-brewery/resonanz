---
version: 'alpha'
name: 'Mosaik Memphis'
description: 'Light-mode value snapshot of the Memphis theme: neo-brutalism with rounded corners, 2px ink outlines, hard offset shadows the face presses onto, pastel fills with ink text, Space Grotesk on a cream page. Consume the --mosaik-* custom properties, never these literals.'
colors:
  primary: '{colors.mosaik-color-primary-500}'
  mosaik-scheme-surface: '#ffffff'
  mosaik-scheme-background: '#fdf3e3'
  mosaik-scheme-foreground: '#111111'
  mosaik-scheme-highlight: '#ede2cf'
  mosaik-scheme-middlelight: '#a19b90'
  mosaik-scheme-lowlight: '#56524b'
  mosaik-scheme-transparent: 'rgba(253, 243, 227, 0)'
  mosaik-scheme-semi-transparent: 'rgba(253, 243, 227, 0.6666666666666666)'
  mosaik-scheme-disabled: '#9a958b'
  mosaik-scheme-contrast: '#111111'
  mosaik-scheme-selection: '#fde68a'
  mosaik-color-primary-0: '#ffffff'
  mosaik-color-primary-50: '#f1ebfe'
  mosaik-color-primary-100: '#dccefc'
  mosaik-color-primary-200: '#c5aefb'
  mosaik-color-primary-300: '#ae8df9'
  mosaik-color-primary-400: '#9c74f7'
  mosaik-color-primary-500: '#8b5cf6'
  mosaik-color-primary-600: '#7950d6'
  mosaik-color-primary-700: '#6140ac'
  mosaik-color-primary-800: '#4b3285'
  mosaik-color-primary-900: '#23173e'
  mosaik-color-secondary-0: '#ffffff'
  mosaik-color-secondary-50: '#fde9f3'
  mosaik-color-secondary-100: '#f9c8e0'
  mosaik-color-secondary-200: '#f6a4cc'
  mosaik-color-secondary-300: '#f27fb8'
  mosaik-color-secondary-400: '#ef63a8'
  mosaik-color-secondary-500: '#ec4899'
  mosaik-color-secondary-600: '#cd3f85'
  mosaik-color-secondary-700: '#a5326b'
  mosaik-color-secondary-800: '#7f2753'
  mosaik-color-secondary-900: '#3b1226'
  mosaik-color-tertiary-0: '#ffffff'
  mosaik-color-tertiary-50: '#fef9e3'
  mosaik-color-tertiary-100: '#fef0b9'
  mosaik-color-tertiary-200: '#fde68a'
  mosaik-color-tertiary-300: '#fcdb5b'
  mosaik-color-tertiary-400: '#fbd438'
  mosaik-color-tertiary-500: '#facc15'
  mosaik-color-tertiary-600: '#dab112'
  mosaik-color-tertiary-700: '#af8f0f'
  mosaik-color-tertiary-800: '#876e0b'
  mosaik-color-tertiary-900: '#3f3305'
  mosaik-color-info-0: '#ffffff'
  mosaik-color-info-50: '#e7f0fe'
  mosaik-color-info-100: '#c4dafc'
  mosaik-color-info-200: '#9dc1fb'
  mosaik-color-info-300: '#76a8f9'
  mosaik-color-info-400: '#5895f7'
  mosaik-color-info-500: '#3b82f6'
  mosaik-color-info-600: '#3371d6'
  mosaik-color-info-700: '#295bac'
  mosaik-color-info-800: '#204685'
  mosaik-color-info-900: '#0f213e'
  mosaik-color-warning-0: '#ffffff'
  mosaik-color-warning-50: '#feeee3'
  mosaik-color-warning-100: '#fdd5b9'
  mosaik-color-warning-200: '#fcb98b'
  mosaik-color-warning-300: '#fb9d5c'
  mosaik-color-warning-400: '#fa8839'
  mosaik-color-warning-500: '#f97316'
  mosaik-color-warning-600: '#d96413'
  mosaik-color-warning-700: '#ae510f'
  mosaik-color-warning-800: '#863e0c'
  mosaik-color-warning-900: '#3e1d06'
  mosaik-color-danger-0: '#ffffff'
  mosaik-color-danger-50: '#fde9e9'
  mosaik-color-danger-100: '#fac7c7'
  mosaik-color-danger-200: '#f7a2a2'
  mosaik-color-danger-300: '#f47c7c'
  mosaik-color-danger-400: '#f16060'
  mosaik-color-danger-500: '#ef4444'
  mosaik-color-danger-600: '#d03b3b'
  mosaik-color-danger-700: '#a73030'
  mosaik-color-danger-800: '#812525'
  mosaik-color-danger-900: '#3c1111'
  mosaik-color-success-0: '#ffffff'
  mosaik-color-success-50: '#e4f8ec'
  mosaik-color-success-100: '#bdeecf'
  mosaik-color-success-200: '#91e2af'
  mosaik-color-success-300: '#64d68e'
  mosaik-color-success-400: '#43ce76'
  mosaik-color-success-500: '#22c55e'
  mosaik-color-success-600: '#1eab52'
  mosaik-color-success-700: '#188a42'
  mosaik-color-success-800: '#126a33'
  mosaik-color-success-900: '#093118'
  mosaik-color-highlight-0: '#ffffff'
  mosaik-color-highlight-50: '#e3f6f4'
  mosaik-color-highlight-100: '#b9eae4'
  mosaik-color-highlight-200: '#8adcd3'
  mosaik-color-highlight-300: '#5bcdc1'
  mosaik-color-highlight-400: '#37c3b3'
  mosaik-color-highlight-500: '#14b8a6'
  mosaik-color-highlight-600: '#11a090'
  mosaik-color-highlight-700: '#0e8174'
  mosaik-color-highlight-800: '#0b635a'
  mosaik-color-highlight-900: '#052e2a'
  mosaik-color-neutral-0: '#ffffff'
  mosaik-color-neutral-50: '#efeeed'
  mosaik-color-neutral-100: '#d7d4d3'
  mosaik-color-neutral-200: '#bcb8b6'
  mosaik-color-neutral-300: '#a19c98'
  mosaik-color-neutral-400: '#8c8682'
  mosaik-color-neutral-500: '#78716c'
  mosaik-color-neutral-600: '#68625e'
  mosaik-color-neutral-700: '#544f4c'
  mosaik-color-neutral-800: '#413d3a'
  mosaik-color-neutral-900: '#1e1c1b'
typography:
  mosaik-typography-headline1:
    fontFamily: '''Space Grotesk'', ''Helvetica Neue'', Arial, sans-serif'
    fontSize: '64px'
    fontWeight: 700
    lineHeight: '68px'
    letterSpacing: '-1.5px'
  mosaik-typography-headline2:
    fontFamily: '''Space Grotesk'', ''Helvetica Neue'', Arial, sans-serif'
    fontSize: '48px'
    fontWeight: 700
    lineHeight: '52px'
    letterSpacing: '-1px'
  mosaik-typography-headline3:
    fontFamily: '''Space Grotesk'', ''Helvetica Neue'', Arial, sans-serif'
    fontSize: '36px'
    fontWeight: 700
    lineHeight: '40px'
    letterSpacing: '-0.5px'
  mosaik-typography-headline4:
    fontFamily: '''Space Grotesk'', ''Helvetica Neue'', Arial, sans-serif'
    fontSize: '28px'
    fontWeight: 700
    lineHeight: '32px'
    letterSpacing: '-0.25px'
  mosaik-typography-headline5:
    fontFamily: '''Space Grotesk'', ''Helvetica Neue'', Arial, sans-serif'
    fontSize: '22px'
    fontWeight: 700
    lineHeight: '28px'
  mosaik-typography-headline6:
    fontFamily: '''Space Grotesk'', ''Helvetica Neue'', Arial, sans-serif'
    fontSize: '18px'
    fontWeight: 700
    lineHeight: '24px'
  mosaik-typography-subtitle1:
    fontFamily: '''Space Grotesk'', ''Helvetica Neue'', Arial, sans-serif'
    fontSize: '16px'
    fontWeight: 600
    lineHeight: '22px'
  mosaik-typography-subtitle2:
    fontFamily: '''Space Grotesk'', ''Helvetica Neue'', Arial, sans-serif'
    fontSize: '14px'
    fontWeight: 600
    lineHeight: '20px'
  mosaik-typography-body1:
    fontFamily: '''Space Grotesk'', ''Helvetica Neue'', Arial, sans-serif'
    fontSize: '16px'
    fontWeight: 400
    lineHeight: '24px'
  mosaik-typography-body2:
    fontFamily: '''Space Grotesk'', ''Helvetica Neue'', Arial, sans-serif'
    fontSize: '14px'
    fontWeight: 400
    lineHeight: '20px'
  mosaik-typography-supporting:
    fontFamily: '''Space Grotesk'', ''Helvetica Neue'', Arial, sans-serif'
    fontSize: '12px'
    fontWeight: 500
    lineHeight: '16px'
  mosaik-typography-caption:
    fontFamily: '''Space Grotesk'', ''Helvetica Neue'', Arial, sans-serif'
    fontSize: '12px'
    fontWeight: 500
    lineHeight: '16px'
    letterSpacing: '0.2px'
  mosaik-typography-overline:
    fontFamily: '''Space Grotesk'', ''Helvetica Neue'', Arial, sans-serif'
    fontSize: '11px'
    fontWeight: 700
    lineHeight: '16px'
    letterSpacing: '1.5px'
  mosaik-typography-button:
    fontFamily: '''Space Grotesk'', ''Helvetica Neue'', Arial, sans-serif'
    fontSize: '15px'
    fontWeight: 700
    lineHeight: '20px'
    letterSpacing: '0.2px'
rounded:
  mosaik-layout-radius: '8px'
spacing:
  mosaik-layout-space: '10px'
  mosaik-layout-thickness: '2px'
  mosaik-size-tiny: '2px'
  mosaik-size-small: '4px'
  mosaik-size-medium: '8px'
  mosaik-size-large: '16px'
  mosaik-size-giant: '32px'
components:
  button:
    backgroundColor: '{colors.mosaik-scheme-surface}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    height: '56px'
    typography: '{typography.mosaik-typography-button}'
  button-checked:
    backgroundColor: '{colors.mosaik-scheme-contrast}'
    textColor: '{colors.mosaik-scheme-surface}'
  button-disabled:
    textColor: '{colors.mosaik-scheme-disabled}'
  button-outline:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
  button-outline-primary:
    textColor: '{colors.mosaik-color-primary-800}'
  button-plain:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
  button-plain-active:
    backgroundColor: '{colors.mosaik-scheme-middlelight}'
  button-plain-disabled:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  button-plain-hover:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
  button-plain-primary:
    textColor: '{colors.mosaik-color-primary-800}'
  button-selected:
    backgroundColor: '{colors.mosaik-scheme-contrast}'
    textColor: '{colors.mosaik-scheme-surface}'
  button-solid:
    backgroundColor: '{colors.mosaik-scheme-contrast}'
    textColor: '{colors.mosaik-scheme-surface}'
  toggle-button:
    backgroundColor: '{colors.mosaik-scheme-surface}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    typography: '{typography.mosaik-typography-button}'
  toggle-button-checked:
    backgroundColor: '{colors.mosaik-scheme-contrast}'
    textColor: '{colors.mosaik-scheme-surface}'
  toggle-button-disabled:
    textColor: '{colors.mosaik-scheme-disabled}'
  toggle-button-outline:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
  toggle-button-outline-primary:
    textColor: '{colors.mosaik-color-primary-800}'
  toggle-button-plain:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
  toggle-button-plain-active:
    backgroundColor: '{colors.mosaik-scheme-middlelight}'
  toggle-button-plain-disabled:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  toggle-button-plain-hover:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
  toggle-button-plain-primary:
    textColor: '{colors.mosaik-color-primary-800}'
  toggle-button-selected:
    backgroundColor: '{colors.mosaik-scheme-contrast}'
    textColor: '{colors.mosaik-scheme-surface}'
  toggle-button-solid:
    backgroundColor: '{colors.mosaik-scheme-contrast}'
    textColor: '{colors.mosaik-scheme-surface}'
  anchor:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-color-primary-800}'
    typography: '{typography.mosaik-typography-button}'
  anchor-disabled:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-disabled}'
  anchor-primary:
    textColor: '{colors.mosaik-color-primary-800}'
  badge:
    backgroundColor: '{colors.mosaik-scheme-surface}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '4px'
    typography: '{typography.mosaik-typography-overline}'
  badge-disabled:
    backgroundColor: '{colors.mosaik-scheme-surface}'
    textColor: '{colors.mosaik-scheme-disabled}'
  badge-outline:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-color-neutral-800}'
  badge-outline-primary:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-color-primary-800}'
  badge-plain:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-color-neutral-800}'
  badge-plain-primary:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-color-primary-800}'
  badge-solid:
    backgroundColor: '{colors.mosaik-scheme-contrast}'
    textColor: '{colors.mosaik-scheme-surface}'
  chip:
    backgroundColor: '{colors.mosaik-scheme-surface}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '7992px'
    height: '32px'
    typography: '{typography.mosaik-typography-body2}'
  chip-disabled:
    textColor: '{colors.mosaik-scheme-disabled}'
  chip-giant:
    height: '40px'
  chip-large:
    height: '36px'
  chip-plain-disabled:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  chip-small:
    height: '28px'
  chip-tiny:
    height: '24px'
  avatar:
    backgroundColor: '{colors.mosaik-scheme-surface}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '7992px'
  avatar-disabled:
    backgroundColor: '{colors.mosaik-scheme-surface}'
    textColor: '{colors.mosaik-scheme-disabled}'
  avatar-outline:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-color-neutral-800}'
  avatar-outline-primary:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-color-primary-800}'
  avatar-plain:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
  avatar-plain-primary:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-color-primary-800}'
  avatar-solid:
    backgroundColor: '{colors.mosaik-scheme-contrast}'
    textColor: '{colors.mosaik-scheme-surface}'
  persona:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '7992px'
  card:
    backgroundColor: '{colors.mosaik-scheme-surface}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '16px'
    typography: '{typography.mosaik-typography-body1}'
  card-disabled:
    textColor: '{colors.mosaik-scheme-disabled}'
  card-outline:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  card-outline-primary:
    textColor: '{colors.mosaik-color-primary-800}'
  card-plain:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  card-plain-disabled:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  card-plain-primary:
    textColor: '{colors.mosaik-color-primary-800}'
  card-selected:
    backgroundColor: '{colors.mosaik-scheme-contrast}'
    textColor: '{colors.mosaik-scheme-surface}'
  card-solid:
    backgroundColor: '{colors.mosaik-scheme-contrast}'
    textColor: '{colors.mosaik-scheme-surface}'
  card-header:
    padding: '20px'
  card-content:
    padding: '20px'
  textbox:
    backgroundColor: '{colors.mosaik-scheme-surface}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    height: '56px'
    typography: '{typography.mosaik-typography-body1}'
  textbox-disabled:
    textColor: '{colors.mosaik-scheme-disabled}'
  textbox-invalid:
    textColor: '{colors.mosaik-color-danger-700}'
  textbox-outline:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  textbox-outline-hover:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
  textbox-outline-primary-hover:
    backgroundColor: '{colors.mosaik-color-primary-100}'
  textbox-plain:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  textbox-plain-disabled:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  textbox-plain-hover:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
  textbox-plain-primary-hover:
    backgroundColor: '{colors.mosaik-color-primary-100}'
  textbox-plain-readonly:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  textbox-readonly:
    backgroundColor: '{colors.mosaik-scheme-background}'
  textbox-readonly-invalid:
    textColor: '{colors.mosaik-color-danger-700}'
  searchbox:
    backgroundColor: '{colors.mosaik-scheme-surface}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    height: '56px'
    typography: '{typography.mosaik-typography-body1}'
  searchbox-disabled:
    textColor: '{colors.mosaik-scheme-disabled}'
  searchbox-invalid:
    textColor: '{colors.mosaik-color-danger-700}'
  searchbox-outline:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  searchbox-outline-hover:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
  searchbox-outline-primary-hover:
    backgroundColor: '{colors.mosaik-color-primary-100}'
  searchbox-plain:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  searchbox-plain-disabled:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  searchbox-plain-hover:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
  searchbox-plain-primary-hover:
    backgroundColor: '{colors.mosaik-color-primary-100}'
  searchbox-plain-readonly:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  searchbox-readonly:
    backgroundColor: '{colors.mosaik-scheme-background}'
  searchbox-readonly-invalid:
    textColor: '{colors.mosaik-color-danger-700}'
  select:
    backgroundColor: '{colors.mosaik-scheme-surface}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    height: '56px'
    typography: '{typography.mosaik-typography-body1}'
  select-disabled:
    textColor: '{colors.mosaik-scheme-disabled}'
  select-invalid:
    textColor: '{colors.mosaik-color-danger-700}'
  select-outline:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  select-outline-hover:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
  select-outline-primary-hover:
    backgroundColor: '{colors.mosaik-color-primary-100}'
  select-plain:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  select-plain-disabled:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  select-plain-hover:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
  select-plain-primary-hover:
    backgroundColor: '{colors.mosaik-color-primary-100}'
  select-item:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    typography: '{typography.mosaik-typography-body2}'
  select-item-disabled:
    textColor: '{colors.mosaik-scheme-disabled}'
  select-item-hover:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
  checkbox:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '4px'
    typography: '{typography.mosaik-typography-body1}'
  radio:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '7992px'
    typography: '{typography.mosaik-typography-body1}'
  radio-invalid:
    textColor: '{colors.mosaik-color-danger-800}'
  toggle-switch:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '7992px'
    padding: '2.5px'
    typography: '{typography.mosaik-typography-body1}'
  slider:
    backgroundColor: '{colors.mosaik-scheme-surface}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '7992px'
    padding: '0px'
    typography: '{typography.mosaik-typography-body1}'
  slider-plain:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
  list:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    typography: '{typography.mosaik-typography-body1}'
  list-item:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    typography: '{typography.mosaik-typography-body1}'
  list-item-active:
    backgroundColor: '{colors.mosaik-scheme-contrast}'
    textColor: '{colors.mosaik-scheme-surface}'
  list-item-active-hover:
    backgroundColor: '{colors.mosaik-scheme-contrast}'
    textColor: '{colors.mosaik-scheme-surface}'
  list-item-checked:
    backgroundColor: '{colors.mosaik-scheme-contrast}'
    textColor: '{colors.mosaik-scheme-surface}'
  list-item-checked-active:
    backgroundColor: '{colors.mosaik-scheme-contrast}'
    textColor: '{colors.mosaik-scheme-surface}'
  list-item-checked-hover:
    backgroundColor: '{colors.mosaik-scheme-contrast}'
    textColor: '{colors.mosaik-scheme-surface}'
  list-item-disabled:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-disabled}'
  list-item-hover:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
  list-item-selected:
    backgroundColor: '{colors.mosaik-scheme-contrast}'
    textColor: '{colors.mosaik-scheme-surface}'
  list-item-selected-active:
    backgroundColor: '{colors.mosaik-scheme-contrast}'
    textColor: '{colors.mosaik-scheme-surface}'
  list-item-selected-hover:
    backgroundColor: '{colors.mosaik-scheme-contrast}'
    textColor: '{colors.mosaik-scheme-surface}'
  menu:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    padding: '5px'
    typography: '{typography.mosaik-typography-body1}'
  menu-item:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    height: '45px'
    typography: '{typography.mosaik-typography-body1}'
  menu-item-active:
    backgroundColor: '{colors.mosaik-scheme-contrast}'
    textColor: '{colors.mosaik-scheme-surface}'
  menu-item-active-hover:
    backgroundColor: '{colors.mosaik-scheme-contrast}'
    textColor: '{colors.mosaik-scheme-surface}'
  menu-item-checked:
    backgroundColor: '{colors.mosaik-scheme-contrast}'
    textColor: '{colors.mosaik-scheme-surface}'
  menu-item-checked-active:
    backgroundColor: '{colors.mosaik-scheme-contrast}'
    textColor: '{colors.mosaik-scheme-surface}'
  menu-item-checked-hover:
    backgroundColor: '{colors.mosaik-scheme-contrast}'
    textColor: '{colors.mosaik-scheme-surface}'
  menu-item-disabled:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-disabled}'
  menu-item-hover:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
  menu-item-plain-primary:
    textColor: '{colors.mosaik-color-primary-800}'
  menu-item-plain-primary-hover:
    backgroundColor: '{colors.mosaik-color-primary-100}'
  menu-item-selected:
    backgroundColor: '{colors.mosaik-scheme-contrast}'
    textColor: '{colors.mosaik-scheme-surface}'
  menu-item-selected-active:
    backgroundColor: '{colors.mosaik-scheme-contrast}'
    textColor: '{colors.mosaik-scheme-surface}'
  menu-item-selected-hover:
    backgroundColor: '{colors.mosaik-scheme-contrast}'
    textColor: '{colors.mosaik-scheme-surface}'
  tab:
    backgroundColor: '{colors.mosaik-scheme-surface}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '16px'
    typography: '{typography.mosaik-typography-body1}'
  tab-disabled:
    textColor: '{colors.mosaik-scheme-disabled}'
  tab-outline:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  tab-plain:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  tab-item:
    rounded: '{rounded.mosaik-layout-radius}'
  tooltip:
    backgroundColor: '{colors.mosaik-scheme-contrast}'
    textColor: '{colors.mosaik-scheme-background}'
    rounded: '6px'
    typography: '{typography.mosaik-typography-body2}'
  dialog:
    backgroundColor: '{colors.mosaik-scheme-surface}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '16px'
    typography: '{typography.mosaik-typography-body1}'
  drawer:
    backgroundColor: '{colors.mosaik-scheme-surface}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '16px'
    width: '320px'
    typography: '{typography.mosaik-typography-body1}'
  toast:
    backgroundColor: '{colors.mosaik-scheme-surface}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '20px'
    typography: '{typography.mosaik-typography-body1}'
  toast-outline:
    backgroundColor: '{colors.mosaik-scheme-background}'
    textColor: '{colors.mosaik-scheme-foreground}'
  toast-outline-primary:
    textColor: '{colors.mosaik-color-primary-800}'
  toast-plain:
    backgroundColor: '{colors.mosaik-scheme-background}'
    textColor: '{colors.mosaik-scheme-foreground}'
  toast-plain-primary:
    textColor: '{colors.mosaik-color-primary-800}'
  toast-soft:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
    textColor: '{colors.mosaik-scheme-foreground}'
  toast-solid:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
    textColor: '{colors.mosaik-scheme-foreground}'
  banner:
    backgroundColor: '{colors.mosaik-scheme-surface}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '16px'
    typography: '{typography.mosaik-typography-body1}'
  banner-disabled:
    textColor: '{colors.mosaik-scheme-disabled}'
  banner-outline:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  banner-plain:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  banner-plain-disabled:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  divider:
    backgroundColor: '{colors.mosaik-scheme-contrast}'
    textColor: '{colors.mosaik-scheme-foreground}'
    typography: '{typography.mosaik-typography-supporting}'
  skeleton:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
    rounded: '4px'
  expander:
    backgroundColor: '{colors.mosaik-scheme-surface}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '16px'
    typography: '{typography.mosaik-typography-body1}'
  expander-disabled:
    textColor: '{colors.mosaik-scheme-disabled}'
  expander-outline:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  expander-plain:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  expander-plain-disabled:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  breadcrumb-item:
    textColor: '{colors.mosaik-color-primary-800}'
    padding: '0px'
    typography: '{typography.mosaik-typography-body2}'
  breadcrumb-item-active:
    textColor: '{colors.mosaik-scheme-foreground}'
  breadcrumb-item-disabled:
    textColor: '{colors.mosaik-scheme-disabled}'
  breadcrumb-item-primary:
    textColor: '{colors.mosaik-color-primary-800}'
  app-header:
    backgroundColor: '{colors.mosaik-scheme-surface}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    typography: '{typography.mosaik-typography-headline6}'
  text:
    backgroundColor: 'transparent'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '0px'
    padding: '0px'
    typography: '{typography.mosaik-typography-body1}'
  text-disabled:
    textColor: '{colors.mosaik-scheme-disabled}'
  text-primary:
    textColor: '{colors.mosaik-color-primary-800}'
---

<!--
The YAML frontmatter and every `design-md:*` region of this file are generated by
libs/mosaik-themes/bin/design-md.mjs from the memphis token sources. Build the themes
package, then run `yarn nx run mosaik-themes:design-md`; `yarn nx run mosaik-themes:design-md:check`
fails while the generated parts have drifted. All other prose is hand-authored and must not be
generated away.

Format: DESIGN.md (https://github.com/google-labs-code/design.md), linted with @google/design.md.
-->

# Mosaik Memphis

## Overview

Memphis is Mosaik's loud theme: **neo-brutalism**, playful, bold and tactile. Every control is a
block lying on a cream page: rounded corners from the radius token, a thick ink outline, and a
**hard offset shadow without blur**. Hovering moves the block halfway onto its shadow, pressing
pushes it fully onto the shadow, which disappears. Fills are pastels with dark ink text, the
high-contrast "dark solid" inverts ink and paper, disabled surfaces are hatched, and the type is a
heavy grotesk (Space Grotesk) with tracked uppercase labels. Dark mode turns the page near-black and
draws outlines and shadows in cream; pastels keep their ink text. Use Memphis for creative tools,
entertainment, dashboards and brand experiences that want energy and high contrast.

Mosaik **is** the design system. Only the **names** are fixed: a product overrides values through
`provideTheme()` / `Theme2` and every component follows, because components never read literals,
only tokens. Memphis is one of the three value sets Mosaik ships for that vocabulary, and it also
carries its own component anatomy in the `*.Memphis.scss` theme stylesheets.

Two token layers are fixed for this theme and captured in this document:

1. **The global set** from `tokens/themes/memphis/memphis.json` (merged with
   `tokens/themes/tokens.json`): scheme roles, nine color ramps, fourteen typography roles, layout
   rhythm, elevation, durations and the enum vocabularies, published as `--mosaik-*` custom
   properties and listed in the frontmatter as a light-mode snapshot.
2. **The component set**: one token file per component under `tokens/themes/memphis/components/`,
   expanded with the shared mixins. Every entry becomes a `--<component>-<token>` custom property
   on the component's shadow host and is public styling API. The complete export, resolved to
   literals, is [COMPONENTS.memphis.md](COMPONENTS.memphis.md); the core atoms are also projected into the
   `components` block of the frontmatter.

Consumers never address a theme by its own prefix. The outward contract is the `--mosaik-*`
family: `ThemeService`, driven by `Theme2` or `provideTheme()`, remaps it onto the active theme's
internal `--<theme>-*` properties, which is what lets every theme, and every product built on one,
be used generically from outside.

Use this precedence whenever sources disagree:

1. The token sources in `libs/mosaik-themes/tokens/` and the component theme stylesheets.
2. The compiled artifacts (`dist/themes/___memphis-tokens.css`, `memphis-style()`) and the runtime
   `--mosaik-*` / `--memphis-*` properties.
3. This document and [COMPONENTS.memphis.md](COMPONENTS.memphis.md).

### At a glance

<!-- design-md:stats -->

| Layer | Count | Source |
|---|---|---|
| Global tokens (compiled) | 448 | `dist/themes/___memphis-tokens.css` |
| Runtime custom properties (light) | 593 | `memphis-style()` and `ThemeService` |
| Components with a token file | 378 | `tokens/themes/memphis/components/` |
| Component tokens (mixins expanded) | 11098 | `src/themes/memphis/_components/` |
| Component tokens that do not resolve | 3 | [Known gaps](#known-gaps) |
<!-- /design-md:stats -->

### Activating the theme

The theme is selected by the `theme` attribute on `<html>` and the mode by `theme-mode`; both have
to be in place before any element module evaluates. Memphis is set in **Space Grotesk** (weights
300-700) with `'Helvetica Neue', Arial, sans-serif` as the fallback; load it, nothing in the theme
ships a `@font-face`.

```html
<html lang="en" theme="memphis" theme-mode="light">
  <head>
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300..700&display=swap" rel="stylesheet" />
    <script type="module">
      import { MemphisTheme, ThemeObserverServiceLocator } from 'https://esm.run/@pixel-brewery/mosaik-themes';
      const root = document.documentElement;
      ThemeObserverServiceLocator.current.applyTheme(root.getAttribute('theme') ?? 'memphis', root.getAttribute('theme-mode') ?? 'light');
      await customElements.whenDefined('mosaik-theme2');
      document.querySelector('mosaik-theme2').theme = MemphisTheme.MEMPHIS_THEME;
    </script>
    <script type="module" src="https://esm.run/@pixel-brewery/mosaik-elements-foundation"></script>
  </head>
  <body>
    <mosaik-theme2>
      <mosaik-button label="Play" variant="primary" appearance="solid"></mosaik-button>
    </mosaik-theme2>
  </body>
</html>
```

In a framework app the same happens through `provideTheme()` (Angular) or
`<Theme2 theme={memphisTheme} global>` (React). Your own markup gets no font or color by default:
set `font-family: var(--mosaik-font-family)`, `color: var(--mosaik-scheme-foreground)` and
`background: var(--mosaik-scheme-background)` on `body`.

## Colors

Memphis draws with **ink on paper**. The page is a warm cream (`background`, `#fdf3e3`), raised
panels are white (`surface`), and both `foreground` and `contrast` are the ink (`#111111`): the
color of the text, of every outline and of every hard shadow. Read `contrast` as "the line", not as
"text on primary". `highlight` is a warm beige (`#ede2cf`) for hover fills and the light stripe of
the hatch, `middlelight` and `lowlight` are warm greys for secondary lines and text, `disabled` a
muted stone, and the text selection is a pastel yellow (`#fde68a`). Dark mode keeps the idea and
swaps paper and ink: a near-black page (`#16161d`), `#22222c` panels, cream (`#fdf3e3`) text,
outlines and shadows, a `#34343f` `highlight` and a violet selection.

The nine ramps are Memphis' own: violet `primary`, pink `secondary`, yellow `tertiary`, blue
`info`, orange `warning`, red `danger`, green `success`, teal `highlight` and a warm-grey `neutral`,
mixed from their `500` seed with the same algorithm the ThemeGenerator uses for custom palettes
(`0` is white, light stops towards white, dark stops towards black; the dark palette is inverted).
**Pastels** are the light stops `100`-`300` of the light palette and fill `solid` and `soft`
controls, stat cards and badges in both modes, always with dark ink text, so a pastel never needs
to be re-tuned for dark mode.

### Scheme roles

<!-- design-md:scheme -->

| Role | Custom property | Light | Dark | Purpose |
|---|---|---|---|---|
| `surface` | `--mosaik-scheme-surface` | `#ffffff` | `#22222c` | Elevated surfaces: cards, dialogs, panels. |
| `background` | `--mosaik-scheme-background` | `#fdf3e3` | `#16161d` | Page canvas and the default component fill. |
| `foreground` | `--mosaik-scheme-foreground` | `#111111` | `#fdf3e3` | Default text and icon color. |
| `highlight` | `--mosaik-scheme-highlight` | `#ede2cf` | `#34343f` | Borders, dividers, hover fills. |
| `middlelight` | `--mosaik-scheme-middlelight` | `#a19b90` | `#787684` | Medium contrast - strokes, dividers, inactive marks and quiet fills. |
| `lowlight` | `--mosaik-scheme-lowlight` | `#56524b` | `#c9c3b6` | The stronger secondary grey - secondary text, placeholders, captions and hints. |
| `transparent` | `--mosaik-scheme-transparent` | `rgba(253, 243, 227, 0)` | `rgba(22, 22, 29, 0)` | Fully transparent fill. |
| `semi-transparent` | `--mosaik-scheme-semi-transparent` | `rgba(253, 243, 227, 0.6666666666666666)` | `rgba(22, 22, 29, 0.6666666666666666)` | Glass-like overlays and backdrops. |
| `disabled` | `--mosaik-scheme-disabled` | `#9a958b` | `#6c6a77` | Disabled text and controls. |
| `contrast` | `--mosaik-scheme-contrast` | `#111111` | `#fdf3e3` | Content on strongly colored surfaces. |
| `selection` | `--mosaik-scheme-selection` | `#fde68a` | `#5b4a9e` | Text selection background. |
<!-- /design-md:scheme -->

### Color ramps

<!-- design-md:palette -->

Light mode (`--mosaik-color-<family>-<stop>` resolves to these while `theme-mode="light"`):

| Family | 0 | 50 | 100 | 200 | 300 | 400 | 500 | 600 | 700 | 800 | 900 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| `primary` | `#ffffff` | `#f1ebfe` | `#dccefc` | `#c5aefb` | `#ae8df9` | `#9c74f7` | `#8b5cf6` | `#7950d6` | `#6140ac` | `#4b3285` | `#23173e` |
| `secondary` | `#ffffff` | `#fde9f3` | `#f9c8e0` | `#f6a4cc` | `#f27fb8` | `#ef63a8` | `#ec4899` | `#cd3f85` | `#a5326b` | `#7f2753` | `#3b1226` |
| `tertiary` | `#ffffff` | `#fef9e3` | `#fef0b9` | `#fde68a` | `#fcdb5b` | `#fbd438` | `#facc15` | `#dab112` | `#af8f0f` | `#876e0b` | `#3f3305` |
| `info` | `#ffffff` | `#e7f0fe` | `#c4dafc` | `#9dc1fb` | `#76a8f9` | `#5895f7` | `#3b82f6` | `#3371d6` | `#295bac` | `#204685` | `#0f213e` |
| `warning` | `#ffffff` | `#feeee3` | `#fdd5b9` | `#fcb98b` | `#fb9d5c` | `#fa8839` | `#f97316` | `#d96413` | `#ae510f` | `#863e0c` | `#3e1d06` |
| `danger` | `#ffffff` | `#fde9e9` | `#fac7c7` | `#f7a2a2` | `#f47c7c` | `#f16060` | `#ef4444` | `#d03b3b` | `#a73030` | `#812525` | `#3c1111` |
| `success` | `#ffffff` | `#e4f8ec` | `#bdeecf` | `#91e2af` | `#64d68e` | `#43ce76` | `#22c55e` | `#1eab52` | `#188a42` | `#126a33` | `#093118` |
| `highlight` | `#ffffff` | `#e3f6f4` | `#b9eae4` | `#8adcd3` | `#5bcdc1` | `#37c3b3` | `#14b8a6` | `#11a090` | `#0e8174` | `#0b635a` | `#052e2a` |
| `neutral` | `#ffffff` | `#efeeed` | `#d7d4d3` | `#bcb8b6` | `#a19c98` | `#8c8682` | `#78716c` | `#68625e` | `#544f4c` | `#413d3a` | `#1e1c1b` |

Dark mode (the same names resolve to these while `theme-mode="dark"`):

| Family | 0 | 50 | 100 | 200 | 300 | 400 | 500 | 600 | 700 | 800 | 900 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| `primary` | `#000000` | `#150e25` | `#2a1c4a` | `#3f296f` | `#533794` | `#6845b9` | `#7d53dd` | `#8b5cf6` | `#ae8df9` | `#c0a7fa` | `#e2d6fd` |
| `secondary` | `#000000` | `#230b17` | `#47162e` | `#6a2045` | `#8e2b5c` | `#b13673` | `#d4418a` | `#ec4899` | `#f27fb8` | `#f59cc8` | `#fad1e6` |
| `tertiary` | `#000000` | `#261f03` | `#4b3d06` | `#715c09` | `#967a0d` | `#bc9910` | `#e1b813` | `#facc15` | `#fcdb5b` | `#fce381` | `#fef2c5` |
| `info` | `#000000` | `#091425` | `#12274a` | `#1b3b6f` | `#234e94` | `#2c62b9` | `#3575dd` | `#3b82f6` | `#76a8f9` | `#95bcfa` | `#cee0fd` |
| `warning` | `#000000` | `#251103` | `#4b2307` | `#70340a` | `#95450d` | `#bb5611` | `#e06814` | `#f97316` | `#fb9d5c` | `#fcb381` | `#fedcc5` |
| `danger` | `#000000` | `#240a0a` | `#481414` | `#6c1f1f` | `#8f2929` | `#b33333` | `#d73d3d` | `#ef4444` | `#f47c7c` | `#f69a9a` | `#fbd0d0` |
| `success` | `#000000` | `#051e0e` | `#0a3b1c` | `#0f592a` | `#147638` | `#1a9447` | `#1fb155` | `#22c55e` | `#64d68e` | `#88e0a8` | `#c8f1d7` |
| `highlight` | `#000000` | `#031c19` | `#063732` | `#09534b` | `#0c6e64` | `#0f8a7d` | `#12a695` | `#14b8a6` | `#5bcdc1` | `#80d9cf` | `#c4ede9` |
| `neutral` | `#000000` | `#121110` | `#242220` | `#363331` | `#484441` | `#5a5551` | `#6c6661` | `#78716c` | `#a19c98` | `#b6b2b0` | `#dddcda` |
<!-- /design-md:palette -->

### How variant and appearance pick a stop

Memphis applies the variant in every appearance; the appearance decides how the colour is cut out
of the paper. The mapping is the button's (`ButtonElement.Memphis.scss`) and every button-like
control (toggle, split, drop-down, compound, press and repeat buttons, FAB, tile, icon button)
follows it; the frontmatter `components` block carries the projected values for `primary`, and the
same stops apply to every other variant. `get-pastel()` and `get-ink()` in the theme bundle
(`src/themes/memphis/_Brutalism.scss`) are the only readers of the light palette.

| Appearance | Neutral (no variant)                                                  | With a variant `v`                                         |
| ---------- | --------------------------------------------------------------------- | ---------------------------------------------------------- |
| `default`  | `surface` fill, `foreground` text, ink outline, ink hard shadow        | as neutral, with a **coloured** `v-500` shadow             |
| `solid`    | dark solid: `contrast` fill, `surface` text (cream fill in dark mode)  | pastel `v-200` fill, ink text, ink outline and shadow      |
| `soft`     | pastel `neutral-100`, ink text                                        | pastel `v-100`, ink text                                   |
| `outline`  | transparent, **dashed** ink outline, tinted shadow                    | text `v-800`, shadow `v-200`                               |
| `plain`    | no outline, no shadow, `foreground` text                              | text `v-800`; hover `v-100`, pressed `v-200` fills         |

The face of the control (`[part='button']`) carries outline and shadow and moves; the host, and with
it the hit box and the focus ring, never does. At rest the face sits above its hard shadow (the
`semilight` offset, 3px). **Hover** moves the face halfway towards its shadow while the shadow
shrinks by the same amount, so its outer edge stays put; **pressing** (and `is-busy`) moves the face
fully onto the shadow, which disappears. Checked and selected controls become the dark solid, or a
stronger pastel (`v-300`) with ink text. **Disabled** controls are hatched with diagonal
`surface`/`highlight` stripes, a `middlelight` outline, `disabled` text and a small muted shadow.

Fields (the text box family, select, combo, pin and chip boxes, rich text, prompt box) are white
sheets that never move: ink outline and a `regular` hard shadow that grows on hover; the shadow
takes `primary-500` (or the variant's `500`) on focus and `danger-500` when the field is invalid,
and the label floats as an uppercase `overline`. Fields carry no variant colour at rest. `readonly`
fields lie flat on the page (`background` fill, `middlelight` outline, no shadow), disabled fields
are hatched, `plain` fields keep only the bottom rule.

### Naming rules

- `--mosaik-scheme-<role>` and `--mosaik-color-<family>-<stop>` are the consumer contract, aliases
  that `ThemeService` writes on `<html>` pointing at the `--memphis-*` originals.
- Mode-specific names exist only under the theme prefix (`--memphis-scheme-light-contrast`). Never
  introduce `dark-*` token names.
- Contrast: pastel fills always carry ink text (`get-ink()`), which passes AA on every pastel in
  both modes. Text drawn in a variant colour on paper uses stop `800`; `500`/`600` are for fills,
  outlines, rings and shadows.

## Typography

Memphis speaks **Space Grotesk**, a geometric grotesk with a lot of character at heavy weights.
Headlines are bold (700), from a 64px `headline1` to an 18px `headline6`, tightly tracked at the
large sizes; `body1` is 16px/24px and `body2` 14px/20px for reading, `subtitle1`/`subtitle2`
semibold. `button` is a bold 15px in sentence case, and `overline` is the theme's label voice:
11px bold **uppercase with 1.5px tracking**, used for field labels, card sub-titles, badges, tags
and table headers. The fourteen role names are the complete vocabulary; a product may change their
values but must not rename them or add roles. Each role publishes `--mosaik-typography-<role>` as
a `font` shorthand plus the individual parts, and per-role families default to
`var(--font-family)`.

<!-- design-md:typography -->

| Role | Custom property | Family | Size | Line height | Weight | Letter spacing | Transform |
|---|---|---|---|---|---|---|---|
| `headline1` | `--mosaik-typography-headline1` | `'Space Grotesk', 'Helvetica Neue', Arial, sans-serif` | `64px` | `68px` | `700` | `-1.5px` | `none` |
| `headline2` | `--mosaik-typography-headline2` | `'Space Grotesk', 'Helvetica Neue', Arial, sans-serif` | `48px` | `52px` | `700` | `-1px` | `none` |
| `headline3` | `--mosaik-typography-headline3` | `'Space Grotesk', 'Helvetica Neue', Arial, sans-serif` | `36px` | `40px` | `700` | `-0.5px` | `none` |
| `headline4` | `--mosaik-typography-headline4` | `'Space Grotesk', 'Helvetica Neue', Arial, sans-serif` | `28px` | `32px` | `700` | `-0.25px` | `none` |
| `headline5` | `--mosaik-typography-headline5` | `'Space Grotesk', 'Helvetica Neue', Arial, sans-serif` | `22px` | `28px` | `700` | `normal` | `none` |
| `headline6` | `--mosaik-typography-headline6` | `'Space Grotesk', 'Helvetica Neue', Arial, sans-serif` | `18px` | `24px` | `700` | `normal` | `none` |
| `subtitle1` | `--mosaik-typography-subtitle1` | `'Space Grotesk', 'Helvetica Neue', Arial, sans-serif` | `16px` | `22px` | `600` | `normal` | `none` |
| `subtitle2` | `--mosaik-typography-subtitle2` | `'Space Grotesk', 'Helvetica Neue', Arial, sans-serif` | `14px` | `20px` | `600` | `normal` | `none` |
| `body1` | `--mosaik-typography-body1` | `'Space Grotesk', 'Helvetica Neue', Arial, sans-serif` | `16px` | `24px` | `400` | `normal` | `none` |
| `body2` | `--mosaik-typography-body2` | `'Space Grotesk', 'Helvetica Neue', Arial, sans-serif` | `14px` | `20px` | `400` | `normal` | `none` |
| `supporting` | `--mosaik-typography-supporting` | `'Space Grotesk', 'Helvetica Neue', Arial, sans-serif` | `12px` | `16px` | `500` | `normal` | `none` |
| `caption` | `--mosaik-typography-caption` | `'Space Grotesk', 'Helvetica Neue', Arial, sans-serif` | `12px` | `16px` | `500` | `0.2px` | `none` |
| `overline` | `--mosaik-typography-overline` | `'Space Grotesk', 'Helvetica Neue', Arial, sans-serif` | `11px` | `16px` | `700` | `1.5px` | `uppercase` |
| `button` | `--mosaik-typography-button` | `'Space Grotesk', 'Helvetica Neue', Arial, sans-serif` | `15px` | `20px` | `700` | `0.2px` | `none` |
<!-- /design-md:typography -->

Type and geometry shout together: bold headlines, bold buttons, uppercase labels. Body text stays
regular and readable; reserve the uppercase overline for short labels.

## Layout

Memphis is **chunky**: a 10px base unit instead of Joy's 8px, a 2px ink stroke and an 8px radius.
Every padding, gap and margin is a `calc()` multiple of `layout.space`; every outline, divider and
indicator is `layout.thickness` wide; every corner derives from `layout.radius`.

<!-- design-md:layout -->

| Token | Custom property | Value | Role |
|---|---|---|---|
| `layout.space` | `--mosaik-layout-space` | `10px` | Base unit of every padding, gap and margin; components scale it with `calc()`. |
| `layout.radius` | `--mosaik-layout-radius` | `8px` | Corner radius of every rectangular surface. |
| `layout.thickness` | `--mosaik-layout-thickness` | `2px` | Border width of controls, dividers and indicators. |

The size vocabulary components accept as `size`, `gap` or `iconSize` (values from `tokens/themes/tokens.json`; these are enum steps, not runtime custom properties):

| Key | Value |
|---|---|
| `tiny` | `2px` |
| `small` | `4px` |
| `medium` | `8px` |
| `large` | `16px` |
| `giant` | `32px` |
<!-- /design-md:layout -->

Layout is composed with `mosaik-stack` and `mosaik-grid`, never with margins. Tailwind consumers
layer `@pixel-brewery/mosaik-themes/tailwind/v4/memphis`, which pins Tailwind's `--spacing` to the
10px unit.

## Elevation & Depth

Depth in Memphis is **physical, not atmospheric**. Every level is one hard shadow with equal x and
y offset, zero blur and zero spread, drawn in the `contrast` role: ink in light mode, cream in dark
mode. The offset grows from 2px (`light`) through 3px, 4px, 5px and 6px to 8px (`extrabold`), and
the weight follows the size of the thing: small controls (checkbox, radio, chip, badge) sit on
`light`, buttons on `semilight`, fields on `regular`, cards and panels on `bold`, overlays (dialog,
menu, popup, toast) on `extrabold`. A non-neutral variant on the `default` appearance colours the
shadow (`v-500`), the theme's way of adding emphasis without filling the block. Components expose
the scale as the named `elevation` prop.

<!-- design-md:elevation -->

Every level is a stack of 1 shadow layer. `--mosaik-elevation-<level>` carries the complete `box-shadow` value; `--mosaik-elevation-<level>-{offset-x,offset-y,blur,spread,color}` expose the primary layer.

| Level | Light | Dark |
|---|---|---|
| `none` | `none` | `none` |
| `light` | `2px 2px 0px 0px #111111` | `2px 2px 0px 0px #fdf3e3` |
| `semilight` | `3px 3px 0px 0px #111111` | `3px 3px 0px 0px #fdf3e3` |
| `regular` | `4px 4px 0px 0px #111111` | `4px 4px 0px 0px #fdf3e3` |
| `semibold` | `5px 5px 0px 0px #111111` | `5px 5px 0px 0px #fdf3e3` |
| `bold` | `6px 6px 0px 0px #111111` | `6px 6px 0px 0px #fdf3e3` |
| `extrabold` | `8px 8px 0px 0px #111111` | `8px 8px 0px 0px #fdf3e3` |
<!-- /design-md:elevation -->

Because the shadow is part of the block's silhouette, hover and press change it together with the
face: halfway on hover, fully on press. Never add a blurred shadow on top; blur breaks the
brutalist block.

## Shapes

Memphis geometry is **rounded and blocky**. Corners derive from `layout.radius` (8px) in four
classes: controls (buttons, fields, tab strips, segmented controls) take the radius itself; small
marks (the checkbox box, badges, tags, key caps) take half of it; surfaces (cards, dialogs, menus,
popups, banners, expanders) take twice the radius; and pill-shaped components (chips, switches,
progress tracks, slider tracks, radios, avatars) are fully round, `calc(radius * 999)`. Every
interactive control, field and surface carries the 2px ink outline; items inside an outlined
container (list and menu items) stay unframed until they are selected.

Focus is an opaque cut line: the ring is drawn at `layout.thickness` in ink (or the variant's
`500` stop) at twice the stroke outside the control and follows its radius, without Joy's
translucent halo.

## Motion

Memphis moves like **cardboard**: translation, not deformation. Hover moves a pressable face half
the shadow offset towards its shadow, press moves it the full offset, both over `duration.short`
with an `ease` curve on `background-color`, `color`, `border-color`, `opacity`, `box-shadow` and
`translate`. Only inner faces (the button face, the checkbox box, a slider thumb) move, never a host
element. Pastel and hatch fills switch instantly, since background images do not interpolate. The
ripple stays transparent; the theme's feedback is the press.

<!-- design-md:motion -->

| Token | Custom property | Value | Role |
|---|---|---|---|
| `duration.short` | `--mosaik-duration-short` | `0.2s` | Hover, focus and color transitions; the default `transition-duration` of components. |
| `duration.medium` | `--mosaik-duration-medium` | `0.4s` | Expand, collapse and reveal. |
| `duration.long` | `--mosaik-duration-long` | `0.6s` | Page-level and staged motion. |
<!-- /design-md:motion -->

Components honour `prefers-reduced-motion` by collapsing durations to `0.01ms`.

## Components

Mosaik components are Lit web components; the framework packages are thin wrappers over the same
custom elements. The public language is expressed as **props, not classes**:

| Prop         | Values                                                                                                             |
| ------------ | ------------------------------------------------------------------------------------------------------------------ |
| `variant`    | `default`, `primary`, `secondary`, `tertiary`, `danger`, `warning`, `success`, `info`, `highlight`, `neutral`       |
| `appearance` | `default`, `outline`, `plain`, `soft`, `solid`                                                                     |
| `size`       | `tiny`, `small`, `medium`, `large`, `giant`                                                                        |
| `elevation`  | `none`, `light`, `semilight`, `regular`, `semibold`, `bold`, `extrabold`                                            |
| others       | `inset`, `fit`, `orientation`, `disabled`, `isBusy`, `isSelected` for spacing, sizing, direction and state          |

Not every component accepts all of them; the component's typings are authoritative. Text travels
through attributes (`label`, `text`, `header`), and containers only project their own sub
components.

### The component token contract

Each component owns one token file. The base skeleton (`tokens/themes/components.json`) gives
every component sixteen `unset` slots for font, padding, gap, transition and translate; mixins add
opt-in groups through `$includes`, and the component file sets the values that differ, always as
references to the global tokens. The merged map is declared on the shadow host as
`--<prefix>-<token>` custom properties, documented as `@cssprop` in the component's TSDoc, and any
of them can be overridden from outside:

```css
mosaik-button { --button-shadow-offset-x: 6px; --button-shadow-offset-y: 6px; }
mosaik-card   { --card-border-width: 1px; }
```

The mixin catalogue is the one shared by all themes; Memphis differs in the values it assigns.
Notable Memphis defaults: the button face is `surface` with a `contrast` (ink) outline, its shadow
tokens point at the `semilight` level and its focus ring is ink at twice the stroke; fields are
`surface` sheets on the `regular` level with an overline label; cards sit on `bold` with twice the
radius.

| Mixin          | Tokens it contributes                                                                                          |
| -------------- | -------------------------------------------------------------------------------------------------------------- |
| `border`       | `borderColor`, `borderRadius`, `borderStyle` (`solid`), `borderWidth`                                          |
| `color:<role>` | `<role>Color`, used as `color:background` and `color:foreground`                                               |
| `dimensions`   | `width`, `height`                                                                                              |
| `minDimensions`| `minWidth`, `minHeight`                                                                                        |
| `padding`      | `paddingTop`, `paddingRight`, `paddingBottom`, `paddingLeft`                                                   |
| `inset`        | `insetTop`, `insetRight`, `insetBottom`, `insetLeft`                                                           |
| `gap`          | `gap`                                                                                                          |
| `font`         | `fontFamily`, `fontSize`, `fontWeight`, `fontLineHeight`, `fontLetterSpacing`, `fontTextDecoration`, `fontTextTransform`; `font:<part>` prefixes them |
| `floatingLabel`| `floatingLabelFontSize` (12px), `floatingLabelLineHeight` (12px)                                               |
| `shadow`       | `shadowOffsetX`, `shadowOffsetY`, `shadowBlur`, `shadowSpread`, `shadowColor` and the composed `shadow`         |
| `focusRing`    | `focusRingColor`, `focusRingInwardOffset` (2px), `focusRingOutwardOffset` (2px), `focusRingActiveWidth` (8px)  |
| `ripple`       | `rippleColor`, `rippleDuration` (200ms)                                                                        |
| `transition`   | `transitionDuration`, `transitionMode`, `transitionProperty`                                                   |
| `translate`    | `translate` (`none`)                                                                                           |
| `progressRing` | `progressRingWidth` (2px)                                                                                      |
| `prefix`, `suffix` | `prefixIconSize`, `suffixIconSize` (20px)                                                                  |
| `thumb`        | `thumbBackgroundColor`, `thumbBorderColor`, `thumbBorderRadius`                                                |
| `line`         | `lineThickness`                                                                                                |
| `stack`        | `stackTranslateStep`, `stackScaleStep`, `stackOpacityStep`, `stackRotationStep`, `stackGap`, `stackTransitionDuration`, `stackTransitionTimingFunction`, `stackIndent`, `stackExpandedScale` |

The frontmatter `components` block projects the core atoms into the DESIGN.md schema: the bare key
(`button`) is the token default with the theme's `:host` overrides applied, and related keys carry
the overrides for an appearance, a variant, a size or a state (`button-primary`,
`button-primary-hover`, `button-outline-primary`, `button-disabled`). Only `backgroundColor`,
`textColor`, `typography`, `rounded`, `padding`, `height` and `width` can be expressed there;
everything else is in [COMPONENTS.memphis.md](COMPONENTS.memphis.md).

### Runtime custom properties

<!-- design-md:runtime -->

A page with a `Theme2` / `provideTheme()` provider carries 593 custom properties in light mode: the 477 the compiled `memphis-style()` stylesheet declares on `:root`, overlaid by what `ThemeService` writes from the theme object (dark mode redeclares the mode-dependent ones).

| Family | Properties |
|---|---|
| `--memphis-color-*` | 297 |
| `--memphis-duration-*` | 3 |
| `--memphis-elevation-*` | 140 |
| `--memphis-font-*` | 1 |
| `--memphis-layout-*` | 4 |
| `--memphis-scheme-*` | 33 |
| `--memphis-typography-*` | 112 |
<!-- /design-md:runtime -->

`ThemeService` mirrors the scheme, color, font, typography, layout and elevation families as
`--mosaik-*` aliases; durations are aliased by the stylesheet itself. Memphis additionally declares
`--memphis-layout-transition`, which several component tokens use as their transition duration.

### Component index

Every component with a token file, its tag and the number of tokens it exports. The prefix of a
component's custom properties is its tag without `mosaik-` (`mosaik-textbox` declares `--textbox-*`). The
full tables, with a link to each component's reference documentation, are in [COMPONENTS.memphis.md](COMPONENTS.memphis.md).

<!-- design-md:component-index -->

| Token file | Tag | Tokens |
|---|---|---|
| [absolute](COMPONENTS.memphis.md#absolute) | `mosaik-absolute` | 22 |
| [absoluteItem](COMPONENTS.memphis.md#absolute-item) | `mosaik-absolute-item` | 22 |
| [accordion](COMPONENTS.memphis.md#accordion) | `mosaik-accordion` | 22 |
| [actionbar-group](COMPONENTS.memphis.md#actionbar-group) | `mosaik-actionbar-group` | 19 |
| [actionbar-item](COMPONENTS.memphis.md#actionbar-item) | `mosaik-actionbar-item` | 20 |
| [actionbar-separator](COMPONENTS.memphis.md#actionbar-separator) | `mosaik-actionbar-separator` | 18 |
| [actionbar](COMPONENTS.memphis.md#actionbar) | `mosaik-actionbar` | 23 |
| [alert](COMPONENTS.memphis.md#alert) | `mosaik-alert` | 22 |
| [anchor](COMPONENTS.memphis.md#anchor) | `mosaik-anchor` | 25 |
| [app](COMPONENTS.memphis.md#app) | `mosaik-app` | 36 |
| [appHeader](COMPONENTS.memphis.md#app-header) | `mosaik-app-header` | 31 |
| [audio](COMPONENTS.memphis.md#audio) | `mosaik-audio` | 36 |
| [autoCompleteBox](COMPONENTS.memphis.md#autocompletebox) | `mosaik-autocompletebox` | 33 |
| [avatar](COMPONENTS.memphis.md#avatar) | `mosaik-avatar` | 34 |
| [avatarGroup](COMPONENTS.memphis.md#avatar-group) | `mosaik-avatar-group` | 28 |
| [backTop](COMPONENTS.memphis.md#back-top) | `mosaik-back-top` | 22 |
| [backdrop](COMPONENTS.memphis.md#backdrop) | `mosaik-backdrop` | 24 |
| [badge](COMPONENTS.memphis.md#badge) | `mosaik-badge` | 34 |
| [banner](COMPONENTS.memphis.md#banner) | `mosaik-banner` | 34 |
| [bannerGroup](COMPONENTS.memphis.md#banner-group) | `mosaik-banner-group` | 31 |
| [bannerHeader](COMPONENTS.memphis.md#banner-header) | `mosaik-banner-header` | 25 |
| [bannerSubHeader](COMPONENTS.memphis.md#banner-sub-header) | `mosaik-banner-sub-header` | 25 |
| [box](COMPONENTS.memphis.md#box) | `mosaik-box` | 30 |
| [breadcrumb](COMPONENTS.memphis.md#breadcrumb) | `mosaik-breadcrumb` | 22 |
| [breadcrumbItem](COMPONENTS.memphis.md#breadcrumb-item) | `mosaik-breadcrumb-item` | 25 |
| [bubbles](COMPONENTS.memphis.md#bubbles) | `mosaik-bubbles` | 23 |
| [busyState](COMPONENTS.memphis.md#busy-state) | `mosaik-busy-state` | 30 |
| [button](COMPONENTS.memphis.md#button) | `mosaik-button` | 41 |
| [buttonGroup](COMPONENTS.memphis.md#button-group) | `mosaik-button-group` | 28 |
| [calendar](COMPONENTS.memphis.md#calendar) | `mosaik-calendar` | 29 |
| [calendarDaysView](COMPONENTS.memphis.md#calendar-days-view) | `mosaik-calendar-days-view` | 22 |
| [calendarHeader](COMPONENTS.memphis.md#calendar-header) | `mosaik-calendar-header` | 28 |
| [calendarItem](COMPONENTS.memphis.md#calendar-item) | `mosaik-calendar-item` | 41 |
| [calendarMonthsView](COMPONENTS.memphis.md#calendar-months-view) | `mosaik-calendar-months-view` | 22 |
| [calendarSubHeader](COMPONENTS.memphis.md#calendar-sub-header) | `mosaik-calendar-sub-header` | 30 |
| [calendarYearsView](COMPONENTS.memphis.md#calendar-years-view) | `mosaik-calendar-years-view` | 22 |
| [camera](COMPONENTS.memphis.md#camera) | `mosaik-camera` | 25 |
| [card](COMPONENTS.memphis.md#card) | `mosaik-card` | 29 |
| [cardActions](COMPONENTS.memphis.md#card-actions) | `mosaik-card-actions` | 22 |
| [cardContent](COMPONENTS.memphis.md#card-content) | `mosaik-card-content` | 22 |
| [cardFooter](COMPONENTS.memphis.md#card-footer) | `mosaik-card-footer` | 22 |
| [cardHeader](COMPONENTS.memphis.md#card-header) | `mosaik-card-header` | 22 |
| [cardStack](COMPONENTS.memphis.md#card-stack) | `mosaik-card-stack` | 21 |
| [cardSubTitle](COMPONENTS.memphis.md#card-sub-title) | `mosaik-card-sub-title` | 25 |
| [cardTitle](COMPONENTS.memphis.md#card-title) | `mosaik-card-title` | 25 |
| [carousel](COMPONENTS.memphis.md#carousel) | `mosaik-carousel` | 42 |
| [carouselItem](COMPONENTS.memphis.md#carousel-item) | `mosaik-carousel-item` | 22 |
| [cell](COMPONENTS.memphis.md#cell) | `mosaik-cell` | 30 |
| [cellGroup](COMPONENTS.memphis.md#cell-group) | `mosaik-cell-group` | 28 |
| [chart](COMPONENTS.memphis.md#chart) | `mosaik-chart` | 24 |
| [chartToolbox](COMPONENTS.memphis.md#chart-toolbox) | `mosaik-chart-toolbox` | 17 |
| [chat](COMPONENTS.memphis.md#chat) | `mosaik-chat` | 31 |
| [chatHeader](COMPONENTS.memphis.md#chat-header) | `mosaik-chat-header` | 23 |
| [chatMarker](COMPONENTS.memphis.md#chat-marker) | `mosaik-chat-marker` | 28 |
| [chatMessage](COMPONENTS.memphis.md#chat-message) | `mosaik-chat-message` | 29 |
| [chatMessageAvatar](COMPONENTS.memphis.md#chat-message-avatar) | `mosaik-chat-message-avatar` | 34 |
| [chatMessageDivider](COMPONENTS.memphis.md#chat-message-divider) | `mosaik-chat-message-divider` | 23 |
| [chatMessageReaction](COMPONENTS.memphis.md#chat-message-reaction) | `mosaik-chat-message-reaction` | 23 |
| [checkBox](COMPONENTS.memphis.md#checkbox) | `mosaik-checkbox` | 28 |
| [checkBoxGroup](COMPONENTS.memphis.md#checkbox-group) | `mosaik-checkbox-group` | 28 |
| [checkmark](COMPONENTS.memphis.md#checkmark) | `mosaik-checkmark` | 36 |
| [chip](COMPONENTS.memphis.md#chip) | `mosaik-chip` | 35 |
| [chipBox](COMPONENTS.memphis.md#chipbox) | `mosaik-chipbox` | 43 |
| [chipGroup](COMPONENTS.memphis.md#chip-group) | `mosaik-chip-group` | 28 |
| [choice](COMPONENTS.memphis.md#choice) | `mosaik-choice` | 32 |
| [choiceGroup](COMPONENTS.memphis.md#choice-group) | `mosaik-choice-group` | 28 |
| [choiceGroupHeader](COMPONENTS.memphis.md#choice-group-header) | `mosaik-choice-group-header` | 28 |
| [clickable](COMPONENTS.memphis.md#clickable) | `mosaik-clickable` | 27 |
| [code](COMPONENTS.memphis.md#code) | `mosaik-code` | 23 |
| [codeEditor](COMPONENTS.memphis.md#code-editor) | `mosaik-code-editor` | 78 |
| [colorArea](COMPONENTS.memphis.md#color-area) | `mosaik-color-area` | 22 |
| [colorBox](COMPONENTS.memphis.md#colorbox) | `mosaik-colorbox` | 41 |
| [colorEditor](COMPONENTS.memphis.md#color-editor) | `mosaik-color-editor` | 34 |
| [colorEditorAlphaSlider](COMPONENTS.memphis.md#color-editor-alpha-slider) | `mosaik-color-editor-alpha-slider` | 41 |
| [colorEditorArea](COMPONENTS.memphis.md#color-editor-area) | `mosaik-color-editor-area` | 39 |
| [colorEditorHueSlider](COMPONENTS.memphis.md#color-editor-hue-slider) | `mosaik-color-editor-hue-slider` | 40 |
| [colorEditorInputs](COMPONENTS.memphis.md#color-editor-inputs) | `mosaik-color-editor-inputs` | 37 |
| [colorEditorPalette](COMPONENTS.memphis.md#color-editor-palette) | `mosaik-color-editor-palette` | 36 |
| [colorEditorShadeSlider](COMPONENTS.memphis.md#color-editor-shade-slider) | `mosaik-color-editor-shade-slider` | 40 |
| [colorEditorSwatch](COMPONENTS.memphis.md#color-editor-swatch) | `mosaik-color-editor-swatch` | 31 |
| [colorPicker](COMPONENTS.memphis.md#color-picker) | `mosaik-color-picker` | 29 |
| [colorSlider](COMPONENTS.memphis.md#color-slider) | `mosaik-color-slider` | 28 |
| [colorSwatch](COMPONENTS.memphis.md#color-swatch) | `mosaik-color-swatch` | 29 |
| [colorSwatchGroup](COMPONENTS.memphis.md#color-swatch-group) | `mosaik-color-swatch-group` | 28 |
| [colorThumb](COMPONENTS.memphis.md#color-thumb) | `mosaik-color-thumb` | 29 |
| [combo](COMPONENTS.memphis.md#combo) | `mosaik-combo` | 36 |
| [comboItem](COMPONENTS.memphis.md#combo-item) | `mosaik-combo-item` | 34 |
| [comboItemGroup](COMPONENTS.memphis.md#combo-item-group) | `mosaik-combo-item-group` | 39 |
| [comboItemVisual](COMPONENTS.memphis.md#combo-item-visual) | `mosaik-combo-item-visual` | 22 |
| [comment](COMPONENTS.memphis.md#comment) | `mosaik-comment` | 25 |
| [compoundButton](COMPONENTS.memphis.md#compound-button) | `mosaik-compound-button` | 41 |
| [content](COMPONENTS.memphis.md#content) | `mosaik-content` | 22 |
| [cookiesConsent](COMPONENTS.memphis.md#cookie-consent) | `mosaik-cookie-consent` | 22 |
| [cursorEffect](COMPONENTS.memphis.md#cursor-effect) | `mosaik-cursor-effect` | 21 |
| [dataList](COMPONENTS.memphis.md#data-list) | `mosaik-data-list` | 22 |
| [dataTable](COMPONENTS.memphis.md#data-table) | `mosaik-data-table` | 24 |
| [dateBox](COMPONENTS.memphis.md#datebox) | `mosaik-datebox` | 41 |
| [dateTimeBox](COMPONENTS.memphis.md#datetimebox) | `mosaik-datetimebox` | 44 |
| [designer](COMPONENTS.memphis.md#designer) | `mosaik-designer` | 16 |
| [designerCanvas](COMPONENTS.memphis.md#designer-canvas) | `mosaik-designer-canvas` | 20 |
| [designerConnector](COMPONENTS.memphis.md#designer-connector) | `mosaik-designer-connector` | 27 |
| [designerContent](COMPONENTS.memphis.md#designer-content) | `mosaik-designer-content` | 16 |
| [designerFrame](COMPONENTS.memphis.md#designer-frame) | `mosaik-designer-frame` | 34 |
| [dialog](COMPONENTS.memphis.md#dialog) | `mosaik-dialog` | 29 |
| [dialogActions](COMPONENTS.memphis.md#dialog-actions) | `mosaik-dialog-actions` | 22 |
| [dialogContent](COMPONENTS.memphis.md#dialog-content) | `mosaik-dialog-content` | 22 |
| [dialogFooter](COMPONENTS.memphis.md#dialog-footer) | `mosaik-dialog-footer` | 22 |
| [dialogHeader](COMPONENTS.memphis.md#dialog-header) | `mosaik-dialog-header` | 22 |
| [dialogHeaderSubText](COMPONENTS.memphis.md#dialog-header-sub-text) | `mosaik-dialog-header-sub-text` | 25 |
| [dialogHeaderText](COMPONENTS.memphis.md#dialog-header-text) | `mosaik-dialog-header-text` | 25 |
| [disclosure](COMPONENTS.memphis.md#disclosure) | `mosaik-disclosure` | 32 |
| [dismiss](COMPONENTS.memphis.md#dismiss) | `mosaik-dismiss` | 22 |
| [divider](COMPONENTS.memphis.md#divider) | `mosaik-divider` | 29 |
| [dockPanel](COMPONENTS.memphis.md#dock-panel) | `mosaik-dock-panel` | 22 |
| [dot](COMPONENTS.memphis.md#dot) | `mosaik-dot` | 29 |
| [dotGroup](COMPONENTS.memphis.md#dot-group) | `mosaik-dot-group` | 28 |
| [drawer](COMPONENTS.memphis.md#drawer) | `mosaik-drawer` | 33 |
| [drawerActions](COMPONENTS.memphis.md#drawer-actions) | `mosaik-drawer-actions` | 22 |
| [drawerContainer](COMPONENTS.memphis.md#drawer-container) | `mosaik-drawer-container` | 23 |
| [drawerContent](COMPONENTS.memphis.md#drawer-content) | `mosaik-drawer-content` | 26 |
| [drawerFooter](COMPONENTS.memphis.md#drawer-footer) | `mosaik-drawer-footer` | 22 |
| [drawerHeader](COMPONENTS.memphis.md#drawer-header) | `mosaik-drawer-header` | 22 |
| [drawerHeaderSubText](COMPONENTS.memphis.md#drawer-header-sub-text) | `mosaik-drawer-header-sub-text` | 25 |
| [drawerHeaderText](COMPONENTS.memphis.md#drawer-header-text) | `mosaik-drawer-header-text` | 25 |
| [drawerRail](COMPONENTS.memphis.md#drawer-rail) | `mosaik-drawer-rail` | 25 |
| [dropDownButton](COMPONENTS.memphis.md#dropdown-button) | `mosaik-dropdown-button` | 44 |
| [dropZone](COMPONENTS.memphis.md#drop-zone) | `mosaik-drop-zone` | 27 |
| [dropdown](COMPONENTS.memphis.md#dropdown) | `mosaik-dropdown` | 42 |
| [durationBox](COMPONENTS.memphis.md#durationbox) | `mosaik-durationbox` | 41 |
| [elevation](COMPONENTS.memphis.md#elevation) | `mosaik-elevation` | 22 |
| [emoji](COMPONENTS.memphis.md#emoji) | `mosaik-emoji` | 23 |
| [emptyState](COMPONENTS.memphis.md#empty-state) | `mosaik-empty-state` | 30 |
| [epg](COMPONENTS.memphis.md#epg) | `mosaik-epg` | 28 |
| [epgChannel](COMPONENTS.memphis.md#epg-channel) | `mosaik-epg-channel` | 28 |
| [epgMinimap](COMPONENTS.memphis.md#epg-minimap) | `mosaik-epg-minimap` | 28 |
| [epgNowLine](COMPONENTS.memphis.md#epg-now-line) | `mosaik-epg-now-line` | 26 |
| [epgProgram](COMPONENTS.memphis.md#epg-program) | `mosaik-epg-program` | 28 |
| [epgTimeline](COMPONENTS.memphis.md#epg-timeline) | `mosaik-epg-timeline` | 28 |
| [error](COMPONENTS.memphis.md#error) | `mosaik-error` | 28 |
| [errorState](COMPONENTS.memphis.md#error-state) | `mosaik-error-state` | 30 |
| [expandable](COMPONENTS.memphis.md#expandable) | `mosaik-expandable` | 22 |
| [expander](COMPONENTS.memphis.md#expander) | `mosaik-expander` | 31 |
| [expanderGroup](COMPONENTS.memphis.md#expander-group) | `mosaik-expander-group` | 28 |
| [expanderHeader](COMPONENTS.memphis.md#expander-header) | `mosaik-expander-header` | 25 |
| [expanderSubHeader](COMPONENTS.memphis.md#expander-sub-header) | `mosaik-expander-sub-header` | 25 |
| [fileBox](COMPONENTS.memphis.md#filebox) | `mosaik-filebox` | 41 |
| [filePicker](COMPONENTS.memphis.md#file-picker) | `mosaik-file-picker` | 28 |
| [fileUpload](COMPONENTS.memphis.md#file-upload) | `mosaik-file-upload` | 37 |
| [fileUploadItem](COMPONENTS.memphis.md#file-upload-item) | `mosaik-file-upload-item` | 28 |
| [flip](COMPONENTS.memphis.md#flip) | `mosaik-flip` | 22 |
| [floating](COMPONENTS.memphis.md#floating) | `mosaik-floating` | 31 |
| [floatingActionButton](COMPONENTS.memphis.md#fab) | `mosaik-fab` | 39 |
| [floatingActionButtonGroup](COMPONENTS.memphis.md#fab-group) | `mosaik-fab-group` | 22 |
| [floatingTrigger](COMPONENTS.memphis.md#floating-trigger) | `mosaik-floating-trigger` | 22 |
| [flow](COMPONENTS.memphis.md#flow) | `mosaik-flow` | 33 |
| [flowBoard](COMPONENTS.memphis.md#flow-board) | `mosaik-flow-board` | 24 |
| [flowBoardColumn](COMPONENTS.memphis.md#flow-board-column) | `mosaik-flow-board-column` | 48 |
| [flowBoardColumnComposer](COMPONENTS.memphis.md#flow-board-column-composer) | `mosaik-flow-board-column-composer` | 30 |
| [flowBoardColumnItem](COMPONENTS.memphis.md#flow-board-column-item) | `mosaik-flow-board-column-item` | 37 |
| [flowBoardColumnItemComposer](COMPONENTS.memphis.md#flow-board-column-item-composer) | `mosaik-flow-board-column-item-composer` | 30 |
| [flowBoardColumnItemGroup](COMPONENTS.memphis.md#flow-board-column-item-group) | `mosaik-flow-board-column-item-group` | 30 |
| [flowControls](COMPONENTS.memphis.md#flow-controls) | `mosaik-flow-controls` | 37 |
| [flowEdge](COMPONENTS.memphis.md#flow-edge) | `mosaik-flow-edge` | 39 |
| [flowMinimap](COMPONENTS.memphis.md#flow-minimap) | `mosaik-flow-minimap` | 42 |
| [flowNode](COMPONENTS.memphis.md#flow-node) | `mosaik-flow-node` | 47 |
| [focusRing](COMPONENTS.memphis.md#focus-ring) | `mosaik-focus-ring` | 35 |
| [fontEditor](COMPONENTS.memphis.md#font-editor) | `mosaik-font-editor` | 56 |
| [footer](COMPONENTS.memphis.md#footer) | `mosaik-footer` | 29 |
| [footerItem](COMPONENTS.memphis.md#footer-item) | `mosaik-footer-item` | 22 |
| [footerItemGroup](COMPONENTS.memphis.md#footer-item-group) | `mosaik-footer-item-group` | 22 |
| [form](COMPONENTS.memphis.md#form) | `mosaik-form` | 24 |
| [formField](COMPONENTS.memphis.md#form-field) | `mosaik-form-field` | 23 |
| [gauge](COMPONENTS.memphis.md#gauge) | `mosaik-gauge` | 28 |
| [gaugeArc](COMPONENTS.memphis.md#gauge-arc) | `mosaik-gauge-arc` | 25 |
| [gaugeControl](COMPONENTS.memphis.md#gauge-control) | `mosaik-gauge-control` | 28 |
| [gaugeDot](COMPONENTS.memphis.md#gauge-dot) | `mosaik-gauge-dot` | 27 |
| [gaugeHub](COMPONENTS.memphis.md#gauge-hub) | `mosaik-gauge-hub` | 25 |
| [gaugeInset](COMPONENTS.memphis.md#gauge-inset) | `mosaik-gauge-inset` | 22 |
| [gaugeMarks](COMPONENTS.memphis.md#gauge-marks) | `mosaik-gauge-marks` | 26 |
| [gaugeNeedle](COMPONENTS.memphis.md#gauge-needle) | `mosaik-gauge-needle` | 25 |
| [gaugeStack](COMPONENTS.memphis.md#gauge-stack) | `mosaik-gauge-stack` | 25 |
| [gaugeText](COMPONENTS.memphis.md#gauge-text) | `mosaik-gauge-text` | 26 |
| [gaugeTickLabels](COMPONENTS.memphis.md#gauge-tick-labels) | `mosaik-gauge-tick-labels` | 26 |
| [gaugeTicks](COMPONENTS.memphis.md#gauge-ticks) | `mosaik-gauge-ticks` | 26 |
| [gaugeTooltip](COMPONENTS.memphis.md#gauge-tooltip) | `mosaik-gauge-tooltip` | 29 |
| [gaugeTrack](COMPONENTS.memphis.md#gauge-track) | `mosaik-gauge-track` | 25 |
| [gaugeValue](COMPONENTS.memphis.md#gauge-value) | `mosaik-gauge-value` | 26 |
| [gaugeZones](COMPONENTS.memphis.md#gauge-zones) | `mosaik-gauge-zones` | 25 |
| [ghost](COMPONENTS.memphis.md#ghost) | `mosaik-ghost` | 27 |
| [globe](COMPONENTS.memphis.md#globe) | `mosaik-globe` | 24 |
| [grid](COMPONENTS.memphis.md#grid) | `mosaik-grid` | 22 |
| [gridItem](COMPONENTS.memphis.md#grid-item) | `mosaik-grid-item` | 22 |
| [helmet](COMPONENTS.memphis.md#helmet) | `mosaik-helmet` | 22 |
| [hint](COMPONENTS.memphis.md#hint) | `mosaik-hint` | 28 |
| [icon](COMPONENTS.memphis.md#icon) | `mosaik-icon` | 29 |
| [image](COMPONENTS.memphis.md#image) | `mosaik-image` | 39 |
| [indicator](COMPONENTS.memphis.md#indicator) | `mosaik-indicator` | 28 |
| [inkBar](COMPONENTS.memphis.md#ink-bar) | `mosaik-ink-bar` | 27 |
| [jumbotron](COMPONENTS.memphis.md#jumbotron) | `mosaik-jumbotron` | 28 |
| [jumbotronHeader](COMPONENTS.memphis.md#jumbotron-header) | `mosaik-jumbotron-header` | 25 |
| [jumbotronSubHeader](COMPONENTS.memphis.md#jumbotron-sub-header) | `mosaik-jumbotron-sub-header` | 25 |
| [kbd](COMPONENTS.memphis.md#kbd) | `mosaik-kbd` | 28 |
| [kbdShortcut](COMPONENTS.memphis.md#kbd-shortcut) | `mosaik-kbd-shortcut` | 22 |
| [knob](COMPONENTS.memphis.md#knob) | `mosaik-knob` | 41 |
| [lightChain](COMPONENTS.memphis.md#light-chain) | `mosaik-light-chain` | 22 |
| [list](COMPONENTS.memphis.md#list) | `mosaik-list` | 29 |
| [listItem](COMPONENTS.memphis.md#list-item) | `mosaik-list-item` | 34 |
| [listItemGroup](COMPONENTS.memphis.md#list-item-group) | `mosaik-list-item-group` | 39 |
| [listing](COMPONENTS.memphis.md#listing) | `mosaik-listing` | 24 |
| [listingItem](COMPONENTS.memphis.md#listing-item) | `mosaik-listing-item` | 24 |
| [listingItemMarker](COMPONENTS.memphis.md#listing-item-marker) | `mosaik-listing-item-marker` | 29 |
| [map](COMPONENTS.memphis.md#map) | `mosaik-map` | 22 |
| [marquee](COMPONENTS.memphis.md#marquee) | `mosaik-marquee` | 25 |
| [masonry](COMPONENTS.memphis.md#masonry) | `mosaik-masonry` | 23 |
| [mention](COMPONENTS.memphis.md#mention) | `mosaik-mention` | 32 |
| [menu](COMPONENTS.memphis.md#menu) | `mosaik-menu` | 28 |
| [menuItem](COMPONENTS.memphis.md#menu-item) | `mosaik-menu-item` | 38 |
| [menuItemGroup](COMPONENTS.memphis.md#menu-item-group) | `mosaik-menu-item-group` | 39 |
| [message](COMPONENTS.memphis.md#message) | `mosaik-message` | 28 |
| [messageBox](COMPONENTS.memphis.md#message-box) | `mosaik-message-box` | 45 |
| [meterBar](COMPONENTS.memphis.md#meter-bar) | `mosaik-meter-bar` | 27 |
| [meterRing](COMPONENTS.memphis.md#meter-ring) | `mosaik-meter-ring` | 36 |
| [number](COMPONENTS.memphis.md#number) | `mosaik-number` | 25 |
| [numberBox](COMPONENTS.memphis.md#numberbox) | `mosaik-numberbox` | 41 |
| [numberCounter](COMPONENTS.memphis.md#number-counter) | `mosaik-number-counter` | 30 |
| [numberTicker](COMPONENTS.memphis.md#number-ticker) | `mosaik-number-ticker` | 16 |
| [orbit](COMPONENTS.memphis.md#orbit) | `mosaik-orbit` | 19 |
| [page](COMPONENTS.memphis.md#page) | `mosaik-page` | 22 |
| [pageContent](COMPONENTS.memphis.md#page-content) | `mosaik-page-content` | 26 |
| [pageHeader](COMPONENTS.memphis.md#page-header) | `mosaik-page-header` | 48 |
| [pageMenu](COMPONENTS.memphis.md#page-menu) | `mosaik-page-menu` | 30 |
| [pagePreContent](COMPONENTS.memphis.md#page-pre-content) | `mosaik-page-pre-content` | 23 |
| [pagePreHeader](COMPONENTS.memphis.md#page-pre-header) | `mosaik-page-pre-header` | 23 |
| [paginator](COMPONENTS.memphis.md#paginator) | `mosaik-paginator` | 23 |
| [parallax](COMPONENTS.memphis.md#parallax) | `mosaik-parallax` | 16 |
| [passwordBox](COMPONENTS.memphis.md#passwordbox) | `mosaik-passwordbox` | 41 |
| [pattern](COMPONENTS.memphis.md#pattern) | `mosaik-pattern` | 23 |
| [persona](COMPONENTS.memphis.md#persona) | `mosaik-persona` | 29 |
| [perspective](COMPONENTS.memphis.md#perspective) | `mosaik-perspective` | 22 |
| [pinBox](COMPONENTS.memphis.md#pinbox) | `mosaik-pinbox` | 34 |
| [pip](COMPONENTS.memphis.md#pip) | `mosaik-pip` | 34 |
| [placeholder](COMPONENTS.memphis.md#placeholder) | `mosaik-placeholder` | 27 |
| [popup](COMPONENTS.memphis.md#popup) | `mosaik-popup` | 28 |
| [portal](COMPONENTS.memphis.md#portal) | `mosaik-portal` | 22 |
| [portalHost](COMPONENTS.memphis.md#portal-host) | `mosaik-portal-host` | 22 |
| [portalProjection](COMPONENTS.memphis.md#portal-projection) | `mosaik-portal-projection` | 22 |
| [pressButton](COMPONENTS.memphis.md#press-button) | `mosaik-press-button` | 44 |
| [progressBar](COMPONENTS.memphis.md#progress-bar) | `mosaik-progress-bar` | 23 |
| [progressRing](COMPONENTS.memphis.md#progress-ring) | `mosaik-progress-ring` | 31 |
| [promptBox](COMPONENTS.memphis.md#prompt-box) | `mosaik-prompt-box` | 40 |
| [promptBoxAttachmentList](COMPONENTS.memphis.md#prompt-box-attachment-list) | `mosaik-prompt-box-attachment-list` | 29 |
| [promptBoxQueue](COMPONENTS.memphis.md#prompt-box-queue) | `mosaik-prompt-box-queue` | 29 |
| [promptBoxVoiceRecorderTool](COMPONENTS.memphis.md#prompt-box-voice-recorder-tool) | `mosaik-prompt-box-voice-recorder-tool` | 22 |
| [pulse](COMPONENTS.memphis.md#pulse) | `mosaik-pulse` | 18 |
| [qrCode](COMPONENTS.memphis.md#qrcode) | `mosaik-qrcode` | 24 |
| [radio](COMPONENTS.memphis.md#radio) | `mosaik-radio` | 28 |
| [radioGroup](COMPONENTS.memphis.md#radio-group) | `mosaik-radio-group` | 28 |
| [rating](COMPONENTS.memphis.md#rating) | `mosaik-rating` | 28 |
| [region](COMPONENTS.memphis.md#region) | `mosaik-region` | 22 |
| [regionView](COMPONENTS.memphis.md#region-view) | `mosaik-region-view` | 22 |
| [repeatButton](COMPONENTS.memphis.md#repeat-button) | `mosaik-repeat-button` | 43 |
| [resize](COMPONENTS.memphis.md#resize) | `mosaik-resize` | 22 |
| [resizeAdorner](COMPONENTS.memphis.md#resize-adorner) | `mosaik-resize-adorner` | 28 |
| [resizeThumb](COMPONENTS.memphis.md#resize-thumb) | `mosaik-resize-thumb` | 28 |
| [reveal](COMPONENTS.memphis.md#reveal) | `mosaik-reveal` | 20 |
| [ribbon](COMPONENTS.memphis.md#ribbon) | `mosaik-ribbon` | 30 |
| [richTextBox](COMPONENTS.memphis.md#richtextbox) | `mosaik-richtextbox` | 71 |
| [richTextBoxToolbox](COMPONENTS.memphis.md#richtextbox-toolbox) | `mosaik-richtextbox-toolbox` | 35 |
| [ripple](COMPONENTS.memphis.md#ripple) | `mosaik-ripple` | 23 |
| [router](COMPONENTS.memphis.md#router) | `mosaik-router` | 22 |
| [routerAnchor](COMPONENTS.memphis.md#router-anchor) | `mosaik-router-anchor` | 25 |
| [routerLink](COMPONENTS.memphis.md#router-link) | `mosaik-router-link` | 22 |
| [routerOutlet](COMPONENTS.memphis.md#router-outlet) | `mosaik-router-outlet` | 22 |
| [scale](COMPONENTS.memphis.md#scale) | `mosaik-scale` | 22 |
| [scheduler](COMPONENTS.memphis.md#scheduler) | `mosaik-scheduler` | 73 |
| [schedulerAgendaView](COMPONENTS.memphis.md#scheduler-agenda-view) | `mosaik-scheduler-agenda-view` | 40 |
| [schedulerDatescale](COMPONENTS.memphis.md#scheduler-datescale) | `mosaik-scheduler-datescale` | 41 |
| [schedulerEvent](COMPONENTS.memphis.md#scheduler-event) | `mosaik-scheduler-event` | 54 |
| [schedulerMonthView](COMPONENTS.memphis.md#scheduler-month-view) | `mosaik-scheduler-month-view` | 58 |
| [schedulerNowIndicator](COMPONENTS.memphis.md#scheduler-now-indicator) | `mosaik-scheduler-now-indicator` | 25 |
| [schedulerTimeGridView](COMPONENTS.memphis.md#scheduler-time-grid-view) | `mosaik-scheduler-time-grid-view` | 67 |
| [schedulerTimelineView](COMPONENTS.memphis.md#scheduler-timeline-view) | `mosaik-scheduler-timeline-view` | 66 |
| [schedulerTimescale](COMPONENTS.memphis.md#scheduler-timescale) | `mosaik-scheduler-timescale` | 34 |
| [scroll](COMPONENTS.memphis.md#scroll) | `mosaik-scroll` | 24 |
| [scrubSlider](COMPONENTS.memphis.md#scrub-slider) | `mosaik-scrub-slider` | 69 |
| [searchBox](COMPONENTS.memphis.md#searchbox) | `mosaik-searchbox` | 35 |
| [segment](COMPONENTS.memphis.md#segment) | `mosaik-segment` | 36 |
| [segmentBar](COMPONENTS.memphis.md#segment-bar) | `mosaik-segment-bar` | 25 |
| [segmentItem](COMPONENTS.memphis.md#segment-item) | `mosaik-segment-item` | 34 |
| [segmentLegend](COMPONENTS.memphis.md#segment-legend) | `mosaik-segment-legend` | 16 |
| [segmentLegendItem](COMPONENTS.memphis.md#segment-legend-item) | `mosaik-segment-legend-item` | 19 |
| [segmentRing](COMPONENTS.memphis.md#segment-ring) | `mosaik-segment-ring` | 25 |
| [select](COMPONENTS.memphis.md#select) | `mosaik-select` | 36 |
| [selectItem](COMPONENTS.memphis.md#select-item) | `mosaik-select-item` | 34 |
| [selectItemGroup](COMPONENTS.memphis.md#select-item-group) | `mosaik-select-item-group` | 39 |
| [selectItemVisual](COMPONENTS.memphis.md#select-item-visual) | `mosaik-select-item-visual` | 22 |
| [sheet](COMPONENTS.memphis.md#sheet) | `mosaik-sheet` | 41 |
| [sheetContent](COMPONENTS.memphis.md#sheet-content) | `mosaik-sheet-content` | 22 |
| [sheetFooter](COMPONENTS.memphis.md#sheet-footer) | `mosaik-sheet-footer` | 22 |
| [sheetHeader](COMPONENTS.memphis.md#sheet-header) | `mosaik-sheet-header` | 22 |
| [sheetHeaderSubText](COMPONENTS.memphis.md#sheet-header-sub-text) | `mosaik-sheet-header-sub-text` | 25 |
| [sheetHeaderText](COMPONENTS.memphis.md#sheet-header-text) | `mosaik-sheet-header-text` | 25 |
| [signaturePad](COMPONENTS.memphis.md#signaturepad) | `mosaik-signaturepad` | 33 |
| [skeleton](COMPONENTS.memphis.md#skeleton) | `mosaik-skeleton` | 29 |
| [slider](COMPONENTS.memphis.md#slider) | `mosaik-slider` | 65 |
| [slider2](COMPONENTS.memphis.md#slider2) | `mosaik-slider2` | 22 |
| [slider2Thumb](COMPONENTS.memphis.md#slider2-thumb) | `mosaik-slider2-thumb` | 23 |
| [spacer](COMPONENTS.memphis.md#spacer) | `mosaik-spacer` | 22 |
| [spline](COMPONENTS.memphis.md#spline) | `mosaik-spline` | 20 |
| [split](COMPONENTS.memphis.md#split) | `mosaik-split` | 30 |
| [splitButton](COMPONENTS.memphis.md#split-button) | `mosaik-split-button` | 43 |
| [stack](COMPONENTS.memphis.md#stack) | `mosaik-stack` | 22 |
| [stepper](COMPONENTS.memphis.md#stepper) | `mosaik-stepper` | 40 |
| [stepperItem](COMPONENTS.memphis.md#stepper-item) | `mosaik-stepper-item` | 25 |
| [sticky](COMPONENTS.memphis.md#sticky) | `mosaik-sticky` | 24 |
| [successState](COMPONENTS.memphis.md#success-state) | `mosaik-success-state` | 30 |
| [suggestionMenu](COMPONENTS.memphis.md#suggestion-menu) | `mosaik-suggestion-menu` | 25 |
| [summary](COMPONENTS.memphis.md#summary) | `mosaik-summary` | 22 |
| [swipe](COMPONENTS.memphis.md#swipe) | `mosaik-swipe` | 22 |
| [tab](COMPONENTS.memphis.md#tab) | `mosaik-tab` | 36 |
| [tabItem](COMPONENTS.memphis.md#tab-item) | `mosaik-tab-item` | 25 |
| [tabPanel](COMPONENTS.memphis.md#tab-panel) | `mosaik-tab-panel` | 23 |
| [tabStrip](COMPONENTS.memphis.md#tab-strip) | `mosaik-tab-strip` | 28 |
| [tabStripItem](COMPONENTS.memphis.md#tab-strip-item) | `mosaik-tab-strip-item` | 36 |
| [table](COMPONENTS.memphis.md#table) | `mosaik-table` | 38 |
| [tableBody](COMPONENTS.memphis.md#table-body) | `mosaik-table-body` | 28 |
| [tableBodyCell](COMPONENTS.memphis.md#table-body-cell) | `mosaik-table-body-cell` | 29 |
| [tableBodyRow](COMPONENTS.memphis.md#table-body-row) | `mosaik-table-body-row` | 27 |
| [tableColumnEditor](COMPONENTS.memphis.md#table-column-editor) | `mosaik-table-column-editor` | 26 |
| [tableFooter](COMPONENTS.memphis.md#table-footer) | `mosaik-table-footer` | 28 |
| [tableFooterCell](COMPONENTS.memphis.md#table-footer-cell) | `mosaik-table-footer-cell` | 28 |
| [tableFooterRow](COMPONENTS.memphis.md#table-footer-row) | `mosaik-table-footer-row` | 28 |
| [tableHeader](COMPONENTS.memphis.md#table-header) | `mosaik-table-header` | 28 |
| [tableHeaderCell](COMPONENTS.memphis.md#table-header-cell) | `mosaik-table-header-cell` | 32 |
| [tableHeaderRow](COMPONENTS.memphis.md#table-header-row) | `mosaik-table-header-row` | 28 |
| [text](COMPONENTS.memphis.md#text) | `mosaik-text` | 34 |
| [textBox](COMPONENTS.memphis.md#textbox) | `mosaik-textbox` | 67 |
| [textEffect](COMPONENTS.memphis.md#text-effect) | `mosaik-text-effect` | 19 |
| [textFormat](COMPONENTS.memphis.md#text-format) | `mosaik-text-format` | 22 |
| [thumb](COMPONENTS.memphis.md#thumb) | `mosaik-thumb` | 27 |
| [thumbnail](COMPONENTS.memphis.md#thumbnail) | `mosaik-thumbnail` | 23 |
| [tickBar](COMPONENTS.memphis.md#tick-bar) | `mosaik-tick-bar` | 32 |
| [tile](COMPONENTS.memphis.md#tile) | `mosaik-tile` | 34 |
| [tileList](COMPONENTS.memphis.md#tile-list) | `mosaik-tile-list` | 23 |
| [tileListItem](COMPONENTS.memphis.md#tile-list-item) | `mosaik-tile-list-item` | 29 |
| [tileManager](COMPONENTS.memphis.md#tile-manager) | `mosaik-tile-manager` | 23 |
| [tileManagerTile](COMPONENTS.memphis.md#tile-manager-tile) | `mosaik-tile-manager-tile` | 52 |
| [timeBox](COMPONENTS.memphis.md#timebox) | `mosaik-timebox` | 43 |
| [timeline](COMPONENTS.memphis.md#timeline) | `mosaik-timeline` | 31 |
| [timelineContent](COMPONENTS.memphis.md#timeline-content) | `mosaik-timeline-content` | 23 |
| [timelineItem](COMPONENTS.memphis.md#timeline-item) | `mosaik-timeline-item` | 30 |
| [timelineMarker](COMPONENTS.memphis.md#timeline-marker) | `mosaik-timeline-marker` | 27 |
| [timelineOpposite](COMPONENTS.memphis.md#timeline-opposite) | `mosaik-timeline-opposite` | 23 |
| [timelineSeparator](COMPONENTS.memphis.md#timeline-separator) | `mosaik-timeline-separator` | 25 |
| [titleBar](COMPONENTS.memphis.md#title-bar) | `mosaik-title-bar` | 22 |
| [titleLayout](COMPONENTS.memphis.md#title-layout) | `mosaik-title-layout` | 23 |
| [toast](COMPONENTS.memphis.md#toast) | `mosaik-toast` | 42 |
| [toastActions](COMPONENTS.memphis.md#toast-actions) | `mosaik-toast-actions` | 22 |
| [toggleButton](COMPONENTS.memphis.md#toggle-button) | `mosaik-toggle-button` | 42 |
| [toggleButtonGroup](COMPONENTS.memphis.md#toggle-button-group) | `mosaik-toggle-button-group` | 28 |
| [toggleSwitch](COMPONENTS.memphis.md#toggle-switch) | `mosaik-toggle-switch` | 28 |
| [toggletip](COMPONENTS.memphis.md#toggletip) | `mosaik-toggletip` | 24 |
| [toolbar](COMPONENTS.memphis.md#toolbar) | `mosaik-toolbar` | 30 |
| [tooltip](COMPONENTS.memphis.md#tooltip) | `mosaik-tooltip` | 29 |
| [tour](COMPONENTS.memphis.md#tour) | `mosaik-tour` | 30 |
| [tourAnchor](COMPONENTS.memphis.md#tour-anchor) | `mosaik-tour-anchor` | 24 |
| [tourNav](COMPONENTS.memphis.md#tour-nav) | `mosaik-tour-nav` | 31 |
| [tourStep](COMPONENTS.memphis.md#tour-step) | `mosaik-tour-step` | 34 |
| [tree](COMPONENTS.memphis.md#tree) | `mosaik-tree` | 22 |
| [treeItem](COMPONENTS.memphis.md#tree-item) | `mosaik-tree-item` | 31 |
| [upDownSpinner](COMPONENTS.memphis.md#updown-spinner) | `mosaik-updown-spinner` | 22 |
| [video](COMPONENTS.memphis.md#video) | `mosaik-video` | 36 |
| [virtualize](COMPONENTS.memphis.md#virtualize) | `mosaik-virtualize` | 22 |
| [walletCard](COMPONENTS.memphis.md#wallet-card) | `mosaik-wallet-card` | 53 |
| [wheelPicker](COMPONENTS.memphis.md#wheel-picker) | `mosaik-wheel-picker` | 29 |
| [wizard](COMPONENTS.memphis.md#wizard) | `mosaik-wizard` | 23 |
| [wizardStep](COMPONENTS.memphis.md#wizard-step) | `mosaik-wizard-step` | 22 |
| [wrap](COMPONENTS.memphis.md#wrap) | `mosaik-wrap` | 22 |
<!-- /design-md:component-index -->

## Do's and Don'ts

### Do

- Consume `--mosaik-*` custom properties for anything you paint yourself; never copy a literal.
- Change a value in `libs/mosaik-themes/tokens/`, not in a component stylesheet, and add a new
  token to all three themes at once.
- Draw boundaries with the ink outline and give blocks a hard shadow; a taller offset is a higher
  layer.
- Put ink text on pastels (`get-pastel()` + `get-ink()`), in both modes.
- Let faces move: halfway on hover, fully on press; keep the host still.
- Load Space Grotesk on every page that renders Memphis.

### Don't

- Don't blur shadows or use `rgba` tints for depth; Memphis depth is an opaque block.
- Don't use hairline (1px) borders, and don't square the corners off; both break the theme's block.
- Don't put cream (dark-mode `foreground`) text on a pastel.
- Don't move a host element on hover or press.
- Don't pass numbers to `size` or `elevation`.
- Don't hard-code a color, spacing, radius, border or shadow.

### Named anti-patterns

- **Soft Memphis**: blurred shadows and hairlines with Memphis colors. If the shadow is blurred it is
  not Memphis.
- **Floating hosts**: moving the whole element (and its hit box) on hover; the edge flickers under
  the pointer. Move the face.
- **Neon overload**: saturated `500` fills everywhere. Memphis colour is pastel plus ink; keep the
  saturated stops for shadows, rings and accents.

## Known gaps

Generated from the same sources as the tables above; a finding here is a finding about the theme,
not about this document. Memphis is complete in its global token set and in its component
anatomy: every component has its own hover, press, focus, selected and disabled behaviour in the
neo-brutalist language. The lists below are what remains at the token level.

<!-- design-md:gaps -->

### Theme references that resolve to nothing (0)

Component tokens pointing at theme properties that neither the compiled stylesheet nor `ThemeService` declares. The property is empty at runtime and the browser falls back to its initial value.

_none_

### References into other components (3)

These resolve only when the referenced component provides the property at runtime (a list item inside a list, a thumb inside a slider). Outside that context they are empty.

`--avatar-font-size` (1), `--data-table-cell-height` (1), `--pulse-ring-color` (1)

### Stylesheet properties the reference theme declares and this one does not (0 families)

Compared between the compiled `<theme>-style()` stylesheets; Joy is the reference theme, and Joy itself is compared against the names Memphis and Cosmopolitan agree on. With a `Theme2` / `provideTheme()` provider `ThemeService` writes these names from the theme object anyway; a page that loads only the stylesheet has them empty.

_none_

### Token files without a consuming component

`tokens/themes/memphis/components/accordion.json`, `tokens/themes/memphis/components/alert.json`, `tokens/themes/memphis/components/cardStack.json`, `tokens/themes/memphis/components/dotGroup.json`, `tokens/themes/memphis/components/gaugeInset.json`, `tokens/themes/memphis/components/numberTicker.json`, `tokens/themes/memphis/components/orbit.json`, `tokens/themes/memphis/components/pulse.json`, `tokens/themes/memphis/components/router.json`, `tokens/themes/memphis/components/routerAnchor.json`, `tokens/themes/memphis/components/routerLink.json`, `tokens/themes/memphis/components/routerOutlet.json`, `tokens/themes/memphis/components/slider2Thumb.json`, `tokens/themes/memphis/components/textEffect.json` define tokens no foundation component reads through its theme stylesheet.

### Token files consumed by more than one component

`tokens/themes/memphis/components/text.json` is read by 2 components; the export uses the `mosaik-text` prefix.

### Token files that feed the same custom property prefix

_none_

### Enum tokens missing from the theme file

_none_
<!-- /design-md:gaps -->

## Sources

| What                       | Where                                                                                             |
| -------------------------- | ------------------------------------------------------------------------------------------------- |
| Global tokens              | `libs/mosaik-themes/tokens/themes/memphis/memphis.json`, `tokens/themes/tokens.json`              |
| Component tokens           | `libs/mosaik-themes/tokens/themes/memphis/components/*.json`, mixins in `tokens/mixins/`         |
| Component anatomy          | `libs/mosaik-elements-foundation/src/controls/components/**/themes/*.Memphis.scss`               |
| Compiled tokens            | `libs/mosaik-themes/dist/themes/___memphis-tokens.css`, `dist/themes/memphis.scss`               |
| Runtime aliases            | `libs/mosaik-elements-foundation/src/theming/ThemeService.ts`                                     |
| Token model                | `.docs/design/tokens.md`, `.docs/design/tokens/1.token-schema-reference.md`                       |
| Component reference        | `apps/frontend/mosaik-showcase/public/llms/mosaik-<tag>.md`                                       |
| Regenerate                 | `yarn nx run mosaik-themes:build && yarn nx run mosaik-themes:design-md`                          |
| Verify                     | `yarn nx run mosaik-themes:design-md:check`                                                       |
