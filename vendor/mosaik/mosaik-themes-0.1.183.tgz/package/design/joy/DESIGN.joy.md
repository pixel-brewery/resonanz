---
version: 'alpha'
name: 'Mosaik Joy'
description: 'Light-mode value snapshot of the Joy theme, Mosaik''s default: soft radii, Nunito, flat surfaces with ripple feedback. Consume the --mosaik-* custom properties, never these literals.'
colors:
  primary: '{colors.mosaik-color-primary-500}'
  mosaik-scheme-surface: '#f5f5f5'
  mosaik-scheme-background: '#eaeaea'
  mosaik-scheme-foreground: '#3c454f'
  mosaik-scheme-highlight: '#d1d1d1'
  mosaik-scheme-middlelight: '#8a8a8a'
  mosaik-scheme-lowlight: '#5c5c5c'
  mosaik-scheme-transparent: 'rgba(255, 255, 255, 0)'
  mosaik-scheme-semi-transparent: 'rgba(255, 255, 255, 0.6666666666666666)'
  mosaik-scheme-disabled: '#686868'
  mosaik-scheme-contrast: '#ffffff'
  mosaik-scheme-selection: 'rgba(204, 204, 204, 0.4392156862745098)'
  mosaik-color-primary-0: '#ffffff'
  mosaik-color-primary-50: '#fce4ec'
  mosaik-color-primary-100: '#f8bcd0'
  mosaik-color-primary-200: '#f48fb1'
  mosaik-color-primary-300: '#f06292'
  mosaik-color-primary-400: '#ec407a'
  mosaik-color-primary-500: '#e91e63'
  mosaik-color-primary-600: '#cb1a56'
  mosaik-color-primary-700: '#a31545'
  mosaik-color-primary-800: '#7e1035'
  mosaik-color-primary-900: '#3a0819'
  mosaik-color-secondary-0: '#ffffff'
  mosaik-color-secondary-50: '#e6f6e9'
  mosaik-color-secondary-100: '#c3e8c9'
  mosaik-color-secondary-200: '#9bd9a7'
  mosaik-color-secondary-300: '#70cb83'
  mosaik-color-secondary-400: '#4dbf68'
  mosaik-color-secondary-500: '#21b34d'
  mosaik-color-secondary-600: '#16a444'
  mosaik-color-secondary-700: '#009238'
  mosaik-color-secondary-800: '#00812d'
  mosaik-color-secondary-900: '#006218'
  mosaik-color-tertiary-0: '#ffffff'
  mosaik-color-tertiary-50: '#e1f5fc'
  mosaik-color-tertiary-100: '#b4e6f7'
  mosaik-color-tertiary-200: '#84d5f3'
  mosaik-color-tertiary-300: '#56c5ee'
  mosaik-color-tertiary-400: '#35b8eb'
  mosaik-color-tertiary-500: '#19ace9'
  mosaik-color-tertiary-600: '#139edb'
  mosaik-color-tertiary-700: '#098bc7'
  mosaik-color-tertiary-800: '#087ab4'
  mosaik-color-tertiary-900: '#005a92'
  mosaik-color-info-0: '#ffffff'
  mosaik-color-info-50: '#f4faff'
  mosaik-color-info-100: '#ddf1ff'
  mosaik-color-info-200: '#addbff'
  mosaik-color-info-300: '#6fb6ff'
  mosaik-color-info-400: '#3990ff'
  mosaik-color-info-500: '#096bde'
  mosaik-color-info-600: '#054da7'
  mosaik-color-info-700: '#02367d'
  mosaik-color-info-800: '#072859'
  mosaik-color-info-900: '#00153c'
  mosaik-color-warning-0: '#ffffff'
  mosaik-color-warning-50: '#fff8c5'
  mosaik-color-warning-100: '#fae17d'
  mosaik-color-warning-200: '#eac54f'
  mosaik-color-warning-300: '#d4a72c'
  mosaik-color-warning-400: '#bf8700'
  mosaik-color-warning-500: '#9a6700'
  mosaik-color-warning-600: '#7d4e00'
  mosaik-color-warning-700: '#633c01'
  mosaik-color-warning-800: '#4d2d00'
  mosaik-color-warning-900: '#3b2300'
  mosaik-color-danger-0: '#ffffff'
  mosaik-color-danger-50: '#fff8f6'
  mosaik-color-danger-100: '#ffe9e8'
  mosaik-color-danger-200: '#ffc7c5'
  mosaik-color-danger-300: '#ff9192'
  mosaik-color-danger-400: '#fa5255'
  mosaik-color-danger-500: '#d3232f'
  mosaik-color-danger-600: '#a10e25'
  mosaik-color-danger-700: '#77061b'
  mosaik-color-danger-800: '#580013'
  mosaik-color-danger-900: '#39000d'
  mosaik-color-success-0: '#ffffff'
  mosaik-color-success-50: '#f3fef5'
  mosaik-color-success-100: '#d7f5dd'
  mosaik-color-success-200: '#77ec95'
  mosaik-color-success-300: '#4cc76e'
  mosaik-color-success-400: '#2ca24d'
  mosaik-color-success-500: '#1a7d36'
  mosaik-color-success-600: '#0f5d26'
  mosaik-color-success-700: '#034318'
  mosaik-color-success-800: '#002f0f'
  mosaik-color-success-900: '#001d09'
  mosaik-color-highlight-0: '#ffffff'
  mosaik-color-highlight-50: '#fdf7ff'
  mosaik-color-highlight-100: '#f4eaff'
  mosaik-color-highlight-200: '#e1cbff'
  mosaik-color-highlight-300: '#c69eff'
  mosaik-color-highlight-400: '#a374f9'
  mosaik-color-highlight-500: '#814dde'
  mosaik-color-highlight-600: '#5f35ae'
  mosaik-color-highlight-700: '#452382'
  mosaik-color-highlight-800: '#301761'
  mosaik-color-highlight-900: '#1d0a42'
  mosaik-color-neutral-0: '#ffffff'
  mosaik-color-neutral-50: '#f7f7f8'
  mosaik-color-neutral-100: '#ebebef'
  mosaik-color-neutral-200: '#d8d8df'
  mosaik-color-neutral-300: '#b9b9c6'
  mosaik-color-neutral-400: '#8f8fa3'
  mosaik-color-neutral-500: '#73738c'
  mosaik-color-neutral-600: '#5a5a72'
  mosaik-color-neutral-700: '#434356'
  mosaik-color-neutral-800: '#25252d'
  mosaik-color-neutral-900: '#131318'
typography:
  mosaik-typography-headline1:
    fontFamily: 'Nunito, sans-serif'
    fontSize: '96px'
    fontWeight: 300
    lineHeight: '100px'
    letterSpacing: '-0.25px'
  mosaik-typography-headline2:
    fontFamily: 'Nunito, sans-serif'
    fontSize: '60px'
    fontWeight: 300
    lineHeight: '64px'
    letterSpacing: '-0.13333333333333333px'
  mosaik-typography-headline3:
    fontFamily: 'Nunito, sans-serif'
    fontSize: '48px'
    fontWeight: 400
    lineHeight: '52px'
  mosaik-typography-headline4:
    fontFamily: 'Nunito, sans-serif'
    fontSize: '34px'
    fontWeight: 400
    lineHeight: '38px'
    letterSpacing: '0.11764705882352941px'
  mosaik-typography-headline5:
    fontFamily: 'Nunito, sans-serif'
    fontSize: '24px'
    fontWeight: 400
    lineHeight: '28px'
  mosaik-typography-headline6:
    fontFamily: 'Nunito, sans-serif'
    fontSize: '20px'
    fontWeight: 500
    lineHeight: '24px'
    letterSpacing: '0.2px'
  mosaik-typography-subtitle1:
    fontFamily: 'Nunito, sans-serif'
    fontSize: '16px'
    fontWeight: 400
    lineHeight: '20px'
    letterSpacing: '0.15px'
  mosaik-typography-subtitle2:
    fontFamily: 'Nunito, sans-serif'
    fontSize: '14px'
    fontWeight: 500
    lineHeight: '18px'
    letterSpacing: '0.1142857142857143px'
  mosaik-typography-body1:
    fontFamily: 'Nunito, sans-serif'
    fontSize: '16px'
    fontWeight: 400
    lineHeight: '20px'
    letterSpacing: '0.5px'
  mosaik-typography-body2:
    fontFamily: 'Nunito, sans-serif'
    fontSize: '14px'
    fontWeight: 400
    lineHeight: '18px'
    letterSpacing: '0.2857142857142857px'
  mosaik-typography-supporting:
    fontFamily: 'Nunito, sans-serif'
    fontSize: '12px'
    fontWeight: 400
    lineHeight: '14px'
    letterSpacing: '0.2857142857142857px'
  mosaik-typography-caption:
    fontFamily: 'Nunito, sans-serif'
    fontSize: '12px'
    fontWeight: 400
    lineHeight: '16px'
    letterSpacing: '0.5333333333333333px'
  mosaik-typography-overline:
    fontFamily: 'Nunito, sans-serif'
    fontSize: '12px'
    fontWeight: 500
    lineHeight: '16px'
    letterSpacing: '2.6666666666666665px'
  mosaik-typography-button:
    fontFamily: 'Nunito, sans-serif'
    fontSize: '14px'
    fontWeight: 700
    lineHeight: '18px'
    letterSpacing: '1.4285714285714286px'
rounded:
  mosaik-layout-radius: '12px'
spacing:
  mosaik-layout-space: '8px'
  mosaik-layout-thickness: '2px'
  mosaik-size-tiny: '2px'
  mosaik-size-small: '4px'
  mosaik-size-medium: '8px'
  mosaik-size-large: '16px'
  mosaik-size-giant: '32px'
components:
  button:
    backgroundColor: '{colors.mosaik-scheme-background}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    height: '56px'
    typography: '{typography.mosaik-typography-button}'
  button-active:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
  button-checked:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
  button-disabled:
    backgroundColor: '{colors.mosaik-scheme-background}'
    textColor: '{colors.mosaik-scheme-disabled}'
  button-focus:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
  button-giant:
    padding: '16px'
  button-hover:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
  button-large:
    padding: '12px'
  button-outline:
    backgroundColor: '{colors.mosaik-scheme-background}'
    textColor: '{colors.mosaik-scheme-foreground}'
  button-outline-hover:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
  button-outline-primary:
    textColor: '{colors.mosaik-color-primary-600}'
  button-outline-primary-hover:
    backgroundColor: '{colors.mosaik-color-primary-100}'
    textColor: '{colors.mosaik-color-primary-700}'
  button-plain:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  button-plain-hover:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
  button-plain-primary:
    textColor: '{colors.mosaik-color-primary-600}'
  button-plain-primary-hover:
    backgroundColor: '{colors.mosaik-color-primary-100}'
    textColor: '{colors.mosaik-color-primary-700}'
  button-selected:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
  button-small:
    padding: '6px'
  button-soft:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
    textColor: '{colors.mosaik-scheme-foreground}'
  button-soft-primary:
    backgroundColor: '{colors.mosaik-color-primary-100}'
    textColor: '{colors.mosaik-color-primary-700}'
  button-soft-primary-hover:
    backgroundColor: '{colors.mosaik-color-primary-200}'
    textColor: '{colors.mosaik-color-primary-800}'
  button-solid:
    backgroundColor: '{colors.mosaik-scheme-background}'
    textColor: '{colors.mosaik-scheme-foreground}'
  button-solid-primary:
    backgroundColor: '{colors.mosaik-color-primary-500}'
    textColor: '{colors.mosaik-color-primary-0}'
  button-solid-primary-hover:
    backgroundColor: '{colors.mosaik-color-primary-600}'
  button-tiny:
    padding: '4px'
  toggle-button:
    backgroundColor: '{colors.mosaik-scheme-background}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    typography: '{typography.mosaik-typography-button}'
  toggle-button-active:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
  toggle-button-checked:
    backgroundColor: '{colors.mosaik-scheme-background}'
  toggle-button-disabled:
    backgroundColor: '{colors.mosaik-scheme-background}'
    textColor: '{colors.mosaik-scheme-disabled}'
  toggle-button-focus:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
  toggle-button-giant:
    padding: '16px'
  toggle-button-hover:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
  toggle-button-large:
    padding: '12px'
  toggle-button-outline:
    backgroundColor: '{colors.mosaik-scheme-background}'
    textColor: '{colors.mosaik-scheme-foreground}'
  toggle-button-outline-hover:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
  toggle-button-outline-primary:
    textColor: '{colors.mosaik-color-primary-600}'
  toggle-button-outline-primary-checked:
    textColor: '{colors.mosaik-color-primary-700}'
  toggle-button-outline-primary-hover:
    backgroundColor: '{colors.mosaik-color-primary-100}'
    textColor: '{colors.mosaik-color-primary-700}'
  toggle-button-plain:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  toggle-button-plain-hover:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
  toggle-button-plain-primary:
    textColor: '{colors.mosaik-color-primary-600}'
  toggle-button-plain-primary-checked:
    textColor: '{colors.mosaik-color-primary-700}'
  toggle-button-plain-primary-hover:
    backgroundColor: '{colors.mosaik-color-primary-100}'
    textColor: '{colors.mosaik-color-primary-700}'
  toggle-button-selected:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
  toggle-button-small:
    padding: '6px'
  toggle-button-soft:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
    textColor: '{colors.mosaik-scheme-foreground}'
  toggle-button-soft-checked:
    backgroundColor: '{colors.mosaik-scheme-background}'
  toggle-button-soft-primary:
    backgroundColor: '{colors.mosaik-color-primary-100}'
    textColor: '{colors.mosaik-color-primary-700}'
  toggle-button-soft-primary-checked:
    backgroundColor: '{colors.mosaik-color-primary-300}'
    textColor: '{colors.mosaik-color-primary-900}'
  toggle-button-soft-primary-hover:
    backgroundColor: '{colors.mosaik-color-primary-200}'
    textColor: '{colors.mosaik-color-primary-800}'
  toggle-button-solid:
    backgroundColor: '{colors.mosaik-color-neutral-500}'
    textColor: '{colors.mosaik-color-neutral-0}'
  toggle-button-solid-checked:
    backgroundColor: '{colors.mosaik-color-neutral-700}'
  toggle-button-solid-primary:
    backgroundColor: '{colors.mosaik-color-primary-500}'
    textColor: '{colors.mosaik-color-primary-0}'
  toggle-button-solid-primary-checked:
    backgroundColor: '{colors.mosaik-color-primary-700}'
    textColor: '{colors.mosaik-color-primary-0}'
  toggle-button-solid-primary-hover:
    backgroundColor: '{colors.mosaik-color-primary-600}'
  toggle-button-tiny:
    padding: '4px'
  anchor:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
    typography: '{typography.mosaik-typography-body1}'
  anchor-disabled:
    textColor: '{colors.mosaik-scheme-disabled}'
  anchor-primary:
    textColor: '{colors.mosaik-color-primary-600}'
  anchor-primary-active:
    textColor: '{colors.mosaik-color-primary-800}'
  anchor-primary-hover:
    textColor: '{colors.mosaik-color-primary-700}'
  badge:
    backgroundColor: '{colors.mosaik-scheme-background}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    typography: '{typography.mosaik-typography-body2}'
  chip:
    backgroundColor: '{colors.mosaik-scheme-background}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '14px'
    height: '28px'
    padding: '{spacing.mosaik-layout-space}'
    typography: '{typography.mosaik-typography-body2}'
  chip-disabled:
    backgroundColor: '{colors.mosaik-scheme-background}'
    textColor: '{colors.mosaik-scheme-disabled}'
  chip-giant:
    height: '36px'
  chip-large:
    height: '32px'
  chip-outline:
    textColor: '{colors.mosaik-color-neutral-600}'
  chip-outline-primary:
    textColor: '{colors.mosaik-color-primary-600}'
  chip-plain:
    textColor: '{colors.mosaik-color-neutral-600}'
  chip-plain-primary:
    textColor: '{colors.mosaik-color-primary-600}'
  chip-small:
    height: '24px'
  chip-soft:
    backgroundColor: '{colors.mosaik-color-neutral-100}'
    textColor: '{colors.mosaik-color-neutral-700}'
  chip-soft-primary:
    backgroundColor: '{colors.mosaik-color-primary-100}'
    textColor: '{colors.mosaik-color-primary-700}'
  chip-solid:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
  chip-solid-primary:
    backgroundColor: '{colors.mosaik-color-primary-500}'
    textColor: '{colors.mosaik-color-primary-0}'
  chip-tiny:
    height: '20px'
  avatar:
    backgroundColor: '{colors.mosaik-scheme-background}'
    textColor: '{colors.mosaik-scheme-foreground}'
  persona:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
  card:
    backgroundColor: '{colors.mosaik-scheme-background}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    typography: '{typography.mosaik-typography-body1}'
  card-plain:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  card-soft:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
  card-header:
    padding: '16px'
  card-content:
    padding: '16px'
  card-actions:
    padding: '16px'
  textbox:
    backgroundColor: '{colors.mosaik-scheme-background}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    height: '56px'
    typography: '{typography.mosaik-typography-body1}'
  textbox-invalid:
    textColor: '{colors.mosaik-color-danger-600}'
  textbox-plain:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  textbox-readonly-invalid:
    textColor: '{colors.mosaik-color-danger-600}'
  textbox-soft:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
  textbox-solid:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
  searchbox:
    backgroundColor: '{colors.mosaik-scheme-background}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    height: '56px'
    typography: '{typography.mosaik-typography-body1}'
  searchbox-invalid:
    textColor: '{colors.mosaik-color-danger-600}'
  searchbox-soft:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
  searchbox-solid:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
  select:
    backgroundColor: '{colors.mosaik-scheme-background}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    height: '56px'
    typography: '{typography.mosaik-typography-body2}'
  select-plain:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  select-item:
    backgroundColor: '{colors.mosaik-scheme-background}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '0px'
    typography: '{typography.mosaik-typography-body2}'
  select-item-disabled:
    textColor: '{colors.mosaik-scheme-disabled}'
  select-item-hover:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
  checkbox:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '6px'
    typography: '{typography.mosaik-typography-body1}'
  checkbox-invalid:
    textColor: '{colors.mosaik-color-danger-600}'
  radio:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '6px'
    typography: '{typography.mosaik-typography-body1}'
  radio-invalid:
    textColor: '{colors.mosaik-color-danger-600}'
  toggle-switch:
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    typography: '{typography.mosaik-typography-body1}'
  toggle-switch-invalid:
    textColor: '{colors.mosaik-color-danger-500}'
  slider:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    typography: '{typography.mosaik-typography-body1}'
  slider-active:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
  slider-focus:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
  slider-hover:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
  slider-invalid:
    backgroundColor: '{colors.mosaik-color-danger-500}'
  list:
    backgroundColor: '{colors.mosaik-scheme-background}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    padding: '16px'
    typography: '{typography.mosaik-typography-body1}'
  list-item:
    backgroundColor: '{colors.mosaik-scheme-background}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    typography: '{typography.mosaik-typography-body1}'
  list-item-active:
    backgroundColor: '{colors.mosaik-color-primary-200}'
    textColor: '{colors.mosaik-color-primary-800}'
  list-item-checked:
    backgroundColor: '{colors.mosaik-color-primary-200}'
    textColor: '{colors.mosaik-color-primary-800}'
  list-item-disabled:
    textColor: '{colors.mosaik-scheme-disabled}'
  list-item-hover:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
  list-item-selected:
    backgroundColor: '{colors.mosaik-color-primary-200}'
    textColor: '{colors.mosaik-color-primary-800}'
  menu:
    backgroundColor: '{colors.mosaik-scheme-background}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    typography: '{typography.mosaik-typography-body1}'
  menu-item:
    backgroundColor: '{colors.mosaik-scheme-background}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    height: '48px'
    typography: '{typography.mosaik-typography-body1}'
  tab:
    backgroundColor: '{colors.mosaik-scheme-background}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    typography: '{typography.mosaik-typography-body1}'
  tab-outline:
    rounded: '{rounded.mosaik-layout-radius}'
  tab-plain:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
    rounded: '{rounded.mosaik-layout-radius}'
  tab-soft:
    rounded: '{rounded.mosaik-layout-radius}'
  tab-solid:
    rounded: '{rounded.mosaik-layout-radius}'
  tab-item:
    rounded: '{rounded.mosaik-layout-radius}'
  tooltip:
    backgroundColor: '{colors.mosaik-scheme-surface}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    padding: '{spacing.mosaik-layout-space}'
    typography: '{typography.mosaik-typography-body2}'
  dialog:
    backgroundColor: '{colors.mosaik-scheme-surface}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    typography: '{typography.mosaik-typography-body1}'
  drawer:
    backgroundColor: '{colors.mosaik-scheme-surface}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    width: '320px'
    typography: '{typography.mosaik-typography-body1}'
  toast:
    backgroundColor: '{colors.mosaik-scheme-background}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    typography: '{typography.mosaik-typography-body1}'
  toast-outline:
    backgroundColor: '{colors.mosaik-scheme-background}'
    textColor: '{colors.mosaik-scheme-foreground}'
  toast-outline-primary:
    textColor: '{colors.mosaik-color-primary-600}'
  toast-plain:
    backgroundColor: '{colors.mosaik-scheme-background}'
    textColor: '{colors.mosaik-scheme-foreground}'
  toast-plain-primary:
    textColor: '{colors.mosaik-color-primary-600}'
  toast-primary:
    backgroundColor: '{colors.mosaik-color-primary-500}'
    textColor: '{colors.mosaik-color-primary-0}'
  toast-soft:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
    textColor: '{colors.mosaik-scheme-foreground}'
  toast-soft-primary:
    backgroundColor: '{colors.mosaik-color-primary-100}'
    textColor: '{colors.mosaik-color-primary-700}'
  toast-solid:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
    textColor: '{colors.mosaik-scheme-foreground}'
  toast-solid-primary:
    backgroundColor: '{colors.mosaik-color-primary-500}'
    textColor: '{colors.mosaik-color-primary-0}'
  banner:
    backgroundColor: '{colors.mosaik-scheme-background}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    typography: '{typography.mosaik-typography-body1}'
  banner-outline:
    backgroundColor: '{colors.mosaik-scheme-background}'
    textColor: '{colors.mosaik-scheme-foreground}'
  banner-outline-primary:
    textColor: '{colors.mosaik-color-primary-600}'
  banner-plain:
    backgroundColor: '{colors.mosaik-scheme-background}'
    textColor: '{colors.mosaik-scheme-foreground}'
  banner-plain-primary:
    textColor: '{colors.mosaik-color-primary-600}'
  banner-soft:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
    textColor: '{colors.mosaik-scheme-foreground}'
  banner-soft-primary:
    backgroundColor: '{colors.mosaik-color-primary-100}'
    textColor: '{colors.mosaik-color-primary-700}'
  banner-solid:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
    textColor: '{colors.mosaik-scheme-foreground}'
  banner-solid-primary:
    backgroundColor: '{colors.mosaik-color-primary-500}'
    textColor: '{colors.mosaik-color-primary-0}'
  divider:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
    textColor: '{colors.mosaik-scheme-foreground}'
    typography: '{typography.mosaik-typography-supporting}'
  skeleton:
    backgroundColor: '{colors.mosaik-scheme-highlight}'
    rounded: '{rounded.mosaik-layout-radius}'
  expander:
    backgroundColor: '{colors.mosaik-scheme-background}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    typography: '{typography.mosaik-typography-body1}'
  expander-plain:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  expander-plain-hover:
    backgroundColor: '{colors.mosaik-scheme-transparent}'
  breadcrumb-item:
    textColor: '{colors.mosaik-scheme-foreground}'
  app-header:
    backgroundColor: '{colors.mosaik-scheme-surface}'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '{rounded.mosaik-layout-radius}'
    typography: '{typography.mosaik-typography-headline6}'
  text:
    backgroundColor: 'transparent'
    textColor: '{colors.mosaik-scheme-foreground}'
    rounded: '0px'
    typography: '{typography.mosaik-typography-body1}'
  text-disabled:
    textColor: '{colors.mosaik-scheme-disabled}'
  text-primary:
    textColor: '{colors.mosaik-color-primary-600}'
  text-readonly:
    textColor: '{colors.mosaik-scheme-lowlight}'
---

<!--
The YAML frontmatter and every `design-md:*` region of this file are generated by
libs/mosaik-themes/bin/design-md.mjs from the joy token sources. Build the themes package,
then run `yarn nx run mosaik-themes:design-md`; `yarn nx run mosaik-themes:design-md:check` fails
while the generated parts have drifted. All other prose is hand-authored and must not be
generated away.

Format: DESIGN.md (https://github.com/google-labs-code/design.md), linted with @google/design.md.
-->

# Mosaik Joy

## Overview

Joy is Mosaik's default theme and the one every downstream product starts from. It is soft,
friendly and unhurried: rounded corners, a warm neutral canvas instead of pure white, Nunito's
rounded terminals, flat surfaces that answer touch with a ripple rather than a shadow. Interfaces
built with Joy should feel approachable and calm, never loud; energy comes from the semantic color
ramps, not from decoration.

Mosaik **is** the design system. It does not sit on top of somebody else's; it ships the tokens,
the components and the icons. What makes it dynamic is that only the **names** are fixed. A
product may set its own font, its own palette values or its own spacing rhythm through
`provideTheme()` / `Theme2` overrides, and every component follows, because components never read
literals, only tokens. Joy, Memphis and Cosmopolitan are the three token value sets Mosaik ships
for that vocabulary, and each of them also carries its own component anatomy in the theme
stylesheets (`*.Joy.scss`, `*.Memphis.scss`, `*.Cosmopolitan.scss`).

Two token layers are fixed for this theme and captured in this document:

1. **The global set** from `tokens/themes/joy/joy.json` (merged with `tokens/themes/tokens.json`):
   scheme roles, nine color ramps, fourteen typography roles, layout rhythm, elevation, durations
   and the enum vocabularies. They are published as `--mosaik-*` custom properties and listed in
   the frontmatter as a light-mode snapshot.
2. **The component set**: one token file per component under `tokens/themes/joy/components/`,
   expanded with the shared mixins. Every entry becomes a `--<component>-<token>` custom property
   on the component's shadow host and is public styling API. The complete export, resolved to
   literals, is [COMPONENTS.joy.md](COMPONENTS.joy.md); the core atoms are also projected into the
   `components` block of the frontmatter.

Consumers never address a theme by its own prefix. The outward contract is the `--mosaik-*`
family: `ThemeService`, driven by `Theme2` or `provideTheme()`, remaps it onto the active theme's
internal `--<theme>-*` properties, which is what lets every theme, and every product built on one,
be used generically from outside.

Use this precedence whenever sources disagree:

1. The token sources in `libs/mosaik-themes/tokens/` and the component theme stylesheets.
2. The compiled artifacts (`dist/themes/___joy-tokens.css`, `joy-style()`) and the runtime
   `--mosaik-*` / `--joy-*` properties.
3. This document and [COMPONENTS.joy.md](COMPONENTS.joy.md).

### At a glance

<!-- design-md:stats -->

| Layer | Count | Source |
|---|---|---|
| Global tokens (compiled) | 448 | `dist/themes/___joy-tokens.css` |
| Runtime custom properties (light) | 593 | `joy-style()` and `ThemeService` |
| Components with a token file | 378 | `tokens/themes/joy/components/` |
| Component tokens (mixins expanded) | 11129 | `src/themes/joy/_components/` |
| Component tokens that do not resolve | 3 | [Known gaps](#known-gaps) |
<!-- /design-md:stats -->

### Activating the theme

The theme is selected by the `theme` attribute on `<html>` and the mode by `theme-mode`; both have
to be in place before any element module evaluates, because a component picks its themed
stylesheet at class-finalization time. Joy needs Nunito loaded; nothing in the theme ships a
`@font-face`.

```html
<html lang="en" theme="joy" theme-mode="light">
  <head>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
    <script type="module">
      import { JoyTheme, ThemeObserverServiceLocator } from 'https://esm.run/@pixel-brewery/mosaik-themes';
      const root = document.documentElement;
      ThemeObserverServiceLocator.current.applyTheme(root.getAttribute('theme') ?? 'joy', root.getAttribute('theme-mode') ?? 'light');
      await customElements.whenDefined('mosaik-theme2');
      document.querySelector('mosaik-theme2').theme = JoyTheme.JOY_THEME;
    </script>
    <script type="module" src="https://esm.run/@pixel-brewery/mosaik-elements-foundation"></script>
  </head>
  <body>
    <mosaik-theme2>
      <mosaik-button label="Save" variant="primary" appearance="solid"></mosaik-button>
    </mosaik-theme2>
  </body>
</html>
```

In a framework app the same happens through `provideTheme()` (Angular) or `<Theme2 theme={joyTheme} global>`
(React); `global` matters because overlays render through a portal outside the component tree.
Your own markup gets no font or color by default: set `font-family: var(--mosaik-font-family)`,
`color: var(--mosaik-scheme-foreground)` and `background: var(--mosaik-scheme-background)` on `body`.

## Colors

Joy paints on a **warm neutral canvas**. The page is `background` (`#eaeaea`), raised panels use
`surface` (`#f5f5f5`), text is a soft slate (`#3c454f`) rather than black, and boundaries are drawn
with `highlight` (`#d1d1d1`). Pure white appears only as stop `0` of a ramp and as `contrast`, the
color of content on a strongly colored surface. Dark mode keeps the same relationships on a
near-black canvas with a warm, slightly desaturated foreground (`#c3bab0`).

Nine ramps carry all chroma. `primary` is a confident pink (`#e91e63`), `secondary` a fresh green,
`tertiary` a sky blue; `info`, `warning`, `danger` and `success` are the semantic ramps, `highlight`
is the violet reserved for promotions and premium accents, and `neutral` is a cool gray for chrome.
Every ramp has eleven stops, `0` through `900`; stop `500` is the hero value, `0` is white.

### Scheme roles

Components reference scheme roles, not ramp stops, for surfaces and text. The custom property is
mode-neutral and switches with `theme-mode`.

<!-- design-md:scheme -->

| Role | Custom property | Light | Dark | Purpose |
|---|---|---|---|---|
| `surface` | `--mosaik-scheme-surface` | `#f5f5f5` | `#1e1e1e` | Elevated surfaces: cards, dialogs, panels. |
| `background` | `--mosaik-scheme-background` | `#eaeaea` | `#151515` | Page canvas and the default component fill. |
| `foreground` | `--mosaik-scheme-foreground` | `#3c454f` | `#c3bab0` | Default text and icon color. |
| `highlight` | `--mosaik-scheme-highlight` | `#d1d1d1` | `#2e2e2e` | Borders, dividers, hover fills. |
| `middlelight` | `--mosaik-scheme-middlelight` | `#8a8a8a` | `#757575` | Medium contrast - strokes, dividers, inactive marks and quiet fills. |
| `lowlight` | `--mosaik-scheme-lowlight` | `#5c5c5c` | `#a3a3a3` | The stronger secondary grey - secondary text, placeholders, captions and hints. |
| `transparent` | `--mosaik-scheme-transparent` | `rgba(255, 255, 255, 0)` | `rgba(255, 255, 255, 0)` | Fully transparent fill. |
| `semi-transparent` | `--mosaik-scheme-semi-transparent` | `rgba(255, 255, 255, 0.6666666666666666)` | `rgba(255, 255, 255, 0.03137254901960784)` | Glass-like overlays and backdrops. |
| `disabled` | `--mosaik-scheme-disabled` | `#686868` | `#474747` | Disabled text and controls. |
| `contrast` | `--mosaik-scheme-contrast` | `#ffffff` | `#000000` | Content on strongly colored surfaces. |
| `selection` | `--mosaik-scheme-selection` | `rgba(204, 204, 204, 0.4392156862745098)` | `rgba(204, 204, 204, 0.4392156862745098)` | Text selection background. |
<!-- /design-md:scheme -->

### Color ramps

<!-- design-md:palette -->

Light mode (`--mosaik-color-<family>-<stop>` resolves to these while `theme-mode="light"`):

| Family | 0 | 50 | 100 | 200 | 300 | 400 | 500 | 600 | 700 | 800 | 900 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| `primary` | `#ffffff` | `#fce4ec` | `#f8bcd0` | `#f48fb1` | `#f06292` | `#ec407a` | `#e91e63` | `#cb1a56` | `#a31545` | `#7e1035` | `#3a0819` |
| `secondary` | `#ffffff` | `#e6f6e9` | `#c3e8c9` | `#9bd9a7` | `#70cb83` | `#4dbf68` | `#21b34d` | `#16a444` | `#009238` | `#00812d` | `#006218` |
| `tertiary` | `#ffffff` | `#e1f5fc` | `#b4e6f7` | `#84d5f3` | `#56c5ee` | `#35b8eb` | `#19ace9` | `#139edb` | `#098bc7` | `#087ab4` | `#005a92` |
| `info` | `#ffffff` | `#f4faff` | `#ddf1ff` | `#addbff` | `#6fb6ff` | `#3990ff` | `#096bde` | `#054da7` | `#02367d` | `#072859` | `#00153c` |
| `warning` | `#ffffff` | `#fff8c5` | `#fae17d` | `#eac54f` | `#d4a72c` | `#bf8700` | `#9a6700` | `#7d4e00` | `#633c01` | `#4d2d00` | `#3b2300` |
| `danger` | `#ffffff` | `#fff8f6` | `#ffe9e8` | `#ffc7c5` | `#ff9192` | `#fa5255` | `#d3232f` | `#a10e25` | `#77061b` | `#580013` | `#39000d` |
| `success` | `#ffffff` | `#f3fef5` | `#d7f5dd` | `#77ec95` | `#4cc76e` | `#2ca24d` | `#1a7d36` | `#0f5d26` | `#034318` | `#002f0f` | `#001d09` |
| `highlight` | `#ffffff` | `#fdf7ff` | `#f4eaff` | `#e1cbff` | `#c69eff` | `#a374f9` | `#814dde` | `#5f35ae` | `#452382` | `#301761` | `#1d0a42` |
| `neutral` | `#ffffff` | `#f7f7f8` | `#ebebef` | `#d8d8df` | `#b9b9c6` | `#8f8fa3` | `#73738c` | `#5a5a72` | `#434356` | `#25252d` | `#131318` |

Dark mode (the same names resolve to these while `theme-mode="dark"`):

| Family | 0 | 50 | 100 | 200 | 300 | 400 | 500 | 600 | 700 | 800 | 900 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| `primary` | `#000000` | `#3a0819` | `#7e1035` | `#a31545` | `#cb1a56` | `#e91e63` | `#ec407a` | `#f06292` | `#f48fb1` | `#f8bcd0` | `#fce4ec` |
| `secondary` | `#000000` | `#006218` | `#00812d` | `#009238` | `#16a444` | `#21b34d` | `#4dbf68` | `#70cb83` | `#9bd9a7` | `#c3e8c9` | `#e6f6e9` |
| `tertiary` | `#000000` | `#005a92` | `#087ab4` | `#098bc7` | `#139edb` | `#19ace9` | `#35b8eb` | `#56c5ee` | `#84d5f3` | `#b4e6f7` | `#e1f5fc` |
| `info` | `#000000` | `#00153c` | `#072859` | `#02367d` | `#054da7` | `#096bde` | `#3990ff` | `#6fb6ff` | `#addbff` | `#ddf1ff` | `#f4faff` |
| `warning` | `#000000` | `#3b2300` | `#4d2d00` | `#633c01` | `#7d4e00` | `#9a6700` | `#bf8700` | `#d4a72c` | `#eac54f` | `#fae17d` | `#fff8c5` |
| `danger` | `#000000` | `#39000d` | `#580013` | `#77061b` | `#a10e25` | `#d3232f` | `#fa5255` | `#ff9192` | `#ffc7c5` | `#ffe9e8` | `#fff8f6` |
| `success` | `#000000` | `#001d09` | `#002f0f` | `#034318` | `#0f5d26` | `#1a7d36` | `#2ca24d` | `#4cc76e` | `#77ec95` | `#d7f5dd` | `#f3fef5` |
| `highlight` | `#000000` | `#1d0a42` | `#301761` | `#452382` | `#5f35ae` | `#814dde` | `#a374f9` | `#c69eff` | `#e1cbff` | `#f4eaff` | `#fdf7ff` |
| `neutral` | `#000000` | `#131318` | `#25252d` | `#434356` | `#5a5a72` | `#73738c` | `#8f8fa3` | `#b9b9c6` | `#d8d8df` | `#ebebef` | `#f7f7f8` |
<!-- /design-md:palette -->

### How variant and appearance pick a stop

The `variant` prop selects the ramp, the `appearance` prop selects how much of it shows. The
mapping below is the button's (`ButtonElement.Joy.scss`) and is the pattern the other interactive
atoms follow; the frontmatter `components` block carries the projected values for `primary`, and
the same stops apply to every other variant.

| Appearance | Rest                                                                 | Hover           | With a variant `v`                                                | Variant hover |
| ---------- | -------------------------------------------------------------------- | --------------- | ----------------------------------------------------------------- | ------------- |
| `default`  | `background` fill, `foreground` text, `highlight` border            | `highlight` fill | the variant is ignored; default buttons stay neutral              | –             |
| `outline`  | `background` fill, `foreground` text, `highlight` border (2px)      | `highlight` fill | text `v-600`, border and focus ring `v-500`, ripple `v-600`       | fill `v-100`, text `v-700` |
| `plain`    | transparent, no border                                               | `highlight` fill | text `v-600`, focus ring `v-500`, ripple `v-600`                  | fill `v-100`, text `v-700` |
| `soft`     | `highlight` fill, `foreground` text, no border                      | –               | fill `v-100`, text `v-700`, focus ring `v-500`, ripple `v-600`    | fill `v-200`, text `v-800` |
| `solid`    | `background` fill, `foreground` text, no border                     | –               | fill `v-500`, text `v-0`, focus ring `v-500`, ripple `v-600`      | fill `v-600`  |

Variant text keeps WCAG AA in both modes: on the page it takes `v-600`, on a tint `v-700` (`v-800` on the `v-200`
hover tint) - the `500` stop read 3.3-4.6:1 there. Borders, focus rings, ripples and the solid fills stay on `v-500` /
`v-600`. Badges, pips, chips, banners, toasts, field labels and links follow the same stops.

Pressing any button lays a `currentcolor` overlay at 26% opacity over the fill and starts the
ripple. Disabled buttons return to `background` / `highlight` with `disabled` text. Invalid inputs
switch the border to `danger-500` and the value text to `danger-600`, which keeps AA on the field and on the soft
and solid fills in both modes. Invalid check boxes, radios and choices follow the same split: the frame stays
`danger-500`, the mark and a slotted label take `danger-600`. The invalid toggle switch keeps its `danger-500` track,
which holds the knob above 3:1 in both modes; selected cards take a `primary-500` border.

### Naming rules

- `--mosaik-scheme-<role>` and `--mosaik-color-<family>-<stop>` are the consumer contract. They are
  aliases that `ThemeService` writes on `<html>`, pointing at the `--joy-*` originals with the
  literal as fallback, so they survive a theme switch.
- Mode-specific names exist only under the theme prefix (`--joy-scheme-light-surface`,
  `--joy-color-dark-primary-500`). Never introduce `dark-*` token names; the mode-neutral alias
  already switches.
- Contrast: `foreground` on `background` is 8.1:1 in light mode. White on `primary-500` is 4.35:1
  and `v-500` text on a `v-100` soft fill is below 3:1 for several ramps, so solid and soft
  emphasis are for buttons and badges, not for body copy. The linter reports these pairs.

## Typography

Joy speaks in **Nunito**, a rounded sans-serif whose terminals echo the 12px radius. The scale is
the Material type ramp: six light-to-regular headlines from 96px down to 20px, two subtitles, two
body sizes, `supporting` and `caption` at 12px, an `overline` and a bold 14px `button` role.
Headlines are light (300) or regular (400); only `headline6` is medium and only `button` is bold,
so weight alone signals interactivity. Nothing is uppercase by default.

The fourteen role names are the complete vocabulary. A product may change their values through an
override but must not rename them or add roles. Each role publishes `--mosaik-typography-<role>`
as a `font` shorthand plus `-font-family`, `-font-size`, `-font-weight`, `-line-height`,
`-letter-spacing`, `-text-decoration` and `-text-transform`. Per-role families default to
`var(--font-family)`, so a product sets one family and every role follows.

<!-- design-md:typography -->

| Role | Custom property | Family | Size | Line height | Weight | Letter spacing | Transform |
|---|---|---|---|---|---|---|---|
| `headline1` | `--mosaik-typography-headline1` | `Nunito, sans-serif` | `96px` | `100px` | `300` | `-0.25px` | `none` |
| `headline2` | `--mosaik-typography-headline2` | `Nunito, sans-serif` | `60px` | `64px` | `300` | `-0.13333333333333333px` | `none` |
| `headline3` | `--mosaik-typography-headline3` | `Nunito, sans-serif` | `48px` | `52px` | `400` | `normal` | `none` |
| `headline4` | `--mosaik-typography-headline4` | `Nunito, sans-serif` | `34px` | `38px` | `400` | `0.11764705882352941px` | `none` |
| `headline5` | `--mosaik-typography-headline5` | `Nunito, sans-serif` | `24px` | `28px` | `400` | `normal` | `none` |
| `headline6` | `--mosaik-typography-headline6` | `Nunito, sans-serif` | `20px` | `24px` | `500` | `0.2px` | `none` |
| `subtitle1` | `--mosaik-typography-subtitle1` | `Nunito, sans-serif` | `16px` | `20px` | `400` | `0.15px` | `none` |
| `subtitle2` | `--mosaik-typography-subtitle2` | `Nunito, sans-serif` | `14px` | `18px` | `500` | `0.1142857142857143px` | `none` |
| `body1` | `--mosaik-typography-body1` | `Nunito, sans-serif` | `16px` | `20px` | `400` | `0.5px` | `none` |
| `body2` | `--mosaik-typography-body2` | `Nunito, sans-serif` | `14px` | `18px` | `400` | `0.2857142857142857px` | `none` |
| `supporting` | `--mosaik-typography-supporting` | `Nunito, sans-serif` | `12px` | `14px` | `400` | `0.2857142857142857px` | `none` |
| `caption` | `--mosaik-typography-caption` | `Nunito, sans-serif` | `12px` | `16px` | `400` | `0.5333333333333333px` | `none` |
| `overline` | `--mosaik-typography-overline` | `Nunito, sans-serif` | `12px` | `16px` | `500` | `2.6666666666666665px` | `none` |
| `button` | `--mosaik-typography-button` | `Nunito, sans-serif` | `14px` | `18px` | `700` | `1.4285714285714286px` | `none` |
<!-- /design-md:typography -->

Letter spacing is tracking-derived, which is why the snapshot carries fractional pixel values;
consume the custom property rather than copying the number.

## Layout

Three tokens carry the whole rhythm. `layout.space` is the base unit of every padding, gap and
margin; components scale it with `calc()` (`calc(var(--mosaik-layout-space) * 2)` is the button's
horizontal padding, `* 4` a card inset). `layout.radius` rounds every rectangular surface, and
`layout.thickness` is the width of borders, dividers and indicators. Joy uses a generous 8px grid
with a 12px radius and a visible 2px stroke.

<!-- design-md:layout -->

| Token | Custom property | Value | Role |
|---|---|---|---|
| `layout.space` | `--mosaik-layout-space` | `8px` | Base unit of every padding, gap and margin; components scale it with `calc()`. |
| `layout.radius` | `--mosaik-layout-radius` | `12px` | Corner radius of every rectangular surface. |
| `layout.thickness` | `--mosaik-layout-thickness` | `2px` | Border width of controls, dividers and indicators. |

The size vocabulary components accept as `size`, `gap` or `iconSize` (values from `tokens/themes/tokens.json`; these are enum steps, not runtime custom properties):

| Key | Value |
|---|---|
| `tiny` | `2px` |
| `small` | `4px` |
| `medium` | `8px` |
| `large` | `16px` |
| `giant` | `32px` |
<!-- /design-md:layout -->

Layout is composed with `mosaik-stack` (flex with `gap`, horizontal by default) and `mosaik-grid`
(WPF-style track definitions), never with margins. Consumers that run Tailwind layer the preset
from `@pixel-brewery/mosaik-themes/tailwind/v4/joy`, which pins Tailwind's `--spacing` to
`layout.space` so utility classes stay on the same grid. Mosaik itself does not use Tailwind.

## Elevation & Depth

Depth in Joy is quiet. Every level is a **single soft shadow** that falls straight down: the offset
grows from 2px to 12px, the blur equals the offset and a negative spread keeps the shadow tucked
under the surface. The tint is black at 17% in light mode and 24% in dark mode, where the darker
canvas needs more. Components expose the scale as the `elevation` prop with named steps only;
numbers are silently invalid.

<!-- design-md:elevation -->

Every level is a stack of 1 shadow layer. `--mosaik-elevation-<level>` carries the complete `box-shadow` value; `--mosaik-elevation-<level>-{offset-x,offset-y,blur,spread,color}` expose the primary layer.

| Level | Light | Dark |
|---|---|---|
| `none` | `none` | `none` |
| `light` | `0px 2px 2px -2px rgba(0, 0, 0, 0.17)` | `0px 2px 2px -2px rgba(0, 0, 0, 0.24)` |
| `semilight` | `0px 4px 4px -2px rgba(0, 0, 0, 0.17)` | `0px 4px 4px -2px rgba(0, 0, 0, 0.24)` |
| `regular` | `0px 6px 6px -2px rgba(0, 0, 0, 0.17)` | `0px 6px 6px -2px rgba(0, 0, 0, 0.24)` |
| `semibold` | `0px 8px 8px -2px rgba(0, 0, 0, 0.17)` | `0px 8px 8px -2px rgba(0, 0, 0, 0.24)` |
| `bold` | `0px 10px 10px -2px rgba(0, 0, 0, 0.17)` | `0px 10px 10px -2px rgba(0, 0, 0, 0.24)` |
| `extrabold` | `0px 12px 12px -2px rgba(0, 0, 0, 0.17)` | `0px 12px 12px -2px rgba(0, 0, 0, 0.24)` |
<!-- /design-md:elevation -->

Prefer scheme contrast, a `highlight` border and spacing before reaching for depth. Resting cards
and buttons use `light` / `semilight`, dropdowns and popovers `regular` to `semibold`, dialogs and
drawers `bold`, and `extrabold` is reserved for the top layer. A `plain` or `soft` appearance drops
the shadow entirely.

## Shapes

Joy's geometry is **rounded and continuous**. `layout.radius` (12px) is the shared corner for
buttons, inputs, cards, chips and menus; components derive their own geometry from it rather than
declaring literals, so overriding the one token reshapes the whole interface. Grouped controls
(button groups, segments) square their inner corners and keep the radius on the outer ends instead
of overlapping independent rounded boxes. Circles and pills are component tokens, not global
ones: the avatar is `border-radius: 50%`, a chip rounds to half its height.

The focus ring is part of the shape language, in the component's focus colour - `foreground` for the
neutral look, the variant's `500` stop. Pointer focus shows it as a soft halo (the ring at 26 %),
2px outside the control (`focusRingOutwardOffset`; borderless appearances pull it flush, `0px`).
Keyboard focus (`:focus-visible`) raises it to a crisp ring one layout thickness wide and one
thickness away from the control (`theme.keyboard-focus-ring()`), following the control's radius.
Fields show focus in their frame and label (primary, or the variant's colour).

## Motion

Joy moves like **elastic gum**. The theme's motion language, Bubble-Drop (`.docs/design/animations.md`),
squashes on impact, stretches on rebound and settles with decreasing amplitude; the cross axis
never exceeds `1.0`, so nothing escapes its track. Interactive feedback is the ripple (`200ms`)
plus a color transition on `background-color`, `color`, `border-color`, `opacity`, `box-shadow`
and `translate`.

The switch thumb uses bounded position and width transitions. While pressed, the unchecked
thumb grows to the right with its left edge anchored; the checked thumb grows to the left
with its right edge anchored. Its height stays fixed, and release returns it to the resting size.

<!-- design-md:motion -->

| Token | Custom property | Value | Role |
|---|---|---|---|
| `duration.short` | `--mosaik-duration-short` | `0.2s` | Hover, focus and color transitions; the default `transition-duration` of components. |
| `duration.medium` | `--mosaik-duration-medium` | `0.4s` | Expand, collapse and reveal. |
| `duration.long` | `--mosaik-duration-long` | `0.6s` | Page-level and staged motion. |
<!-- /design-md:motion -->

`transitionDuration` defaults to `--mosaik-duration-short` with an `ease` curve; components honour
`prefers-reduced-motion` by collapsing durations to `0.01ms`.

## Components

Mosaik components are Lit web components; the framework packages are thin wrappers over the same
custom elements, so the design language is identical everywhere and only binding syntax differs.
The public language is expressed as **props, not classes**:

| Prop         | Values                                                                                                             |
| ------------ | ------------------------------------------------------------------------------------------------------------------ |
| `variant`    | `default`, `primary`, `secondary`, `tertiary`, `danger`, `warning`, `success`, `info`, `highlight`, `neutral`       |
| `appearance` | `default`, `outline`, `plain`, `soft`, `solid`                                                                     |
| `size`       | `tiny`, `small`, `medium`, `large`, `giant`                                                                        |
| `elevation`  | `none`, `light`, `semilight`, `regular`, `semibold`, `bold`, `extrabold`                                            |
| others       | `inset`, `fit`, `orientation`, `disabled`, `isBusy`, `isSelected` for spacing, sizing, direction and state          |

Not every component accepts all of them; the component's typings are authoritative. Text travels
through attributes (`label`, `text`, `header`), and containers only project their own sub
components (`mosaik-card` projects `mosaik-card-header`, `-content`, `-actions`, `-footer`).

### The component token contract

Each component owns one token file. The base skeleton (`tokens/themes/components.json`) gives
every component sixteen `unset` slots for font, padding, gap, transition and translate; mixins add
opt-in groups through `$includes`, and the component file sets the values that differ, always as
references to the global tokens. The merged map is declared on the shadow host as
`--<prefix>-<token>` custom properties, documented as `@cssprop` in the component's TSDoc, and any
of them can be overridden from outside:

```css
mosaik-button { --button-border-radius: 999px; }
mosaik-card   { --card-background-color: var(--mosaik-scheme-surface); }
```

| Mixin          | Tokens it contributes                                                                                          |
| -------------- | -------------------------------------------------------------------------------------------------------------- |
| `border`       | `borderColor`, `borderRadius`, `borderStyle` (`solid`), `borderWidth`                                          |
| `color:<role>` | `<role>Color`, used as `color:background` and `color:foreground`                                               |
| `dimensions`   | `width`, `height`                                                                                              |
| `minDimensions`| `minWidth`, `minHeight`                                                                                        |
| `padding`      | `paddingTop`, `paddingRight`, `paddingBottom`, `paddingLeft`                                                   |
| `inset`        | `insetTop`, `insetRight`, `insetBottom`, `insetLeft`                                                           |
| `gap`          | `gap`                                                                                                          |
| `font`         | `fontFamily`, `fontSize`, `fontWeight`, `fontLineHeight`, `fontLetterSpacing`, `fontTextDecoration`, `fontTextTransform`; `font:<part>` prefixes them |
| `floatingLabel`| `floatingLabelFontSize` (12px), `floatingLabelLineHeight` (12px)                                               |
| `shadow`       | `shadowOffsetX`, `shadowOffsetY`, `shadowBlur`, `shadowSpread`, `shadowColor` and the composed `shadow`         |
| `focusRing`    | `focusRingColor`, `focusRingInwardOffset` (2px), `focusRingOutwardOffset` (2px), `focusRingActiveWidth` (8px)  |
| `ripple`       | `rippleColor`, `rippleDuration` (200ms)                                                                        |
| `transition`   | `transitionDuration`, `transitionMode`, `transitionProperty`                                                   |
| `translate`    | `translate` (`none`)                                                                                           |
| `progressRing` | `progressRingWidth` (2px)                                                                                      |
| `prefix`, `suffix` | `prefixIconSize`, `suffixIconSize` (20px)                                                                  |
| `thumb`        | `thumbBackgroundColor`, `thumbBorderColor`, `thumbBorderRadius`                                                |
| `line`         | `lineThickness`                                                                                                |
| `stack`        | `stackTranslateStep`, `stackScaleStep`, `stackOpacityStep`, `stackRotationStep`, `stackGap`, `stackTransitionDuration`, `stackTransitionTimingFunction`, `stackIndent`, `stackExpandedScale` |

The frontmatter `components` block projects the core atoms into the DESIGN.md schema: the bare key
(`button`) is the token default, and related keys carry the overrides the theme stylesheet applies
for an appearance, a variant, a size or a state (`button-solid-primary`, `button-solid-primary-hover`,
`button-disabled`, `textbox-invalid`). Only `backgroundColor`, `textColor`, `typography`, `rounded`,
`padding`, `height` and `width` can be expressed there; everything else is in
[COMPONENTS.joy.md](COMPONENTS.joy.md).

### Runtime custom properties

<!-- design-md:runtime -->

A page with a `Theme2` / `provideTheme()` provider carries 593 custom properties in light mode: the 477 the compiled `joy-style()` stylesheet declares on `:root`, overlaid by what `ThemeService` writes from the theme object (dark mode redeclares the mode-dependent ones).

| Family | Properties |
|---|---|
| `--joy-color-*` | 297 |
| `--joy-duration-*` | 3 |
| `--joy-elevation-*` | 140 |
| `--joy-font-*` | 1 |
| `--joy-layout-*` | 4 |
| `--joy-scheme-*` | 33 |
| `--joy-typography-*` | 112 |
<!-- /design-md:runtime -->

`ThemeService` mirrors the scheme, color, font, typography, layout and elevation families as
`--mosaik-*` aliases; durations are aliased by the stylesheet itself. Sizes and the enum tokens have
no runtime property.

### Component index

Every component with a token file, its tag and the number of tokens it exports. The prefix of a
component's custom properties is its tag without `mosaik-` (`mosaik-textbox` declares `--textbox-*`). The
full tables, with a link to each component's reference documentation, are in [COMPONENTS.joy.md](COMPONENTS.joy.md).

<!-- design-md:component-index -->

| Token file | Tag | Tokens |
|---|---|---|
| [absolute](COMPONENTS.joy.md#absolute) | `mosaik-absolute` | 22 |
| [absoluteItem](COMPONENTS.joy.md#absolute-item) | `mosaik-absolute-item` | 22 |
| [accordion](COMPONENTS.joy.md#accordion) | `mosaik-accordion` | 22 |
| [actionbar-group](COMPONENTS.joy.md#actionbar-group) | `mosaik-actionbar-group` | 25 |
| [actionbar-item](COMPONENTS.joy.md#actionbar-item) | `mosaik-actionbar-item` | 26 |
| [actionbar-separator](COMPONENTS.joy.md#actionbar-separator) | `mosaik-actionbar-separator` | 24 |
| [actionbar](COMPONENTS.joy.md#actionbar) | `mosaik-actionbar` | 29 |
| [alert](COMPONENTS.joy.md#alert) | `mosaik-alert` | 22 |
| [anchor](COMPONENTS.joy.md#anchor) | `mosaik-anchor` | 25 |
| [app](COMPONENTS.joy.md#app) | `mosaik-app` | 36 |
| [appHeader](COMPONENTS.joy.md#app-header) | `mosaik-app-header` | 31 |
| [audio](COMPONENTS.joy.md#audio) | `mosaik-audio` | 36 |
| [autoCompleteBox](COMPONENTS.joy.md#autocompletebox) | `mosaik-autocompletebox` | 33 |
| [avatar](COMPONENTS.joy.md#avatar) | `mosaik-avatar` | 34 |
| [avatarGroup](COMPONENTS.joy.md#avatar-group) | `mosaik-avatar-group` | 28 |
| [backTop](COMPONENTS.joy.md#back-top) | `mosaik-back-top` | 22 |
| [backdrop](COMPONENTS.joy.md#backdrop) | `mosaik-backdrop` | 24 |
| [badge](COMPONENTS.joy.md#badge) | `mosaik-badge` | 34 |
| [banner](COMPONENTS.joy.md#banner) | `mosaik-banner` | 34 |
| [bannerGroup](COMPONENTS.joy.md#banner-group) | `mosaik-banner-group` | 31 |
| [bannerHeader](COMPONENTS.joy.md#banner-header) | `mosaik-banner-header` | 24 |
| [bannerSubHeader](COMPONENTS.joy.md#banner-sub-header) | `mosaik-banner-sub-header` | 24 |
| [box](COMPONENTS.joy.md#box) | `mosaik-box` | 30 |
| [breadcrumb](COMPONENTS.joy.md#breadcrumb) | `mosaik-breadcrumb` | 22 |
| [breadcrumbItem](COMPONENTS.joy.md#breadcrumb-item) | `mosaik-breadcrumb-item` | 25 |
| [bubbles](COMPONENTS.joy.md#bubbles) | `mosaik-bubbles` | 23 |
| [busyState](COMPONENTS.joy.md#busy-state) | `mosaik-busy-state` | 30 |
| [button](COMPONENTS.joy.md#button) | `mosaik-button` | 41 |
| [buttonGroup](COMPONENTS.joy.md#button-group) | `mosaik-button-group` | 28 |
| [calendar](COMPONENTS.joy.md#calendar) | `mosaik-calendar` | 29 |
| [calendarDaysView](COMPONENTS.joy.md#calendar-days-view) | `mosaik-calendar-days-view` | 22 |
| [calendarHeader](COMPONENTS.joy.md#calendar-header) | `mosaik-calendar-header` | 28 |
| [calendarItem](COMPONENTS.joy.md#calendar-item) | `mosaik-calendar-item` | 41 |
| [calendarMonthsView](COMPONENTS.joy.md#calendar-months-view) | `mosaik-calendar-months-view` | 22 |
| [calendarSubHeader](COMPONENTS.joy.md#calendar-sub-header) | `mosaik-calendar-sub-header` | 30 |
| [calendarYearsView](COMPONENTS.joy.md#calendar-years-view) | `mosaik-calendar-years-view` | 22 |
| [camera](COMPONENTS.joy.md#camera) | `mosaik-camera` | 25 |
| [card](COMPONENTS.joy.md#card) | `mosaik-card` | 29 |
| [cardActions](COMPONENTS.joy.md#card-actions) | `mosaik-card-actions` | 22 |
| [cardContent](COMPONENTS.joy.md#card-content) | `mosaik-card-content` | 22 |
| [cardFooter](COMPONENTS.joy.md#card-footer) | `mosaik-card-footer` | 22 |
| [cardHeader](COMPONENTS.joy.md#card-header) | `mosaik-card-header` | 22 |
| [cardStack](COMPONENTS.joy.md#card-stack) | `mosaik-card-stack` | 21 |
| [cardSubTitle](COMPONENTS.joy.md#card-sub-title) | `mosaik-card-sub-title` | 25 |
| [cardTitle](COMPONENTS.joy.md#card-title) | `mosaik-card-title` | 25 |
| [carousel](COMPONENTS.joy.md#carousel) | `mosaik-carousel` | 42 |
| [carouselItem](COMPONENTS.joy.md#carousel-item) | `mosaik-carousel-item` | 22 |
| [cell](COMPONENTS.joy.md#cell) | `mosaik-cell` | 30 |
| [cellGroup](COMPONENTS.joy.md#cell-group) | `mosaik-cell-group` | 28 |
| [chart](COMPONENTS.joy.md#chart) | `mosaik-chart` | 24 |
| [chartToolbox](COMPONENTS.joy.md#chart-toolbox) | `mosaik-chart-toolbox` | 23 |
| [chat](COMPONENTS.joy.md#chat) | `mosaik-chat` | 30 |
| [chatHeader](COMPONENTS.joy.md#chat-header) | `mosaik-chat-header` | 23 |
| [chatMarker](COMPONENTS.joy.md#chat-marker) | `mosaik-chat-marker` | 28 |
| [chatMessage](COMPONENTS.joy.md#chat-message) | `mosaik-chat-message` | 29 |
| [chatMessageAvatar](COMPONENTS.joy.md#chat-message-avatar) | `mosaik-chat-message-avatar` | 34 |
| [chatMessageDivider](COMPONENTS.joy.md#chat-message-divider) | `mosaik-chat-message-divider` | 23 |
| [chatMessageReaction](COMPONENTS.joy.md#chat-message-reaction) | `mosaik-chat-message-reaction` | 23 |
| [checkBox](COMPONENTS.joy.md#checkbox) | `mosaik-checkbox` | 28 |
| [checkBoxGroup](COMPONENTS.joy.md#checkbox-group) | `mosaik-checkbox-group` | 28 |
| [checkmark](COMPONENTS.joy.md#checkmark) | `mosaik-checkmark` | 36 |
| [chip](COMPONENTS.joy.md#chip) | `mosaik-chip` | 35 |
| [chipBox](COMPONENTS.joy.md#chipbox) | `mosaik-chipbox` | 43 |
| [chipGroup](COMPONENTS.joy.md#chip-group) | `mosaik-chip-group` | 28 |
| [choice](COMPONENTS.joy.md#choice) | `mosaik-choice` | 32 |
| [choiceGroup](COMPONENTS.joy.md#choice-group) | `mosaik-choice-group` | 28 |
| [choiceGroupHeader](COMPONENTS.joy.md#choice-group-header) | `mosaik-choice-group-header` | 28 |
| [clickable](COMPONENTS.joy.md#clickable) | `mosaik-clickable` | 33 |
| [code](COMPONENTS.joy.md#code) | `mosaik-code` | 23 |
| [codeEditor](COMPONENTS.joy.md#code-editor) | `mosaik-code-editor` | 78 |
| [colorArea](COMPONENTS.joy.md#color-area) | `mosaik-color-area` | 22 |
| [colorBox](COMPONENTS.joy.md#colorbox) | `mosaik-colorbox` | 41 |
| [colorEditor](COMPONENTS.joy.md#color-editor) | `mosaik-color-editor` | 34 |
| [colorEditorAlphaSlider](COMPONENTS.joy.md#color-editor-alpha-slider) | `mosaik-color-editor-alpha-slider` | 41 |
| [colorEditorArea](COMPONENTS.joy.md#color-editor-area) | `mosaik-color-editor-area` | 39 |
| [colorEditorHueSlider](COMPONENTS.joy.md#color-editor-hue-slider) | `mosaik-color-editor-hue-slider` | 40 |
| [colorEditorInputs](COMPONENTS.joy.md#color-editor-inputs) | `mosaik-color-editor-inputs` | 37 |
| [colorEditorPalette](COMPONENTS.joy.md#color-editor-palette) | `mosaik-color-editor-palette` | 36 |
| [colorEditorShadeSlider](COMPONENTS.joy.md#color-editor-shade-slider) | `mosaik-color-editor-shade-slider` | 40 |
| [colorEditorSwatch](COMPONENTS.joy.md#color-editor-swatch) | `mosaik-color-editor-swatch` | 31 |
| [colorPicker](COMPONENTS.joy.md#color-picker) | `mosaik-color-picker` | 29 |
| [colorSlider](COMPONENTS.joy.md#color-slider) | `mosaik-color-slider` | 28 |
| [colorSwatch](COMPONENTS.joy.md#color-swatch) | `mosaik-color-swatch` | 29 |
| [colorSwatchGroup](COMPONENTS.joy.md#color-swatch-group) | `mosaik-color-swatch-group` | 28 |
| [colorThumb](COMPONENTS.joy.md#color-thumb) | `mosaik-color-thumb` | 29 |
| [combo](COMPONENTS.joy.md#combo) | `mosaik-combo` | 36 |
| [comboItem](COMPONENTS.joy.md#combo-item) | `mosaik-combo-item` | 34 |
| [comboItemGroup](COMPONENTS.joy.md#combo-item-group) | `mosaik-combo-item-group` | 39 |
| [comboItemVisual](COMPONENTS.joy.md#combo-item-visual) | `mosaik-combo-item-visual` | 22 |
| [comment](COMPONENTS.joy.md#comment) | `mosaik-comment` | 25 |
| [compoundButton](COMPONENTS.joy.md#compound-button) | `mosaik-compound-button` | 41 |
| [content](COMPONENTS.joy.md#content) | `mosaik-content` | 22 |
| [cookiesConsent](COMPONENTS.joy.md#cookie-consent) | `mosaik-cookie-consent` | 22 |
| [cursorEffect](COMPONENTS.joy.md#cursor-effect) | `mosaik-cursor-effect` | 21 |
| [dataList](COMPONENTS.joy.md#data-list) | `mosaik-data-list` | 22 |
| [dataTable](COMPONENTS.joy.md#data-table) | `mosaik-data-table` | 24 |
| [dateBox](COMPONENTS.joy.md#datebox) | `mosaik-datebox` | 41 |
| [dateTimeBox](COMPONENTS.joy.md#datetimebox) | `mosaik-datetimebox` | 41 |
| [designer](COMPONENTS.joy.md#designer) | `mosaik-designer` | 22 |
| [designerCanvas](COMPONENTS.joy.md#designer-canvas) | `mosaik-designer-canvas` | 26 |
| [designerConnector](COMPONENTS.joy.md#designer-connector) | `mosaik-designer-connector` | 27 |
| [designerContent](COMPONENTS.joy.md#designer-content) | `mosaik-designer-content` | 22 |
| [designerFrame](COMPONENTS.joy.md#designer-frame) | `mosaik-designer-frame` | 34 |
| [dialog](COMPONENTS.joy.md#dialog) | `mosaik-dialog` | 29 |
| [dialogActions](COMPONENTS.joy.md#dialog-actions) | `mosaik-dialog-actions` | 22 |
| [dialogContent](COMPONENTS.joy.md#dialog-content) | `mosaik-dialog-content` | 22 |
| [dialogFooter](COMPONENTS.joy.md#dialog-footer) | `mosaik-dialog-footer` | 22 |
| [dialogHeader](COMPONENTS.joy.md#dialog-header) | `mosaik-dialog-header` | 22 |
| [dialogHeaderSubText](COMPONENTS.joy.md#dialog-header-sub-text) | `mosaik-dialog-header-sub-text` | 25 |
| [dialogHeaderText](COMPONENTS.joy.md#dialog-header-text) | `mosaik-dialog-header-text` | 25 |
| [disclosure](COMPONENTS.joy.md#disclosure) | `mosaik-disclosure` | 32 |
| [dismiss](COMPONENTS.joy.md#dismiss) | `mosaik-dismiss` | 22 |
| [divider](COMPONENTS.joy.md#divider) | `mosaik-divider` | 25 |
| [dockPanel](COMPONENTS.joy.md#dock-panel) | `mosaik-dock-panel` | 22 |
| [dot](COMPONENTS.joy.md#dot) | `mosaik-dot` | 29 |
| [dotGroup](COMPONENTS.joy.md#dot-group) | `mosaik-dot-group` | 28 |
| [drawer](COMPONENTS.joy.md#drawer) | `mosaik-drawer` | 33 |
| [drawerActions](COMPONENTS.joy.md#drawer-actions) | `mosaik-drawer-actions` | 22 |
| [drawerContainer](COMPONENTS.joy.md#drawer-container) | `mosaik-drawer-container` | 23 |
| [drawerContent](COMPONENTS.joy.md#drawer-content) | `mosaik-drawer-content` | 26 |
| [drawerFooter](COMPONENTS.joy.md#drawer-footer) | `mosaik-drawer-footer` | 22 |
| [drawerHeader](COMPONENTS.joy.md#drawer-header) | `mosaik-drawer-header` | 22 |
| [drawerHeaderSubText](COMPONENTS.joy.md#drawer-header-sub-text) | `mosaik-drawer-header-sub-text` | 25 |
| [drawerHeaderText](COMPONENTS.joy.md#drawer-header-text) | `mosaik-drawer-header-text` | 25 |
| [drawerRail](COMPONENTS.joy.md#drawer-rail) | `mosaik-drawer-rail` | 25 |
| [dropDownButton](COMPONENTS.joy.md#dropdown-button) | `mosaik-dropdown-button` | 44 |
| [dropZone](COMPONENTS.joy.md#drop-zone) | `mosaik-drop-zone` | 27 |
| [dropdown](COMPONENTS.joy.md#dropdown) | `mosaik-dropdown` | 42 |
| [durationBox](COMPONENTS.joy.md#durationbox) | `mosaik-durationbox` | 41 |
| [elevation](COMPONENTS.joy.md#elevation) | `mosaik-elevation` | 22 |
| [emoji](COMPONENTS.joy.md#emoji) | `mosaik-emoji` | 23 |
| [emptyState](COMPONENTS.joy.md#empty-state) | `mosaik-empty-state` | 30 |
| [epg](COMPONENTS.joy.md#epg) | `mosaik-epg` | 28 |
| [epgChannel](COMPONENTS.joy.md#epg-channel) | `mosaik-epg-channel` | 28 |
| [epgMinimap](COMPONENTS.joy.md#epg-minimap) | `mosaik-epg-minimap` | 28 |
| [epgNowLine](COMPONENTS.joy.md#epg-now-line) | `mosaik-epg-now-line` | 26 |
| [epgProgram](COMPONENTS.joy.md#epg-program) | `mosaik-epg-program` | 28 |
| [epgTimeline](COMPONENTS.joy.md#epg-timeline) | `mosaik-epg-timeline` | 28 |
| [error](COMPONENTS.joy.md#error) | `mosaik-error` | 28 |
| [errorState](COMPONENTS.joy.md#error-state) | `mosaik-error-state` | 29 |
| [expandable](COMPONENTS.joy.md#expandable) | `mosaik-expandable` | 22 |
| [expander](COMPONENTS.joy.md#expander) | `mosaik-expander` | 31 |
| [expanderGroup](COMPONENTS.joy.md#expander-group) | `mosaik-expander-group` | 28 |
| [expanderHeader](COMPONENTS.joy.md#expander-header) | `mosaik-expander-header` | 25 |
| [expanderSubHeader](COMPONENTS.joy.md#expander-sub-header) | `mosaik-expander-sub-header` | 25 |
| [fileBox](COMPONENTS.joy.md#filebox) | `mosaik-filebox` | 41 |
| [filePicker](COMPONENTS.joy.md#file-picker) | `mosaik-file-picker` | 28 |
| [fileUpload](COMPONENTS.joy.md#file-upload) | `mosaik-file-upload` | 37 |
| [fileUploadItem](COMPONENTS.joy.md#file-upload-item) | `mosaik-file-upload-item` | 28 |
| [flip](COMPONENTS.joy.md#flip) | `mosaik-flip` | 22 |
| [floating](COMPONENTS.joy.md#floating) | `mosaik-floating` | 31 |
| [floatingActionButton](COMPONENTS.joy.md#fab) | `mosaik-fab` | 39 |
| [floatingActionButtonGroup](COMPONENTS.joy.md#fab-group) | `mosaik-fab-group` | 22 |
| [floatingTrigger](COMPONENTS.joy.md#floating-trigger) | `mosaik-floating-trigger` | 22 |
| [flow](COMPONENTS.joy.md#flow) | `mosaik-flow` | 33 |
| [flowBoard](COMPONENTS.joy.md#flow-board) | `mosaik-flow-board` | 24 |
| [flowBoardColumn](COMPONENTS.joy.md#flow-board-column) | `mosaik-flow-board-column` | 44 |
| [flowBoardColumnComposer](COMPONENTS.joy.md#flow-board-column-composer) | `mosaik-flow-board-column-composer` | 30 |
| [flowBoardColumnItem](COMPONENTS.joy.md#flow-board-column-item) | `mosaik-flow-board-column-item` | 37 |
| [flowBoardColumnItemComposer](COMPONENTS.joy.md#flow-board-column-item-composer) | `mosaik-flow-board-column-item-composer` | 30 |
| [flowBoardColumnItemGroup](COMPONENTS.joy.md#flow-board-column-item-group) | `mosaik-flow-board-column-item-group` | 36 |
| [flowControls](COMPONENTS.joy.md#flow-controls) | `mosaik-flow-controls` | 37 |
| [flowEdge](COMPONENTS.joy.md#flow-edge) | `mosaik-flow-edge` | 39 |
| [flowMinimap](COMPONENTS.joy.md#flow-minimap) | `mosaik-flow-minimap` | 42 |
| [flowNode](COMPONENTS.joy.md#flow-node) | `mosaik-flow-node` | 47 |
| [focusRing](COMPONENTS.joy.md#focus-ring) | `mosaik-focus-ring` | 35 |
| [fontEditor](COMPONENTS.joy.md#font-editor) | `mosaik-font-editor` | 56 |
| [footer](COMPONENTS.joy.md#footer) | `mosaik-footer` | 29 |
| [footerItem](COMPONENTS.joy.md#footer-item) | `mosaik-footer-item` | 22 |
| [footerItemGroup](COMPONENTS.joy.md#footer-item-group) | `mosaik-footer-item-group` | 22 |
| [form](COMPONENTS.joy.md#form) | `mosaik-form` | 23 |
| [formField](COMPONENTS.joy.md#form-field) | `mosaik-form-field` | 23 |
| [gauge](COMPONENTS.joy.md#gauge) | `mosaik-gauge` | 28 |
| [gaugeArc](COMPONENTS.joy.md#gauge-arc) | `mosaik-gauge-arc` | 25 |
| [gaugeControl](COMPONENTS.joy.md#gauge-control) | `mosaik-gauge-control` | 28 |
| [gaugeDot](COMPONENTS.joy.md#gauge-dot) | `mosaik-gauge-dot` | 27 |
| [gaugeHub](COMPONENTS.joy.md#gauge-hub) | `mosaik-gauge-hub` | 25 |
| [gaugeInset](COMPONENTS.joy.md#gauge-inset) | `mosaik-gauge-inset` | 22 |
| [gaugeMarks](COMPONENTS.joy.md#gauge-marks) | `mosaik-gauge-marks` | 26 |
| [gaugeNeedle](COMPONENTS.joy.md#gauge-needle) | `mosaik-gauge-needle` | 25 |
| [gaugeStack](COMPONENTS.joy.md#gauge-stack) | `mosaik-gauge-stack` | 25 |
| [gaugeText](COMPONENTS.joy.md#gauge-text) | `mosaik-gauge-text` | 26 |
| [gaugeTickLabels](COMPONENTS.joy.md#gauge-tick-labels) | `mosaik-gauge-tick-labels` | 26 |
| [gaugeTicks](COMPONENTS.joy.md#gauge-ticks) | `mosaik-gauge-ticks` | 26 |
| [gaugeTooltip](COMPONENTS.joy.md#gauge-tooltip) | `mosaik-gauge-tooltip` | 29 |
| [gaugeTrack](COMPONENTS.joy.md#gauge-track) | `mosaik-gauge-track` | 25 |
| [gaugeValue](COMPONENTS.joy.md#gauge-value) | `mosaik-gauge-value` | 26 |
| [gaugeZones](COMPONENTS.joy.md#gauge-zones) | `mosaik-gauge-zones` | 25 |
| [ghost](COMPONENTS.joy.md#ghost) | `mosaik-ghost` | 27 |
| [globe](COMPONENTS.joy.md#globe) | `mosaik-globe` | 24 |
| [grid](COMPONENTS.joy.md#grid) | `mosaik-grid` | 22 |
| [gridItem](COMPONENTS.joy.md#grid-item) | `mosaik-grid-item` | 22 |
| [helmet](COMPONENTS.joy.md#helmet) | `mosaik-helmet` | 22 |
| [hint](COMPONENTS.joy.md#hint) | `mosaik-hint` | 28 |
| [icon](COMPONENTS.joy.md#icon) | `mosaik-icon` | 28 |
| [image](COMPONENTS.joy.md#image) | `mosaik-image` | 39 |
| [indicator](COMPONENTS.joy.md#indicator) | `mosaik-indicator` | 28 |
| [inkBar](COMPONENTS.joy.md#ink-bar) | `mosaik-ink-bar` | 25 |
| [jumbotron](COMPONENTS.joy.md#jumbotron) | `mosaik-jumbotron` | 28 |
| [jumbotronHeader](COMPONENTS.joy.md#jumbotron-header) | `mosaik-jumbotron-header` | 25 |
| [jumbotronSubHeader](COMPONENTS.joy.md#jumbotron-sub-header) | `mosaik-jumbotron-sub-header` | 25 |
| [kbd](COMPONENTS.joy.md#kbd) | `mosaik-kbd` | 28 |
| [kbdShortcut](COMPONENTS.joy.md#kbd-shortcut) | `mosaik-kbd-shortcut` | 22 |
| [knob](COMPONENTS.joy.md#knob) | `mosaik-knob` | 41 |
| [lightChain](COMPONENTS.joy.md#light-chain) | `mosaik-light-chain` | 22 |
| [list](COMPONENTS.joy.md#list) | `mosaik-list` | 29 |
| [listItem](COMPONENTS.joy.md#list-item) | `mosaik-list-item` | 34 |
| [listItemGroup](COMPONENTS.joy.md#list-item-group) | `mosaik-list-item-group` | 39 |
| [listing](COMPONENTS.joy.md#listing) | `mosaik-listing` | 24 |
| [listingItem](COMPONENTS.joy.md#listing-item) | `mosaik-listing-item` | 24 |
| [listingItemMarker](COMPONENTS.joy.md#listing-item-marker) | `mosaik-listing-item-marker` | 29 |
| [map](COMPONENTS.joy.md#map) | `mosaik-map` | 22 |
| [marquee](COMPONENTS.joy.md#marquee) | `mosaik-marquee` | 25 |
| [masonry](COMPONENTS.joy.md#masonry) | `mosaik-masonry` | 23 |
| [mention](COMPONENTS.joy.md#mention) | `mosaik-mention` | 32 |
| [menu](COMPONENTS.joy.md#menu) | `mosaik-menu` | 28 |
| [menuItem](COMPONENTS.joy.md#menu-item) | `mosaik-menu-item` | 38 |
| [menuItemGroup](COMPONENTS.joy.md#menu-item-group) | `mosaik-menu-item-group` | 39 |
| [message](COMPONENTS.joy.md#message) | `mosaik-message` | 28 |
| [messageBox](COMPONENTS.joy.md#message-box) | `mosaik-message-box` | 45 |
| [meterBar](COMPONENTS.joy.md#meter-bar) | `mosaik-meter-bar` | 26 |
| [meterRing](COMPONENTS.joy.md#meter-ring) | `mosaik-meter-ring` | 36 |
| [number](COMPONENTS.joy.md#number) | `mosaik-number` | 24 |
| [numberBox](COMPONENTS.joy.md#numberbox) | `mosaik-numberbox` | 41 |
| [numberCounter](COMPONENTS.joy.md#number-counter) | `mosaik-number-counter` | 24 |
| [numberTicker](COMPONENTS.joy.md#number-ticker) | `mosaik-number-ticker` | 16 |
| [orbit](COMPONENTS.joy.md#orbit) | `mosaik-orbit` | 19 |
| [page](COMPONENTS.joy.md#page) | `mosaik-page` | 22 |
| [pageContent](COMPONENTS.joy.md#page-content) | `mosaik-page-content` | 23 |
| [pageHeader](COMPONENTS.joy.md#page-header) | `mosaik-page-header` | 48 |
| [pageMenu](COMPONENTS.joy.md#page-menu) | `mosaik-page-menu` | 30 |
| [pagePreContent](COMPONENTS.joy.md#page-pre-content) | `mosaik-page-pre-content` | 23 |
| [pagePreHeader](COMPONENTS.joy.md#page-pre-header) | `mosaik-page-pre-header` | 23 |
| [paginator](COMPONENTS.joy.md#paginator) | `mosaik-paginator` | 23 |
| [parallax](COMPONENTS.joy.md#parallax) | `mosaik-parallax` | 16 |
| [passwordBox](COMPONENTS.joy.md#passwordbox) | `mosaik-passwordbox` | 41 |
| [pattern](COMPONENTS.joy.md#pattern) | `mosaik-pattern` | 23 |
| [persona](COMPONENTS.joy.md#persona) | `mosaik-persona` | 28 |
| [perspective](COMPONENTS.joy.md#perspective) | `mosaik-perspective` | 22 |
| [pinBox](COMPONENTS.joy.md#pinbox) | `mosaik-pinbox` | 34 |
| [pip](COMPONENTS.joy.md#pip) | `mosaik-pip` | 34 |
| [placeholder](COMPONENTS.joy.md#placeholder) | `mosaik-placeholder` | 27 |
| [popup](COMPONENTS.joy.md#popup) | `mosaik-popup` | 28 |
| [portal](COMPONENTS.joy.md#portal) | `mosaik-portal` | 22 |
| [portalHost](COMPONENTS.joy.md#portal-host) | `mosaik-portal-host` | 22 |
| [portalProjection](COMPONENTS.joy.md#portal-projection) | `mosaik-portal-projection` | 22 |
| [pressButton](COMPONENTS.joy.md#press-button) | `mosaik-press-button` | 44 |
| [progressBar](COMPONENTS.joy.md#progress-bar) | `mosaik-progress-bar` | 22 |
| [progressRing](COMPONENTS.joy.md#progress-ring) | `mosaik-progress-ring` | 31 |
| [promptBox](COMPONENTS.joy.md#prompt-box) | `mosaik-prompt-box` | 40 |
| [promptBoxAttachmentList](COMPONENTS.joy.md#prompt-box-attachment-list) | `mosaik-prompt-box-attachment-list` | 29 |
| [promptBoxQueue](COMPONENTS.joy.md#prompt-box-queue) | `mosaik-prompt-box-queue` | 29 |
| [promptBoxVoiceRecorderTool](COMPONENTS.joy.md#prompt-box-voice-recorder-tool) | `mosaik-prompt-box-voice-recorder-tool` | 22 |
| [pulse](COMPONENTS.joy.md#pulse) | `mosaik-pulse` | 18 |
| [qrCode](COMPONENTS.joy.md#qrcode) | `mosaik-qrcode` | 24 |
| [radio](COMPONENTS.joy.md#radio) | `mosaik-radio` | 28 |
| [radioGroup](COMPONENTS.joy.md#radio-group) | `mosaik-radio-group` | 28 |
| [rating](COMPONENTS.joy.md#rating) | `mosaik-rating` | 28 |
| [region](COMPONENTS.joy.md#region) | `mosaik-region` | 22 |
| [regionView](COMPONENTS.joy.md#region-view) | `mosaik-region-view` | 22 |
| [repeatButton](COMPONENTS.joy.md#repeat-button) | `mosaik-repeat-button` | 43 |
| [resize](COMPONENTS.joy.md#resize) | `mosaik-resize` | 22 |
| [resizeAdorner](COMPONENTS.joy.md#resize-adorner) | `mosaik-resize-adorner` | 28 |
| [resizeThumb](COMPONENTS.joy.md#resize-thumb) | `mosaik-resize-thumb` | 28 |
| [reveal](COMPONENTS.joy.md#reveal) | `mosaik-reveal` | 20 |
| [ribbon](COMPONENTS.joy.md#ribbon) | `mosaik-ribbon` | 30 |
| [richTextBox](COMPONENTS.joy.md#richtextbox) | `mosaik-richtextbox` | 70 |
| [richTextBoxToolbox](COMPONENTS.joy.md#richtextbox-toolbox) | `mosaik-richtextbox-toolbox` | 34 |
| [ripple](COMPONENTS.joy.md#ripple) | `mosaik-ripple` | 23 |
| [router](COMPONENTS.joy.md#router) | `mosaik-router` | 22 |
| [routerAnchor](COMPONENTS.joy.md#router-anchor) | `mosaik-router-anchor` | 25 |
| [routerLink](COMPONENTS.joy.md#router-link) | `mosaik-router-link` | 22 |
| [routerOutlet](COMPONENTS.joy.md#router-outlet) | `mosaik-router-outlet` | 22 |
| [scale](COMPONENTS.joy.md#scale) | `mosaik-scale` | 22 |
| [scheduler](COMPONENTS.joy.md#scheduler) | `mosaik-scheduler` | 73 |
| [schedulerAgendaView](COMPONENTS.joy.md#scheduler-agenda-view) | `mosaik-scheduler-agenda-view` | 40 |
| [schedulerDatescale](COMPONENTS.joy.md#scheduler-datescale) | `mosaik-scheduler-datescale` | 41 |
| [schedulerEvent](COMPONENTS.joy.md#scheduler-event) | `mosaik-scheduler-event` | 54 |
| [schedulerMonthView](COMPONENTS.joy.md#scheduler-month-view) | `mosaik-scheduler-month-view` | 58 |
| [schedulerNowIndicator](COMPONENTS.joy.md#scheduler-now-indicator) | `mosaik-scheduler-now-indicator` | 25 |
| [schedulerTimeGridView](COMPONENTS.joy.md#scheduler-time-grid-view) | `mosaik-scheduler-time-grid-view` | 67 |
| [schedulerTimelineView](COMPONENTS.joy.md#scheduler-timeline-view) | `mosaik-scheduler-timeline-view` | 66 |
| [schedulerTimescale](COMPONENTS.joy.md#scheduler-timescale) | `mosaik-scheduler-timescale` | 34 |
| [scroll](COMPONENTS.joy.md#scroll) | `mosaik-scroll` | 24 |
| [scrubSlider](COMPONENTS.joy.md#scrub-slider) | `mosaik-scrub-slider` | 64 |
| [searchBox](COMPONENTS.joy.md#searchbox) | `mosaik-searchbox` | 34 |
| [segment](COMPONENTS.joy.md#segment) | `mosaik-segment` | 36 |
| [segmentBar](COMPONENTS.joy.md#segment-bar) | `mosaik-segment-bar` | 25 |
| [segmentItem](COMPONENTS.joy.md#segment-item) | `mosaik-segment-item` | 34 |
| [segmentLegend](COMPONENTS.joy.md#segment-legend) | `mosaik-segment-legend` | 22 |
| [segmentLegendItem](COMPONENTS.joy.md#segment-legend-item) | `mosaik-segment-legend-item` | 25 |
| [segmentRing](COMPONENTS.joy.md#segment-ring) | `mosaik-segment-ring` | 25 |
| [select](COMPONENTS.joy.md#select) | `mosaik-select` | 36 |
| [selectItem](COMPONENTS.joy.md#select-item) | `mosaik-select-item` | 34 |
| [selectItemGroup](COMPONENTS.joy.md#select-item-group) | `mosaik-select-item-group` | 39 |
| [selectItemVisual](COMPONENTS.joy.md#select-item-visual) | `mosaik-select-item-visual` | 22 |
| [sheet](COMPONENTS.joy.md#sheet) | `mosaik-sheet` | 41 |
| [sheetContent](COMPONENTS.joy.md#sheet-content) | `mosaik-sheet-content` | 22 |
| [sheetFooter](COMPONENTS.joy.md#sheet-footer) | `mosaik-sheet-footer` | 22 |
| [sheetHeader](COMPONENTS.joy.md#sheet-header) | `mosaik-sheet-header` | 22 |
| [sheetHeaderSubText](COMPONENTS.joy.md#sheet-header-sub-text) | `mosaik-sheet-header-sub-text` | 25 |
| [sheetHeaderText](COMPONENTS.joy.md#sheet-header-text) | `mosaik-sheet-header-text` | 25 |
| [signaturePad](COMPONENTS.joy.md#signaturepad) | `mosaik-signaturepad` | 33 |
| [skeleton](COMPONENTS.joy.md#skeleton) | `mosaik-skeleton` | 29 |
| [slider](COMPONENTS.joy.md#slider) | `mosaik-slider` | 65 |
| [slider2](COMPONENTS.joy.md#slider2) | `mosaik-slider2` | 22 |
| [slider2Thumb](COMPONENTS.joy.md#slider2-thumb) | `mosaik-slider2-thumb` | 23 |
| [spacer](COMPONENTS.joy.md#spacer) | `mosaik-spacer` | 22 |
| [spline](COMPONENTS.joy.md#spline) | `mosaik-spline` | 20 |
| [split](COMPONENTS.joy.md#split) | `mosaik-split` | 30 |
| [splitButton](COMPONENTS.joy.md#split-button) | `mosaik-split-button` | 43 |
| [stack](COMPONENTS.joy.md#stack) | `mosaik-stack` | 22 |
| [stepper](COMPONENTS.joy.md#stepper) | `mosaik-stepper` | 40 |
| [stepperItem](COMPONENTS.joy.md#stepper-item) | `mosaik-stepper-item` | 25 |
| [sticky](COMPONENTS.joy.md#sticky) | `mosaik-sticky` | 24 |
| [successState](COMPONENTS.joy.md#success-state) | `mosaik-success-state` | 29 |
| [suggestionMenu](COMPONENTS.joy.md#suggestion-menu) | `mosaik-suggestion-menu` | 25 |
| [summary](COMPONENTS.joy.md#summary) | `mosaik-summary` | 22 |
| [swipe](COMPONENTS.joy.md#swipe) | `mosaik-swipe` | 22 |
| [tab](COMPONENTS.joy.md#tab) | `mosaik-tab` | 36 |
| [tabItem](COMPONENTS.joy.md#tab-item) | `mosaik-tab-item` | 25 |
| [tabPanel](COMPONENTS.joy.md#tab-panel) | `mosaik-tab-panel` | 23 |
| [tabStrip](COMPONENTS.joy.md#tab-strip) | `mosaik-tab-strip` | 28 |
| [tabStripItem](COMPONENTS.joy.md#tab-strip-item) | `mosaik-tab-strip-item` | 36 |
| [table](COMPONENTS.joy.md#table) | `mosaik-table` | 38 |
| [tableBody](COMPONENTS.joy.md#table-body) | `mosaik-table-body` | 28 |
| [tableBodyCell](COMPONENTS.joy.md#table-body-cell) | `mosaik-table-body-cell` | 28 |
| [tableBodyRow](COMPONENTS.joy.md#table-body-row) | `mosaik-table-body-row` | 27 |
| [tableColumnEditor](COMPONENTS.joy.md#table-column-editor) | `mosaik-table-column-editor` | 32 |
| [tableFooter](COMPONENTS.joy.md#table-footer) | `mosaik-table-footer` | 28 |
| [tableFooterCell](COMPONENTS.joy.md#table-footer-cell) | `mosaik-table-footer-cell` | 27 |
| [tableFooterRow](COMPONENTS.joy.md#table-footer-row) | `mosaik-table-footer-row` | 28 |
| [tableHeader](COMPONENTS.joy.md#table-header) | `mosaik-table-header` | 28 |
| [tableHeaderCell](COMPONENTS.joy.md#table-header-cell) | `mosaik-table-header-cell` | 31 |
| [tableHeaderRow](COMPONENTS.joy.md#table-header-row) | `mosaik-table-header-row` | 28 |
| [text](COMPONENTS.joy.md#text) | `mosaik-text` | 34 |
| [textBox](COMPONENTS.joy.md#textbox) | `mosaik-textbox` | 67 |
| [textEffect](COMPONENTS.joy.md#text-effect) | `mosaik-text-effect` | 19 |
| [textFormat](COMPONENTS.joy.md#text-format) | `mosaik-text-format` | 22 |
| [thumb](COMPONENTS.joy.md#thumb) | `mosaik-thumb` | 27 |
| [thumbnail](COMPONENTS.joy.md#thumbnail) | `mosaik-thumbnail` | 23 |
| [tickBar](COMPONENTS.joy.md#tick-bar) | `mosaik-tick-bar` | 32 |
| [tile](COMPONENTS.joy.md#tile) | `mosaik-tile` | 34 |
| [tileList](COMPONENTS.joy.md#tile-list) | `mosaik-tile-list` | 23 |
| [tileListItem](COMPONENTS.joy.md#tile-list-item) | `mosaik-tile-list-item` | 29 |
| [tileManager](COMPONENTS.joy.md#tile-manager) | `mosaik-tile-manager` | 23 |
| [tileManagerTile](COMPONENTS.joy.md#tile-manager-tile) | `mosaik-tile-manager-tile` | 52 |
| [timeBox](COMPONENTS.joy.md#timebox) | `mosaik-timebox` | 41 |
| [timeline](COMPONENTS.joy.md#timeline) | `mosaik-timeline` | 31 |
| [timelineContent](COMPONENTS.joy.md#timeline-content) | `mosaik-timeline-content` | 23 |
| [timelineItem](COMPONENTS.joy.md#timeline-item) | `mosaik-timeline-item` | 30 |
| [timelineMarker](COMPONENTS.joy.md#timeline-marker) | `mosaik-timeline-marker` | 27 |
| [timelineOpposite](COMPONENTS.joy.md#timeline-opposite) | `mosaik-timeline-opposite` | 23 |
| [timelineSeparator](COMPONENTS.joy.md#timeline-separator) | `mosaik-timeline-separator` | 25 |
| [titleBar](COMPONENTS.joy.md#title-bar) | `mosaik-title-bar` | 22 |
| [titleLayout](COMPONENTS.joy.md#title-layout) | `mosaik-title-layout` | 23 |
| [toast](COMPONENTS.joy.md#toast) | `mosaik-toast` | 42 |
| [toastActions](COMPONENTS.joy.md#toast-actions) | `mosaik-toast-actions` | 22 |
| [toggleButton](COMPONENTS.joy.md#toggle-button) | `mosaik-toggle-button` | 42 |
| [toggleButtonGroup](COMPONENTS.joy.md#toggle-button-group) | `mosaik-toggle-button-group` | 28 |
| [toggleSwitch](COMPONENTS.joy.md#toggle-switch) | `mosaik-toggle-switch` | 27 |
| [toggletip](COMPONENTS.joy.md#toggletip) | `mosaik-toggletip` | 24 |
| [toolbar](COMPONENTS.joy.md#toolbar) | `mosaik-toolbar` | 30 |
| [tooltip](COMPONENTS.joy.md#tooltip) | `mosaik-tooltip` | 29 |
| [tour](COMPONENTS.joy.md#tour) | `mosaik-tour` | 30 |
| [tourAnchor](COMPONENTS.joy.md#tour-anchor) | `mosaik-tour-anchor` | 24 |
| [tourNav](COMPONENTS.joy.md#tour-nav) | `mosaik-tour-nav` | 31 |
| [tourStep](COMPONENTS.joy.md#tour-step) | `mosaik-tour-step` | 34 |
| [tree](COMPONENTS.joy.md#tree) | `mosaik-tree` | 22 |
| [treeItem](COMPONENTS.joy.md#tree-item) | `mosaik-tree-item` | 31 |
| [upDownSpinner](COMPONENTS.joy.md#updown-spinner) | `mosaik-updown-spinner` | 22 |
| [video](COMPONENTS.joy.md#video) | `mosaik-video` | 36 |
| [virtualize](COMPONENTS.joy.md#virtualize) | `mosaik-virtualize` | 22 |
| [walletCard](COMPONENTS.joy.md#wallet-card) | `mosaik-wallet-card` | 53 |
| [wheelPicker](COMPONENTS.joy.md#wheel-picker) | `mosaik-wheel-picker` | 29 |
| [wizard](COMPONENTS.joy.md#wizard) | `mosaik-wizard` | 23 |
| [wizardStep](COMPONENTS.joy.md#wizard-step) | `mosaik-wizard-step` | 22 |
| [wrap](COMPONENTS.joy.md#wrap) | `mosaik-wrap` | 22 |
<!-- /design-md:component-index -->

## Do's and Don'ts

### Do

- Consume `--mosaik-*` custom properties for anything you paint yourself; never copy a literal
  from this file into markup or CSS.
- Change a value in `libs/mosaik-themes/tokens/`, not in a component stylesheet, and add a new
  token to all three themes at once.
- Style through props (`variant`, `appearance`, `size`, `elevation`) and, when that is not enough,
  through the documented `--<prefix>-<token>` properties and `::part()`.
- Keep the warm canvas: pages on `background`, raised panels on `surface`, boundaries with
  `highlight`.
- Reserve `solid` for the one primary action of a view and `soft` or `outline` for the rest.
- Load Nunito on every page that renders Joy.

### Don't

- Don't hard-code a color, spacing, radius, border or shadow.
- Don't rename or add typography roles, and don't create mode-specific token names.
- Don't pass numbers to `size` or `elevation`; they are names and fail silently otherwise.
- Don't mix corner radii in one view or sharpen individual controls; the 12px radius is the identity.
- Don't set headlines in bold; Joy headlines are light and regular, weight is for buttons.
- Don't uppercase labels; no Joy role transforms text.
- Don't put text on a `soft` fill except inside a chip, badge or button.

### Named anti-patterns

- **Pure white card grid**: white cards with gray hairlines on a white page. Joy surfaces are
  `#f5f5f5` and `#eaeaea`, cards separate by a `highlight` border and a `light` shadow.
- **Heavy elevation**: stacked `bold` shadows on resting content. Joy rests at `light` and
  `semilight`.
- **Framework theme leakage**: Material or Bootstrap class names, blue `#1976d2` primaries,
  4px radii. Joy's primary is pink and its radius is 12px.
- **Uppercase overlines and tracked-out buttons** copied from other systems.

## Known gaps

Generated from the same sources as the tables above; a finding here is a finding about the theme,
not about this document.

<!-- design-md:gaps -->

### Theme references that resolve to nothing (0)

Component tokens pointing at theme properties that neither the compiled stylesheet nor `ThemeService` declares. The property is empty at runtime and the browser falls back to its initial value.

_none_

### References into other components (3)

These resolve only when the referenced component provides the property at runtime (a list item inside a list, a thumb inside a slider). Outside that context they are empty.

`--avatar-font-size` (1), `--data-table-cell-height` (1), `--pulse-ring-color` (1)

### Stylesheet properties the reference theme declares and this one does not (0 families)

Compared between the compiled `<theme>-style()` stylesheets; Joy is the reference theme, and Joy itself is compared against the names Memphis and Cosmopolitan agree on. With a `Theme2` / `provideTheme()` provider `ThemeService` writes these names from the theme object anyway; a page that loads only the stylesheet has them empty.

_none_

### Token files without a consuming component

`tokens/themes/joy/components/accordion.json`, `tokens/themes/joy/components/alert.json`, `tokens/themes/joy/components/cardStack.json`, `tokens/themes/joy/components/dotGroup.json`, `tokens/themes/joy/components/gaugeInset.json`, `tokens/themes/joy/components/numberTicker.json`, `tokens/themes/joy/components/orbit.json`, `tokens/themes/joy/components/pulse.json`, `tokens/themes/joy/components/router.json`, `tokens/themes/joy/components/routerAnchor.json`, `tokens/themes/joy/components/routerLink.json`, `tokens/themes/joy/components/routerOutlet.json`, `tokens/themes/joy/components/slider2Thumb.json`, `tokens/themes/joy/components/textEffect.json` define tokens no foundation component reads through its theme stylesheet.

### Token files consumed by more than one component

`tokens/themes/joy/components/text.json` is read by 2 components; the export uses the `mosaik-text` prefix.

### Token files that feed the same custom property prefix

_none_

### Enum tokens missing from the theme file

_none_
<!-- /design-md:gaps -->

## Sources

| What                       | Where                                                                                           |
| -------------------------- | ----------------------------------------------------------------------------------------------- |
| Global tokens              | `libs/mosaik-themes/tokens/themes/joy/joy.json`, `tokens/themes/tokens.json`                    |
| Component tokens           | `libs/mosaik-themes/tokens/themes/joy/components/*.json`, mixins in `tokens/mixins/`           |
| Component anatomy          | `libs/mosaik-elements-foundation/src/controls/components/**/themes/*.Joy.scss`                 |
| Compiled tokens            | `libs/mosaik-themes/dist/themes/___joy-tokens.css`, `dist/themes/joy.scss` (`joy-style()`)     |
| Runtime aliases            | `libs/mosaik-elements-foundation/src/theming/ThemeService.ts`                                   |
| Token model                | `.docs/design/tokens.md`, `.docs/design/tokens/1.token-schema-reference.md`                     |
| Motion                     | `.docs/design/animations.md`                                                                    |
| Component reference        | `apps/frontend/mosaik-showcase/public/llms/mosaik-<tag>.md`                                     |
| Regenerate                 | `yarn nx run mosaik-themes:build && yarn nx run mosaik-themes:design-md`                        |
| Verify                     | `yarn nx run mosaik-themes:design-md:check`                                                     |
