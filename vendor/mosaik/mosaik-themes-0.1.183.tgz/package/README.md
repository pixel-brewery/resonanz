# 📦 @pixel-brewery/mosaik-themes

| Package Status | Source |
|----------------|--------|
| [![GitHub Packages](https://img.shields.io/github/v/release/RueDeRennes/mosaik?label=GitHub%20Packages&logo=github)](https://github.com/orgs/pixel-brewery/packages/npm/package/mosaik-themes) | [libs/mosaik-themes](../../libs/mosaik-themes) |

> Theme tokens and style definitions for the Mosaik design system.
> Provides SCSS, CSS, and design tokens for all supported themes.

---

## 📁 Project Structure

Part of the monorepo [`mosaik`](https://github.com/RueDeRennes/mosaik)  
Package path: `libs/mosaik-themes`  
Version: see [GitHub Packages](https://github.com/orgs/pixel-brewery/packages/npm/package/mosaik-themes)  
License: MIT

---

## 📦 Installation

```bash
yarn add @pixel-brewery/mosaik-themes
# or
npm install @pixel-brewery/mosaik-themes
```

---

## 🔧 Usage

```typescript
import * as Themes from '@pixel-brewery/mosaik-themes';
```

Or import SCSS bundles:

```scss
@use '@pixel-brewery/mosaik-themes/scss' as themes;
```

---

## 🎨 Theme Catalog

Mosaik ships exactly three themes. They share one token vocabulary (the same `--mosaik-*` names)
and differ in the values and in the component anatomy of their theme stylesheets. Each theme has a
design document in the [DESIGN.md format](https://github.com/google-labs-code/design.md) and a
complete component token export, see `design/README.md`.

### Joy — the default

- **Visual identity:** Soft and friendly. 12px radius, 8px rhythm, 2px strokes, Nunito, a warm
  neutral canvas (`#eaeaea` / `#f5f5f5`) with a pink primary, single soft shadows and ripple
  feedback.
- **Best for:** Customer-facing portals, lifestyle services, anything that should feel approachable.
- **Documents:** `design/joy/DESIGN.joy.md`, `design/joy/COMPONENTS.joy.md`

### Memphis

- **Visual identity:** Paper cut-outs. No radius, 10px rhythm, 3px ink borders, offset shadows
  without blur that lift on hover and press flat on click. Same palette and type as Joy.
- **Best for:** Creative tools, entertainment and brand experiences that want energy and contrast.
- **Documents:** `design/memphis/DESIGN.memphis.md`, `design/memphis/COMPONENTS.memphis.md`

### Cosmopolitan

- **Visual identity:** White on white. 3px radius, 8px rhythm, 1px hairlines, Noto Sans, two-layer
  ambient shadows, an uppercase button role. The global tokens are complete; the component anatomy
  and the headline scale are still provisional (see the Known gaps in its design document).
- **Best for:** Editorial and premium content once the anatomy is finished.
- **Documents:** `design/cosmopolitan/DESIGN.cosmopolitan.md`, `design/cosmopolitan/COMPONENTS.cosmopolitan.md`

### Soho

Soho — Mosaik-Theme auf Basis der visuellen Referenzen von shadcn/ui.

- **Visual identity:** shadcn/ui (style `new-york`, base colour Neutral, `new-york-v4` at `shadcn-ui/ui@a2e305c`) in the
  Mosaik architecture: white and near-black, Geist, a 10px radius with the shadcn radius steps, 1px borders,
  `text-sm` controls, small soft shadows and the 3px focus ring at half the ring colour. Colours come from the
  Mosaik theme variables (Neutral by default, every colour scheme applies); icons use the `reicon` set.
- **Best for:** Product UIs, dashboards and developer tools that want the familiar shadcn/ui look.
- **Documents:** `design/soho/DESIGN.soho.md`, `design/soho/COMPONENTS.soho.md`

### Regenerating the design documents

```bash
yarn nx run mosaik-themes:build             # dist/ is required; also exports dist/design/<theme>/model.json
yarn nx run mosaik-themes:design-md         # rewrite frontmatter, generated regions and COMPONENTS.md
yarn nx run mosaik-themes:design-md:check   # fail when stale or when the format lints with errors
```

### Design documents for products built on Mosaik

The package ships the generator as the `mosaik-design-md` bin together with a model of each theme.
A product keeps its `tools/design-md.config.json` (base theme plus the `provideTheme()` / `Theme2`
overrides) and runs `mosaik-design-md generate` to get a `DESIGN.md` and `COMPONENTS.md` with the
values it actually renders. See `design/README.md` for the configuration and the
migration of an existing product.

---

## 🛠 Recommendations

- Combine the theme tokens with any Mosaik component library to guarantee consistent visuals.
- Import SCSS or CSS bundles once at the root of your application and switch themes by toggling the exported CSS custom properties.
- Use the generated design tokens in Figma or other tooling to align designers and engineers.

---

## 📦 Publishing

```bash
yarn nx run mosaik-themes:publish
```

---

## 📄 License

MIT © Pixel Brewery

---
