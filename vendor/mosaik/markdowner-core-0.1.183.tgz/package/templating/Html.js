/**
 * @internal
 */
export function html(strings, ...values) {
    return strings.reduce((result, str, i) => {
        const value = values[i];
        // eslint-disable-next-line @typescript-eslint/restrict-plus-operands, @typescript-eslint/no-base-to-string
        return (result + str + (value != null ? value : '')).trim();
    }, '').trim();
}
//# sourceMappingURL=Html.js.map