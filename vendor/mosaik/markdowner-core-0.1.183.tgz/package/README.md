# 📦 @pixel-brewery/markdowner-core

| Package Status | Source |
|----------------|--------|
| [![GitHub Packages](https://img.shields.io/github/v/release/RueDeRennes/mosaik?label=GitHub%20Packages&logo=github)](https://github.com/orgs/pixel-brewery/packages/npm/package/markdowner-core) | [tools/markdowner/core](../../tools/markdowner/core) |

> Core library for parsing and rendering Markdown with custom extensions.
> Provides extensible Markdown processing for documentation and content workflows.

---

## 📁 Project Structure

Part of the monorepo [`mosaik`](https://github.com/RueDeRennes/mosaik)
Package path: `tools/markdowner/core`
Version: see [GitHub Packages](https://github.com/orgs/pixel-brewery/packages/npm/package/markdowner-core)
License: MIT

---

## 📦 Installation

```bash
yarn add @pixel-brewery/markdowner-core
# or
npm install @pixel-brewery/markdowner-core
```

---

## 🔧 Usage

```typescript
import { MarkdownProcessor } from '@pixel-brewery/markdowner-core';

const html = new MarkdownProcessor().process('# Hello World');
console.log(html);
```

---

## ⚙️ Features

- Extensible Markdown processor
- Custom Markdown extensions (tabs, callouts, etc.)
- Integration with [marked](https://github.com/markedjs/marked)
- TypeScript-first, modern codebase

---

## 🛠 Recommendations

- Use as the core for documentation sites or static site generators.
- Extend with your own Markdown processors for custom needs.

---

## 📦 Publishing

Build the package with `yarn nx run markdowner-core:build`. The build compiles without incremental cache into a
fresh staging directory and replaces the previous output, then validates package entry points and their explicit
relative JavaScript imports with exact path casing. This prevents stale directory names on case-insensitive build machines from producing
packages that fail to load on Linux. The prepared package lives in `dist/`.

```bash
yarn nx run markdowner-core:publish
```

---

## 📄 License

MIT © Pixel Brewery

---
