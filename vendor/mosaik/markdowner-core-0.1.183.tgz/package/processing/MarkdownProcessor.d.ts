import { type MarkedOptions } from 'marked';
import type { IProcessor } from './processors/interfaces/IProcessor.js';
/**
 * Main processor for Markdown content.
 * Orchestrates processors and integrates them with `marked`.
 *
 * @public
 */
export declare class MarkdownProcessor {
    private _processors;
    /**
     * Constructs a new MarkdownProcessor.
     */
    constructor(processors?: Array<IProcessor>);
    /**
     * Adds a custom processor to the manager.
     *
     * @public
     * @param processor The processor to add.
     */
    addProcessor(processor: IProcessor): void;
    /**
     * Removes a custom processor from the manager.
     *
     * @public
     * @param processor The processor to remove.
     */
    removeProcessor(processor: IProcessor): void;
    /**
     * Processes Markdown content into HTML.
     *
     * @public
     * @param markdown The Markdown content to process.
     * @returns The resulting HTML string.
     */
    process(markdown: string, options?: Omit<MarkedOptions, 'async'>): string;
    /**
     * Processes Markdown content into HTML asynchronously.
     *
     * @public
     * @param markdown The Markdown content to process.
     * @returns A promise that resolves to the resulting HTML string.
     */
    processAsync(markdown: string, options?: Omit<MarkedOptions, 'async'>): Promise<string>;
}
//# sourceMappingURL=MarkdownProcessor.d.ts.map