// #region Imports
import { html } from '../../templating/Html.js';
import { BaseProcessor } from './abstracts/BaseProcessor.js';
const KNOWN_VARIANTS = new Set([
    'primary', 'secondary', 'tertiary',
    'info', 'warning', 'danger', 'error',
    'success', 'highlight', 'neutral'
]);
/**
 * A processor that transforms `:::tabs` blocks into tabbed layout structures.
 * Each tab may include a title, content, and an optional variant using `[!TYPE]`.
 *
 * Supported variants: `primary`, `secondary`, `tertiary`, `info`, `warning`, `danger`, `error`, `success`, `highlight`, `neutral`.
 *
 * @example
 * ```markdown
 * ::: tabs
 * ::: tab Tab 1
 * [!INFO]
 * Content for the first tab.
 * ::: end-tab
 *
 * ::: tab Tab 2
 * [!WARNING]
 * Content for the second tab.
 * ::: end-tab
 * ::: end-tabs
 * ```
 *
 * @public
 */
export class TabProcessor extends BaseProcessor {
    get extension() {
        return {
            name: 'tabs',
            level: 'block',
            start(src) {
                return (/^::: tabs/).exec(src)?.index;
            },
            tokenizer(src) {
                return TabTokenizer.tokenize(this.lexer, src);
            },
            renderer(token) {
                return TabRenderer.render(this.parser, token);
            },
            childTokens: ['tabs']
        };
    }
}
/**
 * @private
 */
class TabTokenizer {
    static tokenize(lexer, src) {
        const match = (/^::: tabs\n([\s\S]+?)\n::: end-tabs/).exec(src);
        if (!match) {
            return undefined;
        }
        const tabRegex = /^::: tab (.+?)\n([\s\S]+?)\n::: end-tab/gm;
        const tabs = [];
        let tabMatch = null;
        let index = 0;
        while ((tabMatch = tabRegex.exec(match[1])) !== null) {
            const rawLines = tabMatch[2].trim().split('\n');
            let variant = undefined;
            const variantMatch = (/^\[\!(\w+)\]/).exec(rawLines[0]);
            if (variantMatch) {
                const v = variantMatch[1].toLowerCase();
                if (KNOWN_VARIANTS.has(v)) {
                    variant = v;
                    rawLines.shift(); // Remove variant line
                }
            }
            const content = rawLines.join('\n').trim();
            const tokens = lexer.blockTokens(content);
            tabs.push({
                type: 'tab',
                raw: tabMatch[0],
                tokens,
                id: `tab-${index++}`,
                title: tabMatch[1].trim(),
                content,
                variant
            });
        }
        return {
            type: 'tabs',
            raw: match[0],
            tabs: tabs
        };
    }
}
/**
 * @private
 */
class TabRenderer {
    static render(parser, token) {
        return html `
            <div class="tabs">
                <ul class="tab-list">
                    ${token.tabs.map((tab) => `
                    <li class="tab-item${tab.variant ? ` ${tab.variant}` : ''}" data-tab="${tab.id}">${tab.title}
                    </li>`).join('')}
                </ul>
            ${token.tabs.map((tab) => `
                <div class="tab-content${tab.variant ? ` ${tab.variant}` : ''}" id="${tab.id}">${parser.parse(tab.tokens ?? [])}
                </div>`).join('')}
            </div>
        `.trim();
    }
}
//# sourceMappingURL=TabProcessor.js.map