import type { TokenizerAndRendererExtension, Tokens } from 'marked';
import { BaseProcessor } from './abstracts/BaseProcessor.js';
export interface ICodeBlockToken extends Tokens.Generic {
    type: 'code';
    raw: string;
    text: string;
    lang?: string;
    meta?: {
        lang: string;
        fileName?: string;
        highlights?: string;
    };
}
/**
 * A processor that transforms fenced code blocks with extended metadata
 * (language, filename, highlighted lines).
 *
 * Example:
 * ```ts name="example.ts" {1,3-4}
 * const foo = 42;
 * const bar = 7;
 * ```
 *
 * This will extract:
 * - language: "ts"
 * - filename: "example.ts"
 * - highlights: "1,3-4"
 *
 * @public
 */
export declare class CodeBlockProcessor extends BaseProcessor {
    get extension(): TokenizerAndRendererExtension;
    walkTokens(token: Tokens.Generic): void;
}
//# sourceMappingURL=CodeBlockProcessor.d.ts.map