// #region Imports
import { BaseProcessor } from './abstracts/BaseProcessor.js';
const KNOWN_VARIANTS = new Set([
    'primary', 'secondary', 'tertiary',
    'info', 'warning', 'danger', 'error',
    'success', 'highlight', 'neutral'
]);
const KNOWN_APPEARANCES = new Set([
    'solid', 'soft', 'plain'
]);
/**
 * A processor that transforms `:::button` blocks into clickable button elements.
 *
 * @example
 * ```markdown
 * ::: button Get Started | /getStarted | primary | soft
 * :::
 *
 * ::: button Learn More | /docs
 * :::
 * ```
 *
 * Format: `::: button Label | href | variant | appearance`
 * - `Label` (required): The button text
 * - `href` (optional): The link target, defaults to `#`
 * - `variant` (optional): One of the known variants, defaults to `primary`
 * - `appearance` (optional): One of `solid`, `soft`, `plain`, defaults to `solid`
 *
 * @public
 */
export class ButtonProcessor extends BaseProcessor {
    get extension() {
        return {
            name: 'md_button',
            level: 'block',
            start(src) {
                return (/^::: button /).exec(src)?.index;
            },
            tokenizer(src) {
                return ButtonTokenizer.tokenize(src);
            },
            renderer(token) {
                return ButtonRenderer.render(token);
            }
        };
    }
}
/**
 * @private
 */
class ButtonTokenizer {
    static tokenize(src) {
        const match = (/^::: button (.+?)\n:::/).exec(src);
        if (!match) {
            return undefined;
        }
        const parts = match[1].split('|').map((s) => s.trim());
        const label = parts[0] ?? 'Button';
        const href = parts[1] ?? '#';
        const rawVariant = (parts[2] ?? 'primary').toLowerCase();
        const rawAppearance = (parts[3] ?? 'solid').toLowerCase();
        return {
            type: 'md_button',
            raw: match[0],
            label,
            href,
            variant: KNOWN_VARIANTS.has(rawVariant) ? rawVariant : 'primary',
            appearance: KNOWN_APPEARANCES.has(rawAppearance) ? rawAppearance : 'solid'
        };
    }
}
/**
 * @private
 */
class ButtonRenderer {
    static render(token) {
        return `<a class="md-button ${token.variant} ${token.appearance}" href="${token.href}">${token.label}</a>`;
    }
}
//# sourceMappingURL=ButtonProcessor.js.map