import type { TokenizerAndRendererExtension, Tokens } from 'marked';
import { BaseProcessor } from './abstracts/BaseProcessor.js';
type SplitVariant = 'primary' | 'secondary' | 'tertiary' | 'info' | 'warning' | 'danger' | 'error' | 'success' | 'highlight' | 'neutral';
export interface ISplitsToken extends Tokens.Generic {
    type: 'splits';
    raw: string;
    splits: Array<ISplitToken>;
}
export interface ISplitToken extends Tokens.Generic {
    type: 'split';
    id: string;
    title: Array<Tokens.Generic>;
    tokens: Array<Tokens.Generic>;
    variant?: SplitVariant;
}
/**
 * A processor that transforms `:::split` blocks into a two-column layout.
 * Each column may include a heading, a list, and an optional variant like `[!INFO]`.
 *
 * Supported variants: `primary`, `secondary`, `tertiary`, `info`, `warning`, `danger`, `error`, `success`, `highlight`, `neutral`.
 *
 * @example
 * ```markdown
 * ::: splits
 * ::: split Split 1
 * [!INFO]
 * - Split 1 point a
 * - Split 1 point b
 * - Split 1 point c
 * ::: end-split
 *
 * ::: split Split 2
 * [!ERROR]
 * - Split 2 point a
 * - Split 2 point b
 * - Split 2 point c
 * ::: end-split
 * ::: end-splits
 * ```
 *
 * @public
 */
export declare class SplitProcessor extends BaseProcessor {
    get extension(): TokenizerAndRendererExtension;
}
export {};
//# sourceMappingURL=SplitProcessor.d.ts.map