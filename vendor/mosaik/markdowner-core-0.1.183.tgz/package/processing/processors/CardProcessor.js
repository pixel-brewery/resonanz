// #region Imports
import { html } from '../../templating/Html.js';
import { BaseProcessor } from './abstracts/BaseProcessor.js';
const KNOWN_VARIANTS = new Set([
    'primary', 'secondary', 'tertiary',
    'info', 'warning', 'danger', 'error',
    'success', 'highlight', 'neutral'
]);
/**
 * A processor that transforms `:::card` blocks into card layout elements.
 *
 * @example
 * ```markdown
 * ::: card Joy Theme | Warm and playful | primary
 * The Joy theme uses magenta accents with high-contrast surfaces.
 * Perfect for consumer-facing applications.
 * ::: end-card
 *
 * ::: card Memphis Theme | Bold and geometric
 * Pastel-geometric palette for playful interfaces.
 * ::: end-card
 * ```
 *
 * Format: `::: card Header | Sub-Header | variant`
 * - `Header` (required): The card title
 * - `Sub-Header` (optional): A sub-heading
 * - `variant` (optional): One of the known variants, defaults to `neutral`
 *
 * @public
 */
export class CardProcessor extends BaseProcessor {
    get extension() {
        return {
            name: 'md_card',
            level: 'block',
            start(src) {
                return (/^::: card /).exec(src)?.index;
            },
            tokenizer(src) {
                return CardTokenizer.tokenize(this.lexer, src);
            },
            renderer(token) {
                return CardRenderer.render(this.parser, token);
            },
            childTokens: ['tokens']
        };
    }
}
/**
 * @private
 */
class CardTokenizer {
    static tokenize(lexer, src) {
        const match = (/^::: card (.+?)\n([\s\S]+?)\n::: end-card/).exec(src);
        if (!match) {
            return undefined;
        }
        const headerLine = match[1].trim();
        const parts = headerLine.split('|').map((s) => s.trim());
        const header = parts[0] ?? 'Card';
        const subHeader = parts[1] ?? '';
        const rawVariant = (parts[2] ?? 'neutral').toLowerCase();
        const variant = KNOWN_VARIANTS.has(rawVariant) ? rawVariant : 'neutral';
        const content = match[2].trim();
        const tokens = lexer.blockTokens(content);
        return {
            type: 'md_card',
            raw: match[0],
            header,
            subHeader,
            variant,
            tokens,
            content
        };
    }
}
/**
 * @private
 */
class CardRenderer {
    static render(parser, token) {
        const subHeaderHtml = token.subHeader
            ? `<p class="card-sub-header">${token.subHeader}</p>`
            : '';
        return html `
            <div class="md-card ${token.variant}">
                <div class="card-header">
                    <h6>${token.header}</h6>
                    ${subHeaderHtml}
                </div>
                <div class="card-content">${parser.parse(token.tokens ?? [])}</div>
            </div>
        `.trim();
    }
}
//# sourceMappingURL=CardProcessor.js.map