import type { TokenizerAndRendererExtension, Tokens } from 'marked';
import { BaseProcessor } from './abstracts/BaseProcessor.js';
type ButtonVariant = 'primary' | 'secondary' | 'tertiary' | 'info' | 'warning' | 'danger' | 'error' | 'success' | 'highlight' | 'neutral';
type ButtonAppearance = 'solid' | 'soft' | 'plain';
export interface IButtonToken extends Tokens.Generic {
    type: 'md_button';
    raw: string;
    label: string;
    href: string;
    variant: ButtonVariant;
    appearance: ButtonAppearance;
}
/**
 * A processor that transforms `:::button` blocks into clickable button elements.
 *
 * @example
 * ```markdown
 * ::: button Get Started | /getStarted | primary | soft
 * :::
 *
 * ::: button Learn More | /docs
 * :::
 * ```
 *
 * Format: `::: button Label | href | variant | appearance`
 * - `Label` (required): The button text
 * - `href` (optional): The link target, defaults to `#`
 * - `variant` (optional): One of the known variants, defaults to `primary`
 * - `appearance` (optional): One of `solid`, `soft`, `plain`, defaults to `solid`
 *
 * @public
 */
export declare class ButtonProcessor extends BaseProcessor {
    get extension(): TokenizerAndRendererExtension;
}
export {};
//# sourceMappingURL=ButtonProcessor.d.ts.map