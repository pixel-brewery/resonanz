import type { TokenizerAndRendererExtension, Tokens } from 'marked';
import { BaseProcessor } from './abstracts/BaseProcessor.js';
export interface IDetailsToken extends Tokens.Generic {
    type: 'details';
    raw: string;
    title: string;
    tokens: Array<Tokens.Generic>;
    content: string;
}
/**
 * A processor that transforms `:::details` blocks into collapsible/expandable sections.
 *
 * @example
 * ```markdown
 * ::: details What are design tokens?
 * Design tokens are the visual design atoms of the design system - specifically,
 * they are named entities that store visual design attributes such as colors,
 * typography, spacing, and more.
 * ::: end-details
 * ```
 *
 * @public
 */
export declare class DetailsProcessor extends BaseProcessor {
    get extension(): TokenizerAndRendererExtension;
}
//# sourceMappingURL=DetailsProcessor.d.ts.map