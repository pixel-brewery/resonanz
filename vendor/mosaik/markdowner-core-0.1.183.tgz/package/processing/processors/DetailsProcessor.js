// #region Imports
import { html } from '../../templating/Html.js';
import { BaseProcessor } from './abstracts/BaseProcessor.js';
/**
 * A processor that transforms `:::details` blocks into collapsible/expandable sections.
 *
 * @example
 * ```markdown
 * ::: details What are design tokens?
 * Design tokens are the visual design atoms of the design system - specifically,
 * they are named entities that store visual design attributes such as colors,
 * typography, spacing, and more.
 * ::: end-details
 * ```
 *
 * @public
 */
export class DetailsProcessor extends BaseProcessor {
    get extension() {
        return {
            name: 'details',
            level: 'block',
            start(src) {
                return (/^::: details/).exec(src)?.index;
            },
            tokenizer(src) {
                return DetailsTokenizer.tokenize(this.lexer, src);
            },
            renderer(token) {
                return DetailsRenderer.render(this.parser, token);
            },
            childTokens: ['tokens']
        };
    }
}
/**
 * @private
 */
class DetailsTokenizer {
    static tokenize(lexer, src) {
        const match = (/^::: details (.+?)\n([\s\S]+?)\n::: end-details/).exec(src);
        if (!match) {
            return undefined;
        }
        const content = match[2].trim();
        const tokens = lexer.blockTokens(content);
        return {
            type: 'details',
            raw: match[0],
            title: match[1].trim(),
            tokens,
            content
        };
    }
}
/**
 * @private
 */
class DetailsRenderer {
    static render(parser, token) {
        return html `
            <details class="details">
                <summary class="details-summary">${token.title}</summary>
                <div class="details-content">${parser.parse(token.tokens ?? [])}</div>
            </details>
        `.trim();
    }
}
//# sourceMappingURL=DetailsProcessor.js.map