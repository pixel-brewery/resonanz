import { BaseProcessor } from './abstracts/BaseProcessor.js';
/**
 * Escapes HTML special characters to prevent XSS.
 *
 * @param text - The raw text to escape.
 * @returns The escaped HTML string.
 */
function escapeHtml(text) {
    return text
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}
/**
 * A processor that transforms fenced code blocks with extended metadata
 * (language, filename, highlighted lines).
 *
 * Example:
 * ```ts name="example.ts" {1,3-4}
 * const foo = 42;
 * const bar = 7;
 * ```
 *
 * This will extract:
 * - language: "ts"
 * - filename: "example.ts"
 * - highlights: "1,3-4"
 *
 * @public
 */
export class CodeBlockProcessor extends BaseProcessor {
    get extension() {
        return {
            name: 'code',
            level: 'block',
            renderer(token) {
                return CodeBlockRenderer.render(token);
            }
        };
    }
    walkTokens(token) {
        if (token.type !== 'code') {
            return;
        }
        CodeBlockTokenizer.enrich(token);
    }
}
class CodeBlockTokenizer {
    static enrich(token) {
        const match = (/^(\w+)(?:\s+name="(.+?)")?(?:\s+\{([\d,-]+)\})?/i).exec(token.lang ?? '');
        if (!match) {
            return;
        }
        const [, lang, fileName, highlights] = match;
        token.meta = {
            lang,
            fileName,
            highlights
        };
        token.lang = lang; // override lang so PrismJS still works
    }
}
class CodeBlockRenderer {
    static render(token) {
        const lang = escapeHtml(token.meta?.lang ?? 'plaintext');
        const file = token.meta?.fileName;
        const lines = token.meta?.highlights;
        const filenameBlock = file
            ? `<div class="code-filename">${escapeHtml(file)}</div>\n`
            : '';
        const highlightAttr = lines
            ? ` data-lines="${escapeHtml(lines)}"`
            : '';
        return `${filenameBlock}<pre><code class="language-${lang}"${highlightAttr}>${escapeHtml(token.text)}</code></pre>`;
    }
}
//# sourceMappingURL=CodeBlockProcessor.js.map