import type { TokenizerAndRendererExtension, Tokens } from 'marked';
import { BaseProcessor } from './abstracts/BaseProcessor.js';
type CalloutVariant = 'primary' | 'secondary' | 'tertiary' | 'info' | 'warning' | 'danger' | 'success' | 'highlight' | 'neutral';
export interface ICalloutToken extends Tokens.Generic {
    type: 'callout';
    raw: string;
    variant: CalloutVariant;
    title?: string;
    tokens: Array<Tokens.Generic>;
}
/**
 * A processor that transforms :::callout-style blocks into styled callout boxes.
 *
 * Supported types: info, warning, tip, success, danger, note
 *
 * @example
 * ```markdown
 * ::: warning Be cautious!
 * This is a warning box.
 * :::
 * ```
 *
 * @public
 */
export declare class CalloutProcessor extends BaseProcessor {
    get extension(): TokenizerAndRendererExtension;
}
export {};
//# sourceMappingURL=CalloutProcessor.d.ts.map