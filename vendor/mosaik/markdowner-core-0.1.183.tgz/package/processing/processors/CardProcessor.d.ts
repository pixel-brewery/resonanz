import type { TokenizerAndRendererExtension, Tokens } from 'marked';
import { BaseProcessor } from './abstracts/BaseProcessor.js';
type CardVariant = 'primary' | 'secondary' | 'tertiary' | 'info' | 'warning' | 'danger' | 'error' | 'success' | 'highlight' | 'neutral';
export interface ICardToken extends Tokens.Generic {
    type: 'md_card';
    raw: string;
    header: string;
    subHeader: string;
    variant: CardVariant;
    tokens: Array<Tokens.Generic>;
    content: string;
}
/**
 * A processor that transforms `:::card` blocks into card layout elements.
 *
 * @example
 * ```markdown
 * ::: card Joy Theme | Warm and playful | primary
 * The Joy theme uses magenta accents with high-contrast surfaces.
 * Perfect for consumer-facing applications.
 * ::: end-card
 *
 * ::: card Memphis Theme | Bold and geometric
 * Pastel-geometric palette for playful interfaces.
 * ::: end-card
 * ```
 *
 * Format: `::: card Header | Sub-Header | variant`
 * - `Header` (required): The card title
 * - `Sub-Header` (optional): A sub-heading
 * - `variant` (optional): One of the known variants, defaults to `neutral`
 *
 * @public
 */
export declare class CardProcessor extends BaseProcessor {
    get extension(): TokenizerAndRendererExtension;
}
export {};
//# sourceMappingURL=CardProcessor.d.ts.map