// #region Imports
import { html } from '../../templating/Html.js';
import { BaseProcessor } from './abstracts/BaseProcessor.js';
/**
 * A processor that transforms `:::steps` blocks into a vertical stepper layout.
 * Each step includes a title and content body.
 *
 * @example
 * ```markdown
 * ::: steps
 * ::: step Install the package
 * Run the following command in your terminal:
 * ```bash
 * npm install @pixel-brewery/mosaik-elements
 * ```
 * ::: end-step
 *
 * ::: step Import the component
 * Use the component in your project:
 * ```ts
 * import '@pixel-brewery/mosaik-elements';
 * ```
 * ::: end-step
 * ::: end-steps
 * ```
 *
 * @public
 */
export class StepsProcessor extends BaseProcessor {
    get extension() {
        return {
            name: 'steps',
            level: 'block',
            start(src) {
                return (/^::: steps/).exec(src)?.index;
            },
            tokenizer(src) {
                return StepsTokenizer.tokenize(this.lexer, src);
            },
            renderer(token) {
                return StepsRenderer.render(this.parser, token);
            },
            childTokens: ['steps']
        };
    }
}
/**
 * @private
 */
class StepsTokenizer {
    static tokenize(lexer, src) {
        const match = (/^::: steps\n([\s\S]+?)\n::: end-steps/).exec(src);
        if (!match) {
            return undefined;
        }
        const stepRegex = /^::: step (.+?)\n([\s\S]+?)\n::: end-step/gm;
        const steps = [];
        let stepMatch = null;
        let index = 0;
        while ((stepMatch = stepRegex.exec(match[1])) !== null) {
            const content = stepMatch[2].trim();
            const tokens = lexer.blockTokens(content);
            steps.push({
                type: 'step',
                raw: stepMatch[0],
                tokens,
                id: `step-${index++}`,
                title: stepMatch[1].trim(),
                content
            });
        }
        return {
            type: 'steps',
            raw: match[0],
            steps
        };
    }
}
/**
 * @private
 */
class StepsRenderer {
    static render(parser, token) {
        return html `
            <div class="steps">
            ${token.steps.map((step, i) => `
                <div class="step" id="${step.id}">
                    <div class="step-indicator">
                        <span class="step-number">${i + 1}</span>
                        ${i < token.steps.length - 1 ? '<span class="step-line"></span>' : ''}
                    </div>
                    <div class="step-body">
                        <h6 class="step-title">${step.title}</h6>
                        <div class="step-content">${parser.parse(step.tokens ?? [])}</div>
                    </div>
                </div>
            `).join('')}
            </div>
        `.trim();
    }
}
//# sourceMappingURL=StepsProcessor.js.map