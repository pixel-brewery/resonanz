import { BaseProcessor } from './abstracts/BaseProcessor.js';
const KNOWN_VARIANTS = new Set([
    'primary', 'secondary', 'tertiary', 'info', 'warning', 'danger', 'error', 'success', 'highlight', 'neutral'
]);
/**
 * A processor that transforms blockquotes using the `[!TYPE]` syntax into styled callouts.
 *
 * Supported types: `info`, `warning`, `danger`, `success`. Fallback: `neutral`.
 *
 * @example
 * ```markdown
 * > [!INFO]
 * > This is an informational message.
 *
 * > [!WARNING] Pay attention!
 * > Critical instructions follow.
 *
 * > Just a normal blockquote.
 * ```
 *
 * @public
 */
export class BlockquoteProcessor extends BaseProcessor {
    get extension() {
        return {
            name: 'blockquote',
            level: 'block',
            renderer(token) {
                return BlockquoteRenderer.render(token);
            }
        };
    }
    walkTokens(token) {
        if (token.type !== 'blockquote') {
            return;
        }
        BlockquoteTokenizer.enrich(token);
    }
}
class BlockquoteTokenizer {
    static enrich(token) {
        const text = token.text.trim();
        const match = (/^\[!(PRIMARY|SECONDARY|TERTIARY|INFO|WARNING|DANGER|ERROR|SUCCESS|HIGHLIGHT|NEUTRAL)\][ \t]*([\s\S]*)$/im).exec(text);
        if (match) {
            const variant = match[1].toLowerCase();
            const content = match[2].trim();
            token.variant = KNOWN_VARIANTS.has(variant)
                ? variant
                : 'neutral';
            token.content = content;
        }
        else {
            token.variant = 'neutral';
            token.content = text;
        }
    }
}
class BlockquoteRenderer {
    static render(token) {
        if (token.variant === 'neutral') {
            return `<blockquote>${token.content}</blockquote>`;
        }
        const label = `<strong>${token.variant.charAt(0).toUpperCase() + token.variant.slice(1)}:</strong>`;
        return `<blockquote class="blockquote-${token.variant}">${label}${token.content}</blockquote>`;
    }
}
//# sourceMappingURL=BlockquoteProcessor.js.map