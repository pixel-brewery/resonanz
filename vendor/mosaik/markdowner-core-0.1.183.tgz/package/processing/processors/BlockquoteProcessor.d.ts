import type { TokenizerAndRendererExtension, Tokens } from 'marked';
import { BaseProcessor } from './abstracts/BaseProcessor.js';
type BlockquoteVariant = 'primary' | 'secondary' | 'tertiary' | 'info' | 'warning' | 'danger' | 'error' | 'success' | 'highlight' | 'neutral';
export interface IBlockquoteToken extends Tokens.Generic {
    type: 'blockquote';
    raw: string;
    text: string;
    variant: BlockquoteVariant;
    content: string;
}
/**
 * A processor that transforms blockquotes using the `[!TYPE]` syntax into styled callouts.
 *
 * Supported types: `info`, `warning`, `danger`, `success`. Fallback: `neutral`.
 *
 * @example
 * ```markdown
 * > [!INFO]
 * > This is an informational message.
 *
 * > [!WARNING] Pay attention!
 * > Critical instructions follow.
 *
 * > Just a normal blockquote.
 * ```
 *
 * @public
 */
export declare class BlockquoteProcessor extends BaseProcessor {
    get extension(): TokenizerAndRendererExtension;
    walkTokens(token: Tokens.Generic): void;
}
export {};
//# sourceMappingURL=BlockquoteProcessor.d.ts.map