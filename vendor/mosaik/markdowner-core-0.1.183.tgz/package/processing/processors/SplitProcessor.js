// #region Imports
import { BaseProcessor } from './abstracts/BaseProcessor.js';
const KNOWN_VARIANTS = new Set([
    'primary', 'secondary', 'tertiary',
    'info', 'warning', 'danger', 'error',
    'success', 'highlight', 'neutral'
]);
/**
 * A processor that transforms `:::split` blocks into a two-column layout.
 * Each column may include a heading, a list, and an optional variant like `[!INFO]`.
 *
 * Supported variants: `primary`, `secondary`, `tertiary`, `info`, `warning`, `danger`, `error`, `success`, `highlight`, `neutral`.
 *
 * @example
 * ```markdown
 * ::: splits
 * ::: split Split 1
 * [!INFO]
 * - Split 1 point a
 * - Split 1 point b
 * - Split 1 point c
 * ::: end-split
 *
 * ::: split Split 2
 * [!ERROR]
 * - Split 2 point a
 * - Split 2 point b
 * - Split 2 point c
 * ::: end-split
 * ::: end-splits
 * ```
 *
 * @public
 */
export class SplitProcessor extends BaseProcessor {
    get extension() {
        return {
            name: 'splits',
            level: 'block',
            start(src) {
                return (/^::: splits/).exec(src)?.index;
            },
            tokenizer(src) {
                return SplitTokenizer.tokenize(this.lexer, src);
            },
            renderer(token) {
                return SplitRenderer.render(this.parser, token);
            },
            childTokens: ['splits']
        };
    }
}
/**
 * @private
 */
class SplitTokenizer {
    static tokenize(lexer, src) {
        const match = (/^::: splits\n([\s\S]+?)\n::: end-splits/).exec(src);
        if (!match) {
            return undefined;
        }
        const splitRegex = /^::: split (.+?)\n([\s\S]+?)\n::: end-split/gm;
        const splits = [];
        let splitMatch = null;
        let index = 0;
        while ((splitMatch = splitRegex.exec(match[1])) !== null) {
            const rawLines = splitMatch[2].trim().split('\n');
            let variant = undefined;
            const variantMatch = (/^\[\!(\w+)\]/).exec(rawLines[0]);
            if (variantMatch) {
                const v = variantMatch[1].toLowerCase();
                if (KNOWN_VARIANTS.has(v)) {
                    variant = v;
                    rawLines.shift(); // Remove variant line
                }
            }
            const content = rawLines.join('\n').trim();
            const tokens = lexer.blockTokens(content);
            splits.push({
                type: 'split',
                raw: splitMatch[0],
                tokens,
                id: `split-${index++}`,
                title: lexer.inlineTokens(splitMatch[1].trim()),
                content: content,
                variant: variant
            });
        }
        return {
            type: 'splits',
            raw: match[0],
            splits: splits
        };
    }
}
/**
 * @private
 */
class SplitRenderer {
    static render(parser, token) {
        return `
            <div class="splits">
            ${token.splits.map((split) => `
                <div class="split${split.variant ? ` ${split.variant}` : ''}">
                    <h6>${parser.parseInline(split.title)}</h6>
                    <div class="split-content">
                    ${parser.parse(split.tokens ?? [])}
                    </div>
                </div>
            `).join('')}
            </div>
        `.trim();
    }
}
//# sourceMappingURL=SplitProcessor.js.map