import type { MarkedExtension, TokenizerAndRendererExtension, Tokens } from 'marked';
/**
 * Represents a processor that can handle a specific type of Markdown token.
 */
export interface IProcessor extends Pick<MarkedExtension, 'extensions' | 'walkTokens'> {
    get extension(): TokenizerAndRendererExtension;
    walkTokens?(token: Tokens.Generic): void;
}
//# sourceMappingURL=IProcessor.d.ts.map