import { BaseProcessor } from './abstracts/BaseProcessor.js';
const KNOWN_VARIANTS = new Set([
    'primary', 'secondary', 'tertiary', 'info', 'warning', 'danger', 'success', 'highlight', 'neutral'
]);
/**
 * A processor that transforms :::callout-style blocks into styled callout boxes.
 *
 * Supported types: info, warning, tip, success, danger, note
 *
 * @example
 * ```markdown
 * ::: warning Be cautious!
 * This is a warning box.
 * :::
 * ```
 *
 * @public
 */
export class CalloutProcessor extends BaseProcessor {
    get extension() {
        return {
            name: 'callout',
            level: 'block',
            start(src) {
                return (/^::: \w+/).exec(src)?.index;
            },
            tokenizer(src) {
                return CalloutTokenizer.tokenize(src, this.lexer);
            },
            renderer(token) {
                return CalloutRenderer.render(token, this);
            }
        };
    }
}
class CalloutTokenizer {
    static tokenize(src, lexer) {
        const match = (/^::: (\w+)(?:\s+([^\n]+))?\n([\s\S]+?)\n:::/).exec(src);
        if (!match) {
            return undefined;
        }
        const variant = match[1].toLowerCase();
        if (!KNOWN_VARIANTS.has(variant)) {
            return undefined;
        }
        const title = match[2]?.trim();
        const content = match[3].trim();
        const contentTokens = lexer.blockTokens(content);
        return {
            type: 'callout',
            raw: match[0],
            variant,
            title,
            tokens: contentTokens
        };
    }
}
class CalloutRenderer {
    static render(token, renderer) {
        const classes = ['callout', token.variant];
        const title = token.title
            ? `<div class="callout-title">${token.title}</div>`
            : '';
        const body = renderer.parser.parse(token.tokens ?? []);
        return `<div class="${classes.join(' ')}">${title}${body}</div>`;
    }
}
//# sourceMappingURL=CalloutProcessor.js.map