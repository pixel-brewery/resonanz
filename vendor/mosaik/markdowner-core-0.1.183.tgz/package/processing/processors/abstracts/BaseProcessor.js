// #region Imports
// #endregion
/**
 * Abstract base class for custom Markdown processors.
 */
export class BaseProcessor {
    /**
     * Override this method to provide custom hooks for processing tokens.
     *
     * @public
     * @readonly
     * @returns An object containing hooks for processing tokens.
     */
    get hooks() {
        return {
            processAllTokens: (tokens) => this.processAllTokens(tokens),
            preprocess: (markdown) => this.preprocess(markdown),
            postprocess: (html) => this.postprocess(html)
        };
    }
    // #endregion
    // #region Methods
    /**
     * Preprocesses the Markdown content before rendering.
     *
     * @public
     * @param markdown The Markdown content to preprocess.
     * @returns The preprocessed Markdown content.
     */
    preprocess(markdown) {
        return markdown;
    }
    /**
     * Postprocessing the HTML content after rendering.
     *
     * @public
     * @param html The HTML content to postprocess.
     * @returns The postprocessed HTML content.
     */
    postprocess(html) {
        return html;
    }
    /**
     * Processes all tokens.
     *
     * @public
     * @param tokens The tokens to process.
     * @returns The processed tokens.
     */
    processAllTokens(tokens) {
        return tokens;
    }
    /**
     * Override this method to process tokens.
     *
     * @public
     * @param token The token to process.
     */
    walkTokens(_token) {
    }
    /**
     * Minifies HTML by removing all newlines and unnecessary whitespaces.
     *
     * @param html The raw HTML string to minify.
     * @returns A minified HTML string.
     */
    minifyHTML(html) {
        return html.replace(/\s+/g, ' ').trim();
    }
}
//# sourceMappingURL=BaseProcessor.js.map