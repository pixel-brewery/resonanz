import type { MarkedExtension, TokenizerAndRendererExtension, Tokens } from 'marked';
import type { IProcessor } from '../interfaces/IProcessor.js';
/**
 * Abstract base class for custom Markdown processors.
 */
export declare abstract class BaseProcessor implements MarkedExtension, IProcessor {
    /**
     * @public
     * @abstract
     * @readonly
     */
    abstract get extension(): TokenizerAndRendererExtension;
    /**
     * Override this method to provide custom hooks for processing tokens.
     *
     * @public
     * @readonly
     * @returns An object containing hooks for processing tokens.
     */
    get hooks(): MarkedExtension['hooks'];
    /**
     * Preprocesses the Markdown content before rendering.
     *
     * @public
     * @param markdown The Markdown content to preprocess.
     * @returns The preprocessed Markdown content.
     */
    preprocess(markdown: string): string;
    /**
     * Postprocessing the HTML content after rendering.
     *
     * @public
     * @param html The HTML content to postprocess.
     * @returns The postprocessed HTML content.
     */
    postprocess(html: string): string;
    /**
     * Processes all tokens.
     *
     * @public
     * @param tokens The tokens to process.
     * @returns The processed tokens.
     */
    processAllTokens(tokens: Array<Tokens.Generic>): Array<Tokens.Generic>;
    /**
     * Override this method to process tokens.
     *
     * @public
     * @param token The token to process.
     */
    walkTokens?(_token: Tokens.Generic): void;
    /**
     * Minifies HTML by removing all newlines and unnecessary whitespaces.
     *
     * @param html The raw HTML string to minify.
     * @returns A minified HTML string.
     */
    protected minifyHTML(html: string): string;
}
//# sourceMappingURL=BaseProcessor.d.ts.map