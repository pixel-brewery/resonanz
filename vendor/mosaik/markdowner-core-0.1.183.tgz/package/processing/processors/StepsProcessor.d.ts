import type { TokenizerAndRendererExtension, Tokens } from 'marked';
import { BaseProcessor } from './abstracts/BaseProcessor.js';
export interface IStepsToken extends Tokens.Generic {
    type: 'steps';
    raw: string;
    steps: Array<IStepToken>;
}
export interface IStepToken extends Tokens.Generic {
    type: 'step';
    id: string;
    title: string;
    tokens: Array<Tokens.Generic>;
    content: string;
}
/**
 * A processor that transforms `:::steps` blocks into a vertical stepper layout.
 * Each step includes a title and content body.
 *
 * @example
 * ```markdown
 * ::: steps
 * ::: step Install the package
 * Run the following command in your terminal:
 * ```bash
 * npm install @pixel-brewery/mosaik-elements
 * ```
 * ::: end-step
 *
 * ::: step Import the component
 * Use the component in your project:
 * ```ts
 * import '@pixel-brewery/mosaik-elements';
 * ```
 * ::: end-step
 * ::: end-steps
 * ```
 *
 * @public
 */
export declare class StepsProcessor extends BaseProcessor {
    get extension(): TokenizerAndRendererExtension;
}
//# sourceMappingURL=StepsProcessor.d.ts.map