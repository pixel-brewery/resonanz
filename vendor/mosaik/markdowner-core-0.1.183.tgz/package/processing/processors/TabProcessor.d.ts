import type { TokenizerAndRendererExtension, Tokens } from 'marked';
import { BaseProcessor } from './abstracts/BaseProcessor.js';
type TabVariant = 'primary' | 'secondary' | 'tertiary' | 'info' | 'warning' | 'danger' | 'error' | 'success' | 'highlight' | 'neutral';
export interface ITabsToken extends Tokens.Generic {
    type: 'tabs';
    raw: string;
    tabs: Array<ITabToken>;
}
export interface ITabToken extends Tokens.Generic {
    type: 'tab';
    id: string;
    title: string;
    content: string;
    variant?: TabVariant;
}
/**
 * A processor that transforms `:::tabs` blocks into tabbed layout structures.
 * Each tab may include a title, content, and an optional variant using `[!TYPE]`.
 *
 * Supported variants: `primary`, `secondary`, `tertiary`, `info`, `warning`, `danger`, `error`, `success`, `highlight`, `neutral`.
 *
 * @example
 * ```markdown
 * ::: tabs
 * ::: tab Tab 1
 * [!INFO]
 * Content for the first tab.
 * ::: end-tab
 *
 * ::: tab Tab 2
 * [!WARNING]
 * Content for the second tab.
 * ::: end-tab
 * ::: end-tabs
 * ```
 *
 * @public
 */
export declare class TabProcessor extends BaseProcessor {
    get extension(): TokenizerAndRendererExtension;
}
export {};
//# sourceMappingURL=TabProcessor.d.ts.map