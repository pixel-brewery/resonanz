// #region Imports
import { Marked } from 'marked';
import { BlockquoteProcessor } from './processors/BlockquoteProcessor.js';
import { CalloutProcessor } from './processors/CalloutProcessor.js';
import { CodeBlockProcessor } from './processors/CodeBlockProcessor.js';
import { SplitProcessor } from './processors/SplitProcessor.js';
import { TabProcessor } from './processors/TabProcessor.js';
// #endregion
/**
 * Main processor for Markdown content.
 * Orchestrates processors and integrates them with `marked`.
 *
 * @public
 */
export class MarkdownProcessor {
    // #region Fields
    _processors = [];
    // #endregion
    // #region Ctor
    /**
     * Constructs a new MarkdownProcessor.
     */
    constructor(processors) {
        this._processors = [];
        if (!processors?.length) {
            this._processors.push(new BlockquoteProcessor());
            this._processors.push(new CalloutProcessor());
            this._processors.push(new CodeBlockProcessor());
            this._processors.push(new TabProcessor());
            this._processors.push(new SplitProcessor());
        }
        this._processors.push(...processors ?? []);
    }
    // #endregion
    // #region Methods
    /**
     * Adds a custom processor to the manager.
     *
     * @public
     * @param processor The processor to add.
     */
    addProcessor(processor) {
        this._processors.push(processor);
    }
    /**
     * Removes a custom processor from the manager.
     *
     * @public
     * @param processor The processor to remove.
     */
    removeProcessor(processor) {
        this._processors = this._processors.filter((p) => p !== processor);
    }
    /**
     * Processes Markdown content into HTML.
     *
     * @public
     * @param markdown The Markdown content to process.
     * @returns The resulting HTML string.
     */
    process(markdown, options) {
        const extensions = this._processors.map((p) => ({
            // eslint-disable-next-line @typescript-eslint/unbound-method
            walkTokens: p.walkTokens,
            extensions: [p.extension]
        }));
        const html = new Marked()
            .use(...extensions)
            .parse(markdown, {
            async: false,
            ...options
        });
        return html;
    }
    /**
     * Processes Markdown content into HTML asynchronously.
     *
     * @public
     * @param markdown The Markdown content to process.
     * @returns A promise that resolves to the resulting HTML string.
     */
    processAsync(markdown, options) {
        const html = new Marked()
            .use(...this._processors)
            .parse(markdown, {
            async: true,
            ...options
        });
        return html;
    }
}
//# sourceMappingURL=MarkdownProcessor.js.map