// #region Imports
/**
 * Orders a list by one or multiple selector functions (iteratees).
 * Keys compare in a total order, so the result does not depend on the input order: numbers, bigints, booleans
 * and dates by value, then strings (with the `collator`, or case-insensitively), then other values.
 * Empty keys (`null`, `undefined`, `NaN`, invalid dates) come last in both directions. The sort is stable.
 * Without selectors the items themselves are the keys.
 *
 * @public
 * @param input Source array; `null`/`undefined` yields `[]`.
 * @param selectors Single selector or list of selectors `(item) => key`.
 * @param direction `'asc' | 'desc'` or list thereof aligned to `selectors`. Defaults to `'asc'`.
 * @param collator Optional `Intl.Collator` for locale-aware string comparison.
 * @returns New sorted array (original is not mutated).
 */
export function orderBy(input, selectors, direction, collator) {
    const list = Array.isArray(input) ? [...input] : [];
    if (!selectors || (Array.isArray(selectors) && selectors.length === 0)) {
        return list.sort((a, b) => compareValues(a, b, firstDirection(direction), collator));
    }
    const iteratees = typeof selectors === 'function' ? [selectors] : selectors;
    const directions = Array.isArray(direction)
        ? direction.length === iteratees.length ? direction : Array(iteratees.length).fill(direction[0] ?? 'asc')
        : Array(iteratees.length).fill(direction ?? 'asc');
    return list.sort((a, b) => {
        for (let i = 0; i < iteratees.length; i += 1) {
            const av = iteratees[i](a);
            const bv = iteratees[i](b);
            const cmp = compareValues(av, bv, directions[i], collator);
            if (cmp !== 0) {
                return cmp;
            }
        }
        return 0;
    });
}
/**
 * Orders a list by one or multiple member paths (string-based, deep paths) with compile-time path safety via `type-fest`'s `Paths<T>`.
 * Keys compare as in {@link orderBy}; a path that cannot be resolved yields an empty key, which comes last.
 * Without paths the items themselves are the keys.
 *
 * @public
 * @param input Source array; `null`/`undefined` yields `[]`.
 * @param paths Single path or list of paths (`Paths<T>`).
 * @param direction `'asc' | 'desc'` or list thereof aligned to `paths`. Defaults to `'asc'`.
 * @param collator Optional `Intl.Collator` for locale-aware string comparison.
 * @returns New sorted array (original is not mutated).
 */
export function orderByMemberPath(input, paths, direction, collator) {
    const list = Array.isArray(input) ? [...input] : [];
    if (!paths || (Array.isArray(paths) && paths.length === 0)) {
        return list.sort((a, b) => compareValues(a, b, firstDirection(direction), collator));
    }
    const pathList = Array.isArray(paths) ? paths : [paths];
    const directions = Array.isArray(direction)
        ? direction.length === pathList.length ? direction : Array(pathList.length).fill(direction[0] ?? 'asc')
        : Array(pathList.length).fill(direction ?? 'asc');
    return list.sort((a, b) => {
        for (let i = 0; i < pathList.length; i += 1) {
            const av = getByPath(a, pathList[i]);
            const bv = getByPath(b, pathList[i]);
            const cmp = compareValues(av, bv, directions[i], collator);
            if (cmp !== 0) {
                return cmp;
            }
        }
        return 0;
    });
}
/**
 * Compares two values of a sort key in a total, transitive order, so the result does not depend on the input order.
 * Rules (the same as the built-in column sort of the Mosaik data table):
 *  - empty values (`null`, `undefined`, `NaN` and invalid dates) come last in both directions
 *  - numbers, bigints, booleans and dates compare by value (`false` before `true`, dates by epoch time)
 *  - strings compare with the provided `Intl.Collator`, or case-insensitively without one
 *  - a mixed key orders numbers, bigints, booleans and dates before strings, and strings before other values
 *  - other values compare by their string representation
 */
function compareValues(a, b, direction, collator) {
    const aEmpty = isEmpty(a);
    const bEmpty = isEmpty(b);
    if (aEmpty || bEmpty) {
        if (aEmpty === bEmpty) {
            return 0;
        }
        return aEmpty ? 1 : -1;
    }
    const cmp = compareAscending(a, b, collator);
    return direction === 'desc' ? -cmp : cmp;
}
/**
 * Returns whether the value is empty and sorts last: `null`, `undefined`, `NaN` or an invalid date.
 */
function isEmpty(value) {
    if (value === null || value === undefined) {
        return true;
    }
    if (typeof value === 'number') {
        return Number.isNaN(value);
    }
    return value instanceof Date && Number.isNaN(value.getTime());
}
/**
 * Compares two non-empty values in ascending order and returns `-1`, `0` or `1`.
 */
function compareAscending(a, b, collator) {
    const rankA = rankOf(a);
    const rankB = rankOf(b);
    if (rankA !== rankB) {
        return rankA < rankB ? -1 : 1;
    }
    if (rankA === 0) {
        const na = toNumeric(a);
        const nb = toNumeric(b);
        if (na < nb) {
            return -1;
        }
        if (na > nb) {
            return 1;
        }
        return 0;
    }
    const sa = String(a);
    const sb = String(b);
    return Math.sign(collator ? collator.compare(sa, sb) : sa.toLowerCase().localeCompare(sb.toLowerCase()));
}
/**
 * Returns the position of the value's type in a mixed key:
 * `0` for numbers, bigints, booleans and dates, `1` for strings and `2` for other values.
 */
function rankOf(value) {
    if (typeof value === 'number' || typeof value === 'bigint' || typeof value === 'boolean' || value instanceof Date) {
        return 0;
    }
    return typeof value === 'string' ? 1 : 2;
}
/**
 * Returns the numeric value of a number, bigint, boolean or date.
 */
function toNumeric(value) {
    if (value instanceof Date) {
        return value.getTime();
    }
    if (typeof value === 'boolean') {
        return Number(value);
    }
    return value;
}
/**
 * Returns the direction for a list without selectors or paths: the direction, or the first of a list thereof.
 */
function firstDirection(direction) {
    return (Array.isArray(direction) ? direction[0] : direction) ?? 'asc';
}
/**
 * Reads a deep property via dot-separated path (e.g., "user.profile.lastName").
 * Returns `undefined` if the path cannot be fully resolved.
 */
function getByPath(obj, path) {
    if (!path) {
        return undefined;
    }
    const segments = path.split('.');
    let cursor = obj;
    for (const key of segments) {
        if (cursor !== null && typeof cursor === 'object' && key in cursor) {
            cursor = cursor[key];
        }
        else {
            return undefined;
        }
    }
    return cursor;
}
//# sourceMappingURL=orderBy.js.map