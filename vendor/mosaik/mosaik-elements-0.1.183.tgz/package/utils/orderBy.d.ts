import type { Paths } from 'type-fest';
type Direction = 'asc' | 'desc';
/**
 * Orders a list by one or multiple selector functions (iteratees).
 * Keys compare in a total order, so the result does not depend on the input order: numbers, bigints, booleans
 * and dates by value, then strings (with the `collator`, or case-insensitively), then other values.
 * Empty keys (`null`, `undefined`, `NaN`, invalid dates) come last in both directions. The sort is stable.
 * Without selectors the items themselves are the keys.
 *
 * @public
 * @param input Source array; `null`/`undefined` yields `[]`.
 * @param selectors Single selector or list of selectors `(item) => key`.
 * @param direction `'asc' | 'desc'` or list thereof aligned to `selectors`. Defaults to `'asc'`.
 * @param collator Optional `Intl.Collator` for locale-aware string comparison.
 * @returns New sorted array (original is not mutated).
 */
export declare function orderBy<T>(input: ReadonlyArray<T> | null | undefined, selectors?: ((item: T) => unknown) | ReadonlyArray<(item: T) => unknown>, direction?: Direction | ReadonlyArray<Direction>, collator?: Intl.Collator): Array<T>;
/**
 * Orders a list by one or multiple member paths (string-based, deep paths) with compile-time path safety via `type-fest`'s `Paths<T>`.
 * Keys compare as in {@link orderBy}; a path that cannot be resolved yields an empty key, which comes last.
 * Without paths the items themselves are the keys.
 *
 * @public
 * @param input Source array; `null`/`undefined` yields `[]`.
 * @param paths Single path or list of paths (`Paths<T>`).
 * @param direction `'asc' | 'desc'` or list thereof aligned to `paths`. Defaults to `'asc'`.
 * @param collator Optional `Intl.Collator` for locale-aware string comparison.
 * @returns New sorted array (original is not mutated).
 */
export declare function orderByMemberPath<T>(input: ReadonlyArray<T> | null | undefined, paths?: Paths<T> | ReadonlyArray<Paths<T>>, direction?: Direction | ReadonlyArray<Direction>, collator?: Intl.Collator): Array<T>;
export {};
//# sourceMappingURL=orderBy.d.ts.map