import type { Paths } from 'type-fest';
/**
 * Filters a list using a predicate function (like Array.prototype.filter).
 *
 * @param input      Source array; `null`/`undefined` yields `[]`.
 * @param predicate  Test function `(item, index, array) => boolean`. Must be synchronous.
 * @returns          New filtered array (original is not mutated).
 *
 * @public
 */
export declare function filterBy<T>(input: ReadonlyArray<T> | null | undefined, predicate: (item: T, index: number, array: ReadonlyArray<T>) => boolean): Array<T>;
/**
 * Filters a list of items by checking one or multiple (dot-path) properties against a search term.
 *
 * - Case-insensitive string matching
 * - Supports `string | number | boolean | string[]`
 * - Strict (exact) vs. non-strict (substring) mode
 * - Deep property access via dot notation ("user.profile.name")
 * - Member paths are compile-time checked via TypeFest `Paths<T>`
 *
 * @param input   The source array. `null`/`undefined` yields an empty list.
 * @param props   Property paths (dot-notation, type-checked) to check against the search term(s).
 * @param search  A search term or a list of terms. Non-string terms are stringified.
 * @param strict  If `true`, matches must be exact (case-insensitive for strings). Otherwise substring matching is used.
 * @returns       A new filtered array (original is not mutated).
 *
 * @public
 */
export declare function filterByMemberPath<T>(input: ReadonlyArray<T> | null | undefined, props: ReadonlyArray<Paths<T>>, search?: string | number | boolean | ReadonlyArray<string>, strict?: boolean): Array<T>;
//# sourceMappingURL=filterBy.d.ts.map