// #region Imports
// #endregion
/**
 * Filters a list using a predicate function (like Array.prototype.filter).
 *
 * @param input      Source array; `null`/`undefined` yields `[]`.
 * @param predicate  Test function `(item, index, array) => boolean`. Must be synchronous.
 * @returns          New filtered array (original is not mutated).
 *
 * @public
 */
export function filterBy(input, predicate) {
    const list = Array.isArray(input) ? input : [];
    if (typeof predicate !== 'function') {
        return [...list];
    }
    // Mirrors Array.prototype.filter semantics.
    // Reference: MDN Array.prototype.filter. (https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/filter)
    return list.filter((item, index, array) => predicate(item, index, array));
}
/**
 * Filters a list of items by checking one or multiple (dot-path) properties against a search term.
 *
 * - Case-insensitive string matching
 * - Supports `string | number | boolean | string[]`
 * - Strict (exact) vs. non-strict (substring) mode
 * - Deep property access via dot notation ("user.profile.name")
 * - Member paths are compile-time checked via TypeFest `Paths<T>`
 *
 * @param input   The source array. `null`/`undefined` yields an empty list.
 * @param props   Property paths (dot-notation, type-checked) to check against the search term(s).
 * @param search  A search term or a list of terms. Non-string terms are stringified.
 * @param strict  If `true`, matches must be exact (case-insensitive for strings). Otherwise substring matching is used.
 * @returns       A new filtered array (original is not mutated).
 *
 * @public
 */
export function filterByMemberPath(input, props, search = '', strict = false) {
    const list = Array.isArray(input) ? input : [];
    if (!props.length) {
        return [...list];
    }
    const validType = typeof search === 'string' ||
        typeof search === 'number' ||
        typeof search === 'boolean' ||
        Array.isArray(search);
    if (!validType) {
        return [...list];
    }
    const isArraySearch = Array.isArray(search);
    const terms = isArraySearch
        ? search.map((s) => s.toLowerCase())
        : [String(search).toLowerCase()];
    // Historical behavior: empty string means "no filter"
    if (!isArraySearch && terms[0] === '') {
        return [...list];
    }
    return list.filter((item) => props.some((path) => {
        // `Paths<T>` from type-fest is a template-literal string union; cast is safe for runtime usage.
        const value = getByPath(item, path);
        if (value === null || value === undefined) {
            return false;
        }
        // Support primitive or array-of-primitive values. If an array, match if ANY element satisfies the criteria.
        if (Array.isArray(value)) {
            const lowered = value
                .filter((v) => v !== null && v !== undefined && (typeof v === 'string' || typeof v === 'number' || typeof v === 'boolean'))
                .map((v) => String(v).toLowerCase());
            if (!lowered.length) {
                return false;
            }
            if (isArraySearch) {
                return strict
                    ? lowered.some((lv) => terms.includes(lv))
                    : lowered.some((lv) => terms.some((t) => lv.includes(t)));
            }
            return strict ? lowered.includes(terms[0]) : lowered.some((lv) => lv.includes(terms[0]));
        }
        // Skip plain objects to avoid meaningless "[object Object]" stringification.
        if (typeof value === 'object') {
            return false;
        }
        // includes() is case-sensitive; normalize both sides for case-insensitive contains. (https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/includes)
        if (typeof value !== 'string' && typeof value !== 'number' && typeof value !== 'boolean') {
            return false; // Non-primitive (e.g., symbol) is ignored
        }
        const normalized = String(value).toLowerCase();
        return isArraySearch
            ? terms.some((t) => strict ? normalized === t : normalized.includes(t))
            : strict
                ? normalized === terms[0]
                : normalized.includes(terms[0]);
    }));
}
/**
 * Safely reads a deep property value from an object using a dot-separated path.
 *
 * Example:
 *   getByPath({ a: { b: 1 } }, "a.b") => 1
 *
 * Returns `undefined` if the chain breaks.
 * See MDN for filter semantics referenced above. (https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/filter)
 *
 * @internal
 */
function getByPath(obj, path) {
    if (!path) {
        return undefined;
    }
    const parts = path.split('.');
    let cursor = obj;
    for (const key of parts) {
        if (cursor !== null && typeof cursor === 'object' && key in cursor) {
            cursor = cursor[key];
        }
        else {
            return undefined;
        }
    }
    return cursor;
}
// #endregion
//# sourceMappingURL=filterBy.js.map