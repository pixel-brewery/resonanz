/**
 * @public
 */
export interface IDisposableLike {
    dispose: () => void;
}
/**
 * @public
 */
export declare namespace IDisposableLike {
    /**
     * @public
     */
    function create(dispose: () => void): IDisposableLike;
}
//# sourceMappingURL=Disposable.d.ts.map