/**
 * @public
 */
export var IDisposableLike;
(function (IDisposableLike) {
    /**
     * @public
     */
    function create(dispose) {
        return {
            dispose
            // [Symbol.dispose]: dispose
        };
    }
    IDisposableLike.create = create;
})(IDisposableLike || (IDisposableLike = {}));
//# sourceMappingURL=Disposable.js.map