# 📦 @pixel-brewery/mosaik-elements

| Package Status | Source |
|----------------|--------|
| [![GitHub Packages](https://img.shields.io/github/v/release/RueDeRennes/mosaik?label=GitHub%20Packages&logo=github)](https://github.com/orgs/pixel-brewery/packages/npm/package/mosaik-elements) | [libs/mosaik-elements](../../libs/mosaik-elements) |

> Main web components and shared utilities for the Mosaik design system.
> Provides all core components, types, and helpers for framework wrappers.

---

## 📁 Project Structure

Part of the monorepo [`mosaik`](https://github.com/RueDeRennes/mosaik)
Package path: `libs/mosaik-elements`
Version: see [GitHub Packages](https://github.com/orgs/pixel-brewery/packages/npm/package/mosaik-elements)
License: MIT

---

## 📦 Installation

```bash
yarn add @pixel-brewery/mosaik-elements
# or
npm install @pixel-brewery/mosaik-elements
```

---

## 🔧 Usage

```typescript
import * from '@pixel-brewery/mosaik-elements';
```

---

## ⚙️ Features

- All core Mosaik web components
- Shared types, interfaces, and helpers
- Foundation for Angular, React, Vue, and Svelte wrappers

---

## 🛠 Recommendations

- Use as the base for all Mosaik component wrappers.
- Explore the API docs [here](./../../.docs/api/mosaik-elements/index.md)!

---

## Development builds

Run `yarn nx run mosaik-elements:build` from the workspace root. The build compiles into a fresh temporary directory before replacing `dist/`, then prepares and checks the package. This removes stale output after deletions or directory renames, including case-only renames on macOS and Windows. Build steps run in order.

The package check validates manifest entries and relative JavaScript and declaration imports with exact path casing. Both imports with explicit extensions and extensionless bundler imports are checked. Keep directory names lowercase in the source tree; do not rename generated files manually. Unit specs are excluded from the distributed output.

A successful local rebuild does not repair previously published packages. Publishing a corrected package and updating consumer lockfiles are separate owner-managed steps.

---

## 📦 Publishing

```bash
yarn nx run mosaik-elements:publish
```

---

## 📄 License

MIT © Pixel Brewery

---

