import type { IEventListenerSubscription } from './interfaces/IEventListenerSubscription';
/**
 * The `EventListenerSubscription` class.
 *
 * @public
 */
export declare class EventListenerSubscription<TEvent extends Event = Event> implements IEventListenerSubscription {
    private readonly _eventName;
    private readonly _listener;
    private readonly _dispose;
    private _isDisposed;
    /**
     * Constructs a new instance of the `EventListenerSubscription` class.
     *
     * @private
     */
    private constructor();
    /**
     * Returns the `eventName` property.
     *
     * @public
     * @readonly
     */
    get eventName(): string;
    /**
     * Returns the `listener` property.
     *
     * @public
     * @readonly
     */
    get listener(): Readonly<(event: TEvent) => void>;
    /**
     * @public
     * @static
     */
    static create<TEvent extends Event>(eventName: string, listener: (event: TEvent) => void, dispose: (arg: IEventListenerSubscription) => void): EventListenerSubscription<TEvent>;
    /**
     * @public
     */
    invoke(event: TEvent): void;
    /**
     * @public
     */
    dispose(): void;
}
//# sourceMappingURL=EventListenerSubscription.d.ts.map