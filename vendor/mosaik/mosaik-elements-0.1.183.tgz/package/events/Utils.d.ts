import type { IEventListenerSubscription } from './interfaces/IEventListenerSubscription';
/**
 * @public
 */
export declare function on<TEvent extends keyof HTMLBodyElementEventMap>(target: EventTarget, eventName: TEvent, listener: (event: HTMLBodyElementEventMap[TEvent]) => void, options?: boolean | AddEventListenerOptions): IEventListenerSubscription;
/**
 * @public
 */
export declare function off<TEvent extends Event = Event>(_target: EventTarget | ShadowRoot, subscription: IEventListenerSubscription): void;
/**
 * @public
 */
export declare function emit<TDetail = void>(target: EventTarget, eventName: string, detail?: TDetail): boolean;
/**
 * Waits for a specific event to be emitted from an element. Ignores events that bubble up from child elements.
 *
 * @public
 */
export declare function waitForEvent<TEvent extends keyof HTMLBodyElementEventMap>(target: EventTarget, eventName: TEvent): Promise<HTMLBodyElementEventMap[TEvent]>;
/**
 * Prevents the default action of an event and calls the provided handler.
 *
 * @public
 */
export declare function prevent<T extends Event>(event: T, handler: (event: T) => void): void;
/**
 * Stops the propagation of an event and calls the provided handler.
 * If the event is cancelable, it also prevents the default action.
 *
 * @public
 */
export declare function stop<T extends Event>(event: T, handler: (event: T) => void): void;
//# sourceMappingURL=Utils.d.ts.map