import type { IEventDetail } from './IEventDetail';
/**
 * Represents event details with an error.
 *
 * @public
 */
export interface IErrorEventDetail<TError = Error> extends IEventDetail {
    /**
     * Gets the `error` property.
     */
    readonly error: TError;
}
//# sourceMappingURL=IErrorEventDetail.d.ts.map