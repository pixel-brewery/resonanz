// #region Imports
export {};
//# sourceMappingURL=ICancelEventDetail.js.map