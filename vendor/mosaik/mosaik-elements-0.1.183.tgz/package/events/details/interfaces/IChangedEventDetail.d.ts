import type { IEventDetail } from './IEventDetail';
/**
 * Represents event details with old and new value.
 *
 * @public
 */
export interface IChangedEventDetail<TValue = unknown> extends IEventDetail {
    /**
     * Gets the `oldValue` property.
     */
    readonly oldValue: TValue;
    /**
     * Gets the `newValue` property.
     */
    readonly newValue: TValue;
}
//# sourceMappingURL=IChangedEventDetail.d.ts.map