export {};
//# sourceMappingURL=IEventDetail.js.map