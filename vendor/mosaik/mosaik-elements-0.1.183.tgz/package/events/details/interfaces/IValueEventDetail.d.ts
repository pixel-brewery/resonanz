import type { IEventDetail } from './IEventDetail';
/**
 * Represents event details with a single value.
 *
 * @public
 */
export interface IValueEventDetail<TValue = unknown> extends IEventDetail {
    /**
     * Gets the `value` property.
     */
    readonly value: TValue;
}
//# sourceMappingURL=IValueEventDetail.d.ts.map