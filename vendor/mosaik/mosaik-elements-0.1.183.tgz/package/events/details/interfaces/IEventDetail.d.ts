/**
 * Base interface for all event details.
 * This is a marker interface that can be extended with additional properties.
 *
 * @public
 */
export interface IEventDetail {
}
//# sourceMappingURL=IEventDetail.d.ts.map