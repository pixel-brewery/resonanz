// #region Imports
export {};
//# sourceMappingURL=IErrorEventDetail.js.map