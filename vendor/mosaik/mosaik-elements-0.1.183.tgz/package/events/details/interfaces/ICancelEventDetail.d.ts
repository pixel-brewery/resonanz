import type { IEventDetail } from './IEventDetail';
/**
 * Represents event details with a cancellation flag.
 *
 * @public
 */
export interface ICancelEventDetail extends IEventDetail {
    /**
     * Gets or sets the `cancel` property which decides whether the event should be canceled or not.
     */
    cancel: boolean;
}
//# sourceMappingURL=ICancelEventDetail.d.ts.map