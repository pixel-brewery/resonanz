// #region Imports
import { EventListenerSubscription } from './EventListenerSubscription';
// #endregion
/**
 * @public
 */
export function on(target, eventName, listener, options) {
    target.addEventListener(eventName, listener, options);
    return EventListenerSubscription.create(eventName, listener, (_subscription) => {
        target.removeEventListener(eventName, listener, options);
    });
}
/**
 * @public
 */
export function off(_target, subscription) {
    const typedSubscription = subscription;
    typedSubscription.dispose();
}
/**
 * @public
 */
export function emit(target, eventName, detail) {
    return target.dispatchEvent(new CustomEvent(eventName, {
        bubbles: true,
        cancelable: false,
        composed: true,
        detail: detail
    }));
}
/**
 * Waits for a specific event to be emitted from an element. Ignores events that bubble up from child elements.
 *
 * @public
 */
export function waitForEvent(target, eventName) {
    return new Promise((resolve) => {
        const done = (event) => {
            if (event.composedPath()[0] === target) {
                target.removeEventListener(eventName, done);
                resolve(event);
            }
        };
        target.addEventListener(eventName, done);
    });
}
/**
 * Prevents the default action of an event and calls the provided handler.
 *
 * @public
 */
export function prevent(event, handler) {
    event.preventDefault();
    handler(event);
}
/**
 * Stops the propagation of an event and calls the provided handler.
 * If the event is cancelable, it also prevents the default action.
 *
 * @public
 */
export function stop(event, handler) {
    event.stopPropagation();
    handler(event);
}
//# sourceMappingURL=Utils.js.map