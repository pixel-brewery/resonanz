import type { IDisposableLike } from '../../types/Disposable';
import type { IEventDispatcher } from '../interfaces/IEventDispatcher';
import type { IEventOptions } from '../interfaces/IEventOptions';
import type { IEventEmitter, IReadonlyEventEmitter } from './interfaces/IEventEmitter';
/**
 * The `EventEmitter` class.
 *
 * @public
 */
export declare class HTMLElementEventEmitter<TDetail = unknown> implements IEventEmitter<TDetail> {
    private readonly _dispatcher?;
    private readonly _eventName?;
    private readonly _options?;
    /**
     * Constructs a new instance of the `EventEmitter` class.
     *
     * * Important: If the EventEmitter uses with a Event decorator, the constructor parameters could be ignored.
     *
     * @public
     */
    constructor(dispatcher?: IEventDispatcher, eventName?: string, options?: IEventOptions);
    /**
     * Emits an event with the given detail.
     *
     * @public
     */
    emit(detail?: TDetail): void;
    subscribe(_handler: (data?: TDetail) => void): IDisposableLike;
    unsubscribe(_handler: (data?: TDetail) => void): void;
    toReadonly(): IReadonlyEventEmitter<TDetail>;
}
//# sourceMappingURL=HTMLElementEventEmitter.d.ts.map