// #region Imports
import { IDisposableLike } from '../../types/Disposable';
// #endregion
/**
 * The `PureEventEmitter` class is a simple implementation of the `IEventEmitter` interface.
 * It is used to emit events and subscribe to them when the target of the emit decorator is not an HTMLElement.
 *
 * @public
 */
export class PureEventEmitter {
    _observers = [];
    // #region Methods
    emit(value) {
        for (const observer of this._observers) {
            observer(value);
        }
    }
    subscribe(observer) {
        this._observers.push(observer);
        // Return an object with a dispose method
        return IDisposableLike.create(() => {
            this.unsubscribe(observer);
        });
    }
    unsubscribe(observer) {
        const index = this._observers.indexOf(observer);
        if (index > -1) {
            this._observers.splice(index, 1);
        }
    }
    toReadonly() {
        return {
            subscribe: this.subscribe.bind(this),
            unsubscribe: this.unsubscribe.bind(this)
        };
    }
}
//# sourceMappingURL=PureEventEmitter.js.map