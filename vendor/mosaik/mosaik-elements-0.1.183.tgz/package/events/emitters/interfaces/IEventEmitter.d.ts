import type { IDisposableLike } from '../../../types/Disposable';
/**
 * @public
 */
export interface IEventEmitter<TDetail = void> {
    emit(detail?: TDetail): void;
    subscribe(handler: (detail?: TDetail) => void): IDisposableLike;
    unsubscribe(handler: (detail?: TDetail) => void): void;
}
export interface IReadonlyEventEmitter<TDetail = void> extends Omit<IEventEmitter<TDetail>, 'emit'> {
}
//# sourceMappingURL=IEventEmitter.d.ts.map