import { IDisposableLike } from '../../types/Disposable';
import type { IEventEmitter, IReadonlyEventEmitter } from './interfaces/IEventEmitter';
/**
 * The `PureEventEmitter` class is a simple implementation of the `IEventEmitter` interface.
 * It is used to emit events and subscribe to them when the target of the emit decorator is not an HTMLElement.
 *
 * @public
 */
export declare class PureEventEmitter<T> implements IEventEmitter<T> {
    private readonly _observers;
    emit(value?: T): void;
    subscribe(observer: (value?: T) => void): IDisposableLike;
    unsubscribe(observer: (value?: T) => void): void;
    toReadonly(): IReadonlyEventEmitter<T>;
}
//# sourceMappingURL=PureEventEmitter.d.ts.map