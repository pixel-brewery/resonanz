// #region Imports
// #endregion
/**
 * The `EventEmitter` class.
 *
 * @public
 */
export class HTMLElementEventEmitter {
    // #region Fields
    _dispatcher;
    _eventName;
    _options;
    // #endregion
    // #region Ctor
    /**
     * Constructs a new instance of the `EventEmitter` class.
     *
     * * Important: If the EventEmitter uses with a Event decorator, the constructor parameters could be ignored.
     *
     * @public
     */
    constructor(dispatcher, eventName, options) {
        this._dispatcher = dispatcher;
        this._eventName = eventName;
        this._options = options;
    }
    // #endregion
    // #region Methods
    /**
     * Emits an event with the given detail.
     *
     * @public
     */
    emit(detail) {
        if (!this._dispatcher) {
            const exceptionMessage = 'The dispatcher could not be null.';
            throw new Error(exceptionMessage);
        }
        if (!this._eventName) {
            const exceptionMessage = 'The event name could not be null.';
            throw new Error(exceptionMessage);
        }
        this._dispatcher.dispatchEvent(new CustomEvent(this._eventName, {
            bubbles: this._options?.bubbles ?? true,
            cancelable: this._options?.cancelable ?? false,
            composed: this._options?.composed ?? true,
            detail
        }));
    }
    subscribe(_handler) {
        throw new Error('Method not implemented.');
    }
    unsubscribe(_handler) {
        throw new Error('Method not implemented.');
    }
    toReadonly() {
        return {
            subscribe: this.subscribe.bind(this),
            unsubscribe: this.unsubscribe.bind(this)
        };
    }
}
//# sourceMappingURL=HTMLElementEventEmitter.js.map