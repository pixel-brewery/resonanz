// #region Imports
// #endregion
/**
 * The `EventListenerSubscription` class.
 *
 * @public
 */
export class EventListenerSubscription {
    // #region Fields
    _eventName;
    _listener;
    _dispose;
    _isDisposed;
    // #endregion
    // #region Ctor
    /**
     * Constructs a new instance of the `EventListenerSubscription` class.
     *
     * @private
     */
    constructor(eventName, listener, dispose) {
        this._eventName = eventName;
        this._listener = listener;
        this._dispose = dispose;
        this._isDisposed = false;
    }
    // #endregion
    // #region Properties
    /**
     * Returns the `eventName` property.
     *
     * @public
     * @readonly
     */
    get eventName() {
        return this._eventName;
    }
    /**
     * Returns the `listener` property.
     *
     * @public
     * @readonly
     */
    get listener() {
        return this._listener;
    }
    // #endregion
    // #region Methods
    /**
     * @public
     * @static
     */
    static create(eventName, listener, dispose) {
        return new EventListenerSubscription(eventName, listener, dispose);
    }
    /**
     * @public
     */
    invoke(event) {
        if (this._isDisposed) {
            return;
        }
        this._listener(event);
    }
    /**
     * @public
     */
    dispose() {
        if (this._isDisposed) {
            return;
        }
        this._dispose(this);
        this._isDisposed = true;
    }
}
//# sourceMappingURL=EventListenerSubscription.js.map