/**
 * The isEventListenerSubscription() method determines whether an object is an `{@link IEventListenerSubscription}`
 * This function returns true if the object is an `{@link IEventListenerSubscription}`, and false if not.
 *
 * @public
 * @param value The value to check.
 */
export function isEventListenerSubscription(value) {
    if (!value || typeof value !== 'object') {
        return false;
    }
    const candidate = value;
    return typeof candidate.eventName === 'string' && typeof candidate.dispose === 'function' && typeof candidate.invoke === 'function';
}
//# sourceMappingURL=IEventListenerSubscription.js.map