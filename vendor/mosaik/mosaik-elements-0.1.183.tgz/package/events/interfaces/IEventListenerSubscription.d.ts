/**
 * Represents the `IEventListenerSubscription` interface.
 *
 * @public
 */
export interface IEventListenerSubscription {
    readonly eventName: string;
    dispose(): void;
    invoke(e: Event): void;
}
/**
 * The isEventListenerSubscription() method determines whether an object is an `{@link IEventListenerSubscription}`
 * This function returns true if the object is an `{@link IEventListenerSubscription}`, and false if not.
 *
 * @public
 * @param value The value to check.
 */
export declare function isEventListenerSubscription(value: unknown): value is IEventListenerSubscription;
//# sourceMappingURL=IEventListenerSubscription.d.ts.map