/**
 * @public
 */
export interface IEventDispatcher {
    dispatchEvent(event: Event): boolean;
}
//# sourceMappingURL=IEventDispatcher.d.ts.map