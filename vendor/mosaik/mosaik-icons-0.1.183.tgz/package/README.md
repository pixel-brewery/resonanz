# @pixel-brewery/mosaik-icons

Icon types, adapters and generated icon sets for Mosaik. Contains no UI.

## What is in here

The package root carries **no icon data at all** - only the types, the resolving
registry and the format adapters. Icon sets live behind their own import paths, with
one named export per icon, so an application only bundles the icons it imports.

```
@pixel-brewery/mosaik-icons            types, registry, adapters
@pixel-brewery/mosaik-icons/fluent-ui/filled        Fluent UI, filled
@pixel-brewery/mosaik-icons/lucide                  Lucide
@pixel-brewery/mosaik-icons/reicon                  Reicon
@pixel-brewery/mosaik-icons/reicon/flags            Reicon country flags
@pixel-brewery/mosaik-icons/reicon/social-media     Reicon brands and social media
@pixel-brewery/mosaik-icons/reicon/glass            Reicon glass icons
@pixel-brewery/mosaik-icons/tabler-icons            Tabler Icons
@pixel-brewery/mosaik-icons/phosphor-icons/regular  Phosphor Icons, regular
@pixel-brewery/mosaik-icons/remixicon               Remixicon
```

**Mosaik has no icon library of its own.** The set the components were drawn with is
[Fluent UI System Icons](https://github.com/microsoft/fluentui-system-icons) by
Microsoft, published here as `/fluent-ui/filled`.

## Usage

```ts
import { registerIcons } from '@pixel-brewery/mosaik-icons';
import { lucideCalendar, lucideTrash } from '@pixel-brewery/mosaik-icons/lucide';

registerIcons({ calendar: lucideCalendar, trash: lucideTrash });
```

```html
<mosaik-icon icon="calendar"></mosaik-icon>
<mosaik-icon icon="lucide:calendar"></mosaik-icon>
<mosaik-icon icon="trash" label="Delete"></mosaik-icon>
```

Foundation controls install their minimal semantic core automatically. Applications only
call `registerIcons` for their own icons or overrides. Angular exposes the same optional
override through `provideIcons`; no provider is required for the Foundation defaults.

Complete semantic presets are deliberately separate Foundation subpaths:

```ts
import { registerIconSet, setDefaultIconSet } from '@pixel-brewery/mosaik-icons';
import { LucideAliases } from '@pixel-brewery/mosaik-elements-foundation/icons/lucide';

registerIconSet('lucide', LucideAliases);
setDefaultIconSet('lucide');
```

## Any other icon library

Three adapters cover every format an icon package is published in. Nothing beyond
these is needed to reach a library Mosaik does not ship a set for.

| Adapter | Covers |
| --- | --- |
| `fromNodes` | `[tag, attrs][]` node arrays - Lucide, Tabler, Hugeicons |
| `fromSvg` | raw `.svg` files, SVG string constants, `toSvg()` factories |
| `fromIconify` | the 220 sets published as `@iconify-json/*` |

```ts
import { Calendar } from 'lucide';
import { fromNodes, LucideDefaults, registerIcons } from '@pixel-brewery/mosaik-icons';

registerIcons({ calendar: fromNodes(Calendar, LucideDefaults)! });
```

## The alias catalog

`IconCatalog.CORE` lives in Foundation and is the vocabulary Mosaik's own components
address. Every offered Foundation preset serves all of it. Foundation's automatic Reicon
fallback imports only this core; application definitions always override it.

## Regenerating a set

Sets are generated from the installed source library's npm package or its configured
Git repository, driven by the `icons:generate` target in `project.json`. The task then
cleans and builds this package and refreshes the Showcase icon manifest and search index.
Filtered runs perform the same follow-up steps and preserve the other generated sets.

```sh
yarn nx run mosaik-icons:icons:generate
yarn nx run mosaik-icons:icons:generate --only=lucide
```

Generation reads installed npm versions; update a source dependency before generating
when newer icons were added upstream. Git sources follow their configured `gitRef`.
Reicon Outline and Filled use the installed `reicon` package; Duotone, Flags, Social
Media and Glass use its Git source. Glass is produced with Reicon's own converter from
the filled dataset, retaining its SVG filters, masks and gradients.

To refresh the Showcase index from existing sources without regenerating upstream icons:

```sh
yarn nx run mosaik-showcase:icons:index
```
