/**
 * Points every unprefixed icon name at a registered set.
 * Every mounted icon re-resolves, so this switches the whole application's
 * iconography in one call.
 *
 * @param set The set name.
 * @public
 */
export declare function setDefaultIconSet(set: string): void;
//# sourceMappingURL=setDefaultIconSet.d.ts.map