// #region Imports
import { IconRegistry } from './IconRegistry';
// #endregion
/**
 * Installs a resolver for names that are not registered, for cases where registering
 * a whole set up front is not sensible - an icon picker, a gallery, or icons that are
 * chosen by data rather than by a template.
 *
 * @param loader The resolver, or `null` to remove the current one.
 * @public
 *
 * @example
 * ```ts
 * setIconLoader(async (name) => {
 *     const response = await fetch(`/icons/${name}.svg`);
 *
 *     return response.ok ? response.text() : null;
 * });
 * ```
 */
export function setIconLoader(loader) {
    IconRegistry.instance.setLoader(loader);
}
