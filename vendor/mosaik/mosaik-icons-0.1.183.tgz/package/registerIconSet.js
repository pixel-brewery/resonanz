// #region Imports
import { IconRegistry } from './IconRegistry';
// #endregion
/**
 * Registers icons in a named set, so that they can be addressed as `set:name`
 * and switched to wholesale with `setDefaultIconSet`.
 *
 * @param set The set name.
 * @param icons A map of icon name to source.
 * @public
 *
 * @example
 * ```ts
 * import { lucideCalendar } from '@pixel-brewery/mosaik-icons/lucide';
 * import { tablerCalendar } from '@pixel-brewery/mosaik-icons/tabler-icons';
 *
 * registerIconSet('lucide', { calendar: lucideCalendar });
 * registerIconSet('tabler', { calendar: tablerCalendar });
 * setDefaultIconSet('lucide');
 * ```
 */
export function registerIconSet(set, icons) {
    IconRegistry.instance.registerSet(set, icons);
}
