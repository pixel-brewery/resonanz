// #region Imports
import { IconSanitizer } from './IconSanitizer';
// #endregion
/**
 * Resolves icon names to renderable definitions.
 *
 * The registry itself is intentionally empty when this package is loaded. A component
 * library may install a small fallback vocabulary, while applications register or load
 * every additional icon explicitly.
 *
 * @public
 */
export class IconRegistry {
    // #region Fields
    static _instance = null;
    _sets;
    _pending;
    _listeners;
    _defaultSet;
    _loader;
    _warned;
    // #endregion
    // #region Ctor
    /**
     * Constructs a new instance of the `IconRegistry` class.
     *
     * @public
     */
    constructor() {
        this._sets = new Map();
        this._pending = new Map();
        this._listeners = new Set();
        this._defaultSet = IconRegistry.DEFAULT_SET;
        this._loader = null;
        this._warned = new Set();
    }
    // #endregion
    // #region Properties
    /**
     * The name of the implicit set that unprefixed names resolve against
     * when no other default has been configured.
     *
     * @public
     * @static
     * @readonly
     */
    static get DEFAULT_SET() {
        return 'default';
    }
    /**
     * Accesses the singleton instance.
     *
     * @public
     * @static
     * @readonly
     */
    static get instance() {
        if (!IconRegistry._instance) {
            IconRegistry._instance = new IconRegistry();
        }
        return IconRegistry._instance;
    }
    /**
     * Gets the name of the set that unprefixed names resolve against.
     *
     * @public
     */
    get defaultSet() {
        return this._defaultSet;
    }
    /**
     * Gets the names of all registered sets.
     *
     * @public
     * @readonly
     */
    get sets() {
        return [...this._sets.keys()];
    }
    // #endregion
    // #region Methods
    /**
     * Registers icons in the default set.
     *
     * @param icons A map of icon name to source.
     * @public
     */
    register(icons) {
        this.registerSet(this._defaultSet, icons);
    }
    /**
     * Registers non-overwriting icons in the implicit default set.
     *
     * This is intended for a component library's built-in semantic vocabulary. An
     * application registration always wins, regardless of module evaluation order, and
     * a selected named set can still fall back to these definitions for missing names.
     *
     * @param icons A map of fallback icon name to source.
     * @public
     */
    registerFallbacks(icons) {
        this.registerIntoSet(IconRegistry.DEFAULT_SET, icons, false);
    }
    /**
     * Registers icons in a named set.
     *
     * @param set The set name, used as the prefix in `set:name`.
     * @param icons A map of icon name to source.
     * @public
     */
    registerSet(set, icons) {
        this.registerIntoSet(set, icons, true);
    }
    /**
     * Registers icons in a set.
     *
     * @param set The target set.
     * @param icons A map of icon name to source.
     * @param overwrite Whether an existing definition may be replaced.
     * @private
     */
    registerIntoSet(set, icons, overwrite) {
        const target = this.ensureSet(set);
        let changed = false;
        const register = (name, definition) => {
            if (!overwrite && target.has(name)) {
                return;
            }
            target.set(name, definition);
            changed = true;
        };
        for (const [name, value] of Object.entries(icons)) {
            if (!name || value === undefined || value === null) {
                continue;
            }
            if (typeof value === 'object' && 'data' in value) {
                const definition = this.normalize(value.data);
                if (!definition) {
                    continue;
                }
                register(name, definition);
                const aliases = value.alias === undefined
                    ? []
                    : Array.isArray(value.alias) ? value.alias : [value.alias];
                for (const alias of aliases) {
                    register(alias, definition);
                }
            }
            else {
                const definition = this.normalize(value);
                if (definition) {
                    register(name, definition);
                }
            }
        }
        if (changed) {
            this.notify();
        }
    }
    /**
     * Sets the set that unprefixed names resolve against and notifies every listener,
     * so that elements re-render against the new set.
     *
     * @param set The set name.
     * @public
     */
    setDefaultSet(set) {
        if (this._defaultSet === set) {
            return;
        }
        this._defaultSet = set;
        this._warned.clear();
        this.notify();
    }
    /**
     * Installs a resolver for names that are not registered.
     *
     * @param loader The resolver, or `null` to remove the current one.
     * @public
     */
    setLoader(loader) {
        this._loader = loader;
        this._pending.clear();
        this._warned.clear();
    }
    /**
     * Resolves a name to a definition, without consulting the loader.
     * Returns `null` when the name is unknown.
     *
     * @param name The icon name, with or without a set prefix.
     * @public
     */
    resolve(name) {
        const { set, key } = this.split(name);
        const target = this._sets.get(set);
        const definition = target?.get(key) ?? null;
        if (definition) {
            return definition;
        }
        // An unprefixed name that the default set does not carry may still live in the
        // implicit set, which is where `register()` without a set name puts things.
        if (set !== IconRegistry.DEFAULT_SET && !name.includes(':')) {
            return this._sets.get(IconRegistry.DEFAULT_SET)?.get(key) ?? null;
        }
        return null;
    }
    /**
     * Resolves a name, consulting the loader when the name is not registered.
     * The result of a loader call is cached, including a negative one.
     *
     * @param name The icon name, with or without a set prefix.
     * @public
     */
    async resolveAsync(name) {
        const known = this.resolve(name);
        if (known || !this._loader) {
            return known;
        }
        const cached = this._pending.get(name);
        if (cached) {
            return cached;
        }
        const { set, key } = this.split(name);
        const request = Promise.resolve(this._loader(key, name.includes(':') ? set : null))
            .then((source) => {
            const definition = source === null || source === undefined ? null : this.normalize(source);
            if (definition) {
                this.ensureSet(set).set(key, definition);
                this.notify();
            }
            return definition;
        })
            .catch(() => null);
        this._pending.set(name, request);
        return request;
    }
    /**
     * Reports which of the given names the registry cannot resolve right now.
     *
     * An application uses this to prove that the vocabulary it addresses is covered by
     * the sets it registered. That matters because only the core catalog is guaranteed
     * across sets - an extended alias exists only in the sets whose source library has
     * it, so switching the default set can silently drop icons.
     *
     * @param names The icon names to check.
     * @returns The names that do not resolve, empty when all of them do.
     * @public
     *
     * @example
     * ```ts
     * const missing = IconRegistry.instance.findUnresolved(Object.values(Icons));
     *
     * expect(missing).toEqual([]);
     * ```
     */
    findUnresolved(names) {
        const unresolved = [];
        for (const name of names) {
            if (!this.resolve(name)) {
                unresolved.push(name);
            }
        }
        return unresolved;
    }
    /**
     * Subscribes to registry changes. The returned function removes the subscription.
     *
     * @param listener The callback invoked after every change.
     * @public
     */
    subscribe(listener) {
        this._listeners.add(listener);
        return () => {
            this._listeners.delete(listener);
        };
    }
    /**
     * Reports an unresolved name once per name, so that a typo does not flood the console
     * and does not take a view down the way a thrown error would.
     *
     * @param name The unresolved name.
     * @public
     */
    warnUnresolved(name) {
        if (this._warned.has(name)) {
            return;
        }
        this._warned.add(name);
        console.warn(`[IconRegistry]: No icon registered for "${name}". Import and register the required named icons or a Foundation preset.`);
    }
    /**
     * Removes every registration. Intended for tests.
     *
     * @public
     */
    clear() {
        this._sets.clear();
        this._pending.clear();
        this._warned.clear();
        this._defaultSet = IconRegistry.DEFAULT_SET;
        this.notify();
    }
    /**
     * Converts any accepted source into a definition.
     * Markup is parsed, path data is wrapped, a definition is sanitized and passed through.
     *
     * @param source The source to normalize.
     * @public
     */
    normalize(source) {
        if (source === null || source === undefined) {
            return null;
        }
        if (typeof source === 'object') {
            return {
                ...source,
                body: IconSanitizer.sanitize(source.body)
            };
        }
        const value = source.trim();
        if (!value) {
            return null;
        }
        if (value.startsWith('<')) {
            return IconRegistry.fromMarkup(value);
        }
        return {
            body: `<path fill="currentColor" d="${IconRegistry.escapeAttribute(value)}"/>`
        };
    }
    /**
     * Parses a complete `<svg>` document into a definition.
     * Kept static so that the adapters can reuse it without an instance.
     *
     * @param markup The SVG markup.
     * @public
     * @static
     */
    static fromMarkup(markup) {
        const open = (/<svg\b([^>]*)>/i).exec(markup);
        if (!open) {
            return { body: IconSanitizer.sanitize(markup) };
        }
        const attributes = open[1];
        const close = markup.lastIndexOf('</svg');
        const inner = close === -1
            ? markup.slice(open.index + open[0].length)
            : markup.slice(open.index + open[0].length, close);
        const definition = {
            body: IconSanitizer.sanitize(inner.trim())
        };
        const viewBox = (/viewBox\s*=\s*["']([^"']+)["']/i).exec(attributes);
        if (viewBox) {
            const parts = viewBox[1].split(/[\s,]+/).map(Number);
            if (parts.length === 4 && !parts.some(Number.isNaN)) {
                definition.left = parts[0];
                definition.top = parts[1];
                definition.width = parts[2];
                definition.height = parts[3];
            }
        }
        else {
            const width = (/\bwidth\s*=\s*["']?(\d+(?:\.\d+)?)/i).exec(attributes);
            const height = (/\bheight\s*=\s*["']?(\d+(?:\.\d+)?)/i).exec(attributes);
            if (width) {
                definition.width = Number(width[1]);
            }
            if (height) {
                definition.height = Number(height[1]);
            }
        }
        // Presentation attributes on the source root would be lost, because the element
        // owns the root. They are carried over onto a wrapping group instead.
        const carried = IconRegistry.carriedAttributes(attributes);
        if (carried) {
            definition.body = `<g ${carried}>${definition.body}</g>`;
        }
        return definition;
    }
    /**
     * Escapes a value for use inside a double quoted attribute.
     *
     * @param value The raw value.
     * @public
     * @static
     */
    static escapeAttribute(value) {
        return value.replace(/&/g, '&amp;').replace(/"/g, '&quot;')
            .replace(/</g, '&lt;');
    }
    /**
     * Collects the presentation attributes of a source `<svg>` root that have to survive
     * the move onto the element's own root.
     *
     * @param attributes The raw attribute string of the source root.
     * @private
     * @static
     */
    static carriedAttributes(attributes) {
        const carry = ['fill', 'stroke', 'stroke-width', 'stroke-linecap', 'stroke-linejoin', 'stroke-miterlimit', 'fill-rule', 'clip-rule', 'opacity'];
        const parts = [];
        for (const name of carry) {
            const match = new RegExp(`\\s${name}\\s*=\\s*["']([^"']*)["']`, 'i').exec(attributes);
            if (match) {
                parts.push(`${name}="${IconRegistry.escapeAttribute(match[1])}"`);
            }
        }
        return parts.join(' ');
    }
    /**
     * Splits a name into set and key.
     *
     * @param name The icon name.
     * @private
     */
    split(name) {
        const index = name.indexOf(':');
        if (index === -1) {
            return {
                set: this._defaultSet,
                key: name
            };
        }
        return {
            set: name.slice(0, index),
            key: name.slice(index + 1)
        };
    }
    /**
     * Returns the map for a set, creating it when needed.
     *
     * @param set The set name.
     * @private
     */
    ensureSet(set) {
        let target = this._sets.get(set);
        if (!target) {
            target = new Map();
            this._sets.set(set, target);
        }
        return target;
    }
    /**
     * Notifies every subscriber.
     *
     * @private
     */
    notify() {
        for (const listener of this._listeners) {
            listener();
        }
    }
}
