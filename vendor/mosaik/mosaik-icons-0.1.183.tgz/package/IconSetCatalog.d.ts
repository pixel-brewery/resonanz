import type { IIconDefinition } from './types/IIconDefinition';
/**
 * A lazily loadable generated icon-set entry.
 *
 * Importing the catalog loads metadata only. Icon definitions are fetched
 * only when `load()` is called for one entry.
 *
 * @public
 */
export interface IIconSetCatalogEntry {
    readonly id: string;
    readonly set: string;
    readonly variant: string | null;
    readonly iconPrefix: string;
    readonly iconSuffix: string | null;
    readonly load: () => Promise<Record<string, IIconDefinition>>;
}
/**
 * Every generated icon set and variant, without eagerly importing icon data.
 *
 * @public
 */
export declare const ICON_SET_CATALOG: ReadonlyArray<IIconSetCatalogEntry>;
//# sourceMappingURL=IconSetCatalog.d.ts.map