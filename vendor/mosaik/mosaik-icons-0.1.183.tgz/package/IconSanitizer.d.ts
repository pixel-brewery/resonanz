/**
 * Strips everything from icon markup that has no business being in an icon.
 *
 * Icon bodies reach the registry from generated set modules, from consumer code and -
 * in the loader case - from a network response. Because the body is rendered through
 * `unsafeSVG`, it is cleaned once here at registration time rather than on every render.
 *
 * @public
 */
export declare namespace IconSanitizer {
    /**
     * Removes active content from an icon body.
     *
     * @param body The raw inner SVG markup.
     * @returns The cleaned markup.
     * @public
     */
    function sanitize(body: string): string;
    /**
     * Determines whether a body contains anything the sanitizer would remove.
     * Used by the icon source generator to fail a build rather than ship stripped markup.
     *
     * @param body The raw inner SVG markup.
     * @public
     */
    function isClean(body: string): boolean;
}
//# sourceMappingURL=IconSanitizer.d.ts.map