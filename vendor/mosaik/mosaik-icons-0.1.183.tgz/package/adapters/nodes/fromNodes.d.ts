import { type IconNodeDefaults } from '../../types/IconNodeDefaults';
import { type IconNodeLike } from '../../types/IconNodeLike';
import { type IIconDefinition } from '../../types/IIconDefinition';
/**
 * Converts a node array into a definition.
 *
 * Covers Lucide (`IconNode`), Tabler (`tabler-nodes-*.json`) and Hugeicons
 * (`IconSvgObject`). Lucide keeps its presentation attributes in a separate
 * `defaultAttributes` module - pass it as `defaults`, or the icon renders unpainted.
 * Hugeicons carries them per node in React spelling, which is normalized here.
 *
 * @param nodes The node array.
 * @param defaults The set level attributes, when the set keeps them separately.
 * @returns The definition, or `null` when the input is empty.
 * @public
 *
 * @example
 * ```ts
 * import { Calendar } from 'lucide';
 * import { fromNodes, lucideDefaults } from '@pixel-brewery/mosaik-icons';
 *
 * fromNodes(Calendar, lucideDefaults);
 * ```
 */
export declare function fromNodes(nodes: ReadonlyArray<IconNodeLike> | null | undefined, defaults?: IconNodeDefaults): IIconDefinition | null;
//# sourceMappingURL=fromNodes.d.ts.map