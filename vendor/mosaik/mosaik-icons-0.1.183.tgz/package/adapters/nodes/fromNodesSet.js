// #region Imports
import { fromNodes } from './fromNodes';
// #endregion
/**
 * Converts a map of node arrays into a map of definitions.
 *
 * @param icons A map of icon name to node array.
 * @param defaults The set level attributes.
 * @returns A map of icon name to definition.
 * @public
 */
export function fromNodesSet(icons, defaults) {
    const result = {};
    for (const [name, nodes] of Object.entries(icons)) {
        const definition = fromNodes(nodes, defaults);
        if (definition) {
            result[name] = definition;
        }
    }
    return result;
}
