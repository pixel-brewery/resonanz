import { type IconNodeDefaults } from '../../types/IconNodeDefaults';
import { type IconNodeLike } from '../../types/IconNodeLike';
import { type IIconDefinition } from '../../types/IIconDefinition';
/**
 * Converts a map of node arrays into a map of definitions.
 *
 * @param icons A map of icon name to node array.
 * @param defaults The set level attributes.
 * @returns A map of icon name to definition.
 * @public
 */
export declare function fromNodesSet(icons: Record<string, ReadonlyArray<IconNodeLike>>, defaults?: IconNodeDefaults): Record<string, IIconDefinition>;
//# sourceMappingURL=fromNodesSet.d.ts.map