// #region Imports
import { IconRegistry } from '../../IconRegistry';
// #endregion
// #region Fields
/**
 * Attributes that describe the icon rather than paint it, and therefore
 * belong on the definition instead of on the markup.
 */
const DIMENSION_ATTRIBUTES = new Set(['xmlns', 'width', 'height', 'viewbox', 'class', 'key']);
/**
 * Attributes a bundler or framework adds that must not reach the DOM.
 */
const DROPPED_ATTRIBUTES = new Set(['key', 'ref', 'classname', 'class', 'xmlns']);
// #endregion
// #region Methods
/**
 * Converts a React style attribute name into its SVG spelling.
 * `strokeWidth` becomes `stroke-width`, `fill` stays `fill`.
 *
 * @param name The attribute name.
 */
function toAttributeName(name) {
    if (name.includes('-') || name.includes(':')) {
        return name;
    }
    return name.replace(/([a-z0-9])([A-Z])/g, '$1-$2').toLowerCase();
}
/**
 * Serializes one node into markup.
 *
 * @param node The node to serialize.
 */
function serialize(node) {
    const [tag, attributes] = node;
    const parts = [];
    for (const [rawName, rawValue] of Object.entries(attributes ?? {})) {
        if (rawValue === undefined || rawValue === null) {
            continue;
        }
        const name = toAttributeName(rawName);
        if (DROPPED_ATTRIBUTES.has(name)) {
            continue;
        }
        parts.push(`${name}="${IconRegistry.escapeAttribute(String(rawValue))}"`);
    }
    return parts.length > 0 ? `<${tag} ${parts.join(' ')}/>` : `<${tag}/>`;
}
/**
 * Splits set level defaults into the part that describes the view box and the
 * part that paints, because only the latter belongs in the markup.
 *
 * @param defaults The set level defaults.
 */
function splitDefaults(defaults) {
    const paint = [];
    let width;
    let height;
    let left;
    let top;
    for (const [rawName, rawValue] of Object.entries(defaults ?? {})) {
        if (rawValue === undefined || rawValue === null) {
            continue;
        }
        // The dimension check runs against the raw name, because `toAttributeName`
        // would turn `viewBox` into `view-box` and miss it.
        const lower = rawName.toLowerCase();
        const name = toAttributeName(rawName);
        if (!DIMENSION_ATTRIBUTES.has(lower)) {
            paint.push(`${name}="${IconRegistry.escapeAttribute(String(rawValue))}"`);
            continue;
        }
        if (lower === 'viewbox') {
            const numbers = String(rawValue).split(/[\s,]+/)
                .map(Number);
            if (numbers.length === 4 && !numbers.some(Number.isNaN)) {
                left = numbers[0];
                top = numbers[1];
                width = numbers[2];
                height = numbers[3];
            }
        }
        else if (lower === 'width') {
            width = width ?? Number(rawValue);
        }
        else if (lower === 'height') {
            height = height ?? Number(rawValue);
        }
    }
    return {
        paint: paint.join(' '),
        width,
        height,
        left,
        top
    };
}
// #endregion
/**
 * Converts a node array into a definition.
 *
 * Covers Lucide (`IconNode`), Tabler (`tabler-nodes-*.json`) and Hugeicons
 * (`IconSvgObject`). Lucide keeps its presentation attributes in a separate
 * `defaultAttributes` module - pass it as `defaults`, or the icon renders unpainted.
 * Hugeicons carries them per node in React spelling, which is normalized here.
 *
 * @param nodes The node array.
 * @param defaults The set level attributes, when the set keeps them separately.
 * @returns The definition, or `null` when the input is empty.
 * @public
 *
 * @example
 * ```ts
 * import { Calendar } from 'lucide';
 * import { fromNodes, lucideDefaults } from '@pixel-brewery/mosaik-icons';
 *
 * fromNodes(Calendar, lucideDefaults);
 * ```
 */
export function fromNodes(nodes, defaults) {
    if (!nodes || nodes.length === 0) {
        return null;
    }
    const body = nodes.map(serialize).join('');
    if (!body) {
        return null;
    }
    const { paint, width, height, left, top } = splitDefaults(defaults);
    const definition = {
        body: paint ? `<g ${paint}>${body}</g>` : body
    };
    if (width !== undefined) {
        definition.width = width;
    }
    if (height !== undefined) {
        definition.height = height;
    }
    if (left !== undefined && left !== 0) {
        definition.left = left;
    }
    if (top !== undefined && top !== 0) {
        definition.top = top;
    }
    return definition;
}
