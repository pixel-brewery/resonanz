import { type IIconDefinition } from '../../types/IIconDefinition';
import { type IIconifyIcon } from '../../types/IIconifyIcon';
/**
 * Converts an Iconify icon into a definition.
 *
 * Mosaik's definition shape is deliberately the same as Iconify's, so this is close
 * to an identity function. It exists so that the set level fallbacks for `width` and
 * `height` are applied, which Iconify keeps on the set rather than on the icon.
 *
 * With 220 sets published in this format, this one adapter reaches every icon library
 * that Mosaik does not ship a dedicated set for.
 *
 * @param icon The Iconify icon.
 * @param setDefaults The dimensions declared on the set.
 * @returns The definition, or `null` when the icon is empty or hidden.
 * @public
 *
 * @example
 * ```ts
 * import lucide from '@iconify-json/lucide/icons.json';
 *
 * fromIconify(lucide.icons['calendar'], lucide);
 * ```
 */
export declare function fromIconify(icon: IIconifyIcon | null | undefined, setDefaults?: {
    width?: number;
    height?: number;
}): IIconDefinition | null;
//# sourceMappingURL=fromIconify.d.ts.map