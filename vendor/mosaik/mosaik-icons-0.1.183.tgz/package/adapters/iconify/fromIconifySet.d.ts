import { type IIconDefinition } from '../../types/IIconDefinition';
import { type IIconifyJson } from '../../types/IIconifyJson';
/**
 * Converts a whole Iconify set into a map of definitions, resolving aliases.
 *
 * Registering a complete set is eager: every icon of the set reaches the bundle.
 * For large sets prefer registering single icons, or install a loader.
 *
 * @param set The Iconify set.
 * @returns A map of icon name to definition.
 * @public
 */
export declare function fromIconifySet(set: IIconifyJson): Record<string, IIconDefinition>;
//# sourceMappingURL=fromIconifySet.d.ts.map