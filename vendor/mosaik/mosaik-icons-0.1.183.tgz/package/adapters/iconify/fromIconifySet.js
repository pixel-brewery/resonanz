// #region Imports
import { fromIconify } from './fromIconify';
// #endregion
/**
 * Converts a whole Iconify set into a map of definitions, resolving aliases.
 *
 * Registering a complete set is eager: every icon of the set reaches the bundle.
 * For large sets prefer registering single icons, or install a loader.
 *
 * @param set The Iconify set.
 * @returns A map of icon name to definition.
 * @public
 */
export function fromIconifySet(set) {
    const result = {};
    for (const [name, icon] of Object.entries(set.icons ?? {})) {
        const definition = fromIconify(icon, set);
        if (definition) {
            result[name] = definition;
        }
    }
    for (const [name, alias] of Object.entries(set.aliases ?? {})) {
        const parent = result[alias.parent];
        if (parent) {
            result[name] = parent;
        }
    }
    return result;
}
