import { type IIconDefinition } from '../../types/IIconDefinition';
/**
 * Converts a complete `<svg>` document into a definition.
 *
 * This is the universal adapter. It covers raw `.svg` files (Phosphor, Remixicon,
 * Tabler, Fluent), SVG string constants (`@ng-icons/*`) and factory functions that
 * expose a `toSvg()` method (`reicon`, `lucide`'s `createElement`).
 *
 * @param markup The SVG markup, or a value that can produce it.
 * @returns The definition, or `null` when the input is empty.
 * @public
 *
 * @example
 * ```ts
 * import { Calendar } from 'reicon';
 * fromSvg(Calendar.toSvg());
 * ```
 */
export declare function fromSvg(markup: string | {
    toSvg: () => string;
} | null | undefined): IIconDefinition | null;
//# sourceMappingURL=fromSvg.d.ts.map