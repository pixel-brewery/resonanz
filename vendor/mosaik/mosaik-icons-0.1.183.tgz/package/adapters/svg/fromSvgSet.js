// #region Imports
import { fromSvg } from './fromSvg';
// #endregion
/**
 * Converts a map of SVG documents into a map of definitions.
 *
 * @param icons A map of icon name to SVG markup.
 * @returns A map of icon name to definition.
 * @public
 */
export function fromSvgSet(icons) {
    const result = {};
    for (const [name, markup] of Object.entries(icons)) {
        const definition = fromSvg(markup);
        if (definition) {
            result[name] = definition;
        }
    }
    return result;
}
