import { type IIconDefinition } from '../../types/IIconDefinition';
/**
 * Converts a map of SVG documents into a map of definitions.
 *
 * @param icons A map of icon name to SVG markup.
 * @returns A map of icon name to definition.
 * @public
 */
export declare function fromSvgSet(icons: Record<string, string>): Record<string, IIconDefinition>;
//# sourceMappingURL=fromSvgSet.d.ts.map