import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `circum-icons` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const CircumIconsDefaults: IconNodeDefaults;
//# sourceMappingURL=CircumIconsDefaults.d.ts.map