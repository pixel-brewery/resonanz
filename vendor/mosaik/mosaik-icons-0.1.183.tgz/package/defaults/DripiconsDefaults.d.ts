import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `dripicons` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const DripiconsDefaults: IconNodeDefaults;
//# sourceMappingURL=DripiconsDefaults.d.ts.map