import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `radix-icons` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const RadixIconsDefaults: IconNodeDefaults;
//# sourceMappingURL=RadixIconsDefaults.d.ts.map