import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `fluent-ui/48-filled` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const FluentUi48FilledDefaults: IconNodeDefaults;
//# sourceMappingURL=FluentUi48FilledDefaults.d.ts.map