import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `iconsax/outline` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const IconsaxOutlineDefaults: IconNodeDefaults;
//# sourceMappingURL=IconsaxOutlineDefaults.d.ts.map