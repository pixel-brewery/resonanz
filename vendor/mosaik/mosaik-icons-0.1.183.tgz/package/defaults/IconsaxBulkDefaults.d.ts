import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `iconsax/bulk` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const IconsaxBulkDefaults: IconNodeDefaults;
//# sourceMappingURL=IconsaxBulkDefaults.d.ts.map