import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `boxicons/regular` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const BoxiconsRegularDefaults: IconNodeDefaults;
//# sourceMappingURL=BoxiconsRegularDefaults.d.ts.map