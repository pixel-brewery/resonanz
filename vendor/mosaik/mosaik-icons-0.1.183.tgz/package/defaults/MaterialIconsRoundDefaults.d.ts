import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `material-icons/round` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const MaterialIconsRoundDefaults: IconNodeDefaults;
//# sourceMappingURL=MaterialIconsRoundDefaults.d.ts.map