import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `fluent-ui/10-filled` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const FluentUi10FilledDefaults: IconNodeDefaults;
//# sourceMappingURL=FluentUi10FilledDefaults.d.ts.map