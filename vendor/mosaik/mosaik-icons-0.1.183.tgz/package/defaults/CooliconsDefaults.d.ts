import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `coolicons` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const CooliconsDefaults: IconNodeDefaults;
//# sourceMappingURL=CooliconsDefaults.d.ts.map