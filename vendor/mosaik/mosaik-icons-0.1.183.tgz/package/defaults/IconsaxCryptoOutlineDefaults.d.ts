import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `iconsax/crypto-outline` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const IconsaxCryptoOutlineDefaults: IconNodeDefaults;
//# sourceMappingURL=IconsaxCryptoOutlineDefaults.d.ts.map