import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `lets-icons/fill` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const LetsIconsFillDefaults: IconNodeDefaults;
//# sourceMappingURL=LetsIconsFillDefaults.d.ts.map