import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `iconsax/crypto-bulk` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const IconsaxCryptoBulkDefaults: IconNodeDefaults;
//# sourceMappingURL=IconsaxCryptoBulkDefaults.d.ts.map