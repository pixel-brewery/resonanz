import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `primeicons` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const PrimeiconsDefaults: IconNodeDefaults;
//# sourceMappingURL=PrimeiconsDefaults.d.ts.map