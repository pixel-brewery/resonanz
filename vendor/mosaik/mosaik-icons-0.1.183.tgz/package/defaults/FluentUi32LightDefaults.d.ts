import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `fluent-ui/32-light` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const FluentUi32LightDefaults: IconNodeDefaults;
//# sourceMappingURL=FluentUi32LightDefaults.d.ts.map