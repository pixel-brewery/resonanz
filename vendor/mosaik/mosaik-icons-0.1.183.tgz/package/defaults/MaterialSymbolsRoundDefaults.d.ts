import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `material-symbols/round` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const MaterialSymbolsRoundDefaults: IconNodeDefaults;
//# sourceMappingURL=MaterialSymbolsRoundDefaults.d.ts.map