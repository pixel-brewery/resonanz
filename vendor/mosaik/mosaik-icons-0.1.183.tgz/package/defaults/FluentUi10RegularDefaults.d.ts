import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `fluent-ui/10-regular` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const FluentUi10RegularDefaults: IconNodeDefaults;
//# sourceMappingURL=FluentUi10RegularDefaults.d.ts.map