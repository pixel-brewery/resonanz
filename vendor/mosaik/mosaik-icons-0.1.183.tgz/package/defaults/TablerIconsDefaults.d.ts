import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `tabler-icons` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const TablerIconsDefaults: IconNodeDefaults;
//# sourceMappingURL=TablerIconsDefaults.d.ts.map