import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `simple-icons` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const SimpleIconsDefaults: IconNodeDefaults;
//# sourceMappingURL=SimpleIconsDefaults.d.ts.map