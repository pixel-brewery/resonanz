import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `devicon/line` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const DeviconLineDefaults: IconNodeDefaults;
//# sourceMappingURL=DeviconLineDefaults.d.ts.map