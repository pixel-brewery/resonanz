import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `phosphor-icons/bold` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const PhosphorIconsBoldDefaults: IconNodeDefaults;
//# sourceMappingURL=PhosphorIconsBoldDefaults.d.ts.map