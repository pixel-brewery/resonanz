import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `mynaui/outline` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const MynauiOutlineDefaults: IconNodeDefaults;
//# sourceMappingURL=MynauiOutlineDefaults.d.ts.map