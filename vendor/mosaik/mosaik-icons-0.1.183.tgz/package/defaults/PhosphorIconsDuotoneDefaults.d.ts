import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `phosphor-icons/duotone` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const PhosphorIconsDuotoneDefaults: IconNodeDefaults;
//# sourceMappingURL=PhosphorIconsDuotoneDefaults.d.ts.map