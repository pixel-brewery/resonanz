import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `boxicons/logos` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const BoxiconsLogosDefaults: IconNodeDefaults;
//# sourceMappingURL=BoxiconsLogosDefaults.d.ts.map