import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `heroicons/outline` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const HeroiconsOutlineDefaults: IconNodeDefaults;
//# sourceMappingURL=HeroiconsOutlineDefaults.d.ts.map