import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `material-icons/twotone` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const MaterialIconsTwotoneDefaults: IconNodeDefaults;
//# sourceMappingURL=MaterialIconsTwotoneDefaults.d.ts.map