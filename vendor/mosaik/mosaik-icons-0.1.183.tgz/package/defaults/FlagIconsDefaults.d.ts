import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `flag-icons` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const FlagIconsDefaults: IconNodeDefaults;
//# sourceMappingURL=FlagIconsDefaults.d.ts.map