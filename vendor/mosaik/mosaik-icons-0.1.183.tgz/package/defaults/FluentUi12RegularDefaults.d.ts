import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `fluent-ui/12-regular` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const FluentUi12RegularDefaults: IconNodeDefaults;
//# sourceMappingURL=FluentUi12RegularDefaults.d.ts.map