import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `reicon` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const ReiconDefaults: IconNodeDefaults;
//# sourceMappingURL=ReiconDefaults.d.ts.map