import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `material-icons/baseline` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const MaterialIconsBaselineDefaults: IconNodeDefaults;
//# sourceMappingURL=MaterialIconsBaselineDefaults.d.ts.map