import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `phosphor-icons/light` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const PhosphorIconsLightDefaults: IconNodeDefaults;
//# sourceMappingURL=PhosphorIconsLightDefaults.d.ts.map