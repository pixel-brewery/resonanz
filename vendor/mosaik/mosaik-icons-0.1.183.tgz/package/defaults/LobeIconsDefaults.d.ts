import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `lobe-icons` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const LobeIconsDefaults: IconNodeDefaults;
//# sourceMappingURL=LobeIconsDefaults.d.ts.map