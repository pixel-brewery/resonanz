import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `lobe-icons/text-cn` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const LobeIconsTextCnDefaults: IconNodeDefaults;
//# sourceMappingURL=LobeIconsTextCnDefaults.d.ts.map