import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `iconoir/regular` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const IconoirRegularDefaults: IconNodeDefaults;
//# sourceMappingURL=IconoirRegularDefaults.d.ts.map