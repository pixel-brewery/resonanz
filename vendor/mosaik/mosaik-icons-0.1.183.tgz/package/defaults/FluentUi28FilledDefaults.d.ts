import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `fluent-ui/28-filled` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const FluentUi28FilledDefaults: IconNodeDefaults;
//# sourceMappingURL=FluentUi28FilledDefaults.d.ts.map