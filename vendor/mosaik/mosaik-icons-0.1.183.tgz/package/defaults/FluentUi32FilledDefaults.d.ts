import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `fluent-ui/32-filled` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const FluentUi32FilledDefaults: IconNodeDefaults;
//# sourceMappingURL=FluentUi32FilledDefaults.d.ts.map