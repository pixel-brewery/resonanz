import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `tabler-icons/fill` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const TablerIconsFillDefaults: IconNodeDefaults;
//# sourceMappingURL=TablerIconsFillDefaults.d.ts.map