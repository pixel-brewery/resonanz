import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `fluent-ui/12-filled` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const FluentUi12FilledDefaults: IconNodeDefaults;
//# sourceMappingURL=FluentUi12FilledDefaults.d.ts.map