import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `keyline-icons/duotone` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const KeylineIconsDuotoneDefaults: IconNodeDefaults;
//# sourceMappingURL=KeylineIconsDuotoneDefaults.d.ts.map