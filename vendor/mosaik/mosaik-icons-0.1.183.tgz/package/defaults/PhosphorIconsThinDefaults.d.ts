import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `phosphor-icons/thin` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const PhosphorIconsThinDefaults: IconNodeDefaults;
//# sourceMappingURL=PhosphorIconsThinDefaults.d.ts.map