import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `feather-icons` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const FeatherIconsDefaults: IconNodeDefaults;
//# sourceMappingURL=FeatherIconsDefaults.d.ts.map