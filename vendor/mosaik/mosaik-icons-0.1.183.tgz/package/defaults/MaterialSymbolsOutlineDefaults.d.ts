import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `material-symbols/outline` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const MaterialSymbolsOutlineDefaults: IconNodeDefaults;
//# sourceMappingURL=MaterialSymbolsOutlineDefaults.d.ts.map