import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `iconsax/bold` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const IconsaxBoldDefaults: IconNodeDefaults;
//# sourceMappingURL=IconsaxBoldDefaults.d.ts.map