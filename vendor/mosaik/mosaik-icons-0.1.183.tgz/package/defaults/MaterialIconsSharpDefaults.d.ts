import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `material-icons/sharp` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const MaterialIconsSharpDefaults: IconNodeDefaults;
//# sourceMappingURL=MaterialIconsSharpDefaults.d.ts.map