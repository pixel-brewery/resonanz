import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `phosphor-icons/regular` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const PhosphorIconsRegularDefaults: IconNodeDefaults;
//# sourceMappingURL=PhosphorIconsRegularDefaults.d.ts.map