import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `iconoir/solid` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const IconoirSolidDefaults: IconNodeDefaults;
//# sourceMappingURL=IconoirSolidDefaults.d.ts.map