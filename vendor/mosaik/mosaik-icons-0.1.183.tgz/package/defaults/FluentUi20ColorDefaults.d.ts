import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `fluent-ui/20-color` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const FluentUi20ColorDefaults: IconNodeDefaults;
//# sourceMappingURL=FluentUi20ColorDefaults.d.ts.map