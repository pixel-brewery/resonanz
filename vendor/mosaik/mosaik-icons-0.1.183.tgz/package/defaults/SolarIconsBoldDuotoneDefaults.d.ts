import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `solar-icons/bold-duotone` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const SolarIconsBoldDuotoneDefaults: IconNodeDefaults;
//# sourceMappingURL=SolarIconsBoldDuotoneDefaults.d.ts.map