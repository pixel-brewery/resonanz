import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `reicon/fill` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const ReiconFillDefaults: IconNodeDefaults;
//# sourceMappingURL=ReiconFillDefaults.d.ts.map