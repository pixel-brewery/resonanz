import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `heroicons/micro` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const HeroiconsMicroDefaults: IconNodeDefaults;
//# sourceMappingURL=HeroiconsMicroDefaults.d.ts.map