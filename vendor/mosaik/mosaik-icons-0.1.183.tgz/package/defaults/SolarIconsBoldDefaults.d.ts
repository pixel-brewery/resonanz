import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `solar-icons/bold` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const SolarIconsBoldDefaults: IconNodeDefaults;
//# sourceMappingURL=SolarIconsBoldDefaults.d.ts.map