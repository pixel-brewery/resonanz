import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `solar-icons/linear` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const SolarIconsLinearDefaults: IconNodeDefaults;
//# sourceMappingURL=SolarIconsLinearDefaults.d.ts.map