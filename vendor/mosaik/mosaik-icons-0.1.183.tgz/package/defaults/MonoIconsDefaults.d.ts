import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `mono-icons` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const MonoIconsDefaults: IconNodeDefaults;
//# sourceMappingURL=MonoIconsDefaults.d.ts.map