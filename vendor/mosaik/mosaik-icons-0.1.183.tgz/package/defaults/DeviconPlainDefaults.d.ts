import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `devicon/plain` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const DeviconPlainDefaults: IconNodeDefaults;
//# sourceMappingURL=DeviconPlainDefaults.d.ts.map