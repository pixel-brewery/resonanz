import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `lets-icons/regular` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const LetsIconsRegularDefaults: IconNodeDefaults;
//# sourceMappingURL=LetsIconsRegularDefaults.d.ts.map