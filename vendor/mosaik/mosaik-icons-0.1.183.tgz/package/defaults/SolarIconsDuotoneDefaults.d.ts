import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `solar-icons/duotone` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const SolarIconsDuotoneDefaults: IconNodeDefaults;
//# sourceMappingURL=SolarIconsDuotoneDefaults.d.ts.map