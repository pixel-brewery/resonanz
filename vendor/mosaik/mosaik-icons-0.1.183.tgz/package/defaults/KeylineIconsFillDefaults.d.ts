import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `keyline-icons/fill` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const KeylineIconsFillDefaults: IconNodeDefaults;
//# sourceMappingURL=KeylineIconsFillDefaults.d.ts.map