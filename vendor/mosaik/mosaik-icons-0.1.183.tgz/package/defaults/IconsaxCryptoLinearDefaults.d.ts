import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `iconsax/crypto-linear` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const IconsaxCryptoLinearDefaults: IconNodeDefaults;
//# sourceMappingURL=IconsaxCryptoLinearDefaults.d.ts.map