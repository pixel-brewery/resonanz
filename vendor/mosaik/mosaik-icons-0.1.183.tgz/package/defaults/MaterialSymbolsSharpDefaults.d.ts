import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `material-symbols/sharp` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const MaterialSymbolsSharpDefaults: IconNodeDefaults;
//# sourceMappingURL=MaterialSymbolsSharpDefaults.d.ts.map