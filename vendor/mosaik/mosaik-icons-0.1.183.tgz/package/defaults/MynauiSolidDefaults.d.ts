import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `mynaui/solid` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const MynauiSolidDefaults: IconNodeDefaults;
//# sourceMappingURL=MynauiSolidDefaults.d.ts.map