import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `fluent-ui/24-color` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const FluentUi24ColorDefaults: IconNodeDefaults;
//# sourceMappingURL=FluentUi24ColorDefaults.d.ts.map