import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `fluent-ui/32-regular` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const FluentUi32RegularDefaults: IconNodeDefaults;
//# sourceMappingURL=FluentUi32RegularDefaults.d.ts.map