import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `solar-icons/broken` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const SolarIconsBrokenDefaults: IconNodeDefaults;
//# sourceMappingURL=SolarIconsBrokenDefaults.d.ts.map