import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `lets-icons/light` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const LetsIconsLightDefaults: IconNodeDefaults;
//# sourceMappingURL=LetsIconsLightDefaults.d.ts.map