import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `bootstrap-icons` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const BootstrapIconsDefaults: IconNodeDefaults;
//# sourceMappingURL=BootstrapIconsDefaults.d.ts.map