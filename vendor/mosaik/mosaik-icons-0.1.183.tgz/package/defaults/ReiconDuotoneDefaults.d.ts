import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `reicon/duotone` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const ReiconDuotoneDefaults: IconNodeDefaults;
//# sourceMappingURL=ReiconDuotoneDefaults.d.ts.map