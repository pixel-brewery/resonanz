import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `typicons` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const TypiconsDefaults: IconNodeDefaults;
//# sourceMappingURL=TypiconsDefaults.d.ts.map