import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `iconsax/linear` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const IconsaxLinearDefaults: IconNodeDefaults;
//# sourceMappingURL=IconsaxLinearDefaults.d.ts.map