import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `flag-icons/square` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const FlagIconsSquareDefaults: IconNodeDefaults;
//# sourceMappingURL=FlagIconsSquareDefaults.d.ts.map