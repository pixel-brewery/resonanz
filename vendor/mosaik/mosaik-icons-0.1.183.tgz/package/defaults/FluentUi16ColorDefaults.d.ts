import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `fluent-ui/16-color` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const FluentUi16ColorDefaults: IconNodeDefaults;
//# sourceMappingURL=FluentUi16ColorDefaults.d.ts.map