import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `tdesign-icons` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const TdesignIconsDefaults: IconNodeDefaults;
//# sourceMappingURL=TdesignIconsDefaults.d.ts.map