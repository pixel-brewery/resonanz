import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `remixicon` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const RemixiconDefaults: IconNodeDefaults;
//# sourceMappingURL=RemixiconDefaults.d.ts.map