import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `huge-icons` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const HugeIconsDefaults: IconNodeDefaults;
//# sourceMappingURL=HugeIconsDefaults.d.ts.map