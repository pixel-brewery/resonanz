import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `reicon/flags` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const ReiconFlagsDefaults: IconNodeDefaults;
//# sourceMappingURL=ReiconFlagsDefaults.d.ts.map