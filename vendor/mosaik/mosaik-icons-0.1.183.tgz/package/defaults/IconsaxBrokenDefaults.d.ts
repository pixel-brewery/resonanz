import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `iconsax/broken` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const IconsaxBrokenDefaults: IconNodeDefaults;
//# sourceMappingURL=IconsaxBrokenDefaults.d.ts.map