import type { IconNodeDefaults } from '../types/IconNodeDefaults';
/**
 * The attributes the `boxicons/solid` set keeps on the SVG root rather than on a
 * single node, for handing back to `fromNodes`.
 *
 * @public
 */
export declare const BoxiconsSolidDefaults: IconNodeDefaults;
//# sourceMappingURL=BoxiconsSolidDefaults.d.ts.map