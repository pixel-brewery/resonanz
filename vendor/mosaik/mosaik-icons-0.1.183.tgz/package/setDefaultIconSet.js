// #region Imports
import { IconRegistry } from './IconRegistry';
// #endregion
/**
 * Points every unprefixed icon name at a registered set.
 * Every mounted icon re-resolves, so this switches the whole application's
 * iconography in one call.
 *
 * @param set The set name.
 * @public
 */
export function setDefaultIconSet(set) {
    IconRegistry.instance.setDefaultSet(set);
}
