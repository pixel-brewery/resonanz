// #region Imports
import { IconRegistry } from './IconRegistry';
// #endregion
/**
 * Installs non-overwriting definitions in the implicit default set.
 *
 * Component libraries use this for the smallest vocabulary required by their own
 * controls. Applications remain free to register an override before or after this call.
 *
 * @param icons A map of fallback icon name to source.
 * @public
 */
export function registerFallbackIcons(icons) {
    IconRegistry.instance.registerFallbacks(icons);
}
