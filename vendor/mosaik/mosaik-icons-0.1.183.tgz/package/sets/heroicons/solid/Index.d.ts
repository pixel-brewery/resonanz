/**
 * The `heroicons/solid` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/heroicons/solid`.
 *
 * @packageDocumentation
 */
export * from './HeroiconsSolid';
//# sourceMappingURL=Index.d.ts.map