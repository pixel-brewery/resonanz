/**
 * The `heroicons/outline` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/heroicons/outline`.
 *
 * @packageDocumentation
 */
export * from './HeroiconsOutline';
//# sourceMappingURL=Index.d.ts.map