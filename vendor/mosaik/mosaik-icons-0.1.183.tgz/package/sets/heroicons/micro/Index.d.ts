/**
 * The `heroicons/micro` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/heroicons/micro`.
 *
 * @packageDocumentation
 */
export * from './HeroiconsMicro';
//# sourceMappingURL=Index.d.ts.map