/**
 * The `heroicons/mini` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/heroicons/mini`.
 *
 * @packageDocumentation
 */
export * from './HeroiconsMini';
//# sourceMappingURL=Index.d.ts.map