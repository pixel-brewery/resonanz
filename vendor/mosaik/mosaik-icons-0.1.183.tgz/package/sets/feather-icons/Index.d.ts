/**
 * The `feather-icons` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/feather-icons`.
 *
 * @packageDocumentation
 */
export * from './FeatherIcons';
//# sourceMappingURL=Index.d.ts.map