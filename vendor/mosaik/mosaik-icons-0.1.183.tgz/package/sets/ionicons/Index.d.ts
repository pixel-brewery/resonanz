/**
 * The `ionicons` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/ionicons`.
 *
 * @packageDocumentation
 */
export * from './Ionicons';
//# sourceMappingURL=Index.d.ts.map