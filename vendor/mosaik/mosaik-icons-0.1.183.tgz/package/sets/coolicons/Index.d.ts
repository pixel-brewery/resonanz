/**
 * The `coolicons` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/coolicons`.
 *
 * @packageDocumentation
 */
export * from './Coolicons';
//# sourceMappingURL=Index.d.ts.map