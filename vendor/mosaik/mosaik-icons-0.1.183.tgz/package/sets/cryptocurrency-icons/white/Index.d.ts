/**
 * The `cryptocurrency-icons/white` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/cryptocurrency-icons/white`.
 *
 * @packageDocumentation
 */
export * from './CryptocurrencyIconsWhite';
//# sourceMappingURL=Index.d.ts.map