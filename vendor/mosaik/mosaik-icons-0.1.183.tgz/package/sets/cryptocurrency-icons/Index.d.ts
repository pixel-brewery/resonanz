/**
 * The `cryptocurrency-icons` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/cryptocurrency-icons`.
 *
 * @packageDocumentation
 */
export * from './CryptocurrencyIcons';
//# sourceMappingURL=Index.d.ts.map