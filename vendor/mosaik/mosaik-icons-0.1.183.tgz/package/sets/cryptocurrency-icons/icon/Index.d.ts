/**
 * The `cryptocurrency-icons/icon` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/cryptocurrency-icons/icon`.
 *
 * @packageDocumentation
 */
export * from './CryptocurrencyIconsIcon';
//# sourceMappingURL=Index.d.ts.map