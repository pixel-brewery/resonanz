/**
 * The `cryptocurrency-icons/colored` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/cryptocurrency-icons/colored`.
 *
 * @packageDocumentation
 */
export * from './CryptocurrencyIconsColored';
//# sourceMappingURL=Index.d.ts.map