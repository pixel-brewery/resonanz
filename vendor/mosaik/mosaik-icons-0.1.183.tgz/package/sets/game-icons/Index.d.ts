/**
 * The `game-icons` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/game-icons`.
 *
 * @packageDocumentation
 */
export * from './GameIcons';
//# sourceMappingURL=Index.d.ts.map