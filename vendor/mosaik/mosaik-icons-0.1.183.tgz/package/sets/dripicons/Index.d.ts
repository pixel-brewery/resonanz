/**
 * The `dripicons` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/dripicons`.
 *
 * @packageDocumentation
 */
export * from './Dripicons';
//# sourceMappingURL=Index.d.ts.map