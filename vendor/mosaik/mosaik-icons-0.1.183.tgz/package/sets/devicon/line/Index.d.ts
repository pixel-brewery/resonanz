/**
 * The `devicon/line` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/devicon/line`.
 *
 * @packageDocumentation
 */
export * from './DeviconLine';
//# sourceMappingURL=Index.d.ts.map