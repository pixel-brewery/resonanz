/**
 * The `devicon/original` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/devicon/original`.
 *
 * @packageDocumentation
 */
export * from './DeviconOriginal';
//# sourceMappingURL=Index.d.ts.map