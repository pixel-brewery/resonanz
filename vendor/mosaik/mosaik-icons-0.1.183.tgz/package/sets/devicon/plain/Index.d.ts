/**
 * The `devicon/plain` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/devicon/plain`.
 *
 * @packageDocumentation
 */
export * from './DeviconPlain';
//# sourceMappingURL=Index.d.ts.map