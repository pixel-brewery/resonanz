/**
 * The `keyline-icons/duotone` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/keyline-icons/duotone`.
 *
 * @packageDocumentation
 */
export * from './KeylineIconsDuotone';
//# sourceMappingURL=Index.d.ts.map