/**
 * The `keyline-icons` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/keyline-icons`.
 *
 * @packageDocumentation
 */
export * from './KeylineIcons';
//# sourceMappingURL=Index.d.ts.map