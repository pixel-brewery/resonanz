/**
 * The `iconoir/regular` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/iconoir/regular`.
 *
 * @packageDocumentation
 */
export * from './IconoirRegular';
//# sourceMappingURL=Index.d.ts.map