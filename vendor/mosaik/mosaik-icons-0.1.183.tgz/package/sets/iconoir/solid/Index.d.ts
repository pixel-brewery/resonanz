/**
 * The `iconoir/solid` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/iconoir/solid`.
 *
 * @packageDocumentation
 */
export * from './IconoirSolid';
//# sourceMappingURL=Index.d.ts.map