/**
 * The `akar-icons` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/akar-icons`.
 *
 * @packageDocumentation
 */
export * from './AkarIcons';
//# sourceMappingURL=Index.d.ts.map