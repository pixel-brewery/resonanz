/**
 * The `bootstrap-icons` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/bootstrap-icons`.
 *
 * @packageDocumentation
 */
export * from './BootstrapIcons';
//# sourceMappingURL=Index.d.ts.map