/**
 * The `huge-icons` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/huge-icons`.
 *
 * @packageDocumentation
 */
export * from './HugeIcons';
//# sourceMappingURL=Index.d.ts.map