/**
 * The `fluent-ui` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/fluent-ui`.
 *
 * @packageDocumentation
 */
export * from './FluentUi';
//# sourceMappingURL=Index.d.ts.map