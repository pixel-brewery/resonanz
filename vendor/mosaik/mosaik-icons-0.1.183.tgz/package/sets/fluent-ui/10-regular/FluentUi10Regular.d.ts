/**
 * Every icon of the `fluent-ui/10-regular` set.
 *
 * @packageDocumentation
 */
import type { IIconDefinition } from '../../../types/IIconDefinition';
export declare const fluentPresenceAvailable10Regular: IIconDefinition;
export declare const fluentPresenceAway10Regular: IIconDefinition;
export declare const fluentPresenceBlocked10Regular: IIconDefinition;
export declare const fluentPresenceDnd10Regular: IIconDefinition;
export declare const fluentPresenceOffline10Regular: IIconDefinition;
export declare const fluentPresenceOof10Regular: IIconDefinition;
export declare const fluentPresenceTentative10Regular: IIconDefinition;
export declare const fluentPresenceUnknown10Regular: IIconDefinition;
//# sourceMappingURL=FluentUi10Regular.d.ts.map