/**
 * The `fluent-ui/10-regular` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/fluent-ui/10-regular`.
 *
 * @packageDocumentation
 */
export * from './FluentUi10Regular';
//# sourceMappingURL=Index.d.ts.map