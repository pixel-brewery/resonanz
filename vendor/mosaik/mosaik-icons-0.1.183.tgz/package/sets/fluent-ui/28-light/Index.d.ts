/**
 * The `fluent-ui/28-light` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/fluent-ui/28-light`.
 *
 * @packageDocumentation
 */
export * from './FluentUi28Light';
//# sourceMappingURL=Index.d.ts.map