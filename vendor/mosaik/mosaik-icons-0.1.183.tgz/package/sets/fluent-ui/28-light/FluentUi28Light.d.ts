/**
 * Every icon of the `fluent-ui/28-light` set.
 *
 * @packageDocumentation
 */
import type { IIconDefinition } from '../../../types/IIconDefinition';
export declare const fluentDocument28Light: IIconDefinition;
export declare const fluentDocumentSparkle28Light: IIconDefinition;
//# sourceMappingURL=FluentUi28Light.d.ts.map