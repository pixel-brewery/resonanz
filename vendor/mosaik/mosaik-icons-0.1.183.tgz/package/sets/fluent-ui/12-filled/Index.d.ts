/**
 * The `fluent-ui/12-filled` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/fluent-ui/12-filled`.
 *
 * @packageDocumentation
 */
export * from './FluentUi12Filled';
//# sourceMappingURL=Index.d.ts.map