/**
 * The `fluent-ui/20-regular` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/fluent-ui/20-regular`.
 *
 * @packageDocumentation
 */
export * from './FluentUi20Regular';
//# sourceMappingURL=Index.d.ts.map