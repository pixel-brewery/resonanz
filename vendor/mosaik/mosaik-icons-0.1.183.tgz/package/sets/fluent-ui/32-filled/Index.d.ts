/**
 * The `fluent-ui/32-filled` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/fluent-ui/32-filled`.
 *
 * @packageDocumentation
 */
export * from './FluentUi32Filled';
//# sourceMappingURL=Index.d.ts.map