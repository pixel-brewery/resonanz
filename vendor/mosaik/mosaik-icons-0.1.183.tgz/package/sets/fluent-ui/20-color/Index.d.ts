/**
 * The `fluent-ui/20-color` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/fluent-ui/20-color`.
 *
 * @packageDocumentation
 */
export * from './FluentUi20Color';
//# sourceMappingURL=Index.d.ts.map