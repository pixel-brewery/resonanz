/**
 * Every icon of the `fluent-ui/24-light` set.
 *
 * @packageDocumentation
 */
import type { IIconDefinition } from '../../../types/IIconDefinition';
export declare const fluentDocument24Light: IIconDefinition;
export declare const fluentDocumentSparkle24Light: IIconDefinition;
//# sourceMappingURL=FluentUi24Light.d.ts.map