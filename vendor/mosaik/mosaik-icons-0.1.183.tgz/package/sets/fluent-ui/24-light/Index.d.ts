/**
 * The `fluent-ui/24-light` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/fluent-ui/24-light`.
 *
 * @packageDocumentation
 */
export * from './FluentUi24Light';
//# sourceMappingURL=Index.d.ts.map