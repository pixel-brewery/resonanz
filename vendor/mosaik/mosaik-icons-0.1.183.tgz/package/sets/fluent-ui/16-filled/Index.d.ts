/**
 * The `fluent-ui/16-filled` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/fluent-ui/16-filled`.
 *
 * @packageDocumentation
 */
export * from './FluentUi16Filled';
//# sourceMappingURL=Index.d.ts.map