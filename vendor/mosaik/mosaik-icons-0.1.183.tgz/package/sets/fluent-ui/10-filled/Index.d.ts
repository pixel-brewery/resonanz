/**
 * The `fluent-ui/10-filled` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/fluent-ui/10-filled`.
 *
 * @packageDocumentation
 */
export * from './FluentUi10Filled';
//# sourceMappingURL=Index.d.ts.map