/**
 * Every icon of the `fluent-ui/10-filled` set.
 *
 * @packageDocumentation
 */
import type { IIconDefinition } from '../../../types/IIconDefinition';
export declare const fluentPresenceAvailable10Filled: IIconDefinition;
export declare const fluentPresenceAway10Filled: IIconDefinition;
export declare const fluentPresenceBusy10Filled: IIconDefinition;
export declare const fluentPresenceDnd10Filled: IIconDefinition;
//# sourceMappingURL=FluentUi10Filled.d.ts.map