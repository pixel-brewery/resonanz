/**
 * The `fluent-ui/48-regular` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/fluent-ui/48-regular`.
 *
 * @packageDocumentation
 */
export * from './FluentUi48Regular';
//# sourceMappingURL=Index.d.ts.map