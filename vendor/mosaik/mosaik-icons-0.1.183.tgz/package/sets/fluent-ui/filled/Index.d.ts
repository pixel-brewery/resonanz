/**
 * The `fluent-ui/filled` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/fluent-ui/filled`.
 *
 * @packageDocumentation
 */
export * from './FluentUiFilled';
//# sourceMappingURL=Index.d.ts.map