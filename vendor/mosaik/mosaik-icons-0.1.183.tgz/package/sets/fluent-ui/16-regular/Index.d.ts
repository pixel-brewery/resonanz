/**
 * The `fluent-ui/16-regular` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/fluent-ui/16-regular`.
 *
 * @packageDocumentation
 */
export * from './FluentUi16Regular';
//# sourceMappingURL=Index.d.ts.map