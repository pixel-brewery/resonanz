/**
 * The `fluent-ui/16-color` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/fluent-ui/16-color`.
 *
 * @packageDocumentation
 */
export * from './FluentUi16Color';
//# sourceMappingURL=Index.d.ts.map