/**
 * The `fluent-ui/32-color` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/fluent-ui/32-color`.
 *
 * @packageDocumentation
 */
export * from './FluentUi32Color';
//# sourceMappingURL=Index.d.ts.map