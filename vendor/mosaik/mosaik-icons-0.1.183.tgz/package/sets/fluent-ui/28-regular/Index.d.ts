/**
 * The `fluent-ui/28-regular` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/fluent-ui/28-regular`.
 *
 * @packageDocumentation
 */
export * from './FluentUi28Regular';
//# sourceMappingURL=Index.d.ts.map