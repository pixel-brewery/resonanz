/**
 * The `fluent-ui/24-color` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/fluent-ui/24-color`.
 *
 * @packageDocumentation
 */
export * from './FluentUi24Color';
//# sourceMappingURL=Index.d.ts.map