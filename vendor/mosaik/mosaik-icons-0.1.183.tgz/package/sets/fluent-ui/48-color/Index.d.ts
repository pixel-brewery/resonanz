/**
 * The `fluent-ui/48-color` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/fluent-ui/48-color`.
 *
 * @packageDocumentation
 */
export * from './FluentUi48Color';
//# sourceMappingURL=Index.d.ts.map