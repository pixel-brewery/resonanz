/**
 * The `fluent-ui/20-filled` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/fluent-ui/20-filled`.
 *
 * @packageDocumentation
 */
export * from './FluentUi20Filled';
//# sourceMappingURL=Index.d.ts.map