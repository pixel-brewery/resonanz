/**
 * The `fluent-ui/32-regular` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/fluent-ui/32-regular`.
 *
 * @packageDocumentation
 */
export * from './FluentUi32Regular';
//# sourceMappingURL=Index.d.ts.map