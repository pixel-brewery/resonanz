/**
 * Every icon of the `fluent-ui/48-light` set.
 *
 * @packageDocumentation
 */
import type { IIconDefinition } from '../../../types/IIconDefinition';
export declare const fluentDocument48Light: IIconDefinition;
export declare const fluentDocumentSparkle48Light: IIconDefinition;
//# sourceMappingURL=FluentUi48Light.d.ts.map