/**
 * The `fluent-ui/48-light` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/fluent-ui/48-light`.
 *
 * @packageDocumentation
 */
export * from './FluentUi48Light';
//# sourceMappingURL=Index.d.ts.map