/**
 * The `fluent-ui/28-filled` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/fluent-ui/28-filled`.
 *
 * @packageDocumentation
 */
export * from './FluentUi28Filled';
//# sourceMappingURL=Index.d.ts.map