/**
 * The `fluent-ui/12-regular` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/fluent-ui/12-regular`.
 *
 * @packageDocumentation
 */
export * from './FluentUi12Regular';
//# sourceMappingURL=Index.d.ts.map