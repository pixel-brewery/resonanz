/**
 * The `fluent-ui/48-filled` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/fluent-ui/48-filled`.
 *
 * @packageDocumentation
 */
export * from './FluentUi48Filled';
//# sourceMappingURL=Index.d.ts.map