/**
 * The `fluent-ui/32-light` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/fluent-ui/32-light`.
 *
 * @packageDocumentation
 */
export * from './FluentUi32Light';
//# sourceMappingURL=Index.d.ts.map