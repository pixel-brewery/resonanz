/**
 * The `fluent-ui/28-color` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/fluent-ui/28-color`.
 *
 * @packageDocumentation
 */
export * from './FluentUi28Color';
//# sourceMappingURL=Index.d.ts.map