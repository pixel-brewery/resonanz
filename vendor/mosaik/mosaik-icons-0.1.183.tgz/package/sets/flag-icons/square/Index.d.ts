/**
 * The `flag-icons/square` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/flag-icons/square`.
 *
 * @packageDocumentation
 */
export * from './FlagIconsSquare';
//# sourceMappingURL=Index.d.ts.map