/**
 * The `flag-icons` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/flag-icons`.
 *
 * @packageDocumentation
 */
export * from './FlagIcons';
//# sourceMappingURL=Index.d.ts.map