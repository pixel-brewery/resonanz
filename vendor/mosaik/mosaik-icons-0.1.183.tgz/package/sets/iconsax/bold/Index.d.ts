/**
 * The `iconsax/bold` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/iconsax/bold`.
 *
 * @packageDocumentation
 */
export * from './IconsaxBold';
//# sourceMappingURL=Index.d.ts.map