/**
 * The `iconsax/twotone` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/iconsax/twotone`.
 *
 * @packageDocumentation
 */
export * from './IconsaxTwotone';
//# sourceMappingURL=Index.d.ts.map