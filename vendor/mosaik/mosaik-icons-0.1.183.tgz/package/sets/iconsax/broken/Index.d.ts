/**
 * The `iconsax/broken` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/iconsax/broken`.
 *
 * @packageDocumentation
 */
export * from './IconsaxBroken';
//# sourceMappingURL=Index.d.ts.map