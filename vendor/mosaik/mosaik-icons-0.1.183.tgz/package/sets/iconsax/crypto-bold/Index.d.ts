/**
 * The `iconsax/crypto-bold` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/iconsax/crypto-bold`.
 *
 * @packageDocumentation
 */
export * from './IconsaxCryptoBold';
//# sourceMappingURL=Index.d.ts.map