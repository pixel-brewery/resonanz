/**
 * The `iconsax/crypto-bulk` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/iconsax/crypto-bulk`.
 *
 * @packageDocumentation
 */
export * from './IconsaxCryptoBulk';
//# sourceMappingURL=Index.d.ts.map