/**
 * The `iconsax/crypto-linear` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/iconsax/crypto-linear`.
 *
 * @packageDocumentation
 */
export * from './IconsaxCryptoLinear';
//# sourceMappingURL=Index.d.ts.map