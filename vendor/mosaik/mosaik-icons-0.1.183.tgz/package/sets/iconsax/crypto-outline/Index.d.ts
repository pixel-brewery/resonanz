/**
 * The `iconsax/crypto-outline` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/iconsax/crypto-outline`.
 *
 * @packageDocumentation
 */
export * from './IconsaxCryptoOutline';
//# sourceMappingURL=Index.d.ts.map