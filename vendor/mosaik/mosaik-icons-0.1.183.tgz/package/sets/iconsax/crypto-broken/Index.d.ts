/**
 * The `iconsax/crypto-broken` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/iconsax/crypto-broken`.
 *
 * @packageDocumentation
 */
export * from './IconsaxCryptoBroken';
//# sourceMappingURL=Index.d.ts.map