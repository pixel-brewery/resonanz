/**
 * The `iconsax/crypto-twotone` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/iconsax/crypto-twotone`.
 *
 * @packageDocumentation
 */
export * from './IconsaxCryptoTwotone';
//# sourceMappingURL=Index.d.ts.map