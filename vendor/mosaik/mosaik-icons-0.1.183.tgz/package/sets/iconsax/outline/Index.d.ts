/**
 * The `iconsax/outline` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/iconsax/outline`.
 *
 * @packageDocumentation
 */
export * from './IconsaxOutline';
//# sourceMappingURL=Index.d.ts.map