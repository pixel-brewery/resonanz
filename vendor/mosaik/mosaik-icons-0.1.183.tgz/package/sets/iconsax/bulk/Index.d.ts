/**
 * The `iconsax/bulk` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/iconsax/bulk`.
 *
 * @packageDocumentation
 */
export * from './IconsaxBulk';
//# sourceMappingURL=Index.d.ts.map