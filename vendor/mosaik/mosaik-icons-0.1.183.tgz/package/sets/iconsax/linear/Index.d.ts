/**
 * The `iconsax/linear` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/iconsax/linear`.
 *
 * @packageDocumentation
 */
export * from './IconsaxLinear';
//# sourceMappingURL=Index.d.ts.map