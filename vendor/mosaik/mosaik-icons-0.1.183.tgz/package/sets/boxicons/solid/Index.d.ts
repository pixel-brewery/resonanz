/**
 * The `boxicons/solid` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/boxicons/solid`.
 *
 * @packageDocumentation
 */
export * from './BoxiconsSolid';
//# sourceMappingURL=Index.d.ts.map