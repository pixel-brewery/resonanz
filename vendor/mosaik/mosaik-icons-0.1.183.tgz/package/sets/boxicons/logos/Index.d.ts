/**
 * The `boxicons/logos` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/boxicons/logos`.
 *
 * @packageDocumentation
 */
export * from './BoxiconsLogos';
//# sourceMappingURL=Index.d.ts.map