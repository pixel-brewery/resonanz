/**
 * The `boxicons/regular` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/boxicons/regular`.
 *
 * @packageDocumentation
 */
export * from './BoxiconsRegular';
//# sourceMappingURL=Index.d.ts.map