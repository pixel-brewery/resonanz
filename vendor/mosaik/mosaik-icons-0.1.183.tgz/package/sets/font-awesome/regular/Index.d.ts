/**
 * The `font-awesome/regular` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/font-awesome/regular`.
 *
 * @packageDocumentation
 */
export * from './FontAwesomeRegular';
//# sourceMappingURL=Index.d.ts.map