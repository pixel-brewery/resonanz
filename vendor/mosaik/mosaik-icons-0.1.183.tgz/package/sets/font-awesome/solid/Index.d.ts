/**
 * The `font-awesome/solid` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/font-awesome/solid`.
 *
 * @packageDocumentation
 */
export * from './FontAwesomeSolid';
//# sourceMappingURL=Index.d.ts.map