/**
 * The `font-awesome/brands` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/font-awesome/brands`.
 *
 * @packageDocumentation
 */
export * from './FontAwesomeBrands';
//# sourceMappingURL=Index.d.ts.map