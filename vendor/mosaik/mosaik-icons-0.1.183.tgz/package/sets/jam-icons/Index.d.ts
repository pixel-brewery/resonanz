/**
 * The `jam-icons` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/jam-icons`.
 *
 * @packageDocumentation
 */
export * from './JamIcons';
//# sourceMappingURL=Index.d.ts.map