/**
 * The `circum-icons` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/circum-icons`.
 *
 * @packageDocumentation
 */
export * from './CircumIcons';
//# sourceMappingURL=Index.d.ts.map