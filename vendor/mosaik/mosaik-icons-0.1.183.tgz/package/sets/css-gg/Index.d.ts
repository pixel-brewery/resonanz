/**
 * The `css-gg` icon set.
 *
 * Reachable through the dedicated import
 * `@pixel-brewery/mosaik-icons/css-gg`.
 *
 * @packageDocumentation
 */
export * from './CssGg';
//# sourceMappingURL=Index.d.ts.map