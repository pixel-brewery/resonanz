import { type IconInput } from './types/IconInput';
import { type IconLoader } from './types/IconLoader';
import { type IconSource } from './types/IconSource';
import { type IIconDefinition } from './types/IIconDefinition';
/**
 * Resolves icon names to renderable definitions.
 *
 * The registry itself is intentionally empty when this package is loaded. A component
 * library may install a small fallback vocabulary, while applications register or load
 * every additional icon explicitly.
 *
 * @public
 */
export declare class IconRegistry {
    private static _instance;
    private readonly _sets;
    private readonly _pending;
    private readonly _listeners;
    private _defaultSet;
    private _loader;
    private _warned;
    /**
     * Constructs a new instance of the `IconRegistry` class.
     *
     * @public
     */
    constructor();
    /**
     * The name of the implicit set that unprefixed names resolve against
     * when no other default has been configured.
     *
     * @public
     * @static
     * @readonly
     */
    static get DEFAULT_SET(): string;
    /**
     * Accesses the singleton instance.
     *
     * @public
     * @static
     * @readonly
     */
    static get instance(): IconRegistry;
    /**
     * Gets the name of the set that unprefixed names resolve against.
     *
     * @public
     */
    get defaultSet(): string;
    /**
     * Gets the names of all registered sets.
     *
     * @public
     * @readonly
     */
    get sets(): Array<string>;
    /**
     * Registers icons in the default set.
     *
     * @param icons A map of icon name to source.
     * @public
     */
    register(icons: IconInput): void;
    /**
     * Registers non-overwriting icons in the implicit default set.
     *
     * This is intended for a component library's built-in semantic vocabulary. An
     * application registration always wins, regardless of module evaluation order, and
     * a selected named set can still fall back to these definitions for missing names.
     *
     * @param icons A map of fallback icon name to source.
     * @public
     */
    registerFallbacks(icons: IconInput): void;
    /**
     * Registers icons in a named set.
     *
     * @param set The set name, used as the prefix in `set:name`.
     * @param icons A map of icon name to source.
     * @public
     */
    registerSet(set: string, icons: IconInput): void;
    /**
     * Registers icons in a set.
     *
     * @param set The target set.
     * @param icons A map of icon name to source.
     * @param overwrite Whether an existing definition may be replaced.
     * @private
     */
    private registerIntoSet;
    /**
     * Sets the set that unprefixed names resolve against and notifies every listener,
     * so that elements re-render against the new set.
     *
     * @param set The set name.
     * @public
     */
    setDefaultSet(set: string): void;
    /**
     * Installs a resolver for names that are not registered.
     *
     * @param loader The resolver, or `null` to remove the current one.
     * @public
     */
    setLoader(loader: IconLoader | null): void;
    /**
     * Resolves a name to a definition, without consulting the loader.
     * Returns `null` when the name is unknown.
     *
     * @param name The icon name, with or without a set prefix.
     * @public
     */
    resolve(name: string): IIconDefinition | null;
    /**
     * Resolves a name, consulting the loader when the name is not registered.
     * The result of a loader call is cached, including a negative one.
     *
     * @param name The icon name, with or without a set prefix.
     * @public
     */
    resolveAsync(name: string): Promise<IIconDefinition | null>;
    /**
     * Reports which of the given names the registry cannot resolve right now.
     *
     * An application uses this to prove that the vocabulary it addresses is covered by
     * the sets it registered. That matters because only the core catalog is guaranteed
     * across sets - an extended alias exists only in the sets whose source library has
     * it, so switching the default set can silently drop icons.
     *
     * @param names The icon names to check.
     * @returns The names that do not resolve, empty when all of them do.
     * @public
     *
     * @example
     * ```ts
     * const missing = IconRegistry.instance.findUnresolved(Object.values(Icons));
     *
     * expect(missing).toEqual([]);
     * ```
     */
    findUnresolved(names: Iterable<string>): Array<string>;
    /**
     * Subscribes to registry changes. The returned function removes the subscription.
     *
     * @param listener The callback invoked after every change.
     * @public
     */
    subscribe(listener: () => void): () => void;
    /**
     * Reports an unresolved name once per name, so that a typo does not flood the console
     * and does not take a view down the way a thrown error would.
     *
     * @param name The unresolved name.
     * @public
     */
    warnUnresolved(name: string): void;
    /**
     * Removes every registration. Intended for tests.
     *
     * @public
     */
    clear(): void;
    /**
     * Converts any accepted source into a definition.
     * Markup is parsed, path data is wrapped, a definition is sanitized and passed through.
     *
     * @param source The source to normalize.
     * @public
     */
    normalize(source: IconSource): IIconDefinition | null;
    /**
     * Parses a complete `<svg>` document into a definition.
     * Kept static so that the adapters can reuse it without an instance.
     *
     * @param markup The SVG markup.
     * @public
     * @static
     */
    static fromMarkup(markup: string): IIconDefinition | null;
    /**
     * Escapes a value for use inside a double quoted attribute.
     *
     * @param value The raw value.
     * @public
     * @static
     */
    static escapeAttribute(value: string): string;
    /**
     * Collects the presentation attributes of a source `<svg>` root that have to survive
     * the move onto the element's own root.
     *
     * @param attributes The raw attribute string of the source root.
     * @private
     * @static
     */
    private static carriedAttributes;
    /**
     * Splits a name into set and key.
     *
     * @param name The icon name.
     * @private
     */
    private split;
    /**
     * Returns the map for a set, creating it when needed.
     *
     * @param set The set name.
     * @private
     */
    private ensureSet;
    /**
     * Notifies every subscriber.
     *
     * @private
     */
    private notify;
}
//# sourceMappingURL=IconRegistry.d.ts.map