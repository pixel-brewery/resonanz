## 0.1.183 (2026-10-29)

### 🩹 Fixes

- **build:** token lint contracts, self-contained source maps, packaged CLI launchers, showcase lint inputs ([4e5225c48f](https://github.com/RueDeRennes/mosaik/commit/4e5225c48f))
- **repo:** finish the kebab-case directory migration ([#494](https://github.com/RueDeRennes/mosaik/pull/494))

### ❤️ Thank You

- RueDeRennes

## 0.1.182 (2026-10-28)

### 🚀 Features

- **studio:** admin suite layouts and states, #600 blocks as recipes, recipe id aliases ([#600](https://github.com/RueDeRennes/mosaik/issues/600))
- **scheduler:** enhance selection functionality and styling ([bf4c416bfe](https://github.com/RueDeRennes/mosaik/commit/bf4c416bfe))
- **studio:** page library - 101 pages in ten templates ([#601](https://github.com/RueDeRennes/mosaik/pull/601), [#702](https://github.com/RueDeRennes/mosaik/issues/702), [#703](https://github.com/RueDeRennes/mosaik/issues/703), [#704](https://github.com/RueDeRennes/mosaik/issues/704), [#705](https://github.com/RueDeRennes/mosaik/issues/705), [#706](https://github.com/RueDeRennes/mosaik/issues/706), [#707](https://github.com/RueDeRennes/mosaik/issues/707), [#708](https://github.com/RueDeRennes/mosaik/issues/708), [#709](https://github.com/RueDeRennes/mosaik/issues/709), [#710](https://github.com/RueDeRennes/mosaik/issues/710), [#711](https://github.com/RueDeRennes/mosaik/issues/711))
- **studio:** every template gets a look of its own ([32516f7994](https://github.com/RueDeRennes/mosaik/commit/32516f7994))
- **studio:** landing and full site templates ([#599](https://github.com/RueDeRennes/mosaik/pull/599))
- **studio:** marketing ui blocks catalog ([#594](https://github.com/RueDeRennes/mosaik/pull/594))
- **studio:** shop blocks catalog ([#596](https://github.com/RueDeRennes/mosaik/pull/596), [#650](https://github.com/RueDeRennes/mosaik/issues/650))
- **studio:** data table catalog ([#597](https://github.com/RueDeRennes/mosaik/pull/597), [#663](https://github.com/RueDeRennes/mosaik/issues/663))
- **studio:** bento cards and bento grids catalog ([#598](https://github.com/RueDeRennes/mosaik/pull/598), [#672](https://github.com/RueDeRennes/mosaik/issues/672), [#673](https://github.com/RueDeRennes/mosaik/issues/673))
- **blog:** author profiles with protected CV and a generic Blog API module ([#1117](https://github.com/RueDeRennes/mosaik/issues/1117), [#1119](https://github.com/RueDeRennes/mosaik/issues/1119), [#1120](https://github.com/RueDeRennes/mosaik/issues/1120))

### 🩹 Fixes

- **studio:** align bento, hero and feature blocks with their references ([#1056](https://github.com/RueDeRennes/mosaik/pull/1056))
- **doppler:** update secrets sync command and project references in documentation ([0e1dee3457](https://github.com/RueDeRennes/mosaik/commit/0e1dee3457))

### ❤️ Thank You

- RueDeRennes

## 0.1.181 (2026-10-27)

### 🚀 Features

- add placeholder color to textBox components across themes ([332ef832ba](https://github.com/RueDeRennes/mosaik/commit/332ef832ba))
- update banner and reveal components across themes ([d7fdcb3c6c](https://github.com/RueDeRennes/mosaik/commit/d7fdcb3c6c))
- extend components, scheduler and Studio ([68a93b3ac6](https://github.com/RueDeRennes/mosaik/commit/68a93b3ac6))
- enhance documentation with local environment guidelines and testing constraints ([194c6e6cf3](https://github.com/RueDeRennes/mosaik/commit/194c6e6cf3))
- update SchedulerEventElement and SchedulerElement documentation and events ([012e20096f](https://github.com/RueDeRennes/mosaik/commit/012e20096f))
- add grid item position and resize handle interfaces ([2c56bd2561](https://github.com/RueDeRennes/mosaik/commit/2c56bd2561))
- add Flow Board tools and enhance drag-and-drop functionality ([9c478c72b7](https://github.com/RueDeRennes/mosaik/commit/9c478c72b7))

### 🩹 Fixes

- update TileManagerTileElement documentation and improve CSS part descriptions ([3b9d34fc1d](https://github.com/RueDeRennes/mosaik/commit/3b9d34fc1d))

### ❤️ Thank You

- RueDeRennes

## 0.1.180 (2026-10-24)

### 🚀 Features

- Add documentation for hover reveal functionality and wallet card components ([1d2e4cc173](https://github.com/RueDeRennes/mosaik/commit/1d2e4cc173))
- add numeric keyboard mode to VirtualKeyboardMode ([8622d98026](https://github.com/RueDeRennes/mosaik/commit/8622d98026))

### ❤️ Thank You

- RueDeRennes

## 0.1.179 (2026-10-23)

### 🚀 Features

- **bubbles:** add Memphis and Soho themes with styles and tokens ([854dfa1dbd](https://github.com/RueDeRennes/mosaik/commit/854dfa1dbd))

### ❤️ Thank You

- RueDeRennes

## 0.1.178 (2026-10-23)

### 🚀 Features

- enhance DateTimeBoxElement with period validation and improve elevation handling ([9600f73320](https://github.com/RueDeRennes/mosaik/commit/9600f73320))
- add new icons and update existing ones in mosaik-icons library ([16b8512a67](https://github.com/RueDeRennes/mosaik/commit/16b8512a67))
- **studio:** add the Pricing component blocks ([#617](https://github.com/RueDeRennes/mosaik/pull/617))
- **studio:** add --settle option to the block capture script ([203cd18dfe](https://github.com/RueDeRennes/mosaik/commit/203cd18dfe))
- add internationalization support for various input components ([ecf2c4ee57](https://github.com/RueDeRennes/mosaik/commit/ecf2c4ee57))
- update RoutewisePage type definition for better readability ([802687dd45](https://github.com/RueDeRennes/mosaik/commit/802687dd45))
- **mcp:** enhance template behavior validation and introduce catalog behavior signature ([008ae1bc67](https://github.com/RueDeRennes/mosaik/commit/008ae1bc67))

### ❤️ Thank You

- RueDeRennes

## 0.1.177 (2026-10-22)

### 🚀 Features

- **mcp:** integrate Mosaik Beta MCP server and configuration ([1b1beb0aa9](https://github.com/RueDeRennes/mosaik/commit/1b1beb0aa9))
- **gauge-components:** add renderGauge method to various gauge components ([8995aa7ce6](https://github.com/RueDeRennes/mosaik/commit/8995aa7ce6))

### ❤️ Thank You

- RueDeRennes

## 0.1.176 (2026-10-22)

This was a version bump only for mosaik-icons to align it with other projects, there were no code changes.

## 0.1.175 (2026-10-22)

### 🚀 Features

- **tests:** add unit tests for MarkdownRenderer and FormFieldElement components ([e6caa77f9f](https://github.com/RueDeRennes/mosaik/commit/e6caa77f9f))

### ❤️ Thank You

- RueDeRennes

## 0.1.174 (2026-10-21)

This was a version bump only for mosaik-icons to align it with other projects, there were no code changes.

## 0.1.173 (2026-10-20)

### 🚀 Features

- add unit tests for TileManagerTileElement, AvatarGroupElement, and Mixins ([a904d965d6](https://github.com/RueDeRennes/mosaik/commit/a904d965d6))
- add catalog functionality with recipe references and loaders ([b8875fb373](https://github.com/RueDeRennes/mosaik/commit/b8875fb373))

### ❤️ Thank You

- RueDeRennes

## 0.1.172 (2026-10-19)

### 🚀 Features

- add typography spacing functionality and tests ([f8ee1aa82c](https://github.com/RueDeRennes/mosaik/commit/f8ee1aa82c))
- add ToolsMdGenerator and related tests for project tool inventory management ([3ecec24f33](https://github.com/RueDeRennes/mosaik/commit/3ecec24f33))

### 🩹 Fixes

- **docs:** update file paths in documentation to use lowercase for theming directory ([01e101a985](https://github.com/RueDeRennes/mosaik/commit/01e101a985))
- guard API runtime imports on Vercel ([2062134f36](https://github.com/RueDeRennes/mosaik/commit/2062134f36))
- remove host paths and enforce portable imports ([b1681f0527](https://github.com/RueDeRennes/mosaik/commit/b1681f0527))
- resolve Mosaik backlog and normalize paths ([0ceda93bd3](https://github.com/RueDeRennes/mosaik/commit/0ceda93bd3))

### ❤️ Thank You

- RueDeRennes

## 0.1.171 (2026-10-16)

### 🚀 Features

- add SignaturePad and Chart components for Vue and Svelte ([852158021d](https://github.com/RueDeRennes/mosaik/commit/852158021d))

### ❤️ Thank You

- RueDeRennes

## 0.1.170 (2026-10-15)

This was a version bump only for mosaik-icons to align it with other projects, there were no code changes.

## 0.1.169 (2026-10-15)

This was a version bump only for mosaik-icons to align it with other projects, there were no code changes.

## 0.1.168 (2026-10-15)

This was a version bump only for mosaik-icons to align it with other projects, there were no code changes.

## 0.1.167 (2026-10-15)

### 🚀 Features

- Update backend contracts and workflow documentation for clarity and accuracy ([447d02b559](https://github.com/RueDeRennes/mosaik/commit/447d02b559))
- Add comprehensive documentation for Mosaik architecture and backend contracts ([da91d3a5f5](https://github.com/RueDeRennes/mosaik/commit/da91d3a5f5))
- Enhance RichTextBox and PromptBox functionality ([5c417e004e](https://github.com/RueDeRennes/mosaik/commit/5c417e004e))
- enhance build script and clean task with improved error handling and test coverage ([8b99c789c0](https://github.com/RueDeRennes/mosaik/commit/8b99c789c0))

### 🩹 Fixes

- update nx-generate command to specify directory for library creation ([06fa48d6f7](https://github.com/RueDeRennes/mosaik/commit/06fa48d6f7))

### ❤️ Thank You

- RueDeRennes

## 0.1.166 (2026-10-14)

### 🚀 Features

- enhance TimelineSeparatorElement with slot handling and label preservation ([315a6221d7](https://github.com/RueDeRennes/mosaik/commit/315a6221d7))

### ❤️ Thank You

- RueDeRennes

## 0.1.165 (2026-10-14)

### 🚀 Features

- add TimelineSeparator component with styles and tests ([44a25812d5](https://github.com/RueDeRennes/mosaik/commit/44a25812d5))

### ❤️ Thank You

- RueDeRennes

## 0.1.164 (2026-10-14)

This was a version bump only for mosaik-icons to align it with other projects, there were no code changes.

## 0.1.163 (2026-10-13)

### 🚀 Features

- enhance ColorPickerComponent with internationalization support ([75485d49b4](https://github.com/RueDeRennes/mosaik/commit/75485d49b4))

### ❤️ Thank You

- RueDeRennes

## 0.1.162 (2026-10-13)

This was a version bump only for mosaik-icons to align it with other projects, there were no code changes.

## 0.1.161 (2026-10-13)

This was a version bump only for mosaik-icons to align it with other projects, there were no code changes.

## 0.1.160 (2026-10-13)

### 🚀 Features

- update TextBox component tokens and styles across themes ([8bdfb0713e](https://github.com/RueDeRennes/mosaik/commit/8bdfb0713e))
- add StudioRecipePreviewView and StudioRecipesView components ([750faa2bdb](https://github.com/RueDeRennes/mosaik/commit/750faa2bdb))
- add ElementSchema and MarkupEmitter for attribute binding and markup generation ([45038f8b67](https://github.com/RueDeRennes/mosaik/commit/45038f8b67))

### ❤️ Thank You

- RueDeRennes

## 0.1.159 (2026-10-12)

This was a version bump only for mosaik-icons to align it with other projects, there were no code changes.

## 0.1.158 (2026-10-12)

### 🚀 Features

- update KbdShortcutComponent to support multiple modifier keys ([72d615ddc4](https://github.com/RueDeRennes/mosaik/commit/72d615ddc4))
- enhance KbdShortcutElement to support multiple modifier keys and update documentation/examples ([56833468d2](https://github.com/RueDeRennes/mosaik/commit/56833468d2))

### ❤️ Thank You

- RueDeRennes

## 0.1.157 (2026-10-11)

This was a version bump only for mosaik-icons to align it with other projects, there were no code changes.

## 0.1.156 (2026-10-11)

This was a version bump only for mosaik-icons to align it with other projects, there were no code changes.

## 0.1.155 (2026-10-11)

### 🚀 Features

- enhance Expandable behavior with detailed event types ([bb12677d35](https://github.com/RueDeRennes/mosaik/commit/bb12677d35))

### ❤️ Thank You

- RueDeRennes

## 0.1.154 (2026-10-08)

### 🚀 Features

- **popup:** add focus restoration feature on close ([612ff3cde9](https://github.com/RueDeRennes/mosaik/commit/612ff3cde9))

### ❤️ Thank You

- RueDeRennes

## 0.1.153 (2026-10-07)

This was a version bump only for mosaik-icons to align it with other projects, there were no code changes.

## 0.1.152 (2026-10-06)

This was a version bump only for mosaik-icons to align it with other projects, there were no code changes.

## 0.1.151 (2026-10-06)

This was a version bump only for mosaik-icons to align it with other projects, there were no code changes.

## 0.1.150 (2026-10-05)

### 🚀 Features

- enhance Memphis theme styles for various components with new properties and adjustments ([7054ce562c](https://github.com/RueDeRennes/mosaik/commit/7054ce562c))

### ❤️ Thank You

- RueDeRennes

## 0.1.149 (2026-10-04)

This was a version bump only for mosaik-icons to align it with other projects, there were no code changes.

## 0.1.148 (2026-10-03)

### 🚀 Features

- **calendar:** enhance allowedViews behavior and update related documentation ([c3f86b8cea](https://github.com/RueDeRennes/mosaik/commit/c3f86b8cea))

### ❤️ Thank You

- RueDeRennes

## 0.1.147 (2026-10-03)

### 🚀 Features

- **scheduler:** add gesture support and enhance styling ([04777c82f3](https://github.com/RueDeRennes/mosaik/commit/04777c82f3))

### ❤️ Thank You

- RueDeRennes

## 0.1.146 (2026-10-02)

### 🚀 Features

- enhance scheduler event popup functionality and tests ([03d67ca9aa](https://github.com/RueDeRennes/mosaik/commit/03d67ca9aa))

### ❤️ Thank You

- RueDeRennes

## 0.1.145 (2026-10-02)

This was a version bump only for mosaik-icons to align it with other projects, there were no code changes.

## 0.1.144 (2026-09-30)

### 🚀 Features

- add support for unused keys detection and key consistency checks ([fdcdb7cf50](https://github.com/RueDeRennes/mosaik/commit/fdcdb7cf50))

### ❤️ Thank You

- RueDeRennes

## 0.1.143 (2026-09-29)

### 🚀 Features

- enhance message component behavior and add used keys analysis ([253cebd0bc](https://github.com/RueDeRennes/mosaik/commit/253cebd0bc))

### ❤️ Thank You

- RueDeRennes

## 0.1.142 (2026-09-29)

This was a version bump only for mosaik-icons to align it with other projects, there were no code changes.

## 0.1.141 (2026-09-29)

### 🚀 Features

- **tests:** add unit tests for template resolution and generated code utilities ([5e60a19a77](https://github.com/RueDeRennes/mosaik/commit/5e60a19a77))

### 🩹 Fixes

- update archipel-platform dependencies to version 0.1.11 ([df20e8f678](https://github.com/RueDeRennes/mosaik/commit/df20e8f678))

### ❤️ Thank You

- RueDeRennes

## 0.1.140 (2026-09-29)

### 🚀 Features

- enhance repository workflow instructions and add SplitComponent intl support ([94e5ad6677](https://github.com/RueDeRennes/mosaik/commit/94e5ad6677))

### ❤️ Thank You

- RueDeRennes

## 0.1.139 (2026-09-29)

### 🚀 Features

- enhance repository workflow instructions and add SplitComponent intl support ([996d14e4f0](https://github.com/RueDeRennes/mosaik/commit/996d14e4f0))

### ❤️ Thank You

- RueDeRennes

## 0.1.138 (2026-09-29)

This was a version bump only for mosaik-icons to align it with other projects, there were no code changes.

## 0.1.137 (2026-09-29)

### 🚀 Features

- **selection:** add custom selection triggers for combo and select components ([8c4218a18a](https://github.com/RueDeRennes/mosaik/commit/8c4218a18a))

### ❤️ Thank You

- RueDeRennes

## 0.1.136 (2026-09-29)

This was a version bump only for mosaik-icons to align it with other projects, there were no code changes.

## 0.1.135 (2026-09-29)

### 🚀 Features

- **breadcrumb:** add hasSeparator property and update breadcrumb item behavior ([12a99e559e](https://github.com/RueDeRennes/mosaik/commit/12a99e559e))

### ❤️ Thank You

- RueDeRennes

## 0.1.134 (2026-09-27)

### 🚀 Features

- enhance text wrapping behavior in banner components and related styles ([2d3e7bbff9](https://github.com/RueDeRennes/mosaik/commit/2d3e7bbff9))

### ❤️ Thank You

- RueDeRennes

## 0.1.133 (2026-09-27)

This was a version bump only for mosaik-icons to align it with other projects, there were no code changes.

## 0.1.132 (2026-09-27)

### 🚀 Features

- enhance table and menu item styles for better responsiveness and usability ([919ec25546](https://github.com/RueDeRennes/mosaik/commit/919ec25546))

### ❤️ Thank You

- RueDeRennes

## 0.1.131 (2026-09-26)

This was a version bump only for mosaik-icons to align it with other projects, there were no code changes.

## 0.1.130 (2026-09-26)

This was a version bump only for mosaik-icons to align it with other projects, there were no code changes.

## 0.1.129 (2026-09-25)

### 🩹 Fixes

- update documentation links and improve ChartExportCommand functionality with CSV export ([7153d2ae03](https://github.com/RueDeRennes/mosaik/commit/7153d2ae03))

### ❤️ Thank You

- RueDeRennes

## 0.1.128 (2026-09-24)

This was a version bump only for mosaik-icons to align it with other projects, there were no code changes.

## 0.1.127 (2026-09-23)

### 🚀 Features

- update VideoComponent and VideoElement documentation to include new properties for download and picture-in-picture support ([fb406ae7d0](https://github.com/RueDeRennes/mosaik/commit/fb406ae7d0))

### 🩹 Fixes

- update sandbox network settings to include Unix socket permissions ([2c0bae6c33](https://github.com/RueDeRennes/mosaik/commit/2c0bae6c33))

### ❤️ Thank You

- RueDeRennes

## 0.1.126 (2026-09-19)

### 🚀 Features

- enhance list item elements with prefix and suffix styles ([ea384e8bd9](https://github.com/RueDeRennes/mosaik/commit/ea384e8bd9))

### ❤️ Thank You

- RueDeRennes

## 0.1.125 (2026-09-18)

This was a version bump only for mosaik-icons to align it with other projects, there were no code changes.

## 0.1.124 (2026-09-17)

This was a version bump only for mosaik-icons to align it with other projects, there were no code changes.

## 0.1.123 (2026-09-17)

This was a version bump only for mosaik-icons to align it with other projects, there were no code changes.

## 0.1.122 (2026-09-16)

This was a version bump only for mosaik-icons to align it with other projects, there were no code changes.

## 0.1.121 (2026-09-16)

### 🚀 Features

- add selection runtime component with Playwright tests ([768f7f2fa6](https://github.com/RueDeRennes/mosaik/commit/768f7f2fa6))

### ❤️ Thank You

- RueDeRennes

## 0.1.120 (2026-09-15)

This was a version bump only for mosaik-icons to align it with other projects, there were no code changes.

## 0.1.119 (2026-09-15)

### 🚀 Features

- add shiftBoundary and shiftPadding properties to PopupElement ([b3ec017fb3](https://github.com/RueDeRennes/mosaik/commit/b3ec017fb3))

### ❤️ Thank You

- RueDeRennes

## 0.1.118 (2026-09-15)

### 🚀 Features

- **popup:** update documentation links and add click outside close functionality tests ([aeb763c988](https://github.com/RueDeRennes/mosaik/commit/aeb763c988))
- **menu-item:** improve interaction listener management in MenuItemElement ([7b8e1e6765](https://github.com/RueDeRennes/mosaik/commit/7b8e1e6765))

### ❤️ Thank You

- RueDeRennes

## 0.1.117 (2026-09-13)

This was a version bump only for mosaik-icons to align it with other projects, there were no code changes.

## 0.1.116 (2026-09-13)

This was a version bump only for mosaik-icons to align it with other projects, there were no code changes.

## 0.1.115 (2026-09-13)

### 🚀 Features

- **toast:** add responsive toast sizing behavior and related configurations ([b5c6b55225](https://github.com/RueDeRennes/mosaik/commit/b5c6b55225))

### ❤️ Thank You

- RueDeRennes

## 0.1.114 (2026-09-12)

This was a version bump only for mosaik-icons to align it with other projects, there were no code changes.

## 0.1.113 (2026-09-12)

### 🚀 Features

- **segment:** add size property to MosaikSegment and SegmentComponent ([c9d1fc4d49](https://github.com/RueDeRennes/mosaik/commit/c9d1fc4d49))

### ❤️ Thank You

- RueDeRennes

## 0.1.112 (2026-09-11)

### 🩹 Fixes

- update release script commands for consistency and clarity ([ccedd59e43](https://github.com/RueDeRennes/mosaik/commit/ccedd59e43))
- update documentation links and definitions for various elements ([0255773efd](https://github.com/RueDeRennes/mosaik/commit/0255773efd))

### ❤️ Thank You

- RueDeRennes

## 0.1.111 (2026-09-11)

This was a version bump only for mosaik-icons to align it with other projects, there were no code changes.

## 0.1.110 (2026-09-10)

### 🚀 Features

- **DateTimeBox:** introduce internationalization support and enhance functionality ([ca3d4ac1ac](https://github.com/RueDeRennes/mosaik/commit/ca3d4ac1ac))

### 🩹 Fixes

- **ci:** make package publishing release-only ([1c6c4162ae](https://github.com/RueDeRennes/mosaik/commit/1c6c4162ae))

### ❤️ Thank You

- RueDeRennes

## 0.1.109 (2026-09-10)

### 🚀 Features

- add focus ring color variable to select element styles and remove obsolete unit tests ([fd68ab64d2](https://github.com/RueDeRennes/mosaik/commit/fd68ab64d2))

### ❤️ Thank You

- RueDeRennes

## 0.1.108 (2026-09-09)

This was a version bump only for mosaik-icons to align it with other projects, there were no code changes.

## 0.1.107 (2026-09-09)

This was a version bump only for mosaik-icons to align it with other projects, there were no code changes.

## 0.1.106 (2026-09-08)

### 🚀 Features

- **DataTable:** add footer support with custom templates ([691bdc79ca](https://github.com/RueDeRennes/mosaik/commit/691bdc79ca))

### ❤️ Thank You

- RueDeRennes

## 0.1.103 (2026-09-06)

### 🚀 Features

- **segment-legend:** add shadow properties to SegmentLegend and SegmentLegendItem components ([3cb9db595b](https://github.com/RueDeRennes/mosaik/commit/3cb9db595b))

### 🩹 Fixes

- **nx:** remove invalid clean task inputs ([42a74bf3a0](https://github.com/RueDeRennes/mosaik/commit/42a74bf3a0))
- **packages:** install runtime dependencies ([e91421722e](https://github.com/RueDeRennes/mosaik/commit/e91421722e))

### ❤️ Thank You

- RueDeRennes

## 0.1.102 (2026-09-04)

### 🚀 Features

- **database:** implement Accelerate database module and service ([b06c2028d3](https://github.com/RueDeRennes/mosaik/commit/b06c2028d3))

### ❤️ Thank You

- RueDeRennes

## 0.1.101 (2026-09-04)

This was a version bump only for mosaik-icons to align it with other projects, there were no code changes.

## 0.1.100 (2026-09-03)

### 🚀 Features

- **segment:** add shadow properties and update styles for segment elements ([12fbf0c361](https://github.com/RueDeRennes/mosaik/commit/12fbf0c361))

### ❤️ Thank You

- RueDeRennes

## 0.1.99 (2026-09-03)

### 🚀 Features

- add includes parser and sort tokens preprocessor ([54968b87f7](https://github.com/RueDeRennes/mosaik/commit/54968b87f7))

### ❤️ Thank You

- RueDeRennes

## 0.1.98 (2026-09-02)

### 🚀 Features

- **toast-demo:** implement toast demo component with styling and functionality ([973e709011](https://github.com/RueDeRennes/mosaik/commit/973e709011))
- add segment legend and item components with theming support ([2117a2721a](https://github.com/RueDeRennes/mosaik/commit/2117a2721a))

### ❤️ Thank You

- RueDeRennes

## 0.1.97 (2026-08-31)

### 🩹 Fixes

- **tooltip:** ensure tooltips do not create scroll containers and update documentation links ([701613ca25](https://github.com/RueDeRennes/mosaik/commit/701613ca25))

### ❤️ Thank You

- RueDeRennes

## 0.1.96 (2026-08-31)

### 🚀 Features

- update scheduler component styles and tokens ([6cfb479289](https://github.com/RueDeRennes/mosaik/commit/6cfb479289))

### ❤️ Thank You

- RueDeRennes