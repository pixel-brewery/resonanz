import { type IconInput } from './types/IconInput';
/**
 * Registers icons in the default set.
 *
 * Framework neutral - it is the whole configuration story for React, Vue, Svelte and
 * plain custom element usage. Angular has `provideIcons` on top, which does the same
 * thing through dependency injection.
 *
 * @param icons A map of icon name to source.
 * @public
 *
 * @example
 * ```ts
 * import { registerIcons } from '@pixel-brewery/mosaik-icons';
 * import { lucideCalendar, lucideTrash } from '@pixel-brewery/mosaik-icons/lucide';
 *
 * registerIcons({ calendar: lucideCalendar, trash: lucideTrash });
 * ```
 */
export declare function registerIcons(icons: IconInput): void;
//# sourceMappingURL=registerIcons.d.ts.map