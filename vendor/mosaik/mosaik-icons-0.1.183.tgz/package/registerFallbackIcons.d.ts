import { type IconInput } from './types/IconInput';
/**
 * Installs non-overwriting definitions in the implicit default set.
 *
 * Component libraries use this for the smallest vocabulary required by their own
 * controls. Applications remain free to register an override before or after this call.
 *
 * @param icons A map of fallback icon name to source.
 * @public
 */
export declare function registerFallbackIcons(icons: IconInput): void;
//# sourceMappingURL=registerFallbackIcons.d.ts.map