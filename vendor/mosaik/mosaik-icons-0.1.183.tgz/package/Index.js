/**
 * Icon types, adapters and the resolving registry for Mosaik.
 *
 * This entry point carries no icon data at all. Sets live behind their own import
 * paths - `@pixel-brewery/mosaik-icons/fluent-ui/filled`, `/lucide`, `/reicon`,
 * `/tabler-icons` and so on - so that an application only ever bundles the icons
 * it actually imports.
 *
 * Mosaik has no icon library of its own. The set its components were drawn with is
 * Fluent UI System Icons by Microsoft, available as `/fluent-ui/filled`.
 *
 * @packageDocumentation
 */
export * from './defaults/Index';
export { fromIconify } from './adapters/iconify/fromIconify';
export { fromIconifySet } from './adapters/iconify/fromIconifySet';
export { fromNodes } from './adapters/nodes/fromNodes';
export { fromNodesSet } from './adapters/nodes/fromNodesSet';
export { fromSvg } from './adapters/svg/fromSvg';
export { fromSvgSet } from './adapters/svg/fromSvgSet';
export { IconRegistry } from './IconRegistry';
export { IconSanitizer } from './IconSanitizer';
export { registerFallbackIcons } from './registerFallbackIcons';
export { registerIcons } from './registerIcons';
export { registerIconSet } from './registerIconSet';
export { setDefaultIconSet } from './setDefaultIconSet';
export { setIconLoader } from './setIconLoader';
export { IconSource } from './types/IconSource';
export { IIconDefinition } from './types/IIconDefinition';
