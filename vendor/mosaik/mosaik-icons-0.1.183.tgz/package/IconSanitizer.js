/**
 * Strips everything from icon markup that has no business being in an icon.
 *
 * Icon bodies reach the registry from generated set modules, from consumer code and -
 * in the loader case - from a network response. Because the body is rendered through
 * `unsafeSVG`, it is cleaned once here at registration time rather than on every render.
 *
 * @public
 */
export var IconSanitizer;
(function (IconSanitizer) {
    // #region Fields
    const SCRIPT_PATTERN = /<script\b[^>]*>[\s\S]*?<\/script\s*>/gi;
    const STYLE_PATTERN = /<style\b[^>]*>[\s\S]*?<\/style\s*>/gi;
    const FOREIGN_OBJECT_PATTERN = /<foreignObject\b[^>]*>[\s\S]*?<\/foreignObject\s*>/gi;
    // `use` is deliberately absent: a reference to a fragment inside the same icon is
    // legitimate for gradients and duotone glyphs, and an external one is defused by
    // EXTERNAL_REFERENCE_PATTERN, which strips the href rather than the element.
    const SELF_CLOSING_PATTERN = /<(script|foreignObject|image|iframe|object|embed)\b[^>]*\/>/gi;
    const EVENT_HANDLER_PATTERN = /\son[a-z]+\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]+)/gi;
    // The unquoted branch must not start with a quote, or it swallows a quoted value
    // whose content the two branches above deliberately spared.
    const EXTERNAL_REFERENCE_PATTERN = /\s(?:xlink:href|href|src)\s*=\s*(?:"(?!#)[^"]*"|'(?!#)[^']*'|(?!["'#])[^\s>]+)/gi;
    const JAVASCRIPT_URL_PATTERN = /(?:url\(\s*['"]?\s*)?javascript\s*:/gi;
    // #endregion
    // #region Methods
    /**
     * Removes active content from an icon body.
     *
     * @param body The raw inner SVG markup.
     * @returns The cleaned markup.
     * @public
     */
    function sanitize(body) {
        if (!body) {
            return '';
        }
        return body
            .replace(SCRIPT_PATTERN, '')
            .replace(STYLE_PATTERN, '')
            .replace(FOREIGN_OBJECT_PATTERN, '')
            .replace(SELF_CLOSING_PATTERN, '')
            .replace(EVENT_HANDLER_PATTERN, '')
            .replace(EXTERNAL_REFERENCE_PATTERN, '')
            .replace(JAVASCRIPT_URL_PATTERN, '');
    }
    IconSanitizer.sanitize = sanitize;
    /**
     * Determines whether a body contains anything the sanitizer would remove.
     * Used by the icon source generator to fail a build rather than ship stripped markup.
     *
     * @param body The raw inner SVG markup.
     * @public
     */
    function isClean(body) {
        return sanitize(body) === body;
    }
    IconSanitizer.isClean = isClean;
    // #endregion
})(IconSanitizer || (IconSanitizer = {}));
