export {};
//# sourceMappingURL=Globals.d.ts.map