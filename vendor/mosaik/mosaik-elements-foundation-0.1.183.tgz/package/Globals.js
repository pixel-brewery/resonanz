/**
 * @internal
 */
export const globals = Object.freeze({
    mode: '@@MODE',
    name: '@@NAME',
    version: '@@VERSION',
    description: '@@DESCRIPTION',
    author: '@@AUTHOR',
    buildDate: new Date(Number.parseInt('@@BUILDDATE')),
    license: '@@LICENSE'
});
//# sourceMappingURL=Globals.js.map