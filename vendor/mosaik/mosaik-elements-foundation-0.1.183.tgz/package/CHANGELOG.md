## 0.1.183 (2026-10-29)

### 🩹 Fixes

- **wrappers:** import each element from its own Foundation module ([#964](https://github.com/RueDeRennes/mosaik/pull/964))
- tile accessible names, kebab-case manifest attributes, preset pins after the scheme fix ([9dac0e2e95](https://github.com/RueDeRennes/mosaik/commit/9dac0e2e95))
- **build:** token lint contracts, self-contained source maps, packaged CLI launchers, showcase lint inputs ([4e5225c48f](https://github.com/RueDeRennes/mosaik/commit/4e5225c48f))
- **foundation:** carousel swipes, form field name, hidden-first render, tile events and keyboard resize, empty chart series ([fd0c5f5c50](https://github.com/RueDeRennes/mosaik/commit/fd0c5f5c50))
- **repo:** finish the kebab-case directory migration ([#494](https://github.com/RueDeRennes/mosaik/pull/494))

### ❤️ Thank You

- RueDeRennes

## 0.1.182 (2026-10-28)

### 🚀 Features

- **studio:** admin suite layouts and states, #600 blocks as recipes, recipe id aliases ([#600](https://github.com/RueDeRennes/mosaik/issues/600))
- **scheduler:** enhance selection functionality and styling ([bf4c416bfe](https://github.com/RueDeRennes/mosaik/commit/bf4c416bfe))
- **studio:** page library - 101 pages in ten templates ([#601](https://github.com/RueDeRennes/mosaik/pull/601), [#702](https://github.com/RueDeRennes/mosaik/issues/702), [#703](https://github.com/RueDeRennes/mosaik/issues/703), [#704](https://github.com/RueDeRennes/mosaik/issues/704), [#705](https://github.com/RueDeRennes/mosaik/issues/705), [#706](https://github.com/RueDeRennes/mosaik/issues/706), [#707](https://github.com/RueDeRennes/mosaik/issues/707), [#708](https://github.com/RueDeRennes/mosaik/issues/708), [#709](https://github.com/RueDeRennes/mosaik/issues/709), [#710](https://github.com/RueDeRennes/mosaik/issues/710), [#711](https://github.com/RueDeRennes/mosaik/issues/711))
- **studio:** every template gets a look of its own ([32516f7994](https://github.com/RueDeRennes/mosaik/commit/32516f7994))
- **studio:** landing and full site templates ([#599](https://github.com/RueDeRennes/mosaik/pull/599))
- **studio:** marketing ui blocks catalog ([#594](https://github.com/RueDeRennes/mosaik/pull/594))
- **studio:** shop blocks catalog ([#596](https://github.com/RueDeRennes/mosaik/pull/596), [#650](https://github.com/RueDeRennes/mosaik/issues/650))
- **studio:** data table catalog ([#597](https://github.com/RueDeRennes/mosaik/pull/597), [#663](https://github.com/RueDeRennes/mosaik/issues/663))
- **studio:** bento cards and bento grids catalog ([#598](https://github.com/RueDeRennes/mosaik/pull/598), [#672](https://github.com/RueDeRennes/mosaik/issues/672), [#673](https://github.com/RueDeRennes/mosaik/issues/673))
- **blog:** author profiles with protected CV and a generic Blog API module ([#1117](https://github.com/RueDeRennes/mosaik/issues/1117), [#1119](https://github.com/RueDeRennes/mosaik/issues/1119), [#1120](https://github.com/RueDeRennes/mosaik/issues/1120))

### 🩹 Fixes

- **studio:** align bento, hero and feature blocks with their references ([#1056](https://github.com/RueDeRennes/mosaik/pull/1056))
- **doppler:** update secrets sync command and project references in documentation ([0e1dee3457](https://github.com/RueDeRennes/mosaik/commit/0e1dee3457))

### ❤️ Thank You

- RueDeRennes

## 0.1.181 (2026-10-27)

### 🚀 Features

- add placeholder color to textBox components across themes ([332ef832ba](https://github.com/RueDeRennes/mosaik/commit/332ef832ba))
- update banner and reveal components across themes ([d7fdcb3c6c](https://github.com/RueDeRennes/mosaik/commit/d7fdcb3c6c))
- extend components, scheduler and Studio ([68a93b3ac6](https://github.com/RueDeRennes/mosaik/commit/68a93b3ac6))
- enhance documentation with local environment guidelines and testing constraints ([194c6e6cf3](https://github.com/RueDeRennes/mosaik/commit/194c6e6cf3))
- update pointer-events for event elements in SchedulerTimeGridView themes ([4b6b09898b](https://github.com/RueDeRennes/mosaik/commit/4b6b09898b))
- update SchedulerEventElement and SchedulerElement documentation and events ([012e20096f](https://github.com/RueDeRennes/mosaik/commit/012e20096f))
- add grid item position and resize handle interfaces ([2c56bd2561](https://github.com/RueDeRennes/mosaik/commit/2c56bd2561))
- add Flow Board tools and enhance drag-and-drop functionality ([9c478c72b7](https://github.com/RueDeRennes/mosaik/commit/9c478c72b7))
- add CardActionsTool, CardContentTool, and CardHeaderTool with corresponding tests ([68a00281e0](https://github.com/RueDeRennes/mosaik/commit/68a00281e0))

### 🩹 Fixes

- update TileManagerTileElement documentation and improve CSS part descriptions ([3b9d34fc1d](https://github.com/RueDeRennes/mosaik/commit/3b9d34fc1d))

### ❤️ Thank You

- RueDeRennes

## 0.1.180 (2026-10-24)

### 🚀 Features

- Add documentation for hover reveal functionality and wallet card components ([1d2e4cc173](https://github.com/RueDeRennes/mosaik/commit/1d2e4cc173))
- add numeric keyboard mode to VirtualKeyboardMode ([8622d98026](https://github.com/RueDeRennes/mosaik/commit/8622d98026))

### ❤️ Thank You

- RueDeRennes

## 0.1.179 (2026-10-23)

### 🚀 Features

- **bubbles:** add Memphis and Soho themes with styles and tokens ([854dfa1dbd](https://github.com/RueDeRennes/mosaik/commit/854dfa1dbd))

### ❤️ Thank You

- RueDeRennes

## 0.1.178 (2026-10-23)

### 🚀 Features

- enhance DateTimeBoxElement with period validation and improve elevation handling ([9600f73320](https://github.com/RueDeRennes/mosaik/commit/9600f73320))
- add new icons and update existing ones in mosaik-icons library ([16b8512a67](https://github.com/RueDeRennes/mosaik/commit/16b8512a67))
- **studio:** add the Pricing component blocks ([#617](https://github.com/RueDeRennes/mosaik/pull/617))
- **studio:** add --settle option to the block capture script ([203cd18dfe](https://github.com/RueDeRennes/mosaik/commit/203cd18dfe))
- add internationalization support for various input components ([ecf2c4ee57](https://github.com/RueDeRennes/mosaik/commit/ecf2c4ee57))
- update RoutewisePage type definition for better readability ([802687dd45](https://github.com/RueDeRennes/mosaik/commit/802687dd45))
- **mcp:** enhance template behavior validation and introduce catalog behavior signature ([008ae1bc67](https://github.com/RueDeRennes/mosaik/commit/008ae1bc67))

### 🩹 Fixes

- **carousel:** adopt the item declared selected as the initial selection ([dfba9f3977](https://github.com/RueDeRennes/mosaik/commit/dfba9f3977))

### ❤️ Thank You

- RueDeRennes

## 0.1.177 (2026-10-22)

### 🚀 Features

- **mcp:** integrate Mosaik Beta MCP server and configuration ([1b1beb0aa9](https://github.com/RueDeRennes/mosaik/commit/1b1beb0aa9))
- **gauge-components:** add renderGauge method to various gauge components ([8995aa7ce6](https://github.com/RueDeRennes/mosaik/commit/8995aa7ce6))

### ❤️ Thank You

- RueDeRennes

## 0.1.176 (2026-10-22)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.175 (2026-10-22)

### 🚀 Features

- **tests:** add unit tests for MarkdownRenderer and FormFieldElement components ([e6caa77f9f](https://github.com/RueDeRennes/mosaik/commit/e6caa77f9f))

### ❤️ Thank You

- RueDeRennes

## 0.1.174 (2026-10-21)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.173 (2026-10-20)

### 🚀 Features

- add unit tests for TileManagerTileElement, AvatarGroupElement, and Mixins ([a904d965d6](https://github.com/RueDeRennes/mosaik/commit/a904d965d6))
- add catalog functionality with recipe references and loaders ([b8875fb373](https://github.com/RueDeRennes/mosaik/commit/b8875fb373))

### ❤️ Thank You

- RueDeRennes

## 0.1.172 (2026-10-19)

### 🚀 Features

- enhance calendar navigation methods with detailed behavior descriptions ([8b7e50cc53](https://github.com/RueDeRennes/mosaik/commit/8b7e50cc53))
- add typography spacing functionality and tests ([f8ee1aa82c](https://github.com/RueDeRennes/mosaik/commit/f8ee1aa82c))
- add ToolsMdGenerator and related tests for project tool inventory management ([3ecec24f33](https://github.com/RueDeRennes/mosaik/commit/3ecec24f33))

### 🩹 Fixes

- **docs:** update file paths in documentation to use lowercase for theming directory ([01e101a985](https://github.com/RueDeRennes/mosaik/commit/01e101a985))
- guard API runtime imports on Vercel ([2062134f36](https://github.com/RueDeRennes/mosaik/commit/2062134f36))
- remove host paths and enforce portable imports ([b1681f0527](https://github.com/RueDeRennes/mosaik/commit/b1681f0527))
- resolve Mosaik backlog and normalize paths ([0ceda93bd3](https://github.com/RueDeRennes/mosaik/commit/0ceda93bd3))

### ❤️ Thank You

- RueDeRennes

## 0.1.171 (2026-10-16)

### 🚀 Features

- add SignaturePad and Chart components for Vue and Svelte ([852158021d](https://github.com/RueDeRennes/mosaik/commit/852158021d))

### ❤️ Thank You

- RueDeRennes

## 0.1.170 (2026-10-15)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.169 (2026-10-15)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.168 (2026-10-15)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.167 (2026-10-15)

### 🚀 Features

- Update backend contracts and workflow documentation for clarity and accuracy ([447d02b559](https://github.com/RueDeRennes/mosaik/commit/447d02b559))
- Add comprehensive documentation for Mosaik architecture and backend contracts ([da91d3a5f5](https://github.com/RueDeRennes/mosaik/commit/da91d3a5f5))
- Enhance RichTextBox and PromptBox functionality ([5c417e004e](https://github.com/RueDeRennes/mosaik/commit/5c417e004e))
- enhance build script and clean task with improved error handling and test coverage ([8b99c789c0](https://github.com/RueDeRennes/mosaik/commit/8b99c789c0))

### 🩹 Fixes

- update nx-generate command to specify directory for library creation ([06fa48d6f7](https://github.com/RueDeRennes/mosaik/commit/06fa48d6f7))

### ❤️ Thank You

- RueDeRennes

## 0.1.166 (2026-10-14)

### 🚀 Features

- enhance TimelineSeparatorElement with slot handling and label preservation ([315a6221d7](https://github.com/RueDeRennes/mosaik/commit/315a6221d7))

### ❤️ Thank You

- RueDeRennes

## 0.1.165 (2026-10-14)

### 🚀 Features

- add TimelineSeparator component with styles and tests ([44a25812d5](https://github.com/RueDeRennes/mosaik/commit/44a25812d5))

### ❤️ Thank You

- RueDeRennes

## 0.1.164 (2026-10-14)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.163 (2026-10-13)

### 🚀 Features

- enhance ColorPickerComponent with internationalization support ([75485d49b4](https://github.com/RueDeRennes/mosaik/commit/75485d49b4))

### ❤️ Thank You

- RueDeRennes

## 0.1.162 (2026-10-13)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.161 (2026-10-13)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.160 (2026-10-13)

### 🚀 Features

- update TextBox component tokens and styles across themes ([8bdfb0713e](https://github.com/RueDeRennes/mosaik/commit/8bdfb0713e))
- add StudioRecipePreviewView and StudioRecipesView components ([750faa2bdb](https://github.com/RueDeRennes/mosaik/commit/750faa2bdb))
- add ElementSchema and MarkupEmitter for attribute binding and markup generation ([45038f8b67](https://github.com/RueDeRennes/mosaik/commit/45038f8b67))

### ❤️ Thank You

- RueDeRennes

## 0.1.159 (2026-10-12)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.158 (2026-10-12)

### 🚀 Features

- update KbdShortcutComponent to support multiple modifier keys ([72d615ddc4](https://github.com/RueDeRennes/mosaik/commit/72d615ddc4))
- enhance KbdShortcutElement to support multiple modifier keys and update documentation/examples ([56833468d2](https://github.com/RueDeRennes/mosaik/commit/56833468d2))

### ❤️ Thank You

- RueDeRennes

## 0.1.157 (2026-10-11)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.156 (2026-10-11)

### 🚀 Features

- update comment styles and improve file copy tasks with tests ([fcbaabd66f](https://github.com/RueDeRennes/mosaik/commit/fcbaabd66f))

### ❤️ Thank You

- RueDeRennes

## 0.1.155 (2026-10-11)

### 🚀 Features

- enhance Expandable behavior with detailed event types ([bb12677d35](https://github.com/RueDeRennes/mosaik/commit/bb12677d35))

### ❤️ Thank You

- RueDeRennes

## 0.1.154 (2026-10-08)

### 🚀 Features

- **popup:** add focus restoration feature on close ([612ff3cde9](https://github.com/RueDeRennes/mosaik/commit/612ff3cde9))

### ❤️ Thank You

- RueDeRennes

## 0.1.153 (2026-10-07)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.152 (2026-10-06)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.151 (2026-10-06)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.150 (2026-10-05)

### 🚀 Features

- enhance Memphis theme styles for various components with new properties and adjustments ([7054ce562c](https://github.com/RueDeRennes/mosaik/commit/7054ce562c))
- update Memphis theme components with new styles and configurations ([cce7acbd73](https://github.com/RueDeRennes/mosaik/commit/cce7acbd73))

### ❤️ Thank You

- RueDeRennes

## 0.1.149 (2026-10-04)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.148 (2026-10-03)

### 🚀 Features

- **calendar:** enhance allowedViews behavior and update related documentation ([c3f86b8cea](https://github.com/RueDeRennes/mosaik/commit/c3f86b8cea))

### ❤️ Thank You

- RueDeRennes

## 0.1.147 (2026-10-03)

### 🚀 Features

- **scheduler:** add gesture support and enhance styling ([04777c82f3](https://github.com/RueDeRennes/mosaik/commit/04777c82f3))

### ❤️ Thank You

- RueDeRennes

## 0.1.146 (2026-10-02)

### 🚀 Features

- enhance scheduler event popup functionality and tests ([03d67ca9aa](https://github.com/RueDeRennes/mosaik/commit/03d67ca9aa))

### ❤️ Thank You

- RueDeRennes

## 0.1.145 (2026-10-02)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.144 (2026-09-30)

### 🚀 Features

- add support for unused keys detection and key consistency checks ([fdcdb7cf50](https://github.com/RueDeRennes/mosaik/commit/fdcdb7cf50))

### ❤️ Thank You

- RueDeRennes

## 0.1.143 (2026-09-29)

### 🚀 Features

- enhance message component behavior and add used keys analysis ([253cebd0bc](https://github.com/RueDeRennes/mosaik/commit/253cebd0bc))

### ❤️ Thank You

- RueDeRennes

## 0.1.142 (2026-09-29)

### 🩹 Fixes

- reduce breadcrumb item separator size for improved layout consistency ([f9d424676e](https://github.com/RueDeRennes/mosaik/commit/f9d424676e))

### ❤️ Thank You

- RueDeRennes

## 0.1.141 (2026-09-29)

### 🚀 Features

- **tests:** add unit tests for template resolution and generated code utilities ([5e60a19a77](https://github.com/RueDeRennes/mosaik/commit/5e60a19a77))

### 🩹 Fixes

- update archipel-platform dependencies to version 0.1.11 ([df20e8f678](https://github.com/RueDeRennes/mosaik/commit/df20e8f678))

### ❤️ Thank You

- RueDeRennes

## 0.1.140 (2026-09-29)

### 🚀 Features

- enhance repository workflow instructions and add SplitComponent intl support ([94e5ad6677](https://github.com/RueDeRennes/mosaik/commit/94e5ad6677))

### ❤️ Thank You

- RueDeRennes

## 0.1.139 (2026-09-29)

### 🚀 Features

- enhance repository workflow instructions and add SplitComponent intl support ([996d14e4f0](https://github.com/RueDeRennes/mosaik/commit/996d14e4f0))

### ❤️ Thank You

- RueDeRennes

## 0.1.138 (2026-09-29)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.137 (2026-09-29)

### 🚀 Features

- **selection:** add custom selection triggers for combo and select components ([8c4218a18a](https://github.com/RueDeRennes/mosaik/commit/8c4218a18a))

### ❤️ Thank You

- RueDeRennes

## 0.1.136 (2026-09-29)

### 🩹 Fixes

- **combo:** update background color to use border color property ([6adf642c45](https://github.com/RueDeRennes/mosaik/commit/6adf642c45))

### ❤️ Thank You

- RueDeRennes

## 0.1.135 (2026-09-29)

### 🚀 Features

- **breadcrumb:** add hasSeparator property and update breadcrumb item behavior ([12a99e559e](https://github.com/RueDeRennes/mosaik/commit/12a99e559e))

### 🩹 Fixes

- add timeout to scheduler locale formatting tests for improved performance ([48a093b3dc](https://github.com/RueDeRennes/mosaik/commit/48a093b3dc))

### ❤️ Thank You

- RueDeRennes

## 0.1.134 (2026-09-27)

### 🚀 Features

- enhance text wrapping behavior in banner components and related styles ([2d3e7bbff9](https://github.com/RueDeRennes/mosaik/commit/2d3e7bbff9))

### ❤️ Thank You

- RueDeRennes

## 0.1.133 (2026-09-27)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.132 (2026-09-27)

### 🚀 Features

- enhance table and menu item styles for better responsiveness and usability ([919ec25546](https://github.com/RueDeRennes/mosaik/commit/919ec25546))

### ❤️ Thank You

- RueDeRennes

## 0.1.131 (2026-09-26)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.130 (2026-09-26)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.129 (2026-09-25)

### 🚀 Features

- enhance ChartExportCommand to support theme variable preservation during image export ([cab5324fbf](https://github.com/RueDeRennes/mosaik/commit/cab5324fbf))

### 🩹 Fixes

- update backface visibility styles in FlipElement themes for improved rendering ([98b39a7544](https://github.com/RueDeRennes/mosaik/commit/98b39a7544))
- update documentation links and improve ChartExportCommand functionality with CSV export ([7153d2ae03](https://github.com/RueDeRennes/mosaik/commit/7153d2ae03))

### ❤️ Thank You

- RueDeRennes

## 0.1.128 (2026-09-24)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.127 (2026-09-23)

### 🚀 Features

- update VideoComponent and VideoElement documentation to include new properties for download and picture-in-picture support ([fb406ae7d0](https://github.com/RueDeRennes/mosaik/commit/fb406ae7d0))
- add hidden attribute handling for various components to improve visibility control ([0a0e7df7a4](https://github.com/RueDeRennes/mosaik/commit/0a0e7df7a4))

### 🩹 Fixes

- update sandbox network settings to include Unix socket permissions ([2c0bae6c33](https://github.com/RueDeRennes/mosaik/commit/2c0bae6c33))

### ❤️ Thank You

- RueDeRennes

## 0.1.126 (2026-09-19)

### 🚀 Features

- enhance list item elements with prefix and suffix styles ([ea384e8bd9](https://github.com/RueDeRennes/mosaik/commit/ea384e8bd9))

### ❤️ Thank You

- RueDeRennes

## 0.1.125 (2026-09-18)

### 🚀 Features

- add horizontal orientation styles and unit tests for UpDownSpinnerElement ([d438e9c431](https://github.com/RueDeRennes/mosaik/commit/d438e9c431))

### ❤️ Thank You

- RueDeRennes

## 0.1.124 (2026-09-17)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.123 (2026-09-17)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.122 (2026-09-16)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.121 (2026-09-16)

### 🚀 Features

- add selection runtime component with Playwright tests ([768f7f2fa6](https://github.com/RueDeRennes/mosaik/commit/768f7f2fa6))

### ❤️ Thank You

- RueDeRennes

## 0.1.120 (2026-09-15)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.119 (2026-09-15)

### 🚀 Features

- add shiftBoundary and shiftPadding properties to PopupElement ([b3ec017fb3](https://github.com/RueDeRennes/mosaik/commit/b3ec017fb3))

### ❤️ Thank You

- RueDeRennes

## 0.1.118 (2026-09-15)

### 🚀 Features

- **popup:** update documentation links and add click outside close functionality tests ([aeb763c988](https://github.com/RueDeRennes/mosaik/commit/aeb763c988))
- **menu-item:** improve interaction listener management in MenuItemElement ([7b8e1e6765](https://github.com/RueDeRennes/mosaik/commit/7b8e1e6765))

### ❤️ Thank You

- RueDeRennes

## 0.1.117 (2026-09-13)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.116 (2026-09-13)

### 🚀 Features

- **select, combo:** enhance input styles for better responsiveness and overflow handling ([a8886682d2](https://github.com/RueDeRennes/mosaik/commit/a8886682d2))

### ❤️ Thank You

- RueDeRennes

## 0.1.115 (2026-09-13)

### 🚀 Features

- **toast:** add responsive toast sizing behavior and related configurations ([b5c6b55225](https://github.com/RueDeRennes/mosaik/commit/b5c6b55225))

### ❤️ Thank You

- RueDeRennes

## 0.1.114 (2026-09-12)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.113 (2026-09-12)

### 🚀 Features

- **segment:** add size property to MosaikSegment and SegmentComponent ([c9d1fc4d49](https://github.com/RueDeRennes/mosaik/commit/c9d1fc4d49))

### ❤️ Thank You

- RueDeRennes

## 0.1.112 (2026-09-11)

### 🩹 Fixes

- update release script commands for consistency and clarity ([ccedd59e43](https://github.com/RueDeRennes/mosaik/commit/ccedd59e43))
- update documentation links and definitions for various elements ([0255773efd](https://github.com/RueDeRennes/mosaik/commit/0255773efd))

### ❤️ Thank You

- RueDeRennes

## 0.1.111 (2026-09-11)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.110 (2026-09-10)

### 🚀 Features

- **DateTimeBox:** introduce internationalization support and enhance functionality ([ca3d4ac1ac](https://github.com/RueDeRennes/mosaik/commit/ca3d4ac1ac))

### 🩹 Fixes

- **ci:** make package publishing release-only ([1c6c4162ae](https://github.com/RueDeRennes/mosaik/commit/1c6c4162ae))

### ❤️ Thank You

- RueDeRennes

## 0.1.109 (2026-09-10)

### 🚀 Features

- add focus ring color variable to select element styles and remove obsolete unit tests ([fd68ab64d2](https://github.com/RueDeRennes/mosaik/commit/fd68ab64d2))

### ❤️ Thank You

- RueDeRennes

## 0.1.108 (2026-09-09)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.107 (2026-09-09)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.106 (2026-09-08)

### 🚀 Features

- **DataTable:** add footer support with custom templates ([691bdc79ca](https://github.com/RueDeRennes/mosaik/commit/691bdc79ca))

### ❤️ Thank You

- RueDeRennes

## 0.1.103 (2026-09-06)

### 🚀 Features

- **segment-legend:** add shadow properties to SegmentLegend and SegmentLegendItem components ([3cb9db595b](https://github.com/RueDeRennes/mosaik/commit/3cb9db595b))

### 🩹 Fixes

- **nx:** remove invalid clean task inputs ([42a74bf3a0](https://github.com/RueDeRennes/mosaik/commit/42a74bf3a0))
- **packages:** install runtime dependencies ([e91421722e](https://github.com/RueDeRennes/mosaik/commit/e91421722e))

### ❤️ Thank You

- RueDeRennes

## 0.1.102 (2026-09-04)

### 🚀 Features

- **database:** implement Accelerate database module and service ([b06c2028d3](https://github.com/RueDeRennes/mosaik/commit/b06c2028d3))

### ❤️ Thank You

- RueDeRennes

## 0.1.101 (2026-09-04)

### 🚀 Features

- **banner:** add vertical orientation styles and update related components ([c5d127ccbd](https://github.com/RueDeRennes/mosaik/commit/c5d127ccbd))

### ❤️ Thank You

- RueDeRennes

## 0.1.100 (2026-09-03)

### 🚀 Features

- **segment:** add shadow properties and update styles for segment elements ([12fbf0c361](https://github.com/RueDeRennes/mosaik/commit/12fbf0c361))

### ❤️ Thank You

- RueDeRennes

## 0.1.99 (2026-09-03)

### 🚀 Features

- add includes parser and sort tokens preprocessor ([54968b87f7](https://github.com/RueDeRennes/mosaik/commit/54968b87f7))

### ❤️ Thank You

- RueDeRennes

## 0.1.98 (2026-09-02)

### 🚀 Features

- update segment bar and ring styles with new emphasis scale and gap calculations ([6ea316222b](https://github.com/RueDeRennes/mosaik/commit/6ea316222b))
- **toast-demo:** implement toast demo component with styling and functionality ([973e709011](https://github.com/RueDeRennes/mosaik/commit/973e709011))
- add segment legend and item components with theming support ([2117a2721a](https://github.com/RueDeRennes/mosaik/commit/2117a2721a))

### ❤️ Thank You

- RueDeRennes

## 0.1.97 (2026-08-31)

### 🩹 Fixes

- **tooltip:** ensure tooltips do not create scroll containers and update documentation links ([701613ca25](https://github.com/RueDeRennes/mosaik/commit/701613ca25))

### ❤️ Thank You

- RueDeRennes

## 0.1.96 (2026-08-31)

### 🚀 Features

- update scheduler component styles and tokens ([6cfb479289](https://github.com/RueDeRennes/mosaik/commit/6cfb479289))

### 🩹 Fixes

- **theme:** unify elevation and typography across all three themes ([8465d2856f](https://github.com/RueDeRennes/mosaik/commit/8465d2856f))

### ❤️ Thank You

- Claude Opus 5
- RueDeRennes

## 0.1.95 (2026-08-28)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.94 (2026-08-27)

### 🚀 Features

- **calendar:** update first day of week handling to support locale defaults ([ff913722c8](https://github.com/RueDeRennes/mosaik/commit/ff913722c8))

### ❤️ Thank You

- RueDeRennes

## 0.1.93 (2026-08-27)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.92 (2026-08-27)

### 🚀 Features

- enhance property templates for DateBox, DateTimeBox, Scheduler, and Epg components ([b442d059c2](https://github.com/RueDeRennes/mosaik/commit/b442d059c2))

## 0.1.91 (2026-08-27)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.90 (2026-08-27)

### 🚀 Features

- enhance date and time formatting capabilities ([583ea7a2a2](https://github.com/RueDeRennes/mosaik/commit/583ea7a2a2))

## 0.1.89 (2026-08-27)

### 🚀 Features

- enhance locale formatting for calendar and scheduler components ([d991213864](https://github.com/RueDeRennes/mosaik/commit/d991213864))

## 0.1.88 (2026-08-27)

### 🚀 Features

- **tests:** add unit tests for various controllers and directives ([c1dee32ea5](https://github.com/RueDeRennes/mosaik/commit/c1dee32ea5))
- add custom Vitest configuration with summary reporter ([193b1ea475](https://github.com/RueDeRennes/mosaik/commit/193b1ea475))

## 0.1.87 (2026-08-26)

### 🚀 Features

- add OpenAPI TypeScript generation tests and templates ([c5c6b663fe](https://github.com/RueDeRennes/mosaik/commit/c5c6b663fe))
- update FlowBoard theme styles to exclude actions slot from slotted elements ([b133f6e250](https://github.com/RueDeRennes/mosaik/commit/b133f6e250))
- enhance ChatPromptBox and ChatPromptBoxQueue components with new props and methods ([df4e92812c](https://github.com/RueDeRennes/mosaik/commit/df4e92812c))
- update FlowBoard themes with improved translate calculations and add handling for front sizing in stack mixins ([7e39988037](https://github.com/RueDeRennes/mosaik/commit/7e39988037))
- enhance FlowBoard component with selection capabilities ([63aa920e5a](https://github.com/RueDeRennes/mosaik/commit/63aa920e5a))
- **knob:** add KnobComponent and associated styles for cosmopolitan, joy, and memphis themes ([ae06efd198](https://github.com/RueDeRennes/mosaik/commit/ae06efd198))
- enhance chat and segment components with new styling and transition properties ([b203df4b03](https://github.com/RueDeRennes/mosaik/commit/b203df4b03))
- **toast:** implement toast stacking behavior ([aa9c4969ff](https://github.com/RueDeRennes/mosaik/commit/aa9c4969ff))
- **scheduler:** implement event layout and month bar layout features ([b34d9d5c20](https://github.com/RueDeRennes/mosaik/commit/b34d9d5c20))
- add expand/collapse events for FlowBoard columns ([a42034e45e](https://github.com/RueDeRennes/mosaik/commit/a42034e45e))
- add SegmentBar and SegmentRing components with corresponding styles and themes ([cf0cd6eb3d](https://github.com/RueDeRennes/mosaik/commit/cf0cd6eb3d))
- **table:** update styles for header, footer, and body elements to improve layout and responsiveness ([a8c381d4d9](https://github.com/RueDeRennes/mosaik/commit/a8c381d4d9))
- Enhance FlowBoard component with improved scrolling and layout features ([162a92f4f8](https://github.com/RueDeRennes/mosaik/commit/162a92f4f8))
- **tour-controls:** add TourControlsElement with customizable styles and functionality ([2a338de689](https://github.com/RueDeRennes/mosaik/commit/2a338de689))
- **mcp:** add JSON parse error middleware and related tests ([1478fb4b4c](https://github.com/RueDeRennes/mosaik/commit/1478fb4b4c))
- **combo:** enhance styles and functionality across themes ([de2162bd87](https://github.com/RueDeRennes/mosaik/commit/de2162bd87))
- **chat:** update appearance and variant properties for Chat components ([c3c3f36ec5](https://github.com/RueDeRennes/mosaik/commit/c3c3f36ec5))
- **chat:** enhance message resizing and scrolling behavior ([6d32127ce7](https://github.com/RueDeRennes/mosaik/commit/6d32127ce7))
- **tour:** add tour behaviors ([cf7e9f15b5](https://github.com/RueDeRennes/mosaik/commit/cf7e9f15b5))
- **ai:** add chat support backend/frontend ([a939e7bbcc](https://github.com/RueDeRennes/mosaik/commit/a939e7bbcc))
- **tour:** add more tour functionality ([a2da8233ed](https://github.com/RueDeRennes/mosaik/commit/a2da8233ed))
- **tour:** add more abstraction layer stuff ([571b8ab473](https://github.com/RueDeRennes/mosaik/commit/571b8ab473))
- **tour:** finalize tour implementation ([022ce8fbf9](https://github.com/RueDeRennes/mosaik/commit/022ce8fbf9))
- **tour:** finalize tour implementation ([d3c4f1f7c1](https://github.com/RueDeRennes/mosaik/commit/d3c4f1f7c1))
- **theming:** replace direct event handling with proxy output subscription ([e313c5977b](https://github.com/RueDeRennes/mosaik/commit/e313c5977b))
- **api:** add new interfaces and components for prompt box functionality ([1b7d17e417](https://github.com/RueDeRennes/mosaik/commit/1b7d17e417))
- **components:** add floating label support to various input components ([31c9f86382](https://github.com/RueDeRennes/mosaik/commit/31c9f86382))
- **chat:** add ChatPromptBoxComponent and related styles ([671fe74a6e](https://github.com/RueDeRennes/mosaik/commit/671fe74a6e))
- **Table:** add cell height property and update related styles ([579d46a1d1](https://github.com/RueDeRennes/mosaik/commit/579d46a1d1))
- **DrawerContainerElement:** synchronize content margins with drawer size changes ([d2d8289ae0](https://github.com/RueDeRennes/mosaik/commit/d2d8289ae0))
- **drawer:** add DrawerRail component and associated styles ([8a80e20345](https://github.com/RueDeRennes/mosaik/commit/8a80e20345))
- **overlay:** add requestAttention and closeAttempt CloseAttempted ([54c83ed0d4](https://github.com/RueDeRennes/mosaik/commit/54c83ed0d4))
- **overlay:** add requestAttention and closeAttempt CloseAttempted ([27f164ec7f](https://github.com/RueDeRennes/mosaik/commit/27f164ec7f))
- **overlay:** add requestAttention and closeAttempt CloseAttempted ([1f35ef1a7a](https://github.com/RueDeRennes/mosaik/commit/1f35ef1a7a))
- **dataList:** add caption/summary slot projection ([7e107dc5f1](https://github.com/RueDeRennes/mosaik/commit/7e107dc5f1))
- **dataList:** add caption/summary slot projection ([89cb449e97](https://github.com/RueDeRennes/mosaik/commit/89cb449e97))
- **icon:** add IconPipe and update IconNameDirective for new components ([786e6dc8bb](https://github.com/RueDeRennes/mosaik/commit/786e6dc8bb))
- **list-item-group:** enhance header styling across themes ([eb9cb256ba](https://github.com/RueDeRennes/mosaik/commit/eb9cb256ba))
- **color-swatch:** add handleClick method to ColorSwatchElement class ([a148cc032d](https://github.com/RueDeRennes/mosaik/commit/a148cc032d))
- **color-swatch:** enhance ColorSwatch component with new properties and events ([1ca631f146](https://github.com/RueDeRennes/mosaik/commit/1ca631f146))
- **data-table:** add dataTableSortChanged event and related interfaces ([511727e2f9](https://github.com/RueDeRennes/mosaik/commit/511727e2f9))
- **toast:** enhance toast component with icon and appearance variants ([e5fe7d2071](https://github.com/RueDeRennes/mosaik/commit/e5fe7d2071))
- **toast:** add new positions and action ([581725264f](https://github.com/RueDeRennes/mosaik/commit/581725264f))
- **toast:** add new positions and action ([a8d2411bae](https://github.com/RueDeRennes/mosaik/commit/a8d2411bae))
- **toast:** add new positions and action ([87095811db](https://github.com/RueDeRennes/mosaik/commit/87095811db))
- **theme:** add focus ring properties to various components ([7b2338309e](https://github.com/RueDeRennes/mosaik/commit/7b2338309e))
- **nx-import:** add Turborepo and Vite migration guides ([6340733088](https://github.com/RueDeRennes/mosaik/commit/6340733088))
- **success-state:** add iconSize property to SuccessStateElement and related components ([15e6640e72](https://github.com/RueDeRennes/mosaik/commit/15e6640e72))
- **stepper:** enable text wrapping for step header, description, and hint ([d35054d5e4](https://github.com/RueDeRennes/mosaik/commit/d35054d5e4))
- **stepper:** enhance stepper component with slot handling and styling improvements ([b11dd29f63](https://github.com/RueDeRennes/mosaik/commit/b11dd29f63))
- **empty-state:** update slots for header and content in EmptyStateElement ([491a61d272](https://github.com/RueDeRennes/mosaik/commit/491a61d272))
- **scheduler:** fixed some border styles ([be0ed0d3cc](https://github.com/RueDeRennes/mosaik/commit/be0ed0d3cc))
- **style:** updated flowboard styles ([06c80df1a6](https://github.com/RueDeRennes/mosaik/commit/06c80df1a6))
- **flowboard, scheduler:** add appearance property and show tools functionality ([5e34f86cc0](https://github.com/RueDeRennes/mosaik/commit/5e34f86cc0))
- **caveman:** add caveman prompt with intensity levels and usage examples ([18f6881aad](https://github.com/RueDeRennes/mosaik/commit/18f6881aad))
- **chat:** add minRows and maxRows properties to ChatInputElement and update templates ([f1e2f9ea3d](https://github.com/RueDeRennes/mosaik/commit/f1e2f9ea3d))
- **chat:** add actions slot and update styles for chat message components ([eacedaf22c](https://github.com/RueDeRennes/mosaik/commit/eacedaf22c))
- **chat:** enhance chat components with inheritance and styling improvements ([969dcf66d2](https://github.com/RueDeRennes/mosaik/commit/969dcf66d2))
- **chart:** add pending update handling and readiness check for ApexCharts ([ff05d10045](https://github.com/RueDeRennes/mosaik/commit/ff05d10045))
- **persona:** enhance persona component with presence slot and related styles ([f5697fb5a2](https://github.com/RueDeRennes/mosaik/commit/f5697fb5a2))
- **menu:** use Icons for menu item caret icons instead of string literals ([fa381ee1f6](https://github.com/RueDeRennes/mosaik/commit/fa381ee1f6))
- **database:** add TypedDatabase for type-safe Prisma client and services ([4c40f5dffb](https://github.com/RueDeRennes/mosaik/commit/4c40f5dffb))
- **project:** add documentation build command to build options ([5bbc535144](https://github.com/RueDeRennes/mosaik/commit/5bbc535144))
- **api:** add ClickableComponent and related types for mosaik-elements ([81f1a5e1be](https://github.com/RueDeRennes/mosaik/commit/81f1a5e1be))
- **calendar:** add new CSS parts and properties to CalendarItemElement and ClickableElement ([8a0584991c](https://github.com/RueDeRennes/mosaik/commit/8a0584991c))
- **calendar:** enhance Calendar and DateBox components with new props ([f85c239865](https://github.com/RueDeRennes/mosaik/commit/f85c239865))
- **nx-import:** add Turborepo and Vite migration guides ([a0faf8a2ae](https://github.com/RueDeRennes/mosaik/commit/a0faf8a2ae))
- **order-management:** add filter option to select components and enhance focus management ([97c9824f16](https://github.com/RueDeRennes/mosaik/commit/97c9824f16))
- **popup:** add sync property to PopupElement and update template bindings ([274e8e771f](https://github.com/RueDeRennes/mosaik/commit/274e8e771f))
- **popup:** add sync property to PopupElement and related components ([5b644a14fb](https://github.com/RueDeRennes/mosaik/commit/5b644a14fb))
- **filebox:** add FileBox component and related styles for multiple themes ([95a1acc84f](https://github.com/RueDeRennes/mosaik/commit/95a1acc84f))
- **validators:** add dateNotBefore and dateNotAfter validation functions ([cea71f1773](https://github.com/RueDeRennes/mosaik/commit/cea71f1773))
- **components:** add WheelPicker component for React, Svelte, and Vue ([b9a46f3d3e](https://github.com/RueDeRennes/mosaik/commit/b9a46f3d3e))
- **menu:** add formatter property to MenuItem and MenuItemGroup components ([a1e3f2f1cc](https://github.com/RueDeRennes/mosaik/commit/a1e3f2f1cc))
- **api:** add formatter property to MenuItem and MenuItemGroup components ([aa31380bbd](https://github.com/RueDeRennes/mosaik/commit/aa31380bbd))
- **menu:** add formatter property to MenuItem and MenuItemGroup components ([76e2cc101c](https://github.com/RueDeRennes/mosaik/commit/76e2cc101c))
- **tile:** add Shopify Polaris Tile Theme with Mosaik design tokens ([6a404f36d3](https://github.com/RueDeRennes/mosaik/commit/6a404f36d3))
- **menu:** add text formatting capabilities to menu item and group elements ([27052671d7](https://github.com/RueDeRennes/mosaik/commit/27052671d7))
- **list-item:** add slottable functionality and update methods ([99b0fc8657](https://github.com/RueDeRennes/mosaik/commit/99b0fc8657))
- **overlays:** implement OverlayStackManager for better overlay handling ([2a9e5e31bf](https://github.com/RueDeRennes/mosaik/commit/2a9e5e31bf))
- **TabStripElement:** override firstUpdated to align indicator on initial update ([c4e15cc780](https://github.com/RueDeRennes/mosaik/commit/c4e15cc780))
- **MessageBox:** update MessageBoxResult values to strings and add alignment property ([22df7be730](https://github.com/RueDeRennes/mosaik/commit/22df7be730))
- **intl:** add injection tokens for various components' intl configurations ([09dd365bb2](https://github.com/RueDeRennes/mosaik/commit/09dd365bb2))
- **tooltip:** add TooltipDirective for customizable tooltips ([9d5891816b](https://github.com/RueDeRennes/mosaik/commit/9d5891816b))
- **page-header:** update styles for content layout and visibility handling ([9c1674fced](https://github.com/RueDeRennes/mosaik/commit/9c1674fced))
- **page-header:** add content part with flex layout and hidden state ([0155355fa4](https://github.com/RueDeRennes/mosaik/commit/0155355fa4))
- **page-header:** add new Page Header component with templates and styles ([044eb89596](https://github.com/RueDeRennes/mosaik/commit/044eb89596))
- **layouts:** enhance layout components with CSS custom properties and slot adjustments ([d72d6116bb](https://github.com/RueDeRennes/mosaik/commit/d72d6116bb))
- **page-header:** enhance typography and layout for headers and subheaders ([824031a02a](https://github.com/RueDeRennes/mosaik/commit/824031a02a))
- **data-table:** add events for table selection and editor state changes ([eb94167184](https://github.com/RueDeRennes/mosaik/commit/eb94167184))
- **DataTable:** add events for table selection and editor actions ([e82237349d](https://github.com/RueDeRennes/mosaik/commit/e82237349d))
- **release:** update release commands to use version from mosaik-themes package ([89c563205d](https://github.com/RueDeRennes/mosaik/commit/89c563205d))
- **breadcrumb:** enhance breadcrumb and item components with new properties and slots ([2aa158afd2](https://github.com/RueDeRennes/mosaik/commit/2aa158afd2))
- **tooltip:** implement TooltipDirective and ITooltipDirectiveConfig interface ([a6b0ecedfa](https://github.com/RueDeRennes/mosaik/commit/a6b0ecedfa))
- **duration-box:** add DurationBoxElementValueAccessor and related API documentation ([41c2273c72](https://github.com/RueDeRennes/mosaik/commit/41c2273c72))
- **theme:** enhance theme application with global CSS variable support ([c3822c97d3](https://github.com/RueDeRennes/mosaik/commit/c3822c97d3))
- **table:** add caption and summary slots to DataTableElement and TableElement ([ceedb1fcf4](https://github.com/RueDeRennes/mosaik/commit/ceedb1fcf4))
- **buttons:** enhance button sizes and styles for FloatingActionButton, PressButton, RepeatButton, and ToggleButton ([da69daeb64](https://github.com/RueDeRennes/mosaik/commit/da69daeb64))
- **secrets-vercel-sync:** implement secrets synchronization from providers to Vercel ([09906bfba4](https://github.com/RueDeRennes/mosaik/commit/09906bfba4))
- **app:** add AppView and AppViewStyle for Mosaik Studio ([2fe81e7079](https://github.com/RueDeRennes/mosaik/commit/2fe81e7079))
- **marquee:** update article card rendering and enhance TOON format integration ([4ff2f3de21](https://github.com/RueDeRennes/mosaik/commit/4ff2f3de21))
- **doppler): add command configuration for Doppler integration chore(dependencies:** update archipel platform packages to version 0.0.16 ([a88f0921d9](https://github.com/RueDeRennes/mosaik/commit/a88f0921d9))
- **auth): implement JWT enrichment and user profile management with Prisma feat(auth): add no-op MFA adapter for future use feat(auth): create Prisma-backed session and social auth adapters feat(auth): add user and user profile repositories for data access feat(auth): implement user service for authentication and profile management style(marquee:** enhance marquee styles for better layout and animation ([db7f0a5229](https://github.com/RueDeRennes/mosaik/commit/db7f0a5229))
- **deployment:** enable corepack in install script for mosaik-blog ([0be6666537](https://github.com/RueDeRennes/mosaik/commit/0be6666537))
- **blog): initialize blog app with TypeScript, Vite, and ESLint configuration feat(blog): add Vercel configuration for deployment feat(blog): implement production and development Vite configurations refactor(routes): remove DocsService and related routes from RoutesService refactor(app): update AppBar and SideNav to link to external blog URL refactor(views): remove ArticlesView and related templates refactor(controllers): clean up SideNav filter controllers by removing DocsService references chore(static-content): remove static content plugin and related interfaces chore(package:** update dependencies and scripts for blog app ([2694db201b](https://github.com/RueDeRennes/mosaik/commit/2694db201b))
- **recipes): add ActivityRingsRecipe and DeploymentStatusRecipe definitions chore(recipes): update index to include new recipe imports fix(ProjectService): add 'stored' property to project data structure refactor(ProfileView:** comment out API calls for profile updates ([58f98aa332](https://github.com/RueDeRennes/mosaik/commit/58f98aa332))
- **mcp:** implement McpThemeRegistrar for theme generation and validation tools ([75773f0d88](https://github.com/RueDeRennes/mosaik/commit/75773f0d88))
- **projects:** implement multi-page support in ProjectService and related components ([a77c6f1154](https://github.com/RueDeRennes/mosaik/commit/a77c6f1154))
- **nx-tasks): add executor for generating package documentation with TypeDoc feat(nx-tasks): create schema for generate-package-docs executor options feat(nx-tasks): implement markdown processing utilities for TypeDoc output feat(nx-tasks): add valid HTML tags for markdown processing chore(projects): configure docs-package executor for multiple libraries chore(deps:** update dependencies for TypeDoc and markdown processing ([bdac227dd0](https://github.com/RueDeRennes/mosaik/commit/bdac227dd0))
- **table-editor:** enhance column editor with scroll support and new properties ([79b1c5c7dd](https://github.com/RueDeRennes/mosaik/commit/79b1c5c7dd))
- **data-list): update itemDefinitions to use pathFn for value retrieval feat(table): enhance getColumnMetadata to include key in metadata structure feat(data-table:** filter hidden columns in getColumns and template rendering ([b6f6dfb6ea](https://github.com/RueDeRennes/mosaik/commit/b6f6dfb6ea))
- **data-list:** enhance item definition with pathFn for value retrieval ([256ebbea74](https://github.com/RueDeRennes/mosaik/commit/256ebbea74))
- **mcp:** add component suggestion feature and improve not found messages ([6e642e08b4](https://github.com/RueDeRennes/mosaik/commit/6e642e08b4))
- **themes:** enhance ThemeGenerator and ThemeObserver with detailed documentation and improvements ([e4354e9700](https://github.com/RueDeRennes/mosaik/commit/e4354e9700))
- **playground): extract and merge non-serializable values during JSON round-trip fix(components): update component options and improve data table sorting functionality refactor(segment): integrate property groups for segment and segment item elements style(table): add border-radius CSS property for table themes and improve styling chore(table): update table component methods and enhance slot handling fix(table:** ensure caption visibility and improve table column editor styles ([4a6afb969c](https://github.com/RueDeRennes/mosaik/commit/4a6afb969c))
- **table): add caption slot and allColumnsHidden property to DataTable and Table components feat(table): implement banner for hidden columns in DataTable with actions fix(table): adjust CSS for caption and banner styling across themes refactor(table:** update DataTable and TableColumnEditor components to support new properties ([fa231e0faa](https://github.com/RueDeRennes/mosaik/commit/fa231e0faa))
- **table:** implement column width tracking and editor dismissal event ([d797e5381d](https://github.com/RueDeRennes/mosaik/commit/d797e5381d))
- **portal:** enhance connectedCallback to handle content re-projection on reconnect ([88d2d8d16a](https://github.com/RueDeRennes/mosaik/commit/88d2d8d16a))
- **accessors:** add value accessors for DataList, DataTable, List, and Tree elements ([9845355730](https://github.com/RueDeRennes/mosaik/commit/9845355730))
- **table:** add titles to columns and update min-width styles for table elements ([f2af8609b6](https://github.com/RueDeRennes/mosaik/commit/f2af8609b6))
- **placeholder:** add Placeholder component with sample templates and styles ([e7424de27b](https://github.com/RueDeRennes/mosaik/commit/e7424de27b))
- **table:** add multi-sort mode and display sort index in header cells ([3cb5241ab3](https://github.com/RueDeRennes/mosaik/commit/3cb5241ab3))
- **DataTable): add column reordering functionality with drag-and-drop support feat(DataTable): implement reorderable property for columns in DataTableElement feat(DataTable): update template to support drag-and-drop for column headers feat(DataTable): enhance IDataTableColumnDefinition with reorderable attribute feat(DataTable): add reorderable property to IDataTableElementProps interface test(DataTable): add end-to-end tests for DataTable rendering and interactions test(FlowBoard): implement tests for rendering, drag-and-drop, and item interactions test(Scheduler:** create tests for rendering, navigation, event details, and interactions ([d4c2ccf9e3](https://github.com/RueDeRennes/mosaik/commit/d4c2ccf9e3))
- **portal:** initialize portal listener and observer on host connection ([0bf610c947](https://github.com/RueDeRennes/mosaik/commit/0bf610c947))
- **drag-drop:** add preview mode options and enhance drag functionality with new features ([56408f00e7](https://github.com/RueDeRennes/mosaik/commit/56408f00e7))
- **data-table:** add internationalization support and inheritance consumer controller ([ed302d741c](https://github.com/RueDeRennes/mosaik/commit/ed302d741c))
- **table:** integrate internationalization support for table components ([b04c324044](https://github.com/RueDeRennes/mosaik/commit/b04c324044))
- **table:** enhance column visibility and styling for better UX ([f2d458ccc6](https://github.com/RueDeRennes/mosaik/commit/f2d458ccc6))
- **data-table:** add custom cell and header templates with directives for data table columns ([646ed79109](https://github.com/RueDeRennes/mosaik/commit/646ed79109))
- **data-table): enhance IDataTableElementProps with new properties and update themes feat(table-header-cell): add hideable, autoSizeable, and columnChoosable props feat(icons): add new icons for column actions and update existing ones fix(data-table:** bind new properties in Svelte and Vue components ([fbb6e0d297](https://github.com/RueDeRennes/mosaik/commit/fbb6e0d297))
- **table:** implement pinable feature and enhance column management in table components ([29c66318c5](https://github.com/RueDeRennes/mosaik/commit/29c66318c5))
- **table:** add TableColumnEditor component and related events for column management ([79bc9b0414](https://github.com/RueDeRennes/mosaik/commit/79bc9b0414))
- **table:** add base classes and interfaces for table cell and row components ([2ab0b64071](https://github.com/RueDeRennes/mosaik/commit/2ab0b64071))
- **table:** add column pinning and resizing functionality with styles and events ([edfbcf86d7](https://github.com/RueDeRennes/mosaik/commit/edfbcf86d7))
- **theme:** update action bar and table components for Joy and Memphis themes ([584bd94fd7](https://github.com/RueDeRennes/mosaik/commit/584bd94fd7))
- **table:** add selection modes and types, enhance styling for selected and alternating rows ([57f5b6e71b](https://github.com/RueDeRennes/mosaik/commit/57f5b6e71b))
- **playwright-guidelines:** add Playwright test writing guidelines document ([27bf34e023](https://github.com/RueDeRennes/mosaik/commit/27bf34e023))
- **toolbox): add layers tab visibility control in StudioToolbox feat(designer): implement mobile layout constraints in DesignerView feat(dialogs): create CodeViewDialog for code generation display feat(dialogs): add EditProjectDialog for project name and icon editing feat(dialogs): implement SaveAsRecipeDialog for saving recipes style(dropdown): adjust dropdown button styles for better responsiveness style(avatar:** update avatar styles for transparent backgrounds ([f22dd9095f](https://github.com/RueDeRennes/mosaik/commit/f22dd9095f))
- **designer-canvas): add interaction mode for panning and cursor style docs(mosaik-wizard): enhance dir and lang property descriptions docs(mosaik-wrap): improve dir and lang property descriptions chore(cspell): add new words for artboard, pannable, and zoomable fix(designer-canvas): update cursor styles for interaction modes refactor(designer-canvas:** reorganize imports and improve code structure ([712697b80a](https://github.com/RueDeRennes/mosaik/commit/712697b80a))
- **designer): implement Save As Recipe dialog and functionality feat(designer): add hidden-preview class for conditional visibility fix(expander): update slot names for header and sub-header components style(playground:** correct layout spacing variable name ([5135485994](https://github.com/RueDeRennes/mosaik/commit/5135485994))
- **design:** add print styles for studio and designer views, include toggled event in components ([4125a87f02](https://github.com/RueDeRennes/mosaik/commit/4125a87f02))
- **tile:** add Tile component for React, Svelte, and Vue with theme support ([0d58f0594e](https://github.com/RueDeRennes/mosaik/commit/0d58f0594e))
- **code-editor:** add language support and themes for CodeMirror integration ([f96840827e](https://github.com/RueDeRennes/mosaik/commit/f96840827e))
- **typewriter:** add TypewriterElement component with typing animation effect ([4824c9048e](https://github.com/RueDeRennes/mosaik/commit/4824c9048e))
- **shared/mosaik-meta:** add vitest configuration and migration tools for components ([1e3c8f5f9c](https://github.com/RueDeRennes/mosaik/commit/1e3c8f5f9c))
- **styles:** add shared styles and update package dependencies ([8c63e6d5e8](https://github.com/RueDeRennes/mosaik/commit/8c63e6d5e8))
- **icons:** update fluent icons ([8d2104dfcf](https://github.com/RueDeRennes/mosaik/commit/8d2104dfcf))
- **canvas): add node reordering and duplication functionality feat(designer): implement methods to handle node reordering and duplication refactor(designer): streamline dialog handling and event listeners refactor(designer): replace button icons with action bar component docs(tree-item): update documentation for prefix and suffix slots chore(meta:** update metadata for new prefix and suffix slots ([258e029139](https://github.com/RueDeRennes/mosaik/commit/258e029139))
- **navigation:** add studio link to app bar and update translations for navigation ([06b83f8561](https://github.com/RueDeRennes/mosaik/commit/06b83f8561))
- **toolbox:** enhance toolbox item layout with responsive styles and add progress indicator recipe ([19447a1214](https://github.com/RueDeRennes/mosaik/commit/19447a1214))
- **designer): add EditProjectDialog for editing project details and icon feat(projects): implement project templates and allow project creation from templates style(projects): enhance ProjectsView with new styles and layout adjustments fix(dropdown): update dropdown button styles for better responsiveness and appearance docs(carousel:** update carousel examples to use new image component ([d5690e8dea](https://github.com/RueDeRennes/mosaik/commit/d5690e8dea))
- **studio): add Vite configuration and TypeScript support for Mosaik Studio feat(studio): implement localization plugin and update build settings feat(studio): enhance AppBarTemplate with designer navigation link feat(studio): add new hero images for landing pages fix(studio): correct HTML structure in carousel and wizard components style(studio): update background styles for designer canvas themes fix(studio): adjust split element thumb positioning in themes chore(studio:** update dependencies and add vitest configuration ([1eb81044ad](https://github.com/RueDeRennes/mosaik/commit/1eb81044ad))
- **designer): add Svelte and Vue components for designer layout and functionality feat(themes:** create tokens and JSON configurations for designer components in multiple themes ([447a42cf59](https://github.com/RueDeRennes/mosaik/commit/447a42cf59))
- **actionbar:** add ActionbarSeparatorComponent and related theme tokens ([813fe9918f](https://github.com/RueDeRennes/mosaik/commit/813fe9918f))
- **toolbar:** add custom content template and update toolbar styles for dividers ([eade1af634](https://github.com/RueDeRennes/mosaik/commit/eade1af634))
- **callout): update CalloutProcessor to support dynamic titles and content parsing feat(card): add CardProcessor for card layout with header, sub-header, and variant support test(card): implement tests for CardProcessor to validate various card formats feat(code-block): enhance CodeBlockProcessor to escape HTML and handle filename metadata test(code-block): add tests for CodeBlockProcessor to ensure proper rendering and escaping feat(details): introduce DetailsProcessor for collapsible sections with markdown support test(details): create tests for DetailsProcessor to validate details block rendering feat(split): implement SplitProcessor for creating split layouts with variant support test(split): add tests for SplitProcessor to ensure correct rendering and variant handling feat(steps): add StepsProcessor for vertical stepper layout with numbered steps test(steps): implement tests for StepsProcessor to validate step rendering and numbering feat(tab): introduce TabProcessor for tabbed content layout with variant support test(tab): add tests for TabProcessor to ensure correct tab rendering and content parsing fix(html:** improve html template function to handle null values correctly ([af7c11013b](https://github.com/RueDeRennes/mosaik/commit/af7c11013b))
- **breadcrumb:** add border style CSS custom property ([69bd49814d](https://github.com/RueDeRennes/mosaik/commit/69bd49814d))
- **toolbar, tab:** add hidden state styling and improve border property handling ([62afed09b6](https://github.com/RueDeRennes/mosaik/commit/62afed09b6))
- **routing:** implement hash and path location strategies with tests ([9d2e3ead3e](https://github.com/RueDeRennes/mosaik/commit/9d2e3ead3e))
- **logging:** add progress logging functionality and refactor animation mixins ([8f860fca28](https://github.com/RueDeRennes/mosaik/commit/8f860fca28))
- **progress-bar): enhance indeterminate state with elastic animation and style adjustments feat(progress-ring): add elastic animations for indeterminate state and improve styling fix(segment): ensure mutual exclusivity of selected items on click feat(tab-strip): implement anticipation effect for tab selection with pointer events style(breadcrumb-item): set border style to none for consistency style(checkbox): update border style to none for cleaner appearance style(choice-group): change border style to none for uniformity style(drop-zone): modify border style to dashed for visual distinction style(file-upload): adjust border style to none for a streamlined look style(radio-group): set border style to none for a cohesive design style(rating): update border style to none for aesthetic consistency fix(scheduler-event:** correct hover background color to match theme ([bc6b86cad4](https://github.com/RueDeRennes/mosaik/commit/bc6b86cad4))
- **api): define DEFAULT_GITHUB_REF for fetching content in GitHubContentService refactor(button): remove link part from button component and update templates docs(button): update documentation to reflect removal of link part in button feat(sandbox): add JSX support and update dependencies for Vite and Angular feat(getStarted): add MCP tools for framework guide and starter template fix(llms): simplify llms plugin file handling and remove unnecessary copying style(button:** clean up button themes by removing link styles ([8ac25a2f7a](https://github.com/RueDeRennes/mosaik/commit/8ac25a2f7a))
- **split-element:** add double-click functionality to expand collapsed panel ([78ff6ee475](https://github.com/RueDeRennes/mosaik/commit/78ff6ee475))
- **message-box:** enhance styling and properties for improved customization and themes ([4e097cadfd](https://github.com/RueDeRennes/mosaik/commit/4e097cadfd))
- **interaction:** enhance prompt choices with shortcuts and progress tracking ([56f96113da](https://github.com/RueDeRennes/mosaik/commit/56f96113da))
- **menu:** update styles and tokens for header padding and typography adjustments ([ecdc68a0e2](https://github.com/RueDeRennes/mosaik/commit/ecdc68a0e2))
- **buttons:** update button padding and shadow properties for improved styling ([20e12a6580](https://github.com/RueDeRennes/mosaik/commit/20e12a6580))
- **button:** add PressButton component with events and styles for multiple frameworks ([59dedda1f9](https://github.com/RueDeRennes/mosaik/commit/59dedda1f9))
- **llms:** add download button and generate full file option for llms ([6a65ea4377](https://github.com/RueDeRennes/mosaik/commit/6a65ea4377))
- **diagram): enhance node styling and graph rendering with inheritance levels feat(meta): update graph method to return class hierarchy levels refactor(graph): improve graph rendering logic and add findNodeByLabel method fix(buttons): update button samples to include ripple effect and correct properties chore(cspell:** add new words for spell checking ([d947b4cd9b](https://github.com/RueDeRennes/mosaik/commit/d947b4cd9b))
- **cli:** integrate CliParser for improved argument parsing and build scripts ([23b1773dce](https://github.com/RueDeRennes/mosaik/commit/23b1773dce))
- **buttons): add ripple prop to button components and related updates feat(components): implement ripple behavior in various components fix(theme:** remove duplicate ripple property in theme JSON files ([d31f695f82](https://github.com/RueDeRennes/mosaik/commit/d31f695f82))
- **McpToolRegistrar): add overview and framework guide tools with enhanced descriptions feat(package:** update dependencies across multiple packages to latest versions ([45bc8fb4f6](https://github.com/RueDeRennes/mosaik/commit/45bc8fb4f6))
- **Button, Banner:** add shadow properties and update related styles and tokens ([5d69398b19](https://github.com/RueDeRennes/mosaik/commit/5d69398b19))
- **Elevation:** add Elevation component and related templates, styles, and types ([88b9bcc7e9](https://github.com/RueDeRennes/mosaik/commit/88b9bcc7e9))
- **Expander, ToggleTip:** enhance shadow properties and add CSS custom properties ([aa5c2d557b](https://github.com/RueDeRennes/mosaik/commit/aa5c2d557b))
- **ToggletipComponent, TooltipComponent): add width and height props for better customization docs: add accessibility audit and component layout prompts feat(McpPromptRegistrar): implement dynamic loading of prompt templates from GitHub feat(McpResourceRegistrar): expose Mosaik component documentation as MCP resources feat(McpToolRegistrar): add tools for component search and discovery feat(DocsContentService, GitHubContentService:** implement services for fetching documentation and GitHub content ([0243729c1d](https://github.com/RueDeRennes/mosaik/commit/0243729c1d))
- **components): refactor property grid handling in TitleBar, Toolbar, Tooltip, and UpDownSpinner samples feat(components): implement property groups for TitleBar, Toolbar, and Tooltip samples fix(components): remove unused properties from TileManager and TileManagerTile components feat(observer): add PropertyObserver to track property changes in playground elements style(forms:** adjust tooltip height in form field themes ([31b07f73ee](https://github.com/RueDeRennes/mosaik/commit/31b07f73ee))
- **components:** add property grid overrides and exclusions for various sample elements ([ed0358ff62](https://github.com/RueDeRennes/mosaik/commit/ed0358ff62))
- **translations:** add French translations for theme management and UI components ([569fb63fd0](https://github.com/RueDeRennes/mosaik/commit/569fb63fd0))
- **ai:** add translation feature with request and response models ([3ccfae51a4](https://github.com/RueDeRennes/mosaik/commit/3ccfae51a4))
- **AI): refactor AI module and service to use new SDKs and streaming responses feat(AI): implement chat request handling and streaming responses in AppChatView feat(api): add MCPApiClient for handling MCP server interactions refactor(api:** replace IChatResponse with IChatRequest for chat API ([a738f435bf](https://github.com/RueDeRennes/mosaik/commit/a738f435bf))
- **icon-gallery): add load more functionality and improve icon selection logic feat(dropdown-button): update styles for better appearance in various themes fix(chat-message:** enhance shadow properties and adjust transition settings chore: export FilePickerSampleElement in main.ts ([3bab87427d](https://github.com/RueDeRennes/mosaik/commit/3bab87427d))
- **progress-ring:** update styles and properties for improved responsiveness and consistency ([519ffa9760](https://github.com/RueDeRennes/mosaik/commit/519ffa9760))
- **listing:** enhance listing and item components with size property for better customization ([76e518298e](https://github.com/RueDeRennes/mosaik/commit/76e518298e))
- **theme:** add shadow properties to various components and update shadow mixins ([6796f7e5a4](https://github.com/RueDeRennes/mosaik/commit/6796f7e5a4))
- **listing:** add size property to listing and listing item components for better customization ([2937e40c8c](https://github.com/RueDeRennes/mosaik/commit/2937e40c8c))
- **grid:** add invalidatePosition method and update grid item styles for better layout handling ([a77d83593c](https://github.com/RueDeRennes/mosaik/commit/a77d83593c))
- **timeline:** enhance timeline marker element with icon and text properties ([9f0478566e](https://github.com/RueDeRennes/mosaik/commit/9f0478566e))
- **pip:** add Memphis theme styles and components for Pip element ([21c480d37c](https://github.com/RueDeRennes/mosaik/commit/21c480d37c))
- **memphis, joy:** add new token files for listing, listing item, and markers ([b3bff07210](https://github.com/RueDeRennes/mosaik/commit/b3bff07210))
- **mcp:** add missing 'mosaik' server configuration in mcp.json and reorder imports in McpService.ts ([d1dbe3d7a8](https://github.com/RueDeRennes/mosaik/commit/d1dbe3d7a8))
- **mcp:** implement MCP module with controller and service for JSON-RPC handling ([f29a6c97ab](https://github.com/RueDeRennes/mosaik/commit/f29a6c97ab))
- **dependencies:** add vercel package and update yarn.lock ([23bbeb5285](https://github.com/RueDeRennes/mosaik/commit/23bbeb5285))
- **menu): update hover close delay for MenuItemElement to improve user experience feat(translations): add GitHub source view label to translations feat(sample): include source metadata in sample description feat(icons:** add GitHub icon to Icons resource ([66770004d9](https://github.com/RueDeRennes/mosaik/commit/66770004d9))
- **mcp:** implement MCP server with component documentation and tools ([724d288192](https://github.com/RueDeRennes/mosaik/commit/724d288192))
- **table): add inheritance context for appearance in TableElement feat(wizard): implement inheritance for disabled state in WizardElement feat(carousel): introduce CarouselDisplayMode and CarouselNavigationPosition types feat(image): add thumbnailSrc prop to ImageComponent for better image handling feat(carousel): enhance CarouselComponent with navigationPosition and displayMode props feat(wizard): extend WizardStepComponent with disabled prop for better control fix(css): ensure proper handling of CSS length values in CssLength utility style(theme:** update carousel and image tokens for better theming consistency ([2ac8e1358d](https://github.com/RueDeRennes/mosaik/commit/2ac8e1358d))
- **scramble-code:** add ScrambleCodeComponent with animation and styling ([101f5552c4](https://github.com/RueDeRennes/mosaik/commit/101f5552c4))
- **ShadowOffsetCanvas): add ShadowOffsetCanvasElement with properties and events for offset control feat(ShadowOffsetCanvas): create interfaces for ShadowOffsetCanvas properties and event details style(ShadowOffsetCanvas): implement styles for ShadowOffsetCanvasElement fix(Banner): update BannerElementTemplate to manage actions visibility correctly fix(SegmentItem:** adjust gap property to use layout space variable in Joy theme ([4b89a04440](https://github.com/RueDeRennes/mosaik/commit/4b89a04440))
- **theme): update Angular export strategy to use JoyTheme and improve theme import view feat(theme): enhance AppThemeViewTemplate with improved layout and preset selection feat(message): add custom message template with action button in MessageSample fix(theme:** correct transition properties for Banner and Message components in Joy theme ([72ee51ce58](https://github.com/RueDeRennes/mosaik/commit/72ee51ce58))
- **theme:** update theme configuration and add theme mode initialization ([ad71335818](https://github.com/RueDeRennes/mosaik/commit/ad71335818))
- **split:** enhance ISplitElementProps and SplitElement documentation for clarity ([37dcc85adb](https://github.com/RueDeRennes/mosaik/commit/37dcc85adb))
- **split:** enhance split layout with nested templates and improved styling ([c756516a3b](https://github.com/RueDeRennes/mosaik/commit/c756516a3b))
- **split:** enhance split layout with nested templates and improved styling ([d2dd276b55](https://github.com/RueDeRennes/mosaik/commit/d2dd276b55))
- **sheet:** add SheetHeaderTextComponent and related theme tokens for cosmopolitan and joy ([9b4195fc17](https://github.com/RueDeRennes/mosaik/commit/9b4195fc17))
- **scroll:** enhance scroll component styles and transition properties across themes ([2e60528016](https://github.com/RueDeRennes/mosaik/commit/2e60528016))
- **scroll): enhance scroll component styles and functionality with new anchors and triggers feat(tooltip): add padding to tooltip component for better spacing refactor(intersection): improve intersection anchor controller to support four directions refactor(index): reorganize exports for better clarity and consistency fix(svelte): remove unused props in ScrollComponent for cleaner code fix(vue:** update props in ScrollComponent to align with latest changes ([13f2009b8b](https://github.com/RueDeRennes/mosaik/commit/13f2009b8b))
- **nx:** add skills for generating code, managing plugins, running tasks, and workspace exploration ([c394133f7c](https://github.com/RueDeRennes/mosaik/commit/c394133f7c))
- **theme:** add progress ring width to button components across themes ([939864b584](https://github.com/RueDeRennes/mosaik/commit/939864b584))
- **chip-group): remove orientation property and add wrap functionality to ChipGroupElement refactor(file-picker): remove filePicked input from FilePickerComponent refactor(chip-group): update ChipGroupComponent to use wrap instead of orientation style(chat-input): add cursor pointer on attachment hover fix(paginator): clean up unused methods in PaginatorComponent feat(opportunity-assessment:** add opportunity assessment issue template ([8e05a1233f](https://github.com/RueDeRennes/mosaik/commit/8e05a1233f))
- **paginator:** enhance paginator functionality with new properties and events ([041eb69653](https://github.com/RueDeRennes/mosaik/commit/041eb69653))
- **dot:** add DotGroup component for grouping dot elements with shared properties ([432790b5ef](https://github.com/RueDeRennes/mosaik/commit/432790b5ef))
- **dot): add fill property to Dot component and update styles for fill states feat(scheduler): rename layout to view in SchedulerEventComponent and related files feat(dot): update Dot component to support fill states and adjust themes accordingly refactor(scheduler): remove unused viewLayout prop from SchedulerComponent fix(svelte:** bind fill property in DotComponent and SchedulerEventComponent ([6e47c3675f](https://github.com/RueDeRennes/mosaik/commit/6e47c3675f))
- **DateExtensions): improve week number calculation and add new date utilities test(NumberExtensions): add unit tests for clamp function refactor(DateFormatter): remove unused specifiers and enhance formatting logic refactor(TimeFormatter:** simplify time formatting and add AM/PM designator handling ([792149b505](https://github.com/RueDeRennes/mosaik/commit/792149b505))
- **scheduler:** add new views and update scheduler component props ([4544fe12b2](https://github.com/RueDeRennes/mosaik/commit/4544fe12b2))
- **popup): enhance popup functionality with focus trap and backdrop support feat(overlay): add aria-modal attribute handling for overlays fix(storage): improve storage set method to handle string values correctly refactor(popup): streamline popup properties and remove deprecated ones style(popup:** update popup template for new properties and structure ([6de2f0ddd9](https://github.com/RueDeRennes/mosaik/commit/6de2f0ddd9))
- **theme:** add tertiary and highlight variants to Memphis and Cosmopolitan themes ([c99ce4a0cc](https://github.com/RueDeRennes/mosaik/commit/c99ce4a0cc))
- **tooltip:** enhance tooltip and floating element animations and visibility handling ([e50ab8ed4f](https://github.com/RueDeRennes/mosaik/commit/e50ab8ed4f))
- **tooltip:** add floating visibility control and animations to TooltipElement ([ac5c05d791](https://github.com/RueDeRennes/mosaik/commit/ac5c05d791))
- **tooltip:** enhance TooltipElement with anchor management and event handling ([76d561e6f4](https://github.com/RueDeRennes/mosaik/commit/76d561e6f4))
- **summary:** add SummarySampleElement with templates and playground defaults ([599c7e2c6f](https://github.com/RueDeRennes/mosaik/commit/599c7e2c6f))
- **scheduler:** update scheduler event component and styles for improved theming and accessibility ([c71bc0845f](https://github.com/RueDeRennes/mosaik/commit/c71bc0845f))
- **scheduler): add models for all-day, collected, and positioned events feat(date-extensions): enhance date utility functions for better scheduling support fix(flowboard): set tabIndex for accessibility on FlowBoardColumnItemElement style(scheduler:** update SCSS tokens for improved styling across themes ([5f31abd169](https://github.com/RueDeRennes/mosaik/commit/5f31abd169))
- **scheduler:** enhance all-day event handling and improve styling across themes ([648e2a7f0c](https://github.com/RueDeRennes/mosaik/commit/648e2a7f0c))
- **scheduler:** enhance event handling and styling across themes ([558addabe0](https://github.com/RueDeRennes/mosaik/commit/558addabe0))
- **tour): add TourComponent and TourStepComponent for guided tours feat(vue): implement TourAnchorComponent and TourStepComponent for Vue feat(scheduler): extend SchedulerComponent props for blackout and highlight features style(tour): add SCSS tokens for Tour, TourAnchor, and TourStep components chore(theming:** create theme tokens for cosmopolitan, joy, and memphis themes ([1d0c417f76](https://github.com/RueDeRennes/mosaik/commit/1d0c417f76))
- **scheduler:** rebuild grid layout and add blackout/highlight behavior ([98b7763dbb](https://github.com/RueDeRennes/mosaik/commit/98b7763dbb))
- **scheduler:** add today button and improve event handling in scheduler ([a3c97e7fc6](https://github.com/RueDeRennes/mosaik/commit/a3c97e7fc6))
- **components:** add 'new' property to components and update templates for display ([2464b44e1d](https://github.com/RueDeRennes/mosaik/commit/2464b44e1d))
- **themes:** add new scheduler components and tokens for Memphis and Joy themes ([3b0cdad390](https://github.com/RueDeRennes/mosaik/commit/3b0cdad390))
- **color-editor:** add paletteCustomChanged event and update related components ([64ffd9d69d](https://github.com/RueDeRennes/mosaik/commit/64ffd9d69d))
- **chip:** adjust max-width and margin for checkmark container styles ([1832a68440](https://github.com/RueDeRennes/mosaik/commit/1832a68440))
- **drag-drop): implement drag and drop directives with auto-discovery and cleanup feat(placeholder): add PlaceholderComponent for React, Svelte, and Vue fix(dragPlaceholder): store data as property instead of attribute fix(dragPreview): store data as property instead of attribute fix(dragHandle): simplify directive updates and attributes refactor(dropList:** enhance drop list directive with group registration and auto-discovery ([616f4c95f3](https://github.com/RueDeRennes/mosaik/commit/616f4c95f3))
- **placeholder:** implement PlaceholderElement with customizable styles and themes ([433a4d761a](https://github.com/RueDeRennes/mosaik/commit/433a4d761a))
- **dragdrop): add drag and drop functionality with new events and utilities fix(imports): update import paths for date extensions in formatters chore(tests): setup vitest with jsdom and polyfills for DOM APIs feat(flowboard): add drag start event to FlowBoard components in React, Svelte, and Vue refactor(events): remove unused addListener function from event utils chore(deps:** update dependencies and lockfile for compatibility and security ([d615c2d3cd](https://github.com/RueDeRennes/mosaik/commit/d615c2d3cd))
- **flowboard:** enable reorderable columns and items for drag-and-drop functionality ([653606b69f](https://github.com/RueDeRennes/mosaik/commit/653606b69f))
- **flowboard:** implement new FlowBoard components and update event handling ([eab85cfbb2](https://github.com/RueDeRennes/mosaik/commit/eab85cfbb2))
- **themes:** add flow board and column components for cosmopolitan, joy, and memphis themes ([811fe6f1c0](https://github.com/RueDeRennes/mosaik/commit/811fe6f1c0))
- **color-editor): add ColorEditor, ColorEditorInputs, and ColorEditorPalette components feat(color-editor): implement ColorEditorInputsComponent and ColorEditorPaletteComponent for Angular feat(react): create ColorEditor, ColorEditorInputs, and ColorEditorPalette components for React feat(vue:** add ColorEditor, ColorEditorInputs, and ColorEditorPalette components for Vue ([b8ccdfd0e2](https://github.com/RueDeRennes/mosaik/commit/b8ccdfd0e2))
- **fontEditor:** add fontEditor JSON configurations for Joy and Memphis themes ([8590f31a9c](https://github.com/RueDeRennes/mosaik/commit/8590f31a9c))
- **memphis:** add color editor components with palette, shade slider, and swatch ([356ac68f42](https://github.com/RueDeRennes/mosaik/commit/356ac68f42))
- **swipe:** add leftPanned and rightPanned events to Swipe component ([f364cb41d5](https://github.com/RueDeRennes/mosaik/commit/f364cb41d5))
- **AudioElement:** add properties for autoPlay, showControls, legend, legendPosition, ratio, muted, and loop ([ed2417b186](https://github.com/RueDeRennes/mosaik/commit/ed2417b186))
- **datebox, passwordbox:** add 'cleared' event and update documentation ([cce79081ad](https://github.com/RueDeRennes/mosaik/commit/cce79081ad))
- **DateTimeBox:** add 'cleared' event and update dropdown dimensions properties ([e226a53f85](https://github.com/RueDeRennes/mosaik/commit/e226a53f85))
- **DropDownButtonSample): add dynamic sizing properties for dropdown dimensions feat(FloatingElement): enhance dimension handling and add watchers for width/height feat(AppBarTemplate:** update dropdown dimensions for better responsiveness ([be614eba7e](https://github.com/RueDeRennes/mosaik/commit/be614eba7e))
- **autocomplete, colorbox, datebox, datetimebox, select, timebox, floating, combo:** update dropdown properties for better customization ([9ef5b4dd1c](https://github.com/RueDeRennes/mosaik/commit/9ef5b4dd1c))
- **url-state:** implement URL state service for state persistence and navigation handling ([3d15972947](https://github.com/RueDeRennes/mosaik/commit/3d15972947))
- **Select): update border color and radius variables for themes feat(Expandable): refactor ExpandableElement to use new Expandable behavior feat(Message): add MessageContent component and related events feat(Message): enhance MessageComponent with expandable properties and events feat(TextFormatter): improve Markdown parsing for links and formatting fix(Index:** reorder exports for consistency ([a88c2d8a2e](https://github.com/RueDeRennes/mosaik/commit/a88c2d8a2e))
- **code-editor:** implement scroll synchronization and enhance styling variables ([57cfd04c00](https://github.com/RueDeRennes/mosaik/commit/57cfd04c00))
- **code-editor:** add copy functionality and enhance editor features across components ([004974cf05](https://github.com/RueDeRennes/mosaik/commit/004974cf05))
- **TextFormatter:** enhance text formatting with WhatsApp-style syntax and improve Markdown support ([3939dbe6c7](https://github.com/RueDeRennes/mosaik/commit/3939dbe6c7))
- **order-edit-drawer:** refactor form handling to use Signal Forms and improve validation ([d72d23f3f6](https://github.com/RueDeRennes/mosaik/commit/d72d23f3f6))
- **message:** update message styles for improved appearance and responsiveness ([ce524703c2](https://github.com/RueDeRennes/mosaik/commit/ce524703c2))
- **message:** refactor message component and update theme tokens for improved styling ([b5e23ce50a](https://github.com/RueDeRennes/mosaik/commit/b5e23ce50a))
- **theme:** enhance theme generation with font source and update personas ([09d041690c](https://github.com/RueDeRennes/mosaik/commit/09d041690c))
- **chipbox:** enhance styles and tokens for Cosmopolitan, Joy, and Memphis themes ([d1f69a7605](https://github.com/RueDeRennes/mosaik/commit/d1f69a7605))
- **components:** implement inheritance controllers for Selectors and Tree components ([1907f30979](https://github.com/RueDeRennes/mosaik/commit/1907f30979))
- **colorbox): add colorPosition property to control preview position relative to input feat(expander): add actions part to ExpanderElement for enhanced functionality feat(theme): implement raw elevation shadow management methods in AppThemeView style(theme:** update AppThemeView styles for shadow group ([0d7f887487](https://github.com/RueDeRennes/mosaik/commit/0d7f887487))
- **translations): add font picker translations for de, en, es, and fr languages feat(shadow): implement ShadowCssConverter for parsing and formatting CSS shadows fix(theme): update ThemePresetService to include additional theme properties refactor(theme): enhance AppThemeView and AppThemeSaveView for better theme management feat(elevation:** add elevation handling in AppThemeView and ThemeService ([5d8d639087](https://github.com/RueDeRennes/mosaik/commit/5d8d639087))
- **expander:** add actions part to ExpanderElement and update styles for caret positioning ([f793577d06](https://github.com/RueDeRennes/mosaik/commit/f793577d06))
- **expander:** add stacking prop to ExpanderGroupComponent for Svelte and Vue ([f9a1ed154f](https://github.com/RueDeRennes/mosaik/commit/f9a1ed154f))
- **theme:** add theme export functionality and improve UI translations ([053124921d](https://github.com/RueDeRennes/mosaik/commit/053124921d))
- **Cdk/Utils:** add deepMerge function for merging nested objects ([958d8b1db2](https://github.com/RueDeRennes/mosaik/commit/958d8b1db2))
- **theming): update Theme2Component to include 'name' and 'global' props refactor(theming): reorganize ITheme utility functions for better clarity feat(theming): add THEME_MODES and THEME_MODES_WITH_SYSTEM constants fix(theming:** export ThemeMode and THEME_MODES from index ([5b0d68ef4a](https://github.com/RueDeRennes/mosaik/commit/5b0d68ef4a))
- **progress-ring:** update stroke-dasharray calculations for improved animation effects ([3d26d9e4d2](https://github.com/RueDeRennes/mosaik/commit/3d26d9e4d2))
- **meter:** enhance MeterRing and MeterBar components with new styles and properties ([026b313a58](https://github.com/RueDeRennes/mosaik/commit/026b313a58))
- **badge:** enhance styling and theming for Memphis and Joy badges ([98af94984e](https://github.com/RueDeRennes/mosaik/commit/98af94984e))
- update templates and enhance functionality across various components ([98e0c54635](https://github.com/RueDeRennes/mosaik/commit/98e0c54635))
- **SelectSample, ComboSample, SelectItemElement:** add new templates and enhance existing functionality ([d90b9f9de9](https://github.com/RueDeRennes/mosaik/commit/d90b9f9de9))
- **translations): add empty state message for icon gallery feat(app): update portal attached event handling in AppTemplate feat(icon-gallery): enhance IconGalleryViewPresenter with portal attachment logic feat(icon-gallery): update IconGalleryViewTemplate to handle portal attachment feat(executors): add ng-api-extractor executor for Angular API extraction feat(executors): implement ng-api-extractor task logic fix(typography): inject DOCUMENT for theme handling in TypographyDirective fix(translations): inject DOCUMENT for language setting in provideTranslations fix(portal:** reset projection after portal attachment in PortalElement ([7b75b3a8b0](https://github.com/RueDeRennes/mosaik/commit/7b75b3a8b0))
- **theme:** update transition properties and add new component tokens for Joy and Memphis themes ([904888d0f5](https://github.com/RueDeRennes/mosaik/commit/904888d0f5))
- **llms:** add llms.txt view and enhance code editor with line wrapping support ([1ab551c0a6](https://github.com/RueDeRennes/mosaik/commit/1ab551c0a6))
- **llms:** add new components and llms plugin for documentation generation ([3c4d1ad7a1](https://github.com/RueDeRennes/mosaik/commit/3c4d1ad7a1))
- **AppElementTemplate:** add clickOutsideToClose property for mobile drawer ([d7c2040da1](https://github.com/RueDeRennes/mosaik/commit/d7c2040da1))
- **elements:** update descriptions for media and overlay components; adjust styles for drawer content ([daebf92a43](https://github.com/RueDeRennes/mosaik/commit/daebf92a43))
- **table:** add detailed documentation for columns and caption properties ([01dd61a084](https://github.com/RueDeRennes/mosaik/commit/01dd61a084))
- **order-management): add order management component with list and table views feat(drawer): implement full-screen mode for drawer component fix(drawer): update drawer styles for full-screen support in themes refactor(toast): adjust toast component to handle enter animations correctly chore(package:** update postbuild:dev script to include wca analysis ([0992db6a46](https://github.com/RueDeRennes/mosaik/commit/0992db6a46))
- **dialog): implement responsive dialog and drawer behaviors with breakpoints feat(drawer): add divider height property and update styles for header style(dialog): enforce centering with !important in CSS for dialog themes style(drawer:** enhance drawer themes with divider styles and improve layout ([f5bd0057c6](https://github.com/RueDeRennes/mosaik/commit/f5bd0057c6))
- **drawer:** update DrawerElement styles for consistent line thickness across positions ([2e8ac33b49](https://github.com/RueDeRennes/mosaik/commit/2e8ac33b49))
- **drawer:** enhance DrawerElement with new slot definitions and update properties ([df154611aa](https://github.com/RueDeRennes/mosaik/commit/df154611aa))
- **auth:** add toast overlay button and functionality ([2ba7af0f31](https://github.com/RueDeRennes/mosaik/commit/2ba7af0f31))
- **resize-thumb:** add ResizeDirection enum and update styles for ResizeThumb component ([a114f04b1b](https://github.com/RueDeRennes/mosaik/commit/a114f04b1b))
- **resize-thumb:** add ResizeThumb component with themes and sample templates ([f02814acad](https://github.com/RueDeRennes/mosaik/commit/f02814acad))
- **resize-thumb:** add isResizing property and update related components ([e36a8dfacc](https://github.com/RueDeRennes/mosaik/commit/e36a8dfacc))
- **drawer:** add DrawerActions component and related styles ([0694277f87](https://github.com/RueDeRennes/mosaik/commit/0694277f87))
- **drawer:** implement drawer stacking behavior and update styles for themes ([036f98144e](https://github.com/RueDeRennes/mosaik/commit/036f98144e))
- **dialog:** refactor dialog components and update routing for overlays ([036f4626d8](https://github.com/RueDeRennes/mosaik/commit/036f4626d8))
- **overlays): replace BottomSheet with Sheet component in React, Svelte, and Vue refactor(overlays): create Sheet context and hooks for managing sheet functionality delete(overlays): remove BottomSheet implementation from Svelte and Vue style(themes:** add new tokens and styles for Sheet component in various themes ([9b31d53a48](https://github.com/RueDeRennes/mosaik/commit/9b31d53a48))
- **drawer:** update drawer position and add new drawer options for better usability ([014f64793b](https://github.com/RueDeRennes/mosaik/commit/014f64793b))
- **drawer:** add DrawerFooterElement with styles and templates for themes ([112cf9ecc4](https://github.com/RueDeRennes/mosaik/commit/112cf9ecc4))
- **navigation:** update routes and translations for Icons and remove Grid Generator ([65fbd99200](https://github.com/RueDeRennes/mosaik/commit/65fbd99200))
- **theme:** add background color tokens for Cosmopolitan, Joy, and Memphis themes ([7221acee86](https://github.com/RueDeRennes/mosaik/commit/7221acee86))
- **dialogs:** enhance AppThemeView and ColorBoxElement with improved color handling ([96d3d671a6](https://github.com/RueDeRennes/mosaik/commit/96d3d671a6))
- **menu:** add menuMode property and handle pointer leave for submenu interactions ([ac89155f01](https://github.com/RueDeRennes/mosaik/commit/ac89155f01))
- **dialogs:** update subHeader text for theme dialogs and improve drawer usage ([0283e96f0f](https://github.com/RueDeRennes/mosaik/commit/0283e96f0f))
- **projection:** enhance DrawerService and MenuItemElement with portal and projection capabilities ([9181efdc8f](https://github.com/RueDeRennes/mosaik/commit/9181efdc8f))
- **menu:** add hierarchical submenus and context menu templates with new submenu modes ([72df10b4a9](https://github.com/RueDeRennes/mosaik/commit/72df10b4a9))
- **overlays:** add escape key handling and backdrop click functionality to overlays ([abd104d27e](https://github.com/RueDeRennes/mosaik/commit/abd104d27e))
- **app): replace DialogService with DrawerService for AppSettingsView and update styles feat(app): enhance AppBar and AppThemeView with enableStack property style(drawer): add width and height to transition properties for Joy and Memphis themes style(backdrop:** add blur property to backdrop styles for Cosmopolitan, Joy, and Memphis themes ([2da9c43e8d](https://github.com/RueDeRennes/mosaik/commit/2da9c43e8d))
- **cdk:** implement toast, dialog, drawer, bottom sheet, and message box components for Svelte and Vue ([85e924ee20](https://github.com/RueDeRennes/mosaik/commit/85e924ee20))
- **drawer:** enhance drawer header and content structure with new components ([9d587b01c3](https://github.com/RueDeRennes/mosaik/commit/9d587b01c3))
- **drawer): add DrawerHeader, DrawerHeaderText, and DrawerHeaderSubText components feat(vue): implement DrawerHeader, DrawerHeaderText, and DrawerHeaderSubText for Vue feat(theme): create tokens for DrawerHeader, DrawerHeaderText, and DrawerHeaderSubText in Cosmopolitan, Joy, and Memphis themes fix(autoComplete): update props and methods in AutoCompleteBoxComponent fix(drawer:** enhance DrawerComponent methods and props for better functionality ([a013fd74f5](https://github.com/RueDeRennes/mosaik/commit/a013fd74f5))
- **autocomplete:** enhance AutoCompleteBox with filter input and search placeholder ([3807f82a0d](https://github.com/RueDeRennes/mosaik/commit/3807f82a0d))
- **repeat-button:** refactor event handling to use pointer events for improved responsiveness ([675ba53871](https://github.com/RueDeRennes/mosaik/commit/675ba53871))
- **autocomplete:** add itemSelected event and enhance AutoCompleteBox functionality ([63334f2c73](https://github.com/RueDeRennes/mosaik/commit/63334f2c73))
- **autocomplete:** enhance AutoCompleteBox styles and behaviors with focus ring support ([c897e3f834](https://github.com/RueDeRennes/mosaik/commit/c897e3f834))
- **memphis:** update color tokens for improved theme consistency and accessibility ([5ee21045d0](https://github.com/RueDeRennes/mosaik/commit/5ee21045d0))
- **theme): add AppThemeView component for theme customization feat(style): create AppThemeView styles and template refactor(commands): remove Command interface and implementation fix(expander): adjust styles for first and last expander items fix(drawer): ensure toolbar flex behavior in drawer component fix(color-picker:** update color swatch border-radius to use variable ([7d0dff4b67](https://github.com/RueDeRennes/mosaik/commit/7d0dff4b67))
- **theme:** add surface and selection variants to Cosmopolitan and Memphis themes ([6005459409](https://github.com/RueDeRennes/mosaik/commit/6005459409))
- **theme:** update background color variables to use surface color for Joy theme components ([98edfeb298](https://github.com/RueDeRennes/mosaik/commit/98edfeb298))
- **region:** enhance Region and RegionElement to support default active view rendering ([626095efee](https://github.com/RueDeRennes/mosaik/commit/626095efee))
- **region:** add Region and RegionView components with themes and properties ([16118756b2](https://github.com/RueDeRennes/mosaik/commit/16118756b2))
- **region:** add ViewElement and RegionElement components with demo and themes ([2c4b84c418](https://github.com/RueDeRennes/mosaik/commit/2c4b84c418))
- **selectors): enhance property groups for List, Menu, Tab, and Tree components feat(selectors): add nested structure to Menu and Wizard templates fix(selectors:** improve styling and layout for DataTable themes docs: add article on Controller Pattern in Angular for better component logic management ([aac9fe4d9e](https://github.com/RueDeRennes/mosaik/commit/aac9fe4d9e))
- **icons): update upload icon and add reset icon feat(translations): add reset related translations in de, en, es, fr feat(sampleBase): implement property reset functionality in SampleBaseElement fix(formField): replace TooltipElement with ToggleTipElement and update styles style(formField:** refactor styles for better layout and consistency ([25accc30bf](https://github.com/RueDeRennes/mosaik/commit/25accc30bf))
- **components): refactor TitleBar, Toolbar, Tooltip, and UpDownSpinner samples to use templates style(timeline): enhance horizontal timeline item styles for better layout and alignment fix(main): update exports for IndicatorSample and TreeMap components chore(cspell:** add xaxis and yaxis to spell check words ([442d952d1a](https://github.com/RueDeRennes/mosaik/commit/442d952d1a))
- **timeline:** add custom templates for timeline component with styled content and markers ([eeb6506523](https://github.com/RueDeRennes/mosaik/commit/eeb6506523))
- **timeline:** add timeline components for React, Svelte, and Vue with styles ([1c0375d250](https://github.com/RueDeRennes/mosaik/commit/1c0375d250))
- update component properties and descriptions for better clarity and functionality ([5d4069bff7](https://github.com/RueDeRennes/mosaik/commit/5d4069bff7))
- **stepper:** add icon property and update styles for stepper components ([8a6aafbba8](https://github.com/RueDeRennes/mosaik/commit/8a6aafbba8))
- **split): add min and max properties for size constraints in SplitElement feat(stepper): introduce isActive property in StepperItemElement refactor(split): update SplitElement to use CssLength for position, min, and max fix(split): adjust CSS properties and templates to reflect new min/max constraints style(split:** remove deprecated CSS variables for min and max in themes ([0478bec83f](https://github.com/RueDeRennes/mosaik/commit/0478bec83f))
- **stepper): add Cosmopolitan, Joy, and Memphis themes for Stepper and StepperItem components feat(stepper): implement React and Svelte components for Stepper and StepperItem feat(stepper): create Vue components for Stepper and StepperItem fix(wizard): update event detail interfaces for active step changes style(stepper:** define token styles for various themes in SCSS ([f3922024d6](https://github.com/RueDeRennes/mosaik/commit/f3922024d6))
- add stepper tokens for all themes ([7871bba3fd](https://github.com/RueDeRennes/mosaik/commit/7871bba3fd))
- **tailwind:** implement Tailwind v4 config generation and update package scripts ([db31430aaf](https://github.com/RueDeRennes/mosaik/commit/db31430aaf))
- **error, hint:** add textOverflow property to Error and Hint components ([131d8bec1e](https://github.com/RueDeRennes/mosaik/commit/131d8bec1e))
- **event-hub:** add Event Hub pattern implementation for Angular 2025 ([88dc4f7404](https://github.com/RueDeRennes/mosaik/commit/88dc4f7404))
- **directives:** update FormFieldDirective to improve error handling and usage documentation ([7c07bb43fd](https://github.com/RueDeRennes/mosaik/commit/7c07bb43fd))
- **eslint:** enhance ESLint configuration and add .eslintignore file ([4b3deb5566](https://github.com/RueDeRennes/mosaik/commit/4b3deb5566))
- **themes:** refactor theme generator strategies and update build process ([55859a854f](https://github.com/RueDeRennes/mosaik/commit/55859a854f))
- **tailwind): add Material and Memphis presets for Tailwind CSS themes fix(tokens): correct typo in headline2 key in joy and memphis theme JSON files chore(tsconfig:** update TypeScript configuration to include Tailwind files ([0ae3d28053](https://github.com/RueDeRennes/mosaik/commit/0ae3d28053))
- add oklch color transform and update dependencies in style-dictionary plugins ([40063afe0a](https://github.com/RueDeRennes/mosaik/commit/40063afe0a))
- **mvp:** implement View and ViewPresenter architecture with interfaces and controllers ([17d2a3cc6b](https://github.com/RueDeRennes/mosaik/commit/17d2a3cc6b))
- **tailwind:** add Joy Tailwind plugin with configuration options and token exposure ([72bbf954a8](https://github.com/RueDeRennes/mosaik/commit/72bbf954a8))
- **svg:** add SVG to path conversion utility ([f2f74da782](https://github.com/RueDeRennes/mosaik/commit/f2f74da782))
- Enhance Color Palette Builder and Theme Generation ([7b7a885f6a](https://github.com/RueDeRennes/mosaik/commit/7b7a885f6a))
- add FlipToDirective for flipping components and ReactiveFormValidator for form validation ([ba607ccc49](https://github.com/RueDeRennes/mosaik/commit/ba607ccc49))
- **memphis:** theme choices, selects, and combos ([53f092fa83](https://github.com/RueDeRennes/mosaik/commit/53f092fa83))
- **avatar:** enhance chat message avatar styles with theme-specific properties ([4e85d98a64](https://github.com/RueDeRennes/mosaik/commit/4e85d98a64))
- **chat:** enhance avatar styles and properties across themes ([3cf45d0955](https://github.com/RueDeRennes/mosaik/commit/3cf45d0955))
- **chat:** add author property to chat messages and update templates ([6e22d26e1d](https://github.com/RueDeRennes/mosaik/commit/6e22d26e1d))
- **List:** add inset property and update styles for flexible layout ([3dc4e28f0d](https://github.com/RueDeRennes/mosaik/commit/3dc4e28f0d))
- **List:** add orientation property and update styles for flexible layout ([44aa6a89cb](https://github.com/RueDeRennes/mosaik/commit/44aa6a89cb))
- enhance ChatElement with additional slots for improved functionality ([1dfc91b4ea](https://github.com/RueDeRennes/mosaik/commit/1dfc91b4ea))
- add DateAgo and TimeAgo pipes, directives, and services for time-based formatting ([40c3e551ba](https://github.com/RueDeRennes/mosaik/commit/40c3e551ba))
- add options for ListElement and update release version to 0.0.157 ([0a28367587](https://github.com/RueDeRennes/mosaik/commit/0a28367587))
- Update AutoCompleteBox component to include new input properties and methods ([70b4f5462e](https://github.com/RueDeRennes/mosaik/commit/70b4f5462e))
- add AutoCompleteBox component and update related samples and interfaces ([6778955ecf](https://github.com/RueDeRennes/mosaik/commit/6778955ecf))
- add AutoCompleteBox component with internationalization support ([ab0b6ddfaa](https://github.com/RueDeRennes/mosaik/commit/ab0b6ddfaa))
- add wrap property to StackElement for flexible layout handling ([181634aa81](https://github.com/RueDeRennes/mosaik/commit/181634aa81))
- **calendar:** add support for multiple calendar sheets ([445b84be1b](https://github.com/RueDeRennes/mosaik/commit/445b84be1b))
- **calendar:** enhance range selection and styling ([fdb6cb56db](https://github.com/RueDeRennes/mosaik/commit/fdb6cb56db))
- add comprehensive guidelines for code quality checks and testing standards across backend, frontend, and testing instructions ([9d9bcf13f9](https://github.com/RueDeRennes/mosaik/commit/9d9bcf13f9))
- add reorderable and resizable properties to TileListItemElement and update related styles ([84672caf3a](https://github.com/RueDeRennes/mosaik/commit/84672caf3a))
- **dropzone:** enhance DropZone component with new styles and states ([0d6349f9ce](https://github.com/RueDeRennes/mosaik/commit/0d6349f9ce))
- integrate build info into AppElement and update template to display build metadata ([afff580948](https://github.com/RueDeRennes/mosaik/commit/afff580948))
- Add ThemeService for managing theme application and properties ([a3cb9be861](https://github.com/RueDeRennes/mosaik/commit/a3cb9be861))
- Add Audio Component and related functionality ([a66b67efb6](https://github.com/RueDeRennes/mosaik/commit/a66b67efb6))
- Update chat and map components with new styles and properties; add Thumbnail element themes ([a011c6c44f](https://github.com/RueDeRennes/mosaik/commit/a011c6c44f))
- Add new Map and Thumbnail components with Cosmopolitan, Joy, and Retro themes ([5142fee885](https://github.com/RueDeRennes/mosaik/commit/5142fee885))
- add serve scripts for app and API in package.json ([1ad4faa834](https://github.com/RueDeRennes/mosaik/commit/1ad4faa834))
- add ChatMessageReaction component with styles and templates ([1975e07a4a](https://github.com/RueDeRennes/mosaik/commit/1975e07a4a))
- update styles for ChatInputElement and VoiceRecorderChatToolElement to use theme variables for consistency ([9d9bc8adfb](https://github.com/RueDeRennes/mosaik/commit/9d9bc8adfb))
- reorder appearance input in ChatMarker components and ensure consistent usage across implementations ([eb5b88f6aa](https://github.com/RueDeRennes/mosaik/commit/eb5b88f6aa))
- add appearance property to ChatMarker components and update styles for new appearances ([23a86826b3](https://github.com/RueDeRennes/mosaik/commit/23a86826b3))
- update event names for recorder events to camelCase format ([bfd76cfe4b](https://github.com/RueDeRennes/mosaik/commit/bfd76cfe4b))
- add filePicked event to AttachmentChatTool component across multiple frameworks ([1c4744bc41](https://github.com/RueDeRennes/mosaik/commit/1c4744bc41))
- **voice-recorder:** add event handling for recording actions and update component props ([e78be3a04d](https://github.com/RueDeRennes/mosaik/commit/e78be3a04d))
- Add BusyState and VoiceRecorder components with Joy and Retro themes ([eb1887d8e3](https://github.com/RueDeRennes/mosaik/commit/eb1887d8e3))
- **chat-tools:** integrate attachment and reaction chat tools ([89e61d7157](https://github.com/RueDeRennes/mosaik/commit/89e61d7157))
- add FormValidator2 and provideForms for enhanced form validation capabilities ([0202e7092e](https://github.com/RueDeRennes/mosaik/commit/0202e7092e))
- add new state components and their samples ([662149d135](https://github.com/RueDeRennes/mosaik/commit/662149d135))
- add formatter property to Checkbox, Choice, Radio, and ToggleSwitch components for enhanced text formatting ([e43a9d30b4](https://github.com/RueDeRennes/mosaik/commit/e43a9d30b4))
- update ChoiceElement template and styles for additional slot support ([e9d020bdf9](https://github.com/RueDeRennes/mosaik/commit/e9d020bdf9))
- add alignment property to HintElement and update template to support it ([985785e116](https://github.com/RueDeRennes/mosaik/commit/985785e116))
- enhance formatter setter to support string conversion to TextFormatter ([f89f500f68](https://github.com/RueDeRennes/mosaik/commit/f89f500f68))
- Add ToggleButtonGroup and DockPanel components with associated styles and tokens ([a9728a1a4e](https://github.com/RueDeRennes/mosaik/commit/a9728a1a4e))
- Enhance Wizard and ScrubSlider components with new slot definitions and improved documentation ([9b2319130d](https://github.com/RueDeRennes/mosaik/commit/9b2319130d))
- Add ToggleButtonElementValueAccessor and integrate with ToggleButtonComponent ([5e831d7fbd](https://github.com/RueDeRennes/mosaik/commit/5e831d7fbd))
- **wizard:** add isFirstStep and isLastStep properties to Wizard component ([b398a839e2](https://github.com/RueDeRennes/mosaik/commit/b398a839e2))
- **dialog:** implement custom dialog slots and enhance dialog functionality ([dc13b4b8fe](https://github.com/RueDeRennes/mosaik/commit/dc13b4b8fe))
- **error-directives:** add ErrorDirective and ErrorGroupDirective for form validation handling ([9b753e708a](https://github.com/RueDeRennes/mosaik/commit/9b753e708a))
- **themes:** add content offset top property to app themes and adjust styles ([4490a7438b](https://github.com/RueDeRennes/mosaik/commit/4490a7438b))
- **instructions:** add initial blogpost writing guidelines and structure ([03fbd93fd8](https://github.com/RueDeRennes/mosaik/commit/03fbd93fd8))
- **chat:** enhance styling and theming for chat components ([b8f5a8f6c6](https://github.com/RueDeRennes/mosaik/commit/b8f5a8f6c6))
- **dialog): enhance DialogPortalComponent with dynamic properties and update button appearance feat(translator:** improve addTranslations method to merge existing translations chore: update release script version to 0.0.107 ([e6974a901b](https://github.com/RueDeRennes/mosaik/commit/e6974a901b))
- **instructions:** add guideline for using "const object + derived union" pattern chore: update release version to 0.0.106 ([28ffdf76fb](https://github.com/RueDeRennes/mosaik/commit/28ffdf76fb))
- Add ScrubSlider component with multiple themes and styles ([d1db809262](https://github.com/RueDeRennes/mosaik/commit/d1db809262))
- **instructions:** add guidelines for self-closing tags and update constructor injection recommendation ([12118c959d](https://github.com/RueDeRennes/mosaik/commit/12118c959d))
- **chat:** integrate Slottable behavior and update event naming conventions ([9a1fcbf0d6](https://github.com/RueDeRennes/mosaik/commit/9a1fcbf0d6))
- **select:** enhance empty state handling and improve visibility checks ([ab9611d431](https://github.com/RueDeRennes/mosaik/commit/ab9611d431))
- add provider functions for dialogs, drawers, message boxes, and toasts ([6c8d58d206](https://github.com/RueDeRennes/mosaik/commit/6c8d58d206))
- **CellElement:** add auto-generated styles for cosmopolitan cell element ([57bb5833b2](https://github.com/RueDeRennes/mosaik/commit/57bb5833b2))
- enhance executors with additional imports and caching utility integration ([626574efac](https://github.com/RueDeRennes/mosaik/commit/626574efac))
- implement caching utility and update executors to use it ([109456ef58](https://github.com/RueDeRennes/mosaik/commit/109456ef58))
- **select:** add filter functionality with placeholder support ([30207277b0](https://github.com/RueDeRennes/mosaik/commit/30207277b0))
- add border-radius and overflow properties to AppHeaderElement styles for improved layout ([588ed0f41d](https://github.com/RueDeRennes/mosaik/commit/588ed0f41d))
- add executor options types and schema generation script; remove unused dependencies ([eb71956d5a](https://github.com/RueDeRennes/mosaik/commit/eb71956d5a))
- update release version to 0.0.81 in package.json ([6e01a49d06](https://github.com/RueDeRennes/mosaik/commit/6e01a49d06))
- enhance HTML code generation with new abstract methods and self-closing tag support feat: update icon registration to support aliases for icons style: adjust drawer component styles to use line thickness variable chore: add line thickness property to drawer theme tokens in Cosmopolitan, Joy, and Retro themes ([0174ad7acb](https://github.com/RueDeRennes/mosaik/commit/0174ad7acb))
- update release version to 0.0.80 in package.json ([96a94fca93](https://github.com/RueDeRennes/mosaik/commit/96a94fca93))
- Add synchronous caching methods for file and directory checks in FileCache refactor: Update storage conversion methods to simplify data handling chore: Enhance styledictionary configuration with file caching and logging improvements ([0f6a7350f3](https://github.com/RueDeRennes/mosaik/commit/0f6a7350f3))
- Update input components and themes ([e2379e3bd0](https://github.com/RueDeRennes/mosaik/commit/e2379e3bd0))
- **textbox:** add prefix and suffix icon support with customizable sizes ([eb9c019a17](https://github.com/RueDeRennes/mosaik/commit/eb9c019a17))
- update button components with new size tokens ([22d0cdd674](https://github.com/RueDeRennes/mosaik/commit/22d0cdd674))
- Enhance projection handling and styling for dropdown and menu components ([8c663e6e7e](https://github.com/RueDeRennes/mosaik/commit/8c663e6e7e))
- Implement SandboxProjectFactory and SandboxProjectTemplateEngine ([3300298aec](https://github.com/RueDeRennes/mosaik/commit/3300298aec))
- Enhance ProjectionView with new styling and sample code; add translation for projection ([114c4671a4](https://github.com/RueDeRennes/mosaik/commit/114c4671a4))
- Add Projection View component and update related views and styles ([91d1f76e88](https://github.com/RueDeRennes/mosaik/commit/91d1f76e88))
- Enhance Landing and App View Components ([459cb772ed](https://github.com/RueDeRennes/mosaik/commit/459cb772ed))
- Add AppView styles and template ([6d2c19940f](https://github.com/RueDeRennes/mosaik/commit/6d2c19940f))
- Update DismissElement styles for close button with consistent dimensions and border radius ([75e0cc7731](https://github.com/RueDeRennes/mosaik/commit/75e0cc7731))
- Update dismiss element styles for improved positioning and z-index handling ([8565d05277](https://github.com/RueDeRennes/mosaik/commit/8565d05277))
- Enhance DismissElement with Themeable behavior and update IDismissElementProps interface ([74b709ec06](https://github.com/RueDeRennes/mosaik/commit/74b709ec06))
- Add PortalHostComponent to various frameworks and implement Gappable behavior ([2e84d8f5d0](https://github.com/RueDeRennes/mosaik/commit/2e84d8f5d0))
- Update translations to include dynamic placeholders and enhance icon gallery functionality feat: Add InfiniteScrollController for improved scrolling experience refactor: Improve type safety in UrlParam and Persisted decorators ([6e35f3da1d](https://github.com/RueDeRennes/mosaik/commit/6e35f3da1d))
- Update IPersistedConfig and IUrlParamConfig interfaces for improved type safety and consistency ([6cce9680f5](https://github.com/RueDeRennes/mosaik/commit/6cce9680f5))
- Simplify exports in Index.ts by removing unused properties from Persisted and UrlParam decorators ([73f6f09f72](https://github.com/RueDeRennes/mosaik/commit/73f6f09f72))
- Enhance Persisted and UrlParam decorators to support Signal values and improve property management ([fbe8d5f131](https://github.com/RueDeRennes/mosaik/commit/fbe8d5f131))
- Refactor and enhance reactivity system with new Signal and TrackableSignal classes ([09c5e2a4b8](https://github.com/RueDeRennes/mosaik/commit/09c5e2a4b8))
- **translations:** add new localized strings for icon gallery and update existing translations ([64485437d7](https://github.com/RueDeRennes/mosaik/commit/64485437d7))
- update IconGalleryView to include shared styles; enhance logging format in LitStyleTransformTask; modify executor options to include elementsOnly; remove unused Fluent theme from ButtonElement; improve createStyleSheets function to support array of styles ([7f28e6c94d](https://github.com/RueDeRennes/mosaik/commit/7f28e6c94d))
- Integrate Portal and ProjectionController into DateBox, DateTimeBox, and TimeBox components ([b0d925bdbf](https://github.com/RueDeRennes/mosaik/commit/b0d925bdbf))
- add SpacerDirective with options for spacing control and update index export ([8a2727ea31](https://github.com/RueDeRennes/mosaik/commit/8a2727ea31))
- standardize event listener decorators by removing 'self' target option and improving documentation ([f14fe3f4b5](https://github.com/RueDeRennes/mosaik/commit/f14fe3f4b5))
- Update button components to include event fires and improve documentation ([07140d2542](https://github.com/RueDeRennes/mosaik/commit/07140d2542))
- implement App component with templates and update AppHeader for toggling functionality ([992d3d7433](https://github.com/RueDeRennes/mosaik/commit/992d3d7433))
- add App Header component and related samples, templates, and events ([cb140e78e8](https://github.com/RueDeRennes/mosaik/commit/cb140e78e8))
- add expand, collapse, and toggle methods to MenuItem and TreeItem components with descriptions ([8881f5f730](https://github.com/RueDeRennes/mosaik/commit/8881f5f730))
- add IExpandable interface and implement expandable functionality in MenuItemElement, TreeItemElement, and ExpandableElement ([f2fb5df205](https://github.com/RueDeRennes/mosaik/commit/f2fb5df205))
- add copyExecutorsJson script and update build commands ([0a0aba85b9](https://github.com/RueDeRennes/mosaik/commit/0a0aba85b9))
- update Carousel component methods and add select method implementation ([351e68a615](https://github.com/RueDeRennes/mosaik/commit/351e68a615))
- update menu component styles and structure for improved layout and responsiveness ([373095056e](https://github.com/RueDeRennes/mosaik/commit/373095056e))
- add icon functionality with IconDirective and IconRegistry, enhance app layout with new directives ([8acea01349](https://github.com/RueDeRennes/mosaik/commit/8acea01349))
- enhance app layout and styling with new components and responsive design ([8919fccc0c](https://github.com/RueDeRennes/mosaik/commit/8919fccc0c))
- enhance Jumbotron components with slot definitions and improve HideOnScrollController methods ([4cc6d9de3a](https://github.com/RueDeRennes/mosaik/commit/4cc6d9de3a))
- Add formatter property to Jumbotron components and update related files ([9ae59c7ff9](https://github.com/RueDeRennes/mosaik/commit/9ae59c7ff9))
- Add Svelte titles to German and English translations; update formatting keys in various components ([9889da1578](https://github.com/RueDeRennes/mosaik/commit/9889da1578))
- Add Jumbotron component and related styles for multiple frameworks ([41d4601e08](https://github.com/RueDeRennes/mosaik/commit/41d4601e08))
- enhance backdrop styles and refactor breakpoint handling ([39661be30c](https://github.com/RueDeRennes/mosaik/commit/39661be30c))
- Update layout variables for Cosmopolitan and Joy themes in various components ([af9ca676db](https://github.com/RueDeRennes/mosaik/commit/af9ca676db))
- Introduce Indicator component across multiple frameworks ([7ef850c39d](https://github.com/RueDeRennes/mosaik/commit/7ef850c39d))
- Update Indicator component styles and tokens for layout spacing ([201ee59059](https://github.com/RueDeRennes/mosaik/commit/201ee59059))
- Add Indicator component and related functionality ([b55b86b0e2](https://github.com/RueDeRennes/mosaik/commit/b55b86b0e2))
- implement animation directive and provider with presets ([09550b6633](https://github.com/RueDeRennes/mosaik/commit/09550b6633))
- enhance theme merging logic and add support for deep partial overrides ([870d64b42b](https://github.com/RueDeRennes/mosaik/commit/870d64b42b))
- Remove unused 'onInput' method from ColorPicker components and update related code ([d84ece1672](https://github.com/RueDeRennes/mosaik/commit/d84ece1672))
- Add Svelte support with SvelteCodeGenerator and update build scripts ([955cb75cb6](https://github.com/RueDeRennes/mosaik/commit/955cb75cb6))
- Add new Svelte components for menu, segment, tab, table, tree, wizard, and shell ([e6de8f0553](https://github.com/RueDeRennes/mosaik/commit/e6de8f0553))
- add Color Palette Builder tool and associated views ([55a992138e](https://github.com/RueDeRennes/mosaik/commit/55a992138e))
- add comprehensive article on using const vs enums in TypeScript with Angular templates ([8db46644e3](https://github.com/RueDeRennes/mosaik/commit/8db46644e3))
- add hasHeader and hasNav properties to AppElement and update related components ([37baedabae](https://github.com/RueDeRennes/mosaik/commit/37baedabae))
- add localizator-core dependency and update build dependencies in project configuration ([077a2cd1d9](https://github.com/RueDeRennes/mosaik/commit/077a2cd1d9))
- add FlexDirective for flexible layout management in Angular ([3b8f27e2b7](https://github.com/RueDeRennes/mosaik/commit/3b8f27e2b7))
- add comprehensive guide on the power of regions in TypeScript for improved code organization ([564b600288](https://github.com/RueDeRennes/mosaik/commit/564b600288))
- add theme provider for angular ([04568d1528](https://github.com/RueDeRennes/mosaik/commit/04568d1528))
- update masonry and wrap elements to use CSS variables for gap and columns, enhance templates with static styles ([2dee486060](https://github.com/RueDeRennes/mosaik/commit/2dee486060))
- disable eslint rule for static styles in multiple component templates and update SCSS mixin to exclude properties ([d6e61ac195](https://github.com/RueDeRennes/mosaik/commit/d6e61ac195))
- enhance keyboard element with modifier key support and update styles ([07f7af6d52](https://github.com/RueDeRennes/mosaik/commit/07f7af6d52))
- enhance dropdown button templates with new icons and improved layout fix: adjust padding for menu item group headers across themes ([5004c67e11](https://github.com/RueDeRennes/mosaik/commit/5004c67e11))
- add 'Code' and 'TypeScript' keywords to various documentation files for improved discoverability ([7ac3c152dd](https://github.com/RueDeRennes/mosaik/commit/7ac3c152dd))
- add "The Dependency Forest" article on dependency management challenges in Angular ([d129b84490](https://github.com/RueDeRennes/mosaik/commit/d129b84490))
- add translation command and integrate translation functionality in BlogBaseElement ([7e166a6bea](https://github.com/RueDeRennes/mosaik/commit/7e166a6bea))
- enhance blog and translation features with interview type and language flags ([9aff64d29b](https://github.com/RueDeRennes/mosaik/commit/9aff64d29b))
- update interview content and add StickyController metadata in JSON ([c39d970be6](https://github.com/RueDeRennes/mosaik/commit/c39d970be6))
- add YouTube video rendering support in MarkdownRenderer ([723610d3c8](https://github.com/RueDeRennes/mosaik/commit/723610d3c8))
- Add new translation for "Open with" in code section ([e1b84033bc](https://github.com/RueDeRennes/mosaik/commit/e1b84033bc))
- create Playground components for testing Markdown features ([738f61002f](https://github.com/RueDeRennes/mosaik/commit/738f61002f))
- enhance Listen decorator to support custom query targets and improve event handling ([aa19e6e5a0](https://github.com/RueDeRennes/mosaik/commit/aa19e6e5a0))
- add PinchController for gesture recognition and enhance DiagramElement with centering functionality ([c3feb9a789](https://github.com/RueDeRennes/mosaik/commit/c3feb9a789))
- **docs:** Update documentation with new sections, descriptions, and examples for clarity and usability ([c32ff5f976](https://github.com/RueDeRennes/mosaik/commit/c32ff5f976))
- **docs:** Enhance MVP pattern documentation with detailed explanations and examples ([e3c97f1368](https://github.com/RueDeRennes/mosaik/commit/e3c97f1368))
- implement filter functionality in ArticlesView and update related templates ([1e88d302d4](https://github.com/RueDeRennes/mosaik/commit/1e88d302d4))
- Implement sticky positioning directive and controller, enhance scrolling functionality in Scroller class ([148f07916e](https://github.com/RueDeRennes/mosaik/commit/148f07916e))
- Enhance MVP documentation and examples across multiple frameworks ([cfabea14a3](https://github.com/RueDeRennes/mosaik/commit/cfabea14a3))
- add backdrop images and enhance ArticlesView with documentation grouping ([af72ff74cd](https://github.com/RueDeRennes/mosaik/commit/af72ff74cd))
- add images and enhance Markdown documentation with improved layout and structure ([1eaac2125f](https://github.com/RueDeRennes/mosaik/commit/1eaac2125f))
- enhance Markdown components with improved styling and layout variables ([780d383b31](https://github.com/RueDeRennes/mosaik/commit/780d383b31))
- enhance CodeEditor and Markdown components with improved language and theme support ([0270711752](https://github.com/RueDeRennes/mosaik/commit/0270711752))
- **callouts:** add new callout variants and enhance Markdown processing ([3a5608697b](https://github.com/RueDeRennes/mosaik/commit/3a5608697b))
- Enhance Markdown processing with new features and improvements ([534983c407](https://github.com/RueDeRennes/mosaik/commit/534983c407))
- **translations:** add share message for blog posts ([a3ba45071a](https://github.com/RueDeRennes/mosaik/commit/a3ba45071a))
- enhance Markdown component styles with improved blockquote and list formatting ([dbefc8d12f](https://github.com/RueDeRennes/mosaik/commit/dbefc8d12f))
- refactor text overflow handling and enhance Markdown component styles ([62bb601fc7](https://github.com/RueDeRennes/mosaik/commit/62bb601fc7))
- Update AppSideNavTemplate to use node meta for display names and add value binding ([1488b7d52f](https://github.com/RueDeRennes/mosaik/commit/1488b7d52f))
- update metadata structure in documentation and improve avatar and chip components ([007bd05bea](https://github.com/RueDeRennes/mosaik/commit/007bd05bea))
- enhance Markdown rendering and styling with new link styles and tree directive support ([8fba55993c](https://github.com/RueDeRennes/mosaik/commit/8fba55993c))
- update markdown files to use structured keywords and add author information ([d0df1b883f](https://github.com/RueDeRennes/mosaik/commit/d0df1b883f))
- **docs): enhance keyword metadata across documentation files for improved searchability and context feat(Markdown): update MarkdownElement and MarkdownRenderer for better handling of text and code blocks fix(DocsService): refine getDocsTree method for improved documentation hierarchy and sorting fix(staticContent:** add meta information to static content registration for enhanced metadata handling ([789875e05d](https://github.com/RueDeRennes/mosaik/commit/789875e05d))
- **build:** add vite-plugins build step to deployment script; enhance MarkdownElement and DocsService for better handling of documentation and Markdown sources ([619a32e38b](https://github.com/RueDeRennes/mosaik/commit/619a32e38b))
- **menu:** add textOverflow property to MenuItemComponent and related elements for improved text handling; update DocsService and AppSideNavTemplate for better rendering ([9b7641b6c1](https://github.com/RueDeRennes/mosaik/commit/9b7641b6c1))
- **router:** implement RouterLocation and IRouterLocation for improved routing abstraction; refactor RouterElement to utilize new location handling ([53705c577a](https://github.com/RueDeRennes/mosaik/commit/53705c577a))
- **menu:** enhance menu item styles with indent properties and update theme tokens for better visual hierarchy ([b3dad3c306](https://github.com/RueDeRennes/mosaik/commit/b3dad3c306))
- **router:** enhance routing components with role attributes and update templates for better accessibility; refactor RouterController and RouterLinkDirective for improved functionality ([63b32829f1](https://github.com/RueDeRennes/mosaik/commit/63b32829f1))
- **router:** implement routerLink directive for dynamic link handling; update AppSideNavTemplate to use routerLink ([f2fb309d47](https://github.com/RueDeRennes/mosaik/commit/f2fb309d47))
- **router:** add RouterLinkDirective for dynamic link generation ([ab2e98ed50](https://github.com/RueDeRennes/mosaik/commit/ab2e98ed50))
- enhance package service and controller to support history retrieval with optional limit; update translations and styles for package explorer ([71efae2557](https://github.com/RueDeRennes/mosaik/commit/71efae2557))
- implement ShieldElement with template, style, and props; enhance package metadata and history models ([de73abbc76](https://github.com/RueDeRennes/mosaik/commit/de73abbc76))
- enhance package service and models with metadata and history retrieval ([05c98c197d](https://github.com/RueDeRennes/mosaik/commit/05c98c197d))
- add package manager installation step in CI workflow ([d8453719df](https://github.com/RueDeRennes/mosaik/commit/d8453719df))
- add eslint config build step to the dev deployment workflow ([c831986474](https://github.com/RueDeRennes/mosaik/commit/c831986474))
- add component selector to various sample elements for better integration ([3eb465fed5](https://github.com/RueDeRennes/mosaik/commit/3eb465fed5))
- Update button element CSS properties and enhance template styles ([c83ee77d83](https://github.com/RueDeRennes/mosaik/commit/c83ee77d83))
- Enhance sandbox functionality and UI improvements ([c45d7ca09b](https://github.com/RueDeRennes/mosaik/commit/c45d7ca09b))
- Implement ProjectionController for managing projected content in portals ([1bc46717b5](https://github.com/RueDeRennes/mosaik/commit/1bc46717b5))
- add TableFooter component and related styles ([85d9e96af5](https://github.com/RueDeRennes/mosaik/commit/85d9e96af5))
- Enhance state elements with padding and gap properties ([19074a8b51](https://github.com/RueDeRennes/mosaik/commit/19074a8b51))
- Enhance Select and Combo components with internationalization and improved styling ([8d80d58234](https://github.com/RueDeRennes/mosaik/commit/8d80d58234))
- enhance TagCloudElement with item selection and styling; refactor related components and styles ([2847e96a41](https://github.com/RueDeRennes/mosaik/commit/2847e96a41))
- add ModifierKeyName export and improve attr() function in SCSS ([317b75143d](https://github.com/RueDeRennes/mosaik/commit/317b75143d))
- Refactor CheckBoxGroupSample and TextBoxSample components for improved property formatting ([b0fcc7502e](https://github.com/RueDeRennes/mosaik/commit/b0fcc7502e))
- add default values for boolean attributes across various components ([899d593ba5](https://github.com/RueDeRennes/mosaik/commit/899d593ba5))
- update release script to version 0.0.26 ([11e2fdbc4f](https://github.com/RueDeRennes/mosaik/commit/11e2fdbc4f))
- update release script to version 0.0.25 ([930ba60eb4](https://github.com/RueDeRennes/mosaik/commit/930ba60eb4))
- update version to 0.0.24 and remove prefix/suffix styles from various components ([d061c7f8cd](https://github.com/RueDeRennes/mosaik/commit/d061c7f8cd))
- update appearance of input components and add textAlign property ([5f7321b7a8](https://github.com/RueDeRennes/mosaik/commit/5f7321b7a8))
- Add text alignment support to input components ([0a1069f47d](https://github.com/RueDeRennes/mosaik/commit/0a1069f47d))
- Add Validators class to Cdk for form validation ([5db8b51601](https://github.com/RueDeRennes/mosaik/commit/5db8b51601))
- add spinner and textAlign properties to NumberBox and TextBox components ([cda90dffa4](https://github.com/RueDeRennes/mosaik/commit/cda90dffa4))
- implement flip component with new side property and directives ([2b3c56c9b4](https://github.com/RueDeRennes/mosaik/commit/2b3c56c9b4))
- add select component to auth form and improve validation ([4971bba07f](https://github.com/RueDeRennes/mosaik/commit/4971bba07f))
- add Invalidable behavior and validity check to components ([893bb30b3b](https://github.com/RueDeRennes/mosaik/commit/893bb30b3b))
- add ng forms validation trigger ([e430f70f31](https://github.com/RueDeRennes/mosaik/commit/e430f70f31))
- update project dependencies and build configurations ([569b1bf99d](https://github.com/RueDeRennes/mosaik/commit/569b1bf99d))
- **eslint:** add TypeScript ESLint configuration with comprehensive ruleset ([4d7a0d88b7](https://github.com/RueDeRennes/mosaik/commit/4d7a0d88b7))
- Add Insetable behavior and update BoxElement styles ([ca740ab5f2](https://github.com/RueDeRennes/mosaik/commit/ca740ab5f2))
- export dateTimeBoxElementValueAccessor alongside DateTimeBoxElementValueAccessor for improved accessibility ([fad7497ba7](https://github.com/RueDeRennes/mosaik/commit/fad7497ba7))
- enhance project configurations with inputs and outputs for build targets ([6f80d15bda](https://github.com/RueDeRennes/mosaik/commit/6f80d15bda))
- **PublishPackage:** add version validation and improve error logging ([33ad436126](https://github.com/RueDeRennes/mosaik/commit/33ad436126))
- update package dependencies to use workspace references ([e853ec04e5](https://github.com/RueDeRennes/mosaik/commit/e853ec04e5))
- add changelog configuration to disable author rendering and update release script to specify group ([9ce709c251](https://github.com/RueDeRennes/mosaik/commit/9ce709c251))
- update version generator options to include installArgs and installIgnoreScripts ([747191d4da](https://github.com/RueDeRennes/mosaik/commit/747191d4da))
- streamline release configuration by consolidating project relationships and removing redundant properties ([77fbfcd293](https://github.com/RueDeRennes/mosaik/commit/77fbfcd293))
- add version configuration for conventional commits and generator options ([bd6048596e](https://github.com/RueDeRennes/mosaik/commit/bd6048596e))
- update release configuration to set projectsRelationship to fixed for libs, infra, and tools ([bc0437f95d](https://github.com/RueDeRennes/mosaik/commit/bc0437f95d))
- restructure release configuration to include groups for libs, infra, and tools ([fe9e93b5ce](https://github.com/RueDeRennes/mosaik/commit/fe9e93b5ce))
- update documentation paths and add index file for mosaik-elements-foundation package ([ced717bdea](https://github.com/RueDeRennes/mosaik/commit/ced717bdea))
- update package dependencies to use caret (^) versioning for consistency ([2d8ab96c84](https://github.com/RueDeRennes/mosaik/commit/2d8ab96c84))
- add dependency management for publish targets in project configurations ([e13de9a63b](https://github.com/RueDeRennes/mosaik/commit/e13de9a63b))
- enhance release script to include build and publish targets ([0c29b15d46](https://github.com/RueDeRennes/mosaik/commit/0c29b15d46))
- update package.json dependencies to use specific versions instead of workspace references ([4934f88dc1](https://github.com/RueDeRennes/mosaik/commit/4934f88dc1))
- update project configurations to enable caching and adjust input paths for build targets ([4e8b485497](https://github.com/RueDeRennes/mosaik/commit/4e8b485497))
- add copy-dependencies and publish-package executors; update project.json to use new publish executor ([ba4c5f9393](https://github.com/RueDeRennes/mosaik/commit/ba4c5f9393))
- add changesets for versioning and changelog management ([00db6e0ef1](https://github.com/RueDeRennes/mosaik/commit/00db6e0ef1))
- add semver package for version validation in CopyPublisherPackageJson task ([f848b73d49](https://github.com/RueDeRennes/mosaik/commit/f848b73d49))
- Refactor components to support standalone mode and add method invocation capabilities ([3312924aa2](https://github.com/RueDeRennes/mosaik/commit/3312924aa2))
- **dialog:** implement DialogRef and DialogService for enhanced dialog management ([e1c0b0d850](https://github.com/RueDeRennes/mosaik/commit/e1c0b0d850))
- define custom elements for various components in Mosaik Elements Angular ([cb6a1d5ef2](https://github.com/RueDeRennes/mosaik/commit/cb6a1d5ef2))
- Implement default file cleanup script and enhance component styles ([3aff5d6fd8](https://github.com/RueDeRennes/mosaik/commit/3aff5d6fd8))
- Add Electronic Program Guide components for Angular, React, and Vue ([b62f3f59fc](https://github.com/RueDeRennes/mosaik/commit/b62f3f59fc))
- Add theme change handling and improve dialog dimensions in AppSettingsView; enhance InkBarElement alignment logic ([71da43e4b1](https://github.com/RueDeRennes/mosaik/commit/71da43e4b1))
- Enhance LitStyleTransform with dependency analysis and improve logging; add retro anchor element styles ([730b58ed42](https://github.com/RueDeRennes/mosaik/commit/730b58ed42))
- Enhance PropertyDecorator to support CSS variable binding for style properties ([5273291343](https://github.com/RueDeRennes/mosaik/commit/5273291343))
- add Boundable behavior and utility functions for date handling ([1deae6f00a](https://github.com/RueDeRennes/mosaik/commit/1deae6f00a))
- Add Joy theme styles for Electronic Program Guide components ([7c76dce194](https://github.com/RueDeRennes/mosaik/commit/7c76dce194))
- Enhance Coupon and Highlight components with improved styles and user-select properties ([7de39c4dee](https://github.com/RueDeRennes/mosaik/commit/7de39c4dee))
- Enhance Electronic Program Guide with new properties and styling adjustments ([d2aed27576](https://github.com/RueDeRennes/mosaik/commit/d2aed27576))
- Add Electronic Program Guide components and styles ([4d7c1d2f49](https://github.com/RueDeRennes/mosaik/commit/4d7c1d2f49))
- **expander:** update styles for Cosmopolitan, Default, Joy, and Retro themes to enhance shadow properties and improve consistency ([78f0a88ebe](https://github.com/RueDeRennes/mosaik/commit/78f0a88ebe))
- **tokens:** enhance elevation and typography tokens across themes ([4fca67fd43](https://github.com/RueDeRennes/mosaik/commit/4fca67fd43))
- **theme:** enhance Retro theme with additional variants and update component styles ([6d869ec358](https://github.com/RueDeRennes/mosaik/commit/6d869ec358))
- Update ToggleTip component styles and tokens across themes ([c30920e681](https://github.com/RueDeRennes/mosaik/commit/c30920e681))
- Update theme components and tokens for consistency and improved styling ([ffb9596405](https://github.com/RueDeRennes/mosaik/commit/ffb9596405))
- Enhance Retro theme with new elevation and appearance tokens ([0c9a0084ec](https://github.com/RueDeRennes/mosaik/commit/0c9a0084ec))
- update chart component styles for improved tooltip and legend formatting ([1037a3fa9a](https://github.com/RueDeRennes/mosaik/commit/1037a3fa9a))
- update chart component styles and themes to use Joy typography variables ([8fe7d7f4fe](https://github.com/RueDeRennes/mosaik/commit/8fe7d7f4fe))
- enhance chart and form elements with foreground color support and style adjustments ([dad0dd53df](https://github.com/RueDeRennes/mosaik/commit/dad0dd53df))
- implement theme persistence and configuration storage, update ToastService and RatingElement properties ([2fe40b8ee8](https://github.com/RueDeRennes/mosaik/commit/2fe40b8ee8))
- add installation and setup for package manager in the workflow ([1498f235f9](https://github.com/RueDeRennes/mosaik/commit/1498f235f9))
- add support for package manager setup in the dev workflow ([59aaf6b708](https://github.com/RueDeRennes/mosaik/commit/59aaf6b708))
- update banner appearance to 'soft' across multiple views and adjust button styles for improved consistency ([36804f1758](https://github.com/RueDeRennes/mosaik/commit/36804f1758))
- implement tab panel component with scrollable content and improved selection logic ([a5766822e0](https://github.com/RueDeRennes/mosaik/commit/a5766822e0))
- update App settings view template to enhance layout and add text case directive ([d3b4963491](https://github.com/RueDeRennes/mosaik/commit/d3b4963491))
- Add options for mode and focus delegation in Drawer components ([2439ae5ada](https://github.com/RueDeRennes/mosaik/commit/2439ae5ada))
- Add appearance property to mosaik-toolbar in chat header template ([0dafe85e1f](https://github.com/RueDeRennes/mosaik/commit/0dafe85e1f))
- Add initial QR Code Cosmopolitan theme styles and structure ([ec12f33544](https://github.com/RueDeRennes/mosaik/commit/ec12f33544))
- Enhance wizard and state elements with new styles and responsive design ([f7bbd2303c](https://github.com/RueDeRennes/mosaik/commit/f7bbd2303c))
- Update Persona and QR Code themes with new styles and tokens ([dfb5030cd8](https://github.com/RueDeRennes/mosaik/commit/dfb5030cd8))
- add style dictionary component generation and enhance SCSS file handling ([8cb9f0d702](https://github.com/RueDeRennes/mosaik/commit/8cb9f0d702))
- enhance SCSS file handling by adding default content population and improving path resolution ([d2a09333bc](https://github.com/RueDeRennes/mosaik/commit/d2a09333bc))
- implement retro theme support and enhance theme handling across components ([6e6501b5d3](https://github.com/RueDeRennes/mosaik/commit/6e6501b5d3))
- enable multi-language support and add ColorSwatchGroupElement ([e15a8905a4](https://github.com/RueDeRennes/mosaik/commit/e15a8905a4))
- update theme to dark mode and refine color tokens for improved accessibility ([42819d5937](https://github.com/RueDeRennes/mosaik/commit/42819d5937))
- enhance theming support by adding size and layout properties to various components ([285a91ad39](https://github.com/RueDeRennes/mosaik/commit/285a91ad39))
- add appearance variants to toolbar and tab components for enhanced theming support ([275de74baa](https://github.com/RueDeRennes/mosaik/commit/275de74baa))
- enhance theming support by applying Themeable behavior to multiple component classes ([cd7b65f77b](https://github.com/RueDeRennes/mosaik/commit/cd7b65f77b))
- import Themeable behavior into various component files for enhanced theming support ([f9c34b371e](https://github.com/RueDeRennes/mosaik/commit/f9c34b371e))
- add size, duration, elevation, layout, and typography functions to Joy theme styles ([8d472f999c](https://github.com/RueDeRennes/mosaik/commit/8d472f999c))
- add Themeable mixin and import to component style templates ([60e2060c70](https://github.com/RueDeRennes/mosaik/commit/60e2060c70))
- update Joy theme styles for various components, adding new properties and improving consistency ([7eba0a5ea3](https://github.com/RueDeRennes/mosaik/commit/7eba0a5ea3))
- remove obsolete style files and add shared styles for Portal, Content, Floating, and MessageBox components ([dd521743ec](https://github.com/RueDeRennes/mosaik/commit/dd521743ec))
- add retro theme styles for Chip and QRCode components, remove obsolete Spacer and Sticky styles ([e34f5ee454](https://github.com/RueDeRennes/mosaik/commit/e34f5ee454))
- remove obsolete style files and add new Joy theme styles for various components ([233ed63475](https://github.com/RueDeRennes/mosaik/commit/233ed63475))
- refactor theme styles for Card and CompoundButton components ([a3c49279c0](https://github.com/RueDeRennes/mosaik/commit/a3c49279c0))
- add shared styles for new UI components and update existing styles for consistency ([1772b383a7](https://github.com/RueDeRennes/mosaik/commit/1772b383a7))
- add default styles to Absolute and AbsoluteItem components ([dd26c85a21](https://github.com/RueDeRennes/mosaik/commit/dd26c85a21))
- add cosmopolitan theme style to various form and UI components ([0015925f0c](https://github.com/RueDeRennes/mosaik/commit/0015925f0c))
- enhance Floating Action Button with multiple theme styles ([10892ad232](https://github.com/RueDeRennes/mosaik/commit/10892ad232))
- MAJOR MIGRATION ([4118d0424b](https://github.com/RueDeRennes/mosaik/commit/4118d0424b))
- add script to create theme style templates for components and manage SCSS files ([a12659870b](https://github.com/RueDeRennes/mosaik/commit/a12659870b))
- add new theme styles for various components to enhance UI consistency ([271cecd764](https://github.com/RueDeRennes/mosaik/commit/271cecd764))
- update calendar and chipbox components with improved theming and styles for consistency ([7cdd9a1342](https://github.com/RueDeRennes/mosaik/commit/7cdd9a1342))
- add shared styles for calendar components to enhance UI consistency and layout ([9555e86fab](https://github.com/RueDeRennes/mosaik/commit/9555e86fab))
- enhance input components with improved theming and layout consistency ([5b5a41cf54](https://github.com/RueDeRennes/mosaik/commit/5b5a41cf54))
- enhance select and signature pad components with improved styles for consistency and usability ([8c4ff832f4](https://github.com/RueDeRennes/mosaik/commit/8c4ff832f4))
- add shared styles for grid, virtualize, absolute, tile list, masonry, and title layout components to enhance UI consistency ([cbe8204651](https://github.com/RueDeRennes/mosaik/commit/cbe8204651))
- add shared styles for BackTop and CookieConsent components to enhance UI consistency ([ea0800bf89](https://github.com/RueDeRennes/mosaik/commit/ea0800bf89))
- update chip component styles for improved theming and consistency across appearances ([e397515a48](https://github.com/RueDeRennes/mosaik/commit/e397515a48))
- add shared styles for toggletip, carousel, paginator, drop zone, backdrop, and other components to enhance UI consistency ([62d14f58c6](https://github.com/RueDeRennes/mosaik/commit/62d14f58c6))
- add shared styles for tab, table, and list components to improve UI consistency ([3915378683](https://github.com/RueDeRennes/mosaik/commit/3915378683))
- add shared styles for tree and wizard components to enhance UI consistency ([e3dbaf7ac2](https://github.com/RueDeRennes/mosaik/commit/e3dbaf7ac2))
- enhance persona and QR code components with improved theming and shared styles for consistency ([9a32c6f95f](https://github.com/RueDeRennes/mosaik/commit/9a32c6f95f))
- update floating action button and group styles with improved theming and shared properties for consistency ([09e2c90ca3](https://github.com/RueDeRennes/mosaik/commit/09e2c90ca3))
- enhance toggle button and dropdown button styles with improved theming and shared styles for consistency ([b7423c1248](https://github.com/RueDeRennes/mosaik/commit/b7423c1248))
- update slider and avatar components with improved theming and layout consistency ([e7977bb1c1](https://github.com/RueDeRennes/mosaik/commit/e7977bb1c1))
- add shared styles for slider, meter bar, meter ring, and progress ring components to enhance UI consistency ([09a6c723f0](https://github.com/RueDeRennes/mosaik/commit/09a6c723f0))
- enhance dialog and drawer components with shared styles and improved theming for consistency ([9f5a6c1057](https://github.com/RueDeRennes/mosaik/commit/9f5a6c1057))
- add dialog component styles and theme configurations for improved UI consistency ([c3701084c0](https://github.com/RueDeRennes/mosaik/commit/c3701084c0))
- implement shared styles for ripple elements and add error/success/empty state components for improved consistency ([382d923011](https://github.com/RueDeRennes/mosaik/commit/382d923011))
- update chart themes to use local theme variables and unset default styles for improved consistency ([60aba50dec](https://github.com/RueDeRennes/mosaik/commit/60aba50dec))
- enhance Breadcrumb and Icon components with shared styles and update theme tokens for improved consistency ([43631aabb3](https://github.com/RueDeRennes/mosaik/commit/43631aabb3))
- add router and router-related styles for Joy and Default themes to enhance theming consistency ([33d4882612](https://github.com/RueDeRennes/mosaik/commit/33d4882612))
- update MenuItem and SearchBox styles for improved theming consistency and add shared focus ring styles ([ac0b6710c5](https://github.com/RueDeRennes/mosaik/commit/ac0b6710c5))
- add shared SCSS styles for Menu and Chat components to enhance theming consistency ([b65b7d9d93](https://github.com/RueDeRennes/mosaik/commit/b65b7d9d93))
- update Avatar and Badge styles for improved theming and layout consistency ([d48699783b](https://github.com/RueDeRennes/mosaik/commit/d48699783b))
- add SCSS theme files for media components with shared styling mixins ([9def4b2004](https://github.com/RueDeRennes/mosaik/commit/9def4b2004))
- add SCSS files for media components with initial styling setup ([52eddb1e29](https://github.com/RueDeRennes/mosaik/commit/52eddb1e29))
- update styles to use joy scheme variables for improved theme consistency ([5069a9cc96](https://github.com/RueDeRennes/mosaik/commit/5069a9cc96))
- introduce ITheme2ElementProps interface and enhance Theme2 with palette management ([fedd1abc19](https://github.com/RueDeRennes/mosaik/commit/fedd1abc19))
- implement ThemeGenerator and enhance Theme2Element with public theme application methods ([7c6e338528](https://github.com/RueDeRennes/mosaik/commit/7c6e338528))
- add event handling interfaces for improved event management ([eb8158af09](https://github.com/RueDeRennes/mosaik/commit/eb8158af09))
- hard scss refactoring ([847d18e07a](https://github.com/RueDeRennes/mosaik/commit/847d18e07a))
- update Angular dependencies to version 19.1.5 and add new build configurations ([caa65cbcd7](https://github.com/RueDeRennes/mosaik/commit/caa65cbcd7))
- add node-gyp as a dependency in package.json ([7ee58ddb29](https://github.com/RueDeRennes/mosaik/commit/7ee58ddb29))
- update package.json dependencies to use workspace references ([a09d328efb](https://github.com/RueDeRennes/mosaik/commit/a09d328efb))
- update documentation structure and add metadata for MVP and Command patterns ([aa740dcdc8](https://github.com/RueDeRennes/mosaik/commit/aa740dcdc8))
- add JSON and Markdown configurations to ESLint setup and update index for new configs ([67f5cb6cd9](https://github.com/RueDeRennes/mosaik/commit/67f5cb6cd9))
- add clear method to Renderer and update RouterOutletElement to use it for clearing slots ([e2fb12d2f6](https://github.com/RueDeRennes/mosaik/commit/e2fb12d2f6))
- add @prisma/extension-optimize dependency and enable optimization in PrismaService ([d09a4414dc](https://github.com/RueDeRennes/mosaik/commit/d09a4414dc))
- enhance resource serialization by adding metadata support in serializers and transformers ([d81c5fe981](https://github.com/RueDeRennes/mosaik/commit/d81c5fe981))
- update resource info interfaces to use readonly properties and enhance cloning functionality ([173c1c0d01](https://github.com/RueDeRennes/mosaik/commit/173c1c0d01))
- update CLI argument interfaces and improve resource generator imports ([52697bfaab](https://github.com/RueDeRennes/mosaik/commit/52697bfaab))
- add AI localizator module with configuration and CLI argument support ([38770963c7](https://github.com/RueDeRennes/mosaik/commit/38770963c7))
- add localizator executor and update related configurations ([79a5f1dd0d](https://github.com/RueDeRennes/mosaik/commit/79a5f1dd0d))
- enhance sorting functionality in resource interfaces and update TypeScript configurations ([6fcb2f3903](https://github.com/RueDeRennes/mosaik/commit/6fcb2f3903))
- add ESLint and Vitest configurations, implement TypeScript settings, and define parser and formatter interfaces for localization ([c09d8c541a](https://github.com/RueDeRennes/mosaik/commit/c09d8c541a))
- add ESLint and Vitest configurations for localization tools and implement tests for Angular, React, and Vue presets ([22a450cdd4](https://github.com/RueDeRennes/mosaik/commit/22a450cdd4))
- update package.json files and add TypeScript configurations for localization ([577f8dd710](https://github.com/RueDeRennes/mosaik/commit/577f8dd710))
- implement parser interfaces and various parser classes for localization ([8b5b4258e1](https://github.com/RueDeRennes/mosaik/commit/8b5b4258e1))
- update project CommonJS/ESM TypeScript configurations ([b57802c2d9](https://github.com/RueDeRennes/mosaik/commit/b57802c2d9))
- migrate from lodash to es-toolkit for utility functions and update package dependencies ([cfdb4f64a1](https://github.com/RueDeRennes/mosaik/commit/cfdb4f64a1))
- add tsup configuration for Vite and Utilities, update LiveReload plugin options ([9d0b3a71be](https://github.com/RueDeRennes/mosaik/commit/9d0b3a71be))
- update Vite configuration and improve FileSystemWatcher filtering logic ([43a655b8ac](https://github.com/RueDeRennes/mosaik/commit/43a655b8ac))
- add Vite configuration and plugins, including live reload functionality ([92b0ee5260](https://github.com/RueDeRennes/mosaik/commit/92b0ee5260))
- remove obsolete BlockquoteProcessor tests and add utility functions for token metadata management ([11be8212a8](https://github.com/RueDeRennes/mosaik/commit/11be8212a8))
- add Vitest configuration and implement tests for Markdown processors ([10d745777c](https://github.com/RueDeRennes/mosaik/commit/10d745777c))
- add type annotations for hot update handler and improve import statements in processors ([6c28d98979](https://github.com/RueDeRennes/mosaik/commit/6c28d98979))
- integrate markdowner tool and update API paths for consistency ([21c276f79a](https://github.com/RueDeRennes/mosaik/commit/21c276f79a))
- initialize Mosaik.Elements library with TypeScript configuration and documentation ([121c1196a8](https://github.com/RueDeRennes/mosaik/commit/121c1196a8))
- add mosaik-elements-angular-2 library with initial component and configuration files ([2e4c734f9e](https://github.com/RueDeRennes/mosaik/commit/2e4c734f9e))
- add infrastructure build step to API development workflow ([4f77ea2b30](https://github.com/RueDeRennes/mosaik/commit/4f77ea2b30))
- implement new email delivery strategies ([71d732c67d](https://github.com/RueDeRennes/mosaik/commit/71d732c67d))
- add dependency installation step in GitHub Actions workflow ([0ee17aa199](https://github.com/RueDeRennes/mosaik/commit/0ee17aa199))
- add build infrastructure step and update project configurations with 'infra' tags ([355a7b0768](https://github.com/RueDeRennes/mosaik/commit/355a7b0768))
- add VERBOSE environment variable for detailed linting logs ([e3fe3fad69](https://github.com/RueDeRennes/mosaik/commit/e3fe3fad69))
- add CommandNamingRule for ESLint; update project configuration and enhance documentation ([21e0e36302](https://github.com/RueDeRennes/mosaik/commit/21e0e36302))
- add ICommand interface and implement delete profile view styles; update username references to userName across the codebase ([b7184a2d10](https://github.com/RueDeRennes/mosaik/commit/b7184a2d10))
- **api:** update Doppler configuration to support API key authentication and enhance documentation ([8e4c98a5e0](https://github.com/RueDeRennes/mosaik/commit/8e4c98a5e0))
- **api:** add doppler support for security keys ([bb1dd83041](https://github.com/RueDeRennes/mosaik/commit/bb1dd83041))
- **api:** add new issue models and update icon response; remove unused IIconGroup model ([d05cefc0ed](https://github.com/RueDeRennes/mosaik/commit/d05cefc0ed))
- add docs executor and update package dependencies across multiple libraries ([b55ff52fd4](https://github.com/RueDeRennes/mosaik/commit/b55ff52fd4))
- add GitHub Actions workflow for development app deployment with caching and build steps ([118b8a6bff](https://github.com/RueDeRennes/mosaik/commit/118b8a6bff))
- add SubscribeRequest and UnsubscribeRequest classes, update API response statuses to use HttpStatus, and enhance Prisma configuration for PostgreSQL ([7c49d4098d](https://github.com/RueDeRennes/mosaik/commit/7c49d4098d))
- add Database module and service, integrate with Issues and Newsletter repositories, and update TypeScript configuration ([238c8b509b](https://github.com/RueDeRennes/mosaik/commit/238c8b509b))
- update server port to 8080, add IssuesView and related styles, and enhance ApiService2 with issue management methods ([8e55d5be52](https://github.com/RueDeRennes/mosaik/commit/8e55d5be52))
- navigate to backend directory and list files before building Docker image ([bb4a5f8723](https://github.com/RueDeRennes/mosaik/commit/bb4a5f8723))
- enhance GitHub Actions workflow for Docker by adding artifact upload and improving repository name handling ([b93588e6d5](https://github.com/RueDeRennes/mosaik/commit/b93588e6d5))
- add .dockerignore for mosaik-api and log npm dependencies in build step ([d170a45722](https://github.com/RueDeRennes/mosaik/commit/d170a45722))
- add GitHub Actions workflow for Docker build and push to GHCR ([14f2ed37e1](https://github.com/RueDeRennes/mosaik/commit/14f2ed37e1))
- add backend code ([599d31af49](https://github.com/RueDeRennes/mosaik/commit/599d31af49))
- **nx-cloud:** setup nx cloud workspace ([9dfa175d05](https://github.com/RueDeRennes/mosaik/commit/9dfa175d05))
- add commitlint in repo ([4a71ed5158](https://github.com/RueDeRennes/mosaik/commit/4a71ed5158))
- upgrade to angular 12 ([e604cc6da3](https://github.com/RueDeRennes/mosaik/commit/e604cc6da3))
- **angular:** add cdk dependency to add new dialogService ([8c294ec672](https://github.com/RueDeRennes/mosaik/commit/8c294ec672))
- **commerce:** add new commerce package 🎉 ([b595653878](https://github.com/RueDeRennes/mosaik/commit/b595653878))
- **angular:** add camera recorder typings ([32a8ba560e](https://github.com/RueDeRennes/mosaik/commit/32a8ba560e))

### 🩹 Fixes

- **release:** remove conflicting Nx confirmation flags ([182d98e45f](https://github.com/RueDeRennes/mosaik/commit/182d98e45f))
- update documentation links and improve CSS properties for stack elements ([97d8560d4f](https://github.com/RueDeRennes/mosaik/commit/97d8560d4f))
- update documentation links and definitions for TourService and TourControls ([d4d83fa4bf](https://github.com/RueDeRennes/mosaik/commit/d4d83fa4bf))
- change overflow from scroll to auto for better responsiveness in FloatingElement styles ([a15f9da672](https://github.com/RueDeRennes/mosaik/commit/a15f9da672))
- **chat:** message item styles ([0aa3cc52ed](https://github.com/RueDeRennes/mosaik/commit/0aa3cc52ed))
- **prompt-box:** source focus ring offsets from theme tokens ([36fe537153](https://github.com/RueDeRennes/mosaik/commit/36fe537153))
- **chat:** stabilize rail layout and nested interactions ([637075d3ec](https://github.com/RueDeRennes/mosaik/commit/637075d3ec))
- **components:** ensure closed event handling respects target element ([86da3f3b56](https://github.com/RueDeRennes/mosaik/commit/86da3f3b56))
- **dependencies:** update eslint-import-resolver-node to version 0.4.0 ([0698e6c779](https://github.com/RueDeRennes/mosaik/commit/0698e6c779))
- **DataTableElement:** update line numbers in documentation links ([9ee485ad09](https://github.com/RueDeRennes/mosaik/commit/9ee485ad09))
- **build:** clean foundation output before compilation ([75c960748a](https://github.com/RueDeRennes/mosaik/commit/75c960748a))
- **tab:** add scroll and overflow buttons ([54dfb62877](https://github.com/RueDeRennes/mosaik/commit/54dfb62877))
- **intl:** fix path bug ([91073d923e](https://github.com/RueDeRennes/mosaik/commit/91073d923e))
- dropdown ([4fe38baa1e](https://github.com/RueDeRennes/mosaik/commit/4fe38baa1e))
- **split-button:** floating element in dedicated portal ([ab706da4e4](https://github.com/RueDeRennes/mosaik/commit/ab706da4e4))
- **split-button:** fix focus ring on selection ([eead797e27](https://github.com/RueDeRennes/mosaik/commit/eead797e27))
- **split-button:** fix focus ring on selection ([ac396fadf9](https://github.com/RueDeRennes/mosaik/commit/ac396fadf9))
- **theme:** update shadow properties for various components in joy theme ([58749fd792](https://github.com/RueDeRennes/mosaik/commit/58749fd792))
- **states:** update hidden selector for actions to use [hidden] attribute ([3a251c1c13](https://github.com/RueDeRennes/mosaik/commit/3a251c1c13))
- **states:** update empty actions selector to hidden ([4e3bde1d9f](https://github.com/RueDeRennes/mosaik/commit/4e3bde1d9f))
- **states:** fix state styles ([44108b296e](https://github.com/RueDeRennes/mosaik/commit/44108b296e))
- **drawer:** update DrawerService and DrawerPortalComponent for improved config handling ([b0856036d1](https://github.com/RueDeRennes/mosaik/commit/b0856036d1))
- **chart:** ensure series and options updates are awaited ([b7152bd90a](https://github.com/RueDeRennes/mosaik/commit/b7152bd90a))
- **chart:** change pending update properties to non-readonly ([6d99698f3e](https://github.com/RueDeRennes/mosaik/commit/6d99698f3e))
- **package:** add missing newline at end of file in package.json ([b2edcaf718](https://github.com/RueDeRennes/mosaik/commit/b2edcaf718))
- **popup:** add options for open mode and focus delegation ([f544d36064](https://github.com/RueDeRennes/mosaik/commit/f544d36064))
- **ItemDefDirective:** update line numbers in documentation for clarity ([84911e1e80](https://github.com/RueDeRennes/mosaik/commit/84911e1e80))
- **forms:** add textOverflow property to error and hint components ([39779c12ad](https://github.com/RueDeRennes/mosaik/commit/39779c12ad))
- **styles:** add 'px' unit to drawer-viewport-inset in multiple theme files ([26b16548aa](https://github.com/RueDeRennes/mosaik/commit/26b16548aa))
- **api:** update line numbers and references in documentation for MenuItemGroupElement, ListItemElement, and MenuItemElement ([08cc5bdbf9](https://github.com/RueDeRennes/mosaik/commit/08cc5bdbf9))
- **api:** update line numbers in documentation for various services and components ([7ac1fab82d](https://github.com/RueDeRennes/mosaik/commit/7ac1fab82d))
- **themes:** update typography styles for card subtitle and expander header components ([3982e8ce87](https://github.com/RueDeRennes/mosaik/commit/3982e8ce87))
- **ChipGroupElement:** ensure chips are checkable based on selection mode ([acf4102874](https://github.com/RueDeRennes/mosaik/commit/acf4102874))
- **TabStripItemElement:** update background color variables for hover and selected states ([e7048274dd](https://github.com/RueDeRennes/mosaik/commit/e7048274dd))
- **docs:** update line numbers in overlay service documentation ([5c461a79b7](https://github.com/RueDeRennes/mosaik/commit/5c461a79b7))
- **TabElements:** remove overflow property and disable indicators for tabs ([ee615e0903](https://github.com/RueDeRennes/mosaik/commit/ee615e0903))
- **MessageBoxPortal:** update definition links and add missing styles ([66b0c53414](https://github.com/RueDeRennes/mosaik/commit/66b0c53414))
- **MessageBox:** update event emission and button part names for consistency ([47693311cb](https://github.com/RueDeRennes/mosaik/commit/47693311cb))
- **portal:** set position to fixed for portal host and projection elements ([cec2c9ba9c](https://github.com/RueDeRennes/mosaik/commit/cec2c9ba9c))
- **portal:** update LayerManager z-index and enable position styling ([5c7eca7aa1](https://github.com/RueDeRennes/mosaik/commit/5c7eca7aa1))
- **api:** update event detail definitions and add value property to table components ([2610ad2acb](https://github.com/RueDeRennes/mosaik/commit/2610ad2acb))
- **release:** update changelog command to use version from mosaik-themes package ([cbe25acac5](https://github.com/RueDeRennes/mosaik/commit/cbe25acac5))
- **dependencies:** update Pixel Brewery packages to version 0.0.10 ([de299ae898](https://github.com/RueDeRennes/mosaik/commit/de299ae898))
- **auth:** update dependencies and refactor GitHub authentication strategy ([174d27920f](https://github.com/RueDeRennes/mosaik/commit/174d27920f))
- **token-linter): add error handling for JSON parsing in resolver feat(data-table): suppress column change events during updates style(data-table): update editor panel styles for better layout style(data-table): unify editor panel styles across themes feat(table): add new CSS properties for column and row borders fix(table): ensure proper border handling in body and header rows refactor(table): improve column change subscription logic in TableRowBaseElement style(table-column-editor:** enhance layout and overflow handling ([0defb431bd](https://github.com/RueDeRennes/mosaik/commit/0defb431bd))
- **designer-view:** adjust dialog dimensions to use percentage for width and height ([e5ad192120](https://github.com/RueDeRennes/mosaik/commit/e5ad192120))
- **projects:** add missing newlines in project.json files and update .gitignore ([8a9cc36342](https://github.com/RueDeRennes/mosaik/commit/8a9cc36342))
- **buttons): unify background property usage and adjust opacity values fix(toast): implement progress fill animation and update styles for consistency style(toast): update CSS variables for progress fill color across themes refactor(toast:** remove intervalTick property and related logic from ToastElement ([0dbbbcd78d](https://github.com/RueDeRennes/mosaik/commit/0dbbbcd78d))
- **tokens:** update ripple duration from 200ms to 0.20s across multiple components ([dbe821713f](https://github.com/RueDeRennes/mosaik/commit/dbe821713f))
- **router:** correct router link href formatting and improve fallback logic ([0e74beb027](https://github.com/RueDeRennes/mosaik/commit/0e74beb027))
- **ApiDocs:** update styles for table and code elements in API documentation layout ([2e991817d3](https://github.com/RueDeRennes/mosaik/commit/2e991817d3))
- **docs:** fix HTML @example snippets in 26 element TSDoc blocks ([c9dea12141](https://github.com/RueDeRennes/mosaik/commit/c9dea12141))
- **docs:** correct TSDoc @example HTML snippets in 25 element files ([e207fcb67b](https://github.com/RueDeRennes/mosaik/commit/e207fcb67b))
- **tsdoc:** correct @example HTML snippets in 20 Selectors element files ([b21e580aae](https://github.com/RueDeRennes/mosaik/commit/b21e580aae))
- **tsdoc:** correct @example HTML snippets in 12 element files ([469e33617f](https://github.com/RueDeRennes/mosaik/commit/469e33617f))
- correct TSDoc @example HTML snippets in 40 Primitives element files ([297e2e15e5](https://github.com/RueDeRennes/mosaik/commit/297e2e15e5))
- **docs:** correct TSDoc @example blocks in 40 Lit component files ([8a1bd700e3](https://github.com/RueDeRennes/mosaik/commit/8a1bd700e3))
- correct @example blocks in TSDoc for 25 foundation elements ([140c0f9cb0](https://github.com/RueDeRennes/mosaik/commit/140c0f9cb0))
- **dependencies:** update style-dictionary to version 5.3.3 across all packages ([5df6333874](https://github.com/RueDeRennes/mosaik/commit/5df6333874))
- **chart:** enforce strict type checking for chart element descendant retrieval ([ba6f5f4d61](https://github.com/RueDeRennes/mosaik/commit/ba6f5f4d61))
- **package:** remove zod dependency from yarn.lock ([d01b86d809](https://github.com/RueDeRennes/mosaik/commit/d01b86d809))
- **localizator-ai:** restore schema-based structured generation with vercel sdk ([d2f83bc43c](https://github.com/RueDeRennes/mosaik/commit/d2f83bc43c))
- **theme:** update shadow properties across Joy and Memphis themes for consistency ([1da029cee7](https://github.com/RueDeRennes/mosaik/commit/1da029cee7))
- **config:** update languageId in cspell configuration and increment release version ([ac1296c847](https://github.com/RueDeRennes/mosaik/commit/ac1296c847))
- **sheet:** update transform properties for smoother animations and touch event handling ([5fe9426e43](https://github.com/RueDeRennes/mosaik/commit/5fe9426e43))
- **docs:** correct createdAt and updatedAt dates in NgRx and RxJS articles ([af98b9acfa](https://github.com/RueDeRennes/mosaik/commit/af98b9acfa))
- **author:** correct spelling of Andre to André in multiple documentation files ([e924eb8206](https://github.com/RueDeRennes/mosaik/commit/e924eb8206))
- **scheduler): update time-row styles to use is-last-of-hour for border color style(scheduler): refactor SCSS for header and body components for better structure refactor(scheduler): adjust padding properties for events and header cells in tokens chore(scheduler:** enhance mixin handling in styledictionary configuration ([57b8c3f1fc](https://github.com/RueDeRennes/mosaik/commit/57b8c3f1fc))
- **project:** add missing newline at end of JSON files ([9ae562116e](https://github.com/RueDeRennes/mosaik/commit/9ae562116e))
- **theme:** rename background properties to background-color for consistency ([07433233bc](https://github.com/RueDeRennes/mosaik/commit/07433233bc))
- **components): rename event emitters for consistency and clarity refactor(events): update event detail interfaces for improved type safety feat(events:** add readonly event emitter interface for better encapsulation ([4374d5ef71](https://github.com/RueDeRennes/mosaik/commit/4374d5ef71))
- **router:** fix href handling in RouterLinkElement and RouterLinkDirective ([de729cbc15](https://github.com/RueDeRennes/mosaik/commit/de729cbc15))
- **package:** add missing newline at end of package.json ([88da605287](https://github.com/RueDeRennes/mosaik/commit/88da605287))
- **package:** add missing newline at end of file ([876a6f3b9f](https://github.com/RueDeRennes/mosaik/commit/876a6f3b9f))
- **theme:** enhance AppThemeView with expert mode features and improve styling ([b43b095440](https://github.com/RueDeRennes/mosaik/commit/b43b095440))
- **styles:** correct theme import paths in SCSS files ([932cfad727](https://github.com/RueDeRennes/mosaik/commit/932cfad727))
- **docs:** standardize punctuation and formatting across multiple documentation files ([bed55885fe](https://github.com/RueDeRennes/mosaik/commit/bed55885fe))
- **theme:** update paths for Tailwind presets and add Snyk organization setting ([a2defd1849](https://github.com/RueDeRennes/mosaik/commit/a2defd1849))
- **package.json:** add missing newline at end of file ([8b6d8f8c2b](https://github.com/RueDeRennes/mosaik/commit/8b6d8f8c2b))
- **package.json:** update release version to 0.0.221 ([03ebc3de62](https://github.com/RueDeRennes/mosaik/commit/03ebc3de62))
- **package.json:** update release version to 0.0.220 ([320c50e503](https://github.com/RueDeRennes/mosaik/commit/320c50e503))
- **Sandbox.json): update theme import paths for consistency in SCSS usage fix(package.json:** increment release version to 0.0.219 ([57dce3aace](https://github.com/RueDeRennes/mosaik/commit/57dce3aace))
- **package:** streamline build scripts to include alias replacement and package copying ([65637ebced](https://github.com/RueDeRennes/mosaik/commit/65637ebced))
- **resize:** standardize resize event names to camelCase and update related components ([a9cc1df0a7](https://github.com/RueDeRennes/mosaik/commit/a9cc1df0a7))
- **UpDownSpinnerSample): ensure value updates correctly on spin events fix(FeedbackDetailView): use mutable feedback object for comment and vote updates fix(FeedbackDetailViewTemplate): prevent deleteComment call if feedback ID is undefined refactor(SupportView): override render method for better clarity fix(AppViewTemplate): handle icon assignment safely with fallback fix(NewsletterViewTemplate): ensure newsletter submission works correctly fix(EventsViewTemplate): improve handling of calendar location and link checks fix(ProfileViewTemplate): ensure bio input hint updates correctly fix(ColorPaletteBuilderView): ensure palette generation uses correct types fix(GridGeneratorView): instantiate view model correctly and expose it refactor(GridGeneratorViewTemplate): simplify template function signature fix(IconGalleryViewTemplate): ensure mode selection works correctly with types chore(tsconfig): change module resolution to Bundler for better compatibility chore(vite.config): add vite-plugin-checker for TypeScript checks chore(vite.config.production): include vite-plugin-checker for production builds feat(Controller): add IControllerHostRef and IReactiveController interfaces feat(Controller): implement useController for managing reactive controllers chore(ControllerHost): remove deprecated ControllerHost implementation feat(GlobalDomRef:** create global DOM reference for better testability ([9da5337bfb](https://github.com/RueDeRennes/mosaik/commit/9da5337bfb))
- **tooltip:** handle null values for body and floating elements, improve event handling ([93d88722ee](https://github.com/RueDeRennes/mosaik/commit/93d88722ee))
- **stepper:** improve stepper functionality and styles, add navigation directives ([d53c7333a7](https://github.com/RueDeRennes/mosaik/commit/d53c7333a7))
- **stepper:** update properties and styles for Stepper themes and components ([5f66855a75](https://github.com/RueDeRennes/mosaik/commit/5f66855a75))
- **stepper:** update stepper item properties to use description and hint ([8f8d17acb8](https://github.com/RueDeRennes/mosaik/commit/8f8d17acb8))
- **buttons): update stack-gap variable usage in FloatingActionButton, RepeatButton, SplitButton, ToggleButton themes fix(card): update stack-gap variable usage in CardActions theme fix(expander): update stack-gap variable usage in Expander theme fix(comment): update stack-gap variable usage in Comment theme fix(dialog): update stack-gap variable usage in DialogActions theme fix(segment): update stack-gap variable usage in SegmentItem theme fix(tab-strip): update stack-gap variable usage in TabStripItem theme fix(states): update stack-gap variable usage in Busy, Empty, Error, and Success state themes chore(package:** bump version to 0.0.204 in package.json ([878a490c1e](https://github.com/RueDeRennes/mosaik/commit/878a490c1e))
- **package:** add missing newline at end of file ([e7bbe4e7c1](https://github.com/RueDeRennes/mosaik/commit/e7bbe4e7c1))
- **keywords:** add Event Bus and Message Bus to event hub documentation ([69cafcf76f](https://github.com/RueDeRennes/mosaik/commit/69cafcf76f))
- **package:** add missing newline at end of file in package.json ([a9bf15349b](https://github.com/RueDeRennes/mosaik/commit/a9bf15349b))
- **Cdk:** export FormFieldStatusDirective alongside FORM_STATUS_HOST from FormStatusDirective ([c8521cd4ff](https://github.com/RueDeRennes/mosaik/commit/c8521cd4ff))
- **choice-group:** add flex property to root part for improved layout consistency ([8bd80ed40b](https://github.com/RueDeRennes/mosaik/commit/8bd80ed40b))
- **choice-group:** add flex property to root part for better layout ([51e2a1a9be](https://github.com/RueDeRennes/mosaik/commit/51e2a1a9be))
- **package:** add missing newline at end of file ([0fc5a107d6](https://github.com/RueDeRennes/mosaik/commit/0fc5a107d6))
- **release:** update release script version to 0.0.177 ([1895016b0a](https://github.com/RueDeRennes/mosaik/commit/1895016b0a))
- add missing newline at end of JSON files ([60b2109dd0](https://github.com/RueDeRennes/mosaik/commit/60b2109dd0))
- add missing newline at end of package.json ([b00046e27b](https://github.com/RueDeRennes/mosaik/commit/b00046e27b))
- remove unused elevation2 light token and update release version in package.json ([9a63ade438](https://github.com/RueDeRennes/mosaik/commit/9a63ade438))
- remove unused dependency 'element-to-path' from yarn.lock ([df86dc94de](https://github.com/RueDeRennes/mosaik/commit/df86dc94de))
- add newline at end of package.json ([73db364d3c](https://github.com/RueDeRennes/mosaik/commit/73db364d3c))
- **release:** update release version to 0.0.170 ([089a682d6f](https://github.com/RueDeRennes/mosaik/commit/089a682d6f))
- **release:** update release version to 0.0.169 ([77c58d1eea](https://github.com/RueDeRennes/mosaik/commit/77c58d1eea))
- **release:** update release version to 0.0.168 ([1434c7a9fd](https://github.com/RueDeRennes/mosaik/commit/1434c7a9fd))
- **ChipElementTemplate:** update is-flipped property to use side attribute for better clarity ([fa94cf7a00](https://github.com/RueDeRennes/mosaik/commit/fa94cf7a00))
- **package:** add missing newline at end of file ([4aa435a5b6](https://github.com/RueDeRennes/mosaik/commit/4aa435a5b6))
- add newline at end of package.json ([b35cc46eca](https://github.com/RueDeRennes/mosaik/commit/b35cc46eca))
- correct typo in TODO comment in TemplateType.ts and adjust formatting in ModelKind.ts and ModelKindRegistry.ts ([c8bcbb7a65](https://github.com/RueDeRennes/mosaik/commit/c8bcbb7a65))
- correct typos in interface comments and update default configuration values ([dc58b1a35c](https://github.com/RueDeRennes/mosaik/commit/dc58b1a35c))
- remove outline from list element styles for improved appearance ([ff19b36c81](https://github.com/RueDeRennes/mosaik/commit/ff19b36c81))
- add newline at end of file in package.json ([d0e684e967](https://github.com/RueDeRennes/mosaik/commit/d0e684e967))
- update release version to 0.0.156 in package.json ([323d1588b7](https://github.com/RueDeRennes/mosaik/commit/323d1588b7))
- update release version to 0.0.155 in package.json ([1f1946594c](https://github.com/RueDeRennes/mosaik/commit/1f1946594c))
- update release version to 0.0.154 in package.json ([d894b6b4a1](https://github.com/RueDeRennes/mosaik/commit/d894b6b4a1))
- remove deprecated -webkit-backdrop-filter from transition properties in theme styles refactor: simplify AutoCompleteBox styles for better maintainability chore: update release script to version 0.0.153 ([a7af7fe240](https://github.com/RueDeRennes/mosaik/commit/a7af7fe240))
- update release script version to 0.0.149 and adjust enum handling in modelClass function ([826e15bdf2](https://github.com/RueDeRennes/mosaik/commit/826e15bdf2))
- correct spelling of 'schema' in OpenApiParser logging ([1a75e6c62b](https://github.com/RueDeRennes/mosaik/commit/1a75e6c62b))
- update release script version to 0.0.145 and enhance logging output in TemplateBuilder ([c77501d259](https://github.com/RueDeRennes/mosaik/commit/c77501d259))
- update release version to 0.0.144 and improve type annotations in TemplateEngine ([c99a28f6b6](https://github.com/RueDeRennes/mosaik/commit/c99a28f6b6))
- correct spelling of 'preferred' in TemplateBuilder and related files ([5862673dc4](https://github.com/RueDeRennes/mosaik/commit/5862673dc4))
- update release script version to 0.0.142 ([b558893804](https://github.com/RueDeRennes/mosaik/commit/b558893804))
- correct base component property references in AnchorElement.Joy.scss ([8f7ae019cf](https://github.com/RueDeRennes/mosaik/commit/8f7ae019cf))
- add missing newline at end of package.json ([3309d1ee97](https://github.com/RueDeRennes/mosaik/commit/3309d1ee97))
- resolve split, searchbox and pinbox issues ([8417d2d5bf](https://github.com/RueDeRennes/mosaik/commit/8417d2d5bf))
- standardize padding-top property in Banner styles and templates ([377e883410](https://github.com/RueDeRennes/mosaik/commit/377e883410))
- enhance build info logging format and update release version to 0.0.135 ([61b1c86643](https://github.com/RueDeRennes/mosaik/commit/61b1c86643))
- add missing newline at end of package.json ([cf3b9a3f21](https://github.com/RueDeRennes/mosaik/commit/cf3b9a3f21))
- add missing newline at end of package.json ([d79563d401](https://github.com/RueDeRennes/mosaik/commit/d79563d401))
- **release:** update version to 0.0.118 in release script ([4ac4717314](https://github.com/RueDeRennes/mosaik/commit/4ac4717314))
- **dialog:** update part name from 'scroller' to 'scroll' in dialog content styles chore: update release version to 0.0.117 in package.json ([b6605f00c0](https://github.com/RueDeRennes/mosaik/commit/b6605f00c0))
- **dialog): correct part name from 'scroller' to 'scroll' in _DialogContentElement.scss chore(release:** update release script version to 0.0.116 in package.json ([549b90aade](https://github.com/RueDeRennes/mosaik/commit/549b90aade))
- **scrub-slider:** handle undefined values in tooltip and tick label accessors ([af6ccb9915](https://github.com/RueDeRennes/mosaik/commit/af6ccb9915))
- **release:** update release version to 0.0.101 in package.json ([86223aaef2](https://github.com/RueDeRennes/mosaik/commit/86223aaef2))
- **release:** update release version to 0.0.100 in package.json ([6b4d2ead65](https://github.com/RueDeRennes/mosaik/commit/6b4d2ead65))
- update release version to 0.0.99 in package.json ([00ce8821ae](https://github.com/RueDeRennes/mosaik/commit/00ce8821ae))
- update release version to 0.0.98 in package.json ([7b87750763](https://github.com/RueDeRennes/mosaik/commit/7b87750763))
- update release version to 0.0.97 in package.json ([332303fb5e](https://github.com/RueDeRennes/mosaik/commit/332303fb5e))
- update release version to 0.0.96 in package.json ([6837da25c3](https://github.com/RueDeRennes/mosaik/commit/6837da25c3))
- update @types/node to version 24.2.1 across multiple packages ([1d3b606f14](https://github.com/RueDeRennes/mosaik/commit/1d3b606f14))
- update release version to 0.0.95 in package.json ([c1d12c2301](https://github.com/RueDeRennes/mosaik/commit/c1d12c2301))
- update import path for FileCache and increment release version to 0.0.94 ([54601adcea](https://github.com/RueDeRennes/mosaik/commit/54601adcea))
- add missing newline at end of package.json ([32f8168058](https://github.com/RueDeRennes/mosaik/commit/32f8168058))
- update cache enabling logic across multiple executors ([91828dcf26](https://github.com/RueDeRennes/mosaik/commit/91828dcf26))
- **release): update version number from 0.0.81 to 0.0.82 in release script fix(events:** remove redundant detailType from select event in Meta.g.json ([a330ca39c9](https://github.com/RueDeRennes/mosaik/commit/a330ca39c9))
- **elements:** add TypeScript ignore comments for static 'is' getters in multiple components ([22cc7e5d04](https://github.com/RueDeRennes/mosaik/commit/22cc7e5d04))
- **dependencies:** downgrade TypeScript version from ^5.9.2 to ^5.8.3 across multiple packages ([c58367f25b](https://github.com/RueDeRennes/mosaik/commit/c58367f25b))
- **elements:** add TypeScript ignore comments for static 'is' getters in various components ([5c400e4885](https://github.com/RueDeRennes/mosaik/commit/5c400e4885))
- correct spelling of 'initialize' in various files and update related interfaces ([3c70f28918](https://github.com/RueDeRennes/mosaik/commit/3c70f28918))
- update years of experience from eight to ten in the interview article ([9a728c51e8](https://github.com/RueDeRennes/mosaik/commit/9a728c51e8))
- update release script to version 0.0.77 ([ff9cf9223c](https://github.com/RueDeRennes/mosaik/commit/ff9cf9223c))
- update release script to version 0.0.76 ([fa4bb82518](https://github.com/RueDeRennes/mosaik/commit/fa4bb82518))
- downgrade yargs dependency from 18.0.0 to 17.7.2 in package.json and yarn.lock ([5467661a3f](https://github.com/RueDeRennes/mosaik/commit/5467661a3f))
- update template resolver and add new copy-templates task; include yargs dependency ([669d9a8603](https://github.com/RueDeRennes/mosaik/commit/669d9a8603))
- correct entry file casing in ng-package.json and vite.config.mjs; add TypeScript dependency in package.json and yarn.lock ([fbb6c9614d](https://github.com/RueDeRennes/mosaik/commit/fbb6c9614d))
- standardize title formatting in documentation files ([8899b6307c](https://github.com/RueDeRennes/mosaik/commit/8899b6307c))
- update IconNameDirective to use 'icon' property instead of 'data' for icon name functionality ([af7d70822c](https://github.com/RueDeRennes/mosaik/commit/af7d70822c))
- add missing newline at end of package.json ([649ed1b503](https://github.com/RueDeRennes/mosaik/commit/649ed1b503))
- **dependencies:** add @rollup/plugin-json to package.json refactor: simplify build script in openapi templates ([f6a6476388](https://github.com/RueDeRennes/mosaik/commit/f6a6476388))
- **dependencies:** update peer dependency for vite to support versions 6.x and 7.x refactor: remove unused plugins from nx configuration fix: update build script in openapi templates to use yarn ([0422a23610](https://github.com/RueDeRennes/mosaik/commit/0422a23610))
- **dependencies:** update vite to version 7.0.2 in package.json and yarn.lock ([b6b2b61b42](https://github.com/RueDeRennes/mosaik/commit/b6b2b61b42))
- **dependencies:** update @nx packages to version 21.2.2 ([c044affa8d](https://github.com/RueDeRennes/mosaik/commit/c044affa8d))
- update release script to version 0.0.71 ([c3e7e5e8bf](https://github.com/RueDeRennes/mosaik/commit/c3e7e5e8bf))
- add missing newline at end of package.json ([73866991d5](https://github.com/RueDeRennes/mosaik/commit/73866991d5))
- update background color to transparent for page header and menu components; update release script to version 0.0.70 ([e8e7c124a4](https://github.com/RueDeRennes/mosaik/commit/e8e7c124a4))
- update release version to 0.0.47 in package.json ([5a277d2d1d](https://github.com/RueDeRennes/mosaik/commit/5a277d2d1d))
- correct spelling of 'HTML' in keywords and add new article on `part` attributes ([cd5b688a5c](https://github.com/RueDeRennes/mosaik/commit/cd5b688a5c))
- correct quotation marks in attribute selector examples for consistency ([078a6c9289](https://github.com/RueDeRennes/mosaik/commit/078a6c9289))
- correct quotation marks in markdown article and improve blockquote rendering in MarkdownRenderer ([09442e4509](https://github.com/RueDeRennes/mosaik/commit/09442e4509))
- update release script to version 0.0.41 ([88efd1b9ca](https://github.com/RueDeRennes/mosaik/commit/88efd1b9ca))
- adjust height calculations for content in AppElement styles ([1d8793fd52](https://github.com/RueDeRennes/mosaik/commit/1d8793fd52))
- update const vs enum article to use string literals for WorkType values ([3eb355434e](https://github.com/RueDeRennes/mosaik/commit/3eb355434e))
- correct quotation marks in best practices section of const vs enum article ([df4187ec19](https://github.com/RueDeRennes/mosaik/commit/df4187ec19))
- update backdrop image URLs in const vs enum article ([e05a779a0a](https://github.com/RueDeRennes/mosaik/commit/e05a779a0a))
- update release version to 0.0.38 in package.json and improve description formatting in Meta.g.json ([edbd04421c](https://github.com/RueDeRennes/mosaik/commit/edbd04421c))
- correct formatting of region comments and quote attribution for clarity ([952d90f14b](https://github.com/RueDeRennes/mosaik/commit/952d90f14b))
- update provideTheme function to simplify overrides and adjust merge function ([0359c488be](https://github.com/RueDeRennes/mosaik/commit/0359c488be))
- update provideTheme to useValue for theme and mode signals ([5a7b509869](https://github.com/RueDeRennes/mosaik/commit/5a7b509869))
- update release script to version 0.0.33 ([0954fadfa3](https://github.com/RueDeRennes/mosaik/commit/0954fadfa3))
- update markdowner-core dependency to use workspace reference for consistency ([518dffba42](https://github.com/RueDeRennes/mosaik/commit/518dffba42))
- simplify flex-basis and max-width calculations in WrapElement for improved readability ([0fba2a2eef](https://github.com/RueDeRennes/mosaik/commit/0fba2a2eef))
- change progress/ring/bar number properties to cssLength for simpler data binding ([d15e88f0c9](https://github.com/RueDeRennes/mosaik/commit/d15e88f0c9))
- update checkbox styles by removing unnecessary padding and border properties feat: add YouTube video embed and quote to interview markdown fix: adjust marker color in markdown styles for better visibility ([1284a2bcff](https://github.com/RueDeRennes/mosaik/commit/1284a2bcff))
- correct quotes in interview markdown and enhance closing statements ([8d0e7134ba](https://github.com/RueDeRennes/mosaik/commit/8d0e7134ba))
- correct formatting and update YouTube link in interview markdown ([2b430a99bc](https://github.com/RueDeRennes/mosaik/commit/2b430a99bc))
- **docs:** update route in command-pattern-vue.md for correct path; remove outdated mvp.requirements.md file; add comprehensive requirements documentation ([12dd351358](https://github.com/RueDeRennes/mosaik/commit/12dd351358))
- correct spelling and casing in IconsService and related files ([f4d478699e](https://github.com/RueDeRennes/mosaik/commit/f4d478699e))
- update build commands in CI workflows to use 'yarn nx run' syntax ([a38e725929](https://github.com/RueDeRennes/mosaik/commit/a38e725929))
- update description of mosaik-api in README.md for clarity ([478b4c5177](https://github.com/RueDeRennes/mosaik/commit/478b4c5177))
- restore missing languages and sites in app.json configuration ([ad5f019e46](https://github.com/RueDeRennes/mosaik/commit/ad5f019e46))
- adjust positioning for lightChain and update CookieConsentElement attributes ([708c9832bd](https://github.com/RueDeRennes/mosaik/commit/708c9832bd))
- update theme import paths to use consistent casing ([1aa18b699e](https://github.com/RueDeRennes/mosaik/commit/1aa18b699e))
- hide portal element by default in TimeBoxElementTemplate ([f5f16c13b7](https://github.com/RueDeRennes/mosaik/commit/f5f16c13b7))
- add missing newline at end of package.json ([713cb1f983](https://github.com/RueDeRennes/mosaik/commit/713cb1f983))
- simplify condition checks and remove unnecessary styles in various components ([41e6b5d8a9](https://github.com/RueDeRennes/mosaik/commit/41e6b5d8a9))
- update release script to version 0.0.28 ([baaef44d1d](https://github.com/RueDeRennes/mosaik/commit/baaef44d1d))
- update hover and selection styles for TabStrip and Tree components ([d6c90fc2bb](https://github.com/RueDeRennes/mosaik/commit/d6c90fc2bb))
- add missing newline at end of package.json ([39f2f1c578](https://github.com/RueDeRennes/mosaik/commit/39f2f1c578))
- update TabStrip and TreeItem styles to handle disabled state correctly ([ecb60798db](https://github.com/RueDeRennes/mosaik/commit/ecb60798db))
- update release version to 0.0.19 in package.json ([acccb56f76](https://github.com/RueDeRennes/mosaik/commit/acccb56f76))
- add missing newline at end of package.json ([43ce0e6a3b](https://github.com/RueDeRennes/mosaik/commit/43ce0e6a3b))
- correct spelling of 'getScrollableElement' and remove unused method ([72e17ecc7a](https://github.com/RueDeRennes/mosaik/commit/72e17ecc7a))
- correct spelling of 'success' in logSummary parameter documentation chore: update release script version to 0.0.16 chore: add 'keyhandle' to cspell words ([1a9d5e8732](https://github.com/RueDeRennes/mosaik/commit/1a9d5e8732))
- improve type handling and cleanup in Invalidable, CheckBoxGroup, ChoiceGroup, and RadioGroup components ([84753f810c](https://github.com/RueDeRennes/mosaik/commit/84753f810c))
- correct spelling of "Emitts" to "Emits" in event documentation across multiple components ([17e025c185](https://github.com/RueDeRennes/mosaik/commit/17e025c185))
- correct spelling errors in README and update release version in package.json ([922364afec](https://github.com/RueDeRennes/mosaik/commit/922364afec))
- different themes and styles ([917e55212d](https://github.com/RueDeRennes/mosaik/commit/917e55212d))
- add missing words to cSpell configuration ([933dd56139](https://github.com/RueDeRennes/mosaik/commit/933dd56139))
- correct spelling errors and improve property names in interfaces and components ([e7edf69f3e](https://github.com/RueDeRennes/mosaik/commit/e7edf69f3e))
- remove OTP prompt from publish package task and update related function signatures ([a684f8dc7e](https://github.com/RueDeRennes/mosaik/commit/a684f8dc7e))
- disable caching in project configurations and update build scripts for consistency ([0bf27cb99e](https://github.com/RueDeRennes/mosaik/commit/0bf27cb99e))
- add missing newline at end of package.json files across multiple directories ([a01c97ed2b](https://github.com/RueDeRennes/mosaik/commit/a01c97ed2b))
- correct build script command for SCSS and update build commands in project configuration ([0b243a90be](https://github.com/RueDeRennes/mosaik/commit/0b243a90be))
- update theme in index.html and enhance logging in CopyPublisherPackageJson.ts; add release targets to project.json files; remove obsolete scripts ([648a850c12](https://github.com/RueDeRennes/mosaik/commit/648a850c12))
- correct package name format in changeset configuration and add release script to package.json ([168113d104](https://github.com/RueDeRennes/mosaik/commit/168113d104))
- update package.json dependencies to use version 0.0.0 for consistency across all packages ([9b37f5626c](https://github.com/RueDeRennes/mosaik/commit/9b37f5626c))
- revert package versions to 0.0.0 for consistency across all packages ([8e39bb4e60](https://github.com/RueDeRennes/mosaik/commit/8e39bb4e60))
- update disabled state handling for various components ([bbabccda83](https://github.com/RueDeRennes/mosaik/commit/bbabccda83))
- update Angular dependencies to use caret versioning and remove unused mosaik-elements-angular-2 entry ([65f2f21abf](https://github.com/RueDeRennes/mosaik/commit/65f2f21abf))
- Refactor LitStyleTransform to remove unnecessary timing logs; update ExpanderElement styles for improved theming support ([3ca2b0d734](https://github.com/RueDeRennes/mosaik/commit/3ca2b0d734))
- Correct cache option handling across multiple executors and tasks ([bdbcb05c08](https://github.com/RueDeRennes/mosaik/commit/bdbcb05c08))
- update SKIP_LINT variable to use lowercase 'true' for consistency ([319f15f508](https://github.com/RueDeRennes/mosaik/commit/319f15f508))
- restore 'detect' configuration in project.json and update package manager version in package.json ([ff659684a6](https://github.com/RueDeRennes/mosaik/commit/ff659684a6))
- ensure form elements inherit styles correctly in formElementJoyStyle ([8c3dc71259](https://github.com/RueDeRennes/mosaik/commit/8c3dc71259))
- update theme default settings and padding values for improved consistency across card components ([11c519bf66](https://github.com/RueDeRennes/mosaik/commit/11c519bf66))
- update background color and padding values to unset for improved theme consistency across components ([fe22eaa2ca](https://github.com/RueDeRennes/mosaik/commit/fe22eaa2ca))
- update shared-style mixin to use local $name variable for consistency across components ([dc5fdb55df](https://github.com/RueDeRennes/mosaik/commit/dc5fdb55df))
- update yarn clean script to remove force option ([723efb5c42](https://github.com/RueDeRennes/mosaik/commit/723efb5c42))
- add missing React and Vue dependencies to package.json ([ee2fb6360f](https://github.com/RueDeRennes/mosaik/commit/ee2fb6360f))
- update TypeScript configurations for consistency and readability ([a74cd93fc1](https://github.com/RueDeRennes/mosaik/commit/a74cd93fc1))
- update dependencies in package.json files to latest versions ([00c4430b43](https://github.com/RueDeRennes/mosaik/commit/00c4430b43))
- update package.json to add Angular DevKit and Nx dependencies ([d86b800714](https://github.com/RueDeRennes/mosaik/commit/d86b800714))
- format json configuration files for consistency and readability ([f4e4b56db6](https://github.com/RueDeRennes/mosaik/commit/f4e4b56db6))
- update .gitignore to simplify custom entries and add Angular build artifacts ([8dbc5e0cfe](https://github.com/RueDeRennes/mosaik/commit/8dbc5e0cfe))
- add 'mosaik-ng' to package.json and clean up ToastComponent code with consistent formatting ([8871b31d8b](https://github.com/RueDeRennes/mosaik/commit/8871b31d8b))
- add Angular CLI to install script and update EventEmitter definitions for consistency across components ([d46388649e](https://github.com/RueDeRennes/mosaik/commit/d46388649e))
- remove unnecessary comments and continue-on-error flags in lint jobs for clarity ([a5cc2fbfe3](https://github.com/RueDeRennes/mosaik/commit/a5cc2fbfe3))
- simplify lint command in GitHub Actions workflow ([f6324c6be3](https://github.com/RueDeRennes/mosaik/commit/f6324c6be3))
- enable verbose linting for mosaik-elements-foundation ([9262eb8c5b](https://github.com/RueDeRennes/mosaik/commit/9262eb8c5b))
- correct SKIP_LINT environment variable to use lowercase 'false' ([e04ba33fb4](https://github.com/RueDeRennes/mosaik/commit/e04ba33fb4))
- update API endpoint to use Render URL instead of localhost ([3f3df24c15](https://github.com/RueDeRennes/mosaik/commit/3f3df24c15))
- update deployment path in GitHub Actions workflow for backend API ([4d9721e02f](https://github.com/RueDeRennes/mosaik/commit/4d9721e02f))
- remove redundant ls command from Docker build step in GitHub Actions workflow ([35074e3608](https://github.com/RueDeRennes/mosaik/commit/35074e3608))
- remove redundant npm list commands in GitHub Actions build step ([88cbee4e84](https://github.com/RueDeRennes/mosaik/commit/88cbee4e84))
- update GitHub Actions workflow to install npm packages and list global dependencies ([eda5a6b1f9](https://github.com/RueDeRennes/mosaik/commit/eda5a6b1f9))
- update build step in GitHub Actions to list global npm packages ([f53cf75b47](https://github.com/RueDeRennes/mosaik/commit/f53cf75b47))
- meta path ([7a3bdb39ef](https://github.com/RueDeRennes/mosaik/commit/7a3bdb39ef))

## 0.1.86 (2026-08-19)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.83 (2026-08-19)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.80 (2026-08-19)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.79 (2026-08-19)

### 🚀 Features

- Enhance FlowBoard component with improved scrolling and layout features ([162a92f4f8](https://github.com/RueDeRennes/mosaik/commit/162a92f4f8))

## 0.1.78 (2026-08-17)

### 🩹 Fixes

- update documentation links and definitions for TourService and TourControls ([d4d83fa4bf](https://github.com/RueDeRennes/mosaik/commit/d4d83fa4bf))

## 0.1.76 (2026-08-17)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.75 (2026-08-16)

### 🚀 Features

- **tour-controls:** add TourControlsElement with customizable styles and functionality ([2a338de689](https://github.com/RueDeRennes/mosaik/commit/2a338de689))
- **mcp:** add JSON parse error middleware and related tests ([1478fb4b4c](https://github.com/RueDeRennes/mosaik/commit/1478fb4b4c))

### 🩹 Fixes

- change overflow from scroll to auto for better responsiveness in FloatingElement styles ([a15f9da672](https://github.com/RueDeRennes/mosaik/commit/a15f9da672))

## 0.1.73 (2026-08-09)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.72 (2026-08-09)

### 🚀 Features

- **combo:** enhance styles and functionality across themes ([de2162bd87](https://github.com/RueDeRennes/mosaik/commit/de2162bd87))

## 0.1.71 (2026-08-06)

### 🚀 Features

- **chat:** update appearance and variant properties for Chat components ([c3c3f36ec5](https://github.com/RueDeRennes/mosaik/commit/c3c3f36ec5))

## 0.1.70 (2026-08-06)

### 🚀 Features

- **chat:** enhance message resizing and scrolling behavior ([6d32127ce7](https://github.com/RueDeRennes/mosaik/commit/6d32127ce7))

## 0.1.69 (2026-08-03)

### 🩹 Fixes

- **chat:** message item styles ([0aa3cc52ed](https://github.com/RueDeRennes/mosaik/commit/0aa3cc52ed))

## 0.1.68 (2026-08-02)

### 🩹 Fixes

- **prompt-box:** source focus ring offsets from theme tokens ([36fe537153](https://github.com/RueDeRennes/mosaik/commit/36fe537153))
- **chat:** stabilize rail layout and nested interactions ([637075d3ec](https://github.com/RueDeRennes/mosaik/commit/637075d3ec))

## 0.1.67 (2026-07-31)

### 🚀 Features

- **tour:** add tour behaviors ([cf7e9f15b5](https://github.com/RueDeRennes/mosaik/commit/cf7e9f15b5))
- **ai:** add chat support backend/frontend ([a939e7bbcc](https://github.com/RueDeRennes/mosaik/commit/a939e7bbcc))

## 0.1.66 (2026-07-31)

### 🚀 Features

- **tour:** add tour behaviors ([cf7e9f15b5](https://github.com/RueDeRennes/mosaik/commit/cf7e9f15b5))
- **ai:** add chat support backend/frontend ([a939e7bbcc](https://github.com/RueDeRennes/mosaik/commit/a939e7bbcc))

## 0.1.65 (2026-07-29)

### 🚀 Features

- **tour:** add more tour functionality ([a2da8233ed](https://github.com/RueDeRennes/mosaik/commit/a2da8233ed))

## 0.1.64 (2026-07-29)

### 🚀 Features

- **tour:** add more abstraction layer stuff ([571b8ab473](https://github.com/RueDeRennes/mosaik/commit/571b8ab473))

## 0.1.63 (2026-07-29)

### 🚀 Features

- **tour:** finalize tour implementation ([022ce8fbf9](https://github.com/RueDeRennes/mosaik/commit/022ce8fbf9))
- **tour:** finalize tour implementation ([d3c4f1f7c1](https://github.com/RueDeRennes/mosaik/commit/d3c4f1f7c1))

## 0.1.62 (2026-07-27)

### 🚀 Features

- **theming:** replace direct event handling with proxy output subscription ([e313c5977b](https://github.com/RueDeRennes/mosaik/commit/e313c5977b))

## 0.1.61 (2026-07-27)

### 🩹 Fixes

- **components:** ensure closed event handling respects target element ([86da3f3b56](https://github.com/RueDeRennes/mosaik/commit/86da3f3b56))

## 0.1.60 (2026-07-27)

### 🩹 Fixes

- **components:** ensure closed event handling respects target element ([86da3f3b56](https://github.com/RueDeRennes/mosaik/commit/86da3f3b56))

## 0.1.59 (2026-07-26)

### 🚀 Features

- **api:** add new interfaces and components for prompt box functionality ([1b7d17e417](https://github.com/RueDeRennes/mosaik/commit/1b7d17e417))

### 🩹 Fixes

- **dependencies:** update eslint-import-resolver-node to version 0.4.0 ([0698e6c779](https://github.com/RueDeRennes/mosaik/commit/0698e6c779))

## 0.1.58 (2026-07-25)

### 🚀 Features

- **components:** add floating label support to various input components ([31c9f86382](https://github.com/RueDeRennes/mosaik/commit/31c9f86382))
- **chat:** add ChatPromptBoxComponent and related styles ([671fe74a6e](https://github.com/RueDeRennes/mosaik/commit/671fe74a6e))

### 🩹 Fixes

- **DataTableElement:** update line numbers in documentation links ([9ee485ad09](https://github.com/RueDeRennes/mosaik/commit/9ee485ad09))

## 0.1.57 (2026-07-23)

### 🚀 Features

- **Table:** add cell height property and update related styles ([579d46a1d1](https://github.com/RueDeRennes/mosaik/commit/579d46a1d1))

## 0.1.56 (2026-07-23)

### 🚀 Features

- **DrawerContainerElement:** synchronize content margins with drawer size changes ([d2d8289ae0](https://github.com/RueDeRennes/mosaik/commit/d2d8289ae0))

## 0.1.55 (2026-07-23)

### 🩹 Fixes

- **build:** clean foundation output before compilation ([75c960748a](https://github.com/RueDeRennes/mosaik/commit/75c960748a))

## 0.1.54 (2026-07-14)

### 🚀 Features

- **drawer:** add DrawerRail component and associated styles ([8a80e20345](https://github.com/RueDeRennes/mosaik/commit/8a80e20345))

## 0.1.53 (2026-07-13)

### 🚀 Features

- **overlay:** add requestAttention and closeAttempt CloseAttempted ([54c83ed0d4](https://github.com/RueDeRennes/mosaik/commit/54c83ed0d4))

## 0.1.52 (2026-07-13)

### 🚀 Features

- **overlay:** add requestAttention and closeAttempt CloseAttempted ([27f164ec7f](https://github.com/RueDeRennes/mosaik/commit/27f164ec7f))

## 0.1.51 (2026-07-13)

### 🚀 Features

- **overlay:** add requestAttention and closeAttempt CloseAttempted ([1f35ef1a7a](https://github.com/RueDeRennes/mosaik/commit/1f35ef1a7a))

## 0.1.50 (2026-07-11)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.49 (2026-07-10)

### 🩹 Fixes

- **tab:** add scroll and overflow buttons ([54dfb62877](https://github.com/RueDeRennes/mosaik/commit/54dfb62877))

## 0.1.48 (2026-07-09)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.47 (2026-07-07)

### 🚀 Features

- **dataList:** add caption/summary slot projection ([7e107dc5f1](https://github.com/RueDeRennes/mosaik/commit/7e107dc5f1))

## 0.1.46 (2026-07-07)

### 🚀 Features

- **dataList:** add caption/summary slot projection ([89cb449e97](https://github.com/RueDeRennes/mosaik/commit/89cb449e97))
- **icon:** add IconPipe and update IconNameDirective for new components ([786e6dc8bb](https://github.com/RueDeRennes/mosaik/commit/786e6dc8bb))

## 0.1.45 (2026-07-03)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.44 (2026-07-03)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.43 (2026-07-02)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.42 (2026-07-02)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.41 (2026-07-02)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.40 (2026-07-02)

### 🚀 Features

- **list-item-group:** enhance header styling across themes ([eb9cb256ba](https://github.com/RueDeRennes/mosaik/commit/eb9cb256ba))
- **color-swatch:** add handleClick method to ColorSwatchElement class ([a148cc032d](https://github.com/RueDeRennes/mosaik/commit/a148cc032d))

## 0.1.39 (2026-06-29)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.38 (2026-06-29)

### 🚀 Features

- **color-swatch:** enhance ColorSwatch component with new properties and events ([1ca631f146](https://github.com/RueDeRennes/mosaik/commit/1ca631f146))

## 0.1.37 (2026-06-29)

### 🩹 Fixes

- **intl:** fix path bug ([91073d923e](https://github.com/RueDeRennes/mosaik/commit/91073d923e))

## 0.1.36 (2026-06-29)

### 🩹 Fixes

- dropdown ([4fe38baa1e](https://github.com/RueDeRennes/mosaik/commit/4fe38baa1e))

## 0.1.35 (2026-06-26)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.34 (2026-06-26)

### 🚀 Features

- **data-table:** add dataTableSortChanged event and related interfaces ([511727e2f9](https://github.com/RueDeRennes/mosaik/commit/511727e2f9))

## 0.1.33 (2026-06-25)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.32 (2026-06-25)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.31 (2026-06-24)

### 🚀 Features

- **toast:** enhance toast component with icon and appearance variants ([e5fe7d2071](https://github.com/RueDeRennes/mosaik/commit/e5fe7d2071))

## 0.1.30 (2026-06-24)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.29 (2026-06-24)

### 🚀 Features

- **toast:** add new positions and action ([581725264f](https://github.com/RueDeRennes/mosaik/commit/581725264f))

## 0.1.28 (2026-06-24)

### 🚀 Features

- **toast:** add new positions and action ([a8d2411bae](https://github.com/RueDeRennes/mosaik/commit/a8d2411bae))
- **toast:** add new positions and action ([87095811db](https://github.com/RueDeRennes/mosaik/commit/87095811db))

## 0.1.27 (2026-06-23)

### 🩹 Fixes

- **split-button:** floating element in dedicated portal ([ab706da4e4](https://github.com/RueDeRennes/mosaik/commit/ab706da4e4))
- **split-button:** fix focus ring on selection ([eead797e27](https://github.com/RueDeRennes/mosaik/commit/eead797e27))

## 0.1.26 (2026-06-23)

### 🩹 Fixes

- **split-button:** fix focus ring on selection ([ac396fadf9](https://github.com/RueDeRennes/mosaik/commit/ac396fadf9))

## 0.1.25 (2026-06-22)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.24 (2026-06-20)

### 🩹 Fixes

- **theme:** update shadow properties for various components in joy theme ([58749fd792](https://github.com/RueDeRennes/mosaik/commit/58749fd792))

## 0.1.23 (2026-06-20)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.22 (2026-06-20)

### 🚀 Features

- **theme:** add focus ring properties to various components ([7b2338309e](https://github.com/RueDeRennes/mosaik/commit/7b2338309e))

## 0.1.21 (2026-06-18)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.20 (2026-06-18)

### 🚀 Features

- **nx-import:** add Turborepo and Vite migration guides ([6340733088](https://github.com/RueDeRennes/mosaik/commit/6340733088))

## 0.1.19 (2026-06-18)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.18 (2026-06-18)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.17 (2026-06-15)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.16 (2026-06-15)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.15 (2026-06-14)

### 🩹 Fixes

- **states:** update hidden selector for actions to use [hidden] attribute ([3a251c1c13](https://github.com/RueDeRennes/mosaik/commit/3a251c1c13))

## 0.1.14 (2026-06-14)

### 🩹 Fixes

- **states:** update empty actions selector to hidden ([4e3bde1d9f](https://github.com/RueDeRennes/mosaik/commit/4e3bde1d9f))

## 0.1.13 (2026-06-14)

### 🩹 Fixes

- **states:** fix state styles ([44108b296e](https://github.com/RueDeRennes/mosaik/commit/44108b296e))

## 0.1.12 (2026-06-14)

### 🚀 Features

- **success-state:** add iconSize property to SuccessStateElement and related components ([15e6640e72](https://github.com/RueDeRennes/mosaik/commit/15e6640e72))

## 0.1.11 (2026-06-13)

### 🚀 Features

- **stepper:** enable text wrapping for step header, description, and hint ([d35054d5e4](https://github.com/RueDeRennes/mosaik/commit/d35054d5e4))

## 0.1.10 (2026-06-13)

### 🚀 Features

- **stepper:** enhance stepper component with slot handling and styling improvements ([b11dd29f63](https://github.com/RueDeRennes/mosaik/commit/b11dd29f63))
- **empty-state:** update slots for header and content in EmptyStateElement ([491a61d272](https://github.com/RueDeRennes/mosaik/commit/491a61d272))

## 0.1.9 (2026-06-10)

### 🚀 Features

- **scheduler:** fixed some border styles ([be0ed0d3cc](https://github.com/RueDeRennes/mosaik/commit/be0ed0d3cc))

## 0.1.8 (2026-06-10)

### 🚀 Features

- **style:** updated flowboard styles ([06c80df1a6](https://github.com/RueDeRennes/mosaik/commit/06c80df1a6))

## 0.1.7 (2026-06-10)

### 🚀 Features

- **flowboard, scheduler:** add appearance property and show tools functionality ([5e34f86cc0](https://github.com/RueDeRennes/mosaik/commit/5e34f86cc0))
- **caveman:** add caveman prompt with intensity levels and usage examples ([18f6881aad](https://github.com/RueDeRennes/mosaik/commit/18f6881aad))

## 0.1.6 (2026-06-01)

### 🚀 Features

- **chat:** add minRows and maxRows properties to ChatInputElement and update templates ([f1e2f9ea3d](https://github.com/RueDeRennes/mosaik/commit/f1e2f9ea3d))

## 0.1.5 (2026-05-29)

### 🩹 Fixes

- **drawer:** update DrawerService and DrawerPortalComponent for improved config handling ([b0856036d1](https://github.com/RueDeRennes/mosaik/commit/b0856036d1))

## 0.1.4 (2026-05-29)

### 🚀 Features

- **chat:** add actions slot and update styles for chat message components ([eacedaf22c](https://github.com/RueDeRennes/mosaik/commit/eacedaf22c))

## 0.1.3 (2026-05-29)

### 🚀 Features

- **chat:** enhance chat components with inheritance and styling improvements ([969dcf66d2](https://github.com/RueDeRennes/mosaik/commit/969dcf66d2))

## 0.1.2 (2026-05-28)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.1.1 (2026-05-24)

### 🩹 Fixes

- **chart:** ensure series and options updates are awaited ([b7152bd90a](https://github.com/RueDeRennes/mosaik/commit/b7152bd90a))

## 0.0.291 (2026-05-24)

### 🩹 Fixes

- **chart:** change pending update properties to non-readonly ([6d99698f3e](https://github.com/RueDeRennes/mosaik/commit/6d99698f3e))

## 0.0.290 (2026-05-24)

### 🚀 Features

- **chart:** add pending update handling and readiness check for ApexCharts ([ff05d10045](https://github.com/RueDeRennes/mosaik/commit/ff05d10045))

### 🩹 Fixes

- **package:** add missing newline at end of file in package.json ([b2edcaf718](https://github.com/RueDeRennes/mosaik/commit/b2edcaf718))

## 0.0.289 (2026-05-24)

### 🚀 Features

- **persona:** enhance persona component with presence slot and related styles ([f5697fb5a2](https://github.com/RueDeRennes/mosaik/commit/f5697fb5a2))
- **menu:** use Icons for menu item caret icons instead of string literals ([fa381ee1f6](https://github.com/RueDeRennes/mosaik/commit/fa381ee1f6))
- **database:** add TypedDatabase for type-safe Prisma client and services ([4c40f5dffb](https://github.com/RueDeRennes/mosaik/commit/4c40f5dffb))

## 0.0.288 (2026-05-22)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.287 (2026-05-22)

### 🚀 Features

- **project:** add documentation build command to build options ([5bbc535144](https://github.com/RueDeRennes/mosaik/commit/5bbc535144))
- **api:** add ClickableComponent and related types for mosaik-elements ([81f1a5e1be](https://github.com/RueDeRennes/mosaik/commit/81f1a5e1be))
- **calendar:** add new CSS parts and properties to CalendarItemElement and ClickableElement ([8a0584991c](https://github.com/RueDeRennes/mosaik/commit/8a0584991c))
- **calendar:** enhance Calendar and DateBox components with new props ([f85c239865](https://github.com/RueDeRennes/mosaik/commit/f85c239865))
- **nx-import:** add Turborepo and Vite migration guides ([a0faf8a2ae](https://github.com/RueDeRennes/mosaik/commit/a0faf8a2ae))

## 0.0.286 (2026-05-20)

### 🚀 Features

- **order-management:** add filter option to select components and enhance focus management ([97c9824f16](https://github.com/RueDeRennes/mosaik/commit/97c9824f16))

## 0.0.285 (2026-05-20)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.284 (2026-05-20)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.283 (2026-05-20)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.282 (2026-05-20)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.281 (2026-05-20)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.280 (2026-05-20)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.279 (2026-05-20)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.278 (2026-05-16)

### 🚀 Features

- **popup:** add sync property to PopupElement and update template bindings ([274e8e771f](https://github.com/RueDeRennes/mosaik/commit/274e8e771f))

## 0.0.277 (2026-05-15)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.276 (2026-05-15)

### 🚀 Features

- **popup:** add sync property to PopupElement and related components ([5b644a14fb](https://github.com/RueDeRennes/mosaik/commit/5b644a14fb))

## 0.0.275 (2026-05-15)

### 🩹 Fixes

- **popup:** add options for open mode and focus delegation ([f544d36064](https://github.com/RueDeRennes/mosaik/commit/f544d36064))

## 0.0.274 (2026-05-15)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.273 (2026-05-15)

### 🩹 Fixes

- **ItemDefDirective:** update line numbers in documentation for clarity ([84911e1e80](https://github.com/RueDeRennes/mosaik/commit/84911e1e80))

## 0.0.272 (2026-05-13)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.271 (2026-05-13)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.270 (2026-05-13)

### 🚀 Features

- **filebox:** add FileBox component and related styles for multiple themes ([95a1acc84f](https://github.com/RueDeRennes/mosaik/commit/95a1acc84f))

### 🩹 Fixes

- **forms:** add textOverflow property to error and hint components ([39779c12ad](https://github.com/RueDeRennes/mosaik/commit/39779c12ad))

## 0.0.269 (2026-05-12)

### 🚀 Features

- **validators:** add dateNotBefore and dateNotAfter validation functions ([cea71f1773](https://github.com/RueDeRennes/mosaik/commit/cea71f1773))

## 0.0.268 (2026-05-12)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.267 (2026-05-12)

### 🩹 Fixes

- **styles:** add 'px' unit to drawer-viewport-inset in multiple theme files ([26b16548aa](https://github.com/RueDeRennes/mosaik/commit/26b16548aa))

## 0.0.266 (2026-05-12)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.265 (2026-05-12)

### 🚀 Features

- **components:** add WheelPicker component for React, Svelte, and Vue ([b9a46f3d3e](https://github.com/RueDeRennes/mosaik/commit/b9a46f3d3e))

## 0.0.264 (2026-05-10)

### 🚀 Features

- **menu:** add formatter property to MenuItem and MenuItemGroup components ([a1e3f2f1cc](https://github.com/RueDeRennes/mosaik/commit/a1e3f2f1cc))

## 0.0.263 (2026-05-10)

### 🚀 Features

- **api:** add formatter property to MenuItem and MenuItemGroup components ([aa31380bbd](https://github.com/RueDeRennes/mosaik/commit/aa31380bbd))
- **menu:** add formatter property to MenuItem and MenuItemGroup components ([76e2cc101c](https://github.com/RueDeRennes/mosaik/commit/76e2cc101c))

## 0.0.262 (2026-05-10)

### 🚀 Features

- **tile:** add Shopify Polaris Tile Theme with Mosaik design tokens ([6a404f36d3](https://github.com/RueDeRennes/mosaik/commit/6a404f36d3))
- **menu:** add text formatting capabilities to menu item and group elements ([27052671d7](https://github.com/RueDeRennes/mosaik/commit/27052671d7))
- **list-item:** add slottable functionality and update methods ([99b0fc8657](https://github.com/RueDeRennes/mosaik/commit/99b0fc8657))

### 🩹 Fixes

- **api:** update line numbers and references in documentation for MenuItemGroupElement, ListItemElement, and MenuItemElement ([08cc5bdbf9](https://github.com/RueDeRennes/mosaik/commit/08cc5bdbf9))

## 0.0.261 (2026-05-07)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.260 (2026-05-07)

### 🚀 Features

- **overlays:** implement OverlayStackManager for better overlay handling ([2a9e5e31bf](https://github.com/RueDeRennes/mosaik/commit/2a9e5e31bf))

### 🩹 Fixes

- **api:** update line numbers in documentation for various services and components ([7ac1fab82d](https://github.com/RueDeRennes/mosaik/commit/7ac1fab82d))
- **themes:** update typography styles for card subtitle and expander header components ([3982e8ce87](https://github.com/RueDeRennes/mosaik/commit/3982e8ce87))
- **ChipGroupElement:** ensure chips are checkable based on selection mode ([acf4102874](https://github.com/RueDeRennes/mosaik/commit/acf4102874))

## 0.0.259 (2026-05-06)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.258 (2026-05-06)

### 🩹 Fixes

- **TabStripItemElement:** update background color variables for hover and selected states ([e7048274dd](https://github.com/RueDeRennes/mosaik/commit/e7048274dd))

## 0.0.257 (2026-05-06)

### 🩹 Fixes

- **docs:** update line numbers in overlay service documentation ([5c461a79b7](https://github.com/RueDeRennes/mosaik/commit/5c461a79b7))

## 0.0.256 (2026-05-04)

### 🚀 Features

- **TabStripElement:** override firstUpdated to align indicator on initial update ([c4e15cc780](https://github.com/RueDeRennes/mosaik/commit/c4e15cc780))

## 0.0.255 (2026-05-04)

### 🩹 Fixes

- **TabElements:** remove overflow property and disable indicators for tabs ([ee615e0903](https://github.com/RueDeRennes/mosaik/commit/ee615e0903))

## 0.0.254 (2026-05-03)

### 🩹 Fixes

- **MessageBoxPortal:** update definition links and add missing styles ([66b0c53414](https://github.com/RueDeRennes/mosaik/commit/66b0c53414))

## 0.0.253 (2026-05-03)

### 🚀 Features

- **MessageBox:** update MessageBoxResult values to strings and add alignment property ([22df7be730](https://github.com/RueDeRennes/mosaik/commit/22df7be730))

## 0.0.252 (2026-05-03)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.251 (2026-05-03)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.250 (2026-05-03)

### 🩹 Fixes

- **MessageBox:** update event emission and button part names for consistency ([47693311cb](https://github.com/RueDeRennes/mosaik/commit/47693311cb))

## 0.0.249 (2026-05-03)

### 🚀 Features

- **intl:** add injection tokens for various components' intl configurations ([09dd365bb2](https://github.com/RueDeRennes/mosaik/commit/09dd365bb2))

## 0.0.248 (2026-05-02)

### 🚀 Features

- **tooltip:** add TooltipDirective for customizable tooltips ([9d5891816b](https://github.com/RueDeRennes/mosaik/commit/9d5891816b))

### 🩹 Fixes

- **portal:** set position to fixed for portal host and projection elements ([cec2c9ba9c](https://github.com/RueDeRennes/mosaik/commit/cec2c9ba9c))

## 0.0.247 (2026-05-01)

### 🩹 Fixes

- **portal:** update LayerManager z-index and enable position styling ([5c7eca7aa1](https://github.com/RueDeRennes/mosaik/commit/5c7eca7aa1))

## 0.0.246 (2026-04-30)

### 🚀 Features

- **page-header:** update styles for content layout and visibility handling ([9c1674fced](https://github.com/RueDeRennes/mosaik/commit/9c1674fced))
- **page-header:** add content part with flex layout and hidden state ([0155355fa4](https://github.com/RueDeRennes/mosaik/commit/0155355fa4))
- **page-header:** add new Page Header component with templates and styles ([044eb89596](https://github.com/RueDeRennes/mosaik/commit/044eb89596))

## 0.0.245 (2026-04-30)

### 🚀 Features

- **layouts:** enhance layout components with CSS custom properties and slot adjustments ([d72d6116bb](https://github.com/RueDeRennes/mosaik/commit/d72d6116bb))
- **page-header:** enhance typography and layout for headers and subheaders ([824031a02a](https://github.com/RueDeRennes/mosaik/commit/824031a02a))

## 0.0.244 (2026-04-30)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.243 (2026-04-30)

### 🚀 Features

- **data-table:** add events for table selection and editor state changes ([eb94167184](https://github.com/RueDeRennes/mosaik/commit/eb94167184))

### 🩹 Fixes

- **api:** update event detail definitions and add value property to table components ([2610ad2acb](https://github.com/RueDeRennes/mosaik/commit/2610ad2acb))

## 0.0.242 (2026-04-30)

### 🚀 Features

- **DataTable:** add events for table selection and editor actions ([e82237349d](https://github.com/RueDeRennes/mosaik/commit/e82237349d))
- **release:** update release commands to use version from mosaik-themes package ([89c563205d](https://github.com/RueDeRennes/mosaik/commit/89c563205d))

### 🩹 Fixes

- **release:** update changelog command to use version from mosaik-themes package ([cbe25acac5](https://github.com/RueDeRennes/mosaik/commit/cbe25acac5))

## 0.0.241 (2026-04-30)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.238 (2026-04-29)

### 🚀 Features

- **breadcrumb:** enhance breadcrumb and item components with new properties and slots ([2aa158afd2](https://github.com/RueDeRennes/mosaik/commit/2aa158afd2))

## 0.0.237 (2026-04-28)

### 🚀 Features

- **tooltip:** implement TooltipDirective and ITooltipDirectiveConfig interface ([a6b0ecedfa](https://github.com/RueDeRennes/mosaik/commit/a6b0ecedfa))
- **duration-box:** add DurationBoxElementValueAccessor and related API documentation ([41c2273c72](https://github.com/RueDeRennes/mosaik/commit/41c2273c72))
- **theme:** enhance theme application with global CSS variable support ([c3822c97d3](https://github.com/RueDeRennes/mosaik/commit/c3822c97d3))

## 0.0.235 (2026-04-27)

### 🚀 Features

- **table:** add caption and summary slots to DataTableElement and TableElement ([ceedb1fcf4](https://github.com/RueDeRennes/mosaik/commit/ceedb1fcf4))

## 0.0.234 (2026-04-27)

### 🚀 Features

- **buttons:** enhance button sizes and styles for FloatingActionButton, PressButton, RepeatButton, and ToggleButton ([da69daeb64](https://github.com/RueDeRennes/mosaik/commit/da69daeb64))

## 0.0.233 (2026-04-26)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.232 (2026-04-25)

### 🚀 Features

- **secrets-vercel-sync:** implement secrets synchronization from providers to Vercel ([09906bfba4](https://github.com/RueDeRennes/mosaik/commit/09906bfba4))
- **app:** add AppView and AppViewStyle for Mosaik Studio ([2fe81e7079](https://github.com/RueDeRennes/mosaik/commit/2fe81e7079))
- **marquee:** update article card rendering and enhance TOON format integration ([4ff2f3de21](https://github.com/RueDeRennes/mosaik/commit/4ff2f3de21))
- **doppler): add command configuration for Doppler integration chore(dependencies:** update archipel platform packages to version 0.0.16 ([a88f0921d9](https://github.com/RueDeRennes/mosaik/commit/a88f0921d9))
- **auth): implement JWT enrichment and user profile management with Prisma feat(auth): add no-op MFA adapter for future use feat(auth): create Prisma-backed session and social auth adapters feat(auth): add user and user profile repositories for data access feat(auth): implement user service for authentication and profile management style(marquee:** enhance marquee styles for better layout and animation ([db7f0a5229](https://github.com/RueDeRennes/mosaik/commit/db7f0a5229))
- **deployment:** enable corepack in install script for mosaik-blog ([0be6666537](https://github.com/RueDeRennes/mosaik/commit/0be6666537))
- **blog): initialize blog app with TypeScript, Vite, and ESLint configuration feat(blog): add Vercel configuration for deployment feat(blog): implement production and development Vite configurations refactor(routes): remove DocsService and related routes from RoutesService refactor(app): update AppBar and SideNav to link to external blog URL refactor(views): remove ArticlesView and related templates refactor(controllers): clean up SideNav filter controllers by removing DocsService references chore(static-content): remove static content plugin and related interfaces chore(package:** update dependencies and scripts for blog app ([2694db201b](https://github.com/RueDeRennes/mosaik/commit/2694db201b))
- **recipes): add ActivityRingsRecipe and DeploymentStatusRecipe definitions chore(recipes): update index to include new recipe imports fix(ProjectService): add 'stored' property to project data structure refactor(ProfileView:** comment out API calls for profile updates ([58f98aa332](https://github.com/RueDeRennes/mosaik/commit/58f98aa332))
- **mcp:** implement McpThemeRegistrar for theme generation and validation tools ([75773f0d88](https://github.com/RueDeRennes/mosaik/commit/75773f0d88))
- **projects:** implement multi-page support in ProjectService and related components ([a77c6f1154](https://github.com/RueDeRennes/mosaik/commit/a77c6f1154))
- **nx-tasks): add executor for generating package documentation with TypeDoc feat(nx-tasks): create schema for generate-package-docs executor options feat(nx-tasks): implement markdown processing utilities for TypeDoc output feat(nx-tasks): add valid HTML tags for markdown processing chore(projects): configure docs-package executor for multiple libraries chore(deps:** update dependencies for TypeDoc and markdown processing ([bdac227dd0](https://github.com/RueDeRennes/mosaik/commit/bdac227dd0))
- **table-editor:** enhance column editor with scroll support and new properties ([79b1c5c7dd](https://github.com/RueDeRennes/mosaik/commit/79b1c5c7dd))
- **data-list): update itemDefinitions to use pathFn for value retrieval feat(table): enhance getColumnMetadata to include key in metadata structure feat(data-table:** filter hidden columns in getColumns and template rendering ([b6f6dfb6ea](https://github.com/RueDeRennes/mosaik/commit/b6f6dfb6ea))
- **data-list:** enhance item definition with pathFn for value retrieval ([256ebbea74](https://github.com/RueDeRennes/mosaik/commit/256ebbea74))
- **mcp:** add component suggestion feature and improve not found messages ([6e642e08b4](https://github.com/RueDeRennes/mosaik/commit/6e642e08b4))
- **themes:** enhance ThemeGenerator and ThemeObserver with detailed documentation and improvements ([e4354e9700](https://github.com/RueDeRennes/mosaik/commit/e4354e9700))
- **playground): extract and merge non-serializable values during JSON round-trip fix(components): update component options and improve data table sorting functionality refactor(segment): integrate property groups for segment and segment item elements style(table): add border-radius CSS property for table themes and improve styling chore(table): update table component methods and enhance slot handling fix(table:** ensure caption visibility and improve table column editor styles ([4a6afb969c](https://github.com/RueDeRennes/mosaik/commit/4a6afb969c))
- **table): add caption slot and allColumnsHidden property to DataTable and Table components feat(table): implement banner for hidden columns in DataTable with actions fix(table): adjust CSS for caption and banner styling across themes refactor(table:** update DataTable and TableColumnEditor components to support new properties ([fa231e0faa](https://github.com/RueDeRennes/mosaik/commit/fa231e0faa))
- **table:** implement column width tracking and editor dismissal event ([d797e5381d](https://github.com/RueDeRennes/mosaik/commit/d797e5381d))
- **portal:** enhance connectedCallback to handle content re-projection on reconnect ([88d2d8d16a](https://github.com/RueDeRennes/mosaik/commit/88d2d8d16a))
- **accessors:** add value accessors for DataList, DataTable, List, and Tree elements ([9845355730](https://github.com/RueDeRennes/mosaik/commit/9845355730))
- **table:** add titles to columns and update min-width styles for table elements ([f2af8609b6](https://github.com/RueDeRennes/mosaik/commit/f2af8609b6))
- **placeholder:** add Placeholder component with sample templates and styles ([e7424de27b](https://github.com/RueDeRennes/mosaik/commit/e7424de27b))
- **table:** add multi-sort mode and display sort index in header cells ([3cb5241ab3](https://github.com/RueDeRennes/mosaik/commit/3cb5241ab3))
- **DataTable): add column reordering functionality with drag-and-drop support feat(DataTable): implement reorderable property for columns in DataTableElement feat(DataTable): update template to support drag-and-drop for column headers feat(DataTable): enhance IDataTableColumnDefinition with reorderable attribute feat(DataTable): add reorderable property to IDataTableElementProps interface test(DataTable): add end-to-end tests for DataTable rendering and interactions test(FlowBoard): implement tests for rendering, drag-and-drop, and item interactions test(Scheduler:** create tests for rendering, navigation, event details, and interactions ([d4c2ccf9e3](https://github.com/RueDeRennes/mosaik/commit/d4c2ccf9e3))
- **portal:** initialize portal listener and observer on host connection ([0bf610c947](https://github.com/RueDeRennes/mosaik/commit/0bf610c947))
- **drag-drop:** add preview mode options and enhance drag functionality with new features ([56408f00e7](https://github.com/RueDeRennes/mosaik/commit/56408f00e7))
- **data-table:** add internationalization support and inheritance consumer controller ([ed302d741c](https://github.com/RueDeRennes/mosaik/commit/ed302d741c))
- **table:** integrate internationalization support for table components ([b04c324044](https://github.com/RueDeRennes/mosaik/commit/b04c324044))
- **table:** enhance column visibility and styling for better UX ([f2d458ccc6](https://github.com/RueDeRennes/mosaik/commit/f2d458ccc6))
- **data-table:** add custom cell and header templates with directives for data table columns ([646ed79109](https://github.com/RueDeRennes/mosaik/commit/646ed79109))
- **data-table): enhance IDataTableElementProps with new properties and update themes feat(table-header-cell): add hideable, autoSizeable, and columnChoosable props feat(icons): add new icons for column actions and update existing ones fix(data-table:** bind new properties in Svelte and Vue components ([fbb6e0d297](https://github.com/RueDeRennes/mosaik/commit/fbb6e0d297))
- **table:** implement pinable feature and enhance column management in table components ([29c66318c5](https://github.com/RueDeRennes/mosaik/commit/29c66318c5))
- **table:** add TableColumnEditor component and related events for column management ([79bc9b0414](https://github.com/RueDeRennes/mosaik/commit/79bc9b0414))
- **table:** add base classes and interfaces for table cell and row components ([2ab0b64071](https://github.com/RueDeRennes/mosaik/commit/2ab0b64071))
- **table:** add column pinning and resizing functionality with styles and events ([edfbcf86d7](https://github.com/RueDeRennes/mosaik/commit/edfbcf86d7))
- **theme:** update action bar and table components for Joy and Memphis themes ([584bd94fd7](https://github.com/RueDeRennes/mosaik/commit/584bd94fd7))
- **table:** add selection modes and types, enhance styling for selected and alternating rows ([57f5b6e71b](https://github.com/RueDeRennes/mosaik/commit/57f5b6e71b))
- **playwright-guidelines:** add Playwright test writing guidelines document ([27bf34e023](https://github.com/RueDeRennes/mosaik/commit/27bf34e023))
- **toolbox): add layers tab visibility control in StudioToolbox feat(designer): implement mobile layout constraints in DesignerView feat(dialogs): create CodeViewDialog for code generation display feat(dialogs): add EditProjectDialog for project name and icon editing feat(dialogs): implement SaveAsRecipeDialog for saving recipes style(dropdown): adjust dropdown button styles for better responsiveness style(avatar:** update avatar styles for transparent backgrounds ([f22dd9095f](https://github.com/RueDeRennes/mosaik/commit/f22dd9095f))
- **designer-canvas): add interaction mode for panning and cursor style docs(mosaik-wizard): enhance dir and lang property descriptions docs(mosaik-wrap): improve dir and lang property descriptions chore(cspell): add new words for artboard, pannable, and zoomable fix(designer-canvas): update cursor styles for interaction modes refactor(designer-canvas:** reorganize imports and improve code structure ([712697b80a](https://github.com/RueDeRennes/mosaik/commit/712697b80a))
- **designer): implement Save As Recipe dialog and functionality feat(designer): add hidden-preview class for conditional visibility fix(expander): update slot names for header and sub-header components style(playground:** correct layout spacing variable name ([5135485994](https://github.com/RueDeRennes/mosaik/commit/5135485994))
- **design:** add print styles for studio and designer views, include toggled event in components ([4125a87f02](https://github.com/RueDeRennes/mosaik/commit/4125a87f02))
- **tile:** add Tile component for React, Svelte, and Vue with theme support ([0d58f0594e](https://github.com/RueDeRennes/mosaik/commit/0d58f0594e))
- **code-editor:** add language support and themes for CodeMirror integration ([f96840827e](https://github.com/RueDeRennes/mosaik/commit/f96840827e))
- **typewriter:** add TypewriterElement component with typing animation effect ([4824c9048e](https://github.com/RueDeRennes/mosaik/commit/4824c9048e))
- **shared/mosaik-meta:** add vitest configuration and migration tools for components ([1e3c8f5f9c](https://github.com/RueDeRennes/mosaik/commit/1e3c8f5f9c))
- **styles:** add shared styles and update package dependencies ([8c63e6d5e8](https://github.com/RueDeRennes/mosaik/commit/8c63e6d5e8))
- **icons:** update fluent icons ([8d2104dfcf](https://github.com/RueDeRennes/mosaik/commit/8d2104dfcf))
- **canvas): add node reordering and duplication functionality feat(designer): implement methods to handle node reordering and duplication refactor(designer): streamline dialog handling and event listeners refactor(designer): replace button icons with action bar component docs(tree-item): update documentation for prefix and suffix slots chore(meta:** update metadata for new prefix and suffix slots ([258e029139](https://github.com/RueDeRennes/mosaik/commit/258e029139))
- **navigation:** add studio link to app bar and update translations for navigation ([06b83f8561](https://github.com/RueDeRennes/mosaik/commit/06b83f8561))
- **toolbox:** enhance toolbox item layout with responsive styles and add progress indicator recipe ([19447a1214](https://github.com/RueDeRennes/mosaik/commit/19447a1214))
- **designer): add EditProjectDialog for editing project details and icon feat(projects): implement project templates and allow project creation from templates style(projects): enhance ProjectsView with new styles and layout adjustments fix(dropdown): update dropdown button styles for better responsiveness and appearance docs(carousel:** update carousel examples to use new image component ([d5690e8dea](https://github.com/RueDeRennes/mosaik/commit/d5690e8dea))
- **studio): add Vite configuration and TypeScript support for Mosaik Studio feat(studio): implement localization plugin and update build settings feat(studio): enhance AppBarTemplate with designer navigation link feat(studio): add new hero images for landing pages fix(studio): correct HTML structure in carousel and wizard components style(studio): update background styles for designer canvas themes fix(studio): adjust split element thumb positioning in themes chore(studio:** update dependencies and add vitest configuration ([1eb81044ad](https://github.com/RueDeRennes/mosaik/commit/1eb81044ad))
- **designer): add Svelte and Vue components for designer layout and functionality feat(themes:** create tokens and JSON configurations for designer components in multiple themes ([447a42cf59](https://github.com/RueDeRennes/mosaik/commit/447a42cf59))
- **actionbar:** add ActionbarSeparatorComponent and related theme tokens ([813fe9918f](https://github.com/RueDeRennes/mosaik/commit/813fe9918f))
- **toolbar:** add custom content template and update toolbar styles for dividers ([eade1af634](https://github.com/RueDeRennes/mosaik/commit/eade1af634))
- **callout): update CalloutProcessor to support dynamic titles and content parsing feat(card): add CardProcessor for card layout with header, sub-header, and variant support test(card): implement tests for CardProcessor to validate various card formats feat(code-block): enhance CodeBlockProcessor to escape HTML and handle filename metadata test(code-block): add tests for CodeBlockProcessor to ensure proper rendering and escaping feat(details): introduce DetailsProcessor for collapsible sections with markdown support test(details): create tests for DetailsProcessor to validate details block rendering feat(split): implement SplitProcessor for creating split layouts with variant support test(split): add tests for SplitProcessor to ensure correct rendering and variant handling feat(steps): add StepsProcessor for vertical stepper layout with numbered steps test(steps): implement tests for StepsProcessor to validate step rendering and numbering feat(tab): introduce TabProcessor for tabbed content layout with variant support test(tab): add tests for TabProcessor to ensure correct tab rendering and content parsing fix(html:** improve html template function to handle null values correctly ([af7c11013b](https://github.com/RueDeRennes/mosaik/commit/af7c11013b))
- **breadcrumb:** add border style CSS custom property ([69bd49814d](https://github.com/RueDeRennes/mosaik/commit/69bd49814d))
- **toolbar, tab:** add hidden state styling and improve border property handling ([62afed09b6](https://github.com/RueDeRennes/mosaik/commit/62afed09b6))
- **routing:** implement hash and path location strategies with tests ([9d2e3ead3e](https://github.com/RueDeRennes/mosaik/commit/9d2e3ead3e))
- **logging:** add progress logging functionality and refactor animation mixins ([8f860fca28](https://github.com/RueDeRennes/mosaik/commit/8f860fca28))
- **progress-bar): enhance indeterminate state with elastic animation and style adjustments feat(progress-ring): add elastic animations for indeterminate state and improve styling fix(segment): ensure mutual exclusivity of selected items on click feat(tab-strip): implement anticipation effect for tab selection with pointer events style(breadcrumb-item): set border style to none for consistency style(checkbox): update border style to none for cleaner appearance style(choice-group): change border style to none for uniformity style(drop-zone): modify border style to dashed for visual distinction style(file-upload): adjust border style to none for a streamlined look style(radio-group): set border style to none for a cohesive design style(rating): update border style to none for aesthetic consistency fix(scheduler-event:** correct hover background color to match theme ([bc6b86cad4](https://github.com/RueDeRennes/mosaik/commit/bc6b86cad4))
- **api): define DEFAULT_GITHUB_REF for fetching content in GitHubContentService refactor(button): remove link part from button component and update templates docs(button): update documentation to reflect removal of link part in button feat(sandbox): add JSX support and update dependencies for Vite and Angular feat(getStarted): add MCP tools for framework guide and starter template fix(llms): simplify llms plugin file handling and remove unnecessary copying style(button:** clean up button themes by removing link styles ([8ac25a2f7a](https://github.com/RueDeRennes/mosaik/commit/8ac25a2f7a))
- **split-element:** add double-click functionality to expand collapsed panel ([78ff6ee475](https://github.com/RueDeRennes/mosaik/commit/78ff6ee475))
- **message-box:** enhance styling and properties for improved customization and themes ([4e097cadfd](https://github.com/RueDeRennes/mosaik/commit/4e097cadfd))
- **interaction:** enhance prompt choices with shortcuts and progress tracking ([56f96113da](https://github.com/RueDeRennes/mosaik/commit/56f96113da))
- **menu:** update styles and tokens for header padding and typography adjustments ([ecdc68a0e2](https://github.com/RueDeRennes/mosaik/commit/ecdc68a0e2))
- **buttons:** update button padding and shadow properties for improved styling ([20e12a6580](https://github.com/RueDeRennes/mosaik/commit/20e12a6580))
- **button:** add PressButton component with events and styles for multiple frameworks ([59dedda1f9](https://github.com/RueDeRennes/mosaik/commit/59dedda1f9))
- **llms:** add download button and generate full file option for llms ([6a65ea4377](https://github.com/RueDeRennes/mosaik/commit/6a65ea4377))
- **diagram): enhance node styling and graph rendering with inheritance levels feat(meta): update graph method to return class hierarchy levels refactor(graph): improve graph rendering logic and add findNodeByLabel method fix(buttons): update button samples to include ripple effect and correct properties chore(cspell:** add new words for spell checking ([d947b4cd9b](https://github.com/RueDeRennes/mosaik/commit/d947b4cd9b))

### 🩹 Fixes

- **dependencies:** update Pixel Brewery packages to version 0.0.10 ([de299ae898](https://github.com/RueDeRennes/mosaik/commit/de299ae898))
- **auth:** update dependencies and refactor GitHub authentication strategy ([174d27920f](https://github.com/RueDeRennes/mosaik/commit/174d27920f))
- **token-linter): add error handling for JSON parsing in resolver feat(data-table): suppress column change events during updates style(data-table): update editor panel styles for better layout style(data-table): unify editor panel styles across themes feat(table): add new CSS properties for column and row borders fix(table): ensure proper border handling in body and header rows refactor(table): improve column change subscription logic in TableRowBaseElement style(table-column-editor:** enhance layout and overflow handling ([0defb431bd](https://github.com/RueDeRennes/mosaik/commit/0defb431bd))
- **designer-view:** adjust dialog dimensions to use percentage for width and height ([e5ad192120](https://github.com/RueDeRennes/mosaik/commit/e5ad192120))
- **projects:** add missing newlines in project.json files and update .gitignore ([8a9cc36342](https://github.com/RueDeRennes/mosaik/commit/8a9cc36342))
- **buttons): unify background property usage and adjust opacity values fix(toast): implement progress fill animation and update styles for consistency style(toast): update CSS variables for progress fill color across themes refactor(toast:** remove intervalTick property and related logic from ToastElement ([0dbbbcd78d](https://github.com/RueDeRennes/mosaik/commit/0dbbbcd78d))
- **tokens:** update ripple duration from 200ms to 0.20s across multiple components ([dbe821713f](https://github.com/RueDeRennes/mosaik/commit/dbe821713f))

## 0.0.231 (2026-03-14)

### 🚀 Features

- **cli:** integrate CliParser for improved argument parsing and build scripts ([23b1773dce](https://github.com/RueDeRennes/mosaik/commit/23b1773dce))
- **buttons): add ripple prop to button components and related updates feat(components): implement ripple behavior in various components fix(theme:** remove duplicate ripple property in theme JSON files ([d31f695f82](https://github.com/RueDeRennes/mosaik/commit/d31f695f82))
- **McpToolRegistrar): add overview and framework guide tools with enhanced descriptions feat(package:** update dependencies across multiple packages to latest versions ([45bc8fb4f6](https://github.com/RueDeRennes/mosaik/commit/45bc8fb4f6))
- **Button, Banner:** add shadow properties and update related styles and tokens ([5d69398b19](https://github.com/RueDeRennes/mosaik/commit/5d69398b19))
- **Elevation:** add Elevation component and related templates, styles, and types ([88b9bcc7e9](https://github.com/RueDeRennes/mosaik/commit/88b9bcc7e9))
- **Expander, ToggleTip:** enhance shadow properties and add CSS custom properties ([aa5c2d557b](https://github.com/RueDeRennes/mosaik/commit/aa5c2d557b))

## 0.0.230 (2026-03-12)

### 🚀 Features

- **ToggletipComponent, TooltipComponent): add width and height props for better customization docs: add accessibility audit and component layout prompts feat(McpPromptRegistrar): implement dynamic loading of prompt templates from GitHub feat(McpResourceRegistrar): expose Mosaik component documentation as MCP resources feat(McpToolRegistrar): add tools for component search and discovery feat(DocsContentService, GitHubContentService:** implement services for fetching documentation and GitHub content ([0243729c1d](https://github.com/RueDeRennes/mosaik/commit/0243729c1d))
- **components): refactor property grid handling in TitleBar, Toolbar, Tooltip, and UpDownSpinner samples feat(components): implement property groups for TitleBar, Toolbar, and Tooltip samples fix(components): remove unused properties from TileManager and TileManagerTile components feat(observer): add PropertyObserver to track property changes in playground elements style(forms:** adjust tooltip height in form field themes ([31b07f73ee](https://github.com/RueDeRennes/mosaik/commit/31b07f73ee))
- **components:** add property grid overrides and exclusions for various sample elements ([ed0358ff62](https://github.com/RueDeRennes/mosaik/commit/ed0358ff62))
- **translations:** add French translations for theme management and UI components ([569fb63fd0](https://github.com/RueDeRennes/mosaik/commit/569fb63fd0))
- **ai:** add translation feature with request and response models ([3ccfae51a4](https://github.com/RueDeRennes/mosaik/commit/3ccfae51a4))
- **AI): refactor AI module and service to use new SDKs and streaming responses feat(AI): implement chat request handling and streaming responses in AppChatView feat(api): add MCPApiClient for handling MCP server interactions refactor(api:** replace IChatResponse with IChatRequest for chat API ([a738f435bf](https://github.com/RueDeRennes/mosaik/commit/a738f435bf))
- **icon-gallery): add load more functionality and improve icon selection logic feat(dropdown-button): update styles for better appearance in various themes fix(chat-message:** enhance shadow properties and adjust transition settings chore: export FilePickerSampleElement in main.ts ([3bab87427d](https://github.com/RueDeRennes/mosaik/commit/3bab87427d))
- **progress-ring:** update styles and properties for improved responsiveness and consistency ([519ffa9760](https://github.com/RueDeRennes/mosaik/commit/519ffa9760))
- **listing:** enhance listing and item components with size property for better customization ([76e518298e](https://github.com/RueDeRennes/mosaik/commit/76e518298e))
- **theme:** add shadow properties to various components and update shadow mixins ([6796f7e5a4](https://github.com/RueDeRennes/mosaik/commit/6796f7e5a4))
- **listing:** add size property to listing and listing item components for better customization ([2937e40c8c](https://github.com/RueDeRennes/mosaik/commit/2937e40c8c))
- **grid:** add invalidatePosition method and update grid item styles for better layout handling ([a77d83593c](https://github.com/RueDeRennes/mosaik/commit/a77d83593c))
- **timeline:** enhance timeline marker element with icon and text properties ([9f0478566e](https://github.com/RueDeRennes/mosaik/commit/9f0478566e))
- **pip:** add Memphis theme styles and components for Pip element ([21c480d37c](https://github.com/RueDeRennes/mosaik/commit/21c480d37c))
- **memphis, joy:** add new token files for listing, listing item, and markers ([b3bff07210](https://github.com/RueDeRennes/mosaik/commit/b3bff07210))
- **mcp:** add missing 'mosaik' server configuration in mcp.json and reorder imports in McpService.ts ([d1dbe3d7a8](https://github.com/RueDeRennes/mosaik/commit/d1dbe3d7a8))
- **mcp:** implement MCP module with controller and service for JSON-RPC handling ([f29a6c97ab](https://github.com/RueDeRennes/mosaik/commit/f29a6c97ab))
- **dependencies:** add vercel package and update yarn.lock ([23bbeb5285](https://github.com/RueDeRennes/mosaik/commit/23bbeb5285))
- **menu): update hover close delay for MenuItemElement to improve user experience feat(translations): add GitHub source view label to translations feat(sample): include source metadata in sample description feat(icons:** add GitHub icon to Icons resource ([66770004d9](https://github.com/RueDeRennes/mosaik/commit/66770004d9))
- **mcp:** implement MCP server with component documentation and tools ([724d288192](https://github.com/RueDeRennes/mosaik/commit/724d288192))
- **table): add inheritance context for appearance in TableElement feat(wizard): implement inheritance for disabled state in WizardElement feat(carousel): introduce CarouselDisplayMode and CarouselNavigationPosition types feat(image): add thumbnailSrc prop to ImageComponent for better image handling feat(carousel): enhance CarouselComponent with navigationPosition and displayMode props feat(wizard): extend WizardStepComponent with disabled prop for better control fix(css): ensure proper handling of CSS length values in CssLength utility style(theme:** update carousel and image tokens for better theming consistency ([2ac8e1358d](https://github.com/RueDeRennes/mosaik/commit/2ac8e1358d))
- **scramble-code:** add ScrambleCodeComponent with animation and styling ([101f5552c4](https://github.com/RueDeRennes/mosaik/commit/101f5552c4))
- **ShadowOffsetCanvas): add ShadowOffsetCanvasElement with properties and events for offset control feat(ShadowOffsetCanvas): create interfaces for ShadowOffsetCanvas properties and event details style(ShadowOffsetCanvas): implement styles for ShadowOffsetCanvasElement fix(Banner): update BannerElementTemplate to manage actions visibility correctly fix(SegmentItem:** adjust gap property to use layout space variable in Joy theme ([4b89a04440](https://github.com/RueDeRennes/mosaik/commit/4b89a04440))
- **theme): update Angular export strategy to use JoyTheme and improve theme import view feat(theme): enhance AppThemeViewTemplate with improved layout and preset selection feat(message): add custom message template with action button in MessageSample fix(theme:** correct transition properties for Banner and Message components in Joy theme ([72ee51ce58](https://github.com/RueDeRennes/mosaik/commit/72ee51ce58))

### 🩹 Fixes

- **router:** correct router link href formatting and improve fallback logic ([0e74beb027](https://github.com/RueDeRennes/mosaik/commit/0e74beb027))
- **ApiDocs:** update styles for table and code elements in API documentation layout ([2e991817d3](https://github.com/RueDeRennes/mosaik/commit/2e991817d3))
- **docs:** fix HTML @example snippets in 26 element TSDoc blocks ([c9dea12141](https://github.com/RueDeRennes/mosaik/commit/c9dea12141))
- **docs:** correct TSDoc @example HTML snippets in 25 element files ([e207fcb67b](https://github.com/RueDeRennes/mosaik/commit/e207fcb67b))
- **tsdoc:** correct @example HTML snippets in 20 Selectors element files ([b21e580aae](https://github.com/RueDeRennes/mosaik/commit/b21e580aae))
- **tsdoc:** correct @example HTML snippets in 12 element files ([469e33617f](https://github.com/RueDeRennes/mosaik/commit/469e33617f))
- correct TSDoc @example HTML snippets in 40 Primitives element files ([297e2e15e5](https://github.com/RueDeRennes/mosaik/commit/297e2e15e5))
- **docs:** correct TSDoc @example blocks in 40 Lit component files ([8a1bd700e3](https://github.com/RueDeRennes/mosaik/commit/8a1bd700e3))
- correct @example blocks in TSDoc for 25 foundation elements ([140c0f9cb0](https://github.com/RueDeRennes/mosaik/commit/140c0f9cb0))
- **dependencies:** update style-dictionary to version 5.3.3 across all packages ([5df6333874](https://github.com/RueDeRennes/mosaik/commit/5df6333874))
- **chart:** enforce strict type checking for chart element descendant retrieval ([ba6f5f4d61](https://github.com/RueDeRennes/mosaik/commit/ba6f5f4d61))
- **package:** remove zod dependency from yarn.lock ([d01b86d809](https://github.com/RueDeRennes/mosaik/commit/d01b86d809))
- **localizator-ai:** restore schema-based structured generation with vercel sdk ([d2f83bc43c](https://github.com/RueDeRennes/mosaik/commit/d2f83bc43c))
- **theme:** update shadow properties across Joy and Memphis themes for consistency ([1da029cee7](https://github.com/RueDeRennes/mosaik/commit/1da029cee7))

## 0.0.229 (2026-03-03)

### 🚀 Features

- **theme:** update theme configuration and add theme mode initialization ([ad71335818](https://github.com/RueDeRennes/mosaik/commit/ad71335818))

### 🩹 Fixes

- **config:** update languageId in cspell configuration and increment release version ([ac1296c847](https://github.com/RueDeRennes/mosaik/commit/ac1296c847))

## 0.0.228 (2026-03-02)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.227 (2026-03-02)

### 🚀 Features

- **split:** enhance ISplitElementProps and SplitElement documentation for clarity ([37dcc85adb](https://github.com/RueDeRennes/mosaik/commit/37dcc85adb))
- **split:** enhance split layout with nested templates and improved styling ([c756516a3b](https://github.com/RueDeRennes/mosaik/commit/c756516a3b))
- **split:** enhance split layout with nested templates and improved styling ([d2dd276b55](https://github.com/RueDeRennes/mosaik/commit/d2dd276b55))
- **sheet:** add SheetHeaderTextComponent and related theme tokens for cosmopolitan and joy ([9b4195fc17](https://github.com/RueDeRennes/mosaik/commit/9b4195fc17))
- **scroll:** enhance scroll component styles and transition properties across themes ([2e60528016](https://github.com/RueDeRennes/mosaik/commit/2e60528016))
- **scroll): enhance scroll component styles and functionality with new anchors and triggers feat(tooltip): add padding to tooltip component for better spacing refactor(intersection): improve intersection anchor controller to support four directions refactor(index): reorganize exports for better clarity and consistency fix(svelte): remove unused props in ScrollComponent for cleaner code fix(vue:** update props in ScrollComponent to align with latest changes ([13f2009b8b](https://github.com/RueDeRennes/mosaik/commit/13f2009b8b))
- **nx:** add skills for generating code, managing plugins, running tasks, and workspace exploration ([c394133f7c](https://github.com/RueDeRennes/mosaik/commit/c394133f7c))
- **theme:** add progress ring width to button components across themes ([939864b584](https://github.com/RueDeRennes/mosaik/commit/939864b584))
- **chip-group): remove orientation property and add wrap functionality to ChipGroupElement refactor(file-picker): remove filePicked input from FilePickerComponent refactor(chip-group): update ChipGroupComponent to use wrap instead of orientation style(chat-input): add cursor pointer on attachment hover fix(paginator): clean up unused methods in PaginatorComponent feat(opportunity-assessment:** add opportunity assessment issue template ([8e05a1233f](https://github.com/RueDeRennes/mosaik/commit/8e05a1233f))
- **paginator:** enhance paginator functionality with new properties and events ([041eb69653](https://github.com/RueDeRennes/mosaik/commit/041eb69653))
- **dot:** add DotGroup component for grouping dot elements with shared properties ([432790b5ef](https://github.com/RueDeRennes/mosaik/commit/432790b5ef))
- **dot): add fill property to Dot component and update styles for fill states feat(scheduler): rename layout to view in SchedulerEventComponent and related files feat(dot): update Dot component to support fill states and adjust themes accordingly refactor(scheduler): remove unused viewLayout prop from SchedulerComponent fix(svelte:** bind fill property in DotComponent and SchedulerEventComponent ([6e47c3675f](https://github.com/RueDeRennes/mosaik/commit/6e47c3675f))
- **DateExtensions): improve week number calculation and add new date utilities test(NumberExtensions): add unit tests for clamp function refactor(DateFormatter): remove unused specifiers and enhance formatting logic refactor(TimeFormatter:** simplify time formatting and add AM/PM designator handling ([792149b505](https://github.com/RueDeRennes/mosaik/commit/792149b505))
- **scheduler:** add new views and update scheduler component props ([4544fe12b2](https://github.com/RueDeRennes/mosaik/commit/4544fe12b2))
- **popup): enhance popup functionality with focus trap and backdrop support feat(overlay): add aria-modal attribute handling for overlays fix(storage): improve storage set method to handle string values correctly refactor(popup): streamline popup properties and remove deprecated ones style(popup:** update popup template for new properties and structure ([6de2f0ddd9](https://github.com/RueDeRennes/mosaik/commit/6de2f0ddd9))
- **theme:** add tertiary and highlight variants to Memphis and Cosmopolitan themes ([c99ce4a0cc](https://github.com/RueDeRennes/mosaik/commit/c99ce4a0cc))
- **tooltip:** enhance tooltip and floating element animations and visibility handling ([e50ab8ed4f](https://github.com/RueDeRennes/mosaik/commit/e50ab8ed4f))
- **tooltip:** add floating visibility control and animations to TooltipElement ([ac5c05d791](https://github.com/RueDeRennes/mosaik/commit/ac5c05d791))
- **tooltip:** enhance TooltipElement with anchor management and event handling ([76d561e6f4](https://github.com/RueDeRennes/mosaik/commit/76d561e6f4))
- **summary:** add SummarySampleElement with templates and playground defaults ([599c7e2c6f](https://github.com/RueDeRennes/mosaik/commit/599c7e2c6f))
- **scheduler:** update scheduler event component and styles for improved theming and accessibility ([c71bc0845f](https://github.com/RueDeRennes/mosaik/commit/c71bc0845f))
- **scheduler): add models for all-day, collected, and positioned events feat(date-extensions): enhance date utility functions for better scheduling support fix(flowboard): set tabIndex for accessibility on FlowBoardColumnItemElement style(scheduler:** update SCSS tokens for improved styling across themes ([5f31abd169](https://github.com/RueDeRennes/mosaik/commit/5f31abd169))
- **scheduler:** enhance all-day event handling and improve styling across themes ([648e2a7f0c](https://github.com/RueDeRennes/mosaik/commit/648e2a7f0c))
- **scheduler:** enhance event handling and styling across themes ([558addabe0](https://github.com/RueDeRennes/mosaik/commit/558addabe0))
- **tour): add TourComponent and TourStepComponent for guided tours feat(vue): implement TourAnchorComponent and TourStepComponent for Vue feat(scheduler): extend SchedulerComponent props for blackout and highlight features style(tour): add SCSS tokens for Tour, TourAnchor, and TourStep components chore(theming:** create theme tokens for cosmopolitan, joy, and memphis themes ([1d0c417f76](https://github.com/RueDeRennes/mosaik/commit/1d0c417f76))
- **scheduler:** rebuild grid layout and add blackout/highlight behavior ([98b7763dbb](https://github.com/RueDeRennes/mosaik/commit/98b7763dbb))
- **scheduler:** add today button and improve event handling in scheduler ([a3c97e7fc6](https://github.com/RueDeRennes/mosaik/commit/a3c97e7fc6))
- **components:** add 'new' property to components and update templates for display ([2464b44e1d](https://github.com/RueDeRennes/mosaik/commit/2464b44e1d))
- **themes:** add new scheduler components and tokens for Memphis and Joy themes ([3b0cdad390](https://github.com/RueDeRennes/mosaik/commit/3b0cdad390))
- **color-editor:** add paletteCustomChanged event and update related components ([64ffd9d69d](https://github.com/RueDeRennes/mosaik/commit/64ffd9d69d))
- **chip:** adjust max-width and margin for checkmark container styles ([1832a68440](https://github.com/RueDeRennes/mosaik/commit/1832a68440))
- **drag-drop): implement drag and drop directives with auto-discovery and cleanup feat(placeholder): add PlaceholderComponent for React, Svelte, and Vue fix(dragPlaceholder): store data as property instead of attribute fix(dragPreview): store data as property instead of attribute fix(dragHandle): simplify directive updates and attributes refactor(dropList:** enhance drop list directive with group registration and auto-discovery ([616f4c95f3](https://github.com/RueDeRennes/mosaik/commit/616f4c95f3))
- **placeholder:** implement PlaceholderElement with customizable styles and themes ([433a4d761a](https://github.com/RueDeRennes/mosaik/commit/433a4d761a))
- **dragdrop): add drag and drop functionality with new events and utilities fix(imports): update import paths for date extensions in formatters chore(tests): setup vitest with jsdom and polyfills for DOM APIs feat(flowboard): add drag start event to FlowBoard components in React, Svelte, and Vue refactor(events): remove unused addListener function from event utils chore(deps:** update dependencies and lockfile for compatibility and security ([d615c2d3cd](https://github.com/RueDeRennes/mosaik/commit/d615c2d3cd))
- **flowboard:** enable reorderable columns and items for drag-and-drop functionality ([653606b69f](https://github.com/RueDeRennes/mosaik/commit/653606b69f))
- **flowboard:** implement new FlowBoard components and update event handling ([eab85cfbb2](https://github.com/RueDeRennes/mosaik/commit/eab85cfbb2))
- **themes:** add flow board and column components for cosmopolitan, joy, and memphis themes ([811fe6f1c0](https://github.com/RueDeRennes/mosaik/commit/811fe6f1c0))
- **color-editor): add ColorEditor, ColorEditorInputs, and ColorEditorPalette components feat(color-editor): implement ColorEditorInputsComponent and ColorEditorPaletteComponent for Angular feat(react): create ColorEditor, ColorEditorInputs, and ColorEditorPalette components for React feat(vue:** add ColorEditor, ColorEditorInputs, and ColorEditorPalette components for Vue ([b8ccdfd0e2](https://github.com/RueDeRennes/mosaik/commit/b8ccdfd0e2))
- **fontEditor:** add fontEditor JSON configurations for Joy and Memphis themes ([8590f31a9c](https://github.com/RueDeRennes/mosaik/commit/8590f31a9c))
- **memphis:** add color editor components with palette, shade slider, and swatch ([356ac68f42](https://github.com/RueDeRennes/mosaik/commit/356ac68f42))
- **swipe:** add leftPanned and rightPanned events to Swipe component ([f364cb41d5](https://github.com/RueDeRennes/mosaik/commit/f364cb41d5))
- **AudioElement:** add properties for autoPlay, showControls, legend, legendPosition, ratio, muted, and loop ([ed2417b186](https://github.com/RueDeRennes/mosaik/commit/ed2417b186))
- **datebox, passwordbox:** add 'cleared' event and update documentation ([cce79081ad](https://github.com/RueDeRennes/mosaik/commit/cce79081ad))
- **DateTimeBox:** add 'cleared' event and update dropdown dimensions properties ([e226a53f85](https://github.com/RueDeRennes/mosaik/commit/e226a53f85))
- **DropDownButtonSample): add dynamic sizing properties for dropdown dimensions feat(FloatingElement): enhance dimension handling and add watchers for width/height feat(AppBarTemplate:** update dropdown dimensions for better responsiveness ([be614eba7e](https://github.com/RueDeRennes/mosaik/commit/be614eba7e))
- **autocomplete, colorbox, datebox, datetimebox, select, timebox, floating, combo:** update dropdown properties for better customization ([9ef5b4dd1c](https://github.com/RueDeRennes/mosaik/commit/9ef5b4dd1c))
- **url-state:** implement URL state service for state persistence and navigation handling ([3d15972947](https://github.com/RueDeRennes/mosaik/commit/3d15972947))
- **Select): update border color and radius variables for themes feat(Expandable): refactor ExpandableElement to use new Expandable behavior feat(Message): add MessageContent component and related events feat(Message): enhance MessageComponent with expandable properties and events feat(TextFormatter): improve Markdown parsing for links and formatting fix(Index:** reorder exports for consistency ([a88c2d8a2e](https://github.com/RueDeRennes/mosaik/commit/a88c2d8a2e))
- **code-editor:** implement scroll synchronization and enhance styling variables ([57cfd04c00](https://github.com/RueDeRennes/mosaik/commit/57cfd04c00))
- **code-editor:** add copy functionality and enhance editor features across components ([004974cf05](https://github.com/RueDeRennes/mosaik/commit/004974cf05))

### 🩹 Fixes

- **sheet:** update transform properties for smoother animations and touch event handling ([5fe9426e43](https://github.com/RueDeRennes/mosaik/commit/5fe9426e43))
- **docs:** correct createdAt and updatedAt dates in NgRx and RxJS articles ([af98b9acfa](https://github.com/RueDeRennes/mosaik/commit/af98b9acfa))
- **author:** correct spelling of Andre to André in multiple documentation files ([e924eb8206](https://github.com/RueDeRennes/mosaik/commit/e924eb8206))
- **scheduler): update time-row styles to use is-last-of-hour for border color style(scheduler): refactor SCSS for header and body components for better structure refactor(scheduler): adjust padding properties for events and header cells in tokens chore(scheduler:** enhance mixin handling in styledictionary configuration ([57b8c3f1fc](https://github.com/RueDeRennes/mosaik/commit/57b8c3f1fc))
- **project:** add missing newline at end of JSON files ([9ae562116e](https://github.com/RueDeRennes/mosaik/commit/9ae562116e))
- **theme:** rename background properties to background-color for consistency ([07433233bc](https://github.com/RueDeRennes/mosaik/commit/07433233bc))
- **components): rename event emitters for consistency and clarity refactor(events): update event detail interfaces for improved type safety feat(events:** add readonly event emitter interface for better encapsulation ([4374d5ef71](https://github.com/RueDeRennes/mosaik/commit/4374d5ef71))
- **router:** fix href handling in RouterLinkElement and RouterLinkDirective ([de729cbc15](https://github.com/RueDeRennes/mosaik/commit/de729cbc15))
- **package:** add missing newline at end of package.json ([88da605287](https://github.com/RueDeRennes/mosaik/commit/88da605287))

## 0.0.226 (2026-01-28)

### 🚀 Features

- **TextFormatter:** enhance text formatting with WhatsApp-style syntax and improve Markdown support ([3939dbe6c7](https://github.com/RueDeRennes/mosaik/commit/3939dbe6c7))
- **order-edit-drawer:** refactor form handling to use Signal Forms and improve validation ([d72d23f3f6](https://github.com/RueDeRennes/mosaik/commit/d72d23f3f6))
- **message:** update message styles for improved appearance and responsiveness ([ce524703c2](https://github.com/RueDeRennes/mosaik/commit/ce524703c2))
- **message:** refactor message component and update theme tokens for improved styling ([b5e23ce50a](https://github.com/RueDeRennes/mosaik/commit/b5e23ce50a))

### 🩹 Fixes

- **package:** add missing newline at end of file ([876a6f3b9f](https://github.com/RueDeRennes/mosaik/commit/876a6f3b9f))

## 0.0.225 (2026-01-27)

### 🚀 Features

- **message:** update message styles for improved appearance and responsiveness ([ce524703c2](https://github.com/RueDeRennes/mosaik/commit/ce524703c2))
- **message:** refactor message component and update theme tokens for improved styling ([b5e23ce50a](https://github.com/RueDeRennes/mosaik/commit/b5e23ce50a))

### 🩹 Fixes

- **package:** add missing newline at end of file ([876a6f3b9f](https://github.com/RueDeRennes/mosaik/commit/876a6f3b9f))

## 0.0.224 (2026-01-26)

### 🚀 Features

- **theme:** enhance theme generation with font source and update personas ([09d041690c](https://github.com/RueDeRennes/mosaik/commit/09d041690c))

## 0.0.223 (2026-01-25)

### 🚀 Features

- **chipbox:** enhance styles and tokens for Cosmopolitan, Joy, and Memphis themes ([d1f69a7605](https://github.com/RueDeRennes/mosaik/commit/d1f69a7605))
- **components:** implement inheritance controllers for Selectors and Tree components ([1907f30979](https://github.com/RueDeRennes/mosaik/commit/1907f30979))
- **colorbox): add colorPosition property to control preview position relative to input feat(expander): add actions part to ExpanderElement for enhanced functionality feat(theme): implement raw elevation shadow management methods in AppThemeView style(theme:** update AppThemeView styles for shadow group ([0d7f887487](https://github.com/RueDeRennes/mosaik/commit/0d7f887487))
- **translations): add font picker translations for de, en, es, and fr languages feat(shadow): implement ShadowCssConverter for parsing and formatting CSS shadows fix(theme): update ThemePresetService to include additional theme properties refactor(theme): enhance AppThemeView and AppThemeSaveView for better theme management feat(elevation:** add elevation handling in AppThemeView and ThemeService ([5d8d639087](https://github.com/RueDeRennes/mosaik/commit/5d8d639087))
- **expander:** add actions part to ExpanderElement and update styles for caret positioning ([f793577d06](https://github.com/RueDeRennes/mosaik/commit/f793577d06))
- **expander:** add stacking prop to ExpanderGroupComponent for Svelte and Vue ([f9a1ed154f](https://github.com/RueDeRennes/mosaik/commit/f9a1ed154f))
- **theme:** add theme export functionality and improve UI translations ([053124921d](https://github.com/RueDeRennes/mosaik/commit/053124921d))

### 🩹 Fixes

- **theme:** enhance AppThemeView with expert mode features and improve styling ([b43b095440](https://github.com/RueDeRennes/mosaik/commit/b43b095440))
- **styles:** correct theme import paths in SCSS files ([932cfad727](https://github.com/RueDeRennes/mosaik/commit/932cfad727))
- **docs:** standardize punctuation and formatting across multiple documentation files ([bed55885fe](https://github.com/RueDeRennes/mosaik/commit/bed55885fe))

## 0.0.222 (2026-01-21)

### 🚀 Features

- **Cdk/Utils:** add deepMerge function for merging nested objects ([958d8b1db2](https://github.com/RueDeRennes/mosaik/commit/958d8b1db2))
- **theming): update Theme2Component to include 'name' and 'global' props refactor(theming): reorganize ITheme utility functions for better clarity feat(theming): add THEME_MODES and THEME_MODES_WITH_SYSTEM constants fix(theming:** export ThemeMode and THEME_MODES from index ([5b0d68ef4a](https://github.com/RueDeRennes/mosaik/commit/5b0d68ef4a))

### 🩹 Fixes

- **theme:** update paths for Tailwind presets and add Snyk organization setting ([a2defd1849](https://github.com/RueDeRennes/mosaik/commit/a2defd1849))
- **package.json:** add missing newline at end of file ([8b6d8f8c2b](https://github.com/RueDeRennes/mosaik/commit/8b6d8f8c2b))

## 0.0.221 (2026-01-16)

### 🩹 Fixes

- **package.json:** update release version to 0.0.221 ([03ebc3de62](https://github.com/RueDeRennes/mosaik/commit/03ebc3de62))
- **package.json:** update release version to 0.0.220 ([320c50e503](https://github.com/RueDeRennes/mosaik/commit/320c50e503))

## 0.0.220 (2026-01-15)

### 🩹 Fixes

- **Sandbox.json): update theme import paths for consistency in SCSS usage fix(package.json:** increment release version to 0.0.219 ([57dce3aace](https://github.com/RueDeRennes/mosaik/commit/57dce3aace))

## 0.0.218 (2026-01-15)

### 🚀 Features

- **progress-ring:** update stroke-dasharray calculations for improved animation effects ([3d26d9e4d2](https://github.com/RueDeRennes/mosaik/commit/3d26d9e4d2))
- **meter:** enhance MeterRing and MeterBar components with new styles and properties ([026b313a58](https://github.com/RueDeRennes/mosaik/commit/026b313a58))
- **badge:** enhance styling and theming for Memphis and Joy badges ([98af94984e](https://github.com/RueDeRennes/mosaik/commit/98af94984e))
- update templates and enhance functionality across various components ([98e0c54635](https://github.com/RueDeRennes/mosaik/commit/98e0c54635))
- **SelectSample, ComboSample, SelectItemElement:** add new templates and enhance existing functionality ([d90b9f9de9](https://github.com/RueDeRennes/mosaik/commit/d90b9f9de9))

## 0.0.217 (2026-01-09)

### 🚀 Features

- **translations): add empty state message for icon gallery feat(app): update portal attached event handling in AppTemplate feat(icon-gallery): enhance IconGalleryViewPresenter with portal attachment logic feat(icon-gallery): update IconGalleryViewTemplate to handle portal attachment feat(executors): add ng-api-extractor executor for Angular API extraction feat(executors): implement ng-api-extractor task logic fix(typography): inject DOCUMENT for theme handling in TypographyDirective fix(translations): inject DOCUMENT for language setting in provideTranslations fix(portal:** reset projection after portal attachment in PortalElement ([7b75b3a8b0](https://github.com/RueDeRennes/mosaik/commit/7b75b3a8b0))
- **theme:** update transition properties and add new component tokens for Joy and Memphis themes ([904888d0f5](https://github.com/RueDeRennes/mosaik/commit/904888d0f5))
- **llms:** add llms.txt view and enhance code editor with line wrapping support ([1ab551c0a6](https://github.com/RueDeRennes/mosaik/commit/1ab551c0a6))
- **llms:** add new components and llms plugin for documentation generation ([3c4d1ad7a1](https://github.com/RueDeRennes/mosaik/commit/3c4d1ad7a1))

### 🩹 Fixes

- **package:** streamline build scripts to include alias replacement and package copying ([65637ebced](https://github.com/RueDeRennes/mosaik/commit/65637ebced))

## 0.0.216 (2026-01-04)

### 🚀 Features

- **AppElementTemplate:** add clickOutsideToClose property for mobile drawer ([d7c2040da1](https://github.com/RueDeRennes/mosaik/commit/d7c2040da1))

## 0.0.215 (2026-01-04)

### 🚀 Features

- **elements:** update descriptions for media and overlay components; adjust styles for drawer content ([daebf92a43](https://github.com/RueDeRennes/mosaik/commit/daebf92a43))
- **table:** add detailed documentation for columns and caption properties ([01dd61a084](https://github.com/RueDeRennes/mosaik/commit/01dd61a084))
- **order-management): add order management component with list and table views feat(drawer): implement full-screen mode for drawer component fix(drawer): update drawer styles for full-screen support in themes refactor(toast): adjust toast component to handle enter animations correctly chore(package:** update postbuild:dev script to include wca analysis ([0992db6a46](https://github.com/RueDeRennes/mosaik/commit/0992db6a46))
- **dialog): implement responsive dialog and drawer behaviors with breakpoints feat(drawer): add divider height property and update styles for header style(dialog): enforce centering with !important in CSS for dialog themes style(drawer:** enhance drawer themes with divider styles and improve layout ([f5bd0057c6](https://github.com/RueDeRennes/mosaik/commit/f5bd0057c6))

### 🩹 Fixes

- **resize:** standardize resize event names to camelCase and update related components ([a9cc1df0a7](https://github.com/RueDeRennes/mosaik/commit/a9cc1df0a7))

## 0.0.214 (2026-01-02)

### 🚀 Features

- **drawer:** update DrawerElement styles for consistent line thickness across positions ([2e8ac33b49](https://github.com/RueDeRennes/mosaik/commit/2e8ac33b49))
- **drawer:** enhance DrawerElement with new slot definitions and update properties ([df154611aa](https://github.com/RueDeRennes/mosaik/commit/df154611aa))

## 0.0.212 (2026-01-02)

### 🚀 Features

- **auth:** add toast overlay button and functionality ([2ba7af0f31](https://github.com/RueDeRennes/mosaik/commit/2ba7af0f31))
- **resize-thumb:** add ResizeDirection enum and update styles for ResizeThumb component ([a114f04b1b](https://github.com/RueDeRennes/mosaik/commit/a114f04b1b))
- **resize-thumb:** add ResizeThumb component with themes and sample templates ([f02814acad](https://github.com/RueDeRennes/mosaik/commit/f02814acad))
- **resize-thumb:** add isResizing property and update related components ([e36a8dfacc](https://github.com/RueDeRennes/mosaik/commit/e36a8dfacc))
- **instructions:** enhance coding standards with access modifiers and service-layer guidelines ([7bad04f186](https://github.com/RueDeRennes/mosaik/commit/7bad04f186))
- **drawer:** add DrawerActions component and related styles ([0694277f87](https://github.com/RueDeRennes/mosaik/commit/0694277f87))
- **drawer:** implement drawer stacking behavior and update styles for themes ([036f98144e](https://github.com/RueDeRennes/mosaik/commit/036f98144e))

## 0.0.211 (2025-12-31)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.210 (2025-12-31)

### 🚀 Features

- **dialog:** refactor dialog components and update routing for overlays ([036f4626d8](https://github.com/RueDeRennes/mosaik/commit/036f4626d8))

## 0.0.209 (2025-12-30)

### 🚀 Features

- **overlays): replace BottomSheet with Sheet component in React, Svelte, and Vue refactor(overlays): create Sheet context and hooks for managing sheet functionality delete(overlays): remove BottomSheet implementation from Svelte and Vue style(themes:** add new tokens and styles for Sheet component in various themes ([9b31d53a48](https://github.com/RueDeRennes/mosaik/commit/9b31d53a48))
- **drawer:** update drawer position and add new drawer options for better usability ([014f64793b](https://github.com/RueDeRennes/mosaik/commit/014f64793b))
- **drawer:** add DrawerFooterElement with styles and templates for themes ([112cf9ecc4](https://github.com/RueDeRennes/mosaik/commit/112cf9ecc4))
- **navigation:** update routes and translations for Icons and remove Grid Generator ([65fbd99200](https://github.com/RueDeRennes/mosaik/commit/65fbd99200))
- **theme:** add background color tokens for Cosmopolitan, Joy, and Memphis themes ([7221acee86](https://github.com/RueDeRennes/mosaik/commit/7221acee86))
- **dialogs:** enhance AppThemeView and ColorBoxElement with improved color handling ([96d3d671a6](https://github.com/RueDeRennes/mosaik/commit/96d3d671a6))
- **menu:** add menuMode property and handle pointer leave for submenu interactions ([ac89155f01](https://github.com/RueDeRennes/mosaik/commit/ac89155f01))
- **dialogs:** update subHeader text for theme dialogs and improve drawer usage ([0283e96f0f](https://github.com/RueDeRennes/mosaik/commit/0283e96f0f))
- **projection:** enhance DrawerService and MenuItemElement with portal and projection capabilities ([9181efdc8f](https://github.com/RueDeRennes/mosaik/commit/9181efdc8f))
- **menu:** add hierarchical submenus and context menu templates with new submenu modes ([72df10b4a9](https://github.com/RueDeRennes/mosaik/commit/72df10b4a9))
- **overlays:** add escape key handling and backdrop click functionality to overlays ([abd104d27e](https://github.com/RueDeRennes/mosaik/commit/abd104d27e))
- **app): replace DialogService with DrawerService for AppSettingsView and update styles feat(app): enhance AppBar and AppThemeView with enableStack property style(drawer): add width and height to transition properties for Joy and Memphis themes style(backdrop:** add blur property to backdrop styles for Cosmopolitan, Joy, and Memphis themes ([2da9c43e8d](https://github.com/RueDeRennes/mosaik/commit/2da9c43e8d))
- **cdk:** implement toast, dialog, drawer, bottom sheet, and message box components for Svelte and Vue ([85e924ee20](https://github.com/RueDeRennes/mosaik/commit/85e924ee20))
- **drawer:** enhance drawer header and content structure with new components ([9d587b01c3](https://github.com/RueDeRennes/mosaik/commit/9d587b01c3))
- **drawer): add DrawerHeader, DrawerHeaderText, and DrawerHeaderSubText components feat(vue): implement DrawerHeader, DrawerHeaderText, and DrawerHeaderSubText for Vue feat(theme): create tokens for DrawerHeader, DrawerHeaderText, and DrawerHeaderSubText in Cosmopolitan, Joy, and Memphis themes fix(autoComplete): update props and methods in AutoCompleteBoxComponent fix(drawer:** enhance DrawerComponent methods and props for better functionality ([a013fd74f5](https://github.com/RueDeRennes/mosaik/commit/a013fd74f5))
- **autocomplete:** enhance AutoCompleteBox with filter input and search placeholder ([3807f82a0d](https://github.com/RueDeRennes/mosaik/commit/3807f82a0d))
- **repeat-button:** refactor event handling to use pointer events for improved responsiveness ([675ba53871](https://github.com/RueDeRennes/mosaik/commit/675ba53871))
- **autocomplete:** add itemSelected event and enhance AutoCompleteBox functionality ([63334f2c73](https://github.com/RueDeRennes/mosaik/commit/63334f2c73))
- **autocomplete:** enhance AutoCompleteBox styles and behaviors with focus ring support ([c897e3f834](https://github.com/RueDeRennes/mosaik/commit/c897e3f834))
- **memphis:** update color tokens for improved theme consistency and accessibility ([5ee21045d0](https://github.com/RueDeRennes/mosaik/commit/5ee21045d0))
- **theme): add AppThemeView component for theme customization feat(style): create AppThemeView styles and template refactor(commands): remove Command interface and implementation fix(expander): adjust styles for first and last expander items fix(drawer): ensure toolbar flex behavior in drawer component fix(color-picker:** update color swatch border-radius to use variable ([7d0dff4b67](https://github.com/RueDeRennes/mosaik/commit/7d0dff4b67))
- **theme:** add surface and selection variants to Cosmopolitan and Memphis themes ([6005459409](https://github.com/RueDeRennes/mosaik/commit/6005459409))
- **theme:** update background color variables to use surface color for Joy theme components ([98edfeb298](https://github.com/RueDeRennes/mosaik/commit/98edfeb298))
- **region:** enhance Region and RegionElement to support default active view rendering ([626095efee](https://github.com/RueDeRennes/mosaik/commit/626095efee))
- **region:** add Region and RegionView components with themes and properties ([16118756b2](https://github.com/RueDeRennes/mosaik/commit/16118756b2))
- **region:** add ViewElement and RegionElement components with demo and themes ([2c4b84c418](https://github.com/RueDeRennes/mosaik/commit/2c4b84c418))
- **selectors): enhance property groups for List, Menu, Tab, and Tree components feat(selectors): add nested structure to Menu and Wizard templates fix(selectors:** improve styling and layout for DataTable themes docs: add article on Controller Pattern in Angular for better component logic management ([aac9fe4d9e](https://github.com/RueDeRennes/mosaik/commit/aac9fe4d9e))
- **icons): update upload icon and add reset icon feat(translations): add reset related translations in de, en, es, fr feat(sampleBase): implement property reset functionality in SampleBaseElement fix(formField): replace TooltipElement with ToggleTipElement and update styles style(formField:** refactor styles for better layout and consistency ([25accc30bf](https://github.com/RueDeRennes/mosaik/commit/25accc30bf))
- **components): refactor TitleBar, Toolbar, Tooltip, and UpDownSpinner samples to use templates style(timeline): enhance horizontal timeline item styles for better layout and alignment fix(main): update exports for IndicatorSample and TreeMap components chore(cspell:** add xaxis and yaxis to spell check words ([442d952d1a](https://github.com/RueDeRennes/mosaik/commit/442d952d1a))
- **timeline:** add custom templates for timeline component with styled content and markers ([eeb6506523](https://github.com/RueDeRennes/mosaik/commit/eeb6506523))
- **timeline:** add timeline components for React, Svelte, and Vue with styles ([1c0375d250](https://github.com/RueDeRennes/mosaik/commit/1c0375d250))

### 🩹 Fixes

- **UpDownSpinnerSample): ensure value updates correctly on spin events fix(FeedbackDetailView): use mutable feedback object for comment and vote updates fix(FeedbackDetailViewTemplate): prevent deleteComment call if feedback ID is undefined refactor(SupportView): override render method for better clarity fix(AppViewTemplate): handle icon assignment safely with fallback fix(NewsletterViewTemplate): ensure newsletter submission works correctly fix(EventsViewTemplate): improve handling of calendar location and link checks fix(ProfileViewTemplate): ensure bio input hint updates correctly fix(ColorPaletteBuilderView): ensure palette generation uses correct types fix(GridGeneratorView): instantiate view model correctly and expose it refactor(GridGeneratorViewTemplate): simplify template function signature fix(IconGalleryViewTemplate): ensure mode selection works correctly with types chore(tsconfig): change module resolution to Bundler for better compatibility chore(vite.config): add vite-plugin-checker for TypeScript checks chore(vite.config.production): include vite-plugin-checker for production builds feat(Controller): add IControllerHostRef and IReactiveController interfaces feat(Controller): implement useController for managing reactive controllers chore(ControllerHost): remove deprecated ControllerHost implementation feat(GlobalDomRef:** create global DOM reference for better testability ([9da5337bfb](https://github.com/RueDeRennes/mosaik/commit/9da5337bfb))

## 0.0.208 (2025-12-13)

### 🚀 Features

- update component properties and descriptions for better clarity and functionality ([5d4069bff7](https://github.com/RueDeRennes/mosaik/commit/5d4069bff7))

## 0.0.207 (2025-12-13)

### 🚀 Features

- **stepper:** add icon property and update styles for stepper components ([8a6aafbba8](https://github.com/RueDeRennes/mosaik/commit/8a6aafbba8))
- **split): add min and max properties for size constraints in SplitElement feat(stepper): introduce isActive property in StepperItemElement refactor(split): update SplitElement to use CssLength for position, min, and max fix(split): adjust CSS properties and templates to reflect new min/max constraints style(split:** remove deprecated CSS variables for min and max in themes ([0478bec83f](https://github.com/RueDeRennes/mosaik/commit/0478bec83f))
- **stepper): add Cosmopolitan, Joy, and Memphis themes for Stepper and StepperItem components feat(stepper): implement React and Svelte components for Stepper and StepperItem feat(stepper): create Vue components for Stepper and StepperItem fix(wizard): update event detail interfaces for active step changes style(stepper:** define token styles for various themes in SCSS ([f3922024d6](https://github.com/RueDeRennes/mosaik/commit/f3922024d6))
- add stepper tokens for all themes ([7871bba3fd](https://github.com/RueDeRennes/mosaik/commit/7871bba3fd))
- **tailwind:** implement Tailwind v4 config generation and update package scripts ([db31430aaf](https://github.com/RueDeRennes/mosaik/commit/db31430aaf))

### 🩹 Fixes

- **tooltip:** handle null values for body and floating elements, improve event handling ([93d88722ee](https://github.com/RueDeRennes/mosaik/commit/93d88722ee))
- **stepper:** improve stepper functionality and styles, add navigation directives ([d53c7333a7](https://github.com/RueDeRennes/mosaik/commit/d53c7333a7))
- **stepper:** update properties and styles for Stepper themes and components ([5f66855a75](https://github.com/RueDeRennes/mosaik/commit/5f66855a75))
- **stepper:** update stepper item properties to use description and hint ([8f8d17acb8](https://github.com/RueDeRennes/mosaik/commit/8f8d17acb8))

## 0.0.206 (2025-12-09)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.205 (2025-12-07)

### 🩹 Fixes

- **buttons): update stack-gap variable usage in FloatingActionButton, RepeatButton, SplitButton, ToggleButton themes fix(card): update stack-gap variable usage in CardActions theme fix(expander): update stack-gap variable usage in Expander theme fix(comment): update stack-gap variable usage in Comment theme fix(dialog): update stack-gap variable usage in DialogActions theme fix(segment): update stack-gap variable usage in SegmentItem theme fix(tab-strip): update stack-gap variable usage in TabStripItem theme fix(states): update stack-gap variable usage in Busy, Empty, Error, and Success state themes chore(package:** bump version to 0.0.204 in package.json ([878a490c1e](https://github.com/RueDeRennes/mosaik/commit/878a490c1e))

## 0.0.204 (2025-12-07)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.203 (2025-12-06)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.202 (2025-12-06)

### 🚀 Features

- **error, hint:** add textOverflow property to Error and Hint components ([131d8bec1e](https://github.com/RueDeRennes/mosaik/commit/131d8bec1e))

## 0.0.201 (2025-12-05)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.200 (2025-12-05)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.199 (2025-12-05)

### 🩹 Fixes

- **package:** add missing newline at end of file ([e7bbe4e7c1](https://github.com/RueDeRennes/mosaik/commit/e7bbe4e7c1))

## 0.0.198 (2025-12-05)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.197 (2025-12-05)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.196 (2025-12-05)

### 🚀 Features

- **event-hub:** add Event Hub pattern implementation for Angular 2025 ([88dc4f7404](https://github.com/RueDeRennes/mosaik/commit/88dc4f7404))

### 🩹 Fixes

- **keywords:** add Event Bus and Message Bus to event hub documentation ([69cafcf76f](https://github.com/RueDeRennes/mosaik/commit/69cafcf76f))

## 0.0.195 (2025-12-03)

### 🩹 Fixes

- **package:** add missing newline at end of file in package.json ([a9bf15349b](https://github.com/RueDeRennes/mosaik/commit/a9bf15349b))

## 0.0.194 (2025-12-03)

### 🩹 Fixes

- **Cdk:** export FormFieldStatusDirective alongside FORM_STATUS_HOST from FormStatusDirective ([c8521cd4ff](https://github.com/RueDeRennes/mosaik/commit/c8521cd4ff))

## 0.0.193 (2025-12-03)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.192 (2025-12-03)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.191 (2025-12-03)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.190 (2025-12-02)

### 🩹 Fixes

- **choice-group:** add flex property to root part for improved layout consistency ([8bd80ed40b](https://github.com/RueDeRennes/mosaik/commit/8bd80ed40b))

## 0.0.189 (2025-12-02)

### 🩹 Fixes

- **choice-group:** add flex property to root part for better layout ([51e2a1a9be](https://github.com/RueDeRennes/mosaik/commit/51e2a1a9be))

## 0.0.188 (2025-12-02)

### 🚀 Features

- **directives:** update FormFieldDirective to improve error handling and usage documentation ([7c07bb43fd](https://github.com/RueDeRennes/mosaik/commit/7c07bb43fd))

## 0.0.187 (2025-12-02)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.186 (2025-12-02)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.185 (2025-12-02)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.184 (2025-12-02)

### 🚀 Features

- **eslint:** enhance ESLint configuration and add .eslintignore file ([4b3deb5566](https://github.com/RueDeRennes/mosaik/commit/4b3deb5566))

## 0.0.183 (2025-11-30)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.182 (2025-11-30)

### 🚀 Features

- **themes:** refactor theme generator strategies and update build process ([55859a854f](https://github.com/RueDeRennes/mosaik/commit/55859a854f))

## 0.0.181 (2025-11-30)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.180 (2025-11-30)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.179 (2025-11-29)

### 🚀 Features

- **tailwind): add Material and Memphis presets for Tailwind CSS themes fix(tokens): correct typo in headline2 key in joy and memphis theme JSON files chore(tsconfig:** update TypeScript configuration to include Tailwind files ([0ae3d28053](https://github.com/RueDeRennes/mosaik/commit/0ae3d28053))

## 0.0.178 (2025-11-29)

### 🩹 Fixes

- **package:** add missing newline at end of file ([0fc5a107d6](https://github.com/RueDeRennes/mosaik/commit/0fc5a107d6))

## 0.0.177 (2025-11-29)

### 🩹 Fixes

- **release:** update release script version to 0.0.177 ([1895016b0a](https://github.com/RueDeRennes/mosaik/commit/1895016b0a))

## 0.0.176 (2025-11-29)

### 🚀 Features

- add oklch color transform and update dependencies in style-dictionary plugins ([40063afe0a](https://github.com/RueDeRennes/mosaik/commit/40063afe0a))

### 🩹 Fixes

- add missing newline at end of JSON files ([60b2109dd0](https://github.com/RueDeRennes/mosaik/commit/60b2109dd0))

## 0.0.175 (2025-11-28)

### 🩹 Fixes

- add missing newline at end of package.json ([b00046e27b](https://github.com/RueDeRennes/mosaik/commit/b00046e27b))

## 0.0.174 (2025-11-28)

### 🚀 Features

- **mvp:** implement View and ViewPresenter architecture with interfaces and controllers ([17d2a3cc6b](https://github.com/RueDeRennes/mosaik/commit/17d2a3cc6b))
- **tailwind:** add Joy Tailwind plugin with configuration options and token exposure ([72bbf954a8](https://github.com/RueDeRennes/mosaik/commit/72bbf954a8))
- **svg:** add SVG to path conversion utility ([f2f74da782](https://github.com/RueDeRennes/mosaik/commit/f2f74da782))

### 🩹 Fixes

- remove unused elevation2 light token and update release version in package.json ([9a63ade438](https://github.com/RueDeRennes/mosaik/commit/9a63ade438))
- remove unused dependency 'element-to-path' from yarn.lock ([df86dc94de](https://github.com/RueDeRennes/mosaik/commit/df86dc94de))
- add newline at end of package.json ([73db364d3c](https://github.com/RueDeRennes/mosaik/commit/73db364d3c))

## 0.0.173 (2025-11-26)

### 🚀 Features

- Enhance Color Palette Builder and Theme Generation ([7b7a885f6a](https://github.com/RueDeRennes/mosaik/commit/7b7a885f6a))

## 0.0.172 (2025-11-21)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.171 (2025-11-21)

### 🚀 Features

- add FlipToDirective for flipping components and ReactiveFormValidator for form validation ([ba607ccc49](https://github.com/RueDeRennes/mosaik/commit/ba607ccc49))
- **memphis:** theme choices, selects, and combos ([53f092fa83](https://github.com/RueDeRennes/mosaik/commit/53f092fa83))
- **avatar:** enhance chat message avatar styles with theme-specific properties ([4e85d98a64](https://github.com/RueDeRennes/mosaik/commit/4e85d98a64))

### 🩹 Fixes

- **release:** update release version to 0.0.170 ([089a682d6f](https://github.com/RueDeRennes/mosaik/commit/089a682d6f))

## 0.0.170 (2025-10-28)

### 🚀 Features

- **chat:** enhance avatar styles and properties across themes ([3cf45d0955](https://github.com/RueDeRennes/mosaik/commit/3cf45d0955))

### 🩹 Fixes

- **release:** update release version to 0.0.169 ([77c58d1eea](https://github.com/RueDeRennes/mosaik/commit/77c58d1eea))

## 0.0.169 (2025-10-28)

### 🚀 Features

- **chat:** add author property to chat messages and update templates ([6e22d26e1d](https://github.com/RueDeRennes/mosaik/commit/6e22d26e1d))

### 🩹 Fixes

- **release:** update release version to 0.0.168 ([1434c7a9fd](https://github.com/RueDeRennes/mosaik/commit/1434c7a9fd))

## 0.0.168 (2025-10-26)

### 🩹 Fixes

- **ChipElementTemplate:** update is-flipped property to use side attribute for better clarity ([fa94cf7a00](https://github.com/RueDeRennes/mosaik/commit/fa94cf7a00))

## 0.0.167 (2025-10-26)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.166 (2025-10-26)

### 🚀 Features

- **List:** add inset property and update styles for flexible layout ([3dc4e28f0d](https://github.com/RueDeRennes/mosaik/commit/3dc4e28f0d))

### 🩹 Fixes

- **package:** add missing newline at end of file ([4aa435a5b6](https://github.com/RueDeRennes/mosaik/commit/4aa435a5b6))

## 0.0.165 (2025-10-24)

### 🚀 Features

- **List:** add orientation property and update styles for flexible layout ([44aa6a89cb](https://github.com/RueDeRennes/mosaik/commit/44aa6a89cb))

## 0.0.164 (2025-10-24)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.163 (2025-10-22)

### 🚀 Features

- enhance ChatElement with additional slots for improved functionality ([1dfc91b4ea](https://github.com/RueDeRennes/mosaik/commit/1dfc91b4ea))
- add DateAgo and TimeAgo pipes, directives, and services for time-based formatting ([40c3e551ba](https://github.com/RueDeRennes/mosaik/commit/40c3e551ba))

## 0.0.162 (2025-10-22)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.161 (2025-10-22)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.160 (2025-10-21)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.159 (2025-10-21)

### 🩹 Fixes

- correct typo in TODO comment in TemplateType.ts and adjust formatting in ModelKind.ts and ModelKindRegistry.ts ([c8bcbb7a65](https://github.com/RueDeRennes/mosaik/commit/c8bcbb7a65))

## 0.0.158 (2025-10-21)

### 🚀 Features

- add options for ListElement and update release version to 0.0.157 ([0a28367587](https://github.com/RueDeRennes/mosaik/commit/0a28367587))

### 🩹 Fixes

- correct typos in interface comments and update default configuration values ([dc58b1a35c](https://github.com/RueDeRennes/mosaik/commit/dc58b1a35c))
- remove outline from list element styles for improved appearance ([ff19b36c81](https://github.com/RueDeRennes/mosaik/commit/ff19b36c81))

## 0.0.157 (2025-10-19)

### 🩹 Fixes

- add newline at end of file in package.json ([d0e684e967](https://github.com/RueDeRennes/mosaik/commit/d0e684e967))

## 0.0.156 (2025-10-17)

### 🩹 Fixes

- update release version to 0.0.156 in package.json ([323d1588b7](https://github.com/RueDeRennes/mosaik/commit/323d1588b7))
- update release version to 0.0.155 in package.json ([1f1946594c](https://github.com/RueDeRennes/mosaik/commit/1f1946594c))

## 0.0.155 (2025-10-16)

### 🩹 Fixes

- update release version to 0.0.154 in package.json ([d894b6b4a1](https://github.com/RueDeRennes/mosaik/commit/d894b6b4a1))

## 0.0.154 (2025-10-16)

### 🩹 Fixes

- remove deprecated -webkit-backdrop-filter from transition properties in theme styles refactor: simplify AutoCompleteBox styles for better maintainability chore: update release script to version 0.0.153 ([a7af7fe240](https://github.com/RueDeRennes/mosaik/commit/a7af7fe240))

## 0.0.153 (2025-10-15)

### 🩹 Fixes

- remove deprecated -webkit-backdrop-filter from transition properties in theme styles refactor: simplify AutoCompleteBox styles for better maintainability chore: update release script to version 0.0.153 ([a7af7fe240](https://github.com/RueDeRennes/mosaik/commit/a7af7fe240))

## 0.0.152 (2025-10-15)

### 🚀 Features

- Update AutoCompleteBox component to include new input properties and methods ([70b4f5462e](https://github.com/RueDeRennes/mosaik/commit/70b4f5462e))
- add AutoCompleteBox component and update related samples and interfaces ([6778955ecf](https://github.com/RueDeRennes/mosaik/commit/6778955ecf))
- add AutoCompleteBox component with internationalization support ([ab0b6ddfaa](https://github.com/RueDeRennes/mosaik/commit/ab0b6ddfaa))

## 0.0.151 (2025-09-29)

### 🚀 Features

- add wrap property to StackElement for flexible layout handling ([181634aa81](https://github.com/RueDeRennes/mosaik/commit/181634aa81))

## 0.0.150 (2025-09-29)

### 🩹 Fixes

- update release script version to 0.0.149 and adjust enum handling in modelClass function ([826e15bdf2](https://github.com/RueDeRennes/mosaik/commit/826e15bdf2))

## 0.0.149 (2025-09-25)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.148 (2025-09-25)

### 🚀 Features

- **calendar:** add support for multiple calendar sheets ([445b84be1b](https://github.com/RueDeRennes/mosaik/commit/445b84be1b))
- **calendar:** enhance range selection and styling ([fdb6cb56db](https://github.com/RueDeRennes/mosaik/commit/fdb6cb56db))

## 0.0.147 (2025-09-25)

### 🩹 Fixes

- correct spelling of 'schema' in OpenApiParser logging ([1a75e6c62b](https://github.com/RueDeRennes/mosaik/commit/1a75e6c62b))

## 0.0.146 (2025-09-16)

### 🩹 Fixes

- update release script version to 0.0.145 and enhance logging output in TemplateBuilder ([c77501d259](https://github.com/RueDeRennes/mosaik/commit/c77501d259))

## 0.0.145 (2025-09-16)

### 🩹 Fixes

- update release version to 0.0.144 and improve type annotations in TemplateEngine ([c99a28f6b6](https://github.com/RueDeRennes/mosaik/commit/c99a28f6b6))

## 0.0.144 (2025-09-16)

### 🩹 Fixes

- correct spelling of 'preferred' in TemplateBuilder and related files ([5862673dc4](https://github.com/RueDeRennes/mosaik/commit/5862673dc4))

## 0.0.143 (2025-09-16)

### 🩹 Fixes

- update release script version to 0.0.142 ([b558893804](https://github.com/RueDeRennes/mosaik/commit/b558893804))

## 0.0.142 (2025-09-15)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.141 (2025-09-14)

### 🚀 Features

- add comprehensive guidelines for code quality checks and testing standards across backend, frontend, and testing instructions ([9d9bcf13f9](https://github.com/RueDeRennes/mosaik/commit/9d9bcf13f9))

### 🩹 Fixes

- correct base component property references in AnchorElement.Joy.scss ([8f7ae019cf](https://github.com/RueDeRennes/mosaik/commit/8f7ae019cf))
- add missing newline at end of package.json ([3309d1ee97](https://github.com/RueDeRennes/mosaik/commit/3309d1ee97))

## 0.0.140 (2025-09-10)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.139 (2025-09-08)

### 🚀 Features

- add reorderable and resizable properties to TileListItemElement and update related styles ([84672caf3a](https://github.com/RueDeRennes/mosaik/commit/84672caf3a))

## 0.0.138 (2025-09-07)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.137 (2025-09-05)

### 🚀 Features

- **build:** add environment variable sanitization to build summary ([b2f1e0830e](https://github.com/RueDeRennes/mosaik/commit/b2f1e0830e))
- **dropzone:** enhance DropZone component with new styles and states ([0d6349f9ce](https://github.com/RueDeRennes/mosaik/commit/0d6349f9ce))

### 🩹 Fixes

- resolve split, searchbox and pinbox issues ([8417d2d5bf](https://github.com/RueDeRennes/mosaik/commit/8417d2d5bf))

## 0.0.136 (2025-09-04)

### 🚀 Features

- add comprehensive coding standards for backend, frontend, and testing ([3987d97056](https://github.com/RueDeRennes/mosaik/commit/3987d97056))
- integrate build info into AppElement and update template to display build metadata ([afff580948](https://github.com/RueDeRennes/mosaik/commit/afff580948))

### 🩹 Fixes

- standardize padding-top property in Banner styles and templates ([377e883410](https://github.com/RueDeRennes/mosaik/commit/377e883410))

## 0.0.135 (2025-09-03)

### 🚀 Features

- add build info plugin for Vite to collect and expose build metadata ([888ea8b254](https://github.com/RueDeRennes/mosaik/commit/888ea8b254))

### 🩹 Fixes

- enhance build info logging format and update release version to 0.0.135 ([61b1c86643](https://github.com/RueDeRennes/mosaik/commit/61b1c86643))
- add missing newline at end of package.json ([cf3b9a3f21](https://github.com/RueDeRennes/mosaik/commit/cf3b9a3f21))

## 0.0.134 (2025-09-01)

### 🚀 Features

- Add ThemeService for managing theme application and properties ([a3cb9be861](https://github.com/RueDeRennes/mosaik/commit/a3cb9be861))
- Add Audio Component and related functionality ([a66b67efb6](https://github.com/RueDeRennes/mosaik/commit/a66b67efb6))
- Update chat and map components with new styles and properties; add Thumbnail element themes ([a011c6c44f](https://github.com/RueDeRennes/mosaik/commit/a011c6c44f))
- Add new Map and Thumbnail components with Cosmopolitan, Joy, and Memphis themes ([5142fee885](https://github.com/RueDeRennes/mosaik/commit/5142fee885))
- add serve scripts for app and API in package.json ([1ad4faa834](https://github.com/RueDeRennes/mosaik/commit/1ad4faa834))
- add ChatMessageReaction component with styles and templates ([1975e07a4a](https://github.com/RueDeRennes/mosaik/commit/1975e07a4a))

## 0.0.132 (2025-08-24)

### 🚀 Features

- enhance VoiceRecorderChatToolElement styles for improved layout and consistency ([09adbffe56](https://github.com/RueDeRennes/mosaik/commit/09adbffe56))

## 0.0.131 (2025-08-23)

### 🚀 Features

- update styles for ChatInputElement and VoiceRecorderChatToolElement to use theme variables for consistency ([9d9bc8adfb](https://github.com/RueDeRennes/mosaik/commit/9d9bc8adfb))
- reorder appearance input in ChatMarker components and ensure consistent usage across implementations ([eb5b88f6aa](https://github.com/RueDeRennes/mosaik/commit/eb5b88f6aa))

## 0.0.130 (2025-08-22)

### 🚀 Features

- add appearance property to ChatMarker components and update styles for new appearances ([23a86826b3](https://github.com/RueDeRennes/mosaik/commit/23a86826b3))
- update event names for recorder events to camelCase format ([bfd76cfe4b](https://github.com/RueDeRennes/mosaik/commit/bfd76cfe4b))

## 0.0.129 (2025-08-22)

### 🚀 Features

- add filePicked event to AttachmentChatTool component across multiple frameworks ([1c4744bc41](https://github.com/RueDeRennes/mosaik/commit/1c4744bc41))
- **voice-recorder:** add event handling for recording actions and update component props ([e78be3a04d](https://github.com/RueDeRennes/mosaik/commit/e78be3a04d))

## 0.0.128 (2025-08-22)

### 🚀 Features

- Add BusyState and VoiceRecorder components with Joy and Memphis themes ([eb1887d8e3](https://github.com/RueDeRennes/mosaik/commit/eb1887d8e3))
- **chat-tools:** integrate attachment and reaction chat tools ([89e61d7157](https://github.com/RueDeRennes/mosaik/commit/89e61d7157))

## 0.0.127 (2025-08-21)

### 🚀 Features

- add FormValidator2 and provideForms for enhanced form validation capabilities ([0202e7092e](https://github.com/RueDeRennes/mosaik/commit/0202e7092e))

## 0.0.126 (2025-08-21)

### 🚀 Features

- add new state components and their samples ([662149d135](https://github.com/RueDeRennes/mosaik/commit/662149d135))

## 0.0.125 (2025-08-20)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.124 (2025-08-20)

### 🚀 Features

- add formatter property to Checkbox, Choice, Radio, and ToggleSwitch components for enhanced text formatting ([e43a9d30b4](https://github.com/RueDeRennes/mosaik/commit/e43a9d30b4))
- update ChoiceElement template and styles for additional slot support ([e9d020bdf9](https://github.com/RueDeRennes/mosaik/commit/e9d020bdf9))

## 0.0.123 (2025-08-20)

### 🚀 Features

- add alignment property to HintElement and update template to support it ([985785e116](https://github.com/RueDeRennes/mosaik/commit/985785e116))

## 0.0.122 (2025-08-20)

### 🚀 Features

- enhance formatter setter to support string conversion to TextFormatter ([f89f500f68](https://github.com/RueDeRennes/mosaik/commit/f89f500f68))

### 🩹 Fixes

- add missing newline at end of package.json ([d79563d401](https://github.com/RueDeRennes/mosaik/commit/d79563d401))

## 0.0.121 (2025-08-20)

### 🚀 Features

- Add ToggleButtonGroup and DockPanel components with associated styles and tokens ([a9728a1a4e](https://github.com/RueDeRennes/mosaik/commit/a9728a1a4e))
- Enhance Wizard and ScrubSlider components with new slot definitions and improved documentation ([9b2319130d](https://github.com/RueDeRennes/mosaik/commit/9b2319130d))

## 0.0.120 (2025-08-18)

### 🚀 Features

- Add ToggleButtonElementValueAccessor and integrate with ToggleButtonComponent ([5e831d7fbd](https://github.com/RueDeRennes/mosaik/commit/5e831d7fbd))

## 0.0.119 (2025-08-18)

### 🚀 Features

- **wizard:** add isFirstStep and isLastStep properties to Wizard component ([b398a839e2](https://github.com/RueDeRennes/mosaik/commit/b398a839e2))

### 🩹 Fixes

- **release:** update version to 0.0.118 in release script ([4ac4717314](https://github.com/RueDeRennes/mosaik/commit/4ac4717314))

## 0.0.118 (2025-08-18)

### 🩹 Fixes

- **dialog:** update part name from 'scroller' to 'scroll' in dialog content styles chore: update release version to 0.0.117 in package.json ([b6605f00c0](https://github.com/RueDeRennes/mosaik/commit/b6605f00c0))

## 0.0.117 (2025-08-18)

### 🩹 Fixes

- **dialog): correct part name from 'scroller' to 'scroll' in _DialogContentElement.scss chore(release:** update release script version to 0.0.116 in package.json ([549b90aade](https://github.com/RueDeRennes/mosaik/commit/549b90aade))

## 0.0.116 (2025-08-18)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.115 (2025-08-18)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.114 (2025-08-17)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.113 (2025-08-17)

### 🚀 Features

- **dialog:** implement custom dialog slots and enhance dialog functionality ([dc13b4b8fe](https://github.com/RueDeRennes/mosaik/commit/dc13b4b8fe))

## 0.0.112 (2025-08-16)

### 🩹 Fixes

- **scrub-slider:** handle undefined values in tooltip and tick label accessors ([af6ccb9915](https://github.com/RueDeRennes/mosaik/commit/af6ccb9915))

## 0.0.111 (2025-08-16)

### 🚀 Features

- **error-directives:** add ErrorDirective and ErrorGroupDirective for form validation handling ([9b753e708a](https://github.com/RueDeRennes/mosaik/commit/9b753e708a))

## 0.0.110 (2025-08-16)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.109 (2025-08-15)

### 🚀 Features

- **themes:** add content offset top property to app themes and adjust styles ([4490a7438b](https://github.com/RueDeRennes/mosaik/commit/4490a7438b))
- **instructions:** add initial blogpost writing guidelines and structure ([03fbd93fd8](https://github.com/RueDeRennes/mosaik/commit/03fbd93fd8))

## 0.0.108 (2025-08-15)

### 🚀 Features

- **chat:** enhance styling and theming for chat components ([b8f5a8f6c6](https://github.com/RueDeRennes/mosaik/commit/b8f5a8f6c6))
- **dialog): enhance DialogPortalComponent with dynamic properties and update button appearance feat(translator:** improve addTranslations method to merge existing translations chore: update release script version to 0.0.107 ([e6974a901b](https://github.com/RueDeRennes/mosaik/commit/e6974a901b))

## 0.0.107 (2025-08-15)

### 🚀 Features

- **instructions:** add guideline for using "const object + derived union" pattern chore: update release version to 0.0.106 ([28ffdf76fb](https://github.com/RueDeRennes/mosaik/commit/28ffdf76fb))

## 0.0.106 (2025-08-15)

### 🚀 Features

- Add ScrubSlider component with multiple themes and styles ([d1db809262](https://github.com/RueDeRennes/mosaik/commit/d1db809262))
- **instructions:** add guidelines for self-closing tags and update constructor injection recommendation ([12118c959d](https://github.com/RueDeRennes/mosaik/commit/12118c959d))

## 0.0.105 (2025-08-14)

### 🚀 Features

- **chat:** integrate Slottable behavior and update event naming conventions ([9a1fcbf0d6](https://github.com/RueDeRennes/mosaik/commit/9a1fcbf0d6))

## 0.0.104 (2025-08-14)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.103 (2025-08-13)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.102 (2025-08-12)

### 🩹 Fixes

- **release:** update release version to 0.0.101 in package.json ([86223aaef2](https://github.com/RueDeRennes/mosaik/commit/86223aaef2))

## 0.0.101 (2025-08-12)

### 🩹 Fixes

- **release:** update release version to 0.0.100 in package.json ([6b4d2ead65](https://github.com/RueDeRennes/mosaik/commit/6b4d2ead65))

## 0.0.100 (2025-08-12)

### 🚀 Features

- **select:** enhance empty state handling and improve visibility checks ([ab9611d431](https://github.com/RueDeRennes/mosaik/commit/ab9611d431))

### 🩹 Fixes

- update release version to 0.0.99 in package.json ([00ce8821ae](https://github.com/RueDeRennes/mosaik/commit/00ce8821ae))

## 0.0.99 (2025-08-11)

### 🩹 Fixes

- update release version to 0.0.98 in package.json ([7b87750763](https://github.com/RueDeRennes/mosaik/commit/7b87750763))

## 0.0.98 (2025-08-11)

### 🩹 Fixes

- update release version to 0.0.97 in package.json ([332303fb5e](https://github.com/RueDeRennes/mosaik/commit/332303fb5e))

## 0.0.97 (2025-08-11)

### 🚀 Features

- add provider functions for dialogs, drawers, message boxes, and toasts ([6c8d58d206](https://github.com/RueDeRennes/mosaik/commit/6c8d58d206))

### 🩹 Fixes

- update release version to 0.0.96 in package.json ([6837da25c3](https://github.com/RueDeRennes/mosaik/commit/6837da25c3))

## 0.0.96 (2025-08-10)

### 🩹 Fixes

- update @types/node to version 24.2.1 across multiple packages ([1d3b606f14](https://github.com/RueDeRennes/mosaik/commit/1d3b606f14))
- update release version to 0.0.95 in package.json ([c1d12c2301](https://github.com/RueDeRennes/mosaik/commit/c1d12c2301))

## 0.0.95 (2025-08-09)

### 🩹 Fixes

- refactor animation properties in AnimateDirective and Animation to improve type safety ([c59fd6dd7f](https://github.com/RueDeRennes/mosaik/commit/c59fd6dd7f))
- update import path for FileCache and increment release version to 0.0.94 ([54601adcea](https://github.com/RueDeRennes/mosaik/commit/54601adcea))

## 0.0.94 (2025-08-09)

### 🩹 Fixes

- add missing newline at end of package.json ([32f8168058](https://github.com/RueDeRennes/mosaik/commit/32f8168058))

## 0.0.93 (2025-08-09)

### 🚀 Features

- **CellElement:** add auto-generated styles for cosmopolitan cell element ([57bb5833b2](https://github.com/RueDeRennes/mosaik/commit/57bb5833b2))
- enhance executors with additional imports and caching utility integration ([626574efac](https://github.com/RueDeRennes/mosaik/commit/626574efac))
- implement caching utility and update executors to use it ([109456ef58](https://github.com/RueDeRennes/mosaik/commit/109456ef58))

### 🩹 Fixes

- update cache enabling logic across multiple executors ([91828dcf26](https://github.com/RueDeRennes/mosaik/commit/91828dcf26))

## 0.0.92 (2025-08-08)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.91 (2025-08-08)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.90 (2025-08-08)

### 🚀 Features

- **select:** add filter functionality with placeholder support ([30207277b0](https://github.com/RueDeRennes/mosaik/commit/30207277b0))
- add border-radius and overflow properties to AppHeaderElement styles for improved layout ([588ed0f41d](https://github.com/RueDeRennes/mosaik/commit/588ed0f41d))

## 0.0.89 (2025-08-05)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.88 (2025-08-04)

### 🚀 Features

- add executor options types and schema generation script; remove unused dependencies ([eb71956d5a](https://github.com/RueDeRennes/mosaik/commit/eb71956d5a))

## 0.0.87 (2025-08-04)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.86 (2025-08-04)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.85 (2025-08-01)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.84 (2025-08-01)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.83 (2025-08-01)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.82 (2025-08-01)

### 🚀 Features

- update release version to 0.0.81 in package.json ([6e01a49d06](https://github.com/RueDeRennes/mosaik/commit/6e01a49d06))

### 🩹 Fixes

- **release): update version number from 0.0.81 to 0.0.82 in release script fix(events:** remove redundant detailType from select event in Meta.g.json ([a330ca39c9](https://github.com/RueDeRennes/mosaik/commit/a330ca39c9))
- **elements:** add TypeScript ignore comments for static 'is' getters in multiple components ([22cc7e5d04](https://github.com/RueDeRennes/mosaik/commit/22cc7e5d04))
- **dependencies:** downgrade TypeScript version from ^5.9.2 to ^5.8.3 across multiple packages ([c58367f25b](https://github.com/RueDeRennes/mosaik/commit/c58367f25b))
- **elements:** add TypeScript ignore comments for static 'is' getters in various components ([5c400e4885](https://github.com/RueDeRennes/mosaik/commit/5c400e4885))

## 0.0.81 (2025-07-30)

### 🚀 Features

- enhance HTML code generation with new abstract methods and self-closing tag support feat: update icon registration to support aliases for icons style: adjust drawer component styles to use line thickness variable chore: add line thickness property to drawer theme tokens in Cosmopolitan, Joy, and Memphis themes ([0174ad7acb](https://github.com/RueDeRennes/mosaik/commit/0174ad7acb))
- update release version to 0.0.80 in package.json ([96a94fca93](https://github.com/RueDeRennes/mosaik/commit/96a94fca93))

## 0.0.80 (2025-07-30)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.79 (2025-07-30)

### 🚀 Features

- Add synchronous caching methods for file and directory checks in FileCache refactor: Update storage conversion methods to simplify data handling chore: Enhance styledictionary configuration with file caching and logging improvements ([0f6a7350f3](https://github.com/RueDeRennes/mosaik/commit/0f6a7350f3))
- Update input components and themes ([e2379e3bd0](https://github.com/RueDeRennes/mosaik/commit/e2379e3bd0))
- **textbox:** add prefix and suffix icon support with customizable sizes ([eb9c019a17](https://github.com/RueDeRennes/mosaik/commit/eb9c019a17))
- update button components with new size tokens ([22d0cdd674](https://github.com/RueDeRennes/mosaik/commit/22d0cdd674))
- Enhance projection handling and styling for dropdown and menu components ([8c663e6e7e](https://github.com/RueDeRennes/mosaik/commit/8c663e6e7e))
- Implement SandboxProjectFactory and SandboxProjectTemplateEngine ([3300298aec](https://github.com/RueDeRennes/mosaik/commit/3300298aec))
- add YAML code generation and update chat mode configuration ([9fe1bb330c](https://github.com/RueDeRennes/mosaik/commit/9fe1bb330c))
- Enhance ProjectionView with new styling and sample code; add translation for projection ([114c4671a4](https://github.com/RueDeRennes/mosaik/commit/114c4671a4))
- Add Projection View component and update related views and styles ([91d1f76e88](https://github.com/RueDeRennes/mosaik/commit/91d1f76e88))
- Enhance Landing and App View Components ([459cb772ed](https://github.com/RueDeRennes/mosaik/commit/459cb772ed))

### 🩹 Fixes

- correct spelling of 'initialize' in various files and update related interfaces ([3c70f28918](https://github.com/RueDeRennes/mosaik/commit/3c70f28918))

## 0.0.78 (2025-07-20)

### 🚀 Features

- Add AppView styles and template ([6d2c19940f](https://github.com/RueDeRennes/mosaik/commit/6d2c19940f))
- Update DismissElement styles for close button with consistent dimensions and border radius ([75e0cc7731](https://github.com/RueDeRennes/mosaik/commit/75e0cc7731))
- Update dismiss element styles for improved positioning and z-index handling ([8565d05277](https://github.com/RueDeRennes/mosaik/commit/8565d05277))
- Enhance DismissElement with Themeable behavior and update IDismissElementProps interface ([74b709ec06](https://github.com/RueDeRennes/mosaik/commit/74b709ec06))
- Add PortalHostComponent to various frameworks and implement Gappable behavior ([2e84d8f5d0](https://github.com/RueDeRennes/mosaik/commit/2e84d8f5d0))
- Update translations to include dynamic placeholders and enhance icon gallery functionality feat: Add InfiniteScrollController for improved scrolling experience refactor: Improve type safety in UrlParam and Persisted decorators ([6e35f3da1d](https://github.com/RueDeRennes/mosaik/commit/6e35f3da1d))
- Update IPersistedConfig and IUrlParamConfig interfaces for improved type safety and consistency ([6cce9680f5](https://github.com/RueDeRennes/mosaik/commit/6cce9680f5))
- Simplify exports in Index.ts by removing unused properties from Persisted and UrlParam decorators ([73f6f09f72](https://github.com/RueDeRennes/mosaik/commit/73f6f09f72))
- Enhance Persisted and UrlParam decorators to support Signal values and improve property management ([fbe8d5f131](https://github.com/RueDeRennes/mosaik/commit/fbe8d5f131))
- Refactor and enhance reactivity system with new Signal and TrackableSignal classes ([09c5e2a4b8](https://github.com/RueDeRennes/mosaik/commit/09c5e2a4b8))
- **translations:** add new localized strings for icon gallery and update existing translations ([64485437d7](https://github.com/RueDeRennes/mosaik/commit/64485437d7))
- update IconGalleryView to include shared styles; enhance logging format in LitStyleTransformTask; modify executor options to include elementsOnly; remove unused Fluent theme from ButtonElement; improve createStyleSheets function to support array of styles ([7f28e6c94d](https://github.com/RueDeRennes/mosaik/commit/7f28e6c94d))
- Integrate Portal and ProjectionController into DateBox, DateTimeBox, and TimeBox components ([b0d925bdbf](https://github.com/RueDeRennes/mosaik/commit/b0d925bdbf))
- add SpacerDirective with options for spacing control and update index export ([8a2727ea31](https://github.com/RueDeRennes/mosaik/commit/8a2727ea31))
- standardize event listener decorators by removing 'self' target option and improving documentation ([f14fe3f4b5](https://github.com/RueDeRennes/mosaik/commit/f14fe3f4b5))
- Update button components to include event fires and improve documentation ([07140d2542](https://github.com/RueDeRennes/mosaik/commit/07140d2542))
- implement App component with templates and update AppHeader for toggling functionality ([992d3d7433](https://github.com/RueDeRennes/mosaik/commit/992d3d7433))
- add App Header component and related samples, templates, and events ([cb140e78e8](https://github.com/RueDeRennes/mosaik/commit/cb140e78e8))
- add expand, collapse, and toggle methods to MenuItem and TreeItem components with descriptions ([8881f5f730](https://github.com/RueDeRennes/mosaik/commit/8881f5f730))
- add IExpandable interface and implement expandable functionality in MenuItemElement, TreeItemElement, and ExpandableElement ([f2fb5df205](https://github.com/RueDeRennes/mosaik/commit/f2fb5df205))
- implement ColorTableElement component with associated template and styles ([a5bc0a091a](https://github.com/RueDeRennes/mosaik/commit/a5bc0a091a))
- add copyExecutorsJson script and update build commands ([0a0aba85b9](https://github.com/RueDeRennes/mosaik/commit/0a0aba85b9))
- update Carousel component methods and add select method implementation ([351e68a615](https://github.com/RueDeRennes/mosaik/commit/351e68a615))
- update menu component styles and structure for improved layout and responsiveness ([373095056e](https://github.com/RueDeRennes/mosaik/commit/373095056e))
- add icon functionality with IconDirective and IconRegistry, enhance app layout with new directives ([8acea01349](https://github.com/RueDeRennes/mosaik/commit/8acea01349))
- enhance app layout and styling with new components and responsive design ([8919fccc0c](https://github.com/RueDeRennes/mosaik/commit/8919fccc0c))
- enhance Jumbotron components with slot definitions and improve HideOnScrollController methods ([4cc6d9de3a](https://github.com/RueDeRennes/mosaik/commit/4cc6d9de3a))
- Add formatter property to Jumbotron components and update related files ([9ae59c7ff9](https://github.com/RueDeRennes/mosaik/commit/9ae59c7ff9))
- Add Svelte titles to German and English translations; update formatting keys in various components ([9889da1578](https://github.com/RueDeRennes/mosaik/commit/9889da1578))
- Add Jumbotron component and related styles for multiple frameworks ([41d4601e08](https://github.com/RueDeRennes/mosaik/commit/41d4601e08))
- enhance backdrop styles and refactor breakpoint handling ([39661be30c](https://github.com/RueDeRennes/mosaik/commit/39661be30c))
- Update layout variables for Cosmopolitan and Joy themes in various components ([af9ca676db](https://github.com/RueDeRennes/mosaik/commit/af9ca676db))
- Introduce Indicator component across multiple frameworks ([7ef850c39d](https://github.com/RueDeRennes/mosaik/commit/7ef850c39d))
- Update Indicator component styles and tokens for layout spacing ([201ee59059](https://github.com/RueDeRennes/mosaik/commit/201ee59059))
- Add Indicator component and related functionality ([b55b86b0e2](https://github.com/RueDeRennes/mosaik/commit/b55b86b0e2))
- implement animation directive and provider with presets ([09550b6633](https://github.com/RueDeRennes/mosaik/commit/09550b6633))
- enhance theme merging logic and add support for deep partial overrides ([870d64b42b](https://github.com/RueDeRennes/mosaik/commit/870d64b42b))
- Remove unused 'onInput' method from ColorPicker components and update related code ([d84ece1672](https://github.com/RueDeRennes/mosaik/commit/d84ece1672))
- Add Svelte support with SvelteCodeGenerator and update build scripts ([955cb75cb6](https://github.com/RueDeRennes/mosaik/commit/955cb75cb6))
- Add new Svelte components for menu, segment, tab, table, tree, wizard, and shell ([e6de8f0553](https://github.com/RueDeRennes/mosaik/commit/e6de8f0553))
- add Color Palette Builder tool and associated views ([55a992138e](https://github.com/RueDeRennes/mosaik/commit/55a992138e))
- add comprehensive article on using const vs enums in TypeScript with Angular templates ([8db46644e3](https://github.com/RueDeRennes/mosaik/commit/8db46644e3))
- add hasHeader and hasNav properties to AppElement and update related components ([37baedabae](https://github.com/RueDeRennes/mosaik/commit/37baedabae))
- add localizator-core dependency and update build dependencies in project configuration ([077a2cd1d9](https://github.com/RueDeRennes/mosaik/commit/077a2cd1d9))
- add FlexDirective for flexible layout management in Angular ([3b8f27e2b7](https://github.com/RueDeRennes/mosaik/commit/3b8f27e2b7))
- add comprehensive guide on the power of regions in TypeScript for improved code organization ([564b600288](https://github.com/RueDeRennes/mosaik/commit/564b600288))
- add theme provider for angular ([04568d1528](https://github.com/RueDeRennes/mosaik/commit/04568d1528))
- update masonry and wrap elements to use CSS variables for gap and columns, enhance templates with static styles ([2dee486060](https://github.com/RueDeRennes/mosaik/commit/2dee486060))
- disable eslint rule for static styles in multiple component templates and update SCSS mixin to exclude properties ([d6e61ac195](https://github.com/RueDeRennes/mosaik/commit/d6e61ac195))
- enhance keyboard element with modifier key support and update styles ([07f7af6d52](https://github.com/RueDeRennes/mosaik/commit/07f7af6d52))
- enhance dropdown button templates with new icons and improved layout fix: adjust padding for menu item group headers across themes ([5004c67e11](https://github.com/RueDeRennes/mosaik/commit/5004c67e11))
- add 'Code' and 'TypeScript' keywords to various documentation files for improved discoverability ([7ac3c152dd](https://github.com/RueDeRennes/mosaik/commit/7ac3c152dd))
- add "The Dependency Forest" article on dependency management challenges in Angular ([d129b84490](https://github.com/RueDeRennes/mosaik/commit/d129b84490))
- add translation command and integrate translation functionality in BlogBaseElement ([7e166a6bea](https://github.com/RueDeRennes/mosaik/commit/7e166a6bea))
- enhance blog and translation features with interview type and language flags ([9aff64d29b](https://github.com/RueDeRennes/mosaik/commit/9aff64d29b))
- update interview content and add StickyController metadata in JSON ([c39d970be6](https://github.com/RueDeRennes/mosaik/commit/c39d970be6))
- add YouTube video rendering support in MarkdownRenderer ([723610d3c8](https://github.com/RueDeRennes/mosaik/commit/723610d3c8))
- Add new translation for "Open with" in code section ([e1b84033bc](https://github.com/RueDeRennes/mosaik/commit/e1b84033bc))
- create Playground components for testing Markdown features ([738f61002f](https://github.com/RueDeRennes/mosaik/commit/738f61002f))
- enhance Listen decorator to support custom query targets and improve event handling ([aa19e6e5a0](https://github.com/RueDeRennes/mosaik/commit/aa19e6e5a0))
- add PinchController for gesture recognition and enhance DiagramElement with centering functionality ([c3feb9a789](https://github.com/RueDeRennes/mosaik/commit/c3feb9a789))
- **docs:** Update documentation with new sections, descriptions, and examples for clarity and usability ([c32ff5f976](https://github.com/RueDeRennes/mosaik/commit/c32ff5f976))
- **docs:** Enhance MVP pattern documentation with detailed explanations and examples ([e3c97f1368](https://github.com/RueDeRennes/mosaik/commit/e3c97f1368))
- implement filter functionality in ArticlesView and update related templates ([1e88d302d4](https://github.com/RueDeRennes/mosaik/commit/1e88d302d4))
- Implement sticky positioning directive and controller, enhance scrolling functionality in Scroller class ([148f07916e](https://github.com/RueDeRennes/mosaik/commit/148f07916e))
- Enhance MVP documentation and examples across multiple frameworks ([cfabea14a3](https://github.com/RueDeRennes/mosaik/commit/cfabea14a3))
- add backdrop images and enhance ArticlesView with documentation grouping ([af72ff74cd](https://github.com/RueDeRennes/mosaik/commit/af72ff74cd))
- add images and enhance Markdown documentation with improved layout and structure ([1eaac2125f](https://github.com/RueDeRennes/mosaik/commit/1eaac2125f))
- enhance Markdown components with improved styling and layout variables ([780d383b31](https://github.com/RueDeRennes/mosaik/commit/780d383b31))
- enhance CodeEditor and Markdown components with improved language and theme support ([0270711752](https://github.com/RueDeRennes/mosaik/commit/0270711752))
- **callouts:** add new callout variants and enhance Markdown processing ([3a5608697b](https://github.com/RueDeRennes/mosaik/commit/3a5608697b))
- **markdowner:** enhance Markdown processing with new extension structure and build integration ([0c08852146](https://github.com/RueDeRennes/mosaik/commit/0c08852146))
- Enhance Markdown processing with new features and improvements ([534983c407](https://github.com/RueDeRennes/mosaik/commit/534983c407))
- **translations:** add share message for blog posts ([a3ba45071a](https://github.com/RueDeRennes/mosaik/commit/a3ba45071a))
- improve date formatting in BlogBase and enhance share command data structure ([6f64d0990e](https://github.com/RueDeRennes/mosaik/commit/6f64d0990e))
- enhance Markdown component styles with improved blockquote and list formatting ([dbefc8d12f](https://github.com/RueDeRennes/mosaik/commit/dbefc8d12f))
- refactor text overflow handling and enhance Markdown component styles ([62bb601fc7](https://github.com/RueDeRennes/mosaik/commit/62bb601fc7))
- Update AppSideNavTemplate to use node meta for display names and add value binding ([1488b7d52f](https://github.com/RueDeRennes/mosaik/commit/1488b7d52f))
- update metadata structure in documentation and improve avatar and chip components ([007bd05bea](https://github.com/RueDeRennes/mosaik/commit/007bd05bea))
- enhance Markdown rendering and styling with new link styles and tree directive support ([8fba55993c](https://github.com/RueDeRennes/mosaik/commit/8fba55993c))
- update markdown files to use structured keywords and add author information ([d0df1b883f](https://github.com/RueDeRennes/mosaik/commit/d0df1b883f))
- **docs): enhance keyword metadata across documentation files for improved searchability and context feat(Markdown): update MarkdownElement and MarkdownRenderer for better handling of text and code blocks fix(DocsService): refine getDocsTree method for improved documentation hierarchy and sorting fix(staticContent:** add meta information to static content registration for enhanced metadata handling ([789875e05d](https://github.com/RueDeRennes/mosaik/commit/789875e05d))
- **build:** add vite-plugins build step to deployment script; enhance MarkdownElement and DocsService for better handling of documentation and Markdown sources ([619a32e38b](https://github.com/RueDeRennes/mosaik/commit/619a32e38b))
- **menu:** add textOverflow property to MenuItemComponent and related elements for improved text handling; update DocsService and AppSideNavTemplate for better rendering ([9b7641b6c1](https://github.com/RueDeRennes/mosaik/commit/9b7641b6c1))
- **router:** implement RouterLocation and IRouterLocation for improved routing abstraction; refactor RouterElement to utilize new location handling ([53705c577a](https://github.com/RueDeRennes/mosaik/commit/53705c577a))
- **menu:** enhance menu item styles with indent properties and update theme tokens for better visual hierarchy ([b3dad3c306](https://github.com/RueDeRennes/mosaik/commit/b3dad3c306))
- **router:** enhance routing components with role attributes and update templates for better accessibility; refactor RouterController and RouterLinkDirective for improved functionality ([63b32829f1](https://github.com/RueDeRennes/mosaik/commit/63b32829f1))
- **router:** implement routerLink directive for dynamic link handling; update AppSideNavTemplate to use routerLink ([f2fb309d47](https://github.com/RueDeRennes/mosaik/commit/f2fb309d47))
- **router:** add RouterLinkDirective for dynamic link generation ([ab2e98ed50](https://github.com/RueDeRennes/mosaik/commit/ab2e98ed50))
- enhance package service and controller to support history retrieval with optional limit; update translations and styles for package explorer ([71efae2557](https://github.com/RueDeRennes/mosaik/commit/71efae2557))
- implement ShieldElement with template, style, and props; enhance package metadata and history models ([de73abbc76](https://github.com/RueDeRennes/mosaik/commit/de73abbc76))
- enhance package service and models with metadata and history retrieval ([05c98c197d](https://github.com/RueDeRennes/mosaik/commit/05c98c197d))
- add package manager installation step in CI workflow ([d8453719df](https://github.com/RueDeRennes/mosaik/commit/d8453719df))
- add eslint config build step to the dev deployment workflow ([c831986474](https://github.com/RueDeRennes/mosaik/commit/c831986474))
- add component selector to various sample elements for better integration ([3eb465fed5](https://github.com/RueDeRennes/mosaik/commit/3eb465fed5))
- Update button element CSS properties and enhance template styles ([c83ee77d83](https://github.com/RueDeRennes/mosaik/commit/c83ee77d83))
- Enhance sandbox functionality and UI improvements ([c45d7ca09b](https://github.com/RueDeRennes/mosaik/commit/c45d7ca09b))
- Implement ProjectionController for managing projected content in portals ([1bc46717b5](https://github.com/RueDeRennes/mosaik/commit/1bc46717b5))
- add TableFooter component and related styles ([85d9e96af5](https://github.com/RueDeRennes/mosaik/commit/85d9e96af5))
- Enhance state elements with padding and gap properties ([19074a8b51](https://github.com/RueDeRennes/mosaik/commit/19074a8b51))
- Enhance Select and Combo components with internationalization and improved styling ([8d80d58234](https://github.com/RueDeRennes/mosaik/commit/8d80d58234))
- enhance TagCloudElement with item selection and styling; refactor related components and styles ([2847e96a41](https://github.com/RueDeRennes/mosaik/commit/2847e96a41))
- add ModifierKeyName export and improve attr() function in SCSS ([317b75143d](https://github.com/RueDeRennes/mosaik/commit/317b75143d))
- Refactor CheckBoxGroupSample and TextBoxSample components for improved property formatting ([b0fcc7502e](https://github.com/RueDeRennes/mosaik/commit/b0fcc7502e))
- add default values for boolean attributes across various components ([899d593ba5](https://github.com/RueDeRennes/mosaik/commit/899d593ba5))
- update release script to version 0.0.26 ([11e2fdbc4f](https://github.com/RueDeRennes/mosaik/commit/11e2fdbc4f))
- update release script to version 0.0.25 ([930ba60eb4](https://github.com/RueDeRennes/mosaik/commit/930ba60eb4))
- update version to 0.0.24 and remove prefix/suffix styles from various components ([d061c7f8cd](https://github.com/RueDeRennes/mosaik/commit/d061c7f8cd))
- update appearance of input components and add textAlign property ([5f7321b7a8](https://github.com/RueDeRennes/mosaik/commit/5f7321b7a8))
- Add text alignment support to input components ([0a1069f47d](https://github.com/RueDeRennes/mosaik/commit/0a1069f47d))
- Add Validators class to Cdk for form validation ([5db8b51601](https://github.com/RueDeRennes/mosaik/commit/5db8b51601))
- add spinner and textAlign properties to NumberBox and TextBox components ([cda90dffa4](https://github.com/RueDeRennes/mosaik/commit/cda90dffa4))
- implement flip component with new side property and directives ([2b3c56c9b4](https://github.com/RueDeRennes/mosaik/commit/2b3c56c9b4))
- add select component to auth form and improve validation ([4971bba07f](https://github.com/RueDeRennes/mosaik/commit/4971bba07f))
- add Invalidable behavior and validity check to components ([893bb30b3b](https://github.com/RueDeRennes/mosaik/commit/893bb30b3b))
- add ng forms validation trigger ([e430f70f31](https://github.com/RueDeRennes/mosaik/commit/e430f70f31))
- update project dependencies and build configurations ([569b1bf99d](https://github.com/RueDeRennes/mosaik/commit/569b1bf99d))
- **eslint:** add TypeScript ESLint configuration with comprehensive ruleset ([4d7a0d88b7](https://github.com/RueDeRennes/mosaik/commit/4d7a0d88b7))
- Add Insetable behavior and update BoxElement styles ([ca740ab5f2](https://github.com/RueDeRennes/mosaik/commit/ca740ab5f2))
- export dateTimeBoxElementValueAccessor alongside DateTimeBoxElementValueAccessor for improved accessibility ([fad7497ba7](https://github.com/RueDeRennes/mosaik/commit/fad7497ba7))
- enhance project configurations with inputs and outputs for build targets ([6f80d15bda](https://github.com/RueDeRennes/mosaik/commit/6f80d15bda))
- **PublishPackage:** add version validation and improve error logging ([33ad436126](https://github.com/RueDeRennes/mosaik/commit/33ad436126))
- update package dependencies to use workspace references ([e853ec04e5](https://github.com/RueDeRennes/mosaik/commit/e853ec04e5))
- add changelog configuration to disable author rendering and update release script to specify group ([9ce709c251](https://github.com/RueDeRennes/mosaik/commit/9ce709c251))
- update version generator options to include installArgs and installIgnoreScripts ([747191d4da](https://github.com/RueDeRennes/mosaik/commit/747191d4da))
- streamline release configuration by consolidating project relationships and removing redundant properties ([77fbfcd293](https://github.com/RueDeRennes/mosaik/commit/77fbfcd293))
- add version configuration for conventional commits and generator options ([bd6048596e](https://github.com/RueDeRennes/mosaik/commit/bd6048596e))
- update release configuration to set projectsRelationship to fixed for libs, infra, and tools ([bc0437f95d](https://github.com/RueDeRennes/mosaik/commit/bc0437f95d))
- restructure release configuration to include groups for libs, infra, and tools ([fe9e93b5ce](https://github.com/RueDeRennes/mosaik/commit/fe9e93b5ce))
- update documentation paths and add index file for mosaik-elements-foundation package ([ced717bdea](https://github.com/RueDeRennes/mosaik/commit/ced717bdea))
- update package dependencies to use caret (^) versioning for consistency ([2d8ab96c84](https://github.com/RueDeRennes/mosaik/commit/2d8ab96c84))
- add dependency management for publish targets in project configurations ([e13de9a63b](https://github.com/RueDeRennes/mosaik/commit/e13de9a63b))
- enhance release script to include build and publish targets ([0c29b15d46](https://github.com/RueDeRennes/mosaik/commit/0c29b15d46))
- update package.json dependencies to use specific versions instead of workspace references ([4934f88dc1](https://github.com/RueDeRennes/mosaik/commit/4934f88dc1))
- update project configurations to enable caching and adjust input paths for build targets ([4e8b485497](https://github.com/RueDeRennes/mosaik/commit/4e8b485497))
- add copy-dependencies and publish-package executors; update project.json to use new publish executor ([ba4c5f9393](https://github.com/RueDeRennes/mosaik/commit/ba4c5f9393))
- add changesets for versioning and changelog management ([00db6e0ef1](https://github.com/RueDeRennes/mosaik/commit/00db6e0ef1))
- add semver package for version validation in CopyPublisherPackageJson task ([f848b73d49](https://github.com/RueDeRennes/mosaik/commit/f848b73d49))
- Refactor components to support standalone mode and add method invocation capabilities ([3312924aa2](https://github.com/RueDeRennes/mosaik/commit/3312924aa2))
- **dialog:** implement DialogRef and DialogService for enhanced dialog management ([e1c0b0d850](https://github.com/RueDeRennes/mosaik/commit/e1c0b0d850))
- define custom elements for various components in Mosaik Elements Angular ([cb6a1d5ef2](https://github.com/RueDeRennes/mosaik/commit/cb6a1d5ef2))
- Implement default file cleanup script and enhance component styles ([3aff5d6fd8](https://github.com/RueDeRennes/mosaik/commit/3aff5d6fd8))
- Add Electronic Program Guide components for Angular, React, and Vue ([b62f3f59fc](https://github.com/RueDeRennes/mosaik/commit/b62f3f59fc))
- Add theme change handling and improve dialog dimensions in AppSettingsView; enhance InkBarElement alignment logic ([71da43e4b1](https://github.com/RueDeRennes/mosaik/commit/71da43e4b1))
- Enhance LitStyleTransform with dependency analysis and improve logging; add memphis anchor element styles ([730b58ed42](https://github.com/RueDeRennes/mosaik/commit/730b58ed42))
- Enhance PropertyDecorator to support CSS variable binding for style properties ([5273291343](https://github.com/RueDeRennes/mosaik/commit/5273291343))
- add Boundable behavior and utility functions for date handling ([1deae6f00a](https://github.com/RueDeRennes/mosaik/commit/1deae6f00a))
- Add Joy theme styles for Electronic Program Guide components ([7c76dce194](https://github.com/RueDeRennes/mosaik/commit/7c76dce194))
- Enhance Coupon and Highlight components with improved styles and user-select properties ([7de39c4dee](https://github.com/RueDeRennes/mosaik/commit/7de39c4dee))
- Enhance Electronic Program Guide with new properties and styling adjustments ([d2aed27576](https://github.com/RueDeRennes/mosaik/commit/d2aed27576))
- Add Electronic Program Guide components and styles ([4d7c1d2f49](https://github.com/RueDeRennes/mosaik/commit/4d7c1d2f49))
- **expander:** update styles for Cosmopolitan, Default, Joy, and Memphis themes to enhance shadow properties and improve consistency ([78f0a88ebe](https://github.com/RueDeRennes/mosaik/commit/78f0a88ebe))
- **button:** enhance button styles with shadow and color properties ([46e28550b4](https://github.com/RueDeRennes/mosaik/commit/46e28550b4))
- **tokens:** restructure elevation tokens for better granularity and linting ([d921d201d3](https://github.com/RueDeRennes/mosaik/commit/d921d201d3))
- **tokens:** enhance elevation and typography tokens across themes ([4fca67fd43](https://github.com/RueDeRennes/mosaik/commit/4fca67fd43))
- **theme:** enhance theme management and button styles with new properties and variants ([e733f777e9](https://github.com/RueDeRennes/mosaik/commit/e733f777e9))
- **theme:** enhance Memphis theme with additional variants and update component styles ([6d869ec358](https://github.com/RueDeRennes/mosaik/commit/6d869ec358))
- Update ToggleTip component styles and tokens across themes ([c30920e681](https://github.com/RueDeRennes/mosaik/commit/c30920e681))
- Update theme components and tokens for consistency and improved styling ([ffb9596405](https://github.com/RueDeRennes/mosaik/commit/ffb9596405))
- Enhance Memphis theme with new elevation and appearance tokens ([0c9a0084ec](https://github.com/RueDeRennes/mosaik/commit/0c9a0084ec))
- update chart component styles for improved tooltip and legend formatting ([1037a3fa9a](https://github.com/RueDeRennes/mosaik/commit/1037a3fa9a))
- update chart component styles and themes to use Joy typography variables ([8fe7d7f4fe](https://github.com/RueDeRennes/mosaik/commit/8fe7d7f4fe))
- enhance chart and form elements with foreground color support and style adjustments ([dad0dd53df](https://github.com/RueDeRennes/mosaik/commit/dad0dd53df))
- implement theme persistence and configuration storage, update ToastService and RatingElement properties ([2fe40b8ee8](https://github.com/RueDeRennes/mosaik/commit/2fe40b8ee8))
- add installation and setup for package manager in the workflow ([1498f235f9](https://github.com/RueDeRennes/mosaik/commit/1498f235f9))
- add support for package manager setup in the dev workflow ([59aaf6b708](https://github.com/RueDeRennes/mosaik/commit/59aaf6b708))
- update banner appearance to 'soft' across multiple views and adjust button styles for improved consistency ([36804f1758](https://github.com/RueDeRennes/mosaik/commit/36804f1758))
- implement tab panel component with scrollable content and improved selection logic ([a5766822e0](https://github.com/RueDeRennes/mosaik/commit/a5766822e0))
- update App settings view template to enhance layout and add text case directive ([d3b4963491](https://github.com/RueDeRennes/mosaik/commit/d3b4963491))
- Add options for mode and focus delegation in Drawer components ([2439ae5ada](https://github.com/RueDeRennes/mosaik/commit/2439ae5ada))
- Add appearance property to mosaik-toolbar in chat header template ([0dafe85e1f](https://github.com/RueDeRennes/mosaik/commit/0dafe85e1f))
- Add initial QR Code Cosmopolitan theme styles and structure ([ec12f33544](https://github.com/RueDeRennes/mosaik/commit/ec12f33544))
- Enhance wizard and state elements with new styles and responsive design ([f7bbd2303c](https://github.com/RueDeRennes/mosaik/commit/f7bbd2303c))
- Update Persona and QR Code themes with new styles and tokens ([dfb5030cd8](https://github.com/RueDeRennes/mosaik/commit/dfb5030cd8))
- add style dictionary component generation and enhance SCSS file handling ([8cb9f0d702](https://github.com/RueDeRennes/mosaik/commit/8cb9f0d702))
- enhance SCSS file handling by adding default content population and improving path resolution ([d2a09333bc](https://github.com/RueDeRennes/mosaik/commit/d2a09333bc))
- implement memphis theme support and enhance theme handling across components ([6e6501b5d3](https://github.com/RueDeRennes/mosaik/commit/6e6501b5d3))
- enable multi-language support and add ColorSwatchGroupElement ([e15a8905a4](https://github.com/RueDeRennes/mosaik/commit/e15a8905a4))
- update theme to dark mode and refine color tokens for improved accessibility ([42819d5937](https://github.com/RueDeRennes/mosaik/commit/42819d5937))
- enhance theming support by adding size and layout properties to various components ([285a91ad39](https://github.com/RueDeRennes/mosaik/commit/285a91ad39))
- add appearance variants to toolbar and tab components for enhanced theming support ([275de74baa](https://github.com/RueDeRennes/mosaik/commit/275de74baa))
- enhance theming support by applying Themeable behavior to multiple component classes ([cd7b65f77b](https://github.com/RueDeRennes/mosaik/commit/cd7b65f77b))
- import Themeable behavior into various component files for enhanced theming support ([f9c34b371e](https://github.com/RueDeRennes/mosaik/commit/f9c34b371e))
- add size, duration, elevation, layout, and typography functions to Joy theme styles ([8d472f999c](https://github.com/RueDeRennes/mosaik/commit/8d472f999c))
- add Themeable mixin and import to component style templates ([60e2060c70](https://github.com/RueDeRennes/mosaik/commit/60e2060c70))
- update Joy theme styles for various components, adding new properties and improving consistency ([7eba0a5ea3](https://github.com/RueDeRennes/mosaik/commit/7eba0a5ea3))
- remove obsolete style files and add shared styles for Portal, Content, Floating, and MessageBox components ([dd521743ec](https://github.com/RueDeRennes/mosaik/commit/dd521743ec))
- add memphis theme styles for Chip and QRCode components, remove obsolete Spacer and Sticky styles ([e34f5ee454](https://github.com/RueDeRennes/mosaik/commit/e34f5ee454))
- remove obsolete style files and add new Joy theme styles for various components ([233ed63475](https://github.com/RueDeRennes/mosaik/commit/233ed63475))
- refactor theme styles for Card and CompoundButton components ([a3c49279c0](https://github.com/RueDeRennes/mosaik/commit/a3c49279c0))
- add shared styles for new UI components and update existing styles for consistency ([1772b383a7](https://github.com/RueDeRennes/mosaik/commit/1772b383a7))
- add default styles to Absolute and AbsoluteItem components ([dd26c85a21](https://github.com/RueDeRennes/mosaik/commit/dd26c85a21))
- add cosmopolitan theme style to various form and UI components ([0015925f0c](https://github.com/RueDeRennes/mosaik/commit/0015925f0c))
- enhance Floating Action Button with multiple theme styles ([10892ad232](https://github.com/RueDeRennes/mosaik/commit/10892ad232))
- MAJOR MIGRATION ([4118d0424b](https://github.com/RueDeRennes/mosaik/commit/4118d0424b))
- add script to create theme style templates for components and manage SCSS files ([a12659870b](https://github.com/RueDeRennes/mosaik/commit/a12659870b))
- add new theme styles for various components to enhance UI consistency ([271cecd764](https://github.com/RueDeRennes/mosaik/commit/271cecd764))
- update calendar and chipbox components with improved theming and styles for consistency ([7cdd9a1342](https://github.com/RueDeRennes/mosaik/commit/7cdd9a1342))
- add shared styles for calendar components to enhance UI consistency and layout ([9555e86fab](https://github.com/RueDeRennes/mosaik/commit/9555e86fab))
- enhance input components with improved theming and layout consistency ([5b5a41cf54](https://github.com/RueDeRennes/mosaik/commit/5b5a41cf54))
- enhance select and signature pad components with improved styles for consistency and usability ([8c4ff832f4](https://github.com/RueDeRennes/mosaik/commit/8c4ff832f4))
- add shared styles for grid, virtualize, absolute, tile list, masonry, and title layout components to enhance UI consistency ([cbe8204651](https://github.com/RueDeRennes/mosaik/commit/cbe8204651))
- add shared styles for BackTop and CookieConsent components to enhance UI consistency ([ea0800bf89](https://github.com/RueDeRennes/mosaik/commit/ea0800bf89))
- update chip component styles for improved theming and consistency across appearances ([e397515a48](https://github.com/RueDeRennes/mosaik/commit/e397515a48))
- add shared styles for toggletip, carousel, paginator, drop zone, backdrop, and other components to enhance UI consistency ([62d14f58c6](https://github.com/RueDeRennes/mosaik/commit/62d14f58c6))
- add shared styles for tab, table, and list components to improve UI consistency ([3915378683](https://github.com/RueDeRennes/mosaik/commit/3915378683))
- add shared styles for tree and wizard components to enhance UI consistency ([e3dbaf7ac2](https://github.com/RueDeRennes/mosaik/commit/e3dbaf7ac2))
- enhance persona and QR code components with improved theming and shared styles for consistency ([9a32c6f95f](https://github.com/RueDeRennes/mosaik/commit/9a32c6f95f))
- update floating action button and group styles with improved theming and shared properties for consistency ([09e2c90ca3](https://github.com/RueDeRennes/mosaik/commit/09e2c90ca3))
- enhance toggle button and dropdown button styles with improved theming and shared styles for consistency ([b7423c1248](https://github.com/RueDeRennes/mosaik/commit/b7423c1248))
- update slider and avatar components with improved theming and layout consistency ([e7977bb1c1](https://github.com/RueDeRennes/mosaik/commit/e7977bb1c1))
- add shared styles for slider, meter bar, meter ring, and progress ring components to enhance UI consistency ([09a6c723f0](https://github.com/RueDeRennes/mosaik/commit/09a6c723f0))
- enhance dialog and drawer components with shared styles and improved theming for consistency ([9f5a6c1057](https://github.com/RueDeRennes/mosaik/commit/9f5a6c1057))
- add dialog component styles and theme configurations for improved UI consistency ([c3701084c0](https://github.com/RueDeRennes/mosaik/commit/c3701084c0))
- implement shared styles for ripple elements and add error/success/empty state components for improved consistency ([382d923011](https://github.com/RueDeRennes/mosaik/commit/382d923011))
- update chart themes to use local theme variables and unset default styles for improved consistency ([60aba50dec](https://github.com/RueDeRennes/mosaik/commit/60aba50dec))
- enhance Breadcrumb and Icon components with shared styles and update theme tokens for improved consistency ([43631aabb3](https://github.com/RueDeRennes/mosaik/commit/43631aabb3))
- add router and router-related styles for Joy and Default themes to enhance theming consistency ([33d4882612](https://github.com/RueDeRennes/mosaik/commit/33d4882612))
- update MenuItem and SearchBox styles for improved theming consistency and add shared focus ring styles ([ac0b6710c5](https://github.com/RueDeRennes/mosaik/commit/ac0b6710c5))
- add shared SCSS styles for Menu and Chat components to enhance theming consistency ([b65b7d9d93](https://github.com/RueDeRennes/mosaik/commit/b65b7d9d93))
- update Avatar and Badge styles for improved theming and layout consistency ([d48699783b](https://github.com/RueDeRennes/mosaik/commit/d48699783b))
- add SCSS theme files for media components with shared styling mixins ([9def4b2004](https://github.com/RueDeRennes/mosaik/commit/9def4b2004))
- add SCSS files for media components with initial styling setup ([52eddb1e29](https://github.com/RueDeRennes/mosaik/commit/52eddb1e29))
- update styles to use joy scheme variables for improved theme consistency ([5069a9cc96](https://github.com/RueDeRennes/mosaik/commit/5069a9cc96))
- introduce ITheme2ElementProps interface and enhance Theme2 with palette management ([fedd1abc19](https://github.com/RueDeRennes/mosaik/commit/fedd1abc19))
- implement ThemeGenerator and enhance Theme2Element with public theme application methods ([7c6e338528](https://github.com/RueDeRennes/mosaik/commit/7c6e338528))
- add event handling interfaces for improved event management ([eb8158af09](https://github.com/RueDeRennes/mosaik/commit/eb8158af09))
- hard scss refactoring ([847d18e07a](https://github.com/RueDeRennes/mosaik/commit/847d18e07a))
- update Angular dependencies to version 19.1.5 and add new build configurations ([caa65cbcd7](https://github.com/RueDeRennes/mosaik/commit/caa65cbcd7))
- add node-gyp as a dependency in package.json ([7ee58ddb29](https://github.com/RueDeRennes/mosaik/commit/7ee58ddb29))
- organize vitest workspace configuration by grouping libs, tools, and infra ([b914409938](https://github.com/RueDeRennes/mosaik/commit/b914409938))
- update package.json dependencies to use workspace references ([a09d328efb](https://github.com/RueDeRennes/mosaik/commit/a09d328efb))
- update documentation structure and add metadata for MVP and Command patterns ([aa740dcdc8](https://github.com/RueDeRennes/mosaik/commit/aa740dcdc8))
- add JSON and Markdown configurations to ESLint setup and update index for new configs ([67f5cb6cd9](https://github.com/RueDeRennes/mosaik/commit/67f5cb6cd9))
- add clear method to Renderer and update RouterOutletElement to use it for clearing slots ([e2fb12d2f6](https://github.com/RueDeRennes/mosaik/commit/e2fb12d2f6))
- add @prisma/extension-optimize dependency and enable optimization in PrismaService ([d09a4414dc](https://github.com/RueDeRennes/mosaik/commit/d09a4414dc))
- enhance resource serialization by adding metadata support in serializers and transformers ([d81c5fe981](https://github.com/RueDeRennes/mosaik/commit/d81c5fe981))
- update resource info interfaces to use readonly properties and enhance cloning functionality ([173c1c0d01](https://github.com/RueDeRennes/mosaik/commit/173c1c0d01))
- update CLI argument interfaces and improve resource generator imports ([52697bfaab](https://github.com/RueDeRennes/mosaik/commit/52697bfaab))
- add AI localizator module with configuration and CLI argument support ([38770963c7](https://github.com/RueDeRennes/mosaik/commit/38770963c7))
- add localizator executor and update related configurations ([79a5f1dd0d](https://github.com/RueDeRennes/mosaik/commit/79a5f1dd0d))
- add ESLint configuration for Vitest and implement resource type detection from file paths ([488198e242](https://github.com/RueDeRennes/mosaik/commit/488198e242))
- enhance sorting functionality in resource interfaces and update TypeScript configurations ([6fcb2f3903](https://github.com/RueDeRennes/mosaik/commit/6fcb2f3903))
- implement Vitest configuration and add tests for LitPreset; refactor file handling and update parser methods ([d7b49e2443](https://github.com/RueDeRennes/mosaik/commit/d7b49e2443))
- add ESLint and Vitest configurations, implement TypeScript settings, and define parser and formatter interfaces for localization ([c09d8c541a](https://github.com/RueDeRennes/mosaik/commit/c09d8c541a))
- add ESLint and Vitest configurations for localization tools and implement tests for Angular, React, and Vue presets ([22a450cdd4](https://github.com/RueDeRennes/mosaik/commit/22a450cdd4))
- update package.json files and add TypeScript configurations for localization ([577f8dd710](https://github.com/RueDeRennes/mosaik/commit/577f8dd710))
- implement parser interfaces and various parser classes for localization ([8b5b4258e1](https://github.com/RueDeRennes/mosaik/commit/8b5b4258e1))
- update project CommonJS/ESM TypeScript configurations ([b57802c2d9](https://github.com/RueDeRennes/mosaik/commit/b57802c2d9))
- migrate from lodash to es-toolkit for utility functions and update package dependencies ([cfdb4f64a1](https://github.com/RueDeRennes/mosaik/commit/cfdb4f64a1))
- add tsup configuration for Vite and Utilities, update LiveReload plugin options ([9d0b3a71be](https://github.com/RueDeRennes/mosaik/commit/9d0b3a71be))
- update Vite configuration and improve FileSystemWatcher filtering logic ([43a655b8ac](https://github.com/RueDeRennes/mosaik/commit/43a655b8ac))
- add Vite configuration and plugins, including live reload functionality ([92b0ee5260](https://github.com/RueDeRennes/mosaik/commit/92b0ee5260))
- remove obsolete BlockquoteProcessor tests and add utility functions for token metadata management ([11be8212a8](https://github.com/RueDeRennes/mosaik/commit/11be8212a8))
- add Vitest configuration and implement tests for Markdown processors ([10d745777c](https://github.com/RueDeRennes/mosaik/commit/10d745777c))
- add type annotations for hot update handler and improve import statements in processors ([6c28d98979](https://github.com/RueDeRennes/mosaik/commit/6c28d98979))
- integrate markdowner tool and update API paths for consistency ([21c276f79a](https://github.com/RueDeRennes/mosaik/commit/21c276f79a))
- initialize Mosaik.Elements library with TypeScript configuration and documentation ([121c1196a8](https://github.com/RueDeRennes/mosaik/commit/121c1196a8))
- add mosaik-elements-angular-2 library with initial component and configuration files ([2e4c734f9e](https://github.com/RueDeRennes/mosaik/commit/2e4c734f9e))
- add infrastructure build step to API development workflow ([4f77ea2b30](https://github.com/RueDeRennes/mosaik/commit/4f77ea2b30))
- implement new email delivery strategies ([71d732c67d](https://github.com/RueDeRennes/mosaik/commit/71d732c67d))
- add dependency installation step in GitHub Actions workflow ([0ee17aa199](https://github.com/RueDeRennes/mosaik/commit/0ee17aa199))
- add build infrastructure step and update project configurations with 'infra' tags ([355a7b0768](https://github.com/RueDeRennes/mosaik/commit/355a7b0768))
- add VERBOSE environment variable for detailed linting logs ([e3fe3fad69](https://github.com/RueDeRennes/mosaik/commit/e3fe3fad69))
- add CommandNamingRule for ESLint; update project configuration and enhance documentation ([21e0e36302](https://github.com/RueDeRennes/mosaik/commit/21e0e36302))
- add ICommand interface and implement delete profile view styles; update username references to userName across the codebase ([b7184a2d10](https://github.com/RueDeRennes/mosaik/commit/b7184a2d10))
- **api:** update Doppler configuration to support API key authentication and enhance documentation ([8e4c98a5e0](https://github.com/RueDeRennes/mosaik/commit/8e4c98a5e0))
- **api:** add doppler support for security keys ([bb1dd83041](https://github.com/RueDeRennes/mosaik/commit/bb1dd83041))
- **api:** add new issue models and update icon response; remove unused IIconGroup model ([d05cefc0ed](https://github.com/RueDeRennes/mosaik/commit/d05cefc0ed))
- add docs executor and update package dependencies across multiple libraries ([b55ff52fd4](https://github.com/RueDeRennes/mosaik/commit/b55ff52fd4))
- add GitHub Actions workflow for development app deployment with caching and build steps ([118b8a6bff](https://github.com/RueDeRennes/mosaik/commit/118b8a6bff))
- add SubscribeRequest and UnsubscribeRequest classes, update API response statuses to use HttpStatus, and enhance Prisma configuration for PostgreSQL ([7c49d4098d](https://github.com/RueDeRennes/mosaik/commit/7c49d4098d))
- add Database module and service, integrate with Issues and Newsletter repositories, and update TypeScript configuration ([238c8b509b](https://github.com/RueDeRennes/mosaik/commit/238c8b509b))
- update server port to 8080, add IssuesView and related styles, and enhance ApiService2 with issue management methods ([8e55d5be52](https://github.com/RueDeRennes/mosaik/commit/8e55d5be52))
- navigate to backend directory and list files before building Docker image ([bb4a5f8723](https://github.com/RueDeRennes/mosaik/commit/bb4a5f8723))
- enhance GitHub Actions workflow for Docker by adding artifact upload and improving repository name handling ([b93588e6d5](https://github.com/RueDeRennes/mosaik/commit/b93588e6d5))
- add .dockerignore for mosaik-api and log npm dependencies in build step ([d170a45722](https://github.com/RueDeRennes/mosaik/commit/d170a45722))
- add GitHub Actions workflow for Docker build and push to GHCR ([14f2ed37e1](https://github.com/RueDeRennes/mosaik/commit/14f2ed37e1))
- add backend code ([599d31af49](https://github.com/RueDeRennes/mosaik/commit/599d31af49))
- **nx-cloud:** setup nx cloud workspace ([9dfa175d05](https://github.com/RueDeRennes/mosaik/commit/9dfa175d05))
- add commitlint in repo ([4a71ed5158](https://github.com/RueDeRennes/mosaik/commit/4a71ed5158))
- upgrade to angular 12 ([e604cc6da3](https://github.com/RueDeRennes/mosaik/commit/e604cc6da3))
- **angular:** add cdk dependency to add new dialogService ([8c294ec672](https://github.com/RueDeRennes/mosaik/commit/8c294ec672))
- **commerce:** add new commerce package 🎉 ([b595653878](https://github.com/RueDeRennes/mosaik/commit/b595653878))
- **angular:** add camera recorder typings ([32a8ba560e](https://github.com/RueDeRennes/mosaik/commit/32a8ba560e))

### 🩹 Fixes

- update years of experience from eight to ten in the interview article ([9a728c51e8](https://github.com/RueDeRennes/mosaik/commit/9a728c51e8))
- update release script to version 0.0.77 ([ff9cf9223c](https://github.com/RueDeRennes/mosaik/commit/ff9cf9223c))
- update release script to version 0.0.76 ([fa4bb82518](https://github.com/RueDeRennes/mosaik/commit/fa4bb82518))
- downgrade yargs dependency from 18.0.0 to 17.7.2 in package.json and yarn.lock ([5467661a3f](https://github.com/RueDeRennes/mosaik/commit/5467661a3f))
- update template resolver and add new copy-templates task; include yargs dependency ([669d9a8603](https://github.com/RueDeRennes/mosaik/commit/669d9a8603))
- correct entry file casing in ng-package.json and vite.config.mjs; add TypeScript dependency in package.json and yarn.lock ([fbb6c9614d](https://github.com/RueDeRennes/mosaik/commit/fbb6c9614d))
- standardize title formatting in documentation files ([8899b6307c](https://github.com/RueDeRennes/mosaik/commit/8899b6307c))
- update IconNameDirective to use 'icon' property instead of 'data' for icon name functionality ([af7d70822c](https://github.com/RueDeRennes/mosaik/commit/af7d70822c))
- add missing newline at end of package.json ([649ed1b503](https://github.com/RueDeRennes/mosaik/commit/649ed1b503))
- **dependencies:** add @rollup/plugin-json to package.json refactor: simplify build script in openapi templates ([f6a6476388](https://github.com/RueDeRennes/mosaik/commit/f6a6476388))
- **dependencies:** update peer dependency for vite to support versions 6.x and 7.x refactor: remove unused plugins from nx configuration fix: update build script in openapi templates to use yarn ([0422a23610](https://github.com/RueDeRennes/mosaik/commit/0422a23610))
- **dependencies:** update vite to version 7.0.2 in package.json and yarn.lock ([b6b2b61b42](https://github.com/RueDeRennes/mosaik/commit/b6b2b61b42))
- **dependencies:** update @nx packages to version 21.2.2 ([c044affa8d](https://github.com/RueDeRennes/mosaik/commit/c044affa8d))
- update release script to version 0.0.71 ([c3e7e5e8bf](https://github.com/RueDeRennes/mosaik/commit/c3e7e5e8bf))
- add missing newline at end of package.json ([73866991d5](https://github.com/RueDeRennes/mosaik/commit/73866991d5))
- update background color to transparent for page header and menu components; update release script to version 0.0.70 ([e8e7c124a4](https://github.com/RueDeRennes/mosaik/commit/e8e7c124a4))
- update release version to 0.0.47 in package.json ([5a277d2d1d](https://github.com/RueDeRennes/mosaik/commit/5a277d2d1d))
- correct spelling of 'HTML' in keywords and add new article on `part` attributes ([cd5b688a5c](https://github.com/RueDeRennes/mosaik/commit/cd5b688a5c))
- correct quotation marks in attribute selector examples for consistency ([078a6c9289](https://github.com/RueDeRennes/mosaik/commit/078a6c9289))
- correct quotation marks in markdown article and improve blockquote rendering in MarkdownRenderer ([09442e4509](https://github.com/RueDeRennes/mosaik/commit/09442e4509))
- update release script to version 0.0.41 ([88efd1b9ca](https://github.com/RueDeRennes/mosaik/commit/88efd1b9ca))
- adjust height calculations for content in AppElement styles ([1d8793fd52](https://github.com/RueDeRennes/mosaik/commit/1d8793fd52))
- update const vs enum article to use string literals for WorkType values ([3eb355434e](https://github.com/RueDeRennes/mosaik/commit/3eb355434e))
- correct quotation marks in best practices section of const vs enum article ([df4187ec19](https://github.com/RueDeRennes/mosaik/commit/df4187ec19))
- update backdrop image URLs in const vs enum article ([e05a779a0a](https://github.com/RueDeRennes/mosaik/commit/e05a779a0a))
- update release version to 0.0.38 in package.json and improve description formatting in Meta.g.json ([edbd04421c](https://github.com/RueDeRennes/mosaik/commit/edbd04421c))
- correct formatting of region comments and quote attribution for clarity ([952d90f14b](https://github.com/RueDeRennes/mosaik/commit/952d90f14b))
- update provideTheme function to simplify overrides and adjust merge function ([0359c488be](https://github.com/RueDeRennes/mosaik/commit/0359c488be))
- update provideTheme to useValue for theme and mode signals ([5a7b509869](https://github.com/RueDeRennes/mosaik/commit/5a7b509869))
- update release script to version 0.0.33 ([0954fadfa3](https://github.com/RueDeRennes/mosaik/commit/0954fadfa3))
- update markdowner-core dependency to use workspace reference for consistency ([518dffba42](https://github.com/RueDeRennes/mosaik/commit/518dffba42))
- simplify flex-basis and max-width calculations in WrapElement for improved readability ([0fba2a2eef](https://github.com/RueDeRennes/mosaik/commit/0fba2a2eef))
- change progress/ring/bar number properties to cssLength for simpler data binding ([d15e88f0c9](https://github.com/RueDeRennes/mosaik/commit/d15e88f0c9))
- update checkbox styles by removing unnecessary padding and border properties feat: add YouTube video embed and quote to interview markdown fix: adjust marker color in markdown styles for better visibility ([1284a2bcff](https://github.com/RueDeRennes/mosaik/commit/1284a2bcff))
- correct quotes in interview markdown and enhance closing statements ([8d0e7134ba](https://github.com/RueDeRennes/mosaik/commit/8d0e7134ba))
- correct formatting and update YouTube link in interview markdown ([2b430a99bc](https://github.com/RueDeRennes/mosaik/commit/2b430a99bc))
- **docs:** update route in command-pattern-vue.md for correct path; remove outdated mvp.requirements.md file; add comprehensive requirements documentation ([12dd351358](https://github.com/RueDeRennes/mosaik/commit/12dd351358))
- **build:** reorder build steps in deployment script for clarity and consistency ([4e746f0b36](https://github.com/RueDeRennes/mosaik/commit/4e746f0b36))
- correct spelling and casing in IconsService and related files ([f4d478699e](https://github.com/RueDeRennes/mosaik/commit/f4d478699e))
- update build commands in CI workflows to use 'yarn nx run' syntax ([a38e725929](https://github.com/RueDeRennes/mosaik/commit/a38e725929))
- update description of mosaik-api in README.md for clarity ([478b4c5177](https://github.com/RueDeRennes/mosaik/commit/478b4c5177))
- restore missing languages and sites in app.json configuration ([ad5f019e46](https://github.com/RueDeRennes/mosaik/commit/ad5f019e46))
- adjust positioning for lightChain and update CookieConsentElement attributes ([708c9832bd](https://github.com/RueDeRennes/mosaik/commit/708c9832bd))
- remove verbose flag from mosaik app build command ([f8f2b53714](https://github.com/RueDeRennes/mosaik/commit/f8f2b53714))
- update theme import paths to use consistent casing ([1aa18b699e](https://github.com/RueDeRennes/mosaik/commit/1aa18b699e))
- hide portal element by default in TimeBoxElementTemplate ([f5f16c13b7](https://github.com/RueDeRennes/mosaik/commit/f5f16c13b7))
- add missing newline at end of package.json ([713cb1f983](https://github.com/RueDeRennes/mosaik/commit/713cb1f983))
- simplify condition checks and remove unnecessary styles in various components ([41e6b5d8a9](https://github.com/RueDeRennes/mosaik/commit/41e6b5d8a9))
- update release script to version 0.0.28 ([baaef44d1d](https://github.com/RueDeRennes/mosaik/commit/baaef44d1d))
- update hover and selection styles for TabStrip and Tree components ([d6c90fc2bb](https://github.com/RueDeRennes/mosaik/commit/d6c90fc2bb))
- add missing newline at end of package.json ([39f2f1c578](https://github.com/RueDeRennes/mosaik/commit/39f2f1c578))
- update TabStrip and TreeItem styles to handle disabled state correctly ([ecb60798db](https://github.com/RueDeRennes/mosaik/commit/ecb60798db))
- update release version to 0.0.19 in package.json ([acccb56f76](https://github.com/RueDeRennes/mosaik/commit/acccb56f76))
- add missing newline at end of package.json ([43ce0e6a3b](https://github.com/RueDeRennes/mosaik/commit/43ce0e6a3b))
- correct spelling of 'getScrollableElement' and remove unused method ([72e17ecc7a](https://github.com/RueDeRennes/mosaik/commit/72e17ecc7a))
- correct spelling of 'success' in logSummary parameter documentation chore: update release script version to 0.0.16 chore: add 'keyhandle' to cspell words ([1a9d5e8732](https://github.com/RueDeRennes/mosaik/commit/1a9d5e8732))
- improve type handling and cleanup in Invalidable, CheckBoxGroup, ChoiceGroup, and RadioGroup components ([84753f810c](https://github.com/RueDeRennes/mosaik/commit/84753f810c))
- correct spelling of "Emitts" to "Emits" in event documentation across multiple components ([17e025c185](https://github.com/RueDeRennes/mosaik/commit/17e025c185))
- correct spelling errors in README and update release version in package.json ([922364afec](https://github.com/RueDeRennes/mosaik/commit/922364afec))
- different themes and styles ([917e55212d](https://github.com/RueDeRennes/mosaik/commit/917e55212d))
- add missing words to cSpell configuration ([933dd56139](https://github.com/RueDeRennes/mosaik/commit/933dd56139))
- correct spelling errors and improve property names in interfaces and components ([e7edf69f3e](https://github.com/RueDeRennes/mosaik/commit/e7edf69f3e))
- remove OTP prompt from publish package task and update related function signatures ([a684f8dc7e](https://github.com/RueDeRennes/mosaik/commit/a684f8dc7e))
- disable caching in project configurations and update build scripts for consistency ([0bf27cb99e](https://github.com/RueDeRennes/mosaik/commit/0bf27cb99e))
- add missing newline at end of package.json files across multiple directories ([a01c97ed2b](https://github.com/RueDeRennes/mosaik/commit/a01c97ed2b))
- correct build script command for SCSS and update build commands in project configuration ([0b243a90be](https://github.com/RueDeRennes/mosaik/commit/0b243a90be))
- update theme in index.html and enhance logging in CopyPublisherPackageJson.ts; add release targets to project.json files; remove obsolete scripts ([648a850c12](https://github.com/RueDeRennes/mosaik/commit/648a850c12))
- correct package name format in changeset configuration and add release script to package.json ([168113d104](https://github.com/RueDeRennes/mosaik/commit/168113d104))
- update package.json dependencies to use version 0.0.0 for consistency across all packages ([9b37f5626c](https://github.com/RueDeRennes/mosaik/commit/9b37f5626c))
- revert package versions to 0.0.0 for consistency across all packages ([8e39bb4e60](https://github.com/RueDeRennes/mosaik/commit/8e39bb4e60))
- update disabled state handling for various components ([bbabccda83](https://github.com/RueDeRennes/mosaik/commit/bbabccda83))
- update Angular dependencies to use caret versioning and remove unused mosaik-elements-angular-2 entry ([65f2f21abf](https://github.com/RueDeRennes/mosaik/commit/65f2f21abf))
- Refactor LitStyleTransform to remove unnecessary timing logs; update ExpanderElement styles for improved theming support ([3ca2b0d734](https://github.com/RueDeRennes/mosaik/commit/3ca2b0d734))
- Correct cache option handling across multiple executors and tasks ([bdbcb05c08](https://github.com/RueDeRennes/mosaik/commit/bdbcb05c08))
- update SKIP_LINT variable to use lowercase 'true' for consistency ([319f15f508](https://github.com/RueDeRennes/mosaik/commit/319f15f508))
- restore 'detect' configuration in project.json and update package manager version in package.json ([ff659684a6](https://github.com/RueDeRennes/mosaik/commit/ff659684a6))
- ensure form elements inherit styles correctly in formElementJoyStyle ([8c3dc71259](https://github.com/RueDeRennes/mosaik/commit/8c3dc71259))
- change constructor visibility from protected to public in StateElement class ([4fdc37f008](https://github.com/RueDeRennes/mosaik/commit/4fdc37f008))
- update theme default settings and padding values for improved consistency across card components ([11c519bf66](https://github.com/RueDeRennes/mosaik/commit/11c519bf66))
- update background color and padding values to unset for improved theme consistency across components ([fe22eaa2ca](https://github.com/RueDeRennes/mosaik/commit/fe22eaa2ca))
- update shared-style mixin to use local $name variable for consistency across components ([dc5fdb55df](https://github.com/RueDeRennes/mosaik/commit/dc5fdb55df))
- update yarn clean script to remove force option ([723efb5c42](https://github.com/RueDeRennes/mosaik/commit/723efb5c42))
- add missing React and Vue dependencies to package.json ([ee2fb6360f](https://github.com/RueDeRennes/mosaik/commit/ee2fb6360f))
- update TypeScript configurations for consistency and readability ([a74cd93fc1](https://github.com/RueDeRennes/mosaik/commit/a74cd93fc1))
- update dependencies in package.json files to latest versions ([00c4430b43](https://github.com/RueDeRennes/mosaik/commit/00c4430b43))
- update package.json to add Angular DevKit and Nx dependencies ([d86b800714](https://github.com/RueDeRennes/mosaik/commit/d86b800714))
- format json configuration files for consistency and readability ([f4e4b56db6](https://github.com/RueDeRennes/mosaik/commit/f4e4b56db6))
- update .gitignore to simplify custom entries and add Angular build artifacts ([8dbc5e0cfe](https://github.com/RueDeRennes/mosaik/commit/8dbc5e0cfe))
- add 'mosaik-ng' to package.json and clean up ToastComponent code with consistent formatting ([8871b31d8b](https://github.com/RueDeRennes/mosaik/commit/8871b31d8b))
- add Angular CLI to install script and update EventEmitter definitions for consistency across components ([d46388649e](https://github.com/RueDeRennes/mosaik/commit/d46388649e))
- remove unnecessary comments and continue-on-error flags in lint jobs for clarity ([a5cc2fbfe3](https://github.com/RueDeRennes/mosaik/commit/a5cc2fbfe3))
- simplify lint command in GitHub Actions workflow ([f6324c6be3](https://github.com/RueDeRennes/mosaik/commit/f6324c6be3))
- enable verbose linting for mosaik-elements-foundation ([9262eb8c5b](https://github.com/RueDeRennes/mosaik/commit/9262eb8c5b))
- correct SKIP_LINT environment variable to use lowercase 'false' ([e04ba33fb4](https://github.com/RueDeRennes/mosaik/commit/e04ba33fb4))
- update API endpoint to use Render URL instead of localhost ([3f3df24c15](https://github.com/RueDeRennes/mosaik/commit/3f3df24c15))
- update deployment path in GitHub Actions workflow for backend API ([4d9721e02f](https://github.com/RueDeRennes/mosaik/commit/4d9721e02f))
- remove redundant ls command from Docker build step in GitHub Actions workflow ([35074e3608](https://github.com/RueDeRennes/mosaik/commit/35074e3608))
- remove redundant npm list commands in GitHub Actions build step ([88cbee4e84](https://github.com/RueDeRennes/mosaik/commit/88cbee4e84))
- update GitHub Actions workflow to install npm packages and list global dependencies ([eda5a6b1f9](https://github.com/RueDeRennes/mosaik/commit/eda5a6b1f9))
- update build step in GitHub Actions to list global npm packages ([f53cf75b47](https://github.com/RueDeRennes/mosaik/commit/f53cf75b47))
- meta path ([7a3bdb39ef](https://github.com/RueDeRennes/mosaik/commit/7a3bdb39ef))

## 0.0.77 (2025-07-09)

### 🩹 Fixes

- update release script to version 0.0.76 ([fa4bb82518](https://github.com/RueDeRennes/mosaik/commit/fa4bb82518))
- downgrade yargs dependency from 18.0.0 to 17.7.2 in package.json and yarn.lock ([5467661a3f](https://github.com/RueDeRennes/mosaik/commit/5467661a3f))
- update template resolver and add new copy-templates task; include yargs dependency ([669d9a8603](https://github.com/RueDeRennes/mosaik/commit/669d9a8603))
- correct entry file casing in ng-package.json and vite.config.mjs; add TypeScript dependency in package.json and yarn.lock ([fbb6c9614d](https://github.com/RueDeRennes/mosaik/commit/fbb6c9614d))

## 0.0.76 (2025-07-08)

### 🚀 Features

- add expand, collapse, and toggle methods to MenuItem and TreeItem components with descriptions ([8881f5f730](https://github.com/RueDeRennes/mosaik/commit/8881f5f730))
- add IExpandable interface and implement expandable functionality in MenuItemElement, TreeItemElement, and ExpandableElement ([f2fb5df205](https://github.com/RueDeRennes/mosaik/commit/f2fb5df205))
- implement ColorTableElement component with associated template and styles ([a5bc0a091a](https://github.com/RueDeRennes/mosaik/commit/a5bc0a091a))
- add copyExecutorsJson script and update build commands ([0a0aba85b9](https://github.com/RueDeRennes/mosaik/commit/0a0aba85b9))
- update Carousel component methods and add select method implementation ([351e68a615](https://github.com/RueDeRennes/mosaik/commit/351e68a615))
- update menu component styles and structure for improved layout and responsiveness ([373095056e](https://github.com/RueDeRennes/mosaik/commit/373095056e))
- add icon functionality with IconDirective and IconRegistry, enhance app layout with new directives ([8acea01349](https://github.com/RueDeRennes/mosaik/commit/8acea01349))
- enhance app layout and styling with new components and responsive design ([8919fccc0c](https://github.com/RueDeRennes/mosaik/commit/8919fccc0c))
- enhance Jumbotron components with slot definitions and improve HideOnScrollController methods ([4cc6d9de3a](https://github.com/RueDeRennes/mosaik/commit/4cc6d9de3a))
- Add formatter property to Jumbotron components and update related files ([9ae59c7ff9](https://github.com/RueDeRennes/mosaik/commit/9ae59c7ff9))
- Add Svelte titles to German and English translations; update formatting keys in various components ([9889da1578](https://github.com/RueDeRennes/mosaik/commit/9889da1578))
- Add Jumbotron component and related styles for multiple frameworks ([41d4601e08](https://github.com/RueDeRennes/mosaik/commit/41d4601e08))
- enhance backdrop styles and refactor breakpoint handling ([39661be30c](https://github.com/RueDeRennes/mosaik/commit/39661be30c))
- Update layout variables for Cosmopolitan and Joy themes in various components ([af9ca676db](https://github.com/RueDeRennes/mosaik/commit/af9ca676db))
- Introduce Indicator component across multiple frameworks ([7ef850c39d](https://github.com/RueDeRennes/mosaik/commit/7ef850c39d))
- Update Indicator component styles and tokens for layout spacing ([201ee59059](https://github.com/RueDeRennes/mosaik/commit/201ee59059))
- Add Indicator component and related functionality ([b55b86b0e2](https://github.com/RueDeRennes/mosaik/commit/b55b86b0e2))
- implement animation directive and provider with presets ([09550b6633](https://github.com/RueDeRennes/mosaik/commit/09550b6633))
- enhance theme merging logic and add support for deep partial overrides ([870d64b42b](https://github.com/RueDeRennes/mosaik/commit/870d64b42b))
- Remove unused 'onInput' method from ColorPicker components and update related code ([d84ece1672](https://github.com/RueDeRennes/mosaik/commit/d84ece1672))
- Add Svelte support with SvelteCodeGenerator and update build scripts ([955cb75cb6](https://github.com/RueDeRennes/mosaik/commit/955cb75cb6))
- Add new Svelte components for menu, segment, tab, table, tree, wizard, and shell ([e6de8f0553](https://github.com/RueDeRennes/mosaik/commit/e6de8f0553))
- add Color Palette Builder tool and associated views ([55a992138e](https://github.com/RueDeRennes/mosaik/commit/55a992138e))
- add comprehensive article on using const vs enums in TypeScript with Angular templates ([8db46644e3](https://github.com/RueDeRennes/mosaik/commit/8db46644e3))
- add hasHeader and hasNav properties to AppElement and update related components ([37baedabae](https://github.com/RueDeRennes/mosaik/commit/37baedabae))
- add localizator-core dependency and update build dependencies in project configuration ([077a2cd1d9](https://github.com/RueDeRennes/mosaik/commit/077a2cd1d9))
- add FlexDirective for flexible layout management in Angular ([3b8f27e2b7](https://github.com/RueDeRennes/mosaik/commit/3b8f27e2b7))
- add comprehensive guide on the power of regions in TypeScript for improved code organization ([564b600288](https://github.com/RueDeRennes/mosaik/commit/564b600288))
- add theme provider for angular ([04568d1528](https://github.com/RueDeRennes/mosaik/commit/04568d1528))
- update masonry and wrap elements to use CSS variables for gap and columns, enhance templates with static styles ([2dee486060](https://github.com/RueDeRennes/mosaik/commit/2dee486060))
- disable eslint rule for static styles in multiple component templates and update SCSS mixin to exclude properties ([d6e61ac195](https://github.com/RueDeRennes/mosaik/commit/d6e61ac195))
- enhance keyboard element with modifier key support and update styles ([07f7af6d52](https://github.com/RueDeRennes/mosaik/commit/07f7af6d52))
- enhance dropdown button templates with new icons and improved layout fix: adjust padding for menu item group headers across themes ([5004c67e11](https://github.com/RueDeRennes/mosaik/commit/5004c67e11))
- add 'Code' and 'TypeScript' keywords to various documentation files for improved discoverability ([7ac3c152dd](https://github.com/RueDeRennes/mosaik/commit/7ac3c152dd))
- add "The Dependency Forest" article on dependency management challenges in Angular ([d129b84490](https://github.com/RueDeRennes/mosaik/commit/d129b84490))
- add translation command and integrate translation functionality in BlogBaseElement ([7e166a6bea](https://github.com/RueDeRennes/mosaik/commit/7e166a6bea))
- enhance blog and translation features with interview type and language flags ([9aff64d29b](https://github.com/RueDeRennes/mosaik/commit/9aff64d29b))
- update interview content and add StickyController metadata in JSON ([c39d970be6](https://github.com/RueDeRennes/mosaik/commit/c39d970be6))
- add YouTube video rendering support in MarkdownRenderer ([723610d3c8](https://github.com/RueDeRennes/mosaik/commit/723610d3c8))
- Add new translation for "Open with" in code section ([e1b84033bc](https://github.com/RueDeRennes/mosaik/commit/e1b84033bc))
- create Playground components for testing Markdown features ([738f61002f](https://github.com/RueDeRennes/mosaik/commit/738f61002f))
- enhance Listen decorator to support custom query targets and improve event handling ([aa19e6e5a0](https://github.com/RueDeRennes/mosaik/commit/aa19e6e5a0))
- add PinchController for gesture recognition and enhance DiagramElement with centering functionality ([c3feb9a789](https://github.com/RueDeRennes/mosaik/commit/c3feb9a789))
- **docs:** Update documentation with new sections, descriptions, and examples for clarity and usability ([c32ff5f976](https://github.com/RueDeRennes/mosaik/commit/c32ff5f976))
- **docs:** Enhance MVP pattern documentation with detailed explanations and examples ([e3c97f1368](https://github.com/RueDeRennes/mosaik/commit/e3c97f1368))
- implement filter functionality in ArticlesView and update related templates ([1e88d302d4](https://github.com/RueDeRennes/mosaik/commit/1e88d302d4))
- Implement sticky positioning directive and controller, enhance scrolling functionality in Scroller class ([148f07916e](https://github.com/RueDeRennes/mosaik/commit/148f07916e))
- Enhance MVP documentation and examples across multiple frameworks ([cfabea14a3](https://github.com/RueDeRennes/mosaik/commit/cfabea14a3))
- add backdrop images and enhance ArticlesView with documentation grouping ([af72ff74cd](https://github.com/RueDeRennes/mosaik/commit/af72ff74cd))
- add images and enhance Markdown documentation with improved layout and structure ([1eaac2125f](https://github.com/RueDeRennes/mosaik/commit/1eaac2125f))
- enhance Markdown components with improved styling and layout variables ([780d383b31](https://github.com/RueDeRennes/mosaik/commit/780d383b31))
- enhance CodeEditor and Markdown components with improved language and theme support ([0270711752](https://github.com/RueDeRennes/mosaik/commit/0270711752))
- **callouts:** add new callout variants and enhance Markdown processing ([3a5608697b](https://github.com/RueDeRennes/mosaik/commit/3a5608697b))
- **markdowner:** enhance Markdown processing with new extension structure and build integration ([0c08852146](https://github.com/RueDeRennes/mosaik/commit/0c08852146))
- Enhance Markdown processing with new features and improvements ([534983c407](https://github.com/RueDeRennes/mosaik/commit/534983c407))
- **translations:** add share message for blog posts ([a3ba45071a](https://github.com/RueDeRennes/mosaik/commit/a3ba45071a))
- improve date formatting in BlogBase and enhance share command data structure ([6f64d0990e](https://github.com/RueDeRennes/mosaik/commit/6f64d0990e))
- enhance Markdown component styles with improved blockquote and list formatting ([dbefc8d12f](https://github.com/RueDeRennes/mosaik/commit/dbefc8d12f))
- refactor text overflow handling and enhance Markdown component styles ([62bb601fc7](https://github.com/RueDeRennes/mosaik/commit/62bb601fc7))
- Update AppSideNavTemplate to use node meta for display names and add value binding ([1488b7d52f](https://github.com/RueDeRennes/mosaik/commit/1488b7d52f))
- update metadata structure in documentation and improve avatar and chip components ([007bd05bea](https://github.com/RueDeRennes/mosaik/commit/007bd05bea))
- enhance Markdown rendering and styling with new link styles and tree directive support ([8fba55993c](https://github.com/RueDeRennes/mosaik/commit/8fba55993c))
- update markdown files to use structured keywords and add author information ([d0df1b883f](https://github.com/RueDeRennes/mosaik/commit/d0df1b883f))
- **docs): enhance keyword metadata across documentation files for improved searchability and context feat(Markdown): update MarkdownElement and MarkdownRenderer for better handling of text and code blocks fix(DocsService): refine getDocsTree method for improved documentation hierarchy and sorting fix(staticContent:** add meta information to static content registration for enhanced metadata handling ([789875e05d](https://github.com/RueDeRennes/mosaik/commit/789875e05d))
- **build:** add vite-plugins build step to deployment script; enhance MarkdownElement and DocsService for better handling of documentation and Markdown sources ([619a32e38b](https://github.com/RueDeRennes/mosaik/commit/619a32e38b))
- **menu:** add textOverflow property to MenuItemComponent and related elements for improved text handling; update DocsService and AppSideNavTemplate for better rendering ([9b7641b6c1](https://github.com/RueDeRennes/mosaik/commit/9b7641b6c1))
- **router:** implement RouterLocation and IRouterLocation for improved routing abstraction; refactor RouterElement to utilize new location handling ([53705c577a](https://github.com/RueDeRennes/mosaik/commit/53705c577a))
- **menu:** enhance menu item styles with indent properties and update theme tokens for better visual hierarchy ([b3dad3c306](https://github.com/RueDeRennes/mosaik/commit/b3dad3c306))
- **router:** enhance routing components with role attributes and update templates for better accessibility; refactor RouterController and RouterLinkDirective for improved functionality ([63b32829f1](https://github.com/RueDeRennes/mosaik/commit/63b32829f1))
- **router:** implement routerLink directive for dynamic link handling; update AppSideNavTemplate to use routerLink ([f2fb309d47](https://github.com/RueDeRennes/mosaik/commit/f2fb309d47))
- **router:** add RouterLinkDirective for dynamic link generation ([ab2e98ed50](https://github.com/RueDeRennes/mosaik/commit/ab2e98ed50))
- enhance package service and controller to support history retrieval with optional limit; update translations and styles for package explorer ([71efae2557](https://github.com/RueDeRennes/mosaik/commit/71efae2557))
- implement ShieldElement with template, style, and props; enhance package metadata and history models ([de73abbc76](https://github.com/RueDeRennes/mosaik/commit/de73abbc76))
- enhance package service and models with metadata and history retrieval ([05c98c197d](https://github.com/RueDeRennes/mosaik/commit/05c98c197d))
- add package manager installation step in CI workflow ([d8453719df](https://github.com/RueDeRennes/mosaik/commit/d8453719df))
- add eslint config build step to the dev deployment workflow ([c831986474](https://github.com/RueDeRennes/mosaik/commit/c831986474))
- add component selector to various sample elements for better integration ([3eb465fed5](https://github.com/RueDeRennes/mosaik/commit/3eb465fed5))
- Update button element CSS properties and enhance template styles ([c83ee77d83](https://github.com/RueDeRennes/mosaik/commit/c83ee77d83))
- Enhance sandbox functionality and UI improvements ([c45d7ca09b](https://github.com/RueDeRennes/mosaik/commit/c45d7ca09b))
- Implement ProjectionController for managing projected content in portals ([1bc46717b5](https://github.com/RueDeRennes/mosaik/commit/1bc46717b5))
- add TableFooter component and related styles ([85d9e96af5](https://github.com/RueDeRennes/mosaik/commit/85d9e96af5))
- Enhance state elements with padding and gap properties ([19074a8b51](https://github.com/RueDeRennes/mosaik/commit/19074a8b51))
- Enhance Select and Combo components with internationalization and improved styling ([8d80d58234](https://github.com/RueDeRennes/mosaik/commit/8d80d58234))
- enhance TagCloudElement with item selection and styling; refactor related components and styles ([2847e96a41](https://github.com/RueDeRennes/mosaik/commit/2847e96a41))
- add ModifierKeyName export and improve attr() function in SCSS ([317b75143d](https://github.com/RueDeRennes/mosaik/commit/317b75143d))
- Refactor CheckBoxGroupSample and TextBoxSample components for improved property formatting ([b0fcc7502e](https://github.com/RueDeRennes/mosaik/commit/b0fcc7502e))
- add default values for boolean attributes across various components ([899d593ba5](https://github.com/RueDeRennes/mosaik/commit/899d593ba5))
- update release script to version 0.0.26 ([11e2fdbc4f](https://github.com/RueDeRennes/mosaik/commit/11e2fdbc4f))
- update release script to version 0.0.25 ([930ba60eb4](https://github.com/RueDeRennes/mosaik/commit/930ba60eb4))
- update version to 0.0.24 and remove prefix/suffix styles from various components ([d061c7f8cd](https://github.com/RueDeRennes/mosaik/commit/d061c7f8cd))
- update appearance of input components and add textAlign property ([5f7321b7a8](https://github.com/RueDeRennes/mosaik/commit/5f7321b7a8))
- Add text alignment support to input components ([0a1069f47d](https://github.com/RueDeRennes/mosaik/commit/0a1069f47d))
- Add Validators class to Cdk for form validation ([5db8b51601](https://github.com/RueDeRennes/mosaik/commit/5db8b51601))
- add spinner and textAlign properties to NumberBox and TextBox components ([cda90dffa4](https://github.com/RueDeRennes/mosaik/commit/cda90dffa4))
- implement flip component with new side property and directives ([2b3c56c9b4](https://github.com/RueDeRennes/mosaik/commit/2b3c56c9b4))
- add select component to auth form and improve validation ([4971bba07f](https://github.com/RueDeRennes/mosaik/commit/4971bba07f))
- add Invalidable behavior and validity check to components ([893bb30b3b](https://github.com/RueDeRennes/mosaik/commit/893bb30b3b))
- add ng forms validation trigger ([e430f70f31](https://github.com/RueDeRennes/mosaik/commit/e430f70f31))
- update project dependencies and build configurations ([569b1bf99d](https://github.com/RueDeRennes/mosaik/commit/569b1bf99d))
- **eslint:** add TypeScript ESLint configuration with comprehensive ruleset ([4d7a0d88b7](https://github.com/RueDeRennes/mosaik/commit/4d7a0d88b7))
- Add Insetable behavior and update BoxElement styles ([ca740ab5f2](https://github.com/RueDeRennes/mosaik/commit/ca740ab5f2))
- export dateTimeBoxElementValueAccessor alongside DateTimeBoxElementValueAccessor for improved accessibility ([fad7497ba7](https://github.com/RueDeRennes/mosaik/commit/fad7497ba7))
- enhance project configurations with inputs and outputs for build targets ([6f80d15bda](https://github.com/RueDeRennes/mosaik/commit/6f80d15bda))
- **PublishPackage:** add version validation and improve error logging ([33ad436126](https://github.com/RueDeRennes/mosaik/commit/33ad436126))
- update package dependencies to use workspace references ([e853ec04e5](https://github.com/RueDeRennes/mosaik/commit/e853ec04e5))
- add changelog configuration to disable author rendering and update release script to specify group ([9ce709c251](https://github.com/RueDeRennes/mosaik/commit/9ce709c251))
- update version generator options to include installArgs and installIgnoreScripts ([747191d4da](https://github.com/RueDeRennes/mosaik/commit/747191d4da))
- streamline release configuration by consolidating project relationships and removing redundant properties ([77fbfcd293](https://github.com/RueDeRennes/mosaik/commit/77fbfcd293))
- add version configuration for conventional commits and generator options ([bd6048596e](https://github.com/RueDeRennes/mosaik/commit/bd6048596e))
- update release configuration to set projectsRelationship to fixed for libs, infra, and tools ([bc0437f95d](https://github.com/RueDeRennes/mosaik/commit/bc0437f95d))
- restructure release configuration to include groups for libs, infra, and tools ([fe9e93b5ce](https://github.com/RueDeRennes/mosaik/commit/fe9e93b5ce))
- update documentation paths and add index file for mosaik-elements-foundation package ([ced717bdea](https://github.com/RueDeRennes/mosaik/commit/ced717bdea))
- update package dependencies to use caret (^) versioning for consistency ([2d8ab96c84](https://github.com/RueDeRennes/mosaik/commit/2d8ab96c84))
- add dependency management for publish targets in project configurations ([e13de9a63b](https://github.com/RueDeRennes/mosaik/commit/e13de9a63b))
- enhance release script to include build and publish targets ([0c29b15d46](https://github.com/RueDeRennes/mosaik/commit/0c29b15d46))
- update package.json dependencies to use specific versions instead of workspace references ([4934f88dc1](https://github.com/RueDeRennes/mosaik/commit/4934f88dc1))
- update project configurations to enable caching and adjust input paths for build targets ([4e8b485497](https://github.com/RueDeRennes/mosaik/commit/4e8b485497))
- add copy-dependencies and publish-package executors; update project.json to use new publish executor ([ba4c5f9393](https://github.com/RueDeRennes/mosaik/commit/ba4c5f9393))
- add changesets for versioning and changelog management ([00db6e0ef1](https://github.com/RueDeRennes/mosaik/commit/00db6e0ef1))
- add semver package for version validation in CopyPublisherPackageJson task ([f848b73d49](https://github.com/RueDeRennes/mosaik/commit/f848b73d49))
- Refactor components to support standalone mode and add method invocation capabilities ([3312924aa2](https://github.com/RueDeRennes/mosaik/commit/3312924aa2))
- **dialog:** implement DialogRef and DialogService for enhanced dialog management ([e1c0b0d850](https://github.com/RueDeRennes/mosaik/commit/e1c0b0d850))
- define custom elements for various components in Mosaik Elements Angular ([cb6a1d5ef2](https://github.com/RueDeRennes/mosaik/commit/cb6a1d5ef2))
- Implement default file cleanup script and enhance component styles ([3aff5d6fd8](https://github.com/RueDeRennes/mosaik/commit/3aff5d6fd8))
- Add Electronic Program Guide components for Angular, React, and Vue ([b62f3f59fc](https://github.com/RueDeRennes/mosaik/commit/b62f3f59fc))
- Add theme change handling and improve dialog dimensions in AppSettingsView; enhance InkBarElement alignment logic ([71da43e4b1](https://github.com/RueDeRennes/mosaik/commit/71da43e4b1))
- Enhance LitStyleTransform with dependency analysis and improve logging; add memphis anchor element styles ([730b58ed42](https://github.com/RueDeRennes/mosaik/commit/730b58ed42))
- Enhance PropertyDecorator to support CSS variable binding for style properties ([5273291343](https://github.com/RueDeRennes/mosaik/commit/5273291343))
- add Boundable behavior and utility functions for date handling ([1deae6f00a](https://github.com/RueDeRennes/mosaik/commit/1deae6f00a))
- Add Joy theme styles for Electronic Program Guide components ([7c76dce194](https://github.com/RueDeRennes/mosaik/commit/7c76dce194))
- Enhance Coupon and Highlight components with improved styles and user-select properties ([7de39c4dee](https://github.com/RueDeRennes/mosaik/commit/7de39c4dee))
- Enhance Electronic Program Guide with new properties and styling adjustments ([d2aed27576](https://github.com/RueDeRennes/mosaik/commit/d2aed27576))
- Add Electronic Program Guide components and styles ([4d7c1d2f49](https://github.com/RueDeRennes/mosaik/commit/4d7c1d2f49))
- **expander:** update styles for Cosmopolitan, Default, Joy, and Memphis themes to enhance shadow properties and improve consistency ([78f0a88ebe](https://github.com/RueDeRennes/mosaik/commit/78f0a88ebe))
- **button:** enhance button styles with shadow and color properties ([46e28550b4](https://github.com/RueDeRennes/mosaik/commit/46e28550b4))
- **tokens:** restructure elevation tokens for better granularity and linting ([d921d201d3](https://github.com/RueDeRennes/mosaik/commit/d921d201d3))
- **tokens:** enhance elevation and typography tokens across themes ([4fca67fd43](https://github.com/RueDeRennes/mosaik/commit/4fca67fd43))
- **theme:** enhance theme management and button styles with new properties and variants ([e733f777e9](https://github.com/RueDeRennes/mosaik/commit/e733f777e9))
- **theme:** enhance Memphis theme with additional variants and update component styles ([6d869ec358](https://github.com/RueDeRennes/mosaik/commit/6d869ec358))
- Update ToggleTip component styles and tokens across themes ([c30920e681](https://github.com/RueDeRennes/mosaik/commit/c30920e681))
- Update theme components and tokens for consistency and improved styling ([ffb9596405](https://github.com/RueDeRennes/mosaik/commit/ffb9596405))
- Enhance Memphis theme with new elevation and appearance tokens ([0c9a0084ec](https://github.com/RueDeRennes/mosaik/commit/0c9a0084ec))
- update chart component styles for improved tooltip and legend formatting ([1037a3fa9a](https://github.com/RueDeRennes/mosaik/commit/1037a3fa9a))
- update chart component styles and themes to use Joy typography variables ([8fe7d7f4fe](https://github.com/RueDeRennes/mosaik/commit/8fe7d7f4fe))
- enhance chart and form elements with foreground color support and style adjustments ([dad0dd53df](https://github.com/RueDeRennes/mosaik/commit/dad0dd53df))
- implement theme persistence and configuration storage, update ToastService and RatingElement properties ([2fe40b8ee8](https://github.com/RueDeRennes/mosaik/commit/2fe40b8ee8))
- add installation and setup for package manager in the workflow ([1498f235f9](https://github.com/RueDeRennes/mosaik/commit/1498f235f9))
- add support for package manager setup in the dev workflow ([59aaf6b708](https://github.com/RueDeRennes/mosaik/commit/59aaf6b708))
- update banner appearance to 'soft' across multiple views and adjust button styles for improved consistency ([36804f1758](https://github.com/RueDeRennes/mosaik/commit/36804f1758))
- implement tab panel component with scrollable content and improved selection logic ([a5766822e0](https://github.com/RueDeRennes/mosaik/commit/a5766822e0))
- update App settings view template to enhance layout and add text case directive ([d3b4963491](https://github.com/RueDeRennes/mosaik/commit/d3b4963491))
- Add options for mode and focus delegation in Drawer components ([2439ae5ada](https://github.com/RueDeRennes/mosaik/commit/2439ae5ada))
- Add appearance property to mosaik-toolbar in chat header template ([0dafe85e1f](https://github.com/RueDeRennes/mosaik/commit/0dafe85e1f))
- Add initial QR Code Cosmopolitan theme styles and structure ([ec12f33544](https://github.com/RueDeRennes/mosaik/commit/ec12f33544))
- Enhance wizard and state elements with new styles and responsive design ([f7bbd2303c](https://github.com/RueDeRennes/mosaik/commit/f7bbd2303c))
- Update Persona and QR Code themes with new styles and tokens ([dfb5030cd8](https://github.com/RueDeRennes/mosaik/commit/dfb5030cd8))
- add style dictionary component generation and enhance SCSS file handling ([8cb9f0d702](https://github.com/RueDeRennes/mosaik/commit/8cb9f0d702))
- enhance SCSS file handling by adding default content population and improving path resolution ([d2a09333bc](https://github.com/RueDeRennes/mosaik/commit/d2a09333bc))
- implement memphis theme support and enhance theme handling across components ([6e6501b5d3](https://github.com/RueDeRennes/mosaik/commit/6e6501b5d3))
- enable multi-language support and add ColorSwatchGroupElement ([e15a8905a4](https://github.com/RueDeRennes/mosaik/commit/e15a8905a4))
- update theme to dark mode and refine color tokens for improved accessibility ([42819d5937](https://github.com/RueDeRennes/mosaik/commit/42819d5937))
- enhance theming support by adding size and layout properties to various components ([285a91ad39](https://github.com/RueDeRennes/mosaik/commit/285a91ad39))
- add appearance variants to toolbar and tab components for enhanced theming support ([275de74baa](https://github.com/RueDeRennes/mosaik/commit/275de74baa))
- enhance theming support by applying Themeable behavior to multiple component classes ([cd7b65f77b](https://github.com/RueDeRennes/mosaik/commit/cd7b65f77b))
- import Themeable behavior into various component files for enhanced theming support ([f9c34b371e](https://github.com/RueDeRennes/mosaik/commit/f9c34b371e))
- add size, duration, elevation, layout, and typography functions to Joy theme styles ([8d472f999c](https://github.com/RueDeRennes/mosaik/commit/8d472f999c))
- add Themeable mixin and import to component style templates ([60e2060c70](https://github.com/RueDeRennes/mosaik/commit/60e2060c70))
- update Joy theme styles for various components, adding new properties and improving consistency ([7eba0a5ea3](https://github.com/RueDeRennes/mosaik/commit/7eba0a5ea3))
- remove obsolete style files and add shared styles for Portal, Content, Floating, and MessageBox components ([dd521743ec](https://github.com/RueDeRennes/mosaik/commit/dd521743ec))
- add memphis theme styles for Chip and QRCode components, remove obsolete Spacer and Sticky styles ([e34f5ee454](https://github.com/RueDeRennes/mosaik/commit/e34f5ee454))
- remove obsolete style files and add new Joy theme styles for various components ([233ed63475](https://github.com/RueDeRennes/mosaik/commit/233ed63475))
- refactor theme styles for Card and CompoundButton components ([a3c49279c0](https://github.com/RueDeRennes/mosaik/commit/a3c49279c0))
- add shared styles for new UI components and update existing styles for consistency ([1772b383a7](https://github.com/RueDeRennes/mosaik/commit/1772b383a7))
- add default styles to Absolute and AbsoluteItem components ([dd26c85a21](https://github.com/RueDeRennes/mosaik/commit/dd26c85a21))
- add cosmopolitan theme style to various form and UI components ([0015925f0c](https://github.com/RueDeRennes/mosaik/commit/0015925f0c))
- enhance Floating Action Button with multiple theme styles ([10892ad232](https://github.com/RueDeRennes/mosaik/commit/10892ad232))
- MAJOR MIGRATION ([4118d0424b](https://github.com/RueDeRennes/mosaik/commit/4118d0424b))
- add script to create theme style templates for components and manage SCSS files ([a12659870b](https://github.com/RueDeRennes/mosaik/commit/a12659870b))
- add new theme styles for various components to enhance UI consistency ([271cecd764](https://github.com/RueDeRennes/mosaik/commit/271cecd764))
- update calendar and chipbox components with improved theming and styles for consistency ([7cdd9a1342](https://github.com/RueDeRennes/mosaik/commit/7cdd9a1342))
- add shared styles for calendar components to enhance UI consistency and layout ([9555e86fab](https://github.com/RueDeRennes/mosaik/commit/9555e86fab))
- enhance input components with improved theming and layout consistency ([5b5a41cf54](https://github.com/RueDeRennes/mosaik/commit/5b5a41cf54))
- enhance select and signature pad components with improved styles for consistency and usability ([8c4ff832f4](https://github.com/RueDeRennes/mosaik/commit/8c4ff832f4))
- add shared styles for grid, virtualize, absolute, tile list, masonry, and title layout components to enhance UI consistency ([cbe8204651](https://github.com/RueDeRennes/mosaik/commit/cbe8204651))
- add shared styles for BackTop and CookieConsent components to enhance UI consistency ([ea0800bf89](https://github.com/RueDeRennes/mosaik/commit/ea0800bf89))
- update chip component styles for improved theming and consistency across appearances ([e397515a48](https://github.com/RueDeRennes/mosaik/commit/e397515a48))
- add shared styles for toggletip, carousel, paginator, drop zone, backdrop, and other components to enhance UI consistency ([62d14f58c6](https://github.com/RueDeRennes/mosaik/commit/62d14f58c6))
- add shared styles for tab, table, and list components to improve UI consistency ([3915378683](https://github.com/RueDeRennes/mosaik/commit/3915378683))
- add shared styles for tree and wizard components to enhance UI consistency ([e3dbaf7ac2](https://github.com/RueDeRennes/mosaik/commit/e3dbaf7ac2))
- enhance persona and QR code components with improved theming and shared styles for consistency ([9a32c6f95f](https://github.com/RueDeRennes/mosaik/commit/9a32c6f95f))
- update floating action button and group styles with improved theming and shared properties for consistency ([09e2c90ca3](https://github.com/RueDeRennes/mosaik/commit/09e2c90ca3))
- enhance toggle button and dropdown button styles with improved theming and shared styles for consistency ([b7423c1248](https://github.com/RueDeRennes/mosaik/commit/b7423c1248))
- update slider and avatar components with improved theming and layout consistency ([e7977bb1c1](https://github.com/RueDeRennes/mosaik/commit/e7977bb1c1))
- add shared styles for slider, meter bar, meter ring, and progress ring components to enhance UI consistency ([09a6c723f0](https://github.com/RueDeRennes/mosaik/commit/09a6c723f0))
- enhance dialog and drawer components with shared styles and improved theming for consistency ([9f5a6c1057](https://github.com/RueDeRennes/mosaik/commit/9f5a6c1057))
- add dialog component styles and theme configurations for improved UI consistency ([c3701084c0](https://github.com/RueDeRennes/mosaik/commit/c3701084c0))
- implement shared styles for ripple elements and add error/success/empty state components for improved consistency ([382d923011](https://github.com/RueDeRennes/mosaik/commit/382d923011))
- update chart themes to use local theme variables and unset default styles for improved consistency ([60aba50dec](https://github.com/RueDeRennes/mosaik/commit/60aba50dec))
- enhance Breadcrumb and Icon components with shared styles and update theme tokens for improved consistency ([43631aabb3](https://github.com/RueDeRennes/mosaik/commit/43631aabb3))
- add router and router-related styles for Joy and Default themes to enhance theming consistency ([33d4882612](https://github.com/RueDeRennes/mosaik/commit/33d4882612))
- update MenuItem and SearchBox styles for improved theming consistency and add shared focus ring styles ([ac0b6710c5](https://github.com/RueDeRennes/mosaik/commit/ac0b6710c5))
- add shared SCSS styles for Menu and Chat components to enhance theming consistency ([b65b7d9d93](https://github.com/RueDeRennes/mosaik/commit/b65b7d9d93))
- update Avatar and Badge styles for improved theming and layout consistency ([d48699783b](https://github.com/RueDeRennes/mosaik/commit/d48699783b))
- add SCSS theme files for media components with shared styling mixins ([9def4b2004](https://github.com/RueDeRennes/mosaik/commit/9def4b2004))
- add SCSS files for media components with initial styling setup ([52eddb1e29](https://github.com/RueDeRennes/mosaik/commit/52eddb1e29))
- update styles to use joy scheme variables for improved theme consistency ([5069a9cc96](https://github.com/RueDeRennes/mosaik/commit/5069a9cc96))
- introduce ITheme2ElementProps interface and enhance Theme2 with palette management ([fedd1abc19](https://github.com/RueDeRennes/mosaik/commit/fedd1abc19))
- implement ThemeGenerator and enhance Theme2Element with public theme application methods ([7c6e338528](https://github.com/RueDeRennes/mosaik/commit/7c6e338528))
- add event handling interfaces for improved event management ([eb8158af09](https://github.com/RueDeRennes/mosaik/commit/eb8158af09))
- hard scss refactoring ([847d18e07a](https://github.com/RueDeRennes/mosaik/commit/847d18e07a))
- update Angular dependencies to version 19.1.5 and add new build configurations ([caa65cbcd7](https://github.com/RueDeRennes/mosaik/commit/caa65cbcd7))
- add node-gyp as a dependency in package.json ([7ee58ddb29](https://github.com/RueDeRennes/mosaik/commit/7ee58ddb29))
- organize vitest workspace configuration by grouping libs, tools, and infra ([b914409938](https://github.com/RueDeRennes/mosaik/commit/b914409938))
- update package.json dependencies to use workspace references ([a09d328efb](https://github.com/RueDeRennes/mosaik/commit/a09d328efb))
- update documentation structure and add metadata for MVP and Command patterns ([aa740dcdc8](https://github.com/RueDeRennes/mosaik/commit/aa740dcdc8))
- add JSON and Markdown configurations to ESLint setup and update index for new configs ([67f5cb6cd9](https://github.com/RueDeRennes/mosaik/commit/67f5cb6cd9))
- add clear method to Renderer and update RouterOutletElement to use it for clearing slots ([e2fb12d2f6](https://github.com/RueDeRennes/mosaik/commit/e2fb12d2f6))
- add @prisma/extension-optimize dependency and enable optimization in PrismaService ([d09a4414dc](https://github.com/RueDeRennes/mosaik/commit/d09a4414dc))
- enhance resource serialization by adding metadata support in serializers and transformers ([d81c5fe981](https://github.com/RueDeRennes/mosaik/commit/d81c5fe981))
- update resource info interfaces to use readonly properties and enhance cloning functionality ([173c1c0d01](https://github.com/RueDeRennes/mosaik/commit/173c1c0d01))
- update CLI argument interfaces and improve resource generator imports ([52697bfaab](https://github.com/RueDeRennes/mosaik/commit/52697bfaab))
- add AI localizator module with configuration and CLI argument support ([38770963c7](https://github.com/RueDeRennes/mosaik/commit/38770963c7))
- add localizator executor and update related configurations ([79a5f1dd0d](https://github.com/RueDeRennes/mosaik/commit/79a5f1dd0d))
- add ESLint configuration for Vitest and implement resource type detection from file paths ([488198e242](https://github.com/RueDeRennes/mosaik/commit/488198e242))
- enhance sorting functionality in resource interfaces and update TypeScript configurations ([6fcb2f3903](https://github.com/RueDeRennes/mosaik/commit/6fcb2f3903))
- implement Vitest configuration and add tests for LitPreset; refactor file handling and update parser methods ([d7b49e2443](https://github.com/RueDeRennes/mosaik/commit/d7b49e2443))
- add ESLint and Vitest configurations, implement TypeScript settings, and define parser and formatter interfaces for localization ([c09d8c541a](https://github.com/RueDeRennes/mosaik/commit/c09d8c541a))
- add ESLint and Vitest configurations for localization tools and implement tests for Angular, React, and Vue presets ([22a450cdd4](https://github.com/RueDeRennes/mosaik/commit/22a450cdd4))
- update package.json files and add TypeScript configurations for localization ([577f8dd710](https://github.com/RueDeRennes/mosaik/commit/577f8dd710))
- implement parser interfaces and various parser classes for localization ([8b5b4258e1](https://github.com/RueDeRennes/mosaik/commit/8b5b4258e1))
- update project CommonJS/ESM TypeScript configurations ([b57802c2d9](https://github.com/RueDeRennes/mosaik/commit/b57802c2d9))
- migrate from lodash to es-toolkit for utility functions and update package dependencies ([cfdb4f64a1](https://github.com/RueDeRennes/mosaik/commit/cfdb4f64a1))
- add tsup configuration for Vite and Utilities, update LiveReload plugin options ([9d0b3a71be](https://github.com/RueDeRennes/mosaik/commit/9d0b3a71be))
- update Vite configuration and improve FileSystemWatcher filtering logic ([43a655b8ac](https://github.com/RueDeRennes/mosaik/commit/43a655b8ac))
- add Vite configuration and plugins, including live reload functionality ([92b0ee5260](https://github.com/RueDeRennes/mosaik/commit/92b0ee5260))
- remove obsolete BlockquoteProcessor tests and add utility functions for token metadata management ([11be8212a8](https://github.com/RueDeRennes/mosaik/commit/11be8212a8))
- add Vitest configuration and implement tests for Markdown processors ([10d745777c](https://github.com/RueDeRennes/mosaik/commit/10d745777c))
- add type annotations for hot update handler and improve import statements in processors ([6c28d98979](https://github.com/RueDeRennes/mosaik/commit/6c28d98979))
- integrate markdowner tool and update API paths for consistency ([21c276f79a](https://github.com/RueDeRennes/mosaik/commit/21c276f79a))
- initialize Mosaik.Elements library with TypeScript configuration and documentation ([121c1196a8](https://github.com/RueDeRennes/mosaik/commit/121c1196a8))
- add mosaik-elements-angular-2 library with initial component and configuration files ([2e4c734f9e](https://github.com/RueDeRennes/mosaik/commit/2e4c734f9e))
- add infrastructure build step to API development workflow ([4f77ea2b30](https://github.com/RueDeRennes/mosaik/commit/4f77ea2b30))
- implement new email delivery strategies ([71d732c67d](https://github.com/RueDeRennes/mosaik/commit/71d732c67d))
- add dependency installation step in GitHub Actions workflow ([0ee17aa199](https://github.com/RueDeRennes/mosaik/commit/0ee17aa199))
- add build infrastructure step and update project configurations with 'infra' tags ([355a7b0768](https://github.com/RueDeRennes/mosaik/commit/355a7b0768))
- add VERBOSE environment variable for detailed linting logs ([e3fe3fad69](https://github.com/RueDeRennes/mosaik/commit/e3fe3fad69))
- add CommandNamingRule for ESLint; update project configuration and enhance documentation ([21e0e36302](https://github.com/RueDeRennes/mosaik/commit/21e0e36302))
- add ICommand interface and implement delete profile view styles; update username references to userName across the codebase ([b7184a2d10](https://github.com/RueDeRennes/mosaik/commit/b7184a2d10))
- **api:** update Doppler configuration to support API key authentication and enhance documentation ([8e4c98a5e0](https://github.com/RueDeRennes/mosaik/commit/8e4c98a5e0))
- **api:** add doppler support for security keys ([bb1dd83041](https://github.com/RueDeRennes/mosaik/commit/bb1dd83041))
- **api:** add new issue models and update icon response; remove unused IIconGroup model ([d05cefc0ed](https://github.com/RueDeRennes/mosaik/commit/d05cefc0ed))
- add docs executor and update package dependencies across multiple libraries ([b55ff52fd4](https://github.com/RueDeRennes/mosaik/commit/b55ff52fd4))
- add GitHub Actions workflow for development app deployment with caching and build steps ([118b8a6bff](https://github.com/RueDeRennes/mosaik/commit/118b8a6bff))
- add SubscribeRequest and UnsubscribeRequest classes, update API response statuses to use HttpStatus, and enhance Prisma configuration for PostgreSQL ([7c49d4098d](https://github.com/RueDeRennes/mosaik/commit/7c49d4098d))
- add Database module and service, integrate with Issues and Newsletter repositories, and update TypeScript configuration ([238c8b509b](https://github.com/RueDeRennes/mosaik/commit/238c8b509b))
- update server port to 8080, add IssuesView and related styles, and enhance ApiService2 with issue management methods ([8e55d5be52](https://github.com/RueDeRennes/mosaik/commit/8e55d5be52))
- navigate to backend directory and list files before building Docker image ([bb4a5f8723](https://github.com/RueDeRennes/mosaik/commit/bb4a5f8723))
- enhance GitHub Actions workflow for Docker by adding artifact upload and improving repository name handling ([b93588e6d5](https://github.com/RueDeRennes/mosaik/commit/b93588e6d5))
- add .dockerignore for mosaik-api and log npm dependencies in build step ([d170a45722](https://github.com/RueDeRennes/mosaik/commit/d170a45722))
- add GitHub Actions workflow for Docker build and push to GHCR ([14f2ed37e1](https://github.com/RueDeRennes/mosaik/commit/14f2ed37e1))
- add backend code ([599d31af49](https://github.com/RueDeRennes/mosaik/commit/599d31af49))
- **nx-cloud:** setup nx cloud workspace ([9dfa175d05](https://github.com/RueDeRennes/mosaik/commit/9dfa175d05))
- add commitlint in repo ([4a71ed5158](https://github.com/RueDeRennes/mosaik/commit/4a71ed5158))
- upgrade to angular 12 ([e604cc6da3](https://github.com/RueDeRennes/mosaik/commit/e604cc6da3))
- **angular:** add cdk dependency to add new dialogService ([8c294ec672](https://github.com/RueDeRennes/mosaik/commit/8c294ec672))
- **commerce:** add new commerce package 🎉 ([b595653878](https://github.com/RueDeRennes/mosaik/commit/b595653878))
- **angular:** add camera recorder typings ([32a8ba560e](https://github.com/RueDeRennes/mosaik/commit/32a8ba560e))

### 🩹 Fixes

- standardize title formatting in documentation files ([8899b6307c](https://github.com/RueDeRennes/mosaik/commit/8899b6307c))
- update IconNameDirective to use 'icon' property instead of 'data' for icon name functionality ([af7d70822c](https://github.com/RueDeRennes/mosaik/commit/af7d70822c))
- add missing newline at end of package.json ([649ed1b503](https://github.com/RueDeRennes/mosaik/commit/649ed1b503))
- **dependencies:** add @rollup/plugin-json to package.json refactor: simplify build script in openapi templates ([f6a6476388](https://github.com/RueDeRennes/mosaik/commit/f6a6476388))
- **dependencies:** update peer dependency for vite to support versions 6.x and 7.x refactor: remove unused plugins from nx configuration fix: update build script in openapi templates to use yarn ([0422a23610](https://github.com/RueDeRennes/mosaik/commit/0422a23610))
- **dependencies:** update vite to version 7.0.2 in package.json and yarn.lock ([b6b2b61b42](https://github.com/RueDeRennes/mosaik/commit/b6b2b61b42))
- **dependencies:** update @nx packages to version 21.2.2 ([c044affa8d](https://github.com/RueDeRennes/mosaik/commit/c044affa8d))
- update release script to version 0.0.71 ([c3e7e5e8bf](https://github.com/RueDeRennes/mosaik/commit/c3e7e5e8bf))
- add missing newline at end of package.json ([73866991d5](https://github.com/RueDeRennes/mosaik/commit/73866991d5))
- update background color to transparent for page header and menu components; update release script to version 0.0.70 ([e8e7c124a4](https://github.com/RueDeRennes/mosaik/commit/e8e7c124a4))
- update release version to 0.0.47 in package.json ([5a277d2d1d](https://github.com/RueDeRennes/mosaik/commit/5a277d2d1d))
- correct spelling of 'HTML' in keywords and add new article on `part` attributes ([cd5b688a5c](https://github.com/RueDeRennes/mosaik/commit/cd5b688a5c))
- correct quotation marks in attribute selector examples for consistency ([078a6c9289](https://github.com/RueDeRennes/mosaik/commit/078a6c9289))
- correct quotation marks in markdown article and improve blockquote rendering in MarkdownRenderer ([09442e4509](https://github.com/RueDeRennes/mosaik/commit/09442e4509))
- update release script to version 0.0.41 ([88efd1b9ca](https://github.com/RueDeRennes/mosaik/commit/88efd1b9ca))
- adjust height calculations for content in AppElement styles ([1d8793fd52](https://github.com/RueDeRennes/mosaik/commit/1d8793fd52))
- update const vs enum article to use string literals for WorkType values ([3eb355434e](https://github.com/RueDeRennes/mosaik/commit/3eb355434e))
- correct quotation marks in best practices section of const vs enum article ([df4187ec19](https://github.com/RueDeRennes/mosaik/commit/df4187ec19))
- update backdrop image URLs in const vs enum article ([e05a779a0a](https://github.com/RueDeRennes/mosaik/commit/e05a779a0a))
- update release version to 0.0.38 in package.json and improve description formatting in Meta.g.json ([edbd04421c](https://github.com/RueDeRennes/mosaik/commit/edbd04421c))
- correct formatting of region comments and quote attribution for clarity ([952d90f14b](https://github.com/RueDeRennes/mosaik/commit/952d90f14b))
- update provideTheme function to simplify overrides and adjust merge function ([0359c488be](https://github.com/RueDeRennes/mosaik/commit/0359c488be))
- update provideTheme to useValue for theme and mode signals ([5a7b509869](https://github.com/RueDeRennes/mosaik/commit/5a7b509869))
- update release script to version 0.0.33 ([0954fadfa3](https://github.com/RueDeRennes/mosaik/commit/0954fadfa3))
- update markdowner-core dependency to use workspace reference for consistency ([518dffba42](https://github.com/RueDeRennes/mosaik/commit/518dffba42))
- simplify flex-basis and max-width calculations in WrapElement for improved readability ([0fba2a2eef](https://github.com/RueDeRennes/mosaik/commit/0fba2a2eef))
- change progress/ring/bar number properties to cssLength for simpler data binding ([d15e88f0c9](https://github.com/RueDeRennes/mosaik/commit/d15e88f0c9))
- update checkbox styles by removing unnecessary padding and border properties feat: add YouTube video embed and quote to interview markdown fix: adjust marker color in markdown styles for better visibility ([1284a2bcff](https://github.com/RueDeRennes/mosaik/commit/1284a2bcff))
- correct quotes in interview markdown and enhance closing statements ([8d0e7134ba](https://github.com/RueDeRennes/mosaik/commit/8d0e7134ba))
- correct formatting and update YouTube link in interview markdown ([2b430a99bc](https://github.com/RueDeRennes/mosaik/commit/2b430a99bc))
- **docs:** update route in command-pattern-vue.md for correct path; remove outdated mvp.requirements.md file; add comprehensive requirements documentation ([12dd351358](https://github.com/RueDeRennes/mosaik/commit/12dd351358))
- **build:** reorder build steps in deployment script for clarity and consistency ([4e746f0b36](https://github.com/RueDeRennes/mosaik/commit/4e746f0b36))
- correct spelling and casing in IconsService and related files ([f4d478699e](https://github.com/RueDeRennes/mosaik/commit/f4d478699e))
- update build commands in CI workflows to use 'yarn nx run' syntax ([a38e725929](https://github.com/RueDeRennes/mosaik/commit/a38e725929))
- update description of mosaik-api in README.md for clarity ([478b4c5177](https://github.com/RueDeRennes/mosaik/commit/478b4c5177))
- restore missing languages and sites in app.json configuration ([ad5f019e46](https://github.com/RueDeRennes/mosaik/commit/ad5f019e46))
- adjust positioning for lightChain and update CookieConsentElement attributes ([708c9832bd](https://github.com/RueDeRennes/mosaik/commit/708c9832bd))
- remove verbose flag from mosaik app build command ([f8f2b53714](https://github.com/RueDeRennes/mosaik/commit/f8f2b53714))
- update theme import paths to use consistent casing ([1aa18b699e](https://github.com/RueDeRennes/mosaik/commit/1aa18b699e))
- hide portal element by default in TimeBoxElementTemplate ([f5f16c13b7](https://github.com/RueDeRennes/mosaik/commit/f5f16c13b7))
- add missing newline at end of package.json ([713cb1f983](https://github.com/RueDeRennes/mosaik/commit/713cb1f983))
- simplify condition checks and remove unnecessary styles in various components ([41e6b5d8a9](https://github.com/RueDeRennes/mosaik/commit/41e6b5d8a9))
- update release script to version 0.0.28 ([baaef44d1d](https://github.com/RueDeRennes/mosaik/commit/baaef44d1d))
- update hover and selection styles for TabStrip and Tree components ([d6c90fc2bb](https://github.com/RueDeRennes/mosaik/commit/d6c90fc2bb))
- add missing newline at end of package.json ([39f2f1c578](https://github.com/RueDeRennes/mosaik/commit/39f2f1c578))
- update TabStrip and TreeItem styles to handle disabled state correctly ([ecb60798db](https://github.com/RueDeRennes/mosaik/commit/ecb60798db))
- update release version to 0.0.19 in package.json ([acccb56f76](https://github.com/RueDeRennes/mosaik/commit/acccb56f76))
- add missing newline at end of package.json ([43ce0e6a3b](https://github.com/RueDeRennes/mosaik/commit/43ce0e6a3b))
- correct spelling of 'getScrollableElement' and remove unused method ([72e17ecc7a](https://github.com/RueDeRennes/mosaik/commit/72e17ecc7a))
- correct spelling of 'success' in logSummary parameter documentation chore: update release script version to 0.0.16 chore: add 'keyhandle' to cspell words ([1a9d5e8732](https://github.com/RueDeRennes/mosaik/commit/1a9d5e8732))
- improve type handling and cleanup in Invalidable, CheckBoxGroup, ChoiceGroup, and RadioGroup components ([84753f810c](https://github.com/RueDeRennes/mosaik/commit/84753f810c))
- correct spelling of "Emitts" to "Emits" in event documentation across multiple components ([17e025c185](https://github.com/RueDeRennes/mosaik/commit/17e025c185))
- correct spelling errors in README and update release version in package.json ([922364afec](https://github.com/RueDeRennes/mosaik/commit/922364afec))
- different themes and styles ([917e55212d](https://github.com/RueDeRennes/mosaik/commit/917e55212d))
- add missing words to cSpell configuration ([933dd56139](https://github.com/RueDeRennes/mosaik/commit/933dd56139))
- correct spelling errors and improve property names in interfaces and components ([e7edf69f3e](https://github.com/RueDeRennes/mosaik/commit/e7edf69f3e))
- remove OTP prompt from publish package task and update related function signatures ([a684f8dc7e](https://github.com/RueDeRennes/mosaik/commit/a684f8dc7e))
- disable caching in project configurations and update build scripts for consistency ([0bf27cb99e](https://github.com/RueDeRennes/mosaik/commit/0bf27cb99e))
- add missing newline at end of package.json files across multiple directories ([a01c97ed2b](https://github.com/RueDeRennes/mosaik/commit/a01c97ed2b))
- correct build script command for SCSS and update build commands in project configuration ([0b243a90be](https://github.com/RueDeRennes/mosaik/commit/0b243a90be))
- update theme in index.html and enhance logging in CopyPublisherPackageJson.ts; add release targets to project.json files; remove obsolete scripts ([648a850c12](https://github.com/RueDeRennes/mosaik/commit/648a850c12))
- correct package name format in changeset configuration and add release script to package.json ([168113d104](https://github.com/RueDeRennes/mosaik/commit/168113d104))
- update package.json dependencies to use version 0.0.0 for consistency across all packages ([9b37f5626c](https://github.com/RueDeRennes/mosaik/commit/9b37f5626c))
- revert package versions to 0.0.0 for consistency across all packages ([8e39bb4e60](https://github.com/RueDeRennes/mosaik/commit/8e39bb4e60))
- update disabled state handling for various components ([bbabccda83](https://github.com/RueDeRennes/mosaik/commit/bbabccda83))
- update Angular dependencies to use caret versioning and remove unused mosaik-elements-angular-2 entry ([65f2f21abf](https://github.com/RueDeRennes/mosaik/commit/65f2f21abf))
- Refactor LitStyleTransform to remove unnecessary timing logs; update ExpanderElement styles for improved theming support ([3ca2b0d734](https://github.com/RueDeRennes/mosaik/commit/3ca2b0d734))
- Correct cache option handling across multiple executors and tasks ([bdbcb05c08](https://github.com/RueDeRennes/mosaik/commit/bdbcb05c08))
- update SKIP_LINT variable to use lowercase 'true' for consistency ([319f15f508](https://github.com/RueDeRennes/mosaik/commit/319f15f508))
- restore 'detect' configuration in project.json and update package manager version in package.json ([ff659684a6](https://github.com/RueDeRennes/mosaik/commit/ff659684a6))
- ensure form elements inherit styles correctly in formElementJoyStyle ([8c3dc71259](https://github.com/RueDeRennes/mosaik/commit/8c3dc71259))
- change constructor visibility from protected to public in StateElement class ([4fdc37f008](https://github.com/RueDeRennes/mosaik/commit/4fdc37f008))
- update theme default settings and padding values for improved consistency across card components ([11c519bf66](https://github.com/RueDeRennes/mosaik/commit/11c519bf66))
- update background color and padding values to unset for improved theme consistency across components ([fe22eaa2ca](https://github.com/RueDeRennes/mosaik/commit/fe22eaa2ca))
- update shared-style mixin to use local $name variable for consistency across components ([dc5fdb55df](https://github.com/RueDeRennes/mosaik/commit/dc5fdb55df))
- update yarn clean script to remove force option ([723efb5c42](https://github.com/RueDeRennes/mosaik/commit/723efb5c42))
- add missing React and Vue dependencies to package.json ([ee2fb6360f](https://github.com/RueDeRennes/mosaik/commit/ee2fb6360f))
- update TypeScript configurations for consistency and readability ([a74cd93fc1](https://github.com/RueDeRennes/mosaik/commit/a74cd93fc1))
- update dependencies in package.json files to latest versions ([00c4430b43](https://github.com/RueDeRennes/mosaik/commit/00c4430b43))
- update package.json to add Angular DevKit and Nx dependencies ([d86b800714](https://github.com/RueDeRennes/mosaik/commit/d86b800714))
- format json configuration files for consistency and readability ([f4e4b56db6](https://github.com/RueDeRennes/mosaik/commit/f4e4b56db6))
- update .gitignore to simplify custom entries and add Angular build artifacts ([8dbc5e0cfe](https://github.com/RueDeRennes/mosaik/commit/8dbc5e0cfe))
- add 'mosaik-ng' to package.json and clean up ToastComponent code with consistent formatting ([8871b31d8b](https://github.com/RueDeRennes/mosaik/commit/8871b31d8b))
- add Angular CLI to install script and update EventEmitter definitions for consistency across components ([d46388649e](https://github.com/RueDeRennes/mosaik/commit/d46388649e))
- remove unnecessary comments and continue-on-error flags in lint jobs for clarity ([a5cc2fbfe3](https://github.com/RueDeRennes/mosaik/commit/a5cc2fbfe3))
- simplify lint command in GitHub Actions workflow ([f6324c6be3](https://github.com/RueDeRennes/mosaik/commit/f6324c6be3))
- enable verbose linting for mosaik-elements-foundation ([9262eb8c5b](https://github.com/RueDeRennes/mosaik/commit/9262eb8c5b))
- correct SKIP_LINT environment variable to use lowercase 'false' ([e04ba33fb4](https://github.com/RueDeRennes/mosaik/commit/e04ba33fb4))
- update API endpoint to use Render URL instead of localhost ([3f3df24c15](https://github.com/RueDeRennes/mosaik/commit/3f3df24c15))
- update deployment path in GitHub Actions workflow for backend API ([4d9721e02f](https://github.com/RueDeRennes/mosaik/commit/4d9721e02f))
- remove redundant ls command from Docker build step in GitHub Actions workflow ([35074e3608](https://github.com/RueDeRennes/mosaik/commit/35074e3608))
- remove redundant npm list commands in GitHub Actions build step ([88cbee4e84](https://github.com/RueDeRennes/mosaik/commit/88cbee4e84))
- update GitHub Actions workflow to install npm packages and list global dependencies ([eda5a6b1f9](https://github.com/RueDeRennes/mosaik/commit/eda5a6b1f9))
- update build step in GitHub Actions to list global npm packages ([f53cf75b47](https://github.com/RueDeRennes/mosaik/commit/f53cf75b47))
- meta path ([7a3bdb39ef](https://github.com/RueDeRennes/mosaik/commit/7a3bdb39ef))

## 0.0.75 (2025-07-06)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.74 (2025-07-06)

### 🩹 Fixes

- add missing newline at end of package.json ([649ed1b503](https://github.com/RueDeRennes/mosaik/commit/649ed1b503))

## 0.0.73 (2025-07-06)

### 🚀 Features

- add expand, collapse, and toggle methods to MenuItem and TreeItem components with descriptions ([8881f5f730](https://github.com/RueDeRennes/mosaik/commit/8881f5f730))
- add IExpandable interface and implement expandable functionality in MenuItemElement, TreeItemElement, and ExpandableElement ([f2fb5df205](https://github.com/RueDeRennes/mosaik/commit/f2fb5df205))

## 0.0.72 (2025-07-05)

### 🚀 Features

- implement ColorTableElement component with associated template and styles ([a5bc0a091a](https://github.com/RueDeRennes/mosaik/commit/a5bc0a091a))
- add copyExecutorsJson script and update build commands ([0a0aba85b9](https://github.com/RueDeRennes/mosaik/commit/0a0aba85b9))
- update Carousel component methods and add select method implementation ([351e68a615](https://github.com/RueDeRennes/mosaik/commit/351e68a615))
- update menu component styles and structure for improved layout and responsiveness ([373095056e](https://github.com/RueDeRennes/mosaik/commit/373095056e))
- add icon functionality with IconDirective and IconRegistry, enhance app layout with new directives ([8acea01349](https://github.com/RueDeRennes/mosaik/commit/8acea01349))
- enhance app layout and styling with new components and responsive design ([8919fccc0c](https://github.com/RueDeRennes/mosaik/commit/8919fccc0c))
- enhance Jumbotron components with slot definitions and improve HideOnScrollController methods ([4cc6d9de3a](https://github.com/RueDeRennes/mosaik/commit/4cc6d9de3a))
- Add formatter property to Jumbotron components and update related files ([9ae59c7ff9](https://github.com/RueDeRennes/mosaik/commit/9ae59c7ff9))
- Add Svelte titles to German and English translations; update formatting keys in various components ([9889da1578](https://github.com/RueDeRennes/mosaik/commit/9889da1578))
- Add Jumbotron component and related styles for multiple frameworks ([41d4601e08](https://github.com/RueDeRennes/mosaik/commit/41d4601e08))
- enhance backdrop styles and refactor breakpoint handling ([39661be30c](https://github.com/RueDeRennes/mosaik/commit/39661be30c))
- Update layout variables for Cosmopolitan and Joy themes in various components ([af9ca676db](https://github.com/RueDeRennes/mosaik/commit/af9ca676db))
- Introduce Indicator component across multiple frameworks ([7ef850c39d](https://github.com/RueDeRennes/mosaik/commit/7ef850c39d))
- Update Indicator component styles and tokens for layout spacing ([201ee59059](https://github.com/RueDeRennes/mosaik/commit/201ee59059))
- Add Indicator component and related functionality ([b55b86b0e2](https://github.com/RueDeRennes/mosaik/commit/b55b86b0e2))
- implement animation directive and provider with presets ([09550b6633](https://github.com/RueDeRennes/mosaik/commit/09550b6633))
- enhance theme merging logic and add support for deep partial overrides ([870d64b42b](https://github.com/RueDeRennes/mosaik/commit/870d64b42b))
- Remove unused 'onInput' method from ColorPicker components and update related code ([d84ece1672](https://github.com/RueDeRennes/mosaik/commit/d84ece1672))
- Add Svelte support with SvelteCodeGenerator and update build scripts ([955cb75cb6](https://github.com/RueDeRennes/mosaik/commit/955cb75cb6))
- Add new Svelte components for menu, segment, tab, table, tree, wizard, and shell ([e6de8f0553](https://github.com/RueDeRennes/mosaik/commit/e6de8f0553))
- add Color Palette Builder tool and associated views ([55a992138e](https://github.com/RueDeRennes/mosaik/commit/55a992138e))
- add comprehensive article on using const vs enums in TypeScript with Angular templates ([8db46644e3](https://github.com/RueDeRennes/mosaik/commit/8db46644e3))
- add hasHeader and hasNav properties to AppElement and update related components ([37baedabae](https://github.com/RueDeRennes/mosaik/commit/37baedabae))
- add localizator-core dependency and update build dependencies in project configuration ([077a2cd1d9](https://github.com/RueDeRennes/mosaik/commit/077a2cd1d9))
- add FlexDirective for flexible layout management in Angular ([3b8f27e2b7](https://github.com/RueDeRennes/mosaik/commit/3b8f27e2b7))
- add comprehensive guide on the power of regions in TypeScript for improved code organization ([564b600288](https://github.com/RueDeRennes/mosaik/commit/564b600288))
- add theme provider for angular ([04568d1528](https://github.com/RueDeRennes/mosaik/commit/04568d1528))
- update masonry and wrap elements to use CSS variables for gap and columns, enhance templates with static styles ([2dee486060](https://github.com/RueDeRennes/mosaik/commit/2dee486060))
- disable eslint rule for static styles in multiple component templates and update SCSS mixin to exclude properties ([d6e61ac195](https://github.com/RueDeRennes/mosaik/commit/d6e61ac195))
- enhance keyboard element with modifier key support and update styles ([07f7af6d52](https://github.com/RueDeRennes/mosaik/commit/07f7af6d52))
- enhance dropdown button templates with new icons and improved layout fix: adjust padding for menu item group headers across themes ([5004c67e11](https://github.com/RueDeRennes/mosaik/commit/5004c67e11))
- add 'Code' and 'TypeScript' keywords to various documentation files for improved discoverability ([7ac3c152dd](https://github.com/RueDeRennes/mosaik/commit/7ac3c152dd))
- add "The Dependency Forest" article on dependency management challenges in Angular ([d129b84490](https://github.com/RueDeRennes/mosaik/commit/d129b84490))
- add translation command and integrate translation functionality in BlogBaseElement ([7e166a6bea](https://github.com/RueDeRennes/mosaik/commit/7e166a6bea))
- enhance blog and translation features with interview type and language flags ([9aff64d29b](https://github.com/RueDeRennes/mosaik/commit/9aff64d29b))
- update interview content and add StickyController metadata in JSON ([c39d970be6](https://github.com/RueDeRennes/mosaik/commit/c39d970be6))
- add YouTube video rendering support in MarkdownRenderer ([723610d3c8](https://github.com/RueDeRennes/mosaik/commit/723610d3c8))
- Add new translation for "Open with" in code section ([e1b84033bc](https://github.com/RueDeRennes/mosaik/commit/e1b84033bc))
- create Playground components for testing Markdown features ([738f61002f](https://github.com/RueDeRennes/mosaik/commit/738f61002f))
- enhance Listen decorator to support custom query targets and improve event handling ([aa19e6e5a0](https://github.com/RueDeRennes/mosaik/commit/aa19e6e5a0))
- add PinchController for gesture recognition and enhance DiagramElement with centering functionality ([c3feb9a789](https://github.com/RueDeRennes/mosaik/commit/c3feb9a789))
- **docs:** Update documentation with new sections, descriptions, and examples for clarity and usability ([c32ff5f976](https://github.com/RueDeRennes/mosaik/commit/c32ff5f976))
- **docs:** Enhance MVP pattern documentation with detailed explanations and examples ([e3c97f1368](https://github.com/RueDeRennes/mosaik/commit/e3c97f1368))
- implement filter functionality in ArticlesView and update related templates ([1e88d302d4](https://github.com/RueDeRennes/mosaik/commit/1e88d302d4))
- Implement sticky positioning directive and controller, enhance scrolling functionality in Scroller class ([148f07916e](https://github.com/RueDeRennes/mosaik/commit/148f07916e))
- Enhance MVP documentation and examples across multiple frameworks ([cfabea14a3](https://github.com/RueDeRennes/mosaik/commit/cfabea14a3))
- add backdrop images and enhance ArticlesView with documentation grouping ([af72ff74cd](https://github.com/RueDeRennes/mosaik/commit/af72ff74cd))
- add images and enhance Markdown documentation with improved layout and structure ([1eaac2125f](https://github.com/RueDeRennes/mosaik/commit/1eaac2125f))
- enhance Markdown components with improved styling and layout variables ([780d383b31](https://github.com/RueDeRennes/mosaik/commit/780d383b31))
- enhance CodeEditor and Markdown components with improved language and theme support ([0270711752](https://github.com/RueDeRennes/mosaik/commit/0270711752))
- **callouts:** add new callout variants and enhance Markdown processing ([3a5608697b](https://github.com/RueDeRennes/mosaik/commit/3a5608697b))
- **markdowner:** enhance Markdown processing with new extension structure and build integration ([0c08852146](https://github.com/RueDeRennes/mosaik/commit/0c08852146))
- Enhance Markdown processing with new features and improvements ([534983c407](https://github.com/RueDeRennes/mosaik/commit/534983c407))
- **translations:** add share message for blog posts ([a3ba45071a](https://github.com/RueDeRennes/mosaik/commit/a3ba45071a))
- improve date formatting in BlogBase and enhance share command data structure ([6f64d0990e](https://github.com/RueDeRennes/mosaik/commit/6f64d0990e))
- enhance Markdown component styles with improved blockquote and list formatting ([dbefc8d12f](https://github.com/RueDeRennes/mosaik/commit/dbefc8d12f))
- refactor text overflow handling and enhance Markdown component styles ([62bb601fc7](https://github.com/RueDeRennes/mosaik/commit/62bb601fc7))
- Update AppSideNavTemplate to use node meta for display names and add value binding ([1488b7d52f](https://github.com/RueDeRennes/mosaik/commit/1488b7d52f))
- update metadata structure in documentation and improve avatar and chip components ([007bd05bea](https://github.com/RueDeRennes/mosaik/commit/007bd05bea))
- enhance Markdown rendering and styling with new link styles and tree directive support ([8fba55993c](https://github.com/RueDeRennes/mosaik/commit/8fba55993c))
- update markdown files to use structured keywords and add author information ([d0df1b883f](https://github.com/RueDeRennes/mosaik/commit/d0df1b883f))
- **docs): enhance keyword metadata across documentation files for improved searchability and context feat(Markdown): update MarkdownElement and MarkdownRenderer for better handling of text and code blocks fix(DocsService): refine getDocsTree method for improved documentation hierarchy and sorting fix(staticContent:** add meta information to static content registration for enhanced metadata handling ([789875e05d](https://github.com/RueDeRennes/mosaik/commit/789875e05d))
- **build:** add vite-plugins build step to deployment script; enhance MarkdownElement and DocsService for better handling of documentation and Markdown sources ([619a32e38b](https://github.com/RueDeRennes/mosaik/commit/619a32e38b))
- **menu:** add textOverflow property to MenuItemComponent and related elements for improved text handling; update DocsService and AppSideNavTemplate for better rendering ([9b7641b6c1](https://github.com/RueDeRennes/mosaik/commit/9b7641b6c1))
- **router:** implement RouterLocation and IRouterLocation for improved routing abstraction; refactor RouterElement to utilize new location handling ([53705c577a](https://github.com/RueDeRennes/mosaik/commit/53705c577a))
- **menu:** enhance menu item styles with indent properties and update theme tokens for better visual hierarchy ([b3dad3c306](https://github.com/RueDeRennes/mosaik/commit/b3dad3c306))
- **router:** enhance routing components with role attributes and update templates for better accessibility; refactor RouterController and RouterLinkDirective for improved functionality ([63b32829f1](https://github.com/RueDeRennes/mosaik/commit/63b32829f1))
- **router:** implement routerLink directive for dynamic link handling; update AppSideNavTemplate to use routerLink ([f2fb309d47](https://github.com/RueDeRennes/mosaik/commit/f2fb309d47))
- **router:** add RouterLinkDirective for dynamic link generation ([ab2e98ed50](https://github.com/RueDeRennes/mosaik/commit/ab2e98ed50))
- enhance package service and controller to support history retrieval with optional limit; update translations and styles for package explorer ([71efae2557](https://github.com/RueDeRennes/mosaik/commit/71efae2557))
- implement ShieldElement with template, style, and props; enhance package metadata and history models ([de73abbc76](https://github.com/RueDeRennes/mosaik/commit/de73abbc76))
- enhance package service and models with metadata and history retrieval ([05c98c197d](https://github.com/RueDeRennes/mosaik/commit/05c98c197d))
- add package manager installation step in CI workflow ([d8453719df](https://github.com/RueDeRennes/mosaik/commit/d8453719df))
- add eslint config build step to the dev deployment workflow ([c831986474](https://github.com/RueDeRennes/mosaik/commit/c831986474))
- add component selector to various sample elements for better integration ([3eb465fed5](https://github.com/RueDeRennes/mosaik/commit/3eb465fed5))
- Update button element CSS properties and enhance template styles ([c83ee77d83](https://github.com/RueDeRennes/mosaik/commit/c83ee77d83))
- Enhance sandbox functionality and UI improvements ([c45d7ca09b](https://github.com/RueDeRennes/mosaik/commit/c45d7ca09b))
- Implement ProjectionController for managing projected content in portals ([1bc46717b5](https://github.com/RueDeRennes/mosaik/commit/1bc46717b5))
- add TableFooter component and related styles ([85d9e96af5](https://github.com/RueDeRennes/mosaik/commit/85d9e96af5))
- Enhance state elements with padding and gap properties ([19074a8b51](https://github.com/RueDeRennes/mosaik/commit/19074a8b51))
- Enhance Select and Combo components with internationalization and improved styling ([8d80d58234](https://github.com/RueDeRennes/mosaik/commit/8d80d58234))
- enhance TagCloudElement with item selection and styling; refactor related components and styles ([2847e96a41](https://github.com/RueDeRennes/mosaik/commit/2847e96a41))
- add ModifierKeyName export and improve attr() function in SCSS ([317b75143d](https://github.com/RueDeRennes/mosaik/commit/317b75143d))
- Refactor CheckBoxGroupSample and TextBoxSample components for improved property formatting ([b0fcc7502e](https://github.com/RueDeRennes/mosaik/commit/b0fcc7502e))
- add default values for boolean attributes across various components ([899d593ba5](https://github.com/RueDeRennes/mosaik/commit/899d593ba5))
- update release script to version 0.0.26 ([11e2fdbc4f](https://github.com/RueDeRennes/mosaik/commit/11e2fdbc4f))
- update release script to version 0.0.25 ([930ba60eb4](https://github.com/RueDeRennes/mosaik/commit/930ba60eb4))
- update version to 0.0.24 and remove prefix/suffix styles from various components ([d061c7f8cd](https://github.com/RueDeRennes/mosaik/commit/d061c7f8cd))
- update appearance of input components and add textAlign property ([5f7321b7a8](https://github.com/RueDeRennes/mosaik/commit/5f7321b7a8))
- Add text alignment support to input components ([0a1069f47d](https://github.com/RueDeRennes/mosaik/commit/0a1069f47d))
- Add Validators class to Cdk for form validation ([5db8b51601](https://github.com/RueDeRennes/mosaik/commit/5db8b51601))
- add spinner and textAlign properties to NumberBox and TextBox components ([cda90dffa4](https://github.com/RueDeRennes/mosaik/commit/cda90dffa4))
- implement flip component with new side property and directives ([2b3c56c9b4](https://github.com/RueDeRennes/mosaik/commit/2b3c56c9b4))
- add select component to auth form and improve validation ([4971bba07f](https://github.com/RueDeRennes/mosaik/commit/4971bba07f))
- add Invalidable behavior and validity check to components ([893bb30b3b](https://github.com/RueDeRennes/mosaik/commit/893bb30b3b))
- add ng forms validation trigger ([e430f70f31](https://github.com/RueDeRennes/mosaik/commit/e430f70f31))
- update project dependencies and build configurations ([569b1bf99d](https://github.com/RueDeRennes/mosaik/commit/569b1bf99d))
- **eslint:** add TypeScript ESLint configuration with comprehensive ruleset ([4d7a0d88b7](https://github.com/RueDeRennes/mosaik/commit/4d7a0d88b7))
- Add Insetable behavior and update BoxElement styles ([ca740ab5f2](https://github.com/RueDeRennes/mosaik/commit/ca740ab5f2))
- export dateTimeBoxElementValueAccessor alongside DateTimeBoxElementValueAccessor for improved accessibility ([fad7497ba7](https://github.com/RueDeRennes/mosaik/commit/fad7497ba7))
- enhance project configurations with inputs and outputs for build targets ([6f80d15bda](https://github.com/RueDeRennes/mosaik/commit/6f80d15bda))
- **PublishPackage:** add version validation and improve error logging ([33ad436126](https://github.com/RueDeRennes/mosaik/commit/33ad436126))
- update package dependencies to use workspace references ([e853ec04e5](https://github.com/RueDeRennes/mosaik/commit/e853ec04e5))
- add changelog configuration to disable author rendering and update release script to specify group ([9ce709c251](https://github.com/RueDeRennes/mosaik/commit/9ce709c251))
- update version generator options to include installArgs and installIgnoreScripts ([747191d4da](https://github.com/RueDeRennes/mosaik/commit/747191d4da))
- streamline release configuration by consolidating project relationships and removing redundant properties ([77fbfcd293](https://github.com/RueDeRennes/mosaik/commit/77fbfcd293))
- add version configuration for conventional commits and generator options ([bd6048596e](https://github.com/RueDeRennes/mosaik/commit/bd6048596e))
- update release configuration to set projectsRelationship to fixed for libs, infra, and tools ([bc0437f95d](https://github.com/RueDeRennes/mosaik/commit/bc0437f95d))
- restructure release configuration to include groups for libs, infra, and tools ([fe9e93b5ce](https://github.com/RueDeRennes/mosaik/commit/fe9e93b5ce))
- update documentation paths and add index file for mosaik-elements-foundation package ([ced717bdea](https://github.com/RueDeRennes/mosaik/commit/ced717bdea))
- update package dependencies to use caret (^) versioning for consistency ([2d8ab96c84](https://github.com/RueDeRennes/mosaik/commit/2d8ab96c84))
- add dependency management for publish targets in project configurations ([e13de9a63b](https://github.com/RueDeRennes/mosaik/commit/e13de9a63b))
- enhance release script to include build and publish targets ([0c29b15d46](https://github.com/RueDeRennes/mosaik/commit/0c29b15d46))
- update package.json dependencies to use specific versions instead of workspace references ([4934f88dc1](https://github.com/RueDeRennes/mosaik/commit/4934f88dc1))
- update project configurations to enable caching and adjust input paths for build targets ([4e8b485497](https://github.com/RueDeRennes/mosaik/commit/4e8b485497))
- add copy-dependencies and publish-package executors; update project.json to use new publish executor ([ba4c5f9393](https://github.com/RueDeRennes/mosaik/commit/ba4c5f9393))
- add changesets for versioning and changelog management ([00db6e0ef1](https://github.com/RueDeRennes/mosaik/commit/00db6e0ef1))
- add semver package for version validation in CopyPublisherPackageJson task ([f848b73d49](https://github.com/RueDeRennes/mosaik/commit/f848b73d49))
- Refactor components to support standalone mode and add method invocation capabilities ([3312924aa2](https://github.com/RueDeRennes/mosaik/commit/3312924aa2))
- **dialog:** implement DialogRef and DialogService for enhanced dialog management ([e1c0b0d850](https://github.com/RueDeRennes/mosaik/commit/e1c0b0d850))
- define custom elements for various components in Mosaik Elements Angular ([cb6a1d5ef2](https://github.com/RueDeRennes/mosaik/commit/cb6a1d5ef2))
- Implement default file cleanup script and enhance component styles ([3aff5d6fd8](https://github.com/RueDeRennes/mosaik/commit/3aff5d6fd8))
- Add Electronic Program Guide components for Angular, React, and Vue ([b62f3f59fc](https://github.com/RueDeRennes/mosaik/commit/b62f3f59fc))
- Add theme change handling and improve dialog dimensions in AppSettingsView; enhance InkBarElement alignment logic ([71da43e4b1](https://github.com/RueDeRennes/mosaik/commit/71da43e4b1))
- Enhance LitStyleTransform with dependency analysis and improve logging; add memphis anchor element styles ([730b58ed42](https://github.com/RueDeRennes/mosaik/commit/730b58ed42))
- Enhance PropertyDecorator to support CSS variable binding for style properties ([5273291343](https://github.com/RueDeRennes/mosaik/commit/5273291343))
- add Boundable behavior and utility functions for date handling ([1deae6f00a](https://github.com/RueDeRennes/mosaik/commit/1deae6f00a))
- Add Joy theme styles for Electronic Program Guide components ([7c76dce194](https://github.com/RueDeRennes/mosaik/commit/7c76dce194))
- Enhance Coupon and Highlight components with improved styles and user-select properties ([7de39c4dee](https://github.com/RueDeRennes/mosaik/commit/7de39c4dee))
- Enhance Electronic Program Guide with new properties and styling adjustments ([d2aed27576](https://github.com/RueDeRennes/mosaik/commit/d2aed27576))
- Add Electronic Program Guide components and styles ([4d7c1d2f49](https://github.com/RueDeRennes/mosaik/commit/4d7c1d2f49))
- **expander:** update styles for Cosmopolitan, Default, Joy, and Memphis themes to enhance shadow properties and improve consistency ([78f0a88ebe](https://github.com/RueDeRennes/mosaik/commit/78f0a88ebe))
- **button:** enhance button styles with shadow and color properties ([46e28550b4](https://github.com/RueDeRennes/mosaik/commit/46e28550b4))
- **tokens:** restructure elevation tokens for better granularity and linting ([d921d201d3](https://github.com/RueDeRennes/mosaik/commit/d921d201d3))
- **tokens:** enhance elevation and typography tokens across themes ([4fca67fd43](https://github.com/RueDeRennes/mosaik/commit/4fca67fd43))
- **theme:** enhance theme management and button styles with new properties and variants ([e733f777e9](https://github.com/RueDeRennes/mosaik/commit/e733f777e9))
- **theme:** enhance Memphis theme with additional variants and update component styles ([6d869ec358](https://github.com/RueDeRennes/mosaik/commit/6d869ec358))
- Update ToggleTip component styles and tokens across themes ([c30920e681](https://github.com/RueDeRennes/mosaik/commit/c30920e681))
- Update theme components and tokens for consistency and improved styling ([ffb9596405](https://github.com/RueDeRennes/mosaik/commit/ffb9596405))
- Enhance Memphis theme with new elevation and appearance tokens ([0c9a0084ec](https://github.com/RueDeRennes/mosaik/commit/0c9a0084ec))
- update chart component styles for improved tooltip and legend formatting ([1037a3fa9a](https://github.com/RueDeRennes/mosaik/commit/1037a3fa9a))
- update chart component styles and themes to use Joy typography variables ([8fe7d7f4fe](https://github.com/RueDeRennes/mosaik/commit/8fe7d7f4fe))
- enhance chart and form elements with foreground color support and style adjustments ([dad0dd53df](https://github.com/RueDeRennes/mosaik/commit/dad0dd53df))
- implement theme persistence and configuration storage, update ToastService and RatingElement properties ([2fe40b8ee8](https://github.com/RueDeRennes/mosaik/commit/2fe40b8ee8))
- add installation and setup for package manager in the workflow ([1498f235f9](https://github.com/RueDeRennes/mosaik/commit/1498f235f9))
- add support for package manager setup in the dev workflow ([59aaf6b708](https://github.com/RueDeRennes/mosaik/commit/59aaf6b708))
- update banner appearance to 'soft' across multiple views and adjust button styles for improved consistency ([36804f1758](https://github.com/RueDeRennes/mosaik/commit/36804f1758))
- implement tab panel component with scrollable content and improved selection logic ([a5766822e0](https://github.com/RueDeRennes/mosaik/commit/a5766822e0))
- update App settings view template to enhance layout and add text case directive ([d3b4963491](https://github.com/RueDeRennes/mosaik/commit/d3b4963491))
- Add options for mode and focus delegation in Drawer components ([2439ae5ada](https://github.com/RueDeRennes/mosaik/commit/2439ae5ada))
- Add appearance property to mosaik-toolbar in chat header template ([0dafe85e1f](https://github.com/RueDeRennes/mosaik/commit/0dafe85e1f))
- Add initial QR Code Cosmopolitan theme styles and structure ([ec12f33544](https://github.com/RueDeRennes/mosaik/commit/ec12f33544))
- Enhance wizard and state elements with new styles and responsive design ([f7bbd2303c](https://github.com/RueDeRennes/mosaik/commit/f7bbd2303c))
- Update Persona and QR Code themes with new styles and tokens ([dfb5030cd8](https://github.com/RueDeRennes/mosaik/commit/dfb5030cd8))
- add style dictionary component generation and enhance SCSS file handling ([8cb9f0d702](https://github.com/RueDeRennes/mosaik/commit/8cb9f0d702))
- enhance SCSS file handling by adding default content population and improving path resolution ([d2a09333bc](https://github.com/RueDeRennes/mosaik/commit/d2a09333bc))
- implement memphis theme support and enhance theme handling across components ([6e6501b5d3](https://github.com/RueDeRennes/mosaik/commit/6e6501b5d3))
- enable multi-language support and add ColorSwatchGroupElement ([e15a8905a4](https://github.com/RueDeRennes/mosaik/commit/e15a8905a4))
- update theme to dark mode and refine color tokens for improved accessibility ([42819d5937](https://github.com/RueDeRennes/mosaik/commit/42819d5937))
- enhance theming support by adding size and layout properties to various components ([285a91ad39](https://github.com/RueDeRennes/mosaik/commit/285a91ad39))
- add appearance variants to toolbar and tab components for enhanced theming support ([275de74baa](https://github.com/RueDeRennes/mosaik/commit/275de74baa))
- enhance theming support by applying Themeable behavior to multiple component classes ([cd7b65f77b](https://github.com/RueDeRennes/mosaik/commit/cd7b65f77b))
- import Themeable behavior into various component files for enhanced theming support ([f9c34b371e](https://github.com/RueDeRennes/mosaik/commit/f9c34b371e))
- add size, duration, elevation, layout, and typography functions to Joy theme styles ([8d472f999c](https://github.com/RueDeRennes/mosaik/commit/8d472f999c))
- add Themeable mixin and import to component style templates ([60e2060c70](https://github.com/RueDeRennes/mosaik/commit/60e2060c70))
- update Joy theme styles for various components, adding new properties and improving consistency ([7eba0a5ea3](https://github.com/RueDeRennes/mosaik/commit/7eba0a5ea3))
- remove obsolete style files and add shared styles for Portal, Content, Floating, and MessageBox components ([dd521743ec](https://github.com/RueDeRennes/mosaik/commit/dd521743ec))
- add memphis theme styles for Chip and QRCode components, remove obsolete Spacer and Sticky styles ([e34f5ee454](https://github.com/RueDeRennes/mosaik/commit/e34f5ee454))
- remove obsolete style files and add new Joy theme styles for various components ([233ed63475](https://github.com/RueDeRennes/mosaik/commit/233ed63475))
- refactor theme styles for Card and CompoundButton components ([a3c49279c0](https://github.com/RueDeRennes/mosaik/commit/a3c49279c0))
- add shared styles for new UI components and update existing styles for consistency ([1772b383a7](https://github.com/RueDeRennes/mosaik/commit/1772b383a7))
- add default styles to Absolute and AbsoluteItem components ([dd26c85a21](https://github.com/RueDeRennes/mosaik/commit/dd26c85a21))
- add cosmopolitan theme style to various form and UI components ([0015925f0c](https://github.com/RueDeRennes/mosaik/commit/0015925f0c))
- enhance Floating Action Button with multiple theme styles ([10892ad232](https://github.com/RueDeRennes/mosaik/commit/10892ad232))
- MAJOR MIGRATION ([4118d0424b](https://github.com/RueDeRennes/mosaik/commit/4118d0424b))
- add script to create theme style templates for components and manage SCSS files ([a12659870b](https://github.com/RueDeRennes/mosaik/commit/a12659870b))
- add new theme styles for various components to enhance UI consistency ([271cecd764](https://github.com/RueDeRennes/mosaik/commit/271cecd764))
- update calendar and chipbox components with improved theming and styles for consistency ([7cdd9a1342](https://github.com/RueDeRennes/mosaik/commit/7cdd9a1342))
- add shared styles for calendar components to enhance UI consistency and layout ([9555e86fab](https://github.com/RueDeRennes/mosaik/commit/9555e86fab))
- enhance input components with improved theming and layout consistency ([5b5a41cf54](https://github.com/RueDeRennes/mosaik/commit/5b5a41cf54))
- enhance select and signature pad components with improved styles for consistency and usability ([8c4ff832f4](https://github.com/RueDeRennes/mosaik/commit/8c4ff832f4))
- add shared styles for grid, virtualize, absolute, tile list, masonry, and title layout components to enhance UI consistency ([cbe8204651](https://github.com/RueDeRennes/mosaik/commit/cbe8204651))
- add shared styles for BackTop and CookieConsent components to enhance UI consistency ([ea0800bf89](https://github.com/RueDeRennes/mosaik/commit/ea0800bf89))
- update chip component styles for improved theming and consistency across appearances ([e397515a48](https://github.com/RueDeRennes/mosaik/commit/e397515a48))
- add shared styles for toggletip, carousel, paginator, drop zone, backdrop, and other components to enhance UI consistency ([62d14f58c6](https://github.com/RueDeRennes/mosaik/commit/62d14f58c6))
- add shared styles for tab, table, and list components to improve UI consistency ([3915378683](https://github.com/RueDeRennes/mosaik/commit/3915378683))
- add shared styles for tree and wizard components to enhance UI consistency ([e3dbaf7ac2](https://github.com/RueDeRennes/mosaik/commit/e3dbaf7ac2))
- enhance persona and QR code components with improved theming and shared styles for consistency ([9a32c6f95f](https://github.com/RueDeRennes/mosaik/commit/9a32c6f95f))
- update floating action button and group styles with improved theming and shared properties for consistency ([09e2c90ca3](https://github.com/RueDeRennes/mosaik/commit/09e2c90ca3))
- enhance toggle button and dropdown button styles with improved theming and shared styles for consistency ([b7423c1248](https://github.com/RueDeRennes/mosaik/commit/b7423c1248))
- update slider and avatar components with improved theming and layout consistency ([e7977bb1c1](https://github.com/RueDeRennes/mosaik/commit/e7977bb1c1))
- add shared styles for slider, meter bar, meter ring, and progress ring components to enhance UI consistency ([09a6c723f0](https://github.com/RueDeRennes/mosaik/commit/09a6c723f0))
- enhance dialog and drawer components with shared styles and improved theming for consistency ([9f5a6c1057](https://github.com/RueDeRennes/mosaik/commit/9f5a6c1057))
- add dialog component styles and theme configurations for improved UI consistency ([c3701084c0](https://github.com/RueDeRennes/mosaik/commit/c3701084c0))
- implement shared styles for ripple elements and add error/success/empty state components for improved consistency ([382d923011](https://github.com/RueDeRennes/mosaik/commit/382d923011))
- update chart themes to use local theme variables and unset default styles for improved consistency ([60aba50dec](https://github.com/RueDeRennes/mosaik/commit/60aba50dec))
- enhance Breadcrumb and Icon components with shared styles and update theme tokens for improved consistency ([43631aabb3](https://github.com/RueDeRennes/mosaik/commit/43631aabb3))
- add router and router-related styles for Joy and Default themes to enhance theming consistency ([33d4882612](https://github.com/RueDeRennes/mosaik/commit/33d4882612))
- update MenuItem and SearchBox styles for improved theming consistency and add shared focus ring styles ([ac0b6710c5](https://github.com/RueDeRennes/mosaik/commit/ac0b6710c5))
- add shared SCSS styles for Menu and Chat components to enhance theming consistency ([b65b7d9d93](https://github.com/RueDeRennes/mosaik/commit/b65b7d9d93))
- update Avatar and Badge styles for improved theming and layout consistency ([d48699783b](https://github.com/RueDeRennes/mosaik/commit/d48699783b))
- add SCSS theme files for media components with shared styling mixins ([9def4b2004](https://github.com/RueDeRennes/mosaik/commit/9def4b2004))
- add SCSS files for media components with initial styling setup ([52eddb1e29](https://github.com/RueDeRennes/mosaik/commit/52eddb1e29))
- update styles to use joy scheme variables for improved theme consistency ([5069a9cc96](https://github.com/RueDeRennes/mosaik/commit/5069a9cc96))
- introduce ITheme2ElementProps interface and enhance Theme2 with palette management ([fedd1abc19](https://github.com/RueDeRennes/mosaik/commit/fedd1abc19))
- implement ThemeGenerator and enhance Theme2Element with public theme application methods ([7c6e338528](https://github.com/RueDeRennes/mosaik/commit/7c6e338528))
- add event handling interfaces for improved event management ([eb8158af09](https://github.com/RueDeRennes/mosaik/commit/eb8158af09))
- hard scss refactoring ([847d18e07a](https://github.com/RueDeRennes/mosaik/commit/847d18e07a))
- update Angular dependencies to version 19.1.5 and add new build configurations ([caa65cbcd7](https://github.com/RueDeRennes/mosaik/commit/caa65cbcd7))
- add node-gyp as a dependency in package.json ([7ee58ddb29](https://github.com/RueDeRennes/mosaik/commit/7ee58ddb29))
- organize vitest workspace configuration by grouping libs, tools, and infra ([b914409938](https://github.com/RueDeRennes/mosaik/commit/b914409938))
- update package.json dependencies to use workspace references ([a09d328efb](https://github.com/RueDeRennes/mosaik/commit/a09d328efb))
- update documentation structure and add metadata for MVP and Command patterns ([aa740dcdc8](https://github.com/RueDeRennes/mosaik/commit/aa740dcdc8))
- add JSON and Markdown configurations to ESLint setup and update index for new configs ([67f5cb6cd9](https://github.com/RueDeRennes/mosaik/commit/67f5cb6cd9))
- add clear method to Renderer and update RouterOutletElement to use it for clearing slots ([e2fb12d2f6](https://github.com/RueDeRennes/mosaik/commit/e2fb12d2f6))
- add @prisma/extension-optimize dependency and enable optimization in PrismaService ([d09a4414dc](https://github.com/RueDeRennes/mosaik/commit/d09a4414dc))
- enhance resource serialization by adding metadata support in serializers and transformers ([d81c5fe981](https://github.com/RueDeRennes/mosaik/commit/d81c5fe981))
- update resource info interfaces to use readonly properties and enhance cloning functionality ([173c1c0d01](https://github.com/RueDeRennes/mosaik/commit/173c1c0d01))
- update CLI argument interfaces and improve resource generator imports ([52697bfaab](https://github.com/RueDeRennes/mosaik/commit/52697bfaab))
- add AI localizator module with configuration and CLI argument support ([38770963c7](https://github.com/RueDeRennes/mosaik/commit/38770963c7))
- add localizator executor and update related configurations ([79a5f1dd0d](https://github.com/RueDeRennes/mosaik/commit/79a5f1dd0d))
- add ESLint configuration for Vitest and implement resource type detection from file paths ([488198e242](https://github.com/RueDeRennes/mosaik/commit/488198e242))
- enhance sorting functionality in resource interfaces and update TypeScript configurations ([6fcb2f3903](https://github.com/RueDeRennes/mosaik/commit/6fcb2f3903))
- implement Vitest configuration and add tests for LitPreset; refactor file handling and update parser methods ([d7b49e2443](https://github.com/RueDeRennes/mosaik/commit/d7b49e2443))
- add ESLint and Vitest configurations, implement TypeScript settings, and define parser and formatter interfaces for localization ([c09d8c541a](https://github.com/RueDeRennes/mosaik/commit/c09d8c541a))
- add ESLint and Vitest configurations for localization tools and implement tests for Angular, React, and Vue presets ([22a450cdd4](https://github.com/RueDeRennes/mosaik/commit/22a450cdd4))
- update package.json files and add TypeScript configurations for localization ([577f8dd710](https://github.com/RueDeRennes/mosaik/commit/577f8dd710))
- implement parser interfaces and various parser classes for localization ([8b5b4258e1](https://github.com/RueDeRennes/mosaik/commit/8b5b4258e1))
- update project CommonJS/ESM TypeScript configurations ([b57802c2d9](https://github.com/RueDeRennes/mosaik/commit/b57802c2d9))
- migrate from lodash to es-toolkit for utility functions and update package dependencies ([cfdb4f64a1](https://github.com/RueDeRennes/mosaik/commit/cfdb4f64a1))
- add tsup configuration for Vite and Utilities, update LiveReload plugin options ([9d0b3a71be](https://github.com/RueDeRennes/mosaik/commit/9d0b3a71be))
- update Vite configuration and improve FileSystemWatcher filtering logic ([43a655b8ac](https://github.com/RueDeRennes/mosaik/commit/43a655b8ac))
- add Vite configuration and plugins, including live reload functionality ([92b0ee5260](https://github.com/RueDeRennes/mosaik/commit/92b0ee5260))
- remove obsolete BlockquoteProcessor tests and add utility functions for token metadata management ([11be8212a8](https://github.com/RueDeRennes/mosaik/commit/11be8212a8))
- add Vitest configuration and implement tests for Markdown processors ([10d745777c](https://github.com/RueDeRennes/mosaik/commit/10d745777c))
- add type annotations for hot update handler and improve import statements in processors ([6c28d98979](https://github.com/RueDeRennes/mosaik/commit/6c28d98979))
- integrate markdowner tool and update API paths for consistency ([21c276f79a](https://github.com/RueDeRennes/mosaik/commit/21c276f79a))
- initialize Mosaik.Elements library with TypeScript configuration and documentation ([121c1196a8](https://github.com/RueDeRennes/mosaik/commit/121c1196a8))
- add mosaik-elements-angular-2 library with initial component and configuration files ([2e4c734f9e](https://github.com/RueDeRennes/mosaik/commit/2e4c734f9e))
- add infrastructure build step to API development workflow ([4f77ea2b30](https://github.com/RueDeRennes/mosaik/commit/4f77ea2b30))
- implement new email delivery strategies ([71d732c67d](https://github.com/RueDeRennes/mosaik/commit/71d732c67d))
- add dependency installation step in GitHub Actions workflow ([0ee17aa199](https://github.com/RueDeRennes/mosaik/commit/0ee17aa199))
- add build infrastructure step and update project configurations with 'infra' tags ([355a7b0768](https://github.com/RueDeRennes/mosaik/commit/355a7b0768))
- add VERBOSE environment variable for detailed linting logs ([e3fe3fad69](https://github.com/RueDeRennes/mosaik/commit/e3fe3fad69))
- add CommandNamingRule for ESLint; update project configuration and enhance documentation ([21e0e36302](https://github.com/RueDeRennes/mosaik/commit/21e0e36302))
- add ICommand interface and implement delete profile view styles; update username references to userName across the codebase ([b7184a2d10](https://github.com/RueDeRennes/mosaik/commit/b7184a2d10))
- **api:** update Doppler configuration to support API key authentication and enhance documentation ([8e4c98a5e0](https://github.com/RueDeRennes/mosaik/commit/8e4c98a5e0))
- **api:** add doppler support for security keys ([bb1dd83041](https://github.com/RueDeRennes/mosaik/commit/bb1dd83041))
- **api:** add new issue models and update icon response; remove unused IIconGroup model ([d05cefc0ed](https://github.com/RueDeRennes/mosaik/commit/d05cefc0ed))
- add docs executor and update package dependencies across multiple libraries ([b55ff52fd4](https://github.com/RueDeRennes/mosaik/commit/b55ff52fd4))
- add GitHub Actions workflow for development app deployment with caching and build steps ([118b8a6bff](https://github.com/RueDeRennes/mosaik/commit/118b8a6bff))
- add SubscribeRequest and UnsubscribeRequest classes, update API response statuses to use HttpStatus, and enhance Prisma configuration for PostgreSQL ([7c49d4098d](https://github.com/RueDeRennes/mosaik/commit/7c49d4098d))
- add Database module and service, integrate with Issues and Newsletter repositories, and update TypeScript configuration ([238c8b509b](https://github.com/RueDeRennes/mosaik/commit/238c8b509b))
- update server port to 8080, add IssuesView and related styles, and enhance ApiService2 with issue management methods ([8e55d5be52](https://github.com/RueDeRennes/mosaik/commit/8e55d5be52))
- navigate to backend directory and list files before building Docker image ([bb4a5f8723](https://github.com/RueDeRennes/mosaik/commit/bb4a5f8723))
- enhance GitHub Actions workflow for Docker by adding artifact upload and improving repository name handling ([b93588e6d5](https://github.com/RueDeRennes/mosaik/commit/b93588e6d5))
- add .dockerignore for mosaik-api and log npm dependencies in build step ([d170a45722](https://github.com/RueDeRennes/mosaik/commit/d170a45722))
- add GitHub Actions workflow for Docker build and push to GHCR ([14f2ed37e1](https://github.com/RueDeRennes/mosaik/commit/14f2ed37e1))
- add backend code ([599d31af49](https://github.com/RueDeRennes/mosaik/commit/599d31af49))
- **nx-cloud:** setup nx cloud workspace ([9dfa175d05](https://github.com/RueDeRennes/mosaik/commit/9dfa175d05))
- add commitlint in repo ([4a71ed5158](https://github.com/RueDeRennes/mosaik/commit/4a71ed5158))
- upgrade to angular 12 ([e604cc6da3](https://github.com/RueDeRennes/mosaik/commit/e604cc6da3))
- **angular:** add cdk dependency to add new dialogService ([8c294ec672](https://github.com/RueDeRennes/mosaik/commit/8c294ec672))
- **commerce:** add new commerce package 🎉 ([b595653878](https://github.com/RueDeRennes/mosaik/commit/b595653878))
- **angular:** add camera recorder typings ([32a8ba560e](https://github.com/RueDeRennes/mosaik/commit/32a8ba560e))

### 🩹 Fixes

- **dependencies:** add @rollup/plugin-json to package.json refactor: simplify build script in openapi templates ([f6a6476388](https://github.com/RueDeRennes/mosaik/commit/f6a6476388))
- **dependencies:** update peer dependency for vite to support versions 6.x and 7.x refactor: remove unused plugins from nx configuration fix: update build script in openapi templates to use yarn ([0422a23610](https://github.com/RueDeRennes/mosaik/commit/0422a23610))
- **dependencies:** update vite to version 7.0.2 in package.json and yarn.lock ([b6b2b61b42](https://github.com/RueDeRennes/mosaik/commit/b6b2b61b42))
- **dependencies:** update @nx packages to version 21.2.2 ([c044affa8d](https://github.com/RueDeRennes/mosaik/commit/c044affa8d))
- update release script to version 0.0.71 ([c3e7e5e8bf](https://github.com/RueDeRennes/mosaik/commit/c3e7e5e8bf))
- add missing newline at end of package.json ([73866991d5](https://github.com/RueDeRennes/mosaik/commit/73866991d5))
- update background color to transparent for page header and menu components; update release script to version 0.0.70 ([e8e7c124a4](https://github.com/RueDeRennes/mosaik/commit/e8e7c124a4))
- update release version to 0.0.47 in package.json ([5a277d2d1d](https://github.com/RueDeRennes/mosaik/commit/5a277d2d1d))
- correct spelling of 'HTML' in keywords and add new article on `part` attributes ([cd5b688a5c](https://github.com/RueDeRennes/mosaik/commit/cd5b688a5c))
- correct quotation marks in attribute selector examples for consistency ([078a6c9289](https://github.com/RueDeRennes/mosaik/commit/078a6c9289))
- correct quotation marks in markdown article and improve blockquote rendering in MarkdownRenderer ([09442e4509](https://github.com/RueDeRennes/mosaik/commit/09442e4509))
- update release script to version 0.0.41 ([88efd1b9ca](https://github.com/RueDeRennes/mosaik/commit/88efd1b9ca))
- adjust height calculations for content in AppElement styles ([1d8793fd52](https://github.com/RueDeRennes/mosaik/commit/1d8793fd52))
- update const vs enum article to use string literals for WorkType values ([3eb355434e](https://github.com/RueDeRennes/mosaik/commit/3eb355434e))
- correct quotation marks in best practices section of const vs enum article ([df4187ec19](https://github.com/RueDeRennes/mosaik/commit/df4187ec19))
- update backdrop image URLs in const vs enum article ([e05a779a0a](https://github.com/RueDeRennes/mosaik/commit/e05a779a0a))
- update release version to 0.0.38 in package.json and improve description formatting in Meta.g.json ([edbd04421c](https://github.com/RueDeRennes/mosaik/commit/edbd04421c))
- correct formatting of region comments and quote attribution for clarity ([952d90f14b](https://github.com/RueDeRennes/mosaik/commit/952d90f14b))
- update provideTheme function to simplify overrides and adjust merge function ([0359c488be](https://github.com/RueDeRennes/mosaik/commit/0359c488be))
- update provideTheme to useValue for theme and mode signals ([5a7b509869](https://github.com/RueDeRennes/mosaik/commit/5a7b509869))
- update release script to version 0.0.33 ([0954fadfa3](https://github.com/RueDeRennes/mosaik/commit/0954fadfa3))
- update markdowner-core dependency to use workspace reference for consistency ([518dffba42](https://github.com/RueDeRennes/mosaik/commit/518dffba42))
- simplify flex-basis and max-width calculations in WrapElement for improved readability ([0fba2a2eef](https://github.com/RueDeRennes/mosaik/commit/0fba2a2eef))
- change progress/ring/bar number properties to cssLength for simpler data binding ([d15e88f0c9](https://github.com/RueDeRennes/mosaik/commit/d15e88f0c9))
- update checkbox styles by removing unnecessary padding and border properties feat: add YouTube video embed and quote to interview markdown fix: adjust marker color in markdown styles for better visibility ([1284a2bcff](https://github.com/RueDeRennes/mosaik/commit/1284a2bcff))
- correct quotes in interview markdown and enhance closing statements ([8d0e7134ba](https://github.com/RueDeRennes/mosaik/commit/8d0e7134ba))
- correct formatting and update YouTube link in interview markdown ([2b430a99bc](https://github.com/RueDeRennes/mosaik/commit/2b430a99bc))
- **docs:** update route in command-pattern-vue.md for correct path; remove outdated mvp.requirements.md file; add comprehensive requirements documentation ([12dd351358](https://github.com/RueDeRennes/mosaik/commit/12dd351358))
- **build:** reorder build steps in deployment script for clarity and consistency ([4e746f0b36](https://github.com/RueDeRennes/mosaik/commit/4e746f0b36))
- correct spelling and casing in IconsService and related files ([f4d478699e](https://github.com/RueDeRennes/mosaik/commit/f4d478699e))
- update build commands in CI workflows to use 'yarn nx run' syntax ([a38e725929](https://github.com/RueDeRennes/mosaik/commit/a38e725929))
- update description of mosaik-api in README.md for clarity ([478b4c5177](https://github.com/RueDeRennes/mosaik/commit/478b4c5177))
- restore missing languages and sites in app.json configuration ([ad5f019e46](https://github.com/RueDeRennes/mosaik/commit/ad5f019e46))
- adjust positioning for lightChain and update CookieConsentElement attributes ([708c9832bd](https://github.com/RueDeRennes/mosaik/commit/708c9832bd))
- remove verbose flag from mosaik app build command ([f8f2b53714](https://github.com/RueDeRennes/mosaik/commit/f8f2b53714))
- update theme import paths to use consistent casing ([1aa18b699e](https://github.com/RueDeRennes/mosaik/commit/1aa18b699e))
- hide portal element by default in TimeBoxElementTemplate ([f5f16c13b7](https://github.com/RueDeRennes/mosaik/commit/f5f16c13b7))
- add missing newline at end of package.json ([713cb1f983](https://github.com/RueDeRennes/mosaik/commit/713cb1f983))
- simplify condition checks and remove unnecessary styles in various components ([41e6b5d8a9](https://github.com/RueDeRennes/mosaik/commit/41e6b5d8a9))
- update release script to version 0.0.28 ([baaef44d1d](https://github.com/RueDeRennes/mosaik/commit/baaef44d1d))
- update hover and selection styles for TabStrip and Tree components ([d6c90fc2bb](https://github.com/RueDeRennes/mosaik/commit/d6c90fc2bb))
- add missing newline at end of package.json ([39f2f1c578](https://github.com/RueDeRennes/mosaik/commit/39f2f1c578))
- update TabStrip and TreeItem styles to handle disabled state correctly ([ecb60798db](https://github.com/RueDeRennes/mosaik/commit/ecb60798db))
- update release version to 0.0.19 in package.json ([acccb56f76](https://github.com/RueDeRennes/mosaik/commit/acccb56f76))
- add missing newline at end of package.json ([43ce0e6a3b](https://github.com/RueDeRennes/mosaik/commit/43ce0e6a3b))
- correct spelling of 'getScrollableElement' and remove unused method ([72e17ecc7a](https://github.com/RueDeRennes/mosaik/commit/72e17ecc7a))
- correct spelling of 'success' in logSummary parameter documentation chore: update release script version to 0.0.16 chore: add 'keyhandle' to cspell words ([1a9d5e8732](https://github.com/RueDeRennes/mosaik/commit/1a9d5e8732))
- improve type handling and cleanup in Invalidable, CheckBoxGroup, ChoiceGroup, and RadioGroup components ([84753f810c](https://github.com/RueDeRennes/mosaik/commit/84753f810c))
- correct spelling of "Emitts" to "Emits" in event documentation across multiple components ([17e025c185](https://github.com/RueDeRennes/mosaik/commit/17e025c185))
- correct spelling errors in README and update release version in package.json ([922364afec](https://github.com/RueDeRennes/mosaik/commit/922364afec))
- different themes and styles ([917e55212d](https://github.com/RueDeRennes/mosaik/commit/917e55212d))
- add missing words to cSpell configuration ([933dd56139](https://github.com/RueDeRennes/mosaik/commit/933dd56139))
- correct spelling errors and improve property names in interfaces and components ([e7edf69f3e](https://github.com/RueDeRennes/mosaik/commit/e7edf69f3e))
- remove OTP prompt from publish package task and update related function signatures ([a684f8dc7e](https://github.com/RueDeRennes/mosaik/commit/a684f8dc7e))
- disable caching in project configurations and update build scripts for consistency ([0bf27cb99e](https://github.com/RueDeRennes/mosaik/commit/0bf27cb99e))
- add missing newline at end of package.json files across multiple directories ([a01c97ed2b](https://github.com/RueDeRennes/mosaik/commit/a01c97ed2b))
- correct build script command for SCSS and update build commands in project configuration ([0b243a90be](https://github.com/RueDeRennes/mosaik/commit/0b243a90be))
- update theme in index.html and enhance logging in CopyPublisherPackageJson.ts; add release targets to project.json files; remove obsolete scripts ([648a850c12](https://github.com/RueDeRennes/mosaik/commit/648a850c12))
- correct package name format in changeset configuration and add release script to package.json ([168113d104](https://github.com/RueDeRennes/mosaik/commit/168113d104))
- update package.json dependencies to use version 0.0.0 for consistency across all packages ([9b37f5626c](https://github.com/RueDeRennes/mosaik/commit/9b37f5626c))
- revert package versions to 0.0.0 for consistency across all packages ([8e39bb4e60](https://github.com/RueDeRennes/mosaik/commit/8e39bb4e60))
- update disabled state handling for various components ([bbabccda83](https://github.com/RueDeRennes/mosaik/commit/bbabccda83))
- update Angular dependencies to use caret versioning and remove unused mosaik-elements-angular-2 entry ([65f2f21abf](https://github.com/RueDeRennes/mosaik/commit/65f2f21abf))
- Refactor LitStyleTransform to remove unnecessary timing logs; update ExpanderElement styles for improved theming support ([3ca2b0d734](https://github.com/RueDeRennes/mosaik/commit/3ca2b0d734))
- Correct cache option handling across multiple executors and tasks ([bdbcb05c08](https://github.com/RueDeRennes/mosaik/commit/bdbcb05c08))
- update SKIP_LINT variable to use lowercase 'true' for consistency ([319f15f508](https://github.com/RueDeRennes/mosaik/commit/319f15f508))
- restore 'detect' configuration in project.json and update package manager version in package.json ([ff659684a6](https://github.com/RueDeRennes/mosaik/commit/ff659684a6))
- ensure form elements inherit styles correctly in formElementJoyStyle ([8c3dc71259](https://github.com/RueDeRennes/mosaik/commit/8c3dc71259))
- change constructor visibility from protected to public in StateElement class ([4fdc37f008](https://github.com/RueDeRennes/mosaik/commit/4fdc37f008))
- update theme default settings and padding values for improved consistency across card components ([11c519bf66](https://github.com/RueDeRennes/mosaik/commit/11c519bf66))
- update background color and padding values to unset for improved theme consistency across components ([fe22eaa2ca](https://github.com/RueDeRennes/mosaik/commit/fe22eaa2ca))
- update shared-style mixin to use local $name variable for consistency across components ([dc5fdb55df](https://github.com/RueDeRennes/mosaik/commit/dc5fdb55df))
- update yarn clean script to remove force option ([723efb5c42](https://github.com/RueDeRennes/mosaik/commit/723efb5c42))
- add missing React and Vue dependencies to package.json ([ee2fb6360f](https://github.com/RueDeRennes/mosaik/commit/ee2fb6360f))
- update TypeScript configurations for consistency and readability ([a74cd93fc1](https://github.com/RueDeRennes/mosaik/commit/a74cd93fc1))
- update dependencies in package.json files to latest versions ([00c4430b43](https://github.com/RueDeRennes/mosaik/commit/00c4430b43))
- update package.json to add Angular DevKit and Nx dependencies ([d86b800714](https://github.com/RueDeRennes/mosaik/commit/d86b800714))
- format json configuration files for consistency and readability ([f4e4b56db6](https://github.com/RueDeRennes/mosaik/commit/f4e4b56db6))
- update .gitignore to simplify custom entries and add Angular build artifacts ([8dbc5e0cfe](https://github.com/RueDeRennes/mosaik/commit/8dbc5e0cfe))
- add 'mosaik-ng' to package.json and clean up ToastComponent code with consistent formatting ([8871b31d8b](https://github.com/RueDeRennes/mosaik/commit/8871b31d8b))
- add Angular CLI to install script and update EventEmitter definitions for consistency across components ([d46388649e](https://github.com/RueDeRennes/mosaik/commit/d46388649e))
- remove unnecessary comments and continue-on-error flags in lint jobs for clarity ([a5cc2fbfe3](https://github.com/RueDeRennes/mosaik/commit/a5cc2fbfe3))
- simplify lint command in GitHub Actions workflow ([f6324c6be3](https://github.com/RueDeRennes/mosaik/commit/f6324c6be3))
- enable verbose linting for mosaik-elements-foundation ([9262eb8c5b](https://github.com/RueDeRennes/mosaik/commit/9262eb8c5b))
- correct SKIP_LINT environment variable to use lowercase 'false' ([e04ba33fb4](https://github.com/RueDeRennes/mosaik/commit/e04ba33fb4))
- update API endpoint to use Render URL instead of localhost ([3f3df24c15](https://github.com/RueDeRennes/mosaik/commit/3f3df24c15))
- update deployment path in GitHub Actions workflow for backend API ([4d9721e02f](https://github.com/RueDeRennes/mosaik/commit/4d9721e02f))
- remove redundant ls command from Docker build step in GitHub Actions workflow ([35074e3608](https://github.com/RueDeRennes/mosaik/commit/35074e3608))
- remove redundant npm list commands in GitHub Actions build step ([88cbee4e84](https://github.com/RueDeRennes/mosaik/commit/88cbee4e84))
- update GitHub Actions workflow to install npm packages and list global dependencies ([eda5a6b1f9](https://github.com/RueDeRennes/mosaik/commit/eda5a6b1f9))
- update build step in GitHub Actions to list global npm packages ([f53cf75b47](https://github.com/RueDeRennes/mosaik/commit/f53cf75b47))
- meta path ([7a3bdb39ef](https://github.com/RueDeRennes/mosaik/commit/7a3bdb39ef))

## 0.0.71 (2025-06-30)

### 🩹 Fixes

- add missing newline at end of package.json ([73866991d5](https://github.com/RueDeRennes/mosaik/commit/73866991d5))

## 0.0.70 (2025-06-28)

### 🩹 Fixes

- update background color to transparent for page header and menu components; update release script to version 0.0.70 ([e8e7c124a4](https://github.com/RueDeRennes/mosaik/commit/e8e7c124a4))

## 0.0.69 (2025-06-26)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.68 (2025-06-26)

### 🚀 Features

- add copyExecutorsJson script and update build commands ([0a0aba85b9](https://github.com/RueDeRennes/mosaik/commit/0a0aba85b9))

## 0.0.67 (2025-06-26)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.66 (2025-06-25)

### 🚀 Features

- update Carousel component methods and add select method implementation ([351e68a615](https://github.com/RueDeRennes/mosaik/commit/351e68a615))

## 0.0.65 (2025-06-25)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.64 (2025-06-25)

### 🚀 Features

- update menu component styles and structure for improved layout and responsiveness ([373095056e](https://github.com/RueDeRennes/mosaik/commit/373095056e))

## 0.0.63 (2025-06-24)

### 🚀 Features

- add icon functionality with IconDirective and IconRegistry, enhance app layout with new directives ([8acea01349](https://github.com/RueDeRennes/mosaik/commit/8acea01349))
- enhance app layout and styling with new components and responsive design ([8919fccc0c](https://github.com/RueDeRennes/mosaik/commit/8919fccc0c))

## 0.0.62 (2025-06-24)

### 🚀 Features

- enhance Jumbotron components with slot definitions and improve HideOnScrollController methods ([4cc6d9de3a](https://github.com/RueDeRennes/mosaik/commit/4cc6d9de3a))

## 0.0.61 (2025-06-24)

### 🚀 Features

- Add formatter property to Jumbotron components and update related files ([9ae59c7ff9](https://github.com/RueDeRennes/mosaik/commit/9ae59c7ff9))

## 0.0.60 (2025-06-23)

### 🚀 Features

- Add Svelte titles to German and English translations; update formatting keys in various components ([9889da1578](https://github.com/RueDeRennes/mosaik/commit/9889da1578))
- Add Jumbotron component and related styles for multiple frameworks ([41d4601e08](https://github.com/RueDeRennes/mosaik/commit/41d4601e08))

## 0.0.59 (2025-06-23)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.58 (2025-06-23)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.57 (2025-06-23)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.56 (2025-06-23)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.55 (2025-06-23)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.54 (2025-06-23)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.53 (2025-06-23)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.52 (2025-06-23)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.51 (2025-06-23)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.50 (2025-06-23)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.49 (2025-06-22)

### 🚀 Features

- enhance backdrop styles and refactor breakpoint handling ([39661be30c](https://github.com/RueDeRennes/mosaik/commit/39661be30c))

## 0.0.48 (2025-06-22)

### 🚀 Features

- Update layout variables for Cosmopolitan and Joy themes in various components ([af9ca676db](https://github.com/RueDeRennes/mosaik/commit/af9ca676db))
- Introduce Indicator component across multiple frameworks ([7ef850c39d](https://github.com/RueDeRennes/mosaik/commit/7ef850c39d))

## 0.0.47 (2025-06-22)

### 🚀 Features

- Update Indicator component styles and tokens for layout spacing ([201ee59059](https://github.com/RueDeRennes/mosaik/commit/201ee59059))
- Add Indicator component and related functionality ([b55b86b0e2](https://github.com/RueDeRennes/mosaik/commit/b55b86b0e2))

### 🩹 Fixes

- update release version to 0.0.47 in package.json ([5a277d2d1d](https://github.com/RueDeRennes/mosaik/commit/5a277d2d1d))
- correct spelling of 'HTML' in keywords and add new article on `part` attributes ([cd5b688a5c](https://github.com/RueDeRennes/mosaik/commit/cd5b688a5c))
- correct quotation marks in attribute selector examples for consistency ([078a6c9289](https://github.com/RueDeRennes/mosaik/commit/078a6c9289))
- correct quotation marks in markdown article and improve blockquote rendering in MarkdownRenderer ([09442e4509](https://github.com/RueDeRennes/mosaik/commit/09442e4509))

## 0.0.46 (2025-06-20)

### 🚀 Features

- implement animation directive and provider with presets ([09550b6633](https://github.com/RueDeRennes/mosaik/commit/09550b6633))

## 0.0.45 (2025-06-20)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.44 (2025-06-20)

### 🚀 Features

- enhance theme merging logic and add support for deep partial overrides ([870d64b42b](https://github.com/RueDeRennes/mosaik/commit/870d64b42b))

## 0.0.43 (2025-06-20)

### 🚀 Features

- Remove unused 'onInput' method from ColorPicker components and update related code ([d84ece1672](https://github.com/RueDeRennes/mosaik/commit/d84ece1672))
- Add Svelte support with SvelteCodeGenerator and update build scripts ([955cb75cb6](https://github.com/RueDeRennes/mosaik/commit/955cb75cb6))
- Add new Svelte components for menu, segment, tab, table, tree, wizard, and shell ([e6de8f0553](https://github.com/RueDeRennes/mosaik/commit/e6de8f0553))

## 0.0.42 (2025-06-20)

### 🚀 Features

- add Color Palette Builder tool and associated views ([55a992138e](https://github.com/RueDeRennes/mosaik/commit/55a992138e))

### 🩹 Fixes

- update release script to version 0.0.41 ([88efd1b9ca](https://github.com/RueDeRennes/mosaik/commit/88efd1b9ca))

## 0.0.41 (2025-06-19)

### 🚀 Features

- add comprehensive article on using const vs enums in TypeScript with Angular templates ([8db46644e3](https://github.com/RueDeRennes/mosaik/commit/8db46644e3))

### 🩹 Fixes

- adjust height calculations for content in AppElement styles ([1d8793fd52](https://github.com/RueDeRennes/mosaik/commit/1d8793fd52))
- update const vs enum article to use string literals for WorkType values ([3eb355434e](https://github.com/RueDeRennes/mosaik/commit/3eb355434e))
- correct quotation marks in best practices section of const vs enum article ([df4187ec19](https://github.com/RueDeRennes/mosaik/commit/df4187ec19))
- update backdrop image URLs in const vs enum article ([e05a779a0a](https://github.com/RueDeRennes/mosaik/commit/e05a779a0a))

## 0.0.40 (2025-06-18)

### 🚀 Features

- add hasHeader and hasNav properties to AppElement and update related components ([37baedabae](https://github.com/RueDeRennes/mosaik/commit/37baedabae))
- add localizator-core dependency and update build dependencies in project configuration ([077a2cd1d9](https://github.com/RueDeRennes/mosaik/commit/077a2cd1d9))

## 0.0.39 (2025-06-17)

### 🩹 Fixes

- update release version to 0.0.38 in package.json and improve description formatting in Meta.g.json ([edbd04421c](https://github.com/RueDeRennes/mosaik/commit/edbd04421c))

## 0.0.38 (2025-06-17)

### 🚀 Features

- add FlexDirective for flexible layout management in Angular ([3b8f27e2b7](https://github.com/RueDeRennes/mosaik/commit/3b8f27e2b7))
- add comprehensive guide on the power of regions in TypeScript for improved code organization ([564b600288](https://github.com/RueDeRennes/mosaik/commit/564b600288))

### 🩹 Fixes

- correct formatting of region comments and quote attribution for clarity ([952d90f14b](https://github.com/RueDeRennes/mosaik/commit/952d90f14b))
- update provideTheme function to simplify overrides and adjust merge function ([0359c488be](https://github.com/RueDeRennes/mosaik/commit/0359c488be))

## 0.0.37 (2025-06-17)

### 🩹 Fixes

- update provideTheme to useValue for theme and mode signals ([5a7b509869](https://github.com/RueDeRennes/mosaik/commit/5a7b509869))

## 0.0.35 (2025-06-17)

### 🚀 Features

- add theme provider for angular ([04568d1528](https://github.com/RueDeRennes/mosaik/commit/04568d1528))

## 0.0.34 (2025-06-17)

### 🩹 Fixes

- update release script to version 0.0.33 ([0954fadfa3](https://github.com/RueDeRennes/mosaik/commit/0954fadfa3))

## 0.0.33 (2025-06-16)

### 🚀 Features

- update masonry and wrap elements to use CSS variables for gap and columns, enhance templates with static styles ([2dee486060](https://github.com/RueDeRennes/mosaik/commit/2dee486060))
- disable eslint rule for static styles in multiple component templates and update SCSS mixin to exclude properties ([d6e61ac195](https://github.com/RueDeRennes/mosaik/commit/d6e61ac195))
- enhance keyboard element with modifier key support and update styles ([07f7af6d52](https://github.com/RueDeRennes/mosaik/commit/07f7af6d52))
- enhance dropdown button templates with new icons and improved layout fix: adjust padding for menu item group headers across themes ([5004c67e11](https://github.com/RueDeRennes/mosaik/commit/5004c67e11))
- add 'Code' and 'TypeScript' keywords to various documentation files for improved discoverability ([7ac3c152dd](https://github.com/RueDeRennes/mosaik/commit/7ac3c152dd))
- add "The Dependency Forest" article on dependency management challenges in Angular ([d129b84490](https://github.com/RueDeRennes/mosaik/commit/d129b84490))
- add translation command and integrate translation functionality in BlogBaseElement ([7e166a6bea](https://github.com/RueDeRennes/mosaik/commit/7e166a6bea))
- enhance blog and translation features with interview type and language flags ([9aff64d29b](https://github.com/RueDeRennes/mosaik/commit/9aff64d29b))
- update interview content and add StickyController metadata in JSON ([c39d970be6](https://github.com/RueDeRennes/mosaik/commit/c39d970be6))
- add YouTube video rendering support in MarkdownRenderer ([723610d3c8](https://github.com/RueDeRennes/mosaik/commit/723610d3c8))
- Add new translation for "Open with" in code section ([e1b84033bc](https://github.com/RueDeRennes/mosaik/commit/e1b84033bc))
- create Playground components for testing Markdown features ([738f61002f](https://github.com/RueDeRennes/mosaik/commit/738f61002f))
- enhance Listen decorator to support custom query targets and improve event handling ([aa19e6e5a0](https://github.com/RueDeRennes/mosaik/commit/aa19e6e5a0))
- add PinchController for gesture recognition and enhance DiagramElement with centering functionality ([c3feb9a789](https://github.com/RueDeRennes/mosaik/commit/c3feb9a789))
- **docs:** Update documentation with new sections, descriptions, and examples for clarity and usability ([c32ff5f976](https://github.com/RueDeRennes/mosaik/commit/c32ff5f976))
- **docs:** Enhance MVP pattern documentation with detailed explanations and examples ([e3c97f1368](https://github.com/RueDeRennes/mosaik/commit/e3c97f1368))
- implement filter functionality in ArticlesView and update related templates ([1e88d302d4](https://github.com/RueDeRennes/mosaik/commit/1e88d302d4))
- Implement sticky positioning directive and controller, enhance scrolling functionality in Scroller class ([148f07916e](https://github.com/RueDeRennes/mosaik/commit/148f07916e))
- Enhance MVP documentation and examples across multiple frameworks ([cfabea14a3](https://github.com/RueDeRennes/mosaik/commit/cfabea14a3))
- add backdrop images and enhance ArticlesView with documentation grouping ([af72ff74cd](https://github.com/RueDeRennes/mosaik/commit/af72ff74cd))
- add images and enhance Markdown documentation with improved layout and structure ([1eaac2125f](https://github.com/RueDeRennes/mosaik/commit/1eaac2125f))
- enhance Markdown components with improved styling and layout variables ([780d383b31](https://github.com/RueDeRennes/mosaik/commit/780d383b31))
- enhance CodeEditor and Markdown components with improved language and theme support ([0270711752](https://github.com/RueDeRennes/mosaik/commit/0270711752))
- **callouts:** add new callout variants and enhance Markdown processing ([3a5608697b](https://github.com/RueDeRennes/mosaik/commit/3a5608697b))
- **markdowner:** enhance Markdown processing with new extension structure and build integration ([0c08852146](https://github.com/RueDeRennes/mosaik/commit/0c08852146))
- Enhance Markdown processing with new features and improvements ([534983c407](https://github.com/RueDeRennes/mosaik/commit/534983c407))
- **translations:** add share message for blog posts ([a3ba45071a](https://github.com/RueDeRennes/mosaik/commit/a3ba45071a))
- improve date formatting in BlogBase and enhance share command data structure ([6f64d0990e](https://github.com/RueDeRennes/mosaik/commit/6f64d0990e))
- enhance Markdown component styles with improved blockquote and list formatting ([dbefc8d12f](https://github.com/RueDeRennes/mosaik/commit/dbefc8d12f))
- refactor text overflow handling and enhance Markdown component styles ([62bb601fc7](https://github.com/RueDeRennes/mosaik/commit/62bb601fc7))
- Update AppSideNavTemplate to use node meta for display names and add value binding ([1488b7d52f](https://github.com/RueDeRennes/mosaik/commit/1488b7d52f))
- update metadata structure in documentation and improve avatar and chip components ([007bd05bea](https://github.com/RueDeRennes/mosaik/commit/007bd05bea))
- enhance Markdown rendering and styling with new link styles and tree directive support ([8fba55993c](https://github.com/RueDeRennes/mosaik/commit/8fba55993c))
- update markdown files to use structured keywords and add author information ([d0df1b883f](https://github.com/RueDeRennes/mosaik/commit/d0df1b883f))

### 🩹 Fixes

- update markdowner-core dependency to use workspace reference for consistency ([518dffba42](https://github.com/RueDeRennes/mosaik/commit/518dffba42))
- simplify flex-basis and max-width calculations in WrapElement for improved readability ([0fba2a2eef](https://github.com/RueDeRennes/mosaik/commit/0fba2a2eef))
- change progress/ring/bar number properties to cssLength for simpler data binding ([d15e88f0c9](https://github.com/RueDeRennes/mosaik/commit/d15e88f0c9))
- update checkbox styles by removing unnecessary padding and border properties feat: add YouTube video embed and quote to interview markdown fix: adjust marker color in markdown styles for better visibility ([1284a2bcff](https://github.com/RueDeRennes/mosaik/commit/1284a2bcff))
- correct quotes in interview markdown and enhance closing statements ([8d0e7134ba](https://github.com/RueDeRennes/mosaik/commit/8d0e7134ba))
- correct formatting and update YouTube link in interview markdown ([2b430a99bc](https://github.com/RueDeRennes/mosaik/commit/2b430a99bc))

## 0.0.32 (2025-06-05)

### 🚀 Features

- **docs): enhance keyword metadata across documentation files for improved searchability and context feat(Markdown): update MarkdownElement and MarkdownRenderer for better handling of text and code blocks fix(DocsService): refine getDocsTree method for improved documentation hierarchy and sorting fix(staticContent:** add meta information to static content registration for enhanced metadata handling ([789875e05d](https://github.com/RueDeRennes/mosaik/commit/789875e05d))
- **build:** add vite-plugins build step to deployment script; enhance MarkdownElement and DocsService for better handling of documentation and Markdown sources ([619a32e38b](https://github.com/RueDeRennes/mosaik/commit/619a32e38b))
- **menu:** add textOverflow property to MenuItemComponent and related elements for improved text handling; update DocsService and AppSideNavTemplate for better rendering ([9b7641b6c1](https://github.com/RueDeRennes/mosaik/commit/9b7641b6c1))
- **router:** implement RouterLocation and IRouterLocation for improved routing abstraction; refactor RouterElement to utilize new location handling ([53705c577a](https://github.com/RueDeRennes/mosaik/commit/53705c577a))
- **menu:** enhance menu item styles with indent properties and update theme tokens for better visual hierarchy ([b3dad3c306](https://github.com/RueDeRennes/mosaik/commit/b3dad3c306))
- **router:** enhance routing components with role attributes and update templates for better accessibility; refactor RouterController and RouterLinkDirective for improved functionality ([63b32829f1](https://github.com/RueDeRennes/mosaik/commit/63b32829f1))
- **router:** implement routerLink directive for dynamic link handling; update AppSideNavTemplate to use routerLink ([f2fb309d47](https://github.com/RueDeRennes/mosaik/commit/f2fb309d47))
- **router:** add RouterLinkDirective for dynamic link generation ([ab2e98ed50](https://github.com/RueDeRennes/mosaik/commit/ab2e98ed50))
- enhance package service and controller to support history retrieval with optional limit; update translations and styles for package explorer ([71efae2557](https://github.com/RueDeRennes/mosaik/commit/71efae2557))
- implement ShieldElement with template, style, and props; enhance package metadata and history models ([de73abbc76](https://github.com/RueDeRennes/mosaik/commit/de73abbc76))
- enhance package service and models with metadata and history retrieval ([05c98c197d](https://github.com/RueDeRennes/mosaik/commit/05c98c197d))
- add package manager installation step in CI workflow ([d8453719df](https://github.com/RueDeRennes/mosaik/commit/d8453719df))
- add eslint config build step to the dev deployment workflow ([c831986474](https://github.com/RueDeRennes/mosaik/commit/c831986474))

### 🩹 Fixes

- **docs:** update route in command-pattern-vue.md for correct path; remove outdated mvp.requirements.md file; add comprehensive requirements documentation ([12dd351358](https://github.com/RueDeRennes/mosaik/commit/12dd351358))
- **build:** reorder build steps in deployment script for clarity and consistency ([4e746f0b36](https://github.com/RueDeRennes/mosaik/commit/4e746f0b36))
- correct spelling and casing in IconsService and related files ([f4d478699e](https://github.com/RueDeRennes/mosaik/commit/f4d478699e))
- update build commands in CI workflows to use 'yarn nx run' syntax ([a38e725929](https://github.com/RueDeRennes/mosaik/commit/a38e725929))
- update description of mosaik-api in README.md for clarity ([478b4c5177](https://github.com/RueDeRennes/mosaik/commit/478b4c5177))
- restore missing languages and sites in app.json configuration ([ad5f019e46](https://github.com/RueDeRennes/mosaik/commit/ad5f019e46))
- adjust positioning for lightChain and update CookieConsentElement attributes ([708c9832bd](https://github.com/RueDeRennes/mosaik/commit/708c9832bd))
- remove verbose flag from mosaik app build command ([f8f2b53714](https://github.com/RueDeRennes/mosaik/commit/f8f2b53714))
- update theme import paths to use consistent casing ([1aa18b699e](https://github.com/RueDeRennes/mosaik/commit/1aa18b699e))

## 0.0.31 (2025-05-28)

### 🚀 Features

- add component selector to various sample elements for better integration ([3eb465fed5](https://github.com/RueDeRennes/mosaik/commit/3eb465fed5))
- Update button element CSS properties and enhance template styles ([c83ee77d83](https://github.com/RueDeRennes/mosaik/commit/c83ee77d83))
- Enhance sandbox functionality and UI improvements ([c45d7ca09b](https://github.com/RueDeRennes/mosaik/commit/c45d7ca09b))
- Implement ProjectionController for managing projected content in portals ([1bc46717b5](https://github.com/RueDeRennes/mosaik/commit/1bc46717b5))
- add TableFooter component and related styles ([85d9e96af5](https://github.com/RueDeRennes/mosaik/commit/85d9e96af5))
- Enhance state elements with padding and gap properties ([19074a8b51](https://github.com/RueDeRennes/mosaik/commit/19074a8b51))
- Enhance Select and Combo components with internationalization and improved styling ([8d80d58234](https://github.com/RueDeRennes/mosaik/commit/8d80d58234))
- enhance TagCloudElement with item selection and styling; refactor related components and styles ([2847e96a41](https://github.com/RueDeRennes/mosaik/commit/2847e96a41))
- add ModifierKeyName export and improve attr() function in SCSS ([317b75143d](https://github.com/RueDeRennes/mosaik/commit/317b75143d))
- Refactor CheckBoxGroupSample and TextBoxSample components for improved property formatting ([b0fcc7502e](https://github.com/RueDeRennes/mosaik/commit/b0fcc7502e))

### 🩹 Fixes

- hide portal element by default in TimeBoxElementTemplate ([f5f16c13b7](https://github.com/RueDeRennes/mosaik/commit/f5f16c13b7))
- add missing newline at end of package.json ([713cb1f983](https://github.com/RueDeRennes/mosaik/commit/713cb1f983))

## 0.0.30 (2025-05-20)

### 🩹 Fixes

- simplify condition checks and remove unnecessary styles in various components ([41e6b5d8a9](https://github.com/RueDeRennes/mosaik/commit/41e6b5d8a9))

## 0.0.29 (2025-05-20)

### 🩹 Fixes

- update release script to version 0.0.28 ([baaef44d1d](https://github.com/RueDeRennes/mosaik/commit/baaef44d1d))

## 0.0.28 (2025-05-20)

### 🩹 Fixes

- update hover and selection styles for TabStrip and Tree components ([d6c90fc2bb](https://github.com/RueDeRennes/mosaik/commit/d6c90fc2bb))
- add missing newline at end of package.json ([39f2f1c578](https://github.com/RueDeRennes/mosaik/commit/39f2f1c578))

## 0.0.27 (2025-05-20)

### 🚀 Features

- add default values for boolean attributes across various components ([899d593ba5](https://github.com/RueDeRennes/mosaik/commit/899d593ba5))
- update release script to version 0.0.26 ([11e2fdbc4f](https://github.com/RueDeRennes/mosaik/commit/11e2fdbc4f))

### 🩹 Fixes

- update TabStrip and TreeItem styles to handle disabled state correctly ([ecb60798db](https://github.com/RueDeRennes/mosaik/commit/ecb60798db))

## 0.0.26 (2025-05-19)

### 🚀 Features

- update release script to version 0.0.25 ([930ba60eb4](https://github.com/RueDeRennes/mosaik/commit/930ba60eb4))

## 0.0.25 (2025-05-19)

### 🚀 Features

- update version to 0.0.24 and remove prefix/suffix styles from various components ([d061c7f8cd](https://github.com/RueDeRennes/mosaik/commit/d061c7f8cd))

## 0.0.24 (2025-05-19)

### 🚀 Features

- update appearance of input components and add textAlign property ([5f7321b7a8](https://github.com/RueDeRennes/mosaik/commit/5f7321b7a8))

## 0.0.23 (2025-05-19)

### 🚀 Features

- Add text alignment support to input components ([0a1069f47d](https://github.com/RueDeRennes/mosaik/commit/0a1069f47d))
- Add Validators class to Cdk for form validation ([5db8b51601](https://github.com/RueDeRennes/mosaik/commit/5db8b51601))

## 0.0.22 (2025-05-18)

### 🚀 Features

- add spinner and textAlign properties to NumberBox and TextBox components ([cda90dffa4](https://github.com/RueDeRennes/mosaik/commit/cda90dffa4))

## 0.0.21 (2025-05-18)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.20 (2025-05-18)

### 🚀 Features

- implement flip component with new side property and directives ([2b3c56c9b4](https://github.com/RueDeRennes/mosaik/commit/2b3c56c9b4))

### 🩹 Fixes

- update release version to 0.0.19 in package.json ([acccb56f76](https://github.com/RueDeRennes/mosaik/commit/acccb56f76))

## 0.0.19 (2025-05-18)

### 🩹 Fixes

- add missing newline at end of package.json ([43ce0e6a3b](https://github.com/RueDeRennes/mosaik/commit/43ce0e6a3b))

## 0.0.18 (2025-05-18)

### 🚀 Features

- add select component to auth form and improve validation ([4971bba07f](https://github.com/RueDeRennes/mosaik/commit/4971bba07f))

### 🩹 Fixes

- correct spelling of 'getScrollableElement' and remove unused method ([72e17ecc7a](https://github.com/RueDeRennes/mosaik/commit/72e17ecc7a))

## 0.0.17 (2025-05-18)

### 🚀 Features

- add Invalidable behavior and validity check to components ([893bb30b3b](https://github.com/RueDeRennes/mosaik/commit/893bb30b3b))

## 0.0.16 (2025-05-17)

### 🚀 Features

- add ng forms validation trigger ([e430f70f31](https://github.com/RueDeRennes/mosaik/commit/e430f70f31))

### 🩹 Fixes

- correct spelling of 'success' in logSummary parameter documentation chore: update release script version to 0.0.16 chore: add 'keyhandle' to cspell words ([1a9d5e8732](https://github.com/RueDeRennes/mosaik/commit/1a9d5e8732))

## 0.0.15 (2025-05-16)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.14 (2025-05-16)

### 🩹 Fixes

- improve type handling and cleanup in Invalidable, CheckBoxGroup, ChoiceGroup, and RadioGroup components ([84753f810c](https://github.com/RueDeRennes/mosaik/commit/84753f810c))

## 0.0.13 (2025-05-16)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.12-beta.13 (2025-05-16)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.12-beta.12 (2025-05-16)

### 🚀 Features

- update project dependencies and build configurations ([569b1bf99d](https://github.com/RueDeRennes/mosaik/commit/569b1bf99d))

### 🩹 Fixes

- correct spelling of "Emitts" to "Emits" in event documentation across multiple components ([17e025c185](https://github.com/RueDeRennes/mosaik/commit/17e025c185))

## 0.0.12-beta.11 (2025-05-13)

### 🚀 Features

- **eslint:** add TypeScript ESLint configuration with comprehensive ruleset ([4d7a0d88b7](https://github.com/RueDeRennes/mosaik/commit/4d7a0d88b7))
- Add Insetable behavior and update BoxElement styles ([ca740ab5f2](https://github.com/RueDeRennes/mosaik/commit/ca740ab5f2))
- export dateTimeBoxElementValueAccessor alongside DateTimeBoxElementValueAccessor for improved accessibility ([fad7497ba7](https://github.com/RueDeRennes/mosaik/commit/fad7497ba7))

### 🩹 Fixes

- correct spelling errors in README and update release version in package.json ([922364afec](https://github.com/RueDeRennes/mosaik/commit/922364afec))
- different themes and styles ([917e55212d](https://github.com/RueDeRennes/mosaik/commit/917e55212d))
- add missing words to cSpell configuration ([933dd56139](https://github.com/RueDeRennes/mosaik/commit/933dd56139))
- correct spelling errors and improve property names in interfaces and components ([e7edf69f3e](https://github.com/RueDeRennes/mosaik/commit/e7edf69f3e))

## 0.0.12-beta.9 (2025-05-07)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.12-beta.8 (2025-05-07)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.12-beta.7 (2025-05-07)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.12-beta.6 (2025-05-07)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.12-beta.5 (2025-05-07)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.12-beta.3 (2025-05-07)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.12-beta.1 (2025-05-07)

This was a version bump only for mosaik-elements-foundation to align it with other projects, there were no code changes.

## 0.0.12-beta.0 (2025-05-07)

### 🚀 Features

- enhance project configurations with inputs and outputs for build targets ([6f80d15bda](https://github.com/RueDeRennes/mosaik/commit/6f80d15bda))

## 0.0.2-beta.0 (2025-05-06)

### 🚀 Features

- enhance project configurations with inputs and outputs for build targets ([6f80d15bda](https://github.com/RueDeRennes/mosaik/commit/6f80d15bda))
