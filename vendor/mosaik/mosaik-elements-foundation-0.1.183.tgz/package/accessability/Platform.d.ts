/**
 * @public
 */
export type PlatformType = 'browser' | 'desktop' | 'mobile';
/**
 * @public
 */
export declare namespace Platform {
    namespace Browser {
        function isIE(window: Window): boolean;
        function isEdge(window: Window): boolean;
        function isFireFox(window: Window): boolean;
        function isChrome(window: Window): boolean;
        function isOpera(window: Window): boolean;
        function isSafari(window: Window): boolean;
    }
    /**
     * @public
     */
    function isMobile(window: Window): boolean;
    /**
     * Whether the device runs an Apple operating system, where keyboard shortcuts use the Command key.
     *
     * @public
     */
    function isApple(window: Window): boolean;
    /**
     * @public
     */
    function isDesktop(window: Window): boolean;
    /**
     * @public
     */
    function isWebApp(): boolean;
}
declare global {
    interface Navigator {
        standalone: boolean;
    }
}
//# sourceMappingURL=Platform.d.ts.map