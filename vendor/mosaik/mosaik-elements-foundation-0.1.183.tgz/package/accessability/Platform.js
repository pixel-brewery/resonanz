// #region Imports
// #endregion
/**
 * @public
 */
export var Platform;
(function (Platform) {
    let Browser;
    (function (Browser) {
        function isIE(window) {
            return window.navigator.userAgent.indexOf('MSIE ') > 0 || window.navigator.userAgent.indexOf('Trident/') > 0;
        }
        Browser.isIE = isIE;
        function isEdge(window) {
            return window.navigator.userAgent.includes('Edge');
        }
        Browser.isEdge = isEdge;
        function isFireFox(window) {
            return window.navigator.userAgent.toLowerCase().includes('firefox');
        }
        Browser.isFireFox = isFireFox;
        function isChrome(window) {
            return 'chrome' in window;
        }
        Browser.isChrome = isChrome;
        function isOpera(window) {
            return ('opr' in window) || 'opera' in window || navigator.userAgent.includes(' OPR/');
        }
        Browser.isOpera = isOpera;
        function isSafari(window) {
            // @ts-ignore allow HTMLElement and Safari
            return (/constructor/i).test(window.HTMLElement) || ((p) => p.toString() === '[object SafariRemoteNotification]')(!window.safari || (typeof safari !== 'undefined' && safari.pushNotification));
        }
        Browser.isSafari = isSafari;
    })(Browser = Platform.Browser || (Platform.Browser = {}));
    /**
     * @public
     */
    function isMobile(window) {
        return (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i).test(window.navigator.userAgent);
    }
    Platform.isMobile = isMobile;
    /**
     * Whether the device runs an Apple operating system, where keyboard shortcuts use the Command key.
     *
     * @public
     */
    function isApple(window) {
        const navigator = window.navigator;
        return (/Mac|iPhone|iPad|iPod/i).test(navigator.userAgentData?.platform || navigator.platform || navigator.userAgent);
    }
    Platform.isApple = isApple;
    /**
     * @public
     */
    function isDesktop(window) {
        return window.navigator.userAgent.includes('Electron');
    }
    Platform.isDesktop = isDesktop;
    /**
     * @public
     */
    function isWebApp() {
        const isInWebAppiOS = window.navigator.standalone;
        const isInWebAppChrome = window.matchMedia('(display-mode: standalone)').matches;
        return isInWebAppiOS || isInWebAppChrome;
    }
    Platform.isWebApp = isWebApp;
})(Platform || (Platform = {}));
//# sourceMappingURL=Platform.js.map