# 📦 @pixel-brewery/mosaik-elements-foundation

| Package Status | Source |
|----------------|--------|
| [![GitHub Packages](https://img.shields.io/github/v/release/RueDeRennes/mosaik?label=GitHub%20Packages&logo=github)](https://github.com/orgs/pixel-brewery/packages/npm/package/mosaik-elements-foundation) | [libs/mosaik-elements-foundation](../../libs/mosaik-elements-foundation) |

> Core web components and styles for the Mosaik design system.
> Includes all foundational UI elements, tokens, and themes.

---

## 📁 Project Structure

Part of the monorepo [`mosaik`](https://github.com/RueDeRennes/mosaik)
Package path: `libs/mosaik-elements-foundation`
Version: see [GitHub Packages](https://github.com/orgs/pixel-brewery/packages/npm/package/mosaik-elements-foundation)
License: MIT

---

## 📦 Installation

```bash
yarn add @pixel-brewery/mosaik-elements-foundation
# or
npm install @pixel-brewery/mosaik-elements-foundation
```

---

## 🔧 Usage

```typescript
import * from '@pixel-brewery/mosaik-elements-foundation';
```

---

## Charts (separate entry)

```typescript
import { ChartElement, ChartToolboxElement, ChartDisplayType } from '@pixel-brewery/mosaik-elements-foundation/components/chart';
```

Install the optional `apexcharts` peer (`yarn add apexcharts`) when using charts.
The main entry excludes charts, the toolbox and ApexCharts. Move existing chart imports
from the main package to `components/chart`. The Foundation entry also exports chart
props, display/legend/stack options, interaction types, events and localization.

## Maps (separate entry)

Install the optional `maplibre-gl` peer when importing the Map family:

```sh
yarn add maplibre-gl@6.15.0
```

```typescript
import { MapElement } from '@pixel-brewery/mosaik-elements-foundation/components/map';

const map = document.createElement(MapElement.is) as MapElement;
map.latitude = 52.52;
map.longitude = 13.405;
map.zoom = 12;
map.label = 'Berlin delivery locations';
map.markers = [
    { id: 'alexanderplatz', latitude: 52.5218, longitude: 13.4132, label: 'Alexanderplatz' },
    { id: 'gate', latitude: 52.5163, longitude: 13.3777, label: 'Brandenburg Gate' }
];
map.routes = [{ id: 'delivery', coordinates: [[13.4132, 52.5218], [13.405, 52.52], [13.3777, 52.5163]] }];
map.style.height = '400px';
document.body.append(map);
```

Use the same `components/map` subpath in Angular, React, Vue and Svelte. Move existing main-entry
Map imports there, including apps that render map thumbnails. A Thumbnail does not register Maps
implicitly. Applications using only the general entries do not require MapLibre and do not emit
its renderer, worker or map styles. Importing the optional entry registers the component; mounting
a vector map loads its renderer. Server imports do not create maps or workers.

`mode = 'vector'` is the default. The default basemap uses OpenFreeMap's OSM-based OpenMapTiles
TileJSON with resolved Mosaik colors. Replace `vectorSource` with another compatible TileJSON URL,
or supply `mapStyle` as a MapLibre style URL/object for a different schema, glyph service or provider.
A custom style owns its basemap colors; Mosaik still themes the marker/cluster/route overlays and controls.
Keep the provider's source attribution in custom styles. Default source: [OpenFreeMap](https://openfreemap.org/quick_start/).

`markers` uses named WGS84 latitude/longitude values. Route `coordinates` follows GeoJSON order:
**longitude, latitude**. Routes display supplied geometry; the component does not calculate directions,
distance or ETA. `cluster` groups nearby markers; selecting a cluster zooms into it. `showControls`
controls the zoom/fit actions, and `fitBounds()` fits the supplied points and routes. `MapElementIntl`
owns the control and accessibility strings. `mapMarkerSelected` and `mapCameraChanged` report interactions.

For a provider's iframe instead, set `mode = 'embed'` and `provider` to `default`, `openstreetmap`,
`google`, `bing`, `here` or `apple`. Embeddability and usage conditions remain those of the provider.
Vector-only data and styles apply to vector mode.

Vite applications can let Vite bundle the worker directly, including during development:

```typescript
import { MapElement } from '@pixel-brewery/mosaik-elements-foundation/components/map';
import workerUrl from 'maplibre-gl/dist/maplibre-gl-worker.mjs?worker&url';

MapElement.configureWorker(workerUrl);
```

This configures the worker URL for subsequently mounted maps without creating a renderer or changing
serialized map properties. An instance's `workerUrl` overrides it; `configureWorker(null)` restores
the bundled default. Configure it once before mounting maps and use the exact optional peer version
so the renderer and worker protocols match.

The package ships a self-contained MapLibre module worker beside its optional runtime. Vite and
Webpack recognize its `new URL(..., import.meta.url)` asset reference. Bundlers that do not copy URL
assets must copy `dist/controls/components/media/map/MapLibreWorker.js` from the Foundation package
to their public assets and set each map's `workerUrl` to that same-origin URL. Keep it in sync with
the installed MapLibre version. No CDN worker or remote JavaScript loader is required. The component
provides scoped canvas and attribution styles inside its shadow root; no global MapLibre stylesheet
is needed for its built-in controls. See [MapLibre installation and CSP guidance](https://maplibre.org/maplibre-gl-js/docs/).

## Signature Pad (separate entry)

Import the signature pad explicitly when collecting handwritten signatures:

```typescript
import { SignaturePadElement } from '@pixel-brewery/mosaik-elements-foundation/components/signature-pad';
```

Install the optional `signature_pad` peer (`yarn add signature_pad`) when using this component.
The main package entry excludes the signature pad and its signing library. Existing imports of this
component from the main entry must move to `components/signature-pad`. The Foundation entry also
exports its value accessor, props and signing event types.

## Code editor (separate entry)

`mosaik-code-editor` - a CodeMirror 6 editor with lazy language grammars, search and replace, completions,
diagnostics, formatting (Prettier, on demand), copy, preview, toolbar and status bar, themed by the Mosaik tokens -
is **not** part of the main entry, so an application that never imports it never bundles CodeMirror:

```typescript
import '@pixel-brewery/mosaik-elements-foundation/components/code-editor';
import { createPrettierFormatter, CodeEditorLanguages } from '@pixel-brewery/mosaik-elements-foundation/components/code-editor';
```

```html
<mosaik-code-editor language="typescript" toolbar status-bar max-lines="24"></mosaik-code-editor>
```

The CodeMirror packages (`@codemirror/*`, `@lezer/highlight`, `@replit/codemirror-lang-svelte`) and `prettier`
are optional peer dependencies: install them when you use the editor. Every grammar and Prettier load on demand.

## RxJS integration (separate entry)

The `async` and `observe` directives and the `AsyncController` bind RxJS observables to a template or a host. They are
not part of the main entry; import them from their modules:

```typescript
import { async } from '@pixel-brewery/mosaik-elements-foundation/dist/reactivity/rx/directives/AsyncDirective';
import { observe } from '@pixel-brewery/mosaik-elements-foundation/dist/reactivity/rx/directives/ObserveDirective';
import { addAsyncController } from '@pixel-brewery/mosaik-elements-foundation/dist/reactivity/rx/controllers/AsyncController';
```

Install the optional `rxjs` peer (`yarn add rxjs`, version 7 or later) when you use them.

## Popup focus restoration

`PopupElement.restoreFocus` defaults to `true`. Closing a popup restores focus to
its previously focused element only while that element remains connected.
Set `restoreFocus` to `false` when choosing a popup item transfers focus to
another surface, such as a detail dialog. This prevents the popup from stealing
focus back and reopening a focus-triggered launcher. The boolean HTML attribute
is `restore-focus`; framework wrappers expose the `restoreFocus` property.
The policy applies equally to `close()` and direct changes to `isOpen`.

## Selected option labels

Changing the `label` of the selected `mosaik-select-item` refreshes the closed
Select input immediately. The stable value and selected item remain unchanged,
and renaming an option does not emit a new selection event.

## Form capability metadata

Each form control declares its own readonly `controlValue` capability and creates its
existing value accessor from that declaration. The optional literal `property` names a
writable native model property; composite controls omit it and expose only the accessor.
Framework generators inspect this declaration from the component's TypeScript types.
Adding a control therefore requires no shared tag or property registry.

Framework state stores, model bindings, renderer lifecycles and definition helpers belong
to the CDK of the Angular, React, Vue or Svelte package that consumes them.

## Input masks

`TextBoxElement` uses a `parser` for its raw string `value` and a `formatter` for its
displayed text. Both `InputParsers` and `InputFormatters` expose these matching factories:

| Preset | Model value | Display value | Display `maxlength` |
| --- | --- | --- | --- |
| `cardNumber()` | `0000123456789012` | `0000 1234 5678 9012` | `19` |
| `cardExpiry()` | `0128` | `01/28` | `5` |
| `macAddress()` | `001B44113AB7` | `00:1B:44:11:3A:B7` | `17` |

The parsers strip separators and unsupported characters, preserving leading zeroes and
partial input. They cap card numbers at 16 digits, expiry values at 4 digits and MAC
addresses at 12 hexadecimal digits, matching these examples. MAC values become uppercase.
The display `maxlength` includes the spaces, slash or colons; parser limits apply separately.
These are formatting helpers: they do not validate card checksums, month ranges, expiration
dates or MAC-address completeness.

```typescript
import {
    InputFormatters,
    InputParsers,
    TextBoxElement,
    TextKeyboardMode
} from '@pixel-brewery/mosaik-elements-foundation';

const cardNumber = document.createElement(TextBoxElement.is) as TextBoxElement;
cardNumber.label = 'Card number';
cardNumber.placeholder = '0000 0000 0000 0000';
cardNumber.keyboard = TextKeyboardMode.Numeric;
cardNumber.maxlength = 19;
cardNumber.parser = InputParsers.cardNumber();
cardNumber.formatter = InputFormatters.cardNumber();
cardNumber.value = '0000123456789012';
document.body.append(cardNumber);

// The same functions also work without a component.
const expiryModel = InputParsers.cardExpiry()('01/28') ?? ''; // '0128'
const expiryDisplay = InputFormatters.cardExpiry()(expiryModel); // '01/28'
const macModel = InputParsers.macAddress()('00:1b:44:11:3a:b7') ?? ''; // '001B44113AB7'
const macDisplay = InputFormatters.macAddress()(macModel); // '00:1B:44:11:3A:B7'
```

Assigning an external `value` leaves that model untouched; the formatter normalizes only
its display until the input is parsed. Normalize external data explicitly before assignment
when the stored model must be canonical, for example
`cardNumber.value = InputParsers.cardNumber()(externalValue) ?? '';`.

The Angular, React, Vue and Svelte TextBox wrappers accept the same `parser`, `formatter`
and `keyboard` bindings. Import these utilities from the Foundation package when using a wrapper.

## ⚙️ Features

- Lit-based web components
- Design tokens and themes
- SCSS and CSS utilities
- Foundation for Angular, React, Vue, and Svelte wrappers

### Possible themes

- Memphis (Mosaik)
- Joy (Mosaik Current)
- Material (Google)
- Bootstrap (Twitter)
- Fluent (Microsoft)
- Neumorphism (?)
- Cupertino (Apple)

---

## 🛠 Recommendations

- Use as the base for all Mosaik component wrappers.
- Integrate with your design system for consistent theming.

---

## 📦 Publishing

```bash
yarn nx run mosaik-elements-foundation:publish
```

---

## 📄 License

MIT © Pixel Brewery

---

## Rich text box

The existing `mosaik-richtextbox` uses Tiptap directly. Its toolbox and original
`command('bold' | 'italic' | 'strikethrough' | 'monospace')` API operate on the same
selection and undo history. Underline, undo and redo are included. `value` remains
HTML; `mentionDocument` is a separate plain-text projection with stable reference
IDs and UTF-16 ranges.

Import the whole component explicitly. The Foundation root and all four framework
roots leave it out, so ordinary text boxes and prompt boxes never load Tiptap.

```ts
import { RichTextBoxElement } from '@pixel-brewery/mosaik-elements-foundation/components/rich-textbox';
import { richTextMentions } from '@pixel-brewery/mosaik-elements-foundation/components/rich-textbox/extensions/mentions';
import { richTextEmoji } from '@pixel-brewery/mosaik-elements-foundation/components/rich-textbox/extensions/emoji';
import { richTextPlaceholder } from '@pixel-brewery/mosaik-elements-foundation/components/rich-textbox/extensions/placeholder';

const box = document.createElement(RichTextBoxElement.is) as RichTextBoxElement;
box.extensions = [richTextMentions(), richTextEmoji(), richTextPlaceholder()];
box.suggestions = providers;
document.body.append(box);
```

Additional Mosaik extension factories are `richTextLists`, `richTextHeadings` and
`richTextLinks`, each under its own `/extensions/lists`, `/extensions/headings` or
`/extensions/links` subpath. Consumers use `IRichTextExtension` and Mosaik APIs;
Tiptap objects and configuration are internal. Reuse an extension definition across
boxes: every box creates its own editor and plugin session. Changing providers
preserves undo history; changing `extensions` deliberately rebuilds the schema.

The required optional peers for the basic editor are `@tiptap/core`, `@tiptap/pm`,
`@tiptap/extensions`, and `@tiptap/extension-{document,paragraph,text,hard-break,bold,italic,strike,code,underline}`.
Install version `3.31.3`. Each extra feature needs its corresponding peer:
`@tiptap/extension-list`, `@tiptap/extension-heading`, `@tiptap/extension-link`,
`@tiptap/extension-emoji`, `@tiptap/extension-placeholder`, or
`@tiptap/extension-mention` plus `@tiptap/suggestion`.

```html
<mosaik-richtextbox label="Release notes" show-toolbox></mosaik-richtextbox>
<mosaik-prompt-box>
    <mosaik-richtextbox slot="editor"></mosaik-richtextbox>
</mosaik-prompt-box>
```

A separate `mosaik-richtextbox-toolbox` can be placed anywhere and connected through
its `editor` property, like Chart Toolbox. It exposes visibility overrides through
`tools`, reads selection capabilities and disables unavailable actions. Use
`command('link', url)` or its URL controls to set a link. The four framework packages
export RichTextBox and RichTextBoxToolbox only from `components/rich-textbox`.
