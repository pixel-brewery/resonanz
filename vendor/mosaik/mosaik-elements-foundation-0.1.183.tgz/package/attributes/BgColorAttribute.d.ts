import { CustomAttr } from './abstracts/CustomAttr';
export declare class BgColorAttr extends CustomAttr {
    connectedCallback(): void;
    changedCallback(pref: string, next: string): void;
}
//# sourceMappingURL=BgColorAttribute.d.ts.map