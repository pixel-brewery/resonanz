// #region Imports
// #endregion
/**
 * The `CustomAttr` class.
 * The base class for all custom attributes.
 *
 * @public
 */
export class CustomAttr {
    // #region Fields
    _ownerElement;
    _name;
    _value;
    // #endregion
    // #region Ctor
    constructor(ownerElement) {
        this._ownerElement = ownerElement;
        this._name = '';
        this._value = '';
    }
    // #endregion
    // #region Properties
    /**
     * Gets or sets the `name` property.
     *
     * @public
     */
    get name() {
        return this._name;
    }
    set name(value) {
        this._name = value;
    }
    /**
     * Gets or sets the `value` property.
     *
     * @public
     */
    get value() {
        return this._value;
    }
    set value(value) {
        this._value = value;
    }
    /**
     * Returns the `ownerElement` property.
     *
     * @public
     * @readonly
     */
    get ownerElement() {
        if (this._ownerElement === undefined) {
            throw new Error('The owner element is not defined.');
        }
        return this._ownerElement;
    }
}
//# sourceMappingURL=CustomAttr.js.map