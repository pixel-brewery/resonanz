import type { ICustomAttribute } from '../interfaces/ICustomAttribute';
/**
 * The `CustomAttr` class.
 * The base class for all custom attributes.
 *
 * @public
 */
export declare abstract class CustomAttr<TElement extends HTMLElement = HTMLElement> implements ICustomAttribute {
    private readonly _ownerElement?;
    private _name;
    private _value;
    protected constructor(ownerElement: TElement);
    /**
     * Gets or sets the `name` property.
     *
     * @public
     */
    get name(): string;
    set name(value: string);
    /**
     * Gets or sets the `value` property.
     *
     * @public
     */
    get value(): string;
    set value(value: string);
    /**
     * Returns the `ownerElement` property.
     *
     * @public
     * @readonly
     */
    get ownerElement(): TElement;
}
//# sourceMappingURL=CustomAttr.d.ts.map