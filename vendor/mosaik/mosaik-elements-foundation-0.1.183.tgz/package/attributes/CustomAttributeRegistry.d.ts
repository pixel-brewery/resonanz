import type { Constructor } from '../types/Constructor';
import type { ICustomAttribute } from './interfaces/ICustomAttribute';
export declare class CustomAttributeRegistry {
    private readonly _attrMap;
    private readonly _elementMap;
    private readonly _observer;
    constructor(ownerDocument: Document | ShadowRoot);
    ownerDocument: Document | ShadowRoot;
    define(attrName: string, ctor: Constructor): void;
    has(attrName: string): boolean;
    get(element: Element, attrName: string): ICustomAttribute | undefined;
    private tryGetConstructor;
    private observe;
    private unobserve;
    private reobserve;
    private upgradeAttr;
    private elementConnected;
    private elementDisconnected;
    private handleChange;
}
//# sourceMappingURL=CustomAttributeRegistry.d.ts.map