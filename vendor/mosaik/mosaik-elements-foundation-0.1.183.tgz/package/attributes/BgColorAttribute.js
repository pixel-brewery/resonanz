var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CustomAttr } from './abstracts/CustomAttr';
import { Attr } from './decorators/AttrDecorator';
let BgColorAttr = class BgColorAttr extends CustomAttr {
    // #region Methods
    connectedCallback() {
        // eslint-disable-next-line no-restricted-syntax
        this.ownerElement.style.backgroundColor = this.value;
    }
    changedCallback(pref, next) {
        // eslint-disable-next-line no-restricted-syntax
        this.ownerElement.style.backgroundColor = next;
    }
};
BgColorAttr = __decorate([
    Attr({ selector: 'bg-color' })
], BgColorAttr);
export { BgColorAttr };
//# sourceMappingURL=BgColorAttribute.js.map