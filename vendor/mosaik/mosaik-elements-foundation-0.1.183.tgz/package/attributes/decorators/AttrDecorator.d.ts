import '../CustomAttributes';
/**
 * Represents the `IComponentOptions` interface.
 *
 * @public
 */
export interface IAttrOptions {
    /**
     * The name of the custom element.
     */
    selector: string;
}
export declare function Attr(options: IAttrOptions): Function;
//# sourceMappingURL=AttrDecorator.d.ts.map