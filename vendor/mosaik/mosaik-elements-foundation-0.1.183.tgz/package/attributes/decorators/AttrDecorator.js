import '../CustomAttributes';
/**
 * @private
 */
function legacyCustomAttribute(ctor, options) {
    if (!customAttributes.has(options.selector)) {
        customAttributes.define(options.selector, ctor);
    }
    else {
        console.warn(`[Attr]: The attribute '${options.selector}' is already defined.`);
    }
    return ctor;
}
/**
 * @private
 */
function standardCustomAttribute(descriptor, options) {
    return {
        kind: descriptor.kind,
        elements: descriptor.elements,
        finisher: (ctor) => {
            if (!customAttributes.has(options.selector)) {
                customAttributes.define(options.selector, ctor);
            }
            else {
                console.warn(`[Attr]: The attribute '${options.selector}' is already defined.`);
            }
        }
    };
}
export function Attr(options) {
    return (classOrDescriptor) => typeof classOrDescriptor === 'function'
        ? legacyCustomAttribute(classOrDescriptor, options)
        : standardCustomAttribute(classOrDescriptor, options);
}
//# sourceMappingURL=AttrDecorator.js.map