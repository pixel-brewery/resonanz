import { CustomAttributeRegistry } from './CustomAttributeRegistry';
export * from './CustomAttributeRegistry';
export declare let customAttributes: CustomAttributeRegistry;
declare global {
    var customAttributes: CustomAttributeRegistry;
    interface ShadowRoot {
        customAttributes: CustomAttributeRegistry;
    }
    interface Window {
        customAttributes: CustomAttributeRegistry;
    }
}
//# sourceMappingURL=CustomAttributes.d.ts.map