import { CustomAttributeRegistry } from './CustomAttributeRegistry';
export * from './CustomAttributeRegistry';
// eslint-disable-next-line @typescript-eslint/init-declarations
export let customAttributes;
// Avoid errors trying to use DOM APIs in non-DOM environments (f.e. server-side rendering).
// eslint-disable-next-line @typescript-eslint/no-unnecessary-condition
if (globalThis.window.document) {
    customAttributes = globalThis.customAttributes = new CustomAttributeRegistry(document);
}
//# sourceMappingURL=CustomAttributes.js.map