export {};
//# sourceMappingURL=ICustomAttribute.js.map