import type { Constructor } from '../../types/Constructor';
import type { ICustomAttribute } from './ICustomAttribute';
export interface ICustomAttributeConstructor extends Constructor {
    new (ownerElement: Element): ICustomAttribute;
}
//# sourceMappingURL=ICustomAttributeConstructor.d.ts.map