// #region Imports
export {};
//# sourceMappingURL=ICustomAttributeConstructor.js.map