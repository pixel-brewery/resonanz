export interface ICustomAttribute {
    name: string;
    value: string;
    readonly ownerElement: HTMLElement;
    connectedCallback?(): void;
    disconnectedCallback?(): void;
    changedCallback?(prev: string, next: string): void;
}
//# sourceMappingURL=ICustomAttribute.d.ts.map