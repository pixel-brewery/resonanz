import type { IRAFInit } from './interfaces/IRAFInit';
/**
 * @public
 */
export declare class RAF {
    private static _request;
    private static _cancel;
    private static _lastTime;
    static init(window: Window): IRAFInit;
}
//# sourceMappingURL=RAF.d.ts.map