/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/unbound-method */
/* eslint-disable @typescript-eslint/no-unnecessary-condition */
// #endregion
/**
 * @public
 */
export class RAF {
    // #region Properties
    static _request;
    static _cancel;
    static _lastTime;
    // #endregion
    // #region Methods
    static init(window) {
        RAF._request = window.requestAnimationFrame;
        RAF._cancel = window.cancelAnimationFrame;
        RAF._lastTime = 0;
        if (!RAF._request) {
            RAF._request = (callback) => {
                const currTime = Date.now();
                const timeToCall = Math.max(0, 16 - (currTime - RAF._lastTime));
                const token = setTimeout(() => {
                    callback(currTime + timeToCall);
                }, timeToCall);
                RAF._lastTime = currTime + timeToCall;
                return token;
            };
            RAF._cancel = clearTimeout;
        }
        return {
            request: RAF._request,
            cancel: RAF._cancel
        };
    }
}
//# sourceMappingURL=RAF.js.map