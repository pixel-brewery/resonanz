export {};
//# sourceMappingURL=IRAFInit.js.map