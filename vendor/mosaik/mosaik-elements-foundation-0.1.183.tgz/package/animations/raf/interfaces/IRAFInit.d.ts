/**
 * @public
 */
export interface IRAFInit {
    request: (callback: FrameRequestCallback) => number;
    cancel: (handle: number) => void;
}
//# sourceMappingURL=IRAFInit.d.ts.map