/**
 * Represents the metadata for an animation reference.
 *
 * @public
 */
export interface IAnimationReferenceMetadata {
    /**
     * Optional initial styles to apply to the element before the animation starts.
     * This ensures the element is in the correct state before the animation begins,
     * preventing visual flicker (e.g., setting opacity: 0 before a fade-in animation).
     */
    initial?: Keyframe;
    /**
     * The keyframes that define the animation.
     */
    steps: Array<Keyframe>;
    /**
     * Optional animation options (duration, easing, fill, etc.).
     */
    options?: KeyframeAnimationOptions;
}
//# sourceMappingURL=IAnimationReferenceMetadata.d.ts.map