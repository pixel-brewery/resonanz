// #region Imports
import { animation } from '../animation';
// #endregion
export const flash = animation([
    { opacity: 0 },
    {
        opacity: 1,
        offset: 0.03
    },
    {
        opacity: 0.75,
        offset: 0.6
    },
    { opacity: 0 }
], {
    duration: 600,
    easing: 'ease-in',
    iterations: 1
});
//# sourceMappingURL=Flash.js.map