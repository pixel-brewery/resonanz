// #region Imports
// #endregion
/**
 * A continuous rotation animation.
 *
 * @public
 */
export const rotate = {
    steps: [
        { transform: 'rotate(0deg)' },
        { transform: 'rotate(360deg)' }
    ],
    options: {
        duration: 1000,
        easing: 'linear',
        iterations: Infinity
    }
};
//# sourceMappingURL=Rotate.js.map