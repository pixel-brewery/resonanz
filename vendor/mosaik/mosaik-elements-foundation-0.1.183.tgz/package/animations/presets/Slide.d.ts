declare const slideInFromTop: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
declare const slideOutToTop: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
declare const slideInFromBottom: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
declare const slideOutToBottom: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
declare const slideInFromLeft: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
declare const slideOutToLeft: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
declare const slideInFromRight: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
declare const slideOutToRight: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
export { slideInFromBottom, slideInFromLeft, slideInFromRight, slideInFromTop, slideOutToBottom, slideOutToLeft, slideOutToRight, slideOutToTop };
//# sourceMappingURL=Slide.d.ts.map