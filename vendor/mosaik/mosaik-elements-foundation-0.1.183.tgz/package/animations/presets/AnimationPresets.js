// #region Imports
import { elasticBreathe, elasticDigitDown, elasticDigitUp, elasticEnter, elasticExit, elasticFocusGrow, elasticFocusShrink, elasticInkSettle, elasticPress, elasticPressVertical, elasticShimmer, elasticSweep, elasticTileContract, elasticTileExpand, elasticToggle } from './ElasticSnap';
import { fadeIn, fadeOut, fadeSlideIn, fadeSlideInBottom, fadeSlideInLeft, fadeSlideInRight, fadeSlideInTop, fadeSlideOut, fadeSlideOutBottom, fadeSlideOutLeft, fadeSlideOutRight, fadeSlideOutTop } from './Fade';
import { flash, } from './Flash';
import { growHorIn, growHorOut, growVerIn, growVerOut, } from './Grow';
import { rotate, } from './Rotate';
import { shakeHorizontal, shakeVertical, } from './Shake';
import { slideInFromBottom, slideInFromLeft, slideInFromRight, slideInFromTop, slideOutToBottom, slideOutToLeft, slideOutToRight, slideOutToTop, } from './Slide';
// #endregion
/**
 * Collection of pre-defined animation presets.
 *
 * @public
 */
export const AnimationPreset = {
    // Fade animations
    fadeIn: fadeIn,
    fadeOut: fadeOut,
    fadeSlideIn: fadeSlideIn,
    fadeSlideInBottom: fadeSlideInBottom,
    fadeSlideInLeft: fadeSlideInLeft,
    fadeSlideInRight: fadeSlideInRight,
    fadeSlideInTop: fadeSlideInTop,
    fadeSlideOut: fadeSlideOut,
    fadeSlideOutBottom: fadeSlideOutBottom,
    fadeSlideOutLeft: fadeSlideOutLeft,
    fadeSlideOutRight: fadeSlideOutRight,
    fadeSlideOutTop: fadeSlideOutTop,
    // Flash animation
    flash: flash,
    // Grow animations
    growHorIn: growHorIn,
    growHorOut: growHorOut,
    growVerIn: growVerIn,
    growVerOut: growVerOut,
    // Rotate animation
    rotate: rotate,
    // Shake animations
    shakeHorizontal: shakeHorizontal,
    shakeVertical: shakeVertical,
    // Slide animations
    slideInBottom: slideInFromBottom,
    slideOutBottom: slideOutToBottom,
    slideInTop: slideInFromTop,
    slideOutTop: slideOutToTop,
    slideInLeft: slideInFromLeft,
    slideOutLeft: slideOutToLeft,
    slideInRight: slideInFromRight,
    slideOutRight: slideOutToRight,
    // Elastic Snap animations (Joy theme)
    elasticEnter: elasticEnter,
    elasticExit: elasticExit,
    elasticToggle: elasticToggle,
    elasticPress: elasticPress,
    elasticPressVertical: elasticPressVertical,
    elasticDigitUp: elasticDigitUp,
    elasticDigitDown: elasticDigitDown,
    elasticSweep: elasticSweep,
    elasticShimmer: elasticShimmer,
    elasticBreathe: elasticBreathe,
    elasticTileExpand: elasticTileExpand,
    elasticTileContract: elasticTileContract,
    elasticFocusGrow: elasticFocusGrow,
    elasticFocusShrink: elasticFocusShrink,
    elasticInkSettle: elasticInkSettle
};
/**
 * Alias for `AnimationPreset` for backward compatibility.
 *
 * @public
 */
export const Animation = AnimationPreset;
//# sourceMappingURL=AnimationPresets.js.map