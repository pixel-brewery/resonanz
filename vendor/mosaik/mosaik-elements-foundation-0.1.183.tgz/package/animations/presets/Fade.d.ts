/**
 * A fade in animation.
 */
declare const fadeIn: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
/**
 * A fade out animation.
 */
declare const fadeOut: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
/**
 * A fade and slide in animation from bottom to top.
 */
declare const fadeSlideInTop: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
/**
 * A fade and slide in animation from top to bottom.
 */
declare const fadeSlideInBottom: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
/**
 * A fade and slide out animation from bottom to top.
 */
declare const fadeSlideInLeft: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
/**
 * A fade and slide out animation from top to bottom.
 */
declare const fadeSlideInRight: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
/**
 * A fade and slide out animation from top to bottom.
 */
declare const fadeSlideOutTop: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
/**
 * A fade and slide out animation from top to bottom.
 */
declare const fadeSlideOutBottom: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
/**
 * A fade and slide out animation from top to bottom.
 */
declare const fadeSlideOutLeft: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
/**
 * A fade and slide out animation from top to bottom.
 */
declare const fadeSlideOutRight: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
export { fadeIn, fadeOut, fadeSlideInTop as fadeSlideIn, fadeSlideInBottom, fadeSlideInLeft, fadeSlideInRight, fadeSlideInTop, fadeSlideOutTop as fadeSlideOut, fadeSlideOutBottom, fadeSlideOutLeft, fadeSlideOutRight, fadeSlideOutTop };
//# sourceMappingURL=Fade.d.ts.map