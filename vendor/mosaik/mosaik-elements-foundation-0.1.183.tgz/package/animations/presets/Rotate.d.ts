import type { IAnimationReferenceMetadata } from '../IAnimationReferenceMetadata';
/**
 * A continuous rotation animation.
 *
 * @public
 */
export declare const rotate: IAnimationReferenceMetadata;
//# sourceMappingURL=Rotate.d.ts.map