declare const shakeHorizontal: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
declare const shakeVertical: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
export { shakeHorizontal, shakeVertical };
//# sourceMappingURL=Shake.d.ts.map