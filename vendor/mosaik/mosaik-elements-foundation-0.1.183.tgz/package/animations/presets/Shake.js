// #region Imports
import { EaseInOut } from '../AnimationEasings';
import { animation } from '../animation';
// #endregion
const shakeHorizontal = animation([
    {
        offset: 0,
        transform: 'rotate(0deg) translateX(0)',
        transformOrigin: 'center center'
    },
    {
        offset: 0.1,
        transform: 'rotate(0deg) translateX(-10px)'
    },
    {
        offset: 0.2,
        transform: 'rotate(-0deg) translateX(10px)'
    },
    {
        offset: 0.3,
        transform: 'rotate(0deg) translateX(-10px)'
    },
    {
        offset: 0.4,
        transform: 'rotate(-0deg) translateX(10px)'
    },
    {
        offset: 0.5,
        transform: 'rotate(0deg) translateX(-10px)'
    },
    {
        offset: 0.6,
        transform: 'rotate(-0deg) translateX(10px)'
    },
    {
        offset: 0.7,
        transform: 'rotate(0deg) translateX(-10px)'
    },
    {
        offset: 0.8,
        transform: 'rotate(-0deg) translateX(8px)'
    },
    {
        offset: 0.9,
        transform: 'rotate(0deg) translateX(-8px)'
    },
    {
        offset: 1,
        transform: 'rotate(0deg) translateX(0)',
        transformOrigin: 'center center'
    }
], {
    delay: 0,
    duration: 800,
    easing: EaseInOut.Quad
});
const shakeVertical = animation([
    {
        offset: 0,
        transform: 'rotate(0deg) translateY(0)',
        transformOrigin: 'center center'
    },
    {
        offset: 0.1,
        transform: 'rotate(0deg) translateY(-10px)'
    },
    {
        offset: 0.2,
        transform: 'rotate(-0deg) translateY(10px)'
    },
    {
        offset: 0.3,
        transform: 'rotate(0deg) translateY(-10px)'
    },
    {
        offset: 0.4,
        transform: 'rotate(-0deg) translateY(10px)'
    },
    {
        offset: 0.5,
        transform: 'rotate(0deg) translateY(-10px)'
    },
    {
        offset: 0.6,
        transform: 'rotate(-0deg) translateY(10px)'
    },
    {
        offset: 0.7,
        transform: 'rotate(0deg) translateY(-10px)'
    },
    {
        offset: 0.8,
        transform: 'rotate(-0deg) translateY(8px)'
    },
    {
        offset: 0.9,
        transform: 'rotate(0deg) translateY(-8px)'
    },
    {
        offset: 1,
        transform: 'rotate(0deg) translateY(0)',
        transformOrigin: 'center center'
    }
], {
    delay: 0,
    duration: 800,
    easing: EaseInOut.Quad
});
export { shakeHorizontal, shakeVertical };
//# sourceMappingURL=Shake.js.map