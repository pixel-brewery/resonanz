declare const growVerIn: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
declare const growVerOut: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
declare const growHorIn: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
declare const growHorOut: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
export { growHorIn, growHorOut, growVerIn, growVerOut };
//# sourceMappingURL=Grow.d.ts.map