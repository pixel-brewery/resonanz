/**
 * Elastic enter - element scales in with slow tension build then fast
 * snap to rest. One slight overshoot, then settle.
 */
declare const elasticEnter: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
/**
 * Elastic exit - slow scale-up tension then fast snap to invisible.
 */
declare const elasticExit: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
/**
 * Elastic toggle - starts at peak deformation, fast snap to rest,
 * one tiny overshoot. Mirrors: `elastic-switch-snap` (CheckmarkElement).
 */
declare const elasticToggle: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
/**
 * Elastic press - slow stretch then fast snap back.
 */
declare const elasticPress: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
/**
 * Elastic press vertical - slow vertical stretch then fast snap back.
 */
declare const elasticPressVertical: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
/**
 * Elastic digit up - slow stretch tall (tension), fast snap back.
 * Mirrors: `elastic-digit-up` (NumberCounterElement).
 */
declare const elasticDigitUp: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
/**
 * Elastic digit down - slow stretch wide (tension), fast snap back.
 * Mirrors: `elastic-digit-down` (NumberCounterElement).
 */
declare const elasticDigitDown: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
/**
 * Elastic sweep - fill stretches wide as it enters (slow tension),
 * snaps narrow as it exits (fast snap), then dead time.
 * Mirrors: `elastic-indeterminate` (ProgressBarElement).
 */
declare const elasticSweep: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
/**
 * Elastic shimmer - slow stretch across, fast narrow exit.
 * Mirrors: `elastic-shimmer` (SkeletonElement).
 */
declare const elasticShimmer: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
/**
 * Elastic breathe - gentle scale cycle: slow grow (tension),
 * fast shrink (snap), settle. For typing indicators, idle states.
 */
declare const elasticBreathe: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
/**
 * Elastic tile expand - slow scale-up with tension, fast settle.
 * Mirrors: tile maximize animation.
 */
declare const elasticTileExpand: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
/**
 * Elastic tile contract - slow tension pull then fast snap down.
 */
declare const elasticTileContract: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
/**
 * Elastic focus grow - slow outline build with overshoot, fast snap
 * to final width. Mirrors: `elastic-outward-grow` (FocusRingElement).
 */
declare const elasticFocusGrow: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
/**
 * Elastic focus shrink - tiny tension bump then fast retract.
 * Mirrors: `elastic-outward-shrink` (FocusRingElement).
 */
declare const elasticFocusShrink: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
/**
 * Elastic ink settle - slow release from deformed state, fast snap
 * to rest. Mirrors: `elastic-ink-settle-a` (InkBarElement).
 */
declare const elasticInkSettle: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
export { elasticBreathe, elasticDigitDown, elasticDigitUp, elasticEnter, elasticExit, elasticFocusGrow, elasticFocusShrink, elasticInkSettle, elasticPress, elasticPressVertical, elasticShimmer, elasticSweep, elasticTileContract, elasticTileExpand, elasticToggle };
//# sourceMappingURL=ElasticSnap.d.ts.map