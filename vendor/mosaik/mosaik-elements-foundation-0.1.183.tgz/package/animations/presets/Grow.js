// #region Imports
import { EaseOut } from '../AnimationEasings';
import { animation } from '../animation';
// #endregion
const growVerIn = animation([
    {
        opacity: 0,
        height: 0
    },
    {
        opacity: 1,
        height: 'auto'
    }
], {
    duration: 200,
    easing: EaseOut.Quad
});
const growVerOut = animation([
    {
        opacity: 1,
        height: 'auto'
    },
    {
        opacity: 0,
        height: 0
    }
], {
    duration: 200,
    easing: EaseOut.Quad
});
const growHorIn = animation([
    {
        opacity: 0,
        width: 0
    },
    {
        opacity: 1,
        width: 'auto'
    }
], {
    duration: 200,
    easing: EaseOut.Quad
});
const growHorOut = animation([
    {
        opacity: 1,
        width: 'auto'
    },
    {
        opacity: 0,
        width: 0
    }
], {
    duration: 200,
    easing: EaseOut.Quad
});
export { growHorIn, growHorOut, growVerIn, growVerOut };
//# sourceMappingURL=Grow.js.map