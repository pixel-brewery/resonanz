export declare const flash: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
//# sourceMappingURL=Flash.d.ts.map