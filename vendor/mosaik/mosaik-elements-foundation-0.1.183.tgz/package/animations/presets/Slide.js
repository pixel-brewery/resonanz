// #region Imports
import { EaseInOut } from '../AnimationEasings';
import { animation } from '../animation';
// #endregion
const slideInFromTop = animation([
    {
        transform: 'translateY(-100%)'
    },
    {
        transform: 'translateY(0)'
    }
], {
    duration: 200,
    easing: EaseInOut.Cubic,
    fill: 'forwards'
});
const slideOutToTop = animation([
    {
        transform: 'translateY(0)'
    },
    {
        transform: 'translateY(-100%)'
    }
], {
    duration: 200,
    easing: EaseInOut.Cubic,
    fill: 'forwards'
});
const slideInFromBottom = animation([
    {
        transform: 'translateY(100%)'
    },
    {
        transform: 'translateY(0)'
    }
], {
    duration: 200,
    easing: EaseInOut.Cubic,
    fill: 'forwards'
});
const slideOutToBottom = animation([
    {
        transform: 'translateY(0)'
    },
    {
        transform: 'translateY(100%)'
    }
], {
    duration: 200,
    easing: EaseInOut.Cubic,
    fill: 'forwards'
});
const slideInFromLeft = animation([
    {
        transform: 'translateX(-100%)'
    },
    {
        transform: 'translateX(0)'
    }
], {
    duration: 200,
    easing: EaseInOut.Cubic,
    fill: 'forwards'
});
const slideOutToLeft = animation([
    {
        transform: 'translateX(0)'
    },
    {
        transform: 'translateX(-100%)'
    }
], {
    duration: 200,
    easing: EaseInOut.Cubic,
    fill: 'forwards'
});
const slideInFromRight = animation([
    {
        transform: 'translateX(100%)'
    },
    {
        transform: 'translateX(0)'
    }
], {
    duration: 200,
    easing: EaseInOut.Cubic,
    fill: 'forwards'
});
const slideOutToRight = animation([
    {
        transform: 'translateX(0)'
    },
    {
        transform: 'translateX(100%)'
    }
], {
    duration: 200,
    easing: EaseInOut.Cubic,
    fill: 'forwards'
});
export { slideInFromBottom, slideInFromLeft, slideInFromRight, slideInFromTop, slideOutToBottom, slideOutToLeft, slideOutToRight, slideOutToTop };
//# sourceMappingURL=Slide.js.map