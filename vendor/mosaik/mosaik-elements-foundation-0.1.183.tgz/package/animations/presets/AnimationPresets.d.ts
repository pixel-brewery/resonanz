/**
 * Collection of pre-defined animation presets.
 *
 * @public
 */
export declare const AnimationPreset: {
    readonly fadeIn: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly fadeOut: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly fadeSlideIn: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly fadeSlideInBottom: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly fadeSlideInLeft: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly fadeSlideInRight: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly fadeSlideInTop: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly fadeSlideOut: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly fadeSlideOutBottom: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly fadeSlideOutLeft: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly fadeSlideOutRight: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly fadeSlideOutTop: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly flash: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly growHorIn: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly growHorOut: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly growVerIn: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly growVerOut: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly rotate: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly shakeHorizontal: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly shakeVertical: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly slideInBottom: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly slideOutBottom: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly slideInTop: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly slideOutTop: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly slideInLeft: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly slideOutLeft: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly slideInRight: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly slideOutRight: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly elasticEnter: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly elasticExit: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly elasticToggle: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly elasticPress: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly elasticPressVertical: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly elasticDigitUp: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly elasticDigitDown: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly elasticSweep: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly elasticShimmer: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly elasticBreathe: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly elasticTileExpand: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly elasticTileContract: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly elasticFocusGrow: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly elasticFocusShrink: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly elasticInkSettle: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
};
/**
 * @public
 */
export type AnimationPreset = keyof typeof AnimationPreset;
/**
 * Alias for `AnimationPreset` for backward compatibility.
 *
 * @public
 */
export declare const Animation: {
    readonly fadeIn: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly fadeOut: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly fadeSlideIn: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly fadeSlideInBottom: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly fadeSlideInLeft: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly fadeSlideInRight: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly fadeSlideInTop: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly fadeSlideOut: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly fadeSlideOutBottom: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly fadeSlideOutLeft: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly fadeSlideOutRight: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly fadeSlideOutTop: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly flash: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly growHorIn: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly growHorOut: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly growVerIn: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly growVerOut: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly rotate: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly shakeHorizontal: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly shakeVertical: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly slideInBottom: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly slideOutBottom: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly slideInTop: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly slideOutTop: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly slideInLeft: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly slideOutLeft: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly slideInRight: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly slideOutRight: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly elasticEnter: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly elasticExit: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly elasticToggle: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly elasticPress: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly elasticPressVertical: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly elasticDigitUp: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly elasticDigitDown: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly elasticSweep: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly elasticShimmer: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly elasticBreathe: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly elasticTileExpand: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly elasticTileContract: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly elasticFocusGrow: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly elasticFocusShrink: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
    readonly elasticInkSettle: import("../IAnimationReferenceMetadata").IAnimationReferenceMetadata;
};
//# sourceMappingURL=AnimationPresets.d.ts.map