// #region Imports
import { RendererServiceLocator } from '../dom/Renderer';
// #endregion
/**
 * The computed transforms that have no visual effect.
 *
 * @internal
 */
const IDENTITY_TRANSFORMS = new Set([
    'matrix(1,0,0,1,0,0)',
    'matrix3d(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1)'
]);
/**
 * The `AnimationPlayer` class provides functionality to play and manage animations on HTML elements.
 *
 * @public
 */
export class AnimationPlayer {
    // #region Fields
    /**
     * The time added on top of an animation's own runtime before the watchdog steps in.
     */
    static WATCHDOG_SLACK = 250;
    /**
     * Animations that run longer than this are left alone. Looping decorations do not gate any
     * lifecycle, so completing them by hand would only cut them short.
     */
    static MAXIMUM_WATCHED_RUNTIME = 10_000;
    // #endregion
    // #region Ctor
    /**
     * Constructs a new instance of the `AnimationPlayer` class.
     *
     * @public
     */
    constructor() {
    }
    // #endregion
    // #region Methods
    /**
     * Plays an animation on the specified element.
     *
     * @param element - The element to animate.
     * @param animation - The animation reference metadata containing keyframes and options.
     * @param overrideOptions - Optional override options for the animation.
     * @param signal - Optionally cancels this playback without applying its final styles.
     * @returns A promise that resolves when the animation completes.
     * @public
     */
    play(element, animation, overrideOptions, signal) {
        if (signal?.aborted) {
            return Promise.resolve(new Event('cancel'));
        }
        const parsedKeyframes = this.parseKeyframes(element, animation.steps);
        if (typeof element.animate !== 'function') {
            this.applyKeyframes(element, parsedKeyframes);
            return Promise.resolve(new Event('finish'));
        }
        return new Promise((resolve) => {
            const options = {
                duration: 333,
                easing: 'ease',
                fill: 'forwards',
                ...animation.options,
                ...overrideOptions
            };
            // Respect prefers-reduced-motion
            if (typeof window.matchMedia === 'function' &&
                window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
                options.duration = 0;
            }
            const anim = element.animate(parsedKeyframes, options);
            let isSettled = false;
            const abort = () => {
                if (isSettled) {
                    return;
                }
                isSettled = true;
                stopWatchdog();
                signal?.removeEventListener('abort', abort);
                anim.cancel();
                resolve(new Event('cancel'));
            };
            const stopWatchdog = this.watchForSuspendedAnimation(options, () => {
                if (isSettled) {
                    return;
                }
                isSettled = true;
                signal?.removeEventListener('abort', abort);
                this.applyKeyframes(element, parsedKeyframes);
                resolve(new Event('finish'));
                anim.cancel();
            });
            anim.addEventListener('cancel', (event) => {
                if (isSettled) {
                    return;
                }
                isSettled = true;
                stopWatchdog();
                signal?.removeEventListener('abort', abort);
                resolve(event);
            }, { once: true });
            anim.addEventListener('finish', (event) => {
                if (isSettled) {
                    return;
                }
                isSettled = true;
                stopWatchdog();
                signal?.removeEventListener('abort', abort);
                this.applyKeyframes(element, parsedKeyframes);
                resolve(event);
                anim.cancel();
            }, { once: true });
            signal?.addEventListener('abort', abort, { once: true });
            if (signal?.aborted) {
                abort();
            }
            else {
                anim.play();
            }
        });
    }
    /**
     * Stops all running animations on the specified element.
     *
     * @param element - The element to stop animations on.
     * @returns A promise that resolves when all animations are stopped.
     * @public
     */
    stopAll(element) {
        if (typeof element.getAnimations !== 'function') {
            return Promise.resolve([]);
        }
        return Promise.all(element.getAnimations().map((animation) => new Promise((resolve) => {
            const handleAnimationEvent = () => requestAnimationFrame(resolve);
            animation.addEventListener('cancel', handleAnimationEvent, { once: true });
            animation.addEventListener('finish', handleAnimationEvent, { once: true });
            animation.cancel();
        })));
    }
    /**
     * Parses keyframes and resolves special values like `height: 'auto'`.
     *
     * @param element - The element being animated.
     * @param keyframes - The keyframes to parse.
     * @returns The parsed keyframes with resolved values.
     * @private
     */
    parseKeyframes(element, keyframes) {
        return keyframes.map((keyframe) => {
            const parsed = { ...keyframe };
            if (parsed.height === 'auto') {
                parsed.height = `${element.scrollHeight}px`;
            }
            if (parsed.width === 'auto') {
                parsed.width = `${element.scrollWidth}px`;
            }
            return parsed;
        });
    }
    /**
     * Plays an animation from the current element state to the final keyframe.
     * This is useful when initial styles have been applied and you want to animate
     * from those styles to the final state.
     *
     * @param element - The element to animate.
     * @param animation - The animation reference metadata containing keyframes and options.
     * @param overrideOptions - Optional override options for the animation.
     * @returns A promise that resolves when the animation completes.
     * @public
     */
    playToFinal(element, animation, overrideOptions) {
        return new Promise((resolve) => {
            if (animation.steps.length === 0) {
                resolve(new Event('finish'));
                return;
            }
            // Get the final keyframe as the target
            const finalKeyframe = this.parseKeyframes(element, [animation.steps[animation.steps.length - 1]])[0];
            // Convert to PropertyIndexedKeyframes format (animates from current state to target)
            const targetProps = {};
            for (const [key, value] of Object.entries(finalKeyframe)) {
                if (key === 'offset' || key === 'easing' || key === 'composite') {
                    continue;
                }
                targetProps[key] = value;
            }
            if (typeof element.animate !== 'function') {
                this.applyStyles(element, targetProps);
                resolve(new Event('finish'));
                return;
            }
            const options = {
                duration: 333,
                easing: 'ease',
                fill: 'forwards',
                ...animation.options,
                ...overrideOptions
            };
            // Respect prefers-reduced-motion
            if (typeof window.matchMedia === 'function' &&
                window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
                options.duration = 0;
            }
            const anim = element.animate(targetProps, options);
            let isSettled = false;
            const stopWatchdog = this.watchForSuspendedAnimation(options, () => {
                if (isSettled) {
                    return;
                }
                isSettled = true;
                this.applyStyles(element, targetProps);
                resolve(new Event('finish'));
                anim.cancel();
            });
            anim.addEventListener('cancel', (event) => {
                if (isSettled) {
                    return;
                }
                isSettled = true;
                stopWatchdog();
                resolve(event);
            }, { once: true });
            anim.addEventListener('finish', (event) => {
                if (isSettled) {
                    return;
                }
                isSettled = true;
                stopWatchdog();
                this.applyStyles(element, targetProps);
                resolve(event);
                anim.cancel();
            }, { once: true });
            anim.play();
        });
    }
    /**
     * Guards an animation against a document timeline that stops advancing.
     *
     * A browser suspends the document timeline while the page is hidden, so an animation started
     * just before a tab switch never reaches its `finish` event. Anything awaiting that event -
     * a tour stepping to the next anchor, for example - would stay pending forever, and would
     * still be stuck after the user comes back. The watchdog settles the animation once its own
     * running time has clearly elapsed.
     *
     * @param options - The options the animation was started with.
     * @param settle - Invoked when the animation has to be completed by hand.
     * @returns A function that cancels the watchdog.
     * @private
     */
    watchForSuspendedAnimation(options, settle) {
        const duration = typeof options.duration === 'number' ? options.duration : 0;
        const iterations = typeof options.iterations === 'number' ? options.iterations : 1;
        const delay = typeof options.delay === 'number' ? options.delay : 0;
        const endDelay = typeof options.endDelay === 'number' ? options.endDelay : 0;
        const runtime = (duration * iterations) + delay + endDelay;
        if (!Number.isFinite(runtime) || runtime > AnimationPlayer.MAXIMUM_WATCHED_RUNTIME) {
            return () => undefined;
        }
        const handle = setTimeout(settle, runtime + AnimationPlayer.WATCHDOG_SLACK);
        return () => clearTimeout(handle);
    }
    /**
     * Applies the final keyframe values to the element's style.
     *
     * @param element - The element to apply styles to.
     * @param keyframes - The keyframes array.
     * @private
     */
    applyKeyframes(element, keyframes) {
        if (keyframes.length === 0) {
            return;
        }
        const finalKeyframe = keyframes[keyframes.length - 1];
        for (const [key, value] of Object.entries(finalKeyframe)) {
            if (key === 'offset' || key === 'easing' || key === 'composite') {
                continue;
            }
            if (key in element.style) {
                RendererServiceLocator.current.setStyle(element, key, value?.toString() ?? '');
            }
        }
        if ('transform' in finalKeyframe) {
            this.dropIdentityTransform(element);
        }
    }
    /**
     * Applies styles from a PropertyIndexedKeyframes object to the element.
     *
     * @param element - The element to apply styles to.
     * @param props - The property values to apply.
     * @private
     */
    applyStyles(element, props) {
        for (const [key, value] of Object.entries(props)) {
            if (key in element.style) {
                RendererServiceLocator.current.setStyle(element, key, value?.toString() ?? '');
            }
        }
        if ('transform' in props) {
            this.dropIdentityTransform(element);
        }
    }
    /**
     * Removes a retained transform that resolves to the identity matrix.
     *
     * Enter animations usually end on `translate(0)` or `scale(1)`. Keeping that value inline is
     * visually a no-op, but it turns the element into the containing block of every fixed
     * positioned descendant. Overlays that measure themselves against the viewport - the tour
     * spotlight for example - would be positioned relative to the animated element instead.
     *
     * @param element - The element the animation was applied to.
     * @private
     */
    dropIdentityTransform(element) {
        if (typeof window === 'undefined' || typeof window.getComputedStyle !== 'function') {
            return;
        }
        const transform = window.getComputedStyle(element).transform;
        if (!transform || transform === 'none' || IDENTITY_TRANSFORMS.has(transform.replace(/\s/g, ''))) {
            RendererServiceLocator.current.removeStyle(element, 'transform');
        }
    }
}
//# sourceMappingURL=AnimationPlayer.js.map