// #region Imports
import { AsyncDirectiveBase, PartType, compose } from '../../controls/directives/abstracts/AsyncDirectiveBase';
import { nothing } from '../../dom/Html';
import { AnimationPlayer } from '../AnimationPlayer';
/**
 * Type guard to check if a value is an `IAnimationRef`.
 *
 * @param value - The value to check.
 * @returns True if the value is an `IAnimationRef`, false otherwise.
 * @public
 */
export function isAnimationRef(value) {
    return value !== null && typeof value === 'object' && 'play' in value;
}
/**
 * The `AnimationRefDirective` class.
 *
 * This directive provides a reference to an element that can be used to trigger animations programmatically.
 *
 * @public
 */
export class AnimationRefDirective extends AsyncDirectiveBase {
    // #region Fields
    _animationPlayer;
    // #endregion
    // #region Ctor
    /**
     * Constructs a new instance of the `AnimationRefDirective` class.
     *
     * @public
     */
    constructor(args) {
        super(args);
        if (args.type !== PartType.ELEMENT) {
            throw new Error('The `animationRef` directive must be used in attribute position.');
        }
        this._animationPlayer = new AnimationPlayer();
    }
    // #endregion
    // #region Methods
    /**
     * Renders the directive and provides an animation reference to the callback.
     *
     * @param callback - A callback that receives the animation reference.
     * @returns Nothing.
     * @public
     */
    render(callback) {
        const animationRef = {
            play: (animation, overrideOptions) => this._animationPlayer.play(this.internals.element, animation, overrideOptions)
        };
        callback(animationRef);
        return nothing;
    }
}
/**
 * A directive that provides an animation reference to programmatically trigger animations.
 *
 * @public
 */
export const animationRef = compose(AnimationRefDirective);
//# sourceMappingURL=AnimationRefDirective.js.map