// #region Imports
export {};
//# sourceMappingURL=IAnimationDirectiveOptions.js.map