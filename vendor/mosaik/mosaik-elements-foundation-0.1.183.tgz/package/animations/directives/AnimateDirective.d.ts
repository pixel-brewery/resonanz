import { type ElementPart } from 'lit/directive.js';
import { type DirectiveArgs, DirectiveBase } from '../../controls/directives/abstracts/DirectiveBase';
import type { IAnimationReferenceMetadata } from '../IAnimationReferenceMetadata';
import { type IAnimationRef } from './AnimationRefDirective';
import type { IAnimationDirectiveOptions } from './IAnimationDirectiveOptions';
/**
 * The `AnimateDirective` class.
 *
 * @public
 */
export declare class AnimateDirective extends DirectiveBase {
    private readonly _animationPlayer;
    private _wasTriggered;
    private _element;
    /**
     * Constructs a new instance of the `AnimateDirective` class.
     *
     * @public
     */
    constructor(args: DirectiveArgs);
    /**
     * Renders the directive with the provided animation options.
     *
     * @param _optionsOrRef - The animation options or an animation reference.
     * @returns Empty string (actual work is done in update).
     * @public
     */
    render(_optionsOrRef: IAnimationDirectiveOptions | IAnimationReferenceMetadata | IAnimationRef): unknown;
    /**
     * Updates the directive and triggers the animation.
     *
     * @param part - The element part containing the target element.
     * @param args - The directive arguments.
     * @returns The render result.
     * @public
     */
    update(part: ElementPart, [optionsOrRef]: Parameters<this['render']>): unknown;
    /**
     * Applies the initial styles to the element.
     *
     * @param options - The animation options containing the initial keyframe.
     * @private
     */
    private applyInitialStyles;
    /**
     * Plays the animation on the element.
     * Uses playToFinal to animate from current state (with initial styles) to the final keyframe.
     *
     * @param options - The animation options.
     * @private
     */
    private playAnimation;
}
/**
 * A directive that triggers an animation on an element.
 *
 * @public
 */
export declare const animate: (...values: Parameters<AnimateDirective["render"]>) => any;
//# sourceMappingURL=AnimateDirective.d.ts.map