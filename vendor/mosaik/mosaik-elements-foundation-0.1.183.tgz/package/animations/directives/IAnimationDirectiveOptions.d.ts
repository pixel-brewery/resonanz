import type { IAnimationReferenceMetadata } from '../IAnimationReferenceMetadata';
/**
 * Options for the `animate` directive.
 *
 * @public
 */
export interface IAnimationDirectiveOptions extends IAnimationReferenceMetadata {
    /**
     * A trigger function that allows delaying the animation until the callback is invoked.
     */
    trigger?: (callback: () => void) => void;
    /**
     * Callback invoked when the animation finishes.
     */
    onFinished?: () => void;
}
//# sourceMappingURL=IAnimationDirectiveOptions.d.ts.map