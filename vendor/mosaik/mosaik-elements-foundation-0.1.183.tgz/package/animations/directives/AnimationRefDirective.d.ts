import { type AsyncDirectiveArgs, AsyncDirectiveBase } from '../../controls/directives/abstracts/AsyncDirectiveBase';
import type { IAnimationReferenceMetadata } from '../IAnimationReferenceMetadata';
/**
 * Interface for an animation reference that can be used to trigger animations programmatically.
 *
 * @public
 */
export interface IAnimationRef {
    /**
     * Plays the specified animation on the element.
     *
     * @param animation - The animation to play.
     * @param overrideOptions - Optional override options for the animation.
     * @returns A promise that resolves when the animation completes.
     */
    play: (animation: IAnimationReferenceMetadata, overrideOptions?: KeyframeAnimationOptions) => Promise<AnimationPlaybackEvent>;
}
/**
 * Type guard to check if a value is an `IAnimationRef`.
 *
 * @param value - The value to check.
 * @returns True if the value is an `IAnimationRef`, false otherwise.
 * @public
 */
export declare function isAnimationRef(value: unknown): value is IAnimationRef;
/**
 * The `AnimationRefDirective` class.
 *
 * This directive provides a reference to an element that can be used to trigger animations programmatically.
 *
 * @public
 */
export declare class AnimationRefDirective extends AsyncDirectiveBase {
    private readonly _animationPlayer;
    /**
     * Constructs a new instance of the `AnimationRefDirective` class.
     *
     * @public
     */
    constructor(args: AsyncDirectiveArgs);
    /**
     * Renders the directive and provides an animation reference to the callback.
     *
     * @param callback - A callback that receives the animation reference.
     * @returns Nothing.
     * @public
     */
    render(callback: (ref: IAnimationRef) => void): unknown;
}
/**
 * A directive that provides an animation reference to programmatically trigger animations.
 *
 * @public
 */
export declare const animationRef: (...values: Parameters<AnimationRefDirective["render"]>) => any;
//# sourceMappingURL=AnimationRefDirective.d.ts.map