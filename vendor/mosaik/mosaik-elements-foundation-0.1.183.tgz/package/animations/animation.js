/**
 * Creates an animation reference metadata object.
 *
 * @param steps - The keyframes that define the animation.
 * @param options - Optional animation options (duration, easing, fill, etc.).
 * @param initial - Optional initial styles. If `true`, uses the first keyframe as initial. If a Keyframe, uses that. If `false` or `undefined`, no initial styles are applied.
 * @returns The animation reference metadata object.
 * @public
 */
export function animation(steps, options, initial = true) {
    let initialKeyframe;
    if (initial === true && steps.length > 0) {
        // Use first keyframe as initial
        initialKeyframe = steps[0];
    }
    else if (typeof initial === 'object' && initial !== null) {
        // Use provided keyframe as initial
        initialKeyframe = initial;
    }
    return {
        initial: initialKeyframe,
        steps,
        options
    };
}
//# sourceMappingURL=animation.js.map