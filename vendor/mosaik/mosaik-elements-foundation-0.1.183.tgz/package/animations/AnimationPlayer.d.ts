import type { IAnimationReferenceMetadata } from './IAnimationReferenceMetadata';
/**
 * The `AnimationPlayer` class provides functionality to play and manage animations on HTML elements.
 *
 * @public
 */
export declare class AnimationPlayer {
    /**
     * The time added on top of an animation's own runtime before the watchdog steps in.
     */
    private static readonly WATCHDOG_SLACK;
    /**
     * Animations that run longer than this are left alone. Looping decorations do not gate any
     * lifecycle, so completing them by hand would only cut them short.
     */
    private static readonly MAXIMUM_WATCHED_RUNTIME;
    /**
     * Constructs a new instance of the `AnimationPlayer` class.
     *
     * @public
     */
    constructor();
    /**
     * Plays an animation on the specified element.
     *
     * @param element - The element to animate.
     * @param animation - The animation reference metadata containing keyframes and options.
     * @param overrideOptions - Optional override options for the animation.
     * @param signal - Optionally cancels this playback without applying its final styles.
     * @returns A promise that resolves when the animation completes.
     * @public
     */
    play(element: HTMLElement, animation: IAnimationReferenceMetadata, overrideOptions?: KeyframeAnimationOptions, signal?: AbortSignal): Promise<AnimationPlaybackEvent>;
    /**
     * Stops all running animations on the specified element.
     *
     * @param element - The element to stop animations on.
     * @returns A promise that resolves when all animations are stopped.
     * @public
     */
    stopAll(element: HTMLElement): Promise<unknown>;
    /**
     * Parses keyframes and resolves special values like `height: 'auto'`.
     *
     * @param element - The element being animated.
     * @param keyframes - The keyframes to parse.
     * @returns The parsed keyframes with resolved values.
     * @private
     */
    private parseKeyframes;
    /**
     * Plays an animation from the current element state to the final keyframe.
     * This is useful when initial styles have been applied and you want to animate
     * from those styles to the final state.
     *
     * @param element - The element to animate.
     * @param animation - The animation reference metadata containing keyframes and options.
     * @param overrideOptions - Optional override options for the animation.
     * @returns A promise that resolves when the animation completes.
     * @public
     */
    playToFinal(element: HTMLElement, animation: IAnimationReferenceMetadata, overrideOptions?: KeyframeAnimationOptions): Promise<AnimationPlaybackEvent>;
    /**
     * Guards an animation against a document timeline that stops advancing.
     *
     * A browser suspends the document timeline while the page is hidden, so an animation started
     * just before a tab switch never reaches its `finish` event. Anything awaiting that event -
     * a tour stepping to the next anchor, for example - would stay pending forever, and would
     * still be stuck after the user comes back. The watchdog settles the animation once its own
     * running time has clearly elapsed.
     *
     * @param options - The options the animation was started with.
     * @param settle - Invoked when the animation has to be completed by hand.
     * @returns A function that cancels the watchdog.
     * @private
     */
    private watchForSuspendedAnimation;
    /**
     * Applies the final keyframe values to the element's style.
     *
     * @param element - The element to apply styles to.
     * @param keyframes - The keyframes array.
     * @private
     */
    private applyKeyframes;
    /**
     * Applies styles from a PropertyIndexedKeyframes object to the element.
     *
     * @param element - The element to apply styles to.
     * @param props - The property values to apply.
     * @private
     */
    private applyStyles;
    /**
     * Removes a retained transform that resolves to the identity matrix.
     *
     * Enter animations usually end on `translate(0)` or `scale(1)`. Keeping that value inline is
     * visually a no-op, but it turns the element into the containing block of every fixed
     * positioned descendant. Overlays that measure themselves against the viewport - the tour
     * spotlight for example - would be positioned relative to the animated element instead.
     *
     * @param element - The element the animation was applied to.
     * @private
     */
    private dropIdentityTransform;
}
//# sourceMappingURL=AnimationPlayer.d.ts.map