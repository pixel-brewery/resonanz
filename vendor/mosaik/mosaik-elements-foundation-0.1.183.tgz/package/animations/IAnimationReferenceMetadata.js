export {};
//# sourceMappingURL=IAnimationReferenceMetadata.js.map