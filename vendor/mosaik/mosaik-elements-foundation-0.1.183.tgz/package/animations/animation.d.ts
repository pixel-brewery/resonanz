import { IAnimationReferenceMetadata } from './IAnimationReferenceMetadata';
/**
 * Creates an animation reference metadata object.
 *
 * @param steps - The keyframes that define the animation.
 * @param options - Optional animation options (duration, easing, fill, etc.).
 * @param initial - Optional initial styles. If `true`, uses the first keyframe as initial. If a Keyframe, uses that. If `false` or `undefined`, no initial styles are applied.
 * @returns The animation reference metadata object.
 * @public
 */
export declare function animation(steps: Array<Keyframe>, options?: KeyframeAnimationOptions, initial?: boolean | Keyframe): IAnimationReferenceMetadata;
//# sourceMappingURL=animation.d.ts.map