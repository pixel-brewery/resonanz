/* eslint-disable @typescript-eslint/naming-convention */
// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Attribute } from '../decorators/AttributeDecorator';
import { ElevationWeight } from '../types/ElevationWeight';
/**
 * @public
 */
export const Elevatable = (base) => {
    class ElevatableElement extends base {
        // #region Fields
        _elevation;
        // #endregion
        // #region Ctor
        /**
         * Constructs a new instance of the `ElevatableElement` class.
         *
         * @public
         */
        constructor(...args) {
            super(args);
            this._elevation = IElevatableProps.DEFAULTS.elevation;
        }
        // #endregion
        // #region Properties
        /**
         * Gets or sets the `elevation` property.
         * The default value is `none`, which means the element has no elevation.
         *
         * @public
         * @attr elevation
         */
        get elevation() {
            return this._elevation;
        }
        set elevation(value) {
            if (this._elevation !== value) {
                this._elevation = value;
                this.requestUpdate('elevation');
            }
        }
    }
    __decorate([
        Attribute({ type: ElevationWeight }),
        __metadata("design:type", String),
        __metadata("design:paramtypes", [String])
    ], ElevatableElement.prototype, "elevation", null);
    return ElevatableElement;
};
/**
 * @public
 */
export var IElevatableProps;
(function (IElevatableProps) {
    IElevatableProps.DEFAULTS = {
        elevation: ElevationWeight.None
    };
})(IElevatableProps || (IElevatableProps = {}));
//# sourceMappingURL=Elevatable.js.map