/* eslint-disable @typescript-eslint/naming-convention */
// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { KeyboardShortcutController } from '../controllers/KeyboardShortcutController';
import { Attribute } from '../decorators/AttributeDecorator';
import { Watch } from '../decorators/WatchDecorator';
/**
 * @public
 */
export const Shortcutable = (base) => {
    class ShortcutableElement extends base {
        // #region Fields
        _shortcutController;
        _shortcut;
        // #endregion
        // #region Ctor
        /**
         * Constructs a new instance of the `ShortcutableElement` class.
         *
         * @public
         */
        constructor(...args) {
            super(args);
            this._shortcut = IShortcutableProps.DEFAULTS.shortcut;
            this._shortcutController = new KeyboardShortcutController(this, {
                pattern: this._shortcut,
                callback: (e) => {
                    e.preventDefault();
                    this.dispatchEvent(new KeyboardEvent('shortcut', e));
                }
            });
        }
        // #endregion
        // #region Properties
        /**
         * Gets or sets the `shortcut` property.
         * This property defines a keyboard shortcut that can trigger an action when pressed.
         * The default value is an empty string, which means no shortcut is defined.
         *
         * @public
         * @attr shortcut
         */
        get shortcut() {
            return this._shortcut;
        }
        set shortcut(value) {
            if (this._shortcut !== value) {
                this._shortcut = value;
                this.requestUpdate('shortcut');
            }
        }
        // #endregion
        // #region Methods
        /**
         * @protected
         */
        onShortcutChanged(prev, next) {
            if (prev !== next && prev && next) {
                this._shortcutController.pattern = next;
            }
        }
    }
    __decorate([
        Attribute({ type: String }),
        __metadata("design:type", String),
        __metadata("design:paramtypes", [String])
    ], ShortcutableElement.prototype, "shortcut", null);
    __decorate([
        Watch('shortcut'),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [String, String]),
        __metadata("design:returntype", void 0)
    ], ShortcutableElement.prototype, "onShortcutChanged", null);
    return ShortcutableElement;
};
/**
 * @public
 */
export var IShortcutableProps;
(function (IShortcutableProps) {
    IShortcutableProps.DEFAULTS = {
        shortcut: ''
    };
})(IShortcutableProps || (IShortcutableProps = {}));
//# sourceMappingURL=Shortcutable.js.map