/* eslint-disable @typescript-eslint/naming-convention */
// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Attribute } from '../decorators/AttributeDecorator';
import { Watch } from '../decorators/WatchDecorator';
/**
 * @public
 */
export const Invalidable = (base) => {
    // The base already provides the value (see the constraint). Applying `Valueable` again would shadow its accessor
    // and reset its default - e.g. the numeric value, its attribute type and the `rangeValueChanged` event of a range.
    class InvalidableElement extends base {
        // #region Fields
        _invalid;
        // #endregion
        // #region Ctor
        /**
         * Constructs a new instance of the `InvalidableElement` class.
         *
         * @public
         */
        constructor(...args) {
            super(args);
            this._invalid = IInvalidableProps.DEFAULTS.invalid;
        }
        // #endregion
        // #region Properties
        /**
         * Determines whether the element is invalid or not.
         * If `true`, the element will be invalid.
         * The default value is `false`, which means the element is valid.
         *
         * @public
         * @attr invalid
         */
        get invalid() {
            return this._invalid;
        }
        set invalid(value) {
            if (this._invalid !== value) {
                this._invalid = value;
                this.requestUpdate('invalid');
            }
        }
        /**
         * @protected
         * @override
         */
        onApplyTemplate() {
            super.onApplyTemplate();
            this.on('invalid', (e) => {
                e.stopPropagation();
                this.invalid = true;
            });
            this.on('blur', () => {
                this.invalid = !this.checkValidity();
            });
        }
        /**
         * @protected
         */
        onValuePropertyChange() {
            void this.updateComplete.then(() => {
                this.invalid = !this.checkValidity();
            });
        }
    }
    __decorate([
        Attribute({
            type: Boolean,
            useDefault: true
        }),
        __metadata("design:type", Boolean),
        __metadata("design:paramtypes", [Boolean])
    ], InvalidableElement.prototype, "invalid", null);
    __decorate([
        Watch('value', { waitUntilFirstUpdate: true }),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", []),
        __metadata("design:returntype", void 0)
    ], InvalidableElement.prototype, "onValuePropertyChange", null);
    return InvalidableElement;
};
/**
 * @public
 */
export var IInvalidableProps;
(function (IInvalidableProps) {
    IInvalidableProps.DEFAULTS = {
        invalid: false
    };
})(IInvalidableProps || (IInvalidableProps = {}));
//# sourceMappingURL=Invalidable.js.map