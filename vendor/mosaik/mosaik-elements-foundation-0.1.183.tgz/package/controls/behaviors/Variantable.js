/* eslint-disable @typescript-eslint/naming-convention */
// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Attribute } from '../decorators/AttributeDecorator';
import { Variant } from '../types/Variant';
/**
 * @public
 */
export const Variantable = (base) => {
    class VariantableElement extends base {
        // #region Fields
        _variant;
        // #endregion
        // #region Ctor
        /**
         * Constructs a new instance of the `VariantableElement` class.
         *
         * @public
         */
        constructor(...args) {
            super(args);
            this._variant = IVariantableProps.DEFAULTS.variant;
        }
        // #endregion
        // #region Properties
        /**
         * Determines the visual appearance (color) of the element.
         * The default value is `default`, which means the element will use the default variant.
         *
         * @public
         * @attr variant
         */
        get variant() {
            return this._variant;
        }
        set variant(value) {
            if (this._variant !== value) {
                this._variant = value;
                this.requestUpdate('variant');
            }
        }
    }
    __decorate([
        Attribute({
            type: Variant,
            useDefault: true
        }),
        __metadata("design:type", String),
        __metadata("design:paramtypes", [String])
    ], VariantableElement.prototype, "variant", null);
    return VariantableElement;
};
/**
 * @public
 */
export var IVariantableProps;
(function (IVariantableProps) {
    IVariantableProps.DEFAULTS = {
        variant: Variant.Default
    };
})(IVariantableProps || (IVariantableProps = {}));
//# sourceMappingURL=Variantable.js.map