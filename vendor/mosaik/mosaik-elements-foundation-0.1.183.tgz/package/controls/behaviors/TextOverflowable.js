/* eslint-disable @typescript-eslint/naming-convention */
// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Attribute } from '../decorators/AttributeDecorator';
import { TextOverflow } from '../types/TextOverflow';
/**
 * @public
 */
export const TextOverflowable = (base) => {
    class TextOverflowableElement extends base {
        // #region Fields
        _textOverflow;
        // #endregion
        // #region Ctor
        /**
         * Constructs a new instance of the `TextOverflowableElement` class.
         *
         * @public
         */
        constructor(...args) {
            super(args);
            this._textOverflow = ITextOverflowableProps.DEFAULTS.textOverflow;
        }
        // #endregion
        // #region Properties
        /**
         * Gets or sets the `textOverflow` property.
         * The default value is `truncate`, which means the text will be truncated if it overflows.
         *
         * @public
         * @attr text-overflow
         */
        get textOverflow() {
            return this._textOverflow;
        }
        set textOverflow(value) {
            if (this._textOverflow !== value) {
                this._textOverflow = value;
                this.requestUpdate('textOverflow');
            }
        }
    }
    __decorate([
        Attribute({ type: TextOverflow }),
        __metadata("design:type", String),
        __metadata("design:paramtypes", [String])
    ], TextOverflowableElement.prototype, "textOverflow", null);
    return TextOverflowableElement;
};
/**
 * @public
 */
export var ITextOverflowableProps;
(function (ITextOverflowableProps) {
    ITextOverflowableProps.DEFAULTS = {
        textOverflow: TextOverflow.Truncate
    };
})(ITextOverflowableProps || (ITextOverflowableProps = {}));
//# sourceMappingURL=TextOverflowable.js.map