import type { CustomElement } from '../components/abstracts/CustomElement';
import type { ControlBehaviorBase, ControlBehaviorReturn } from './abstracts/Behavior';
/**
 * Represents the `IBoundableProps` interface.
 *
 * @public
 */
export interface IBoundableProps {
    start: Date;
    end: Date;
}
/**
 * @public
 */
export declare const Boundable: <T extends ControlBehaviorBase<CustomElement>>(base: T) => ControlBehaviorReturn<T, IBoundableProps>;
/**
 * @public
 */
export declare namespace IBoundableProps {
    const DEFAULTS: IBoundableProps;
}
//# sourceMappingURL=Boundable.d.ts.map