/* eslint-disable @typescript-eslint/naming-convention */
// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Attribute } from '../decorators/AttributeDecorator';
import { Property } from '../decorators/PropertyDecorator';
import { Watch } from '../decorators/WatchDecorator';
/**
 * @public
 */
export var IFilterableProps;
(function (IFilterableProps) {
    IFilterableProps.DEFAULTS = {
        showFilter: false,
        filterMemberPath: '',
        filter: '',
        filterPlaceholder: ''
    };
})(IFilterableProps || (IFilterableProps = {}));
/**
 * @public
 */
export const Filterable = (base) => {
    class FilterableElement extends base {
        // #region Fields
        _showFilter;
        _filterMemberPath;
        _filter;
        _filterPlaceholder;
        // #endregion
        // #region Ctor
        /**
         * Constructs a new instance of the `FilterableElement` class.
         *
         * @public
         */
        constructor(...args) {
            super(args);
            this._showFilter = IFilterableProps.DEFAULTS.showFilter;
            this._filterMemberPath = IFilterableProps.DEFAULTS.filterMemberPath;
            this._filter = IFilterableProps.DEFAULTS.filter;
            this._filterPlaceholder = IFilterableProps.DEFAULTS.filterPlaceholder;
        }
        // #endregion
        // #region Properties
        /**
         * Gets or sets the `showFilter` property.
         * The default value is `false`, which means the filter input is not shown.
         *
         * @public
         * @attr show-filter
         */
        get showFilter() {
            return this._showFilter;
        }
        set showFilter(value) {
            if (this._showFilter !== value) {
                this._showFilter = value;
                this.requestUpdate('showFilter');
            }
        }
        /**
         * Gets or sets the `filterMemberPath` property.
         * The member path is a dot-separated string that specifies the property to filter by.
         * The default value is an empty string, which means no specific member path is used for filtering.
         *
         * @attr filter-member-path
         * @public
         * @example
         * ```ts
         * interface ICar {
         *     brand: {
         *        name: string;
         *     };
         * }
         *
         * filterMemberPath: 'brand.name'
         * ```
         */
        get filterMemberPath() {
            return this._filterMemberPath;
        }
        set filterMemberPath(value) {
            if (this._filterMemberPath !== value) {
                this._filterMemberPath = value;
                this.requestUpdate('filterMemberPath');
            }
        }
        /**
         * Gets or sets the `filter` property.
         * The default value is an empty string, which means no filter is applied.
         *
         * @public
         */
        get filter() {
            return this._filter;
        }
        set filter(value) {
            if (this._filter !== value) {
                this._filter = value;
                this.requestUpdate('filter');
            }
        }
        /**
         * Gets or sets the `filterPlaceholder` property.
         * The default value is an empty string, which means no placeholder is shown in the filter input.
         *
         * @public
         */
        get filterPlaceholder() {
            return this._filterPlaceholder;
        }
        set filterPlaceholder(value) {
            if (this._filterPlaceholder !== value) {
                this._filterPlaceholder = value;
                this.requestUpdate('filterPlaceholder');
            }
        }
    }
    __decorate([
        Attribute({
            type: Boolean,
            useDefault: true
        }),
        __metadata("design:type", Boolean),
        __metadata("design:paramtypes", [Boolean])
    ], FilterableElement.prototype, "showFilter", null);
    __decorate([
        Attribute({ type: String }),
        __metadata("design:type", String),
        __metadata("design:paramtypes", [String])
    ], FilterableElement.prototype, "filterMemberPath", null);
    __decorate([
        Property({ type: String }),
        __metadata("design:type", String),
        __metadata("design:paramtypes", [String])
    ], FilterableElement.prototype, "filter", null);
    __decorate([
        Property({ type: String }),
        __metadata("design:type", String),
        __metadata("design:paramtypes", [String])
    ], FilterableElement.prototype, "filterPlaceholder", null);
    return FilterableElement;
};
/**
 * The `FilterableChild` mix-in enables automatic hiding based on a parent filter.
 *
 * @public
 */
export const FilterableChild = (base) => {
    class FilterableChildElement extends base {
        // #region Fields
        _isFiltered = false;
        // #endregion
        // #region Properties
        /**
         * Gets or sets the `isFiltered` property.
         * If true, the element is hidden via `display: none`.
         *
         * @public
         * @attr is-filtered
         */
        get isFiltered() {
            return this._isFiltered;
        }
        set isFiltered(value) {
            if (this._isFiltered !== value) {
                this._isFiltered = value;
                this.requestUpdate('isFiltered');
            }
        }
        // #endregion
        // #region Methods
        /**
         * @protected
         */
        onIsFilteredPropertyChanged(_, next) {
            if (next) {
                this.setAttribute('is-filtered', '');
            }
            else {
                this.removeAttribute('is-filtered');
            }
        }
    }
    __decorate([
        Attribute({
            type: Boolean,
            useDefault: true
        }),
        __metadata("design:type", Boolean),
        __metadata("design:paramtypes", [Boolean])
    ], FilterableChildElement.prototype, "isFiltered", null);
    __decorate([
        Watch('isFiltered'),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [String, String]),
        __metadata("design:returntype", void 0)
    ], FilterableChildElement.prototype, "onIsFilteredPropertyChanged", null);
    return FilterableChildElement;
};
/**
 * Returns a value by member path.
 *
 * @public
 */
export function getMemberValue(self, memberKey) {
    // @ts-ignore fix suppressImplicitAnyIndexErrors
    return memberKey.split('.').reduce((a, b) => a[b], self);
}
/**
 * Determines whether the specified string contains the specified value.
 *
 * @public
 */
export function contains(self, match, ignoreCase) {
    if (ignoreCase) {
        return self.toUpperCase().includes(match.toUpperCase());
    }
    return self.includes(match);
}
//# sourceMappingURL=Filterable.js.map