/* eslint-disable @typescript-eslint/naming-convention */
// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { RendererServiceLocator } from '../../dom/Renderer';
import { Attribute } from '../decorators/AttributeDecorator';
import { Watch } from '../decorators/WatchDecorator';
import { Inset, InsetFn } from '../types/Inset';
/**
 * @public
 */
export const Insetable = (base) => {
    class InsetableElement extends base {
        // #region Fields
        _inset;
        // #endregion
        // #region Ctor
        /**
         * Constructs a new instance of the `InsetableElement` class.
         *
         * @public
         */
        constructor(...args) {
            super(args);
            this._inset = IInsetableProps.DEFAULTS.inset;
        }
        // #endregion
        // #region Properties
        /**
         * Gets or sets the inset value.
         * Appears as dom class property.
         *
         * Possible values are:
         * * `top` - applies an inset to the top of the element
         * * `right` - applies an inset to the right of the element
         * * `bottom` - applies an inset to the bottom of the element
         * * `left` - applies an inset to the left of the element
         * * `vertical` - applies an inset to both the top and bottom of the element
         * * `horizontal` - applies an inset to both the left and right of the element
         * * `all` - applies an inset to all sides of the element
         * * `none` (default) - no inset is applied
         *
         * The default value is `none`, which means no inset is applied.
         *
         * @public
         * @attr inset
         */
        get inset() {
            return this._inset;
        }
        set inset(value) {
            if (this._inset !== value) {
                this._inset = InsetFn.parse(value);
                this.requestUpdate('inset');
            }
        }
        // #endregion
        // #region Methods
        /**
         * @protected
         */
        onInsetChanged(prev, next) {
            if (prev !== next && prev && next) {
                if (this.classList.contains(prev)) {
                    RendererServiceLocator.current.removeClass(this, prev);
                    RendererServiceLocator.current.addClass(this, next);
                }
            }
        }
    }
    __decorate([
        Attribute({
            type: (Array),
            converter: {
                fromAttribute: (value) => value.split(' ').map((p) => p.trim())
                    .filter((p) => p !== ''),
                toAttribute: (value) => value.join(' ')
            }
        }),
        __metadata("design:type", Object),
        __metadata("design:paramtypes", [Object])
    ], InsetableElement.prototype, "inset", null);
    __decorate([
        Watch('inset'),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [String, String]),
        __metadata("design:returntype", void 0)
    ], InsetableElement.prototype, "onInsetChanged", null);
    return InsetableElement;
};
/**
 * @public
 */
export var IInsetableProps;
(function (IInsetableProps) {
    IInsetableProps.DEFAULTS = {
        inset: [Inset.None]
    };
})(IInsetableProps || (IInsetableProps = {}));
//# sourceMappingURL=Insetable.js.map