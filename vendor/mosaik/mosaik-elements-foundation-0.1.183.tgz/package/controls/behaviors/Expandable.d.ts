import { IEventEmitter } from '@pixel-brewery/mosaik-elements';
import type { CustomElement } from '../components/abstracts/CustomElement';
import type { ICollapsedEventDetail, IExpandedEventDetail, IToggledEventDetail } from '../events';
import type { ControlBehaviorBase, ControlBehaviorReturn } from './abstracts/Behavior';
import type { IDisableableProps } from './Disableable';
/**
 * Represents the events of the `Expandable` mixin.
 *
 * @public
 */
export interface IExpandableEvents {
    /**
     * Called when the element is expanded.
     */
    expanded: IEventEmitter<IExpandedEventDetail>;
    /**
     * Called when the element is collapsed.
     */
    collapsed: IEventEmitter<ICollapsedEventDetail>;
    /**
     * Called when the element is toggled.
     */
    toggled: IEventEmitter<IToggledEventDetail>;
}
/**
 * Represents the `IExpandableProps` interface.
 *
 * @public
 */
export interface IExpandableProps {
    /**
     * Whether the element is currently expanded.
     */
    isExpanded: boolean;
}
/**
 * Represents the `IExpandable` interface.
 *
 * @public
 */
export interface IExpandableBehavior {
    /**
     * Expands the element.
     */
    expand(): void;
    /**
     * Collapses the element.
     */
    collapse(): void;
    /**
     * Toggles the element between expanded and collapsed states.
     */
    toggle(): void;
    /**
     * This method is invoked when the `isExpanded` property is changed.
     * Override this method to add custom behavior when the expanded state changes.
     *
     * @param prev - The previous value of `isExpanded`.
     * @param next - The new value of `isExpanded`.
     */
    onIsExpandedChanged(prev: boolean, next: boolean): void;
}
/**
 * @public
 */
export declare namespace IExpandableProps {
    const DEFAULTS: IExpandableProps;
}
/**
 * A mixin that provides expand/collapse functionality to a custom element.
 *
 * @fires expanded {ExpandedEvent} - Fired when the element is expanded.
 * @fires collapsed {CollapsedEvent} - Fired when the element is collapsed.
 * @fires toggled {ToggledEvent} - Fired when the element is toggled.
 *
 * @public
 */
export declare const Expandable: <T extends ControlBehaviorBase<CustomElement & IDisableableProps>>(base: T) => ControlBehaviorReturn<T, IExpandableProps & IExpandableEvents & IExpandableBehavior>;
//# sourceMappingURL=Expandable.d.ts.map