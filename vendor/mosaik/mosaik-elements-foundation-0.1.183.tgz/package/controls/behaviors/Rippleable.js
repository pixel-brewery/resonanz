/* eslint-disable @typescript-eslint/naming-convention */
// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Attribute } from '../decorators/AttributeDecorator';
/**
 * A mixin that adds ripple control to a component.
 * When `ripple` is set to `false`, the ripple effect is disabled.
 *
 * @public
 */
export const Rippleable = (base) => {
    class RippleableElement extends base {
        // #region Fields
        _ripple;
        // #endregion
        // #region Ctor
        /**
         * Constructs a new instance of the `RippleableElement` class.
         *
         * @public
         */
        constructor(...args) {
            super(args);
            this._ripple = IRippleableProps.DEFAULTS.ripple;
        }
        // #endregion
        // #region Properties
        /**
         * Gets or sets the `ripple` property.
         * When set to `false`, the ripple effect is disabled for the element.
         * The default value is `true`, which means the ripple effect is enabled.
         *
         * @public
         * @attr ripple
         */
        get ripple() {
            return this._ripple;
        }
        set ripple(value) {
            if (this._ripple !== value) {
                this._ripple = value;
                this.requestUpdate('ripple');
            }
        }
    }
    __decorate([
        Attribute({
            type: Boolean,
            useDefault: true
        }),
        __metadata("design:type", Boolean),
        __metadata("design:paramtypes", [Boolean])
    ], RippleableElement.prototype, "ripple", null);
    return RippleableElement;
};
/**
 * @public
 */
export var IRippleableProps;
(function (IRippleableProps) {
    IRippleableProps.DEFAULTS = {
        ripple: true
    };
})(IRippleableProps || (IRippleableProps = {}));
//# sourceMappingURL=Rippleable.js.map