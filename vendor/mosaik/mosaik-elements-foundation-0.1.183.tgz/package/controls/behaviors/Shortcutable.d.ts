import type { CustomElement } from '../components/abstracts/CustomElement';
import type { ControlBehaviorBase, ControlBehaviorReturn } from './abstracts/Behavior';
/**
 * Represents the `IShortcutable` interface.
 *
 * @public
 */
export interface IShortcutableProps {
    shortcut: string;
}
/**
 * @public
 */
export declare const Shortcutable: <T extends ControlBehaviorBase<CustomElement>>(base: T) => ControlBehaviorReturn<T, IShortcutableProps>;
/**
 * @public
 */
export declare namespace IShortcutableProps {
    const DEFAULTS: IShortcutableProps;
}
//# sourceMappingURL=Shortcutable.d.ts.map