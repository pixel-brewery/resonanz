import type { CustomElement } from '../components/abstracts/CustomElement';
import { Variant } from '../types/Variant';
import type { ControlBehaviorBase, ControlBehaviorReturn } from './abstracts/Behavior';
/**
 * Represents the `IVariantableElementProps` interface.
 *
 * @public
 */
export interface IVariantableProps {
    variant: Variant;
}
/**
 * @public
 */
export declare const Variantable: <T extends ControlBehaviorBase<CustomElement>>(base: T) => ControlBehaviorReturn<T, IVariantableProps>;
/**
 * @public
 */
export declare namespace IVariantableProps {
    const DEFAULTS: IVariantableProps;
}
//# sourceMappingURL=Variantable.d.ts.map