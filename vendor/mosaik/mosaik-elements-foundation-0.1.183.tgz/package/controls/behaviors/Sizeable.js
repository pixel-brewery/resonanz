/* eslint-disable @typescript-eslint/naming-convention */
// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Attribute } from '../decorators/AttributeDecorator';
import { Watch } from '../decorators/WatchDecorator';
import { Size } from '../types/Size';
/**
 * @public
 */
export const Sizeable = (base) => {
    class SizeableElement extends base {
        // #region Fields
        _size;
        // #endregion
        // #region Ctor
        /**
         * Constructs a new instance of the `SizeableElement` class.
         *
         * @public
         */
        constructor(...args) {
            super(args);
            this._size = ISizeableProps.DEFAULTS.size;
        }
        // #endregion
        // #region Properties
        /**
         * Gets or sets the `size` property.
         * The default value is `medium`, which means the element has a medium size.
         *
         * @public
         * @attr size
         */
        get size() {
            return this._size;
        }
        set size(value) {
            if (this._size !== value) {
                this._size = value;
                this.requestUpdate('size');
            }
        }
        // #endregion
        // #region Methods
        /**
         * @protected
         */
        onSizeChanged(prev, next) {
            if (prev !== next && prev && next) {
                if (this.classList.contains(prev)) {
                    this.classList.remove(prev);
                    this.classList.add(next);
                }
            }
        }
    }
    __decorate([
        Attribute({ type: Size }),
        __metadata("design:type", String),
        __metadata("design:paramtypes", [String])
    ], SizeableElement.prototype, "size", null);
    __decorate([
        Watch('size'),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [String, String]),
        __metadata("design:returntype", void 0)
    ], SizeableElement.prototype, "onSizeChanged", null);
    return SizeableElement;
};
/**
 * @public
 */
export var ISizeableProps;
(function (ISizeableProps) {
    ISizeableProps.DEFAULTS = {
        size: Size.Medium
    };
})(ISizeableProps || (ISizeableProps = {}));
//# sourceMappingURL=Sizeable.js.map