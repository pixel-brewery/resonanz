/* eslint-disable @typescript-eslint/naming-convention */
// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Property } from '../decorators/PropertyDecorator';
import { TextFormatters } from '../types/TextFormatter';
/**
 * The unknown formatter names that warned already - each one warns once, not on every render.
 */
const warnedFormatterNames = new Set();
/**
 * Resolves a formatter: a function stays as it is, a name (any case) becomes the formatter of `TextFormatters` with that
 * name. An unknown name or any other value means no formatter - the text stays as it is, and an unknown name warns once
 * instead of failing on every render.
 */
function resolveTextFormatter(value) {
    if (typeof value === 'function') {
        return value;
    }
    if (typeof value !== 'string' || value === '') {
        return null;
    }
    const name = value.toLowerCase();
    const known = Object.entries(TextFormatters).find(([key]) => key.toLowerCase() === name);
    if (known) {
        return known[1];
    }
    if (!warnedFormatterNames.has(name)) {
        warnedFormatterNames.add(name);
        console.warn(`[TextFormattable]: Unknown formatter '${value}' - the text stays unformatted. Known formatters: ${Object.keys(TextFormatters).map((x) => x.toLowerCase()).join(', ')}.`);
    }
    return null;
}
/**
 * @public
 */
export const TextFormattable = (base) => {
    class TextFormattableElement extends base {
        // #region Fields
        _formatter;
        // #endregion
        // #region Ctor
        /**
         * Constructs a new instance of the `TextFormattableElement` class.
         *
         * @public
         */
        constructor(...args) {
            super(args);
            this._formatter = ITextFormattableProps.DEFAULTS.formatter;
        }
        // #endregion
        // #region Properties
        /**
         * Gets or sets the `formatter` property.
         * A function, or the name of one of the `TextFormatters` (`richtext`, `markdown`, `bbcode`, `default`; any
         * case), which is read as that function. The default value is `null`, which means no formatter is set; an
         * unknown name means no formatter too (it warns once).
         *
         * @public
         */
        get formatter() {
            return this._formatter;
        }
        set formatter(value) {
            const formatter = resolveTextFormatter(value);
            if (this._formatter !== formatter) {
                this._formatter = formatter;
                this.requestUpdate('formatter');
            }
        }
    }
    __decorate([
        Property({
            type: Object,
            converter: (value) => resolveTextFormatter(value)
        }),
        __metadata("design:type", Object),
        __metadata("design:paramtypes", [Object])
    ], TextFormattableElement.prototype, "formatter", null);
    return TextFormattableElement;
};
/**
 * @public
 */
export var ITextFormattableProps;
(function (ITextFormattableProps) {
    ITextFormattableProps.DEFAULTS = {
        formatter: null
    };
})(ITextFormattableProps || (ITextFormattableProps = {}));
//# sourceMappingURL=TextFormattable.js.map