import { ICancelEventDetail, IEventEmitter } from '@pixel-brewery/mosaik-elements';
import type { CustomElement } from '../components/abstracts/CustomElement';
import type { ControlBehaviorBase, ControlBehaviorReturn } from './abstracts/Behavior';
/**
 * Represents the events of the `Openable` mixin.
 *
 * @fires opened {OpenedEvent} - Fired when the element is opened.
 *
 * @public
 */
export interface IOpenableEvents {
    opened: IEventEmitter<ICancelEventDetail>;
}
/**
 * Represents the `IOpenable` interface.
 *
 * @public
 */
export interface IOpenable {
    /**
     * Opens the element.
     */
    open(): Promise<void>;
}
/**
 * @public
 */
export declare const Openable: <T extends ControlBehaviorBase<CustomElement>>(base: T) => ControlBehaviorReturn<T, IOpenable & IOpenableEvents>;
//# sourceMappingURL=Openable.d.ts.map