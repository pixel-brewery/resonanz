/**
 * The base class for a mixin/behavior with an optional expected base class type.
 *
 * @template TElement Optional expected base class type, such as `CustomElement`.
 *
 * @example
 * ```ts
 * interface Foo {
 *   isFoo: boolean;
 * }
 *
 * function fooBehavior<T extends ControlBehaviorBase>(base: T): ControlBehaviorReturn<T, Foo> {
 *   // class must be `abstract`
 *   abstract class FooImpl extends base implements Foo {
 *     isFoo = true;
 *   }
 *
 *   return FooImpl;
 * }
 * ```
 */
export type ControlBehaviorBase<TElement = object> = abstract new (...args: Array<any>) => TElement;
/**
 * The return value of a mixin/behavior.
 *
 * @template TBehaviorBase The generic that extends `ControlBehaviorBase` used for the mixin's base class argument.
 * @template TBehaviorClass Optional interface of functionality that was mixed in. Omit if no additional APIs were added (such as purely overriding base class functionality).
 *
 * @example
 * ```ts
 * interface Foo {
 *   isFoo: boolean;
 * }
 *
 * function fooBehavior<T extends ControlBehaviorBase>(base: T): ControlBehaviorReturn<T, Foo> {
 *   // class must be `abstract`
 *   abstract class FooImpl extends base implements Foo {
 *     isFoo = true;
 *   }
 *
 *   return FooImpl;
 * }
 * ```
 */
export type ControlBehaviorReturn<TBehaviorBase, TBehaviorClass = object> = (abstract new (...args: Array<any>) => TBehaviorClass) & TBehaviorBase;
//# sourceMappingURL=Behavior.d.ts.map