import { CssLength } from '@pixel-brewery/mosaik-themes';
import type { CustomElement } from '../components/abstracts/CustomElement';
import { Placement } from '../types/Placement';
import { Strategy } from '../types/Strategy';
import type { ControlBehaviorBase, ControlBehaviorReturn } from './abstracts/Behavior';
import type { IDisableableProps } from './Disableable';
export interface IDropDownable {
    /**
     * Opens the drop down.
     */
    open(): void;
    /**
     * Closes the drop down.
     */
    close(): void;
    /**
     * Toggles the drop down.
     */
    toggle(): void;
}
/**
 * Represents the `IDropDownable` interface.
 *
 * @public
 */
export interface IDropDownableProps {
    dropDownPlacement: Placement;
    dropDownStrategy: Strategy;
    dropDownDistance: number;
    dropDownSkidding: number;
    dropDownStaysOpen: boolean;
    dropDownMaxHeight: CssLength;
    dropDownHeight?: CssLength;
    dropDownMaxWidth?: CssLength;
    dropDownWidth?: CssLength;
    isDropDownOpen: boolean;
}
/**
 * @public
 */
export declare namespace IDropDownableProps {
    const DEFAULTS: IDropDownableProps;
}
/**
 * @public
 */
export declare const DropDownable: <T extends ControlBehaviorBase<CustomElement & IDisableableProps>>(base: T) => ControlBehaviorReturn<T, IDropDownableProps & IDropDownable>;
//# sourceMappingURL=DropDownable.d.ts.map