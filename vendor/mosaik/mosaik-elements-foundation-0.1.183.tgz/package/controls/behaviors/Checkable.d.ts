import { IEventEmitter } from '@pixel-brewery/mosaik-elements';
import type { CustomElement } from '../components/abstracts/CustomElement';
import type { ICheckedEventDetail, IToggledEventDetail, IUncheckedEventDetail } from '../events';
import type { ControlBehaviorBase, ControlBehaviorReturn } from './abstracts/Behavior';
import type { IDisableableProps } from './Disableable';
/**
 * Represents the events of the `Checkable` mixin.
 *
 * @public
 */
export interface ICheckableEvents {
    checked: IEventEmitter<ICheckedEventDetail>;
    unchecked: IEventEmitter<IUncheckedEventDetail>;
    toggled: IEventEmitter<IToggledEventDetail>;
}
/**
 * Represents the `ICheckableProps` interface.
 *
 * @public
 */
export interface ICheckableProps {
    isChecked: boolean;
}
/**
 * Represents the `ICheckable` interface.
 *
 * @public
 */
export interface ICheckable {
    check(): void;
    uncheck(): void;
    toggle(): void;
}
/**
 * @public
 */
export declare namespace ICheckableProps {
    const DEFAULTS: ICheckableProps;
}
/**
 * @fires checked {CheckedEvent} - Fired when the `isChecked` property is `true`.
 * @fires unchecked {UncheckedEvent} - Fired when the `isChecked` property is `false`.
 * @fires toggled {ToggledEvent} - Fired when the `isChecked` property changes (either direction).
 *
 * @public
 */
export declare const Checkable: <T extends ControlBehaviorBase<CustomElement & IDisableableProps>>(base: T) => ControlBehaviorReturn<T, ICheckableProps & ICheckableEvents & ICheckable>;
//# sourceMappingURL=Checkable.d.ts.map