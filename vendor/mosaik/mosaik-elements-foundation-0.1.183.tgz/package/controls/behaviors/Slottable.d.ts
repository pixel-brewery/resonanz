import type { Constructor } from '../../types/Constructor';
import type { CustomElement } from '../components/abstracts/CustomElement';
import type { ControlBehaviorBase, ControlBehaviorReturn } from './abstracts/Behavior';
export interface ISlottable {
    /**
     * Assigns nodes to a dedicated slot.
     *
     * @public
     * @hidden
     * @param slotName - The slot name (For default slot, pass an empty string).
     * @param node - The nodes to assign to the slot.
     * @returns void
     */
    assignToSlot(slotName: string, node: Element | Text): void;
    /**
     * Returns the assigned elements of a slot.
     *
     * @public
     * @hidden
     * @param slotName - The slot name (For default slot, pass an empty string).
     * @param filter - The optional filter function.
     * @returns The assigned elements of a slot.
     */
    getSlotAssignments<T extends Element = Element>(slotName: string, filter?: (e: T) => boolean): Array<T>;
    /**
     * Returns the assigned elements of a slot with a specific element type.
     *
     * @public
     * @hidden
     * @param slotName - The slot name (For default slot, pass an empty string).
     * @param element - The element to filter.
     * @returns The assigned elements of a slot.
     */
    getSlotAssignmentsOf<T extends Element = Element>(slotName: string, element: Constructor<T>): Array<T>;
    /**
     * Returns the assigned elements of a slot as string.
     *
     * @public
     * @hidden
     * @param slotName - The slot name (For default slot, pass an empty string).
     * @returns The assigned elements of a slot as string.
     */
    getSlotContent(slotName: string): string;
    /**
     * Returns a boolean that indicates if a slot has content.
     *
     * @public
     * @hidden
     * @param slotName - The slot name (For default slot, pass an empty string).
     * @returns A boolean that indicates if a slot has content.
     */
    hasSlotContent(slotName: string): boolean;
    /**
     * Returns a boolean that indicates if a slot exists.
     *
     * @public
     * @hidden
     * @param slotName - The slot name (For default slot, pass an empty string).
     * @returns A boolean that indicates if a slot exists.
     */
    hasSlot(slotName: string): boolean;
    /**
     * Called when the slot changes.
     * This method is a hook that can be overridden.
     *
     * @public
     * @hidden
     * @param slotName - The optional slot name (For default slot, passes undefined).
     */
    onSlotChanges(slotName?: string): void;
}
/**
 * Represents the `ISlottable` interface.
 *
 * @public
 */
export interface ISlottableProps {
}
/**
 * Slottable - A behavior that adds slottable capabilities to a control.
 *
 * @public
 */
export declare const Slottable: <T extends ControlBehaviorBase<CustomElement>>(base: T) => ControlBehaviorReturn<T, ISlottableProps & ISlottable>;
//# sourceMappingURL=Slottable.d.ts.map