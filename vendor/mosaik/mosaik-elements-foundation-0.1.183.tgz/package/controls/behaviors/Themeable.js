// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { ThemeObserverServiceLocator } from '@pixel-brewery/mosaik-themes';
import { adoptStyles, getCompatibleStyle, supportsAdoptingStyleSheets } from 'lit';
import { ThemeService } from '../../theming/ThemeService';
import { Property } from '../decorators/PropertyDecorator';
// #endregion
/**
 * The document theme each themeable element class finalized its class-wide `elementStyles` for.
 *
 * @private
 */
const FINALIZED_THEMES = new WeakMap();
/**
 * The finalized styles of each themeable element class per document theme.
 *
 * @private
 */
const THEME_STYLES = new WeakMap();
/**
 * @public
 */
export var IThemeableProps;
(function (IThemeableProps) {
    IThemeableProps.DEFAULTS = {
        themeName: ''
    };
})(IThemeableProps || (IThemeableProps = {}));
/**
 * @public
 */
export const Themeable = (base) => {
    class ThemeableElement extends base {
        // #region Fields
        static _themeStyles = {};
        _themeName;
        _themeChangedSubscription = null;
        _themeObserverSubscription = null;
        _adoptedTheme = undefined;
        // #endregion
        // #region Ctor
        /**
         * Constructs a new instance of the `ThemeableElement` class.
         *
         * @public
         */
        constructor(...args) {
            super(args);
            this._themeName = IThemeableProps.DEFAULTS.themeName;
            this._themeChangedSubscription = null;
            this._themeObserverSubscription = null;
            this._adoptedTheme = undefined;
        }
        // #endregion
        // #region Properties
        /**
         * Gets or sets the `themeName` property.
         * This property defines the name of the theme to be applied to the element.
         * If not set, the element will use the default theme.
         * The default value is an empty string, which means no theme is set.
         *
         * @public
         */
        get themeName() {
            return this._themeName;
        }
        set themeName(value) {
            if (this._themeName !== value) {
                this._themeName = value;
                this.requestUpdate('themeName');
            }
        }
        // #endregion
        // #region Methods
        /**
         * Registers the themes for subsequent instances, including when the element class is already defined.
         *
         * @public
         * @static
         * @param themes - The themes to register.
         */
        static registerThemes(themes) {
            this._themeStyles = themes;
            THEME_STYLES.delete(this);
            const finalizedTheme = FINALIZED_THEMES.get(this);
            if (finalizedTheme !== undefined) {
                this.elementStyles = this.getThemeStyles(finalizedTheme);
            }
        }
        /**
         * @public
         * @override
         */
        connectedCallback() {
            super.connectedCallback();
            // if (!this._theme) {
            //     this.theme = this.getGlobalTheme();
            // }
            this._themeChangedSubscription = ThemeService.instance.themeChanged.subscribe((x) => {
                this.themeName = x?.name ?? '';
            });
            this._themeObserverSubscription = ThemeObserverServiceLocator.current.themeChanged.subscribe(() => {
                this.forceStyleUpdate();
            });
            // The observer only reports later switches: a theme the document switched to before the element was
            // created, or while it was detached, has to be taken over now.
            if (this.adoptThemeStyles()) {
                this.requestUpdate();
            }
        }
        /**
         * @public
         * @override
         */
        disconnectedCallback() {
            super.disconnectedCallback();
            this._themeChangedSubscription?.dispose();
            this._themeChangedSubscription = null;
            // The observer is global - keeping the subscription would keep every removed element alive.
            this._themeObserverSubscription?.dispose();
            this._themeObserverSubscription = null;
        }
        /**
         * Finalizes the class-wide styles for the theme the document runs when the element class is defined.
         * Lit adopts these styles into every new render root; an element created under another theme adopts
         * that theme on connection.
         *
         * @protected
         * @param styles - The styles to finalize.
         * @returns - The finalized styles.
         */
        static finalizeStyles(styles) {
            const theme = document.documentElement.getAttribute('theme');
            FINALIZED_THEMES.set(this, theme);
            return this.composeThemeStyles(theme, styles);
        }
        /**
         * Returns the styles of the element class for a theme, finalized once per class and theme.
         *
         * @private
         * @param theme - The document theme.
         */
        static getThemeStyles(theme) {
            let stylesByTheme = THEME_STYLES.get(this);
            if (!stylesByTheme) {
                stylesByTheme = new Map();
                THEME_STYLES.set(this, stylesByTheme);
            }
            let styles = stylesByTheme.get(theme);
            if (!styles) {
                styles = this.composeThemeStyles(theme, this.styles);
                stylesByTheme.set(theme, styles);
            }
            return styles;
        }
        /**
         * Composes the base styles with the styles registered for a theme.
         *
         * @private
         * @param theme - The document theme.
         * @param styles - The base styles.
         */
        static composeThemeStyles(theme, styles) {
            const themeStyles = Object.entries(this._themeStyles).find(([key]) => key === theme)?.[1];
            return finalizeStyles([
                styles ?? [],
                themeStyles ?? []
            ]);
        }
        /**
         * Adopts the styles of the current document theme and renders the element again.
         *
         * @private
         */
        forceStyleUpdate() {
            this.adoptThemeStyles();
            this.requestUpdate();
        }
        /**
         * Adopts the styles of the theme the document runs now, unless the shadow root already holds them.
         * Until the element adopted a theme itself, its shadow root holds the class-wide styles Lit finalized
         * for the theme of the document when the element class was defined.
         *
         * @private
         * @returns Whether the styles of another theme were adopted.
         */
        adoptThemeStyles() {
            if (!this.shadowRoot) {
                return false;
            }
            const ctor = this.constructor;
            const theme = document.documentElement.getAttribute('theme');
            const adoptedTheme = this._adoptedTheme === undefined
                ? FINALIZED_THEMES.get(ctor)
                : this._adoptedTheme;
            const adoptedStyles = this._adoptedTheme === undefined
                ? ctor.elementStyles
                : ctor.getThemeStyles(this._adoptedTheme);
            this._adoptedTheme = theme;
            if (adoptedTheme === theme) {
                return false;
            }
            const styles = ctor.getThemeStyles(theme);
            if (supportsAdoptingStyleSheets) {
                // Swap only the class styles: sheets added at runtime (e.g. by the inline style controller) stay.
                const toSheet = (style) => style instanceof CSSStyleSheet ? style : style.styleSheet;
                const previousSheets = new Set(adoptedStyles.map(toSheet));
                const sheets = styles.map(toSheet).filter((sheet) => sheet !== undefined);
                this.shadowRoot.adoptedStyleSheets = [
                    ...sheets,
                    ...this.shadowRoot.adoptedStyleSheets.filter((sheet) => !previousSheets.has(sheet) && !sheets.includes(sheet))
                ];
            }
            else {
                adoptStyles(this.shadowRoot, styles);
            }
            return true;
        }
    }
    __decorate([
        Property({ type: String }),
        __metadata("design:type", String),
        __metadata("design:paramtypes", [String])
    ], ThemeableElement.prototype, "themeName", null);
    return ThemeableElement;
};
function finalizeStyles(styles) {
    const elementStyles = [];
    if (Array.isArray(styles)) {
        // Dedupe the flattened array in reverse order to preserve the last items.
        // Casting to Array<unknown> works around TS error that
        // appears to come from trying to flatten a type CSSResultArray.
        const set = new Set(styles.flat(Infinity).reverse());
        // Then preserve original order by adding the set items in reverse order.
        for (const s of set) {
            elementStyles.unshift(getCompatibleStyle(s));
        }
    }
    else if (styles !== undefined) {
        elementStyles.push(getCompatibleStyle(styles));
    }
    return elementStyles;
}
//# sourceMappingURL=Themeable.js.map