import { CssNumber } from '@pixel-brewery/mosaik-themes';
import type { CustomElement } from '../components/abstracts/CustomElement';
import { Size } from '../types/Size';
import type { ControlBehaviorBase, ControlBehaviorReturn } from './abstracts/Behavior';
/**
 * Represents the `IGapable` interface.
 *
 * @public
 */
export interface IGapableProps {
    gap: CssNumber | Size;
}
/**
 * @public
 */
export declare const Gapable: <T extends ControlBehaviorBase<CustomElement>>(base: T) => ControlBehaviorReturn<T, IGapableProps>;
/**
 * @public
 */
export declare namespace IGapableProps {
    const DEFAULTS: IGapableProps;
}
//# sourceMappingURL=Gapable.d.ts.map