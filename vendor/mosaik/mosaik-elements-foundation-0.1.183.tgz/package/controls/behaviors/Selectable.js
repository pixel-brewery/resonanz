/* eslint-disable @typescript-eslint/naming-convention */
// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { HTMLElementEventEmitter } from '@pixel-brewery/mosaik-elements';
import { RendererServiceLocator } from '../../dom/Renderer';
import { Emit } from '../../events/decorators/EmitDecorator';
import { Attribute } from '../decorators/AttributeDecorator';
/**
 * @public
 */
export var ISelectableProps;
(function (ISelectableProps) {
    ISelectableProps.DEFAULTS = {
        isSelected: false
    };
})(ISelectableProps || (ISelectableProps = {}));
/**
 * A mixin that describes a selector behavior.
 *
 * @fires selected {SelectedEvent} - Fired when the `isSelected` property is `true`.
 * @fires deselected {DeselectedEvent} - Fired when the `isSelected` property is `false`.
 *
 * @public
 */
export const Selectable = (base) => {
    class SelectableElement extends base {
        // #region Fields
        _selected;
        _deselected;
        _isSelected;
        // #endregion
        // #region Ctor
        /**
         * Constructs a new instance of the `SelectableElement` class.
         *
         * @public
         */
        constructor(...args) {
            super(args);
            this._isSelected = ISelectableProps.DEFAULTS.isSelected;
            this._selected = new HTMLElementEventEmitter(this, 'selected');
            this._deselected = new HTMLElementEventEmitter(this, 'deselected');
        }
        // #endregion
        // #region Properties
        /**
         * Gets or sets the `isSelected` property.
         * The default value is `false`, which means the element is not selected.
         *
         * @public
         * @attr is-selected
         */
        get isSelected() {
            return this._isSelected;
        }
        set isSelected(value) {
            if (this.disabled) {
                return;
            }
            if (this._isSelected !== value) {
                this.onIsSelectedChanged(this._isSelected, value);
            }
        }
        /**
         * Called when the `isSelected` property is `true`.
         * Provides reference to the `IEventDetail` as event argument.
         *
         * @public
         * @eventProperty
         * @readonly
         */
        get selected() {
            return this._selected;
        }
        /**
         * Called when the `isSelected` property is `false`.
         * Provides reference to the `IEventDetail` as event argument.
         *
         * @public
         * @eventProperty
         * @readonly
         */
        get deselected() {
            return this._deselected;
        }
        // #endregion
        // #region Methods
        /**
         * Selects the element.
         *
         * @public
         */
        select() {
            if (this.disabled) {
                return;
            }
            if (this._isSelected) {
                return;
            }
            this.isSelected = true;
        }
        /**
         * Deselects the element.
         *
         * @public
         */
        deselect() {
            if (this.disabled) {
                return;
            }
            if (!this._isSelected) {
                return;
            }
            this.isSelected = false;
        }
        /**
         * This method is invoked when the `isSelected` property is changed.
         *
         * @protected
         * @virtual
         */
        onIsSelectedChanged(_prev, next) {
            this._isSelected = next;
            this.requestUpdate('isSelected');
            if (next) {
                RendererServiceLocator.current.setAttribute(this, 'aria-selected', 'true');
                this._selected.emit();
            }
            else {
                RendererServiceLocator.current.removeAttribute(this, 'aria-selected');
                this._deselected.emit();
            }
        }
    }
    __decorate([
        Attribute({
            type: Boolean,
            useDefault: true
        }),
        __metadata("design:type", Boolean),
        __metadata("design:paramtypes", [Boolean])
    ], SelectableElement.prototype, "isSelected", null);
    __decorate([
        Emit(),
        __metadata("design:type", Object),
        __metadata("design:paramtypes", [])
    ], SelectableElement.prototype, "selected", null);
    __decorate([
        Emit(),
        __metadata("design:type", Object),
        __metadata("design:paramtypes", [])
    ], SelectableElement.prototype, "deselected", null);
    return SelectableElement;
};
//# sourceMappingURL=Selectable.js.map