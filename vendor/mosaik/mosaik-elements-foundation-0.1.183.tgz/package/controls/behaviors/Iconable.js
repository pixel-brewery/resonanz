// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { IconSource } from '@pixel-brewery/mosaik-icons';
import { Attribute } from '../decorators/AttributeDecorator';
import { Property } from '../decorators/PropertyDecorator';
import { Watch } from '../decorators/WatchDecorator';
import { IconPosition } from '../types/IconPosition';
import { Size } from '../types/Size';
/**
 * @public
 */
export const Iconable = (base) => {
    class IconableElement extends base {
        // #region Fields
        _icon;
        _iconPosition;
        _iconSize;
        // #endregion
        // #region Ctor
        /**
         * Constructs a new instance of the `IconableElement` class.
         *
         * @public
         */
        constructor(...args) {
            super(args);
            this._icon = IIconableProps.DEFAULTS.icon;
            this._iconPosition = IIconableProps.DEFAULTS.iconPosition;
            this._iconSize = IIconableProps.DEFAULTS.iconSize;
        }
        // #endregion
        // #region Properties
        /**
         * Gets or sets the `icon` property.
         * The default value is an empty string, which means no icon is displayed.
         *
         * @public
         */
        get icon() {
            return this._icon;
        }
        set icon(value) {
            if (this._icon !== value) {
                this._icon = value;
                this.requestUpdate('icon');
            }
        }
        /**
         * Gets or sets the `iconPosition` property.
         * The default value is `before`, which means the icon is displayed before the content.
         *
         * @public
         * @attr icon-position
         */
        get iconPosition() {
            return this._iconPosition;
        }
        set iconPosition(value) {
            if (this._iconPosition !== value) {
                this._iconPosition = value;
                this.requestUpdate('iconPosition');
            }
        }
        /**
         * Gets or sets the `iconSize` property.
         * The default value is `null`, which means the icon size is not specified.
         *
         * @public
         * @attr icon-size
         */
        get iconSize() {
            return this._iconSize;
        }
        set iconSize(value) {
            if (this._iconSize !== value) {
                this._iconSize = value;
                this.requestUpdate('iconSize');
            }
        }
        // #endregion
        // #region Methods
        onIconPropertyChanged(_prev, next) {
            if (next) {
                this.setAttribute('has-icon', '');
            }
            else {
                this.removeAttribute('has-icon');
            }
        }
    }
    __decorate([
        Property({ type: String }),
        __metadata("design:type", Object),
        __metadata("design:paramtypes", [Object])
    ], IconableElement.prototype, "icon", null);
    __decorate([
        Attribute({ type: IconPosition }),
        __metadata("design:type", String),
        __metadata("design:paramtypes", [String])
    ], IconableElement.prototype, "iconPosition", null);
    __decorate([
        Attribute({ type: Size }),
        __metadata("design:type", Object),
        __metadata("design:paramtypes", [Object])
    ], IconableElement.prototype, "iconSize", null);
    __decorate([
        Watch('icon'),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object, Object]),
        __metadata("design:returntype", void 0)
    ], IconableElement.prototype, "onIconPropertyChanged", null);
    return IconableElement;
};
/**
 * @public
 */
export var IIconableProps;
(function (IIconableProps) {
    IIconableProps.DEFAULTS = {
        icon: '',
        iconSize: null,
        iconPosition: IconPosition.Before
    };
})(IIconableProps || (IIconableProps = {}));
//# sourceMappingURL=Iconable.js.map