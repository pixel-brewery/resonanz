/* eslint-disable @typescript-eslint/naming-convention */
// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { CssLength } from '@pixel-brewery/mosaik-themes';
import { Attribute } from '../decorators/AttributeDecorator';
import { Placement } from '../types/Placement';
import { Strategy } from '../types/Strategy';
/**
 * @public
 */
export var IDropDownableProps;
(function (IDropDownableProps) {
    IDropDownableProps.DEFAULTS = {
        dropDownPlacement: Placement.Bottom,
        dropDownStrategy: Strategy.Fixed,
        dropDownDistance: 8,
        dropDownSkidding: 0,
        dropDownStaysOpen: false,
        dropDownMaxHeight: '200px',
        dropDownHeight: 'auto',
        dropDownWidth: 'auto',
        dropDownMaxWidth: 'auto',
        isDropDownOpen: false
    };
})(IDropDownableProps || (IDropDownableProps = {}));
/**
 * @public
 */
export const DropDownable = (base) => {
    class DropDownableElement extends base {
        // #region Fields
        _dropDownPlacement;
        _dropDownStrategy;
        _dropDownDistance;
        _dropDownSkidding;
        _dropDownStaysOpen;
        _isDropDownOpen;
        _dropDownMaxHeight;
        _dropDownHeight;
        _dropDownWidth;
        _dropDownMaxWidth;
        // #endregion
        // #region Ctor
        /**
         * Constructs a new instance of the `DropDownableElement` class.
         *
         * @public
         */
        constructor(...args) {
            super(args);
            this._dropDownPlacement = IDropDownableProps.DEFAULTS.dropDownPlacement;
            this._dropDownStrategy = IDropDownableProps.DEFAULTS.dropDownStrategy;
            this._dropDownDistance = IDropDownableProps.DEFAULTS.dropDownDistance;
            this._dropDownSkidding = IDropDownableProps.DEFAULTS.dropDownSkidding;
            this._dropDownStaysOpen = IDropDownableProps.DEFAULTS.dropDownStaysOpen;
            this._isDropDownOpen = IDropDownableProps.DEFAULTS.isDropDownOpen;
            this._dropDownHeight = IDropDownableProps.DEFAULTS.dropDownHeight;
            this._dropDownMaxHeight = IDropDownableProps.DEFAULTS.dropDownMaxHeight;
            this._dropDownWidth = IDropDownableProps.DEFAULTS.dropDownWidth;
            this._dropDownMaxWidth = IDropDownableProps.DEFAULTS.dropDownMaxWidth;
        }
        // #endregion
        // #region Properties
        /**
         * Gets or sets the `dropDownPlacement` property.
         * The default value is `bottom`, which means the drop down appears below the element.
         *
         * @public
         * @attr drop-down-placement
         */
        get dropDownPlacement() {
            return this._dropDownPlacement;
        }
        set dropDownPlacement(value) {
            if (this._dropDownPlacement !== value) {
                this._dropDownPlacement = value;
                this.requestUpdate('dropDownPlacement');
            }
        }
        /**
         * Gets or sets the `dropDownStrategy` property.
         * The default value is `fixed`, which means the drop down is positioned relative to the viewport.
         *
         * @public
         * @attr drop-down-strategy
         */
        get dropDownStrategy() {
            return this._dropDownStrategy;
        }
        set dropDownStrategy(value) {
            if (this._dropDownStrategy !== value) {
                this._dropDownStrategy = value;
                this.requestUpdate('dropDownStrategy');
            }
        }
        /**
         * Gets or sets the `dropDownDistance` property.
         * The default value is `8`, which means the drop down appears 8 pixels away from the element.
         *
         * @public
         * @attr drop-down-distance
         */
        get dropDownDistance() {
            return this._dropDownDistance;
        }
        set dropDownDistance(value) {
            if (this._dropDownDistance !== value) {
                this._dropDownDistance = value;
                this.requestUpdate('dropDownDistance');
            }
        }
        /**
         * Gets or sets the `dropDownSkidding` property.
         * The default value is `0`, which means the drop down is aligned with the element.
         *
         * @public
         * @attr drop-down-skidding
         */
        get dropDownSkidding() {
            return this._dropDownSkidding;
        }
        set dropDownSkidding(value) {
            if (this._dropDownSkidding !== value) {
                this._dropDownSkidding = value;
                this.requestUpdate('dropDownSkidding');
            }
        }
        /**
         * Gets or sets the `dropDownStaysOpen` property.
         * The default value is `false`, which means the drop down closes when the user clicks outside of it.
         *
         * @public
         * @attr drop-down-stays-open
         */
        get dropDownStaysOpen() {
            return this._dropDownStaysOpen;
        }
        set dropDownStaysOpen(value) {
            if (this._dropDownStaysOpen !== value) {
                this._dropDownStaysOpen = value;
                this.requestUpdate('dropDownStaysOpen');
            }
        }
        /**
           * Gets or sets the `dropDownMaxHeight` property.
           *
           * @public
           * @attr drop-down-max-height
           */
        get dropDownMaxHeight() {
            return this._dropDownMaxHeight;
        }
        set dropDownMaxHeight(value) {
            if (this._dropDownMaxHeight !== value) {
                this._dropDownMaxHeight = value;
                this.requestUpdate('dropDownMaxHeight');
            }
        }
        /**
         * Gets or sets the `dropDownHeight` property.
         *
         * @public
         * @attr drop-down-height
         */
        get dropDownHeight() {
            return this._dropDownHeight;
        }
        set dropDownHeight(value) {
            if (this._dropDownHeight !== value) {
                this._dropDownHeight = value;
                this.requestUpdate('dropDownHeight');
            }
        }
        /**
         * Gets or sets the `dropDownWidth` property.
         *
         * @public
         * @attr drop-down-width
         */
        get dropDownWidth() {
            return this._dropDownWidth;
        }
        set dropDownWidth(value) {
            if (this._dropDownWidth !== value) {
                this._dropDownWidth = value;
                this.requestUpdate('dropDownWidth');
            }
        }
        /**
         * Gets or sets the `dropDownMaxWidth` property.
         *
         * @public
         * @attr drop-down-max-width
         */
        get dropDownMaxWidth() {
            return this._dropDownMaxWidth;
        }
        set dropDownMaxWidth(value) {
            if (this._dropDownMaxWidth !== value) {
                this._dropDownMaxWidth = value;
                this.requestUpdate('dropDownMaxWidth');
            }
        }
        /**
         * Gets or sets the `isDropDownOpen` property.
         *
         * @public
         * @attr is-drop-down-open
         */
        get isDropDownOpen() {
            return this._isDropDownOpen;
        }
        set isDropDownOpen(value) {
            if (this._isDropDownOpen !== value) {
                this._isDropDownOpen = value;
                this.requestUpdate('isDropDownOpen');
            }
        }
        // #endregion
        // #region Methods
        /**
         * @public
         */
        open() {
            if (this.disabled && this.isDropDownOpen) {
                return;
            }
            this.isDropDownOpen = true;
        }
        /**
         * @public
         */
        close() {
            if (this._dropDownStaysOpen || (this.disabled && !this.isDropDownOpen)) {
                return;
            }
            this.isDropDownOpen = false;
        }
        /**
         * @public
         */
        toggle() {
            if (this.disabled) {
                this.close();
                return;
            }
            if (this.isDropDownOpen) {
                this.close();
            }
            else {
                this.open();
            }
        }
    }
    __decorate([
        Attribute({ type: Placement }),
        __metadata("design:type", String),
        __metadata("design:paramtypes", [String])
    ], DropDownableElement.prototype, "dropDownPlacement", null);
    __decorate([
        Attribute({ type: Strategy }),
        __metadata("design:type", String),
        __metadata("design:paramtypes", [String])
    ], DropDownableElement.prototype, "dropDownStrategy", null);
    __decorate([
        Attribute({ type: Number }),
        __metadata("design:type", Number),
        __metadata("design:paramtypes", [Number])
    ], DropDownableElement.prototype, "dropDownDistance", null);
    __decorate([
        Attribute({ type: Number }),
        __metadata("design:type", Number),
        __metadata("design:paramtypes", [Number])
    ], DropDownableElement.prototype, "dropDownSkidding", null);
    __decorate([
        Attribute({
            type: Boolean,
            useDefault: true
        }),
        __metadata("design:type", Boolean),
        __metadata("design:paramtypes", [Boolean])
    ], DropDownableElement.prototype, "dropDownStaysOpen", null);
    __decorate([
        Attribute({ type: String }),
        __metadata("design:type", Object),
        __metadata("design:paramtypes", [Object])
    ], DropDownableElement.prototype, "dropDownMaxHeight", null);
    __decorate([
        Attribute({ type: String }),
        __metadata("design:type", Object),
        __metadata("design:paramtypes", [Object])
    ], DropDownableElement.prototype, "dropDownHeight", null);
    __decorate([
        Attribute({ type: String }),
        __metadata("design:type", Object),
        __metadata("design:paramtypes", [Object])
    ], DropDownableElement.prototype, "dropDownWidth", null);
    __decorate([
        Attribute({ type: String }),
        __metadata("design:type", Object),
        __metadata("design:paramtypes", [Object])
    ], DropDownableElement.prototype, "dropDownMaxWidth", null);
    __decorate([
        Attribute({
            type: Boolean,
            useDefault: true
        }),
        __metadata("design:type", Boolean),
        __metadata("design:paramtypes", [Boolean])
    ], DropDownableElement.prototype, "isDropDownOpen", null);
    return DropDownableElement;
};
//# sourceMappingURL=DropDownable.js.map