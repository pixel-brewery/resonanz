/* eslint-disable @typescript-eslint/naming-convention */
// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Attribute } from '../decorators/AttributeDecorator';
/**
 * @public
 */
export const Rangeable = (base) => {
    class RangeableElement extends base {
        // #region Fields
        _min;
        _max;
        // #endregion
        // #region Ctor
        /**
         * Constructs a new instance of the `RangeableElement` class.
         *
         * @public
         */
        constructor(...args) {
            super(args);
            this._min = undefined;
            this._max = undefined;
        }
        // #endregion
        // #region Properties
        /**
         * The minimum value of the range.
         * This property is used to define the lower bound of the range.
         * The default value is `undefined`, which means no minimum value is set.
         * The concrete control owns native or role-specific accessibility bounds.
         *
         * @public
         * @attr min
         */
        get min() {
            return this._min;
        }
        set min(value) {
            if (this._min !== value) {
                this._min = value;
                this.requestUpdate('min');
            }
        }
        /**
         * The maximum value of the range.
         * This property is used to define the upper bound of the range.
         * The default value is `undefined`, which means no maximum value is set.
         * The concrete control owns native or role-specific accessibility bounds.
         *
         * @public
         * @attr max
         */
        get max() {
            return this._max;
        }
        set max(value) {
            if (this._max !== value) {
                this._max = value;
                this.requestUpdate('max');
            }
        }
    }
    __decorate([
        Attribute({ type: Object }),
        __metadata("design:type", Object),
        __metadata("design:paramtypes", [Object])
    ], RangeableElement.prototype, "min", null);
    __decorate([
        Attribute({ type: Object }),
        __metadata("design:type", Object),
        __metadata("design:paramtypes", [Object])
    ], RangeableElement.prototype, "max", null);
    return RangeableElement;
};
//# sourceMappingURL=Rangeable.js.map