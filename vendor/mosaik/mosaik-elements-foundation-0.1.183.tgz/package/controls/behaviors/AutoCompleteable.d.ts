import { IEventDetail, IEventEmitter } from '@pixel-brewery/mosaik-elements';
import type { CustomElement } from '../components/abstracts/CustomElement';
import { AutoCompleteTextSearchMode } from '../types/AutoCompleteTextSearchMode';
import type { IItemsProviderRequest, ItemsProviderFn } from '../types/ItemsProvider';
import type { ControlBehaviorBase, ControlBehaviorReturn } from './abstracts/Behavior';
/**
 * Represents the events of the `AutoCompletable` mixin.
 *
 * @public
 */
export interface IAutoCompletableEvents {
    populating: IEventEmitter<IAutoCompletePopulatingEventDetail>;
    populated: IEventEmitter<IAutoCompletePopulatedEventDetail>;
    itemSelected: IEventEmitter<IAutoCompleteItemSelectedEventDetail>;
}
/**
 * Represents the `IAutoCompletable` interface.
 *
 * @public
 */
export interface IAutoCompletable {
    filteredItems: Array<unknown>;
    isPopulating: boolean;
    onFilterCallback?(items: Array<unknown>): void;
    onSelectCallback?(item: unknown): void;
    getDisplayValue(item: unknown): string;
    getItemValue(item: unknown): string;
    updateSearchText(searchText: string): void;
    updateSelectedItem(item: unknown): void;
}
/**
 * Describes the detail payload for the populating event.
 *
 * @public
 */
export interface IAutoCompletePopulatingEventDetail extends IEventDetail {
    searchText: string;
    requestId: number;
    signal: AbortSignal;
}
/**
 * Describes the detail payload for the populated event.
 *
 * @public
 */
export interface IAutoCompletePopulatedEventDetail extends IEventDetail {
    searchText: string;
    items: Array<unknown>;
    requestId: number;
}
/**
 * Describes the detail payload for the itemSelected event.
 *
 * @public
 */
export interface IAutoCompleteItemSelectedEventDetail extends IEventDetail {
    /**
     * The selected item.
     */
    item: unknown;
    /**
     * The display value of the selected item.
     */
    displayValue: string;
    /**
     * The value of the selected item (based on valueMemberPath).
     */
    value: string;
}
/**
 * Describes the context passed to asynchronous suggestion providers.
 *
 * @remarks
 * Extends the simplified `IItemsProviderRequest` with internal tracking properties.
 * External providers should only use `searchText` and `signal` from `IItemsProviderRequest`.
 *
 * @public
 */
export interface IAutoCompleteItemsRequestContext extends IItemsProviderRequest {
}
/**
 * Represents a delegate that resolves suggestion items.
 *
 * @remarks
 * This is an alias for `ItemsProviderFn` for backward compatibility.
 * New code should use `ItemsProviderFn` directly.
 *
 * @deprecated Use `ItemsProviderFn` instead.
 * @public
 */
export type AutoCompleteItemsProvider = ItemsProviderFn;
/**
 * Represents the `IAutoCompleteableProps` interface.
 *
 * @public
 */
export interface IAutoCompleteableProps {
    minimumPrefixLength: number;
    minimumPopulateDelay: number;
    isTextCompletionEnabled: boolean;
    searchMode: AutoCompleteTextSearchMode;
    displayMemberPath: string;
    valueMemberPath: string;
    items: Array<unknown>;
    itemsProvider: ItemsProviderFn | null;
}
/**
 * @public
 */
export declare const AutoCompleteable: <T extends ControlBehaviorBase<CustomElement>>(base: T) => ControlBehaviorReturn<T, IAutoCompleteableProps & IAutoCompletableEvents & IAutoCompletable>;
/**
 * @public
 */
export declare namespace IAutoCompleteableProps {
    const DEFAULTS: IAutoCompleteableProps;
}
//# sourceMappingURL=AutoCompleteable.d.ts.map