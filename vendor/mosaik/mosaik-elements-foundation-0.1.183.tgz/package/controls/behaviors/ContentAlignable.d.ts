import type { CustomElement } from '../components/abstracts/CustomElement';
import { HorizontalAlignment } from '../types/HorizontalAlignment';
import { VerticalAlignment } from '../types/VerticalAlignment';
import type { ControlBehaviorBase, ControlBehaviorReturn } from './abstracts/Behavior';
/**
 * Represents the `IContentAlignableProps` interface.
 *
 * @public
 */
export interface IContentAlignableProps {
    verticalContentAlignment: VerticalAlignment;
    horizontalContentAlignment: HorizontalAlignment;
}
/**
 * @public
 */
export declare const ContentAlignable: <T extends ControlBehaviorBase<CustomElement>>(base: T) => ControlBehaviorReturn<T, IContentAlignableProps>;
/**
 * @public
 */
export declare namespace IContentAlignableProps {
    const DEFAULTS: IContentAlignableProps;
}
//# sourceMappingURL=ContentAlignable.d.ts.map