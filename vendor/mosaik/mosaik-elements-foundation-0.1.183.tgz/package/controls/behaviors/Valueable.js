/* eslint-disable @typescript-eslint/naming-convention */
// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Attribute } from '../decorators/AttributeDecorator';
/**
 * @public
 */
export const Valueable = (base) => {
    class ValueableElement extends base {
        // #region Fields
        _value;
        // #endregion
        // #region Ctor
        /**
         * Constructs a new instance of the `ValueableElement` class.
         *
         * @public
         */
        constructor(...args) {
            super(args);
            this._value = IValueableProps.DEFAULTS.value;
        }
        // #endregion
        // #region Properties
        /**
         * Gets or sets the `value` property.
         * The default value is `undefined`, which means the element has no value set.
         * The attribute is read as JSON when it is valid JSON (`value="2"` is the number `2`,
         * `value="true"` the boolean) and as the plain string otherwise (`value="left"`).
         * Accessibility values belong to the concrete control's native input or range semantics;
         * arbitrary values are not reflected as ARIA attributes.
         *
         * @public
         * @attr value
         */
        get value() {
            return this._value;
        }
        set value(value) {
            if (this._value !== value) {
                this._value = value;
                this.requestUpdate('value');
            }
        }
    }
    __decorate([
        Attribute({
            type: Object,
            converter: {
                fromAttribute: (value) => {
                    if (value === null) {
                        return null;
                    }
                    try {
                        return JSON.parse(value);
                    }
                    catch {
                        return value;
                    }
                },
                toAttribute: (value) => String(value)
            }
        }),
        __metadata("design:type", Object),
        __metadata("design:paramtypes", [Object])
    ], ValueableElement.prototype, "value", null);
    return ValueableElement;
};
/**
 * @public
 */
export var IValueableProps;
(function (IValueableProps) {
    IValueableProps.DEFAULTS = {
        value: undefined
    };
})(IValueableProps || (IValueableProps = {}));
//# sourceMappingURL=Valueable.js.map