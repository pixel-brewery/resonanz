import type { CustomElement } from '../components/abstracts/CustomElement';
import { ElevationWeight } from '../types/ElevationWeight';
import type { ControlBehaviorBase, ControlBehaviorReturn } from './abstracts/Behavior';
/**
 * Represents the `IElevatable` interface.
 *
 * @public
 */
export interface IElevatableProps {
    elevation: ElevationWeight;
}
/**
 * @public
 */
export declare const Elevatable: <T extends ControlBehaviorBase<CustomElement>>(base: T) => ControlBehaviorReturn<T, IElevatableProps>;
/**
 * @public
 */
export declare namespace IElevatableProps {
    const DEFAULTS: IElevatableProps;
}
//# sourceMappingURL=Elevatable.d.ts.map