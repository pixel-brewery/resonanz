/* eslint-disable @typescript-eslint/naming-convention */
// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Attribute } from '../decorators/AttributeDecorator';
import { HorizontalAlignment } from '../types/HorizontalAlignment';
import { VerticalAlignment } from '../types/VerticalAlignment';
/**
 * @public
 */
export const ContentAlignable = (base) => {
    class ContentAlignableElement extends base {
        // #region Fields
        _horizontalContentAlignment;
        _verticalContentAlignment;
        // #endregion
        // #region Ctor
        /**
         * Constructs a new instance of the `ContentAlignableElement` class.
         *
         * @public
         */
        constructor(...args) {
            super(args);
            this._horizontalContentAlignment = IContentAlignableProps.DEFAULTS.horizontalContentAlignment;
            this._verticalContentAlignment = IContentAlignableProps.DEFAULTS.verticalContentAlignment;
        }
        // #endregion
        // #region Properties
        /**
         * A property that supports adjusting the horizontal alignment of its content.
         * The default value is `center`, which means the content is centered horizontally.
         *
         * @public
         * @attr horizontal-content-alignment
         */
        get horizontalContentAlignment() {
            return this._horizontalContentAlignment;
        }
        set horizontalContentAlignment(value) {
            if (this._horizontalContentAlignment !== value) {
                this._horizontalContentAlignment = value;
                this.requestUpdate('horizontalContentAlignment');
            }
        }
        /**
         * A property that supports adjusting the vertical alignment of its content.
         * The default value is `center`, which means the content is centered vertically.
         *
         * @public
         * @attr vertical-content-alignment
         */
        get verticalContentAlignment() {
            return this._verticalContentAlignment;
        }
        set verticalContentAlignment(value) {
            if (this._verticalContentAlignment !== value) {
                this._verticalContentAlignment = value;
                this.requestUpdate('verticalContentAlignment');
            }
        }
    }
    __decorate([
        Attribute({ type: HorizontalAlignment }),
        __metadata("design:type", String),
        __metadata("design:paramtypes", [String])
    ], ContentAlignableElement.prototype, "horizontalContentAlignment", null);
    __decorate([
        Attribute({ type: VerticalAlignment }),
        __metadata("design:type", String),
        __metadata("design:paramtypes", [String])
    ], ContentAlignableElement.prototype, "verticalContentAlignment", null);
    return ContentAlignableElement;
};
/**
 * @public
 */
export var IContentAlignableProps;
(function (IContentAlignableProps) {
    IContentAlignableProps.DEFAULTS = {
        horizontalContentAlignment: HorizontalAlignment.Center,
        verticalContentAlignment: VerticalAlignment.Center
    };
})(IContentAlignableProps || (IContentAlignableProps = {}));
//# sourceMappingURL=ContentAlignable.js.map