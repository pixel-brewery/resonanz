import { CssLength } from '@pixel-brewery/mosaik-themes';
import type { CustomElement } from '../components/abstracts/CustomElement';
import type { ControlBehaviorBase, ControlBehaviorReturn } from './abstracts/Behavior';
/**
 * Represents the `IDimensionable` interface.
 *
 * @public
 */
export interface IDimensionableProps {
    width: CssLength;
    height: CssLength;
}
/**
 * @public
 */
export declare const Dimensionable: <T extends ControlBehaviorBase<CustomElement>>(base: T) => ControlBehaviorReturn<T, IDimensionableProps>;
/**
 * @public
 */
export declare namespace IDimensionableProps {
    const DEFAULTS: IDimensionableProps;
}
//# sourceMappingURL=Dimensionable.d.ts.map