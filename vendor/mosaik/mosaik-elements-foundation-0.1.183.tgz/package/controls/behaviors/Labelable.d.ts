import type { CustomElement } from '../components/abstracts/CustomElement';
import type { ControlBehaviorBase, ControlBehaviorReturn } from './abstracts/Behavior';
/**
 * Represents the `ILabelable` interface.
 *
 * @public
 */
export interface ILabelableProps {
    label: string;
}
/**
 * @public
 */
export declare const Labelable: <T extends ControlBehaviorBase<CustomElement>>(base: T) => ControlBehaviorReturn<T, ILabelableProps>;
/**
 * @public
 */
export declare namespace ILabelableProps {
    const DEFAULTS: ILabelableProps;
}
//# sourceMappingURL=Labelable.d.ts.map