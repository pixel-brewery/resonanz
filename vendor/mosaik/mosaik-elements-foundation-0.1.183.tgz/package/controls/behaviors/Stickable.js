/* eslint-disable @typescript-eslint/naming-convention */
// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { RendererServiceLocator } from '../../dom/Renderer';
import { Attribute } from '../decorators/AttributeDecorator';
import { Watch } from '../decorators/WatchDecorator';
/**
 * @public
 */
export const Stickable = (base) => {
    class StickableElement extends base {
        // #region Fields
        _isSticky;
        // #endregion
        // #region Ctor
        /**
         * Constructs a new instance of the `StickableElement` class.
         *
         * @public
         */
        constructor(...args) {
            super(args);
            this._isSticky = IStickableProps.DEFAULTS.isSticky;
        }
        // #endregion
        // #region Properties
        /**
         * The `isSticky` property indicates whether the element is sticky or not.
         * The default value is `false`, which means the element is not sticky.
         *
         * @public
         * @attr is-sticky
         */
        get isSticky() {
            return this._isSticky;
        }
        set isSticky(value) {
            if (this._isSticky !== value) {
                this._isSticky = value;
                this.requestUpdate('isSticky');
            }
        }
        // #endregion
        // #region Methods
        /**
         * @protected
         */
        onIsStickyChanged(prev, next) {
            if (prev !== next) {
                if (next) {
                    RendererServiceLocator.current.addClass(this, 'sticky');
                }
            }
            if (!next) {
                RendererServiceLocator.current.removeClass(this, 'sticky');
            }
        }
    }
    __decorate([
        Attribute({
            type: Boolean,
            useDefault: true
        }),
        __metadata("design:type", Boolean),
        __metadata("design:paramtypes", [Boolean])
    ], StickableElement.prototype, "isSticky", null);
    __decorate([
        Watch('isSticky'),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Boolean, Boolean]),
        __metadata("design:returntype", void 0)
    ], StickableElement.prototype, "onIsStickyChanged", null);
    return StickableElement;
};
/**
 * @public
 */
export var IStickableProps;
(function (IStickableProps) {
    IStickableProps.DEFAULTS = {
        isSticky: false
    };
})(IStickableProps || (IStickableProps = {}));
//# sourceMappingURL=Stickable.js.map