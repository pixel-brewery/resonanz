import type { IAnimationReferenceMetadata } from '../../animations/IAnimationReferenceMetadata';
import type { CustomElement } from '../components/abstracts/CustomElement';
import type { ControlBehaviorBase, ControlBehaviorReturn } from './abstracts/Behavior';
/**
 * Represents the `IAnimatableProps` interface.
 *
 * @public
 */
export interface IAnimatableProps {
    enter: IAnimationReferenceMetadata | null;
    exit: IAnimationReferenceMetadata | null;
}
/**
 * Represents the `IAnimatable` interface.
 *
 * @public
 */
export interface IAnimatable {
    /**
     * Gets the target element for animations.
     * Override this to animate a different element than the host (e.g., a template part).
     *
     * @returns The element to animate, defaults to the host element.
     * @optional
     */
    readonly animationTarget?: HTMLElement;
    /**
     * Executes the animation.
     *
     * @param animation - The animation to execute.
     */
    play(animation: IAnimationReferenceMetadata): Promise<boolean>;
    /**
     * A lifecycle hook that is invoked when the element is added to the DOM.
     *
     * @optional
     */
    onEnterAnimation?(): Promise<boolean>;
    /**
     * A lifecycle hook that is invoked when the element is removed from the DOM.
     *
     * @optional
     */
    onExitAnimation?(): Promise<boolean>;
}
/**
 * @public
 */
export declare const Animatable: <T extends ControlBehaviorBase<CustomElement>>(base: T) => ControlBehaviorReturn<T, IAnimatableProps & IAnimatable>;
/**
 * @public
 */
export declare namespace IAnimatableProps {
    const DEFAULTS: IAnimatableProps;
}
//# sourceMappingURL=Animatable.d.ts.map