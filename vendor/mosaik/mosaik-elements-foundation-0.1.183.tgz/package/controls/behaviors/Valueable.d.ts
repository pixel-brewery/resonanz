import type { CustomElement } from '../components/abstracts/CustomElement';
import type { ControlBehaviorBase, ControlBehaviorReturn } from './abstracts/Behavior';
/**
 * Represents the `IValueable` interface.
 *
 * @template TType - The type of the value.
 * @public
 */
export interface IValueableProps<TType = unknown> {
    value: TType;
}
/**
 * @public
 */
export declare const Valueable: <TType, T extends ControlBehaviorBase<CustomElement>>(base: T) => ControlBehaviorReturn<T, IValueableProps<TType>>;
/**
 * @public
 */
export declare namespace IValueableProps {
    const DEFAULTS: IValueableProps;
}
//# sourceMappingURL=Valueable.d.ts.map