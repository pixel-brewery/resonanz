import type { CustomElement } from '../components/abstracts/CustomElement';
import type { ControlBehaviorBase, ControlBehaviorReturn } from './abstracts/Behavior';
/**
 * Represents the `ILocaleable` interface.
 *
 * @public
 */
export interface ILocaleableProps {
    locale: string;
}
/**
 * @public
 */
export declare const Localeable: <T extends ControlBehaviorBase<CustomElement>>(base: T) => ControlBehaviorReturn<T, ILocaleableProps>;
/**
 * @public
 */
export declare namespace ILocaleableProps {
    const DEFAULTS: ILocaleableProps;
}
//# sourceMappingURL=Localeable.d.ts.map