import type { CustomElement } from '../components/abstracts/CustomElement';
import { type TextFormatter } from '../types/TextFormatter';
import type { ControlBehaviorBase, ControlBehaviorReturn } from './abstracts/Behavior';
/**
 * Represents the `ITextFormattableProps` interface.
 *
 * @public
 */
export interface ITextFormattableProps {
    formatter: TextFormatter | null;
}
/**
 * @public
 */
export declare const TextFormattable: <T extends ControlBehaviorBase<CustomElement>>(base: T) => ControlBehaviorReturn<T, ITextFormattableProps>;
/**
 * @public
 */
export declare namespace ITextFormattableProps {
    const DEFAULTS: ITextFormattableProps;
}
//# sourceMappingURL=TextFormattable.d.ts.map