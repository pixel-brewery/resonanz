import type { CustomElement } from '../components/abstracts/CustomElement';
import type { ControlBehaviorBase, ControlBehaviorReturn } from './abstracts/Behavior';
/**
 * Represents the `IRangeable` interface.
 *
 * @template TType - The type of the range.
 * @public
 */
export interface IRangeableProps<TType> {
    min: TType;
    max: TType;
}
/**
 * @public
 */
export declare const Rangeable: <TType = unknown>(base: ControlBehaviorBase<CustomElement>) => ControlBehaviorReturn<ControlBehaviorBase<CustomElement>, IRangeableProps<TType>>;
//# sourceMappingURL=Rangeable.d.ts.map