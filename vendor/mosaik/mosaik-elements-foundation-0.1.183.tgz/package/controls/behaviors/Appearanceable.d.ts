import type { CustomElement } from '../components/abstracts/CustomElement';
import { Appearance } from '../types/Appearance';
import type { ControlBehaviorBase, ControlBehaviorReturn } from './abstracts/Behavior';
/**
 * Represents the `IAppearanceableElementProps` interface.
 *
 * @public
 */
export interface IAppearanceableProps {
    appearance: Appearance;
}
/**
 * @public
 */
export declare const Appearanceable: <T extends ControlBehaviorBase<CustomElement>>(base: T) => ControlBehaviorReturn<T, IAppearanceableProps>;
/**
 * @public
 */
export declare namespace IAppearanceableProps {
    const DEFAULTS: IAppearanceableProps;
}
//# sourceMappingURL=Appearanceable.d.ts.map