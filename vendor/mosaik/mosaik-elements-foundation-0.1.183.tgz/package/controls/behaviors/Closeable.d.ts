import { ICancelEventDetail, IEventEmitter } from '@pixel-brewery/mosaik-elements';
import type { CustomElement } from '../components/abstracts/CustomElement';
import type { ControlBehaviorBase, ControlBehaviorReturn } from './abstracts/Behavior';
/**
 * @public
 */
export interface ICloseable {
    /**
     * Removes the element from the DOM.
     */
    close(): Promise<boolean>;
}
/**
 * Represents the events of the `Closeable` mixin.
 *
 * @public
 */
export interface ICloseableEvents {
    closed: IEventEmitter<ICancelEventDetail>;
}
/**
 * Represents the `ICloseableElementProps` interface.
 *
 * @public
 */
export interface ICloseableProps {
    closeable: boolean;
}
/**
 * @public
 */
export declare namespace ICloseableProps {
    const DEFAULTS: ICloseableProps;
}
/**
 * @fires closed {ClosedEvent} - Fired when the `close` method is called.
 *
 * @public
 *
 */
export declare const Closeable: <T extends ControlBehaviorBase<CustomElement>>(base: T) => ControlBehaviorReturn<T, ICloseableProps & ICloseableEvents & ICloseable>;
//# sourceMappingURL=Closeable.d.ts.map