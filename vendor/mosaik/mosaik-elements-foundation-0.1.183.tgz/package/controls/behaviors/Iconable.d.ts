import { IconSource } from '@pixel-brewery/mosaik-icons';
import type { CustomElement } from '../components/abstracts/CustomElement';
import { IconPosition } from '../types/IconPosition';
import { Size } from '../types/Size';
import type { ControlBehaviorBase, ControlBehaviorReturn } from './abstracts/Behavior';
/**
 * Represents the `IIconable` interface.
 *
 * @public
 */
export interface IIconableProps {
    icon: IconSource;
    iconSize: Size | null;
    iconPosition: IconPosition;
}
/**
 * @public
 */
export declare const Iconable: <T extends ControlBehaviorBase<CustomElement>>(base: T) => ControlBehaviorReturn<T, IIconableProps>;
/**
 * @public
 */
export declare namespace IIconableProps {
    const DEFAULTS: IIconableProps;
}
//# sourceMappingURL=Iconable.d.ts.map