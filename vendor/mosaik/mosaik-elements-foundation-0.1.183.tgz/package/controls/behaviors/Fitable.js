/* eslint-disable @typescript-eslint/naming-convention */
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
// #region Imports
import { css } from '../../dom/Css';
import { Attribute } from '../decorators/AttributeDecorator';
import { Fit } from '../types/Fit';
/**
 * @public
 */
export const Fitable = (base) => {
    class FitableElement extends base {
        // #region Fields
        _fit;
        // #endregion
        // #region Ctor
        /**
         * Constructs a new instance of the `FitableElement` class.
         *
         * @public
         */
        constructor(...args) {
            super(args);
            this._fit = IFitableProps.DEFAULTS.fit;
        }
        // #endregion
        // #region Properties
        /**
         * Returns the `styles` property.
         * The default value is an empty array, which means no styles are applied.
         *
         * @public
         * @readonly
         */
        static get styles() {
            return [
                base.styles ?? [],
                css `
                    :host([fit='width']) {
                        width: 100%;
                    }

                    :host([fit='height']) {
                        height: 100%;
                    }

                    :host([fit='both']) {
                        width: 100%;
                        height: 100%;
                    }
                `
            ];
        }
        /**
         * Gets or sets a value indicating whether this element is displayed in the UI.
         * The default value is `none`, which means the element is not displayed.
         *
         * @public
         * @attr fit
         */
        get fit() {
            return this._fit;
        }
        set fit(value) {
            if (this._fit !== value) {
                this._fit = value;
                this.requestUpdate('fit');
            }
        }
    }
    __decorate([
        Attribute({ type: Fit }),
        __metadata("design:type", String),
        __metadata("design:paramtypes", [String])
    ], FitableElement.prototype, "fit", null);
    return FitableElement;
};
/**
 * @public
 */
export var IFitableProps;
(function (IFitableProps) {
    IFitableProps.DEFAULTS = {
        fit: Fit.None
    };
})(IFitableProps || (IFitableProps = {}));
//# sourceMappingURL=Fitable.js.map