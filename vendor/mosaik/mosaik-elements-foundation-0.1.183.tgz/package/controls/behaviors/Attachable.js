/* eslint-disable @typescript-eslint/naming-convention */
// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Attribute } from '../decorators/AttributeDecorator';
/**
 * @public
 */
export const Attachable = (base) => {
    class AttachableElement extends base {
        // #region Fields
        _for;
        _control;
        // #endregion
        // #region Ctor
        /**
         * Constructs a new instance of the `AttachableElement` class.
         *
         * @public
         */
        constructor(...args) {
            super(args);
            this._for = IAttachableProps.DEFAULTS.for;
            this._control = null;
        }
        // #endregion
        // #region Properties
        /**
         * Gets or sets the `for` property.
         * The `for` property reflects the value of the `for` attribute, which is the ID of the element's associated control.
         *
         * @public
         * @attr for
         */
        get for() {
            return this._for;
        }
        set for(value) {
            if (this._for !== value) {
                this._for = value;
                this.requestUpdate('for');
            }
        }
        /**
         * @private
         * @readonly
         */
        get control() {
            if (this._control) {
                return this._control;
            }
            if (this.hasAttribute('for')) {
                if (!this.for || !this.isConnected) {
                    return null;
                }
                return this.getRootNode().querySelector(`#${this._for}`);
            }
            return this.parentElement;
        }
        // #endregion
        // #region Methods
        /**
         * @public
         * @param control - The control or id to attach.
         */
        attach(control) {
            if (typeof control === 'string') {
                const x = this.getRootNode().querySelector(`#${control}`);
                if (!x) {
                    throw new Error(`Element with id '${control}' not found.`);
                }
                this._control = x;
            }
            else {
                this._control = control;
            }
        }
        /**
         * @public
         */
        detach() {
            this._control = null;
        }
    }
    __decorate([
        Attribute({ type: String }),
        __metadata("design:type", Object),
        __metadata("design:paramtypes", [Object])
    ], AttachableElement.prototype, "for", null);
    return AttachableElement;
};
/**
 * @public
 */
export var IAttachableProps;
(function (IAttachableProps) {
    IAttachableProps.DEFAULTS = {
        for: null
    };
})(IAttachableProps || (IAttachableProps = {}));
//# sourceMappingURL=Attachable.js.map