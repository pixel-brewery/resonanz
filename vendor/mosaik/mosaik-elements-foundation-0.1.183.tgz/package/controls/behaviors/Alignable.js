/* eslint-disable @typescript-eslint/naming-convention */
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Attribute } from '../decorators/AttributeDecorator';
import { HorizontalAlignment } from '../types/HorizontalAlignment';
import { VerticalAlignment } from '../types/VerticalAlignment';
/**
 * @public
 */
export const Alignable = (base) => {
    class AlignableElement extends base {
        // #region Fields
        _horizontalAlignment;
        _verticalAlignment;
        // #endregion
        // #region Ctor
        /**
         * Constructs a new instance of the `AlignableElement` class.
         *
         * @public
         */
        constructor(...args) {
            super(args);
            this._horizontalAlignment = IAlignableProps.DEFAULTS.horizontalAlignment;
            this._verticalAlignment = IAlignableProps.DEFAULTS.verticalAlignment;
        }
        // #endregion
        // #region Properties
        /**
         * Gets or sets the `horizontalAlignment` property.
         * The default value is `stretch`.
         *
         * @public
         * @attr horizontal-alignment
         */
        get horizontalAlignment() {
            return this._horizontalAlignment;
        }
        set horizontalAlignment(value) {
            if (this._horizontalAlignment !== value) {
                this._horizontalAlignment = value;
                this.requestUpdate('horizontalAlignment');
            }
        }
        /**
         * Gets or sets the `verticalAlignment` property.
         * The default value is `stretch`.
         *
         * @public
         * @attr vertical-alignment
         */
        get verticalAlignment() {
            return this._verticalAlignment;
        }
        set verticalAlignment(value) {
            if (this._verticalAlignment !== value) {
                this._verticalAlignment = value;
                this.requestUpdate('verticalAlignment');
            }
        }
    }
    __decorate([
        Attribute({ type: HorizontalAlignment }),
        __metadata("design:type", String),
        __metadata("design:paramtypes", [String])
    ], AlignableElement.prototype, "horizontalAlignment", null);
    __decorate([
        Attribute({ type: VerticalAlignment }),
        __metadata("design:type", String),
        __metadata("design:paramtypes", [String])
    ], AlignableElement.prototype, "verticalAlignment", null);
    return AlignableElement;
};
/**
 * @public
 */
export var IAlignableProps;
(function (IAlignableProps) {
    IAlignableProps.DEFAULTS = {
        horizontalAlignment: HorizontalAlignment.Stretch,
        verticalAlignment: VerticalAlignment.Stretch
    };
})(IAlignableProps || (IAlignableProps = {}));
//# sourceMappingURL=Alignable.js.map