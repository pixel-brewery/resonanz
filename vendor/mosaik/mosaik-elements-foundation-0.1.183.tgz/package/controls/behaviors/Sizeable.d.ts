import type { CustomElement } from '../components/abstracts/CustomElement';
import { Size } from '../types/Size';
import type { ControlBehaviorBase, ControlBehaviorReturn } from './abstracts/Behavior';
/**
 * Represents the `ISizeable` interface.
 *
 * @public
 */
export interface ISizeableProps {
    size: Size;
}
/**
 * @public
 */
export declare const Sizeable: <T extends ControlBehaviorBase<CustomElement>>(base: T) => ControlBehaviorReturn<T, ISizeableProps>;
/**
 * @public
 */
export declare namespace ISizeableProps {
    const DEFAULTS: ISizeableProps;
}
//# sourceMappingURL=Sizeable.d.ts.map