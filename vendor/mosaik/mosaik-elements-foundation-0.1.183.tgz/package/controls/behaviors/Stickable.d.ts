import type { CustomElement } from '../components/abstracts/CustomElement';
import type { ControlBehaviorBase, ControlBehaviorReturn } from './abstracts/Behavior';
/**
 * Represents the `IStickable` interface.
 *
 * @public
 */
export interface IStickableProps {
    isSticky: boolean;
}
/**
 * @public
 */
export declare const Stickable: <T extends ControlBehaviorBase<CustomElement>>(base: T) => ControlBehaviorReturn<T, IStickableProps>;
/**
 * @public
 */
export declare namespace IStickableProps {
    const DEFAULTS: IStickableProps;
}
//# sourceMappingURL=Stickable.d.ts.map