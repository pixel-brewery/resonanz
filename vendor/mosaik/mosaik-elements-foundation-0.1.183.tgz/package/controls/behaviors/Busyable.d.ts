import type { CustomElement } from '../components/abstracts/CustomElement';
import type { ControlBehaviorBase, ControlBehaviorReturn } from './abstracts/Behavior';
/**
 * Represents the `IBusyableProps` interface.
 *
 * @public
 */
export interface IBusyableProps {
    isBusy: boolean;
}
/**
 * @public
 */
export declare const Busyable: <T extends ControlBehaviorBase<CustomElement>>(base: T) => ControlBehaviorReturn<T, IBusyableProps>;
/**
 * @public
 */
export declare namespace IBusyableProps {
    const DEFAULTS: IBusyableProps;
}
//# sourceMappingURL=Busyable.d.ts.map