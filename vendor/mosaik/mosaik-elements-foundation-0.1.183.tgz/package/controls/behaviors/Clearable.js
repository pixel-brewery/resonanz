/* eslint-disable @typescript-eslint/naming-convention */
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
// #region Imports
import { HTMLElementEventEmitter } from '@pixel-brewery/mosaik-elements';
import { RendererServiceLocator } from '../../dom/Renderer';
import { Emit } from '../../events/decorators/EmitDecorator';
import { Attribute } from '../decorators/AttributeDecorator';
import { Disableable } from './Disableable';
import { Valueable } from './Valueable';
/**
 * @public
 */
export var IClearableProps;
(function (IClearableProps) {
    IClearableProps.DEFAULTS = {
        isClearable: false
    };
})(IClearableProps || (IClearableProps = {}));
/**
 * @fires cleared {ClearedEvent} - Fires when the `clear` method is called.
 *
 * @public
 */
export const Clearable = (base) => {
    class ClearableElement extends Valueable(Disableable(base)) {
        // #region Fields
        _cleared;
        _isClearable;
        // #endregion
        // #region Ctor
        /**
         * Constructs a new instance of the `ClearableElement` class.
         *
         * @public
         */
        constructor(...args) {
            super(args);
            this._isClearable = IClearableProps.DEFAULTS.isClearable;
            this._cleared = new HTMLElementEventEmitter(this, 'cleared');
        }
        // #endregion
        // #region Properties
        /**
         * Gets or sets the `isClearable` property.
         * The default value is `false`, which means the element is not clearable.
         *
         * @public
         * @attr is-clearable
         */
        get isClearable() {
            return this._isClearable;
        }
        set isClearable(value) {
            if (this._isClearable !== value) {
                this._isClearable = value;
                this.requestUpdate('isClearable');
            }
        }
        /**
         * Called when the clear method will be called.
         * Provides reference to the `IEventDetail` as event argument.
         *
         * @public
         * @eventProperty
         * @readonly
         */
        get cleared() {
            return this._cleared;
        }
        // #endregion
        // #region Methods
        /**
         * Clears the value of the element but not the validation.
         *
         * @param force - A optional parameter executes the clear method even if the component is disable.
         * @returns Returns `true` if the value was cleared; otherwise, `false`.
         *          If the component is disabled and the `force` parameter is not `true`, the method will return `false`.
         */
        clear(force) {
            // isClearable was disabled because it does not make sense to compare the property with the method.
            // clear() is a method and part of the public API, so it should always be callable.
            // isClearable is used to determine whether the clear button should be shown in the UI.
            // if (!this._isClearable) {
            //     return false;
            // }
            if (this.disabled && !force) {
                return false;
            }
            this.value = null;
            RendererServiceLocator.current.removeAttribute(this, 'value');
            this._cleared.emit();
            return true;
        }
    }
    __decorate([
        Attribute({
            type: Boolean,
            useDefault: true
        }),
        __metadata("design:type", Boolean),
        __metadata("design:paramtypes", [Boolean])
    ], ClearableElement.prototype, "isClearable", null);
    __decorate([
        Emit(),
        __metadata("design:type", Object),
        __metadata("design:paramtypes", [])
    ], ClearableElement.prototype, "cleared", null);
    return ClearableElement;
};
//# sourceMappingURL=Clearable.js.map