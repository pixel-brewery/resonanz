import type { CustomElement } from '../components/abstracts/CustomElement';
import { HorizontalAlignment } from '../types/HorizontalAlignment';
import { VerticalAlignment } from '../types/VerticalAlignment';
import type { ControlBehaviorBase, ControlBehaviorReturn } from './abstracts/Behavior';
/**
 * Represents the `IAlignableProps` interface.
 *
 * @public
 */
export interface IAlignableProps {
    verticalAlignment: VerticalAlignment;
    horizontalAlignment: HorizontalAlignment;
}
/**
 * @public
 */
export declare const Alignable: <T extends ControlBehaviorBase<CustomElement>>(base: T) => ControlBehaviorReturn<T, IAlignableProps>;
/**
 * @public
 */
export declare namespace IAlignableProps {
    const DEFAULTS: IAlignableProps;
}
//# sourceMappingURL=Alignable.d.ts.map