import type { CustomElement } from '../components/abstracts/CustomElement';
import type { ControlBehaviorBase, ControlBehaviorReturn } from './abstracts/Behavior';
import { IOrientableProps } from './Orientable';
/**
 * Represents the `IReversible` interface.
 *
 * @public
 */
export interface IReversibleProps {
    reverse: boolean;
}
/**
 * @public
 */
export declare const Reversible: <T extends ControlBehaviorBase<CustomElement & IOrientableProps>>(base: T) => ControlBehaviorReturn<T, IReversibleProps>;
/**
 * @public
 */
export declare namespace IReversibleProps {
    const DEFAULTS: IReversibleProps;
}
//# sourceMappingURL=Reversible.d.ts.map