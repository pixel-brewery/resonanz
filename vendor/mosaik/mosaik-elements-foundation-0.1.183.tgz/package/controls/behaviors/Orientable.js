/* eslint-disable @typescript-eslint/naming-convention */
// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { css } from '../../dom/Css';
import { Attribute } from '../decorators/AttributeDecorator';
import { Orientation } from '../types/Orientation';
/**
 * @public
 */
export const Orientable = (base) => {
    class OrientableElement extends base {
        // #region Fields
        _orientation;
        // #endregion
        // #region Ctor
        /**
         * Constructs a new instance of the `OrientableElement` class.
         *
         * @public
         */
        constructor(...args) {
            super(args);
            this._orientation = IOrientableProps.DEFAULTS.orientation;
        }
        // #endregion
        // #region Properties
        /**
         * Returns the `styles` property.
         *
         * @public
         * @readonly
         */
        static get styles() {
            return [
                base.styles ?? [],
                css `
                    :host {
                        display: flex;
                        flex-direction: row;
                    }

                    :host([orientation='horizontal']) {
                        flex-direction: row;
                    }

                    :host([orientation='vertical']) {
                        flex-direction: column;
                    }
                `
            ];
        }
        /**
         * Gets or sets the `orientation` property.
         * The default value is `horizontal`.
         *
         * @public
         * @attr orientation
         */
        get orientation() {
            return this._orientation;
        }
        set orientation(value) {
            if (this._orientation !== value) {
                this._orientation = value;
                this.requestUpdate('orientation');
            }
        }
    }
    __decorate([
        Attribute({ type: Orientation }),
        __metadata("design:type", String),
        __metadata("design:paramtypes", [String])
    ], OrientableElement.prototype, "orientation", null);
    return OrientableElement;
};
/**
 * @public
 */
export var IOrientableProps;
(function (IOrientableProps) {
    IOrientableProps.DEFAULTS = {
        orientation: Orientation.Horizontal
    };
})(IOrientableProps || (IOrientableProps = {}));
//# sourceMappingURL=Orientable.js.map