/* eslint-disable @typescript-eslint/naming-convention */
// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Property } from '../decorators/PropertyDecorator';
/**
 * @public
 */
export const Localeable = (base) => {
    class LocaleableElement extends base {
        // #region Fields
        _locale;
        // #endregion
        // #region Ctor
        /**
         * Constructs a new instance of the `LocaleableElement` class.
         *
         * @public
         */
        constructor(...args) {
            super(args);
            this._locale = ILocaleableProps.DEFAULTS.locale;
        }
        // #endregion
        // #region Properties
        /**
         * Gets or sets the `locale` property.
         * The default value is 'default', which means the element uses the default locale.
         *
         * @public
         */
        get locale() {
            return this._locale;
        }
        set locale(value) {
            if (this._locale !== value) {
                this._locale = value;
                this.requestUpdate('locale');
            }
        }
    }
    __decorate([
        Property({ type: String }),
        __metadata("design:type", String),
        __metadata("design:paramtypes", [String])
    ], LocaleableElement.prototype, "locale", null);
    return LocaleableElement;
};
/**
 * @public
 */
export var ILocaleableProps;
(function (ILocaleableProps) {
    ILocaleableProps.DEFAULTS = {
        locale: 'default' // TODO; check if this really works as intended. 'default' is not a valid locale, but it should trigger the element to use the browser's default locale. If this doesn't work, we might need to change the implementation to use navigator.language as the default value.
    };
})(ILocaleableProps || (ILocaleableProps = {}));
//# sourceMappingURL=Localeable.js.map