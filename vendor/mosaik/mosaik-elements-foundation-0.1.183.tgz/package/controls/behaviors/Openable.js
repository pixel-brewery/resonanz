/* eslint-disable @typescript-eslint/naming-convention */
// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { HTMLElementEventEmitter, waitForEvent } from '@pixel-brewery/mosaik-elements';
import { Emit } from '../../events/decorators/EmitDecorator';
/**
 * @public
 */
export const Openable = (base) => {
    class OpenableElement extends base {
        // #region Fields
        _opened;
        // #endregion
        // #region Ctor
        /**
         * Constructs a new instance of the `OpenableElement` class.
         *
         * @public
         */
        constructor(...args) {
            super(args);
            this._opened = new HTMLElementEventEmitter(this, 'opened');
        }
        // #endregion
        // #region Properties
        /**
         * Called when the `open` method is called.
         * Provides reference to the `ICancelEventDetail` as event argument.
         *
         * @public
         * @eventProperty
         * @readonly
         */
        get opened() {
            return this._opened;
        }
        // #endregion
        // #region Methods
        /**
         * @public
         */
        async open() {
            const args = { cancel: false };
            const wait = waitForEvent(this, 'opened')
                .then(() => { });
            this._opened.emit(args);
            return wait;
        }
    }
    __decorate([
        Emit(),
        __metadata("design:type", Object),
        __metadata("design:paramtypes", [])
    ], OpenableElement.prototype, "opened", null);
    return OpenableElement;
};
//# sourceMappingURL=Openable.js.map