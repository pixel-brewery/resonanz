import type { CustomElement } from '../components/abstracts/CustomElement';
import { Orientation } from '../types/Orientation';
import type { ControlBehaviorBase, ControlBehaviorReturn } from './abstracts/Behavior';
/**
 * Represents the `IOrientable` interface.
 *
 * @public
 */
export interface IOrientableProps {
    orientation: Orientation;
}
/**
 * @public
 */
export declare const Orientable: <T extends ControlBehaviorBase<CustomElement>>(base: T) => ControlBehaviorReturn<T, IOrientableProps>;
/**
 * @public
 */
export declare namespace IOrientableProps {
    const DEFAULTS: IOrientableProps;
}
//# sourceMappingURL=Orientable.d.ts.map