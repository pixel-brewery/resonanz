/* eslint-disable @typescript-eslint/naming-convention */
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
// #region Imports
import { css } from '../../dom/Css';
import { RendererServiceLocator } from '../../dom/Renderer';
import { Listen } from '../../events/decorators/ListenDecorator';
import { Attribute } from '../decorators/AttributeDecorator';
import { Watch } from '../decorators/WatchDecorator';
/**
 * @public
 */
export const Focusable = (base) => {
    class FocusableElement extends base {
        // #region Fields
        _isFocused;
        // #endregion
        // #region Ctor
        /**
         * Constructs a new instance of the `FocusableElement` class.
         *
         * @public
         */
        constructor(...args) {
            super(args);
            this._isFocused = IFocusableProps.DEFAULTS.isFocused;
        }
        // #endregion
        // #region Properties
        /**
         * Returns the `styles` property.
         *
         * @public
         * @readonly
         */
        static get styles() {
            return [
                base.styles ?? [],
                css `
                    :host {
                        outline: none;
                    }
                 `
            ];
        }
        /**
         * Gets or sets a value indicating whether this element is displayed in the UI.
         * The default value is `false`, which means the element is not focused.
         *
         * @public
         * @attr is-focused
         */
        get isFocused() {
            return this._isFocused;
        }
        set isFocused(value) {
            if (this._isFocused !== value) {
                this._isFocused = value;
                this.requestUpdate('isFocused');
            }
        }
        // #endregion
        // #region Methods
        /**
         * @protected
         */
        onIsFocusedPropertyChanged(_prev, next) {
            if (next) {
                RendererServiceLocator.current.addClass(this, 'focus-visible');
            }
            else {
                RendererServiceLocator.current.removeClass(this, 'focus-visible');
            }
        }
        /**
         * @private
         */
        handleFocus() {
            this.isFocused = true;
        }
        /**
         * @private
         */
        handleBlur() {
            this.isFocused = false;
        }
    }
    __decorate([
        Attribute({
            type: Boolean,
            useDefault: true
        }),
        __metadata("design:type", Boolean),
        __metadata("design:paramtypes", [Boolean])
    ], FocusableElement.prototype, "isFocused", null);
    __decorate([
        Watch('isFocused'),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Boolean, Boolean]),
        __metadata("design:returntype", void 0)
    ], FocusableElement.prototype, "onIsFocusedPropertyChanged", null);
    __decorate([
        Listen('focus'),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", []),
        __metadata("design:returntype", void 0)
    ], FocusableElement.prototype, "handleFocus", null);
    __decorate([
        Listen('blur'),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", []),
        __metadata("design:returntype", void 0)
    ], FocusableElement.prototype, "handleBlur", null);
    return FocusableElement;
};
/**
 * @public
 */
export var IFocusableProps;
(function (IFocusableProps) {
    IFocusableProps.DEFAULTS = {
        isFocused: false
    };
})(IFocusableProps || (IFocusableProps = {}));
//# sourceMappingURL=Focusable.js.map