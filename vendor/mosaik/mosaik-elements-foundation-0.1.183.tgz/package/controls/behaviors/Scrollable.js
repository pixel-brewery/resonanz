/* eslint-disable @typescript-eslint/naming-convention */
// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Attribute } from '../decorators/AttributeDecorator';
/**
 * @public
 */
export const Scrollable = (base) => {
    class ScrollableElement extends base {
        // #region Fields
        _showScrollButtons;
        _showScrollbar;
        // #endregion
        // #region Ctor
        /**
         * Constructs a new instance of the `ScrollableElement` class.
         *
         * @public
         */
        constructor(...args) {
            super(args);
            this._showScrollButtons = IScrollableProps.DEFAULTS.showScrollButtons;
            this._showScrollbar = IScrollableProps.DEFAULTS.showScrollbar;
        }
        // #endregion
        // #region Properties
        /**
         * Gets or sets the `showScrollButtons` property.
         * When `true`, prev/next navigation buttons are shown overlaying the scroll area.
         * The buttons are positioned at the edges and hidden when the scroll position is
         * already at the respective boundary. This property is independent of gradient
         * indicators and scrollbar visibility.
         * The default value is `false`, which means no navigation buttons are shown.
         *
         * @public
         * @attr show-scroll-buttons
         */
        get showScrollButtons() {
            return this._showScrollButtons;
        }
        set showScrollButtons(value) {
            if (this._showScrollButtons !== value) {
                this._showScrollButtons = value;
                this.requestUpdate('showScrollButtons');
            }
        }
        /**
         * Gets or sets the `showScrollbar` property.
         * When `true`, the native scrollbar of the scroll area is visible.
         * The default value is `false`, which means the scrollbar is hidden.
         *
         * @public
         * @attr show-scrollbar
         */
        get showScrollbar() {
            return this._showScrollbar;
        }
        set showScrollbar(value) {
            if (this._showScrollbar !== value) {
                this._showScrollbar = value;
                this.requestUpdate('showScrollbar');
            }
        }
    }
    __decorate([
        Attribute({
            type: Boolean,
            useDefault: true
        }),
        __metadata("design:type", Boolean),
        __metadata("design:paramtypes", [Boolean])
    ], ScrollableElement.prototype, "showScrollButtons", null);
    __decorate([
        Attribute({
            type: Boolean,
            useDefault: true
        }),
        __metadata("design:type", Boolean),
        __metadata("design:paramtypes", [Boolean])
    ], ScrollableElement.prototype, "showScrollbar", null);
    return ScrollableElement;
};
/**
 * @public
 */
export var IScrollableProps;
(function (IScrollableProps) {
    IScrollableProps.DEFAULTS = {
        showScrollButtons: false,
        showScrollbar: false
    };
})(IScrollableProps || (IScrollableProps = {}));
//# sourceMappingURL=Scrollable.js.map