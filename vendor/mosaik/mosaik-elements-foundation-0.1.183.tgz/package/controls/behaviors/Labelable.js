/* eslint-disable @typescript-eslint/naming-convention */
// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Property } from '../decorators/PropertyDecorator';
import { Watch } from '../decorators/WatchDecorator';
/**
 * @public
 */
export const Labelable = (base) => {
    class LabelableElement extends base {
        // #region Fields
        _label;
        _ownAriaLabel;
        // #endregion
        // #region Ctor
        /**
         * Constructs a new instance of the `LabelableElement` class.
         *
         * @public
         */
        constructor(...args) {
            super(args);
            this._label = ILabelableProps.DEFAULTS.label;
            this._ownAriaLabel = null;
        }
        // #endregion
        // #region Properties
        /**
         * Gets or sets the `label` property.
         * The default value is an empty string, which means no label is displayed.
         *
         * @public
         */
        get label() {
            return this._label;
        }
        set label(value) {
            if (this._label !== value) {
                this._label = value;
                this.requestUpdate('label');
            }
        }
        // #endregion
        // #region Methods
        onLabelPropertyChanged(_prev, next) {
            // The behavior only replaces or removes the `aria-label` it wrote itself: an
            // `aria-label` the author set on the host names the control, whether it carries a
            // visible `label` or none (an icon-only control) - and the watch also fires once on
            // the first update without a label.
            const ariaLabel = this.getAttribute('aria-label');
            const isOwnAriaLabel = ariaLabel === null || ariaLabel === this._ownAriaLabel;
            if (next) {
                if (isOwnAriaLabel) {
                    this.setAttribute('aria-label', next);
                    this._ownAriaLabel = next;
                }
                this.setAttribute('has-label', '');
                return;
            }
            if (ariaLabel !== null && isOwnAriaLabel) {
                this.removeAttribute('aria-label');
            }
            this._ownAriaLabel = null;
            this.removeAttribute('has-label');
        }
    }
    __decorate([
        Property({ type: String }),
        __metadata("design:type", String),
        __metadata("design:paramtypes", [String])
    ], LabelableElement.prototype, "label", null);
    __decorate([
        Watch('label'),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [String, String]),
        __metadata("design:returntype", void 0)
    ], LabelableElement.prototype, "onLabelPropertyChanged", null);
    return LabelableElement;
};
/**
 * @public
 */
export var ILabelableProps;
(function (ILabelableProps) {
    ILabelableProps.DEFAULTS = {
        label: ''
    };
})(ILabelableProps || (ILabelableProps = {}));
//# sourceMappingURL=Labelable.js.map