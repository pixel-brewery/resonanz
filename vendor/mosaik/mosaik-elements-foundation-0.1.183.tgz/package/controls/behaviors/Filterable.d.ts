import type { CustomElement } from '../components/abstracts/CustomElement';
import type { ControlBehaviorBase, ControlBehaviorReturn } from './abstracts/Behavior';
/**
 * Represents the `IFilterable` interface.
 *
 * @public
 */
export interface IFilterableProps {
    showFilter: boolean;
    filterMemberPath: string;
    filter: string;
    filterPlaceholder: string;
}
/**
 * @public
 */
export declare namespace IFilterableProps {
    const DEFAULTS: IFilterableProps;
}
/**
 * @public
 */
export declare const Filterable: <T extends ControlBehaviorBase<CustomElement>>(base: T) => ControlBehaviorReturn<T, IFilterableProps>;
/**
 * Represents the `IFilterableChildProps` interface.
 *
 * @public
 */
export interface IFilterableChildProps {
    /**
     * Indicates whether this element is currently filtered out.
     *
     * @public
     */
    isFiltered: boolean;
}
/**
 * The `FilterableChild` mix-in enables automatic hiding based on a parent filter.
 *
 * @public
 */
export declare const FilterableChild: <T extends ControlBehaviorBase<CustomElement>>(base: T) => ControlBehaviorReturn<T, IFilterableChildProps>;
/**
 * Returns a value by member path.
 *
 * @public
 */
export declare function getMemberValue<T>(self: T, memberKey: string): unknown;
/**
 * Determines whether the specified string contains the specified value.
 *
 * @public
 */
export declare function contains(self: string, match: string, ignoreCase?: boolean): boolean;
//# sourceMappingURL=Filterable.d.ts.map