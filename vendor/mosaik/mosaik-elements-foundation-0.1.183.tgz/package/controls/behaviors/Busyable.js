/* eslint-disable @typescript-eslint/naming-convention */
// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Attribute } from '../decorators/AttributeDecorator';
import { Watch } from '../decorators/WatchDecorator';
/**
 * @public
 */
export const Busyable = (base) => {
    class BusyableElement extends base {
        // #region Fields
        _isBusy;
        // #endregion
        // #region Ctor
        /**
         * Constructs a new instance of the `BusyableElement` class.
         *
         * @public
         */
        constructor(...args) {
            super(args);
            this._isBusy = IBusyableProps.DEFAULTS.isBusy;
        }
        // #endregion
        // #region Properties
        /**
         * A visual characteristics and presentation of this element.
         * The default value is `false`, which means the element is not busy.
         *
         * @public
         * @attr is-busy
         */
        get isBusy() {
            return this._isBusy;
        }
        set isBusy(value) {
            if (this._isBusy !== value) {
                this._isBusy = value;
                this.requestUpdate('isBusy');
            }
        }
        // #endregion
        // #region Methods
        /**
         * @protected
         */
        onIsBusyPropertyChanged(_prev, next) {
            if (next) {
                this.setAttribute('aria-busy', this.isBusy ? 'true' : 'false');
            }
            else {
                this.removeAttribute('aria-busy');
            }
        }
    }
    __decorate([
        Attribute({
            type: Boolean,
            useDefault: true
        }),
        __metadata("design:type", Boolean),
        __metadata("design:paramtypes", [Boolean])
    ], BusyableElement.prototype, "isBusy", null);
    __decorate([
        Watch('isBusy'),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Boolean, Boolean]),
        __metadata("design:returntype", void 0)
    ], BusyableElement.prototype, "onIsBusyPropertyChanged", null);
    return BusyableElement;
};
/**
 * @public
 */
export var IBusyableProps;
(function (IBusyableProps) {
    IBusyableProps.DEFAULTS = {
        isBusy: false
    };
})(IBusyableProps || (IBusyableProps = {}));
//# sourceMappingURL=Busyable.js.map