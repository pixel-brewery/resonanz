/* eslint-disable @typescript-eslint/naming-convention */
// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { RendererServiceLocator } from '../../dom/Renderer';
import { Listen } from '../../events/decorators/ListenDecorator';
import { Attribute } from '../decorators/AttributeDecorator';
import { Watch } from '../decorators/WatchDecorator';
/**
 * @public
 */
export const Disableable = (base) => {
    class DisableableElement extends base {
        // #region Fields
        _disabled;
        // #endregion
        // #region Ctor
        /**
         * Constructs a new instance of the `DisableableElement` class.
         *
         * @public
         */
        constructor(...args) {
            super(args);
            this._disabled = IDisableableProps.DEFAULTS.disabled;
        }
        // #endregion
        // #region Properties
        /**
         * The disabled state of the element.
         * The default value is `false`, which means the element is not disabled.
         *
         * @public
         * @attr disabled
         */
        get disabled() {
            return this._disabled;
        }
        set disabled(value) {
            if (this._disabled !== value) {
                this._disabled = value;
                this.requestUpdate('disabled');
            }
        }
        // #endregion
        // #region Methods
        /**
         * @protected
         */
        onDisabledChanged(prev, next) {
            if (prev !== next) {
                if (next) {
                    RendererServiceLocator.current.addClass(this, 'disabled');
                    RendererServiceLocator.current.setAttribute(this, 'aria-disabled', next.toString());
                }
                else {
                    RendererServiceLocator.current.removeClass(this, 'disabled');
                    RendererServiceLocator.current.removeAttribute(this, 'aria-disabled');
                }
            }
        }
        /**
         * @protected
         */
        onClick(event) {
            if (this.disabled) {
                event.preventDefault();
                event.stopPropagation();
            }
        }
    }
    __decorate([
        Attribute({
            type: Boolean,
            useDefault: false
        }),
        __metadata("design:type", Boolean),
        __metadata("design:paramtypes", [Boolean])
    ], DisableableElement.prototype, "disabled", null);
    __decorate([
        Watch('disabled'),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Boolean, Boolean]),
        __metadata("design:returntype", void 0)
    ], DisableableElement.prototype, "onDisabledChanged", null);
    __decorate([
        Listen('click'),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [MouseEvent]),
        __metadata("design:returntype", void 0)
    ], DisableableElement.prototype, "onClick", null);
    return DisableableElement;
};
/**
 * @public
 */
export var IDisableableProps;
(function (IDisableableProps) {
    IDisableableProps.DEFAULTS = {
        disabled: false
    };
})(IDisableableProps || (IDisableableProps = {}));
//# sourceMappingURL=Disableable.js.map