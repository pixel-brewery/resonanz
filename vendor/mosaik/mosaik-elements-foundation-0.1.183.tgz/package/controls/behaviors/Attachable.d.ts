import type { CustomElement } from '../components/abstracts/CustomElement';
import type { ControlBehaviorBase, ControlBehaviorReturn } from './abstracts/Behavior';
/**
 * Represents the `IAttachable` interface.
 *
 * @public
 */
export interface IAttachable {
    /**
     * Reflects the value of the `for` attribute, which is the ID of the element's
     * associated control.
     *
     * Use this when the elements's associated control is not its parent.
     *
     * To manually control an element, set its `for` attribute to `""`.
     *
     * @example
     * ```html
     * <div class="container">
     *   <mosaik-attachable for="interactive"></mosaik-attachable>
     *   <button id="interactive">Action</button>
     * </div>
     * ```
     *
     * @example
     * ```html
     * <button class="manually-controlled">
     *   <mosaik-attachable></mosaik-attachable>
     * </button>
     * ```
     */
    for: string | null;
    /**
     * The element that controls the visibility of the attachable element. It is
     * one of:
     *
     * - The control referenced by the `for` attribute.
     * - The control provided to `element.attach(control)`
     * - The element's parent.
     * - `null` if the element is not controlled.
     */
    readonly control: HTMLElement | null;
    /**
     * Attaches the element to an interactive control.
     *
     * @param control - The element or id that controls the attachable element.
     */
    attach(control: HTMLElement | string): void;
    /**
     * Detaches the element from its current control.
     */
    detach(): void;
}
/**
 * Represents the `IAttachableProps` interface.
 *
 * @public
 */
export interface IAttachableProps {
    for: string | null;
}
/**
 * @public
 */
export declare const Attachable: <T extends ControlBehaviorBase<CustomElement>>(base: T) => ControlBehaviorReturn<T, IAttachable>;
/**
 * @public
 */
export declare namespace IAttachableProps {
    const DEFAULTS: IAttachableProps;
}
//# sourceMappingURL=Attachable.d.ts.map