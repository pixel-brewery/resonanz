import { IEventDetail, IEventEmitter } from '@pixel-brewery/mosaik-elements';
import type { CustomElement } from '../components/abstracts/CustomElement';
import type { ControlBehaviorBase, ControlBehaviorReturn } from './abstracts/Behavior';
import { type IDisableableProps } from './Disableable';
import { type IValueableProps } from './Valueable';
/**
 * Represents the events of the `Clearable` mixin.
 *
 * @public
 */
export interface IClearableEvents {
    cleared: IEventEmitter<IEventDetail>;
}
/**
 * Represents the `IClearableElementProps` interface.
 *
 * @public
 */
export interface IClearableProps extends IValueableProps, IDisableableProps {
    /**
     * Determines whether the element is clearable or not.
     * Clearable means that a clear button will be displayed when the element has a value.
     * When the clear button is clicked, the value of the element will be cleared.
     */
    isClearable: boolean;
}
/**
 * Represents the `IClearable` interface.
 *
 * @public
 */
export interface IClearable {
    /**
     * Clears the value of the element but not the validation.
     *
     * @param force - A optional parameter executes the clear method even if the component is disable.
     * @returns Returns `true` if the value was cleared; otherwise, `false`.
     *          If the component is disabled and the `force` parameter is not `true`, the method will return `false`.
     */
    clear(force?: boolean): boolean;
}
/**
 * @public
 */
export declare namespace IClearableProps {
    const DEFAULTS: Omit<IClearableProps, keyof IValueableProps | keyof IDisableableProps>;
}
/**
 * @fires cleared {ClearedEvent} - Fires when the `clear` method is called.
 *
 * @public
 */
export declare const Clearable: <T extends ControlBehaviorBase<CustomElement & IValueableProps & IDisableableProps>>(base: T) => ControlBehaviorReturn<T, IClearableProps & IClearableEvents & IClearable>;
//# sourceMappingURL=Clearable.d.ts.map