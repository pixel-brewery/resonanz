import { CSSResultGroup } from '../../dom/Css';
import type { CustomElement } from '../components/abstracts/CustomElement';
import type { ControlBehaviorBase, ControlBehaviorReturn } from './abstracts/Behavior';
/**
 * Represents the `IThemeableProps` interface.
 *
 * @public
 */
export interface IThemeableProps {
    themeName: string;
}
/**
 * @public
 */
export declare namespace IThemeableProps {
    const DEFAULTS: IThemeableProps;
}
/**
 * Represents the `IThemeableConstructor` type.
 *
 * @public
 */
export interface IThemeableCtor {
    new (...args: Array<any>): CustomElement;
    readonly themeStyles: Record<string, CSSResultGroup>;
    registerThemes: (themes: Record<string, CSSResultGroup>) => void;
}
/**
 * @public
 */
export declare const Themeable: <T extends ControlBehaviorBase<CustomElement>>(base: T) => ControlBehaviorReturn<T, IThemeableProps> & IThemeableCtor;
//# sourceMappingURL=Themeable.d.ts.map