import type { CustomElement } from '../components/abstracts/CustomElement';
import type { ControlBehaviorBase, ControlBehaviorReturn } from './abstracts/Behavior';
/**
 * Represents the `IDisableable` interface.
 *
 * @public
 */
export interface IDisableableProps {
    disabled: boolean;
}
/**
 * @public
 */
export declare const Disableable: <T extends ControlBehaviorBase<CustomElement>>(base: T) => ControlBehaviorReturn<T, IDisableableProps>;
/**
 * @public
 */
export declare namespace IDisableableProps {
    const DEFAULTS: IDisableableProps;
}
//# sourceMappingURL=Disableable.d.ts.map