import type { CustomElement } from '../components/abstracts/CustomElement';
import type { ControlBehaviorBase, ControlBehaviorReturn } from './abstracts/Behavior';
/**
 * Represents the `IFocusable` interface.
 *
 * @public
 */
export interface IFocusableProps {
    isFocused: boolean;
}
/**
 * @public
 */
export declare const Focusable: <T extends ControlBehaviorBase<CustomElement>>(base: T) => ControlBehaviorReturn<T, IFocusableProps>;
/**
 * @public
 */
export declare namespace IFocusableProps {
    const DEFAULTS: IFocusableProps;
}
//# sourceMappingURL=Focusable.d.ts.map