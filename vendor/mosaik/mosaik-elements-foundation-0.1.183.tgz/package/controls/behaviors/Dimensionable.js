/* eslint-disable @typescript-eslint/naming-convention */
// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { CssLength } from '@pixel-brewery/mosaik-themes';
import { Attribute } from '../decorators/AttributeDecorator';
import { Watch } from '../decorators/WatchDecorator';
/**
 * @public
 */
export const Dimensionable = (base) => {
    class DimensionableElement extends base {
        // #region Fields
        _width;
        _height;
        // #endregion
        // #region Ctor
        /**
         * Constructs a new instance of the `DimensionableElement` class.
         *
         * @public
         */
        constructor(...args) {
            super(args);
            this._width = IDimensionableProps.DEFAULTS.width;
            this._height = IDimensionableProps.DEFAULTS.height;
        }
        // #endregion
        // #region Properties
        /**
         * Gets or sets the `width` property.
         * The default value is `auto`, which means the width is determined by the content.
         *
         * @public
         * @attr width
         */
        get width() {
            return this._width;
        }
        set width(value) {
            if (this._width !== value) {
                this._width = value;
                this.requestUpdate('width');
            }
        }
        /**
         * Gets or sets the `height` property.
         * The default value is `auto`, which means the height is determined by the content.
         *
         * @public
         * @attr height
         */
        get height() {
            return this._height;
        }
        set height(value) {
            if (this._height !== value) {
                this._height = value;
                this.requestUpdate('height');
            }
        }
        // #endregion
        // #region Methods
        /**
         * @protected
         */
        onWidthPropertyChanged(_, __) {
        }
        /**
         * @protected
         */
        onHeightPropertyChanged(_, __) {
        }
    }
    __decorate([
        Attribute({
            type: String,
            converter: {
                toAttribute: (value) => typeof value === 'number' ? `${value}px` : value?.toString() ?? ''
            }
        }),
        __metadata("design:type", Object),
        __metadata("design:paramtypes", [Object])
    ], DimensionableElement.prototype, "width", null);
    __decorate([
        Attribute({
            type: String,
            converter: {
                toAttribute: (value) => typeof value === 'number' ? `${value}px` : value?.toString() ?? ''
            }
        }),
        __metadata("design:type", Object),
        __metadata("design:paramtypes", [Object])
    ], DimensionableElement.prototype, "height", null);
    __decorate([
        Watch('width'),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object, Object]),
        __metadata("design:returntype", void 0)
    ], DimensionableElement.prototype, "onWidthPropertyChanged", null);
    __decorate([
        Watch('height'),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object, Object]),
        __metadata("design:returntype", void 0)
    ], DimensionableElement.prototype, "onHeightPropertyChanged", null);
    return DimensionableElement;
};
/**
 * @public
 */
export var IDimensionableProps;
(function (IDimensionableProps) {
    IDimensionableProps.DEFAULTS = {
        width: 'auto',
        height: 'auto'
    };
})(IDimensionableProps || (IDimensionableProps = {}));
//# sourceMappingURL=Dimensionable.js.map