import type { CustomElement } from '../components/abstracts/CustomElement';
import { TextOverflow } from '../types/TextOverflow';
import type { ControlBehaviorBase, ControlBehaviorReturn } from './abstracts/Behavior';
/**
 * Represents the `ITextOverflowableProps` interface.
 *
 * @public
 */
export interface ITextOverflowableProps {
    textOverflow: TextOverflow;
}
/**
 * @public
 */
export declare const TextOverflowable: <T extends ControlBehaviorBase<CustomElement>>(base: T) => ControlBehaviorReturn<T, ITextOverflowableProps>;
/**
 * @public
 */
export declare namespace ITextOverflowableProps {
    const DEFAULTS: ITextOverflowableProps;
}
//# sourceMappingURL=TextOverflowable.d.ts.map