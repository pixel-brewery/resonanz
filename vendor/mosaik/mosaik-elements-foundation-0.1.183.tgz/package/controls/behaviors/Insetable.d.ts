import type { CustomElement } from '../components/abstracts/CustomElement';
import { Inset } from '../types/Inset';
import type { ControlBehaviorBase, ControlBehaviorReturn } from './abstracts/Behavior';
/**
 * Represents the `IInsetable` interface.
 *
 * @public
 */
export interface IInsetableProps {
    inset: Inset | Array<Inset> | null;
}
/**
 * @public
 */
export declare const Insetable: <T extends ControlBehaviorBase<CustomElement>>(base: T) => ControlBehaviorReturn<T, IInsetableProps>;
/**
 * @public
 */
export declare namespace IInsetableProps {
    const DEFAULTS: IInsetableProps;
}
//# sourceMappingURL=Insetable.d.ts.map