/* eslint-disable @typescript-eslint/naming-convention */
// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Attribute } from '../decorators/AttributeDecorator';
import { Appearance } from '../types/Appearance';
/**
 * @public
 */
export const Appearanceable = (base) => {
    class AppearanceableElement extends base {
        // #region Fields
        _appearance;
        // #endregion
        // #region Ctor
        /**
         * Constructs a new instance of the `AppearanceableElement` class.
         *
         * @public
         */
        constructor(...args) {
            super(args);
            this._appearance = IAppearanceableProps.DEFAULTS.appearance;
        }
        // #endregion
        // #region Properties
        /**
         * A visual characteristics and presentation of the element.
         * The default value is `default`.
         *
         * @public
         * @attr appearance
         */
        get appearance() {
            return this._appearance;
        }
        set appearance(value) {
            if (this._appearance !== value) {
                this._appearance = value;
                this.requestUpdate('appearance');
            }
        }
    }
    __decorate([
        Attribute({
            type: Appearance,
            useDefault: true
        }),
        __metadata("design:type", String),
        __metadata("design:paramtypes", [String])
    ], AppearanceableElement.prototype, "appearance", null);
    return AppearanceableElement;
};
/**
 * @public
 */
export var IAppearanceableProps;
(function (IAppearanceableProps) {
    IAppearanceableProps.DEFAULTS = {
        appearance: Appearance.Default
    };
})(IAppearanceableProps || (IAppearanceableProps = {}));
//# sourceMappingURL=Appearanceable.js.map