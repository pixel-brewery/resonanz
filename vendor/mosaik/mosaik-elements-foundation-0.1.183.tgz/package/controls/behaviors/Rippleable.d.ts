import type { CustomElement } from '../components/abstracts/CustomElement';
import type { ControlBehaviorBase, ControlBehaviorReturn } from './abstracts/Behavior';
/**
 * Represents the `IRippleableProps` interface.
 *
 * @public
 */
export interface IRippleableProps {
    ripple: boolean;
}
/**
 * A mixin that adds ripple control to a component.
 * When `ripple` is set to `false`, the ripple effect is disabled.
 *
 * @public
 */
export declare const Rippleable: <T extends ControlBehaviorBase<CustomElement>>(base: T) => ControlBehaviorReturn<T, IRippleableProps>;
/**
 * @public
 */
export declare namespace IRippleableProps {
    const DEFAULTS: IRippleableProps;
}
//# sourceMappingURL=Rippleable.d.ts.map