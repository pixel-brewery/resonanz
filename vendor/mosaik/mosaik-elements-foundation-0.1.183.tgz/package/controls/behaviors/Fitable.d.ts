import type { CustomElement } from '../components/abstracts/CustomElement';
import { Fit } from '../types/Fit';
import type { ControlBehaviorBase, ControlBehaviorReturn } from './abstracts/Behavior';
/**
 * Represents the `IFitable` interface.
 *
 * @public
 */
export interface IFitableProps {
    fit: Fit;
}
/**
 * @public
 */
export declare const Fitable: <T extends ControlBehaviorBase<CustomElement>>(base: T) => ControlBehaviorReturn<T, IFitableProps>;
/**
 * @public
 */
export declare namespace IFitableProps {
    const DEFAULTS: IFitableProps;
}
//# sourceMappingURL=Fitable.d.ts.map