// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { HTMLElementEventEmitter } from '@pixel-brewery/mosaik-elements';
import { RendererServiceLocator } from '../../dom/Renderer';
import { Emit } from '../../events/decorators/EmitDecorator';
import { Listen } from '../../events/decorators/ListenDecorator';
import { Attribute } from '../decorators/AttributeDecorator';
/**
 * @public
 */
export var ICheckableProps;
(function (ICheckableProps) {
    ICheckableProps.DEFAULTS = {
        isChecked: false
    };
})(ICheckableProps || (ICheckableProps = {}));
/**
 * @fires checked {CheckedEvent} - Fired when the `isChecked` property is `true`.
 * @fires unchecked {UncheckedEvent} - Fired when the `isChecked` property is `false`.
 * @fires toggled {ToggledEvent} - Fired when the `isChecked` property changes (either direction).
 *
 * @public
 */
export const Checkable = (base) => {
    class CheckableElement extends base {
        // #region Fields
        _checked;
        _unchecked;
        _toggled;
        _isChecked;
        // #endregion
        // #region Ctor
        /**
         * Constructs a new instance of the `CheckableElement` class.
         *
         * @public
         */
        constructor(...args) {
            super(args);
            this._isChecked = ICheckableProps.DEFAULTS.isChecked;
            this._checked = new HTMLElementEventEmitter(this, 'checked');
            this._unchecked = new HTMLElementEventEmitter(this, 'unchecked');
            this._toggled = new HTMLElementEventEmitter(this, 'toggled');
        }
        // #endregion
        // #region Properties
        /**
         * Gets or sets the `isChecked` property.
         * The default value is `false`, which means the element is not checked.
         *
         * @public
         * @attr is-checked
         */
        get isChecked() {
            return this._isChecked;
        }
        set isChecked(value) {
            if (this.disabled) {
                return;
            }
            if (this._isChecked !== value) {
                this.onIsCheckedChanged(this._isChecked, value);
            }
        }
        /**
         * Called when the `isChecked` property is `true`.
         * Provides reference to the `ICheckedEventDetail` as event argument.
         *
         * @public
         * @eventProperty
         * @readonly
         */
        get checked() {
            return this._checked;
        }
        /**
         * Called when the `isChecked` property is `false`.
         * Provides reference to the `IUncheckedEventDetail` as event argument.
         *
         * @public
         * @eventProperty
         * @readonly
         */
        get unchecked() {
            return this._unchecked;
        }
        /**
         * Called when the `isChecked` property changes (either direction).
         * Provides reference to the `IToggledEventDetail` as event argument.
         *
         * @public
         * @eventProperty
         * @readonly
         */
        get toggled() {
            return this._toggled;
        }
        // #endregion
        // #region Methods
        /**
         * Checks the element.
         *
         * @public
         */
        check() {
            if (this.disabled) {
                return;
            }
            if (this._isChecked) {
                return;
            }
            this.isChecked = true;
        }
        /**
         * Unchecks the element.
         *
         * @public
         */
        uncheck() {
            if (this.disabled) {
                return;
            }
            if (!this._isChecked) {
                return;
            }
            this.isChecked = false;
        }
        /**
         * @public
         */
        toggle() {
            if (this.disabled) {
                return;
            }
            this.isChecked = !this.isChecked;
        }
        /**
         * This method is invoked when the `isChecked` property is changed.
         *
         * @protected
         * @virtual
         */
        onIsCheckedChanged(_prev, next) {
            this._isChecked = next;
            this.requestUpdate('isChecked');
            if (next) {
                RendererServiceLocator.current.setAttribute(this, 'aria-checked', 'true');
                this._checked.emit();
            }
            else {
                RendererServiceLocator.current.removeAttribute(this, 'aria-checked');
                this._unchecked.emit();
            }
            this._toggled.emit();
        }
        /**
         * @protected
         */
        handleClick() {
            if (this.disabled) {
                return;
            }
            this.toggle();
        }
    }
    __decorate([
        Attribute({
            type: Boolean,
            useDefault: true
        }),
        __metadata("design:type", Boolean),
        __metadata("design:paramtypes", [Boolean])
    ], CheckableElement.prototype, "isChecked", null);
    __decorate([
        Emit(),
        __metadata("design:type", Object),
        __metadata("design:paramtypes", [])
    ], CheckableElement.prototype, "checked", null);
    __decorate([
        Emit(),
        __metadata("design:type", Object),
        __metadata("design:paramtypes", [])
    ], CheckableElement.prototype, "unchecked", null);
    __decorate([
        Emit(),
        __metadata("design:type", Object),
        __metadata("design:paramtypes", [])
    ], CheckableElement.prototype, "toggled", null);
    __decorate([
        Listen('click'),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", []),
        __metadata("design:returntype", void 0)
    ], CheckableElement.prototype, "handleClick", null);
    return CheckableElement;
};
//# sourceMappingURL=Checkable.js.map