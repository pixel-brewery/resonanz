/* eslint-disable @typescript-eslint/naming-convention */
// #region Imports
import { CustomElement } from '../components/abstracts/CustomElement';
export function mapFormAssociatable(input) {
    return {
        value: input.value,
        form: input.form,
        name: input.name,
        type: input.type,
        validity: input.validity,
        validationMessage: input.validationMessage,
        willValidate: input.willValidate,
        checkValidity: () => input.checkValidity(),
        reportValidity: () => input.reportValidity()
    };
}
/**
 * @public
 */
export var IFormAssociatableProps;
(function (IFormAssociatableProps) {
    IFormAssociatableProps.DEFAULTS = {
        value: undefined
    };
})(IFormAssociatableProps || (IFormAssociatableProps = {}));
/**
 * @public
 */
export const FormAssociatable = (base) => {
    class FormAssociatableElement extends base {
        // #region Fields
        static formAssociated = true;
        _internals;
        _value;
        // #endregion
        // #region Ctor
        /**
         * Constructs a new instance of the `FormAssociatableElement` class.
         *
         * @public
         */
        constructor(...args) {
            super(args);
            this._internals = this.attachInternals();
            this._value = IFormAssociatableProps.DEFAULTS.value;
        }
        // #endregion
        // #region Properties
        get value() {
            return this._value;
        }
        set value(v) {
            this._value = v;
        }
        get form() {
            return this._internals.form;
        }
        get name() {
            return this.getAttribute('name');
        }
        get type() {
            return this.localName;
        }
        get validity() {
            return this._internals.validity;
        }
        get validationMessage() {
            return this._internals.validationMessage;
        }
        get willValidate() {
            return this._internals.willValidate;
        }
        // #endregion
        // #region Methods
        /**
         * Returns true if internals's target element has no validity problems; false otherwise. Fires an invalid event at the element in the latter case.
         *
         * @public
         */
        checkValidity() {
            return this._internals.checkValidity();
        }
        /**
         * Returns true if internals's target element has no validity problems; otherwise, returns false, fires an invalid event at the element, and (if the event isn't canceled) reports the problem to the user.
         *
         * @public
         */
        reportValidity() {
            return this._internals.reportValidity();
        }
    }
    return FormAssociatableElement;
};
/**
 * @public
 */
export function isFormAssociatable(element) {
    const isInput = element.shadowRoot?.querySelector('input') instanceof HTMLInputElement || element.shadowRoot?.querySelector('textarea') instanceof HTMLTextAreaElement || element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement;
    // Check if the element impl. the IFormAssociatedAware interface
    const isAware = element instanceof CustomElement && 'getFormAssociated' in element;
    return (isInput || isAware) && element instanceof CustomElement;
}
//# sourceMappingURL=FormAssociatable.js.map