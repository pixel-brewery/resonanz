import type { CustomElement } from '../components/abstracts/CustomElement';
import type { ControlBehaviorBase, ControlBehaviorReturn } from './abstracts/Behavior';
/**
 * Represents the `IScrollable` interface.
 *
 * @public
 */
export interface IScrollableProps {
    showScrollButtons: boolean;
    showScrollbar: boolean;
}
/**
 * @public
 */
export declare const Scrollable: <T extends ControlBehaviorBase<CustomElement>>(base: T) => ControlBehaviorReturn<T, IScrollableProps>;
/**
 * @public
 */
export declare namespace IScrollableProps {
    const DEFAULTS: IScrollableProps;
}
//# sourceMappingURL=Scrollable.d.ts.map