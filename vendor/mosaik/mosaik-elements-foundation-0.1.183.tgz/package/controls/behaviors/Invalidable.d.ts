import type { CustomElement } from '../components/abstracts/CustomElement';
import type { ControlBehaviorBase, ControlBehaviorReturn } from './abstracts/Behavior';
import type { IValueableProps } from './Valueable';
export interface IInvalidable {
    /**
     * Checks the validity of the element.
     *
     * @public
     */
    checkValidity(): boolean;
}
/**
 * Represents the `IInvalidable` interface.
 *
 * @template TType - The type of the value.
 * @public
 */
export interface IInvalidableProps<TType = unknown> extends IValueableProps<TType> {
    invalid: boolean;
}
/**
 * @public
 */
export declare const Invalidable: <TType, T extends ControlBehaviorBase<CustomElement & IValueableProps<TType>>>(base: T) => ControlBehaviorReturn<T, IInvalidable & IInvalidableProps<TType>>;
/**
 * @public
 */
export declare namespace IInvalidableProps {
    const DEFAULTS: Omit<IInvalidableProps, keyof IValueableProps>;
}
//# sourceMappingURL=Invalidable.d.ts.map