import { IEventDetail, IEventEmitter } from '@pixel-brewery/mosaik-elements';
import type { CustomElement } from '../components/abstracts/CustomElement';
import type { ControlBehaviorBase, ControlBehaviorReturn } from './abstracts/Behavior';
import { IDisableableProps } from './Disableable';
/**
 * Represents the events of the `Selectable` mixin.
 *
 * @public
 */
export interface ISelectableEvents {
    selected: IEventEmitter<IEventDetail>;
    deselected: IEventEmitter<IEventDetail>;
}
/**
 * Represents the `ISelectableProps` interface.
 *
 * @public
 */
export interface ISelectableProps {
    isSelected: boolean;
}
/**
 * Represents the `ISelectable` interface.
 *
 * @public
 */
export interface ISelectable {
    /**
     * Selects the element.
     *
     * @public
     */
    select(): void;
    /**
     * Deselects the element.
     *
     * @public
     */
    deselect(): void;
}
/**
 * @public
 */
export declare namespace ISelectableProps {
    const DEFAULTS: ISelectableProps;
}
/**
 * A mixin that describes a selector behavior.
 *
 * @fires selected {SelectedEvent} - Fired when the `isSelected` property is `true`.
 * @fires deselected {DeselectedEvent} - Fired when the `isSelected` property is `false`.
 *
 * @public
 */
export declare const Selectable: <T extends ControlBehaviorBase<CustomElement & IDisableableProps>>(base: T) => ControlBehaviorReturn<T, ISelectableProps & ISelectableEvents & ISelectable>;
//# sourceMappingURL=Selectable.d.ts.map