/* eslint-disable @typescript-eslint/naming-convention */
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
// #region Imports
import { HTMLElementEventEmitter, waitForEvent } from '@pixel-brewery/mosaik-elements';
import { Emit } from '../../events/decorators/EmitDecorator';
import { Attribute } from '../decorators/AttributeDecorator';
/**
 * @public
 */
export var ICloseableProps;
(function (ICloseableProps) {
    ICloseableProps.DEFAULTS = {
        closeable: false
    };
})(ICloseableProps || (ICloseableProps = {}));
/**
 * @fires closed {ClosedEvent} - Fired when the `close` method is called.
 *
 * @public
 *
 */
export const Closeable = (base) => {
    class CloseableElement extends base {
        // #region Fields
        _closed;
        _closeable;
        // #endregion
        // #region Ctor
        /**
         * Constructs a new instance of the `CloseableElement` class.
         *
         * @public
         */
        constructor(...args) {
            super(args);
            this._closeable = ICloseableProps.DEFAULTS.closeable;
            this._closed = new HTMLElementEventEmitter(this, 'closed');
        }
        // #endregion
        // #region Properties
        /**
         * Gets or sets the `closeable` property.
         * The default value is `false`, which means the element is not closeable.
         *
         * @public
         * @attr closeable
         */
        get closeable() {
            return this._closeable;
        }
        set closeable(value) {
            if (this._closeable !== value) {
                this._closeable = value;
                this.requestUpdate('closeable');
            }
        }
        /**
         * Called when the `close` method is called.
         * Provides reference to the `ICancelEventDetail` as event argument.
         *
         * @public
         * @eventProperty
         * @readonly
         */
        get closed() {
            return this._closed;
        }
        // #endregion
        // #region Methods
        /**
         * Removes the element from the DOM.
         *
         * @public
         */
        async close() {
            // we ignore the undefined value here because 'closeable' is not a required attribute.
            if (this._closeable) {
                const args = { cancel: false };
                const wait = waitForEvent(this, 'closed')
                    .then((x) => x.detail.cancel);
                this._closed.emit(args);
                return wait;
                // If (!args.cancel) {
                //     Const parent = RENDERER.parentNode(this);
                //     If (parent) {
                //         RENDERER.removeChild(parent, this);
                //     }
                // }
            }
            return Promise.resolve(false);
        }
    }
    __decorate([
        Attribute({
            type: Boolean,
            useDefault: true
        }),
        __metadata("design:type", Boolean),
        __metadata("design:paramtypes", [Boolean])
    ], CloseableElement.prototype, "closeable", null);
    __decorate([
        Emit(),
        __metadata("design:type", Object),
        __metadata("design:paramtypes", [])
    ], CloseableElement.prototype, "closed", null);
    return CloseableElement;
};
//# sourceMappingURL=Closeable.js.map