/* eslint-disable @typescript-eslint/naming-convention */
// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { RendererServiceLocator } from '../../dom/Renderer';
import { Attribute } from '../decorators/AttributeDecorator';
import { Watch } from '../decorators/WatchDecorator';
import { Orientation } from '../types/Orientation';
/**
 * @public
 */
export const Reversible = (base) => {
    class ReversibleElement extends base {
        // #region Fields
        _reverse;
        // #endregion
        // #region Ctor
        /**
         * Constructs a new instance of the `ReversibleElement` class.
         *
         * @public
         */
        constructor(...args) {
            super(args);
            this._reverse = IReversibleProps.DEFAULTS.reverse;
        }
        // #endregion
        // #region Properties
        /**
         * Gets or sets the `reverse` property.
         * If `true`, the element will be reversed in its orientation.
         * The default value is `false`, which means the element is not reversed.
         *
         * @public
         * @attr reverse
         */
        get reverse() {
            return this._reverse;
        }
        set reverse(value) {
            if (this._reverse !== value) {
                this._reverse = value;
                this.requestUpdate('reverse');
            }
        }
        // #endregion
        // #region Methods
        /**
         * @protected
         */
        onReversePropertyChanged(prev, next) {
            if (next !== prev) {
                RendererServiceLocator.current.setStyle(this, 'flex-direction', this.getFlexDirection());
            }
        }
        /**
         * @private
         */
        getFlexDirection() {
            switch (this.orientation) {
                case Orientation.Horizontal:
                    return this._reverse ? 'row-reverse' : 'row';
                case Orientation.Vertical:
                    return this._reverse ? 'column-reverse' : 'column';
                default:
                    return this._reverse ? 'row-reverse' : 'row';
            }
        }
    }
    __decorate([
        Attribute({
            type: Boolean,
            useDefault: true
        }),
        __metadata("design:type", Boolean),
        __metadata("design:paramtypes", [Boolean])
    ], ReversibleElement.prototype, "reverse", null);
    __decorate([
        Watch('reverse'),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Boolean, Boolean]),
        __metadata("design:returntype", void 0)
    ], ReversibleElement.prototype, "onReversePropertyChanged", null);
    return ReversibleElement;
};
/**
 * @public
 */
export var IReversibleProps;
(function (IReversibleProps) {
    IReversibleProps.DEFAULTS = {
        reverse: false
    };
})(IReversibleProps || (IReversibleProps = {}));
//# sourceMappingURL=Reversible.js.map