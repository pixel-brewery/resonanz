// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { CssLength } from '@pixel-brewery/mosaik-themes';
import { Attribute } from '../decorators/AttributeDecorator';
import { isSize, Size } from '../types/Size';
/**
 * @public
 */
export const Gapable = (base) => {
    class GapableElement extends base {
        // #region Fields
        _gap;
        // #endregion
        // #region Ctor
        /**
         * Constructs a new instance of the `GapableElement` class.
         *
         * @public
         */
        constructor(...args) {
            super(args);
            this._gap = IGapableProps.DEFAULTS.gap;
        }
        // #endregion
        // #region Properties
        /**
         * The `gap` represents the space between the child elements.
         * The default value is `0`, which means no gap is applied.
         *
         * @public
         * @attr gap
         * @type CssNumber | Size
         */
        get gap() {
            return this._gap;
        }
        set gap(value) {
            if (typeof value === 'string' && isSize(value)) {
                // TODO: this magic 8 const should be came from the theme var(--joy-layout-space).
                const size = 8 * getSizeAsNumber(value);
                value = CssLength.tryParse(size);
            }
            const v = CssLength.tryParse(value);
            if (v) {
                if (this._gap !== v) {
                    this._gap = v;
                    this.requestUpdate('gap');
                }
            }
            else {
                this._gap = 0;
                this.requestUpdate('gap');
            }
        }
    }
    __decorate([
        Attribute({
            type: String,
            converter: {
                fromAttribute: (value) => {
                    if (isSize(value)) {
                        // TODO: this magic 8 const should be came from the theme var(--joy-layout-space).
                        const size = 8 * getSizeAsNumber(value);
                        return CssLength.tryParse(size);
                    }
                    return CssLength.tryParse(value);
                }
            }
        }),
        __metadata("design:type", Object),
        __metadata("design:paramtypes", [Object])
    ], GapableElement.prototype, "gap", null);
    return GapableElement;
};
/**
 * Gets the size as number.
 *
 * @private
 */
function getSizeAsNumber(size) {
    switch (size) {
        case Size.Tiny:
            return 1;
        case Size.Small:
            return 2;
        case Size.Medium:
            return 3;
        case Size.Large:
            return 4;
        case Size.Giant:
            return 5;
        default:
            throw new Error();
    }
}
/**
 * @public
 */
export var IGapableProps;
(function (IGapableProps) {
    IGapableProps.DEFAULTS = {
        gap: 0
    };
})(IGapableProps || (IGapableProps = {}));
//# sourceMappingURL=Gapable.js.map