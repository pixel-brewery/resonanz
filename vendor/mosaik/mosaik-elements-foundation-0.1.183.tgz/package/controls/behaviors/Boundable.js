/* eslint-disable @typescript-eslint/naming-convention */
// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Attribute } from '../decorators/AttributeDecorator';
import { Watch } from '../decorators/WatchDecorator';
/**
 * @public
 */
export const Boundable = (base) => {
    class BoundableElement extends base {
        // #region Fields
        _start;
        _end;
        // #endregion
        // #region Ctor
        /**
         * Constructs a new instance of the `BoundableElement` class.
         *
         * @public
         */
        constructor(...args) {
            super(args);
            this._start = IBoundableProps.DEFAULTS.start;
            this._end = IBoundableProps.DEFAULTS.end;
        }
        // #endregion
        // #region Properties
        /**
         * Gets or sets the `start` property.
         * The default value is the current date and time.
         *
         * @public
         * @attr start
         */
        get start() {
            return this._start;
        }
        set start(value) {
            if (this._start !== value) {
                this._start = value;
                this.requestUpdate('start');
            }
        }
        /**
         * Gets or sets the `end` property.
         * The default value is the current date and time.
         *
         * @public
         * @attr end
         */
        get end() {
            return this._end;
        }
        set end(value) {
            if (this._end !== value) {
                this._end = value;
                this.requestUpdate('end');
            }
        }
        // #endregion
        // #region Methods
        /**
         * @protected
         */
        onStartPropertyChanged(_prev, _next) {
            // Handle changes to the `start` property.
        }
        /**
         * @protected
         */
        onEndPropertyChanged(_prev, _next) {
            // Handle changes to the `end` property.
        }
    }
    __decorate([
        Attribute({
            type: Date,
            converter: {
                fromAttribute: (value) => value ? new Date(value) : new Date(),
                toAttribute: (value) => value ? value.toISOString() : ''
            }
        }),
        __metadata("design:type", Date),
        __metadata("design:paramtypes", [Date])
    ], BoundableElement.prototype, "start", null);
    __decorate([
        Attribute({
            type: Date,
            converter: {
                fromAttribute: (value) => value ? new Date(value) : new Date(),
                toAttribute: (value) => value ? value.toISOString() : ''
            }
        }),
        __metadata("design:type", Date),
        __metadata("design:paramtypes", [Date])
    ], BoundableElement.prototype, "end", null);
    __decorate([
        Watch('start'),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Date, Date]),
        __metadata("design:returntype", void 0)
    ], BoundableElement.prototype, "onStartPropertyChanged", null);
    __decorate([
        Watch('end'),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Date, Date]),
        __metadata("design:returntype", void 0)
    ], BoundableElement.prototype, "onEndPropertyChanged", null);
    return BoundableElement;
};
/**
 * @public
 */
export var IBoundableProps;
(function (IBoundableProps) {
    IBoundableProps.DEFAULTS = {
        start: new Date(),
        end: new Date()
    };
})(IBoundableProps || (IBoundableProps = {}));
//# sourceMappingURL=Boundable.js.map