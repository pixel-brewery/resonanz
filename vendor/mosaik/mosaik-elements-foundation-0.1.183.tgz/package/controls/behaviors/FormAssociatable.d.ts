import { CustomElement } from '../components/abstracts/CustomElement';
import type { ControlBehaviorBase, ControlBehaviorReturn } from './abstracts/Behavior';
/**
 * Represents the `IFormAssociatedAware` interface.
 *
 * @public
 */
export interface IFormAssociatedAware {
    getFormAssociated(): IFormAssociatable | null;
}
/**
 * Represents the `IFormAssociatable` interface.
 *
 * @public
 */
export interface IFormAssociatable {
    get value(): unknown;
    set value(v: unknown);
    get form(): HTMLFormElement | null;
    get name(): string | null;
    get type(): string;
    get validity(): ValidityState;
    get validationMessage(): string;
    get willValidate(): boolean;
    checkValidity(): boolean;
    reportValidity(): boolean;
}
export declare function mapFormAssociatable(input: HTMLInputElement | HTMLTextAreaElement): IFormAssociatable | null;
/**
 * Represents the `IFormAssociatableElementProps` interface.
 *
 * @public
 */
export interface IFormAssociatableProps {
    value: unknown;
}
/**
 * @public
 */
export declare namespace IFormAssociatableProps {
    const DEFAULTS: IFormAssociatableProps;
}
/**
 * @public
 */
export declare const FormAssociatable: <T extends ControlBehaviorBase<CustomElement>>(base: T) => ControlBehaviorReturn<T, IFormAssociatableProps & IFormAssociatable>;
/**
 * @public
 */
export declare function isFormAssociatable(element: HTMLElement): element is IFormAssociatedAware & HTMLElement;
//# sourceMappingURL=FormAssociatable.d.ts.map