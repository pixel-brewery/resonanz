/**
 * ICustomElement - The interface contract for custom element constructors.
 *
 * @description
 * ICustomElement defines the type contract for custom element class constructors, ensuring
 * they provide the required static `is` property that returns the element's tag name. This
 * interface is used for type-safe custom element registration and factory patterns throughout
 * the Mosaik framework. It enables compile-time verification that custom element classes
 * conform to the expected constructor signature and static property requirements.
 *
 * @remarks
 * This interface is primarily used internally by the component registration system and
 * dependency injection mechanisms. It ensures that all custom element classes can be
 * instantiated with `new()` and expose their tag name via the static `is` getter.
 *
 * @example
 * Implementing ICustomElement in a component class:
 * ```typescript
 * export class ButtonElement extends CustomElement {
 *   public static get is(): string {
 *     return 'mosaik-button';
 *   }
 * }
 * ```
 *
 * @example
 * Using ICustomElement for type-safe registration:
 * ```typescript
 * function registerElement<T extends HTMLElement>(elementClass: ICustomElement<T>): void {
 *   customElements.define(elementClass.is, elementClass);
 * }
 * ```
 *
 * @example
 * Factory pattern with ICustomElement:
 * ```typescript
 * function createElement<T extends HTMLElement>(ElementClass: ICustomElement<T>): T {
 *   return document.createElement(ElementClass.is) as T;
 * }
 * ```
 *
 * @public
 */
export interface ICustomElement<T extends HTMLElement = HTMLElement> {
    new (...params: Array<any>): T;
    /**
     * The `is` property returns the tag name of the custom element.
     */
    get is(): string;
}
//# sourceMappingURL=ICustomElement.d.ts.map