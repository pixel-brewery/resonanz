/**
 * Represents the `IDisconnectedCallback` interface.
 *
 * @public
 */
export interface IDisconnectedCallback {
    /**
     * Invoked when the component is removed from the document's DOM.
     *
     * This callback is the main signal to the element that it may no longer be
     * used. `disconnectedCallback()` should ensure that nothing is holding a
     * reference to the element (such as event listeners added to nodes external
     * to the element), so that it is free to be garbage collected.
     *
     * ```ts
     * disconnectedCallback() {
     *   super.disconnectedCallback();
     *   window.removeEventListener('keydown', this._handleKeydown);
     * }
     * ```
     *
     * An element may be re-connected after being disconnected.
     *
     * @public
     */
    disconnectedCallback(): void;
}
//# sourceMappingURL=IDisconnectedCallback.d.ts.map