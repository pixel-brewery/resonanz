export {};
//# sourceMappingURL=ICustomFormElement.js.map