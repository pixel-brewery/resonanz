export {};
//# sourceMappingURL=ICustomElement.js.map