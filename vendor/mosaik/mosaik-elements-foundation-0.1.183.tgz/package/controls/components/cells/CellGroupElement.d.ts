import { CustomElement } from '../abstracts/CustomElement';
import { ICellGroupElementProps } from './ICellGroupElementProps';
declare const CellGroupElement_base: (abstract new (...args: Array<any>) => import("../../../controls/behaviors/Themeable").IThemeableProps) & typeof CustomElement & import("../../../controls/behaviors/Themeable").IThemeableCtor;
/**
 * CellGroup - A logical container component for organizing related cells into cohesive sections with optional headers.
 *
 * @description
 * The CellGroup component groups multiple cell components together with consistent styling, optional section headers,
 * and semantic organization for improved content structure. Ideal for creating organized lists, settings panels,
 * form sections, and grouped data presentations. Features configurable borders, padding, and header styling
 * for comprehensive layout control.
 *
 * @name CellGroup
 * @element mosaik-cell-group
 * @category Cells
 *
 * @slot - Default content area for cell components and related content
 * @slot header - Header content area for group titles, descriptions, or section labels
 *
 * @csspart header - Header section styling container for group titles
 * @csspart root - Root container wrapping the entire cell group structure
 *
 * @cssprop {String} --cell-group-border-color - Border color for the group container
 * @cssprop {String} --cell-group-border-radius - Border radius for group container corner rounding
 * @cssprop {String} --cell-group-border-style - Border line style (solid, dashed, dotted)
 * @cssprop {String} --cell-group-border-width - Border width for group container outline
 * @cssprop {String} --cell-group-font-family - Font family for header text
 * @cssprop {String} --cell-group-font-letter-spacing - Letter spacing for header text
 * @cssprop {String} --cell-group-font-line-height - Line height for header text
 * @cssprop {String} --cell-group-font-size - Font size for header text
 * @cssprop {String} --cell-group-font-text-decoration - Text decoration for header text
 * @cssprop {String} --cell-group-font-text-transform - Text transform for header text
 * @cssprop {String} --cell-group-font-weight - Font weight for header text
 * @cssprop {String} --cell-group-gap - The group gap CSS custom property.
 * @cssprop {String} --cell-group-inline-end - Inline end offset for group positioning
 * @cssprop {String} --cell-group-inline-start - Inline start offset for group positioning
 * @cssprop {String} --cell-group-padding-bottom - The group padding bottom CSS custom property.
 * @cssprop {String} --cell-group-padding-left - The group padding left CSS custom property.
 * @cssprop {String} --cell-group-padding-right - The group padding right CSS custom property.
 * @cssprop {String} --cell-group-padding-top - The group padding top CSS custom property.
 * @cssprop {String} --cell-group-shadow - The group shadow CSS custom property.
 * @cssprop {String} --cell-group-shadow-blur - The group shadow blur CSS custom property.
 * @cssprop {String} --cell-group-shadow-color - The group shadow color CSS custom property.
 * @cssprop {String} --cell-group-shadow-offset-x - The group shadow offset x CSS custom property.
 * @cssprop {String} --cell-group-shadow-offset-y - The group shadow offset y CSS custom property.
 * @cssprop {String} --cell-group-shadow-spread - The group shadow spread CSS custom property.
 * @cssprop {String} --cell-group-transition-duration - The group transition duration CSS custom property.
 * @cssprop {String} --cell-group-transition-mode - The group transition mode CSS custom property.
 * @cssprop {String} --cell-group-transition-property - The group transition property CSS custom property.
 * @cssprop {String} --cell-group-translate - The group translate CSS custom property.
 *
 * @dependency mosaik-text - The Text element.
 *
 * @example
 * Basic cell group with slotted header:
 * ```html
 * <mosaik-cell-group>
 *   <span slot="header">Account Settings</span>
 *   <mosaik-cell label="Profile Information"></mosaik-cell>
 *   <mosaik-cell label="Change Password"></mosaik-cell>
 * </mosaik-cell-group>
 * ```
 *
 * @example
 * Settings group with cells and icons:
 * ```html
 * <mosaik-cell-group>
 *   <span slot="header">Account Settings</span>
 *   <mosaik-cell label="Profile Information" is-navigation></mosaik-cell>
 *   <mosaik-cell label="Change Password" is-navigation></mosaik-cell>
 * </mosaik-cell-group>
 * ```
 *
 * @example
 * Navigation menu group:
 * ```html
 * <mosaik-cell-group>
 *   <span slot="header">Navigation</span>
 *   <mosaik-cell label="Dashboard" is-navigation></mosaik-cell>
 *   <mosaik-cell label="Analytics" is-navigation></mosaik-cell>
 * </mosaik-cell-group>
 * ```
 *
 * @public
 */
export declare class CellGroupElement extends CellGroupElement_base implements ICellGroupElementProps {
    private _header;
    /**
     * @public
     */
    constructor();
    /**
     * Returns the `is` property.
     * The `is` property represents natural name of this element.
     *
     * @public
     * @static
     * @readonly
     */
    static get is(): string;
    /**
     * Gets or sets the `header` property.
     *
     * @public
     */
    get header(): string;
    set header(value: string);
}
/**
 * @public
 */
export declare namespace CellGroupElement {
    type Props = ICellGroupElementProps;
}
/**
 * @public
 */
declare global {
    interface HTMLElementTagNameMap {
        'mosaik-cell-group': CellGroupElement;
    }
}
export {};
//# sourceMappingURL=CellGroupElement.d.ts.map