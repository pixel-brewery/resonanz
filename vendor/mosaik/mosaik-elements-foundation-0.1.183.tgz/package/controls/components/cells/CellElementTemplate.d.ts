import { type TemplateResult } from '../../../dom/Html';
import type { CellElement } from './CellElement';
/**
 * The template of the `CellElement`.
 *
 * @public
 */
export declare function cellElementTemplate<T extends CellElement>(e: T): TemplateResult;
//# sourceMappingURL=CellElementTemplate.d.ts.map