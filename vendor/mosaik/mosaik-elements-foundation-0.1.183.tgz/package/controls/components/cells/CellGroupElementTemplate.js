// #region Imports
import { html } from '../../../dom/Html';
// #endregion
/**
 * The template of the `CellGroupElement`.
 *
 * @public
 */
export function cellGroupElementTemplate(e) {
    return html `
        <slot name="header">
            <mosaik-text part="header" .text="${e.header}"></mosaik-text>
        </slot>
        <div part="root">
            <slot></slot>
        </div>
    `;
}
//# sourceMappingURL=CellGroupElementTemplate.js.map