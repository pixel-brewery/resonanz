// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Themeable } from '../../../controls/behaviors/Themeable';
import { Disableable } from '../../behaviors/Disableable';
import { Labelable } from '../../behaviors/Labelable';
import { Attribute } from '../../decorators/AttributeDecorator';
import { Component } from '../../decorators/ComponentDecorator';
import { Property } from '../../decorators/PropertyDecorator';
import { CustomElement } from '../abstracts/CustomElement';
import { TextElement } from '../primitives/text/TextElement';
import { cellElementTemplate } from './CellElementTemplate';
import { cellElementCosmopolitanStyle } from './themes/CellElement.Cosmopolitan';
import { cellElementJoyStyle } from './themes/CellElement.Joy';
import { cellElementMemphisStyle } from './themes/CellElement.Memphis';
import { cellElementSohoStyle } from './themes/CellElement.Soho';
// #endregion
/**
 * Cell - A flexible content container component optimized for structured data presentation in grids, lists, and tables.
 *
 * @description
 * The Cell component provides a structured content cell with support for primary labels, secondary descriptions,
 * and flexible content areas. Designed for consistent data presentation across various layout patterns including
 * list items, table cells, grid components, and card content organization. It features built-in support for
 * disabled states, navigation indicators, and flexible slot-based content composition. On narrow cells the label
 * and sub label wrap, and end content that does not fit beside the text's minimum width moves to its own line at
 * the end edge, so neither the text is crushed nor trailing actions leave the cell. End content keeps its own height
 * and is centered on its line.
 *
 * @name Cell
 * @element mosaik-cell
 * @category Cells
 *
 * @slot end - Trailing content area for actions, status indicators, or secondary controls
 * @slot label - Primary content area for main text, titles, or primary information
 * @slot start - Leading content area for icons, avatars, thumbnails, or visual indicators
 * @slot subLabel - Secondary content area for descriptions, metadata, or supplementary text
 *
 * @csspart label - Primary label content styling container
 * @csspart root - Root container wrapping the entire cell content and layout
 * @csspart subLabel - Secondary label content styling container
 * @csspart text - Text content wrapper for typography and text styling
 *
 * @cssprop {String} --cell-background-color - Background color of the cell container
 * @cssprop {String} --cell-font-family - Font family for primary cell text
 * @cssprop {String} --cell-font-letter-spacing - Letter spacing for primary cell text
 * @cssprop {String} --cell-font-line-height - Line height for primary cell text
 * @cssprop {String} --cell-font-size - Font size for primary cell text
 * @cssprop {String} --cell-font-text-decoration - Text decoration for primary cell text
 * @cssprop {String} --cell-font-text-transform - Text transform for primary cell text
 * @cssprop {String} --cell-font-weight - Font weight for primary cell text
 * @cssprop {String} --cell-gap - Gap between cell content elements
 * @cssprop {String} --cell-padding-bottom - Bottom padding for cell content spacing
 * @cssprop {String} --cell-padding-left - Left padding for cell content spacing
 * @cssprop {String} --cell-padding-right - Right padding for cell content spacing
 * @cssprop {String} --cell-padding-top - Top padding for cell content spacing
 * @cssprop {String} --cell-shadow - The shadow CSS custom property.
 * @cssprop {String} --cell-shadow-blur - The shadow blur CSS custom property.
 * @cssprop {String} --cell-shadow-color - The shadow color CSS custom property.
 * @cssprop {String} --cell-shadow-offset-x - The shadow offset x CSS custom property.
 * @cssprop {String} --cell-shadow-offset-y - The shadow offset y CSS custom property.
 * @cssprop {String} --cell-shadow-spread - The shadow spread CSS custom property.
 * @cssprop {String} --cell-sub-font-family - Font family for secondary cell text
 * @cssprop {String} --cell-sub-font-letter-spacing - Letter spacing for secondary cell text
 * @cssprop {String} --cell-sub-font-line-height - Line height for secondary cell text
 * @cssprop {String} --cell-sub-font-size - Font size for secondary cell text
 * @cssprop {String} --cell-sub-font-text-decoration - Text decoration for secondary cell text
 * @cssprop {String} --cell-sub-font-text-transform - Text transform for secondary cell text
 * @cssprop {String} --cell-sub-font-weight - Font weight for secondary cell text
 * @cssprop {String} --cell-text-min-width - Minimum width of the text beside the end content before the end content moves to its own line (default `8rem`)
 * @cssprop {String} --cell-transition-duration - The transition duration CSS custom property.
 * @cssprop {String} --cell-transition-mode - The transition mode CSS custom property.
 * @cssprop {String} --cell-transition-property - The transition property CSS custom property.
 * @cssprop {String} --cell-translate - The translate CSS custom property.
 *
 * @dependency mosaik-text - The Text element.
 *
 * @example
 * Basic cell with label:
 * ```html
 * <mosaik-cell label="Dashboard"></mosaik-cell>
 * ```
 *
 * @example
 * Contact list cell with slotted content:
 * ```html
 * <mosaik-cell>
 *   <mosaik-avatar slot="start"></mosaik-avatar>
 *   <span slot="label">John Smith</span>
 *   <span slot="subLabel">john.smith@company.com</span>
 *   <mosaik-button slot="end" label="Call" appearance="plain"></mosaik-button>
 * </mosaik-cell>
 * ```
 *
 * @example
 * Navigation cell with indicator:
 * ```html
 * <mosaik-cell is-navigation label="Privacy &amp; Security"></mosaik-cell>
 * ```
 *
 * @example
 * Disabled cell:
 * ```html
 * <mosaik-cell disabled label="Unavailable Option"></mosaik-cell>
 * ```
 *
 * @public
 */
let CellElement = class CellElement extends Themeable(Labelable(Disableable(CustomElement))) {
    // #region Fields
    _isNavigation;
    _subLabel;
    // #endregion
    // #region Ctor
    /**
     * @public
     */
    constructor() {
        super();
        this._isNavigation = false;
        this._subLabel = '';
    }
    // #endregion
    // #region Properties
    /**
     * Returns the `is` property.
     * The `is` property represents natural name of this element.
     *
     * @public
     * @static
     * @readonly
     */
    static get is() {
        return 'mosaik-cell';
    }
    /**
     * Gets or sets the `isNavigation` property.
     *
     * @public
     * @attr is-navigation
     */
    get isNavigation() {
        return this._isNavigation;
    }
    set isNavigation(value) {
        if (this._isNavigation !== value) {
            this._isNavigation = value;
            this.requestUpdate('isNavigation');
        }
    }
    /**
     * Gets or sets the `subLabel` property.
     *
     * @public
     */
    get subLabel() {
        return this._subLabel;
    }
    set subLabel(value) {
        if (this._subLabel !== value) {
            this._subLabel = value;
            this.requestUpdate('subLabel');
        }
    }
};
__decorate([
    Attribute({
        type: Boolean,
        useDefault: true
    }),
    __metadata("design:type", Boolean),
    __metadata("design:paramtypes", [Boolean])
], CellElement.prototype, "isNavigation", null);
__decorate([
    Property({ type: String }),
    __metadata("design:type", String),
    __metadata("design:paramtypes", [String])
], CellElement.prototype, "subLabel", null);
CellElement = __decorate([
    Component({
        selector: 'mosaik-cell',
        template: cellElementTemplate,
        themes: {
            joy: cellElementJoyStyle,
            memphis: cellElementMemphisStyle,
            cosmopolitan: cellElementCosmopolitanStyle,
            soho: cellElementSohoStyle
        },
        imports: [
            TextElement
        ]
    }),
    __metadata("design:paramtypes", [])
], CellElement);
export { CellElement };
//# sourceMappingURL=CellElement.js.map