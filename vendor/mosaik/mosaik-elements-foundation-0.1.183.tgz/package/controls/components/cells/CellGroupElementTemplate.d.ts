import { type TemplateResult } from '../../../dom/Html';
import type { CellGroupElement } from './CellGroupElement';
/**
 * The template of the `CellGroupElement`.
 *
 * @public
 */
export declare function cellGroupElementTemplate<T extends CellGroupElement>(e: T): TemplateResult;
//# sourceMappingURL=CellGroupElementTemplate.d.ts.map