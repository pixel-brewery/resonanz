// #region Imports
import { html } from '../../../dom/Html';
import { when } from '../../directives/Directives';
// #endregion
/**
 * The template of the `CellElement`.
 *
 * @public
 */
export function cellElementTemplate(e) {
    return html `
        <div part="root">
            <slot name="start"></slot>
            <div part="text">
                <slot name="label">
                    ${when(e.label, () => html `
                    <mosaik-text part="label"
                                 .text="${e.label}"
                                 .wrap="${true}"
                                 ?disabled="${e.disabled}"></mosaik-text>
                    `)}
                </slot>
                <slot name="subLabel">
                    ${when(e.subLabel, () => html `
                    <mosaik-text part="subLabel"
                                 .text="${e.subLabel}"
                                 .readonly="${true}"
                                 .wrap="${true}"
                                 ?disabled="${e.disabled}"></mosaik-text>
                    `)}
                </slot>
            </div>
            <slot name="end"></slot>
        </div>
    `;
}
//# sourceMappingURL=CellElementTemplate.js.map