export {};
//# sourceMappingURL=ICellGroupElementProps.js.map