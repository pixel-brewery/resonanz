import type { IDisableableProps } from '../../behaviors/Disableable';
import type { ILabelableProps } from '../../behaviors/Labelable';
/**
 * Represents the `ICellElementProps` interface.
 *
 * @public
 */
export interface ICellElementProps extends ILabelableProps, IDisableableProps {
    isNavigation: boolean;
    subLabel?: string;
}
//# sourceMappingURL=ICellElementProps.d.ts.map