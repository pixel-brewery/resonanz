// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Themeable } from '../../../controls/behaviors/Themeable';
import { Component } from '../../decorators/ComponentDecorator';
import { Property } from '../../decorators/PropertyDecorator';
import { CustomElement } from '../abstracts/CustomElement';
import { TextElement } from '../primitives/text/TextElement';
import { cellGroupElementTemplate } from './CellGroupElementTemplate';
import { cellGroupElementCosmopolitanStyle } from './themes/CellGroupElement.Cosmopolitan';
import { cellGroupElementJoyStyle } from './themes/CellGroupElement.Joy';
import { cellGroupElementMemphisStyle } from './themes/CellGroupElement.Memphis';
import { cellGroupElementSohoStyle } from './themes/CellGroupElement.Soho';
// #endregion
/**
 * CellGroup - A logical container component for organizing related cells into cohesive sections with optional headers.
 *
 * @description
 * The CellGroup component groups multiple cell components together with consistent styling, optional section headers,
 * and semantic organization for improved content structure. Ideal for creating organized lists, settings panels,
 * form sections, and grouped data presentations. Features configurable borders, padding, and header styling
 * for comprehensive layout control.
 *
 * @name CellGroup
 * @element mosaik-cell-group
 * @category Cells
 *
 * @slot - Default content area for cell components and related content
 * @slot header - Header content area for group titles, descriptions, or section labels
 *
 * @csspart header - Header section styling container for group titles
 * @csspart root - Root container wrapping the entire cell group structure
 *
 * @cssprop {String} --cell-group-border-color - Border color for the group container
 * @cssprop {String} --cell-group-border-radius - Border radius for group container corner rounding
 * @cssprop {String} --cell-group-border-style - Border line style (solid, dashed, dotted)
 * @cssprop {String} --cell-group-border-width - Border width for group container outline
 * @cssprop {String} --cell-group-font-family - Font family for header text
 * @cssprop {String} --cell-group-font-letter-spacing - Letter spacing for header text
 * @cssprop {String} --cell-group-font-line-height - Line height for header text
 * @cssprop {String} --cell-group-font-size - Font size for header text
 * @cssprop {String} --cell-group-font-text-decoration - Text decoration for header text
 * @cssprop {String} --cell-group-font-text-transform - Text transform for header text
 * @cssprop {String} --cell-group-font-weight - Font weight for header text
 * @cssprop {String} --cell-group-gap - The group gap CSS custom property.
 * @cssprop {String} --cell-group-inline-end - Inline end offset for group positioning
 * @cssprop {String} --cell-group-inline-start - Inline start offset for group positioning
 * @cssprop {String} --cell-group-padding-bottom - The group padding bottom CSS custom property.
 * @cssprop {String} --cell-group-padding-left - The group padding left CSS custom property.
 * @cssprop {String} --cell-group-padding-right - The group padding right CSS custom property.
 * @cssprop {String} --cell-group-padding-top - The group padding top CSS custom property.
 * @cssprop {String} --cell-group-shadow - The group shadow CSS custom property.
 * @cssprop {String} --cell-group-shadow-blur - The group shadow blur CSS custom property.
 * @cssprop {String} --cell-group-shadow-color - The group shadow color CSS custom property.
 * @cssprop {String} --cell-group-shadow-offset-x - The group shadow offset x CSS custom property.
 * @cssprop {String} --cell-group-shadow-offset-y - The group shadow offset y CSS custom property.
 * @cssprop {String} --cell-group-shadow-spread - The group shadow spread CSS custom property.
 * @cssprop {String} --cell-group-transition-duration - The group transition duration CSS custom property.
 * @cssprop {String} --cell-group-transition-mode - The group transition mode CSS custom property.
 * @cssprop {String} --cell-group-transition-property - The group transition property CSS custom property.
 * @cssprop {String} --cell-group-translate - The group translate CSS custom property.
 *
 * @dependency mosaik-text - The Text element.
 *
 * @example
 * Basic cell group with slotted header:
 * ```html
 * <mosaik-cell-group>
 *   <span slot="header">Account Settings</span>
 *   <mosaik-cell label="Profile Information"></mosaik-cell>
 *   <mosaik-cell label="Change Password"></mosaik-cell>
 * </mosaik-cell-group>
 * ```
 *
 * @example
 * Settings group with cells and icons:
 * ```html
 * <mosaik-cell-group>
 *   <span slot="header">Account Settings</span>
 *   <mosaik-cell label="Profile Information" is-navigation></mosaik-cell>
 *   <mosaik-cell label="Change Password" is-navigation></mosaik-cell>
 * </mosaik-cell-group>
 * ```
 *
 * @example
 * Navigation menu group:
 * ```html
 * <mosaik-cell-group>
 *   <span slot="header">Navigation</span>
 *   <mosaik-cell label="Dashboard" is-navigation></mosaik-cell>
 *   <mosaik-cell label="Analytics" is-navigation></mosaik-cell>
 * </mosaik-cell-group>
 * ```
 *
 * @public
 */
let CellGroupElement = class CellGroupElement extends Themeable(CustomElement) {
    // #region Fields
    _header;
    // #endregion
    // #region Ctor
    /**
     * @public
     */
    constructor() {
        super();
        this._header = '';
    }
    // #endregion
    // #region Properties
    /**
     * Returns the `is` property.
     * The `is` property represents natural name of this element.
     *
     * @public
     * @static
     * @readonly
     */
    static get is() {
        return 'mosaik-cell-group';
    }
    /**
     * Gets or sets the `header` property.
     *
     * @public
     */
    get header() {
        return this._header;
    }
    set header(value) {
        if (this._header !== value) {
            this._header = value;
            this.requestUpdate('header');
        }
    }
};
__decorate([
    Property({ type: String }),
    __metadata("design:type", String),
    __metadata("design:paramtypes", [String])
], CellGroupElement.prototype, "header", null);
CellGroupElement = __decorate([
    Component({
        selector: 'mosaik-cell-group',
        template: cellGroupElementTemplate,
        themes: {
            joy: cellGroupElementJoyStyle,
            memphis: cellGroupElementMemphisStyle,
            cosmopolitan: cellGroupElementCosmopolitanStyle,
            soho: cellGroupElementSohoStyle
        },
        imports: [
            TextElement
        ]
    }),
    __metadata("design:paramtypes", [])
], CellGroupElement);
export { CellGroupElement };
//# sourceMappingURL=CellGroupElement.js.map