/**
 * Represents the `ICellGroupElementProps` interface.
 *
 * @public
 */
export interface ICellGroupElementProps {
    header: string;
}
//# sourceMappingURL=ICellGroupElementProps.d.ts.map