import { type CSSResult } from '../../../../dom/Css';
/**
 * @public
 */
export declare function cellElementSohoStyle(): CSSResult;
//# sourceMappingURL=CellElement.Soho.d.ts.map