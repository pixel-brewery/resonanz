import { type CSSResult } from '../../../../dom/Css';
/**
 * @public
 */
export declare function cellGroupElementCosmopolitanStyle(): CSSResult;
//# sourceMappingURL=CellGroupElement.Cosmopolitan.d.ts.map