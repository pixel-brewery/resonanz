import { type CSSResult } from '../../../../dom/Css';
/**
 * @public
 */
export declare function cellElementJoyStyle(): CSSResult;
//# sourceMappingURL=CellElement.Joy.d.ts.map