import { type CSSResult } from '../../../../dom/Css';
/**
 * @public
 */
export declare function cellElementMemphisStyle(): CSSResult;
//# sourceMappingURL=CellElement.Memphis.d.ts.map