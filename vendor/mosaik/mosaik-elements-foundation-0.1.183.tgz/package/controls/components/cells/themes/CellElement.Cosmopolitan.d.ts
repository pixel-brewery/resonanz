import { type CSSResult } from '../../../../dom/Css';
/**
 * @public
 */
export declare function cellElementCosmopolitanStyle(): CSSResult;
//# sourceMappingURL=CellElement.Cosmopolitan.d.ts.map