import { type CSSResult } from '../../../../dom/Css';
/**
 * @public
 */
export declare function cellGroupElementJoyStyle(): CSSResult;
//# sourceMappingURL=CellGroupElement.Joy.d.ts.map