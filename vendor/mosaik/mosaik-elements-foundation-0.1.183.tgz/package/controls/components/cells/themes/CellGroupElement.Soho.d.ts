import { type CSSResult } from '../../../../dom/Css';
/**
 * @public
 */
export declare function cellGroupElementSohoStyle(): CSSResult;
//# sourceMappingURL=CellGroupElement.Soho.d.ts.map