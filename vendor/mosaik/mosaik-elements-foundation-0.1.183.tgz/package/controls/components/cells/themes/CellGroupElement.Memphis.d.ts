import { type CSSResult } from '../../../../dom/Css';
/**
 * @public
 */
export declare function cellGroupElementMemphisStyle(): CSSResult;
//# sourceMappingURL=CellGroupElement.Memphis.d.ts.map