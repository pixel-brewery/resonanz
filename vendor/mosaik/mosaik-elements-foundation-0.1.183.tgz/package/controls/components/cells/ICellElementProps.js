// #region Imports
export {};
//# sourceMappingURL=ICellElementProps.js.map