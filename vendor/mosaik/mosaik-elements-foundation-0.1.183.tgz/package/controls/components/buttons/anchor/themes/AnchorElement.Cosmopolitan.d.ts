import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function anchorElementCosmopolitanStyle(): CSSResult;
//# sourceMappingURL=AnchorElement.Cosmopolitan.d.ts.map