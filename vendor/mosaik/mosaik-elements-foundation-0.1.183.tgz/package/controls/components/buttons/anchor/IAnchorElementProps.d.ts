import type { IDisableableProps } from '../../../behaviors/Disableable';
import type { ILabelableProps } from '../../../behaviors/Labelable';
import type { IVariantableProps } from '../../../behaviors/Variantable';
import type { HyperlinkUnderline } from '../../../types/HyperlinkUnderline';
import type { IButtonLinkElementProps } from '../button/IButtonLinkElementProps';
/**
 * Represents the `IAnchorElementProps` interface.
 *
 * @public
 */
export interface IAnchorElementProps extends IButtonLinkElementProps, IDisableableProps, IVariantableProps, ILabelableProps {
    underline: HyperlinkUnderline;
}
//# sourceMappingURL=IAnchorElementProps.d.ts.map