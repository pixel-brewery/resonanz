import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function anchorElementJoyStyle(): CSSResult;
//# sourceMappingURL=AnchorElement.Joy.d.ts.map