import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function anchorElementMemphisStyle(): CSSResult;
//# sourceMappingURL=AnchorElement.Memphis.d.ts.map