import { HyperlinkUnderline } from '../../../types/HyperlinkUnderline';
import { CustomElement } from '../../abstracts/CustomElement';
import type { IAnchorElementProps } from './IAnchorElementProps';
declare const AnchorElement_base: (abstract new (...args: Array<any>) => import("../../../../controls/behaviors/Themeable").IThemeableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Variantable").IVariantableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Disableable").IDisableableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Labelable").ILabelableProps) & typeof CustomElement & import("../../../../controls/behaviors/Themeable").IThemeableCtor;
/**
 * Anchor - A hyperlink component for navigation between pages or external resources.
 *
 * @description
 * The Anchor component provides a customizable hyperlink element that functions as a clickable link
 * for navigation. It extends the native anchor element functionality with enhanced styling,
 * accessibility features, and consistent visual appearance across the design system.
 * The component supports various underline styles, target configurations, and download attributes.
 *
 * @name Anchor
 * @element mosaik-anchor
 * @category Links
 *
 * @slot label - The text content or elements to display as the link text
 *
 * @csspart label - The text label area of the anchor
 * @csspart link - The main link element wrapper
 *
 * @cssprop {Color} --anchor-background-color - The background color of the anchor
 * @cssprop {Color} --anchor-border-color - The border color of the anchor
 * @cssprop {String} --anchor-font-family - The font family for the anchor text
 * @cssprop {String} --anchor-font-letter-spacing - The letter spacing for anchor text
 * @cssprop {String} --anchor-font-line-height - The line height for anchor text
 * @cssprop {String} --anchor-font-size - The font size of the anchor text
 * @cssprop {String} --anchor-font-text-decoration - The text decoration style (underline, none, etc.)
 * @cssprop {String} --anchor-font-text-transform - The text transformation (uppercase, lowercase, etc.)
 * @cssprop {String} --anchor-font-weight - The font weight for anchor text
 * @cssprop {Color} --anchor-foreground-color - The text color of the anchor
 * @cssprop {String} --anchor-gap - The gap CSS custom property.
 * @cssprop {String} --anchor-padding-bottom - The padding bottom CSS custom property.
 * @cssprop {String} --anchor-padding-left - The padding left CSS custom property.
 * @cssprop {String} --anchor-padding-right - The padding right CSS custom property.
 * @cssprop {String} --anchor-padding-top - The padding top CSS custom property.
 * @cssprop {String} --anchor-shadow - The shadow CSS custom property.
 * @cssprop {String} --anchor-shadow-blur - The shadow blur CSS custom property.
 * @cssprop {String} --anchor-shadow-color - The shadow color CSS custom property.
 * @cssprop {String} --anchor-shadow-offset-x - The shadow offset x CSS custom property.
 * @cssprop {String} --anchor-shadow-offset-y - The shadow offset y CSS custom property.
 * @cssprop {String} --anchor-shadow-spread - The shadow spread CSS custom property.
 * @cssprop {String} --anchor-transition-duration - The duration of hover and focus transitions
 * @cssprop {String} --anchor-transition-mode - The transition mode CSS custom property.
 * @cssprop {String} --anchor-transition-property - The transition property CSS custom property.
 * @cssprop {String} --anchor-translate - The translate CSS custom property.
 *
 * @dependency mosaik-text - The Text element.
 *
 * @example
 * Basic anchor link:
 * ```html
 * <mosaik-anchor label="Visit Example.com"></mosaik-anchor>
 * ```
 *
 * @example
 * Anchor with custom underline style:
 * ```html
 * <mosaik-anchor label="About Us" underline="hover"></mosaik-anchor>
 * ```
 *
 * @example
 * Anchor with variant styling:
 * ```html
 * <mosaik-anchor label="Learn More" variant="primary" underline="always"></mosaik-anchor>
 * ```
 *
 * @example
 * Disabled anchor:
 * ```html
 * <mosaik-anchor label="Unavailable Link" disabled></mosaik-anchor>
 * ```
 *
 * @public
 */
export declare class AnchorElement extends AnchorElement_base implements IAnchorElementProps {
    private _href;
    private _download;
    private _rel;
    private _target;
    private _underline;
    private _hasAssignedUnderline;
    /**
     * @public
     */
    constructor();
    /**
     * Returns the `is` property.
     * The `is` property represents natural name of this element.
     *
     * @public
     * @static
     * @readonly
     */
    static get is(): string;
    /**
     * Gets or sets the `href` property.
     *
     * @public
     */
    get href(): string;
    set href(value: string);
    /**
     * Gets or sets the `download` property.
     *
     * @public
     */
    get download(): string;
    set download(value: string);
    /**
     * Gets or sets the `rel` property.
     *
     * @public
     */
    get rel(): string;
    set rel(value: string);
    /**
     * Gets or sets the `target` property.
     *
     * @public
     */
    get target(): string;
    set target(value: string);
    /**
     * Gets or sets the `underline` property.
     *
     * @remarks
     * Determines when the underline is displayed on the link. A theme may draw the default (`always`) without a line at
     * rest (Cosmopolitan underlines a link only while it is hovered or focused); an assigned value, including `always`
     * itself, applies as it is in every theme.
     *
     * @public
     * @attr underline
     */
    get underline(): HyperlinkUnderline;
    set underline(value: HyperlinkUnderline);
}
/**
 * @public
 */
export declare namespace AnchorElement {
    type Props = IAnchorElementProps;
}
/**
 * @public
 */
declare global {
    interface HTMLElementTagNameMap {
        'mosaik-anchor': AnchorElement;
    }
}
export {};
//# sourceMappingURL=AnchorElement.d.ts.map