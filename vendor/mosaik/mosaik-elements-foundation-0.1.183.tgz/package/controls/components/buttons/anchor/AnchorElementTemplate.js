// #region Imports
import { html } from '../../../../dom/Html';
import { classMap, when } from '../../../directives/Directives';
import { ifNonEmpty } from '../../../directives/IfNonEmpty';
// #endregion
/**
 * The template of the `AnchorElement`.
 *
 * @public
 */
export function anchorElementTemplate(e) {
    return html `
        <a part="link"
           href="${ifNonEmpty(e.href)}"
           rel="${ifNonEmpty(e.rel)}"
           target="${ifNonEmpty(e.target)}"
           download="${ifNonEmpty(e.download)}"
           class="${classMap({ [e.underline]: true, assigned: e.hasAssignedUnderline })}">
            <slot name="label">
                ${when(e.label, () => html `
                <mosaik-text part="label"
                             .text="${e.label}"
                             .variant="${e.variant}"
                             ?disabled="${e.disabled}"></mosaik-text>
                `)}
            </slot>
        </a>
    `;
}
//# sourceMappingURL=AnchorElementTemplate.js.map