import { type TemplateResult } from '../../../../dom/Html';
import type { AnchorElement } from './AnchorElement';
/**
 * The template of the `AnchorElement`.
 *
 * @public
 */
export declare function anchorElementTemplate<T extends AnchorElement>(e: T): TemplateResult;
//# sourceMappingURL=AnchorElementTemplate.d.ts.map