export {};
//# sourceMappingURL=IAnchorElementProps.js.map