// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Themeable } from '../../../../controls/behaviors/Themeable';
import { Disableable } from '../../../behaviors/Disableable';
import { Labelable } from '../../../behaviors/Labelable';
import { Variantable } from '../../../behaviors/Variantable';
import { Attribute } from '../../../decorators/AttributeDecorator';
import { Component } from '../../../decorators/ComponentDecorator';
import { Property } from '../../../decorators/PropertyDecorator';
import { HyperlinkUnderline } from '../../../types/HyperlinkUnderline';
import { CustomElement } from '../../abstracts/CustomElement';
import { TextElement } from '../../primitives/text/TextElement';
import { anchorElementTemplate } from './AnchorElementTemplate';
import { anchorElementCosmopolitanStyle } from './themes/AnchorElement.Cosmopolitan';
import { anchorElementJoyStyle } from './themes/AnchorElement.Joy';
import { anchorElementMemphisStyle } from './themes/AnchorElement.Memphis';
import { anchorElementSohoStyle } from './themes/AnchorElement.Soho';
// #endregion
/**
 * Anchor - A hyperlink component for navigation between pages or external resources.
 *
 * @description
 * The Anchor component provides a customizable hyperlink element that functions as a clickable link
 * for navigation. It extends the native anchor element functionality with enhanced styling,
 * accessibility features, and consistent visual appearance across the design system.
 * The component supports various underline styles, target configurations, and download attributes.
 *
 * @name Anchor
 * @element mosaik-anchor
 * @category Links
 *
 * @slot label - The text content or elements to display as the link text
 *
 * @csspart label - The text label area of the anchor
 * @csspart link - The main link element wrapper
 *
 * @cssprop {Color} --anchor-background-color - The background color of the anchor
 * @cssprop {Color} --anchor-border-color - The border color of the anchor
 * @cssprop {String} --anchor-font-family - The font family for the anchor text
 * @cssprop {String} --anchor-font-letter-spacing - The letter spacing for anchor text
 * @cssprop {String} --anchor-font-line-height - The line height for anchor text
 * @cssprop {String} --anchor-font-size - The font size of the anchor text
 * @cssprop {String} --anchor-font-text-decoration - The text decoration style (underline, none, etc.)
 * @cssprop {String} --anchor-font-text-transform - The text transformation (uppercase, lowercase, etc.)
 * @cssprop {String} --anchor-font-weight - The font weight for anchor text
 * @cssprop {Color} --anchor-foreground-color - The text color of the anchor
 * @cssprop {String} --anchor-gap - The gap CSS custom property.
 * @cssprop {String} --anchor-padding-bottom - The padding bottom CSS custom property.
 * @cssprop {String} --anchor-padding-left - The padding left CSS custom property.
 * @cssprop {String} --anchor-padding-right - The padding right CSS custom property.
 * @cssprop {String} --anchor-padding-top - The padding top CSS custom property.
 * @cssprop {String} --anchor-shadow - The shadow CSS custom property.
 * @cssprop {String} --anchor-shadow-blur - The shadow blur CSS custom property.
 * @cssprop {String} --anchor-shadow-color - The shadow color CSS custom property.
 * @cssprop {String} --anchor-shadow-offset-x - The shadow offset x CSS custom property.
 * @cssprop {String} --anchor-shadow-offset-y - The shadow offset y CSS custom property.
 * @cssprop {String} --anchor-shadow-spread - The shadow spread CSS custom property.
 * @cssprop {String} --anchor-transition-duration - The duration of hover and focus transitions
 * @cssprop {String} --anchor-transition-mode - The transition mode CSS custom property.
 * @cssprop {String} --anchor-transition-property - The transition property CSS custom property.
 * @cssprop {String} --anchor-translate - The translate CSS custom property.
 *
 * @dependency mosaik-text - The Text element.
 *
 * @example
 * Basic anchor link:
 * ```html
 * <mosaik-anchor label="Visit Example.com"></mosaik-anchor>
 * ```
 *
 * @example
 * Anchor with custom underline style:
 * ```html
 * <mosaik-anchor label="About Us" underline="hover"></mosaik-anchor>
 * ```
 *
 * @example
 * Anchor with variant styling:
 * ```html
 * <mosaik-anchor label="Learn More" variant="primary" underline="always"></mosaik-anchor>
 * ```
 *
 * @example
 * Disabled anchor:
 * ```html
 * <mosaik-anchor label="Unavailable Link" disabled></mosaik-anchor>
 * ```
 *
 * @public
 */
let AnchorElement = class AnchorElement extends Themeable(Variantable(Disableable(Labelable(CustomElement)))) {
    // #region Fields
    _href;
    _download;
    _rel;
    _target;
    _underline;
    _hasAssignedUnderline;
    // #endregion
    // #region Ctor
    /**
     * @public
     */
    constructor() {
        super();
        this._href = '';
        this._download = '';
        this._rel = '';
        this._target = '';
        this._underline = HyperlinkUnderline.Always;
        this._hasAssignedUnderline = false;
    }
    // #endregion
    // #region Properties
    /**
     * Returns the `is` property.
     * The `is` property represents natural name of this element.
     *
     * @public
     * @static
     * @readonly
     */
    static get is() {
        return 'mosaik-anchor';
    }
    /**
     * Gets or sets the `href` property.
     *
     * @public
     */
    get href() {
        return this._href;
    }
    set href(value) {
        if (this._href !== value) {
            this._href = value;
            this.requestUpdate('href');
        }
    }
    /**
     * Gets or sets the `download` property.
     *
     * @public
     */
    get download() {
        return this._download;
    }
    set download(value) {
        if (this._download !== value) {
            this._download = value;
            this.requestUpdate('download');
        }
    }
    /**
     * Gets or sets the `rel` property.
     *
     * @public
     */
    get rel() {
        return this._rel;
    }
    set rel(value) {
        if (this._rel !== value) {
            this._rel = value;
            this.requestUpdate('rel');
        }
    }
    /**
     * Gets or sets the `target` property.
     *
     * @public
     */
    get target() {
        return this._target;
    }
    set target(value) {
        if (this._target !== value) {
            this._target = value;
            this.requestUpdate('target');
        }
    }
    /**
     * Gets or sets the `underline` property.
     *
     * @remarks
     * Determines when the underline is displayed on the link. A theme may draw the default (`always`) without a line at
     * rest (Cosmopolitan underlines a link only while it is hovered or focused); an assigned value, including `always`
     * itself, applies as it is in every theme.
     *
     * @public
     * @attr underline
     */
    get underline() {
        return this._underline;
    }
    set underline(value) {
        const isFirstAssignment = !this._hasAssignedUnderline;
        this._hasAssignedUnderline = true;
        if (this._underline !== value) {
            this._underline = value;
            this.requestUpdate('underline');
        }
        else if (isFirstAssignment) {
            // Repeating the default still marks the setting as assigned.
            this.requestUpdate();
        }
    }
    /**
     * Gets whether `underline` was assigned, so a theme that draws the default without a line at rest keeps an
     * assigned `always`.
     *
     * @private
     * @internal
     * @hidden
     */
    get hasAssignedUnderline() {
        return this._hasAssignedUnderline;
    }
};
__decorate([
    Property({ type: String }),
    __metadata("design:type", String),
    __metadata("design:paramtypes", [String])
], AnchorElement.prototype, "href", null);
__decorate([
    Property({ type: String }),
    __metadata("design:type", String),
    __metadata("design:paramtypes", [String])
], AnchorElement.prototype, "download", null);
__decorate([
    Property({ type: String }),
    __metadata("design:type", String),
    __metadata("design:paramtypes", [String])
], AnchorElement.prototype, "rel", null);
__decorate([
    Property({ type: String }),
    __metadata("design:type", String),
    __metadata("design:paramtypes", [String])
], AnchorElement.prototype, "target", null);
__decorate([
    Attribute({ type: HyperlinkUnderline }),
    __metadata("design:type", String),
    __metadata("design:paramtypes", [String])
], AnchorElement.prototype, "underline", null);
AnchorElement = __decorate([
    Component({
        selector: 'mosaik-anchor',
        template: anchorElementTemplate,
        themes: {
            joy: anchorElementJoyStyle,
            memphis: anchorElementMemphisStyle,
            cosmopolitan: anchorElementCosmopolitanStyle,
            soho: anchorElementSohoStyle
        },
        imports: [TextElement]
    }),
    __metadata("design:paramtypes", [])
], AnchorElement);
export { AnchorElement };
//# sourceMappingURL=AnchorElement.js.map