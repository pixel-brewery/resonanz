import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function anchorElementSohoStyle(): CSSResult;
//# sourceMappingURL=AnchorElement.Soho.d.ts.map