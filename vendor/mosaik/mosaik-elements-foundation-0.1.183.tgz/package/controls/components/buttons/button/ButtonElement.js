// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { RendererServiceLocator } from '../../../../dom/Renderer';
import { Busyable } from '../../../behaviors/Busyable';
import { ContentAlignable } from '../../../behaviors/ContentAlignable';
import { Fitable } from '../../../behaviors/Fitable';
import { Iconable } from '../../../behaviors/Iconable';
import { Labelable } from '../../../behaviors/Labelable';
import { Orientable } from '../../../behaviors/Orientable';
import { Reversible } from '../../../behaviors/Reversible';
import { Themeable } from '../../../behaviors/Themeable';
import { addInheritanceConsumerController } from '../../../controllers/InheritanceConsumerController';
import { Component } from '../../../decorators/ComponentDecorator';
import { Property } from '../../../decorators/PropertyDecorator';
import { Watch } from '../../../decorators/WatchDecorator';
import { RippleElement } from '../../effects/ripple/RippleElement';
import { StackElement } from '../../layouts/stack/StackElement';
import { IconElement } from '../../media/icon/IconElement';
import { FocusRingElement } from '../../primitives/focus-ring/FocusRingElement';
import { TextElement } from '../../primitives/text/TextElement';
import { ProgressRingElement } from '../../ranges/progress-ring/ProgressRingElement';
import { ButtonBaseElement } from '../abstracts/ButtonBaseElement';
import { buttonElementTemplate } from './ButtonElementTemplate';
import { BUTTON_GROUP_INHERITANCE_CONTEXT } from './ButtonGroupInheritanceContext';
import { buttonElementCosmopolitanStyle } from './themes/ButtonElement.Cosmopolitan';
import { buttonElementJoyStyle } from './themes/ButtonElement.Joy';
import { buttonElementMemphisStyle } from './themes/ButtonElement.Memphis';
import { buttonElementSohoStyle } from './themes/ButtonElement.Soho';
// #endregion
/**
 * The ARIA attributes of the host that the inner control carries - the control takes the focus, so
 * assistive technology reads them there. ID references (`aria-controls`, `aria-describedby`) cannot
 * cross the shadow root and stay on the host.
 *
 * @private
 */
const FORWARDED_ARIA_ATTRIBUTES = ['aria-pressed', 'aria-expanded', 'aria-haspopup'];
/**
 * Button - A versatile interactive element for triggering actions and user interactions.
 *
 * @description
 * The Button component is a fundamental user interface element that provides interactive
 * functionality within applications. It supports various configurations including text labels,
 * icons, busy states, different orientations, and content alignment options. The button can
 * function as a traditional button, a link, or a download trigger, making it highly versatile
 * for different use cases. It includes advanced features like ripple effects, focus rings,
 * progress indicators, and comprehensive accessibility support.
 *
 * @name Button
 * @element mosaik-button
 * @category Buttons
 *
 * @slot icon - The icon displayed alongside or instead of the label
 * @slot label - The text content or label displayed on the button
 * @slot overlay - Additional overlay content such as badges or indicators
 *
 * @csspart button - The main button element container
 * @csspart focusRing - The focus indicator ring for keyboard navigation
 * @csspart icon - The icon display area within the button
 * @csspart innerStack - The innerStack part.
 * @csspart label - The text label display area within the button
 * @csspart progressRing - The busy state progress indicator
 * @csspart ripple - The touch feedback ripple effect container
 *
 * @cssprop {Color} --button-background-color - The background fill color
 * @cssprop {Color} --button-border-color - The border outline color
 * @cssprop {String} --button-border-radius - The corner rounding radius
 * @cssprop {String} --button-border-style - The border line style
 * @cssprop {String} --button-border-width - The border thickness
 * @cssprop {String} --button-focus-ring-active-width - The focus ring active width CSS custom property.
 * @cssprop {String} --button-focus-ring-color - The focus ring color
 * @cssprop {String} --button-focus-ring-inward-offset - The focus ring inward offset CSS custom property.
 * @cssprop {String} --button-focus-ring-outward-offset - The focus ring outward offset CSS custom property.
 * @cssprop {String} --button-font-family - The font family for button text
 * @cssprop {String} --button-font-letter-spacing - The letter spacing for button text
 * @cssprop {String} --button-font-line-height - The line height for button text
 * @cssprop {String} --button-font-size - The font size for button text
 * @cssprop {String} --button-font-text-decoration - The text decoration style
 * @cssprop {String} --button-font-text-transform - The text transformation style
 * @cssprop {String} --button-font-weight - The font weight for button text
 * @cssprop {Color} --button-foreground-color - The text and icon color
 * @cssprop {String} --button-gap - The spacing between icon and label elements
 * @cssprop {String} --button-height - The button height
 * @cssprop {String} --button-icon-min-height - The icon min height CSS custom property.
 * @cssprop {String} --button-icon-min-width - The icon min width CSS custom property.
 * @cssprop {String} --button-min-height - The min height CSS custom property.
 * @cssprop {String} --button-min-width - The min width CSS custom property.
 * @cssprop {String} --button-padding-bottom - The bottom padding inside the button
 * @cssprop {String} --button-padding-left - The left padding inside the button
 * @cssprop {String} --button-padding-right - The right padding inside the button
 * @cssprop {String} --button-padding-top - The top padding inside the button
 * @cssprop {String} --button-progress-ring-width - The progress ring width CSS custom property.
 * @cssprop {Color} --button-ripple-color - The ripple color CSS custom property.
 * @cssprop {String} --button-ripple-duration - The ripple duration CSS custom property.
 * @cssprop {String} --button-shadow - The drop shadow or elevation effect
 * @cssprop {String} --button-shadow-blur - The shadow blur CSS custom property.
 * @cssprop {String} --button-shadow-color - The shadow color CSS custom property.
 * @cssprop {String} --button-shadow-offset-x - The shadow offset x CSS custom property.
 * @cssprop {String} --button-shadow-offset-y - The shadow offset y CSS custom property.
 * @cssprop {String} --button-shadow-spread - The shadow spread CSS custom property.
 * @cssprop {String} --button-transition-duration - The duration of hover/focus transitions
 * @cssprop {String} --button-transition-mode - The timing function for transitions
 * @cssprop {String} --button-transition-property - The CSS properties to transition
 * @cssprop {String} --button-translate - The translate CSS custom property.
 * @cssprop {String} --button-width - The button width (when not using fit behavior)
 *
 * @dependency mosaik-focus-ring - The Focus Ring element.
 * @dependency mosaik-icon - The Icon element.
 * @dependency mosaik-progress-ring - The Progress Ring element.
 * @dependency mosaik-ripple - The Ripple element.
 * @dependency mosaik-stack - The Stack element.
 * @dependency mosaik-text - The Text element.
 *
 * @example
 * Basic button with label:
 * ```html
 * <mosaik-button label="Click Me"></mosaik-button>
 * ```
 *
 * @example
 * Button with variant and appearance:
 * ```html
 * <mosaik-button label="Save" variant="primary" appearance="solid"></mosaik-button>
 * ```
 *
 * @example
 * Disabled button:
 * ```html
 * <mosaik-button label="Unavailable" disabled></mosaik-button>
 * ```
 *
 * @example
 * Busy/loading button:
 * ```html
 * <mosaik-button label="Processing..." is-busy disabled></mosaik-button>
 * ```
 *
 * @example
 * Vertical button layout:
 * ```html
 * <mosaik-button label="Upload" orientation="vertical"></mosaik-button>
 * ```
 *
 * @public
 */
let ButtonElement = class ButtonElement extends Themeable(Reversible(Orientable(ContentAlignable(Fitable(Busyable(Labelable(Iconable(ButtonBaseElement)))))))) {
    // #region Fields
    _inheritance = addInheritanceConsumerController(this, {
        context: BUTTON_GROUP_INHERITANCE_CONTEXT
    });
    _href;
    _download;
    _rel;
    _target;
    // #endregion
    // #region Ctor
    /**
     * Constructs a new instance of the `ButtonElement` class.
     *
     * @public
     */
    constructor() {
        super();
        this._href = '';
        this._download = '';
        this._rel = '';
        this._target = '';
    }
    // #endregion
    // #region Properties
    /**
     * Returns the `is` property.
     *
     * @public
     * @static
     * @readonly
    */
    static get is() {
        return 'mosaik-button';
    }
    /**
     * The observed attributes, including the forwarded ARIA attributes of the host.
     *
     * @public
     * @static
     * @override
     * @readonly
     */
    static get observedAttributes() {
        return [...super.observedAttributes, ...FORWARDED_ARIA_ATTRIBUTES];
    }
    /**
     * @inheritdoc
     * When used inside a ButtonGroup, inherits the group's disabled state unless explicitly set.
     *
     * @public
     * @override
     */
    get disabled() {
        return this._inheritance.get('disabled', super.disabled);
    }
    set disabled(value) {
        this._inheritance.markExplicit('disabled');
        super.disabled = value;
    }
    /**
     * @inheritdoc
     * When used inside a ButtonGroup, inherits the group's appearance unless explicitly set.
     *
     * @public
     * @override
     */
    get appearance() {
        return this._inheritance.get('appearance', super.appearance);
    }
    set appearance(value) {
        this._inheritance.markExplicit('appearance');
        super.appearance = value;
    }
    /**
     * @inheritdoc
     * When used inside a ButtonGroup, inherits the group's variant unless explicitly set.
     *
     * @public
     * @override
     */
    get variant() {
        return this._inheritance.get('variant', super.variant);
    }
    set variant(value) {
        this._inheritance.markExplicit('variant');
        super.variant = value;
    }
    /**
     * Gets or sets the `href` property.
     *
     * @public
     */
    get href() {
        return this._href;
    }
    set href(value) {
        if (this._href !== value) {
            this._href = value;
            this.requestUpdate('href');
        }
    }
    /**
     * Gets or sets the `download` property.
     *
     * @public
     */
    get download() {
        return this._download;
    }
    set download(value) {
        if (this._download !== value) {
            this._download = value;
            this.requestUpdate('download');
        }
    }
    /**
     * Gets or sets the `rel` property.
     *
     * @public
     */
    get rel() {
        return this._rel;
    }
    set rel(value) {
        if (this._rel !== value) {
            this._rel = value;
            this.requestUpdate('rel');
        }
    }
    /**
     * Gets or sets the `target` property.
     *
     * @public
     */
    get target() {
        return this._target;
    }
    set target(value) {
        if (this._target !== value) {
            this._target = value;
            this.requestUpdate('target');
        }
    }
    // #endregion
    // #region Methods
    /**
     * Renders again when a forwarded ARIA attribute of the host changes, so the inner control follows
     * it - e.g. `aria-expanded` of a disclosure toggle.
     *
     * @public
     * @override
     */
    attributeChangedCallback(name, old, value) {
        super.attributeChangedCallback(name, old, value);
        if (old !== value && FORWARDED_ARIA_ATTRIBUTES.includes(name)) {
            this.requestUpdate();
        }
    }
    /**
     * @protected
     */
    onHrefPropertyChanged(_prev, next) {
        if (next === '') {
            RendererServiceLocator.current.removeAttribute(this, 'has-link');
        }
        else {
            RendererServiceLocator.current.setAttribute(this, 'has-link');
        }
    }
};
__decorate([
    Property({ type: String }),
    __metadata("design:type", String),
    __metadata("design:paramtypes", [String])
], ButtonElement.prototype, "href", null);
__decorate([
    Property({ type: String }),
    __metadata("design:type", String),
    __metadata("design:paramtypes", [String])
], ButtonElement.prototype, "download", null);
__decorate([
    Property({ type: String }),
    __metadata("design:type", String),
    __metadata("design:paramtypes", [String])
], ButtonElement.prototype, "rel", null);
__decorate([
    Property({ type: String }),
    __metadata("design:type", String),
    __metadata("design:paramtypes", [String])
], ButtonElement.prototype, "target", null);
__decorate([
    Watch('href'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", void 0)
], ButtonElement.prototype, "onHrefPropertyChanged", null);
ButtonElement = __decorate([
    Component({
        selector: 'mosaik-button',
        template: buttonElementTemplate,
        themes: {
            joy: buttonElementJoyStyle,
            memphis: buttonElementMemphisStyle,
            cosmopolitan: buttonElementCosmopolitanStyle,
            soho: buttonElementSohoStyle
        },
        options: {
            mode: 'open',
            delegatesFocus: true
        },
        imports: [
            StackElement,
            IconElement,
            RippleElement,
            FocusRingElement,
            TextElement,
            ProgressRingElement
        ]
    }),
    __metadata("design:paramtypes", [])
], ButtonElement);
export { ButtonElement };
//# sourceMappingURL=ButtonElement.js.map