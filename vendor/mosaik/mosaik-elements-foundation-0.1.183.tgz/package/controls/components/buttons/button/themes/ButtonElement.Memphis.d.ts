import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function buttonElementMemphisStyle(): CSSResult;
//# sourceMappingURL=ButtonElement.Memphis.d.ts.map