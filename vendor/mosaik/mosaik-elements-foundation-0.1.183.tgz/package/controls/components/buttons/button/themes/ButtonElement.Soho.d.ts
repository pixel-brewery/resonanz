import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function buttonElementSohoStyle(): CSSResult;
//# sourceMappingURL=ButtonElement.Soho.d.ts.map