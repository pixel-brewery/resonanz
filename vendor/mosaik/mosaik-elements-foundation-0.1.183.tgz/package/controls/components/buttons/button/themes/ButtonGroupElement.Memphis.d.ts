import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function buttonGroupElementMemphisStyle(): CSSResult;
//# sourceMappingURL=ButtonGroupElement.Memphis.d.ts.map