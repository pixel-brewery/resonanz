// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Appearanceable } from '../../../behaviors/Appearanceable';
import { Disableable } from '../../../behaviors/Disableable';
import { Orientable } from '../../../behaviors/Orientable';
import { Slottable } from '../../../behaviors/Slottable';
import { Themeable } from '../../../behaviors/Themeable';
import { Variantable } from '../../../behaviors/Variantable';
import { addInheritanceProviderController } from '../../../controllers/InheritanceProviderController';
import { Component } from '../../../decorators/ComponentDecorator';
import { CustomElement } from '../../abstracts/CustomElement';
import { ButtonBaseElement } from '../abstracts/ButtonBaseElement';
import { buttonGroupElementTemplate } from './ButtonGroupElementTemplate';
import { BUTTON_GROUP_INHERITANCE_CONTEXT } from './ButtonGroupInheritanceContext';
import { buttonGroupElementCosmopolitanStyle } from './themes/ButtonGroupElement.Cosmopolitan';
import { buttonGroupElementJoyStyle } from './themes/ButtonGroupElement.Joy';
import { buttonGroupElementMemphisStyle } from './themes/ButtonGroupElement.Memphis';
import { buttonGroupElementSohoStyle } from './themes/ButtonGroupElement.Soho';
// #endregion
/**
 * Button Group - A user interface component for grouping multiple buttons together.
 *
 * @description
 * The Button Group component is designed to group multiple buttons together for a cohesive user interface.
 * It provides a way to organize related actions or options and visually group them as a single unit.
 * Button groups are commonly used in toolbars, navigation menus, and form layouts.
 *
 * @name Button Group
 * @element mosaik-button-group
 * @category Buttons
 *
 * @slot - The default slot.
 *
 * @cssprop {Color} --button-group-background-color
 * @cssprop {Color} --button-group-border-color
 * @cssprop {String} --button-group-border-radius
 * @cssprop {String} --button-group-border-style
 * @cssprop {String} --button-group-border-width
 * @cssprop {String} --button-group-font-family
 * @cssprop {String} --button-group-font-letter-spacing
 * @cssprop {String} --button-group-font-line-height
 * @cssprop {String} --button-group-font-size
 * @cssprop {String} --button-group-font-text-decoration
 * @cssprop {String} --button-group-font-text-transform
 * @cssprop {String} --button-group-font-weight
 * @cssprop {Color} --button-group-foreground-color
 * @cssprop {String} --button-group-gap
 * @cssprop {String} --button-group-padding-bottom
 * @cssprop {String} --button-group-padding-left
 * @cssprop {String} --button-group-padding-right
 * @cssprop {String} --button-group-padding-top
 * @cssprop {String} --button-group-shadow
 * @cssprop {String} --button-group-shadow-blur - The group shadow blur CSS custom property.
 * @cssprop {String} --button-group-shadow-color - The group shadow color CSS custom property.
 * @cssprop {String} --button-group-shadow-offset-x - The group shadow offset x CSS custom property.
 * @cssprop {String} --button-group-shadow-offset-y - The group shadow offset y CSS custom property.
 * @cssprop {String} --button-group-shadow-spread - The group shadow spread CSS custom property.
 * @cssprop {String} --button-group-transition-duration
 * @cssprop {String} --button-group-transition-mode
 * @cssprop {String} --button-group-transition-property
 * @cssprop {String} --button-group-translate - The group translate CSS custom property.
 *
 * @example
 * Basic button group:
 * ```html
 * <mosaik-button-group>
 *   <mosaik-button></mosaik-button>
 *   <mosaik-button></mosaik-button>
 *   <mosaik-button></mosaik-button>
 * </mosaik-button-group>
 * ```
 *
 * @example
 * Vertical group with shared appearance and variant:
 * ```html
 * <mosaik-button-group orientation="vertical" appearance="solid" variant="primary">
 *   <mosaik-button></mosaik-button>
 *   <mosaik-button></mosaik-button>
 * </mosaik-button-group>
 * ```
 *
 * @public
 */
let ButtonGroupElement = class ButtonGroupElement extends Themeable(Orientable(Disableable(Appearanceable(Variantable(Slottable(CustomElement)))))) {
    // #region Fields
    _provider = addInheritanceProviderController(this, {
        context: BUTTON_GROUP_INHERITANCE_CONTEXT,
        values: () => ({
            disabled: this.disabled,
            appearance: this.appearance,
            variant: this.variant
        })
    });
    // #endregion
    // #region Ctor
    /**
     * @public
     */
    constructor() {
        super();
    }
    // #endregion
    // #region Properties
    /**
     * Returns the `is` property.
     * The `is` property represents natural name of this element.
     *
     * @public
     * @static
     * @readonly
     */
    static get is() {
        return 'mosaik-button-group';
    }
    // #endregion
    // #region Methods
    /**
     * @public
     */
    onSlotChanges() {
        const elements = this.getSlotAssignments('')
            .filter((x) => x instanceof ButtonBaseElement);
        for (const [i, e] of elements.entries()) {
            e.classList.add('button-group-button');
            e.classList.toggle('first', i === 0);
            e.classList.toggle('inner', i > 0 && i < elements.length - 1);
            e.classList.toggle('last', i === elements.length - 1);
        }
    }
};
ButtonGroupElement = __decorate([
    Component({
        selector: 'mosaik-button-group',
        template: buttonGroupElementTemplate,
        themes: {
            joy: buttonGroupElementJoyStyle,
            memphis: buttonGroupElementMemphisStyle,
            cosmopolitan: buttonGroupElementCosmopolitanStyle,
            soho: buttonGroupElementSohoStyle
        },
        host: {
            role: 'group'
        },
        imports: []
    }),
    __metadata("design:paramtypes", [])
], ButtonGroupElement);
export { ButtonGroupElement };
//# sourceMappingURL=ButtonGroupElement.js.map