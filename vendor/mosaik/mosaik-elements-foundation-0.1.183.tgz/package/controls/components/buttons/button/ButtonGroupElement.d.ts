import { ISlottable } from '../../../behaviors/Slottable';
import { CustomElement } from '../../abstracts/CustomElement';
import type { IButtonGroupElementProps } from './IButtonGroupElementProps';
declare const ButtonGroupElement_base: (abstract new (...args: Array<any>) => import("../../../behaviors/Themeable").IThemeableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Orientable").IOrientableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Disableable").IDisableableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Appearanceable").IAppearanceableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Variantable").IVariantableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Slottable").ISlottableProps & ISlottable) & typeof CustomElement & import("../../../behaviors/Themeable").IThemeableCtor;
/**
 * Button Group - A user interface component for grouping multiple buttons together.
 *
 * @description
 * The Button Group component is designed to group multiple buttons together for a cohesive user interface.
 * It provides a way to organize related actions or options and visually group them as a single unit.
 * Button groups are commonly used in toolbars, navigation menus, and form layouts.
 *
 * @name Button Group
 * @element mosaik-button-group
 * @category Buttons
 *
 * @slot - The default slot.
 *
 * @cssprop {Color} --button-group-background-color
 * @cssprop {Color} --button-group-border-color
 * @cssprop {String} --button-group-border-radius
 * @cssprop {String} --button-group-border-style
 * @cssprop {String} --button-group-border-width
 * @cssprop {String} --button-group-font-family
 * @cssprop {String} --button-group-font-letter-spacing
 * @cssprop {String} --button-group-font-line-height
 * @cssprop {String} --button-group-font-size
 * @cssprop {String} --button-group-font-text-decoration
 * @cssprop {String} --button-group-font-text-transform
 * @cssprop {String} --button-group-font-weight
 * @cssprop {Color} --button-group-foreground-color
 * @cssprop {String} --button-group-gap
 * @cssprop {String} --button-group-padding-bottom
 * @cssprop {String} --button-group-padding-left
 * @cssprop {String} --button-group-padding-right
 * @cssprop {String} --button-group-padding-top
 * @cssprop {String} --button-group-shadow
 * @cssprop {String} --button-group-shadow-blur - The group shadow blur CSS custom property.
 * @cssprop {String} --button-group-shadow-color - The group shadow color CSS custom property.
 * @cssprop {String} --button-group-shadow-offset-x - The group shadow offset x CSS custom property.
 * @cssprop {String} --button-group-shadow-offset-y - The group shadow offset y CSS custom property.
 * @cssprop {String} --button-group-shadow-spread - The group shadow spread CSS custom property.
 * @cssprop {String} --button-group-transition-duration
 * @cssprop {String} --button-group-transition-mode
 * @cssprop {String} --button-group-transition-property
 * @cssprop {String} --button-group-translate - The group translate CSS custom property.
 *
 * @example
 * Basic button group:
 * ```html
 * <mosaik-button-group>
 *   <mosaik-button></mosaik-button>
 *   <mosaik-button></mosaik-button>
 *   <mosaik-button></mosaik-button>
 * </mosaik-button-group>
 * ```
 *
 * @example
 * Vertical group with shared appearance and variant:
 * ```html
 * <mosaik-button-group orientation="vertical" appearance="solid" variant="primary">
 *   <mosaik-button></mosaik-button>
 *   <mosaik-button></mosaik-button>
 * </mosaik-button-group>
 * ```
 *
 * @public
 */
export declare class ButtonGroupElement extends ButtonGroupElement_base implements IButtonGroupElementProps, ISlottable {
    private readonly _provider;
    /**
     * @public
     */
    constructor();
    /**
     * Returns the `is` property.
     * The `is` property represents natural name of this element.
     *
     * @public
     * @static
     * @readonly
     */
    static get is(): string;
    /**
     * @public
     */
    onSlotChanges(): void;
}
/**
 * @public
 */
export declare namespace ButtonGroupElement {
    type Props = IButtonGroupElementProps;
}
/**
 * @public
 */
declare global {
    interface HTMLElementTagNameMap {
        'mosaik-button-group': ButtonGroupElement;
    }
}
export {};
//# sourceMappingURL=ButtonGroupElement.d.ts.map