// #region Imports
import { html } from '../../../../dom/Html';
import { ifDefined, when } from '../../../directives/Directives';
import { Appearance } from '../../../types/Appearance';
import { IconPosition } from '../../../types/IconPosition';
// #endregion
/**
 * @public
 */
export function buttonElementTemplate(e) {
    return html `
        ${when(!e.disabled, () => html `
        <mosaik-focus-ring part="focusRing"
                           .variant="${e.variant}"
                           .visible="${e.isFocused}"
                           .controlled="${'manual'}"
                           .for="${'button'}"></mosaik-focus-ring>
        `)}
        ${when(!e.href, () => html `
        <button id="button"
                part="button"
                type="${e.type}"
                ?disabled="${e.disabled}"
                aria-label="${ifDefined(e.getAttribute('aria-label') ?? undefined)}"
                aria-pressed="${ifDefined(e.getAttribute('aria-pressed') ?? undefined)}"
                aria-expanded="${ifDefined(e.getAttribute('aria-expanded') ?? undefined)}"
                aria-haspopup="${ifDefined(e.getAttribute('aria-haspopup') ?? undefined)}">
            ${when(!e.disabled && e.ripple, () => html `
            <mosaik-ripple part="ripple"
                           .variant="${e.variant}"
                           .for="${'button'}"></mosaik-ripple>
            `)}
            <mosaik-stack part="innerStack"
                          .orientation="${e.orientation}"
                          .verticalAlignment="${e.verticalContentAlignment}"
                          .horizontalAlignment="${e.horizontalContentAlignment}"
                          .reverse="${e.iconPosition === IconPosition.After}">
                <slot name="icon">
                ${when(e.icon, () => html `
                    <mosaik-icon part="icon"
                                 .appearance="${Appearance.Plain}"
                                 .variant="${e.variant}"
                                 .icon="${e.icon}"
                                 .size="${e.iconSize ?? e.size}"
                                 .inline="${true}"
                                 ?disabled="${e.disabled}"></mosaik-icon>
                `)}
                </slot>
                <slot name="label">
                ${when(e.label, () => html `
                    <mosaik-text part="label"
                                 .text="${e.label}"
                                 .variant="${e.variant}"
                                 ?disabled="${e.disabled}"></mosaik-text>
                `)}
                </slot>
            </mosaik-stack>
        </button>
        `, () => html `
        <a id="button"
           part="button"
           href="${ifDefined(e.href || undefined)}"
           rel="${ifDefined(e.rel || undefined)}"
           target="${ifDefined(e.target || undefined)}"
           download="${ifDefined(e.download || undefined)}"
           aria-label="${ifDefined(e.getAttribute('aria-label') ?? undefined)}"
           aria-pressed="${ifDefined(e.getAttribute('aria-pressed') ?? undefined)}"
           aria-expanded="${ifDefined(e.getAttribute('aria-expanded') ?? undefined)}"
           aria-haspopup="${ifDefined(e.getAttribute('aria-haspopup') ?? undefined)}"
           aria-disabled="${ifDefined(e.disabled ? 'true' : undefined)}"
           tabindex="${ifDefined(e.disabled ? '-1' : undefined)}">
            ${when(!e.disabled && e.ripple, () => html `
            <mosaik-ripple part="ripple"
                           .variant="${e.variant}"
                           .for="${'button'}"></mosaik-ripple>
            `)}
            <mosaik-stack part="innerStack"
                          .orientation="${e.orientation}"
                          .verticalAlignment="${e.verticalContentAlignment}"
                          .horizontalAlignment="${e.horizontalContentAlignment}"
                          .reverse="${e.iconPosition === IconPosition.After}">
                <slot name="icon">
                ${when(e.icon, () => html `
                    <mosaik-icon part="icon"
                                 .appearance="${Appearance.Plain}"
                                 .variant="${e.variant}"
                                 .icon="${e.icon}"
                                 .size="${e.iconSize ?? e.size}"
                                 .inline="${true}"
                                 ?disabled="${e.disabled}"></mosaik-icon>
                `)}
                </slot>
                <slot name="label">
                ${when(e.label, () => html `
                    <mosaik-text part="label"
                                 .text="${e.label}"
                                 .variant="${e.variant}"
                                 ?disabled="${e.disabled}"></mosaik-text>
                `)}
                </slot>
            </mosaik-stack>
        </a>
        `)}
        ${when(e.isBusy, () => html `
        <mosaik-progress-ring part="progressRing"
                              .lang="${e.lang}"
                              .dir="${e.dir}"
                              .radius="${'12px'}"
                              .variant="${e.variant}"
                              .isIndeterminate="${true}"
                              ?disabled="${e.disabled}"></mosaik-progress-ring>
        `)}
        <slot name="overlay"></slot>
    `;
}
//# sourceMappingURL=ButtonElementTemplate.js.map