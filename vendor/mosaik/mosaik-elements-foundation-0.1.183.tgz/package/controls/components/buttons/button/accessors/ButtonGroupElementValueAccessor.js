"use strict";
// // #region Imports
// import { ElementValueAccessorBase } from '../../../../../forms/accessors/abstracts/ElementValueAccessorBase';
// import type { ElementValueAccessorFn } from '../../../../../forms/accessors/functions/ElementValueAccessorFn';
// import { ButtonGroupElement } from '../ButtonGroupElement';
// import type { CheckBoxGroupElement } from '../CheckBoxGroupElement';
// // #endregion
// /**
//  * @public
//  */
// export class ButtonGroupControlValueAccessorDirective
//     extends ElementValueAccessorBase<ButtonGroupElement> {
//     // #region Methods
//     /**
//      * @public
//      */
//     public hostConnected(): void {
//         this._subscriptions.add(
//             this.host.changed.subscribe((x) => this.onChanged(x.values))
//         );
//     }
//     /**
//      * @public
//      */
//     public ngOnDestroy(): void {
//         this._subscriptions.unsubscribe();
//     }
//     /**
//      * @public
//      */
//     public writeValue(value: any): void {
//         if (this._element.multiSelection) {
//             if (Array.isArray(value)) {
//                 this._element.values = value;
//             } else {
//                 const exceptionMessage = 'A object is not assignable to values when multi selection is true.';
//                 throw new Exception(exceptionMessage);
//             }
//         } else {
//             if (!Array.isArray(value)) {
//                 this._element.values = value;
//             } else {
//                 const exceptionMessage = 'A array is not assignable to values when multi selection in false';
//                 throw new Exception(exceptionMessage);
//             }
//         }
//     }
//     /**
//      * @public
//      */
//     public registerOnChange(fn: (_: any) => void): void {
//         this._onChangeCallback = fn;
//     }
//     /**
//      * @public
//      */
//     public registerOnTouched(fn: () => void): void {
//         this._onTouchedCallback = fn;
//     }
//     /**
//      * @private
//      */
//     private onChanged(value: any): void {
//         this._onChangeCallback(value);
//     }
//     // #endregion
// }
//# sourceMappingURL=ButtonGroupElementValueAccessor.js.map