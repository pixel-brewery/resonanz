import type { IContentAlignableProps } from '../../../behaviors/ContentAlignable';
import type { IBusyableProps } from '../../../behaviors/Busyable';
import type { IFitableProps } from '../../../behaviors/Fitable';
import type { IIconableProps } from '../../../behaviors/Iconable';
import type { ILabelableProps } from '../../../behaviors/Labelable';
import type { IOrientableProps } from '../../../behaviors/Orientable';
import type { IReversibleProps } from '../../../behaviors/Reversible';
import type { IconPosition } from '../../../types/IconPosition';
import type { Size } from '../../../types/Size';
import type { IButtonBaseElementProps } from '../abstracts/IButtonBaseElementProps';
import type { IconSource } from '@pixel-brewery/mosaik-icons';
/**
 * Represents the `IButtonElementProps` interface.
 *
 * @public
 */
export interface IButtonElementProps extends IButtonBaseElementProps, IOrientableProps, IBusyableProps, IReversibleProps, IFitableProps, ILabelableProps, IIconableProps, IContentAlignableProps {
    icon: IconSource;
    iconSize: Size | null;
    iconPosition: IconPosition;
}
//# sourceMappingURL=IButtonElementProps.d.ts.map