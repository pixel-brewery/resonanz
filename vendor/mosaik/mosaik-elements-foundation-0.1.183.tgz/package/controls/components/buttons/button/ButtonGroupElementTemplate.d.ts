import { type TemplateResult } from '../../../../dom/Html';
import type { ButtonGroupElement } from './ButtonGroupElement';
/**
 * The template of the `ButtonGroupElement`.
 *
 * @public
 */
export declare function buttonGroupElementTemplate<T extends ButtonGroupElement>(e: T): TemplateResult;
//# sourceMappingURL=ButtonGroupElementTemplate.d.ts.map