import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function buttonElementCosmopolitanStyle(): CSSResult;
//# sourceMappingURL=ButtonElement.Cosmopolitan.d.ts.map