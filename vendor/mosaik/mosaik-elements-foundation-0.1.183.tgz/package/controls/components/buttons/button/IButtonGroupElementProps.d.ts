import type { IAppearanceableProps } from '../../../behaviors/Appearanceable';
import type { IDisableableProps } from '../../../behaviors/Disableable';
import type { IOrientableProps } from '../../../behaviors/Orientable';
import type { ISlottableProps } from '../../../behaviors/Slottable';
import type { IVariantableProps } from '../../../behaviors/Variantable';
/**
 * Represents the `IButtonGroupElementProps` interface.
 *
 * @public
 */
export interface IButtonGroupElementProps extends IDisableableProps, IOrientableProps, IVariantableProps, IAppearanceableProps, ISlottableProps {
}
//# sourceMappingURL=IButtonGroupElementProps.d.ts.map