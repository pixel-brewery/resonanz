// #region Imports
export {};
//# sourceMappingURL=IButtonElementProps.js.map