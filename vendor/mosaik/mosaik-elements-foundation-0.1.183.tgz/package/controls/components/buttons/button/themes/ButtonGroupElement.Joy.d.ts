import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function buttonGroupElementJoyStyle(): CSSResult;
//# sourceMappingURL=ButtonGroupElement.Joy.d.ts.map