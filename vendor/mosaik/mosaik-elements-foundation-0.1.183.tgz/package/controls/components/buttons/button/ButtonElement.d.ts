import type { Appearance } from '../../../types/Appearance';
import type { Variant } from '../../../types/Variant';
import { ButtonBaseElement } from '../abstracts/ButtonBaseElement';
import type { IButtonElementProps } from './IButtonElementProps';
import type { IButtonLinkElementProps } from './IButtonLinkElementProps';
declare const ButtonElement_base: (abstract new (...args: Array<any>) => import("../../../behaviors/Themeable").IThemeableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Reversible").IReversibleProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Orientable").IOrientableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/ContentAlignable").IContentAlignableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Fitable").IFitableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Busyable").IBusyableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Labelable").ILabelableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Iconable").IIconableProps) & typeof ButtonBaseElement & import("../../../behaviors/Themeable").IThemeableCtor;
/**
 * Button - A versatile interactive element for triggering actions and user interactions.
 *
 * @description
 * The Button component is a fundamental user interface element that provides interactive
 * functionality within applications. It supports various configurations including text labels,
 * icons, busy states, different orientations, and content alignment options. The button can
 * function as a traditional button, a link, or a download trigger, making it highly versatile
 * for different use cases. It includes advanced features like ripple effects, focus rings,
 * progress indicators, and comprehensive accessibility support.
 *
 * @name Button
 * @element mosaik-button
 * @category Buttons
 *
 * @slot icon - The icon displayed alongside or instead of the label
 * @slot label - The text content or label displayed on the button
 * @slot overlay - Additional overlay content such as badges or indicators
 *
 * @csspart button - The main button element container
 * @csspart focusRing - The focus indicator ring for keyboard navigation
 * @csspart icon - The icon display area within the button
 * @csspart innerStack - The innerStack part.
 * @csspart label - The text label display area within the button
 * @csspart progressRing - The busy state progress indicator
 * @csspart ripple - The touch feedback ripple effect container
 *
 * @cssprop {Color} --button-background-color - The background fill color
 * @cssprop {Color} --button-border-color - The border outline color
 * @cssprop {String} --button-border-radius - The corner rounding radius
 * @cssprop {String} --button-border-style - The border line style
 * @cssprop {String} --button-border-width - The border thickness
 * @cssprop {String} --button-focus-ring-active-width - The focus ring active width CSS custom property.
 * @cssprop {String} --button-focus-ring-color - The focus ring color
 * @cssprop {String} --button-focus-ring-inward-offset - The focus ring inward offset CSS custom property.
 * @cssprop {String} --button-focus-ring-outward-offset - The focus ring outward offset CSS custom property.
 * @cssprop {String} --button-font-family - The font family for button text
 * @cssprop {String} --button-font-letter-spacing - The letter spacing for button text
 * @cssprop {String} --button-font-line-height - The line height for button text
 * @cssprop {String} --button-font-size - The font size for button text
 * @cssprop {String} --button-font-text-decoration - The text decoration style
 * @cssprop {String} --button-font-text-transform - The text transformation style
 * @cssprop {String} --button-font-weight - The font weight for button text
 * @cssprop {Color} --button-foreground-color - The text and icon color
 * @cssprop {String} --button-gap - The spacing between icon and label elements
 * @cssprop {String} --button-height - The button height
 * @cssprop {String} --button-icon-min-height - The icon min height CSS custom property.
 * @cssprop {String} --button-icon-min-width - The icon min width CSS custom property.
 * @cssprop {String} --button-min-height - The min height CSS custom property.
 * @cssprop {String} --button-min-width - The min width CSS custom property.
 * @cssprop {String} --button-padding-bottom - The bottom padding inside the button
 * @cssprop {String} --button-padding-left - The left padding inside the button
 * @cssprop {String} --button-padding-right - The right padding inside the button
 * @cssprop {String} --button-padding-top - The top padding inside the button
 * @cssprop {String} --button-progress-ring-width - The progress ring width CSS custom property.
 * @cssprop {Color} --button-ripple-color - The ripple color CSS custom property.
 * @cssprop {String} --button-ripple-duration - The ripple duration CSS custom property.
 * @cssprop {String} --button-shadow - The drop shadow or elevation effect
 * @cssprop {String} --button-shadow-blur - The shadow blur CSS custom property.
 * @cssprop {String} --button-shadow-color - The shadow color CSS custom property.
 * @cssprop {String} --button-shadow-offset-x - The shadow offset x CSS custom property.
 * @cssprop {String} --button-shadow-offset-y - The shadow offset y CSS custom property.
 * @cssprop {String} --button-shadow-spread - The shadow spread CSS custom property.
 * @cssprop {String} --button-transition-duration - The duration of hover/focus transitions
 * @cssprop {String} --button-transition-mode - The timing function for transitions
 * @cssprop {String} --button-transition-property - The CSS properties to transition
 * @cssprop {String} --button-translate - The translate CSS custom property.
 * @cssprop {String} --button-width - The button width (when not using fit behavior)
 *
 * @dependency mosaik-focus-ring - The Focus Ring element.
 * @dependency mosaik-icon - The Icon element.
 * @dependency mosaik-progress-ring - The Progress Ring element.
 * @dependency mosaik-ripple - The Ripple element.
 * @dependency mosaik-stack - The Stack element.
 * @dependency mosaik-text - The Text element.
 *
 * @example
 * Basic button with label:
 * ```html
 * <mosaik-button label="Click Me"></mosaik-button>
 * ```
 *
 * @example
 * Button with variant and appearance:
 * ```html
 * <mosaik-button label="Save" variant="primary" appearance="solid"></mosaik-button>
 * ```
 *
 * @example
 * Disabled button:
 * ```html
 * <mosaik-button label="Unavailable" disabled></mosaik-button>
 * ```
 *
 * @example
 * Busy/loading button:
 * ```html
 * <mosaik-button label="Processing..." is-busy disabled></mosaik-button>
 * ```
 *
 * @example
 * Vertical button layout:
 * ```html
 * <mosaik-button label="Upload" orientation="vertical"></mosaik-button>
 * ```
 *
 * @public
 */
export declare class ButtonElement extends ButtonElement_base implements IButtonElementProps, IButtonLinkElementProps {
    private readonly _inheritance;
    private _href;
    private _download;
    private _rel;
    private _target;
    /**
     * Constructs a new instance of the `ButtonElement` class.
     *
     * @public
     */
    constructor();
    /**
     * Returns the `is` property.
     *
     * @public
     * @static
     * @readonly
    */
    static get is(): string;
    /**
     * The observed attributes, including the forwarded ARIA attributes of the host.
     *
     * @public
     * @static
     * @override
     * @readonly
     */
    static get observedAttributes(): Array<string>;
    /**
     * @inheritdoc
     * When used inside a ButtonGroup, inherits the group's disabled state unless explicitly set.
     *
     * @public
     * @override
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * @inheritdoc
     * When used inside a ButtonGroup, inherits the group's appearance unless explicitly set.
     *
     * @public
     * @override
     */
    get appearance(): Appearance;
    set appearance(value: Appearance);
    /**
     * @inheritdoc
     * When used inside a ButtonGroup, inherits the group's variant unless explicitly set.
     *
     * @public
     * @override
     */
    get variant(): Variant;
    set variant(value: Variant);
    /**
     * Gets or sets the `href` property.
     *
     * @public
     */
    get href(): string;
    set href(value: string);
    /**
     * Gets or sets the `download` property.
     *
     * @public
     */
    get download(): string;
    set download(value: string);
    /**
     * Gets or sets the `rel` property.
     *
     * @public
     */
    get rel(): string;
    set rel(value: string);
    /**
     * Gets or sets the `target` property.
     *
     * @public
     */
    get target(): string;
    set target(value: string);
    /**
     * Renders again when a forwarded ARIA attribute of the host changes, so the inner control follows
     * it - e.g. `aria-expanded` of a disclosure toggle.
     *
     * @public
     * @override
     */
    attributeChangedCallback(name: string, old: string | null, value: string | null): void;
    /**
     * @protected
     */
    protected onHrefPropertyChanged(_prev: string, next: string): void;
}
/**
 * @public
 */
export declare namespace ButtonElement {
    type Props = IButtonElementProps;
}
/**
 * @public
 */
declare global {
    interface HTMLElementTagNameMap {
        'mosaik-button': ButtonElement;
    }
}
export {};
//# sourceMappingURL=ButtonElement.d.ts.map