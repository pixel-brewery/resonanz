// #region Imports
import { html } from '../../../../dom/Html';
// #endregion
/**
 * The template of the `ButtonGroupElement`.
 *
 * @public
 */
export function buttonGroupElementTemplate(e) {
    return html `
        <slot></slot>
    `;
}
//# sourceMappingURL=ButtonGroupElementTemplate.js.map