import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function buttonElementFluentStyle(): CSSResult;
//# sourceMappingURL=ButtonElement.Fluent.d.ts.map