import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function buttonElementJoyStyle(): CSSResult;
//# sourceMappingURL=ButtonElement.Joy.d.ts.map