export {};
//# sourceMappingURL=IButtonLinkElementProps.js.map