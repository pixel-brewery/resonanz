import type { Appearance } from '../../../types/Appearance';
import type { Variant } from '../../../types/Variant';
/**
 * Interface for properties inherited by child ButtonElements.
 *
 * @public
 */
export interface IButtonGroupInherited {
    /**
     * Inherited disabled state.
     */
    disabled?: boolean;
    /**
     * Inherited appearance.
     */
    appearance?: Appearance;
    /**
     * Inherited variant.
     */
    variant?: Variant;
}
/**
 * Context for ButtonGroup → Button inheritance.
 *
 * @public
 */
export declare const BUTTON_GROUP_INHERITANCE_CONTEXT: {
    __context__: Partial<IButtonGroupInherited>;
};
//# sourceMappingURL=ButtonGroupInheritanceContext.d.ts.map