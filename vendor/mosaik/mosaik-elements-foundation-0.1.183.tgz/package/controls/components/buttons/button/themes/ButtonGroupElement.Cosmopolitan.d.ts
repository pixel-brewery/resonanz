import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function buttonGroupElementCosmopolitanStyle(): CSSResult;
//# sourceMappingURL=ButtonGroupElement.Cosmopolitan.d.ts.map