import { type TemplateResult } from '../../../../dom/Html';
import type { ButtonElement } from './ButtonElement';
/**
 * @public
 */
export declare function buttonElementTemplate<T extends ButtonElement>(e: T): TemplateResult;
//# sourceMappingURL=ButtonElementTemplate.d.ts.map