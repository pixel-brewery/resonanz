import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function buttonGroupElementSohoStyle(): CSSResult;
//# sourceMappingURL=ButtonGroupElement.Soho.d.ts.map