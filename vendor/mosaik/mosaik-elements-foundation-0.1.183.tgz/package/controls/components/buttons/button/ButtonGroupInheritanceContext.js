// #region Imports
import { createContext } from '@lit/context';
/**
 * Context for ButtonGroup → Button inheritance.
 *
 * @public
 */
export const BUTTON_GROUP_INHERITANCE_CONTEXT = createContext(Symbol.for('mosaik:button-group:inheritance'));
//# sourceMappingURL=ButtonGroupInheritanceContext.js.map