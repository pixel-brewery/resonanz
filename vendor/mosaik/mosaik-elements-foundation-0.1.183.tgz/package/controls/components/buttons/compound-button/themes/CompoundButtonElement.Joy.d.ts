import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function compoundButtonElementJoyStyle(): CSSResult;
//# sourceMappingURL=CompoundButtonElement.Joy.d.ts.map