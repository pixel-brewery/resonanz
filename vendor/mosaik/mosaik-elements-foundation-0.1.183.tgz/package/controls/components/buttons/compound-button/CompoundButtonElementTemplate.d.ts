import { type TemplateResult } from '../../../../dom/Html';
import type { CompoundButtonElement } from './CompoundButtonElement';
/**
 * The template of the `CompoundButtonElement`.
 *
 * @public
 */
export declare function compoundButtonElementTemplate<T extends CompoundButtonElement>(e: T): TemplateResult;
//# sourceMappingURL=CompoundButtonElementTemplate.d.ts.map