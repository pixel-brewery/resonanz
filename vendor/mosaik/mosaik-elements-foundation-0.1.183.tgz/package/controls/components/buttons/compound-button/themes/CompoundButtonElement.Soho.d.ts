import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function compoundButtonElementSohoStyle(): CSSResult;
//# sourceMappingURL=CompoundButtonElement.Soho.d.ts.map