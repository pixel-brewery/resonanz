import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function compoundButtonElementMemphisStyle(): CSSResult;
//# sourceMappingURL=CompoundButtonElement.Memphis.d.ts.map