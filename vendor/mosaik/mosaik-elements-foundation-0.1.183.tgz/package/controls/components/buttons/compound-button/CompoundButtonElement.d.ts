import { ButtonBaseElement } from '../abstracts/ButtonBaseElement';
import type { ICompoundButtonElementProps } from './ICompoundButtonElementProps';
declare const CompoundButtonElement_base: (abstract new (...args: Array<any>) => import("../../../../controls/behaviors/Themeable").IThemeableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Reversible").IReversibleProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Orientable").IOrientableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/ContentAlignable").IContentAlignableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Fitable").IFitableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Busyable").IBusyableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Labelable").ILabelableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Iconable").IIconableProps) & typeof ButtonBaseElement & import("../../../../controls/behaviors/Themeable").IThemeableCtor;
/**
 * CompoundButton - An enhanced button component with hierarchical content support for complex interactions.
 *
 * @description
 * The CompoundButton component provides a sophisticated interactive element that combines primary
 * and secondary content areas within a single button interface. It supports multiple content slots
 * including main labels, sub-labels, icons, prefix/suffix areas, and overlays, enabling rich
 * information presentation for navigation, action cards, or complex user interactions. The component
 * includes advanced features like ripple effects, focus rings, progress indicators, navigation
 * chevrons, and comprehensive accessibility support, making it ideal for interfaces requiring
 * detailed button content with hierarchical information display.
 *
 * @name CompoundButton
 * @element mosaik-compound-button
 * @category Buttons
 *
 * @slot label - Primary text content area for main button labeling
 * @slot overlay - Overlay content area for badges, notifications, or status indicators
 * @slot prefix - Leading content area displayed before the main label and icon
 * @slot subLabel - Secondary text content area for descriptions or additional contextual information
 * @slot suffix - Trailing content area displayed after all main content
 *
 * @csspart button - The main button element container
 * @csspart focusRing - The focus indicator ring for keyboard navigation accessibility
 * @csspart icon - The icon display area within the button
 * @csspart icon nav - The icon nav part.
 * @csspart innerStack - The internal stack layout container for organizing content
 * @csspart label - The primary text label display area
 * @csspart progressRing - The busy state progress indicator
 * @csspart ripple - The touch feedback ripple effect container
 * @csspart subLabel - The secondary text label display area for descriptions
 *
 * @cssprop {String} --compound-button-background-color - The background fill color
 * @cssprop {String} --compound-button-border-color - The border outline color
 * @cssprop {String} --compound-button-border-radius - The corner rounding radius
 * @cssprop {String} --compound-button-border-style - The border line style
 * @cssprop {String} --compound-button-border-width - The border thickness
 * @cssprop {String} --compound-button-focus-ring-active-width - The focus ring width when active (from focusRing mixin)
 * @cssprop {String} --compound-button-focus-ring-color - The focus ring color (from focusRing mixin)
 * @cssprop {String} --compound-button-focus-ring-inward-offset - The focus ring inward offset (from focusRing mixin)
 * @cssprop {String} --compound-button-focus-ring-outward-offset - The focus ring outward offset (from focusRing mixin)
 * @cssprop {String} --compound-button-font-family - The font family for button text content
 * @cssprop {String} --compound-button-font-letter-spacing - The letter spacing for button text
 * @cssprop {String} --compound-button-font-line-height - The line height for button text
 * @cssprop {String} --compound-button-font-size - The font size for primary button text
 * @cssprop {String} --compound-button-font-text-decoration - The text decoration style for button text
 * @cssprop {String} --compound-button-font-text-transform - The text transformation style for button text
 * @cssprop {String} --compound-button-font-weight - The font weight for button text
 * @cssprop {String} --compound-button-foreground-color - The text and icon color
 * @cssprop {String} --compound-button-gap - The spacing between button content elements
 * @cssprop {String} --compound-button-height - The button height
 * @cssprop {String} --compound-button-icon-min-height - The minimum height for icon display area
 * @cssprop {String} --compound-button-icon-min-width - The minimum width for icon display area
 * @cssprop {String} --compound-button-min-height - The minimum button height
 * @cssprop {String} --compound-button-min-width - The minimum button width
 * @cssprop {String} --compound-button-padding-bottom - The bottom padding inside the button
 * @cssprop {String} --compound-button-padding-left - The left padding inside the button
 * @cssprop {String} --compound-button-padding-right - The right padding inside the button
 * @cssprop {String} --compound-button-padding-top - The top padding inside the button
 * @cssprop {String} --compound-button-progress-ring-width - The button progress ring width CSS custom property.
 * @cssprop {String} --compound-button-ripple-color - The ripple effect color (from ripple mixin)
 * @cssprop {String} --compound-button-ripple-duration - The ripple effect animation duration (from ripple mixin)
 * @cssprop {String} --compound-button-shadow - The drop shadow or elevation effect
 * @cssprop {String} --compound-button-shadow-blur - The button shadow blur CSS custom property.
 * @cssprop {String} --compound-button-shadow-color - The button shadow color CSS custom property.
 * @cssprop {String} --compound-button-shadow-offset-x - The button shadow offset x CSS custom property.
 * @cssprop {String} --compound-button-shadow-offset-y - The button shadow offset y CSS custom property.
 * @cssprop {String} --compound-button-shadow-spread - The button shadow spread CSS custom property.
 * @cssprop {String} --compound-button-transition-duration - The duration of hover and focus transitions
 * @cssprop {String} --compound-button-transition-mode - The timing function for transitions
 * @cssprop {String} --compound-button-transition-property - The CSS properties to animate during transitions
 * @cssprop {String} --compound-button-translate - The transform translation offset
 * @cssprop {String} --compound-button-width - The button width
 *
 * @dependency mosaik-focus-ring - The Focus Ring element.
 * @dependency mosaik-icon - The Icon element.
 * @dependency mosaik-progress-ring - The Progress Ring element.
 * @dependency mosaik-ripple - The Ripple element.
 * @dependency mosaik-stack - The Stack element.
 * @dependency mosaik-text - The Text element.
 *
 * @example
 * Basic compound button with label:
 * ```html
 * <mosaik-compound-button label="Settings"></mosaik-compound-button>
 * ```
 *
 * @example
 * Navigation compound button with chevron:
 * ```html
 * <mosaik-compound-button label="Account Settings"
 *                         is-navigation
 *                         variant="primary"></mosaik-compound-button>
 * ```
 *
 * @public
 */
export declare class CompoundButtonElement extends CompoundButtonElement_base implements ICompoundButtonElementProps {
    private _subLabel;
    private _isNavigation;
    /**
     * @public
     */
    constructor();
    /**
     * Returns the `is` property.
     * The `is` property represents natural name of this element.
     *
     * @public
     * @static
     * @readonly
     */
    static get is(): string;
    /**
     * Gets or sets the `subLabel` property.
     *
     * @public
     */
    get subLabel(): string;
    set subLabel(value: string);
    /**
     * Gets or sets the `isNavigation` property.
     *
     * @public
     * @attr is-navigation
     */
    get isNavigation(): boolean;
    set isNavigation(value: boolean);
}
/**
 * @public
 */
export declare namespace CompoundButtonElement {
    type Props = ICompoundButtonElementProps;
}
/**
 * @public
 */
declare global {
    interface HTMLElementTagNameMap {
        'mosaik-compound-button': CompoundButtonElement;
    }
}
export {};
//# sourceMappingURL=CompoundButtonElement.d.ts.map