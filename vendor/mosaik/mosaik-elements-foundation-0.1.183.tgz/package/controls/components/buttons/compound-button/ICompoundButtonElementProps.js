// #region Imports
export {};
//# sourceMappingURL=ICompoundButtonElementProps.js.map