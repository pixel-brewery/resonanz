import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function compoundButtonElementCosmopolitanStyle(): CSSResult;
//# sourceMappingURL=CompoundButtonElement.Cosmopolitan.d.ts.map