// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Themeable } from '../../../../controls/behaviors/Themeable';
import { Busyable } from '../../../behaviors/Busyable';
import { ContentAlignable } from '../../../behaviors/ContentAlignable';
import { Fitable } from '../../../behaviors/Fitable';
import { Iconable } from '../../../behaviors/Iconable';
import { Labelable } from '../../../behaviors/Labelable';
import { Orientable } from '../../../behaviors/Orientable';
import { Reversible } from '../../../behaviors/Reversible';
import { Attribute } from '../../../decorators/AttributeDecorator';
import { Component } from '../../../decorators/ComponentDecorator';
import { Property } from '../../../decorators/PropertyDecorator';
import { RippleElement } from '../../effects/ripple/RippleElement';
import { StackElement } from '../../layouts/stack/StackElement';
import { IconElement } from '../../media/icon/IconElement';
import { FocusRingElement } from '../../primitives/focus-ring/FocusRingElement';
import { TextElement } from '../../primitives/text/TextElement';
import { ProgressRingElement } from '../../ranges/progress-ring/ProgressRingElement';
import { ButtonBaseElement } from '../abstracts/ButtonBaseElement';
import { compoundButtonElementTemplate } from './CompoundButtonElementTemplate';
import { compoundButtonElementCosmopolitanStyle } from './themes/CompoundButtonElement.Cosmopolitan';
import { compoundButtonElementJoyStyle } from './themes/CompoundButtonElement.Joy';
import { compoundButtonElementMemphisStyle } from './themes/CompoundButtonElement.Memphis';
import { compoundButtonElementSohoStyle } from './themes/CompoundButtonElement.Soho';
// #endregion
/**
 * CompoundButton - An enhanced button component with hierarchical content support for complex interactions.
 *
 * @description
 * The CompoundButton component provides a sophisticated interactive element that combines primary
 * and secondary content areas within a single button interface. It supports multiple content slots
 * including main labels, sub-labels, icons, prefix/suffix areas, and overlays, enabling rich
 * information presentation for navigation, action cards, or complex user interactions. The component
 * includes advanced features like ripple effects, focus rings, progress indicators, navigation
 * chevrons, and comprehensive accessibility support, making it ideal for interfaces requiring
 * detailed button content with hierarchical information display.
 *
 * @name CompoundButton
 * @element mosaik-compound-button
 * @category Buttons
 *
 * @slot label - Primary text content area for main button labeling
 * @slot overlay - Overlay content area for badges, notifications, or status indicators
 * @slot prefix - Leading content area displayed before the main label and icon
 * @slot subLabel - Secondary text content area for descriptions or additional contextual information
 * @slot suffix - Trailing content area displayed after all main content
 *
 * @csspart button - The main button element container
 * @csspart focusRing - The focus indicator ring for keyboard navigation accessibility
 * @csspart icon - The icon display area within the button
 * @csspart icon nav - The icon nav part.
 * @csspart innerStack - The internal stack layout container for organizing content
 * @csspart label - The primary text label display area
 * @csspart progressRing - The busy state progress indicator
 * @csspart ripple - The touch feedback ripple effect container
 * @csspart subLabel - The secondary text label display area for descriptions
 *
 * @cssprop {String} --compound-button-background-color - The background fill color
 * @cssprop {String} --compound-button-border-color - The border outline color
 * @cssprop {String} --compound-button-border-radius - The corner rounding radius
 * @cssprop {String} --compound-button-border-style - The border line style
 * @cssprop {String} --compound-button-border-width - The border thickness
 * @cssprop {String} --compound-button-focus-ring-active-width - The focus ring width when active (from focusRing mixin)
 * @cssprop {String} --compound-button-focus-ring-color - The focus ring color (from focusRing mixin)
 * @cssprop {String} --compound-button-focus-ring-inward-offset - The focus ring inward offset (from focusRing mixin)
 * @cssprop {String} --compound-button-focus-ring-outward-offset - The focus ring outward offset (from focusRing mixin)
 * @cssprop {String} --compound-button-font-family - The font family for button text content
 * @cssprop {String} --compound-button-font-letter-spacing - The letter spacing for button text
 * @cssprop {String} --compound-button-font-line-height - The line height for button text
 * @cssprop {String} --compound-button-font-size - The font size for primary button text
 * @cssprop {String} --compound-button-font-text-decoration - The text decoration style for button text
 * @cssprop {String} --compound-button-font-text-transform - The text transformation style for button text
 * @cssprop {String} --compound-button-font-weight - The font weight for button text
 * @cssprop {String} --compound-button-foreground-color - The text and icon color
 * @cssprop {String} --compound-button-gap - The spacing between button content elements
 * @cssprop {String} --compound-button-height - The button height
 * @cssprop {String} --compound-button-icon-min-height - The minimum height for icon display area
 * @cssprop {String} --compound-button-icon-min-width - The minimum width for icon display area
 * @cssprop {String} --compound-button-min-height - The minimum button height
 * @cssprop {String} --compound-button-min-width - The minimum button width
 * @cssprop {String} --compound-button-padding-bottom - The bottom padding inside the button
 * @cssprop {String} --compound-button-padding-left - The left padding inside the button
 * @cssprop {String} --compound-button-padding-right - The right padding inside the button
 * @cssprop {String} --compound-button-padding-top - The top padding inside the button
 * @cssprop {String} --compound-button-progress-ring-width - The button progress ring width CSS custom property.
 * @cssprop {String} --compound-button-ripple-color - The ripple effect color (from ripple mixin)
 * @cssprop {String} --compound-button-ripple-duration - The ripple effect animation duration (from ripple mixin)
 * @cssprop {String} --compound-button-shadow - The drop shadow or elevation effect
 * @cssprop {String} --compound-button-shadow-blur - The button shadow blur CSS custom property.
 * @cssprop {String} --compound-button-shadow-color - The button shadow color CSS custom property.
 * @cssprop {String} --compound-button-shadow-offset-x - The button shadow offset x CSS custom property.
 * @cssprop {String} --compound-button-shadow-offset-y - The button shadow offset y CSS custom property.
 * @cssprop {String} --compound-button-shadow-spread - The button shadow spread CSS custom property.
 * @cssprop {String} --compound-button-transition-duration - The duration of hover and focus transitions
 * @cssprop {String} --compound-button-transition-mode - The timing function for transitions
 * @cssprop {String} --compound-button-transition-property - The CSS properties to animate during transitions
 * @cssprop {String} --compound-button-translate - The transform translation offset
 * @cssprop {String} --compound-button-width - The button width
 *
 * @dependency mosaik-focus-ring - The Focus Ring element.
 * @dependency mosaik-icon - The Icon element.
 * @dependency mosaik-progress-ring - The Progress Ring element.
 * @dependency mosaik-ripple - The Ripple element.
 * @dependency mosaik-stack - The Stack element.
 * @dependency mosaik-text - The Text element.
 *
 * @example
 * Basic compound button with label:
 * ```html
 * <mosaik-compound-button label="Settings"></mosaik-compound-button>
 * ```
 *
 * @example
 * Navigation compound button with chevron:
 * ```html
 * <mosaik-compound-button label="Account Settings"
 *                         is-navigation
 *                         variant="primary"></mosaik-compound-button>
 * ```
 *
 * @public
 */
let CompoundButtonElement = class CompoundButtonElement extends Themeable(Reversible(Orientable(ContentAlignable(Fitable(Busyable(Labelable(Iconable(ButtonBaseElement)))))))) {
    // #region Fields
    _subLabel;
    _isNavigation;
    // #endregion
    // #region Ctor
    /**
     * @public
     */
    constructor() {
        super();
        // this.verticalContentAlignment = VerticalAlignment.Center;
        // this.horizontalContentAlignment = HorizontalAlignment.Left;
        this._subLabel = '';
        this._isNavigation = false;
    }
    // #endregion
    // #region Properties
    /**
     * Returns the `is` property.
     * The `is` property represents natural name of this element.
     *
     * @public
     * @static
     * @readonly
     */
    static get is() {
        return 'mosaik-compound-button';
    }
    /**
     * Gets or sets the `subLabel` property.
     *
     * @public
     */
    get subLabel() {
        return this._subLabel;
    }
    set subLabel(value) {
        if (this._subLabel !== value) {
            this._subLabel = value;
            this.requestUpdate('subLabel');
        }
    }
    /**
     * Gets or sets the `isNavigation` property.
     *
     * @public
     * @attr is-navigation
     */
    get isNavigation() {
        return this._isNavigation;
    }
    set isNavigation(value) {
        if (this._isNavigation !== value) {
            this._isNavigation = value;
            this.requestUpdate('isNavigation');
        }
    }
};
__decorate([
    Property({ type: String }),
    __metadata("design:type", String),
    __metadata("design:paramtypes", [String])
], CompoundButtonElement.prototype, "subLabel", null);
__decorate([
    Attribute({
        type: Boolean,
        useDefault: true
    }),
    __metadata("design:type", Boolean),
    __metadata("design:paramtypes", [Boolean])
], CompoundButtonElement.prototype, "isNavigation", null);
CompoundButtonElement = __decorate([
    Component({
        selector: 'mosaik-compound-button',
        template: compoundButtonElementTemplate,
        themes: {
            joy: compoundButtonElementJoyStyle,
            memphis: compoundButtonElementMemphisStyle,
            cosmopolitan: compoundButtonElementCosmopolitanStyle,
            soho: compoundButtonElementSohoStyle
        },
        options: {
            mode: 'open',
            delegatesFocus: true
        },
        imports: [
            StackElement,
            IconElement,
            RippleElement,
            FocusRingElement,
            TextElement,
            ProgressRingElement
        ]
    }),
    __metadata("design:paramtypes", [])
], CompoundButtonElement);
export { CompoundButtonElement };
//# sourceMappingURL=CompoundButtonElement.js.map