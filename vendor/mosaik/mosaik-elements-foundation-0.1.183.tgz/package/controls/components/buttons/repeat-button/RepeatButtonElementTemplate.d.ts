import { type TemplateResult } from '../../../../dom/Html';
import type { RepeatButtonElement } from './RepeatButtonElement';
/**
 * @public
 */
export declare function repeatButtonElementTemplate<T extends RepeatButtonElement>(e: T): TemplateResult;
//# sourceMappingURL=RepeatButtonElementTemplate.d.ts.map