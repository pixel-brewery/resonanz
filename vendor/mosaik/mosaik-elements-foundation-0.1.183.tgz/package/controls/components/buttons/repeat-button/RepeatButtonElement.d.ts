import { IEventEmitter } from '@pixel-brewery/mosaik-elements';
import type { IRepeatedEventDetail } from '../../../events';
import { ButtonBaseElement } from '../abstracts/ButtonBaseElement';
import type { IRepeatButtonElementProps } from './IRepeatButtonElementProps';
declare const RepeatButtonElement_base: (abstract new (...args: Array<any>) => import("../../../behaviors/Themeable").IThemeableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Reversible").IReversibleProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Orientable").IOrientableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/ContentAlignable").IContentAlignableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Fitable").IFitableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Busyable").IBusyableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Labelable").ILabelableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Iconable").IIconableProps) & typeof ButtonBaseElement & import("../../../behaviors/Themeable").IThemeableCtor;
/**
 * Repeat Button - An interactive button element designed to trigger an action repeatedly when held down.
 *
 * @description
 * The Repeat Button is an interactive UI element that allows users to trigger an action repeatedly by holding down
 * the button. This component is often used for actions that require continuous input, such as adjusting a value or
 * repeatedly executing a command. It provides a user-friendly way to perform actions in a continuous manner.
 *
 * @name Repeat Button
 * @element mosaik-repeat-button
 * @category Buttons
 *
 * @slot icon - The icon slot for placing an icon inside the button.
 * @slot label - The label slot for text or labels inside the button.
 * @slot overlay - The overlay slot (useful for badges or additional visual elements).
 *
 * @csspart button - The button part of the Repeat Button.
 * @csspart focusRing - The focus ring part of the Repeat Button.
 * @csspart icon - The icon part of the Repeat Button.
 * @csspart innerStack - The innerStack part.
 * @csspart label - The label part of the Repeat Button.
 * @csspart progressRing - The progress ring part of the Repeat Button.
 * @csspart ripple - The ripple effect part of the Repeat Button.
 *
 * @cssprop {Color} --repeat-button-background-color - The background color of the Repeat Button.
 * @cssprop {Color} --repeat-button-border-color - The border color of the Repeat Button.
 * @cssprop {String} --repeat-button-border-radius - The border radius of the Repeat Button.
 * @cssprop {String} --repeat-button-border-style - The border style of the Repeat Button.
 * @cssprop {String} --repeat-button-border-width - The border width of the Repeat Button.
 * @cssprop {String} --repeat-button-focus-ring-active-width - The button focus ring active width CSS custom property.
 * @cssprop {String} --repeat-button-focus-ring-color - The button focus ring color CSS custom property.
 * @cssprop {String} --repeat-button-focus-ring-inward-offset - The button focus ring inward offset CSS custom property.
 * @cssprop {String} --repeat-button-focus-ring-outward-offset - The button focus ring outward offset CSS custom property.
 * @cssprop {String} --repeat-button-font-family - The font family of the Repeat Button.
 * @cssprop {String} --repeat-button-font-letter-spacing - The font letter spacing of the Repeat Button.
 * @cssprop {String} --repeat-button-font-line-height - The font line height of the Repeat Button.
 * @cssprop {String} --repeat-button-font-size - The font size of the Repeat Button.
 * @cssprop {String} --repeat-button-font-text-decoration - The font text decoration of the Repeat Button.
 * @cssprop {String} --repeat-button-font-text-transform - The font text transform of the Repeat Button.
 * @cssprop {String} --repeat-button-font-weight - The font weight of the Repeat Button.
 * @cssprop {Color} --repeat-button-foreground-color - The foreground color of the Repeat Button.
 * @cssprop {String} --repeat-button-gap - The gap between elements of the Repeat Button.
 * @cssprop {String} --repeat-button-height - The button height CSS custom property.
 * @cssprop {String} --repeat-button-icon-min-height - The button icon min height CSS custom property.
 * @cssprop {String} --repeat-button-icon-min-width - The button icon min width CSS custom property.
 * @cssprop {String} --repeat-button-line-height - The line height of the Repeat Button text.
 * @cssprop {String} --repeat-button-min-height - The button min height CSS custom property.
 * @cssprop {String} --repeat-button-min-width - The button min width CSS custom property.
 * @cssprop {String} --repeat-button-padding-bottom - The padding bottom of the Repeat Button.
 * @cssprop {String} --repeat-button-padding-left - The padding left of the Repeat Button.
 * @cssprop {String} --repeat-button-padding-right - The padding right of the Repeat Button.
 * @cssprop {String} --repeat-button-padding-top - The padding top of the Repeat Button.
 * @cssprop {String} --repeat-button-progress-ring-width - The button progress ring width CSS custom property.
 * @cssprop {String} --repeat-button-progress-thickness - The button progress thickness CSS custom property.
 * @cssprop {Color} --repeat-button-ripple-color - The button ripple color CSS custom property.
 * @cssprop {String} --repeat-button-ripple-duration - The button ripple duration CSS custom property.
 * @cssprop {String} --repeat-button-shadow - The shadow of the Repeat Button.
 * @cssprop {String} --repeat-button-shadow-blur - The button shadow blur CSS custom property.
 * @cssprop {String} --repeat-button-shadow-color - The button shadow color CSS custom property.
 * @cssprop {String} --repeat-button-shadow-offset-x - The button shadow offset x CSS custom property.
 * @cssprop {String} --repeat-button-shadow-offset-y - The button shadow offset y CSS custom property.
 * @cssprop {String} --repeat-button-shadow-spread - The button shadow spread CSS custom property.
 * @cssprop {String} --repeat-button-transition-duration - The transition duration for the Repeat Button.
 * @cssprop {String} --repeat-button-transition-mode - The transition mode for the Repeat Button.
 * @cssprop {String} --repeat-button-transition-property - The transition property for the Repeat Button.
 * @cssprop {String} --repeat-button-translate - The button translate CSS custom property.
 * @cssprop {String} --repeat-button-width - The button width CSS custom property.
 *
 * @fires repeated {RepeatedEvent} - Called when the button is repeated.
 *
 * @dependency {FocusRingElement} mosaik-focus-ring - The Focus Ring component, used for focus indication.
 * @dependency {IconElement} mosaik-icon - The Icon component, used for displaying the icon.
 * @dependency {ProgressRingElement} mosaik-progress-ring - The Progress Ring component, used for progress indication.
 * @dependency {RippleElement} mosaik-ripple - The Ripple component, used for the ripple effect.
 * @dependency {StackElement} mosaik-stack - The Stack component, used for layout management.
 * @dependency {TextElement} mosaik-text - The Text component, used for displaying the label text.
 *
 * @example
 * Basic repeat button:
 * ```html
 * <mosaik-repeat-button label="Increment"></mosaik-repeat-button>
 * ```
 *
 * @example
 * Repeat button with custom delay and interval:
 * ```html
 * <mosaik-repeat-button label="Hold to repeat" delay="300" interval="100"></mosaik-repeat-button>
 * ```
 *
 * @public
 */
export declare class RepeatButtonElement extends RepeatButtonElement_base implements IRepeatButtonElementProps {
    private _delay;
    private _interval;
    private _isMouseKeydown;
    private _delayHandler;
    private _intervalHandler;
    private _isRepeating;
    private _pointerDownSubscription;
    private _pointerUpSubscription;
    private _pointerCancelSubscription;
    private readonly _repeated;
    /**
     * @public
     */
    constructor();
    /**
     * Returns the `is` property.
     * The `is` property represents natural name of this element.
     *
     * @public
     * @static
     * @readonly
     */
    static get is(): string;
    /**
     * Gets or sets the `delay` property.
     *
     * @public
     * @attr delay
     */
    get delay(): number;
    set delay(value: number);
    /**
     * Gets or sets the `interval` property.
     *
     * @public
     * @attr interval
     */
    get interval(): number;
    set interval(value: number);
    /**
     * Gets or sets the `isRepeating` property.
     *
     * @public
     * @readonly
     * @attr is-repeating
     */
    get isRepeating(): boolean;
    /**
     * @private
     */
    private set isRepeating(value);
    /**
     * Called when the button is repeated.
     * Provides reference to `IRepeatedEventDetail` as event detail.
     *
     * @public
     * @readonly
     * @eventProperty
     */
    get repeated(): IEventEmitter<IRepeatedEventDetail>;
    /**
     * @public
     * @override
     */
    connectedCallback(): void;
    /**
     * @public
     * @override
     */
    disconnectedCallback(): void;
    /**
     * @protected
     * @override
     */
    protected onApplyTemplate(): void;
    /**
     * Emits the `repeated` event.
     *
     * @protected
     */
    protected onRepeated(args: IRepeatedEventDetail): void;
    /**
     * @private
     */
    private attachPointerDown;
    /**
     * @private
     */
    private onPointerDown;
    /**
     * @private
     */
    private release;
}
/**
 * @public
 */
export declare namespace RepeatButtonElement {
    type Props = IRepeatButtonElementProps;
}
/**
 * @public
 */
declare global {
    interface HTMLElementTagNameMap {
        'mosaik-repeat-button': RepeatButtonElement;
    }
}
export {};
//# sourceMappingURL=RepeatButtonElement.d.ts.map