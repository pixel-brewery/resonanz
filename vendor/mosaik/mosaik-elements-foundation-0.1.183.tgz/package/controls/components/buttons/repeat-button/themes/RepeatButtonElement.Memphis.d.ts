import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function repeatButtonElementMemphisStyle(): CSSResult;
//# sourceMappingURL=RepeatButtonElement.Memphis.d.ts.map