import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function repeatButtonElementJoyStyle(): CSSResult;
//# sourceMappingURL=RepeatButtonElement.Joy.d.ts.map