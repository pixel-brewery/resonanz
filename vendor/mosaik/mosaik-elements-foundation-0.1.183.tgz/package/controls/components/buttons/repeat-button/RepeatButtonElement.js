// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { HTMLElementEventEmitter, on } from '@pixel-brewery/mosaik-elements';
import { Emit } from '../../../../events/decorators/EmitDecorator';
import { Busyable } from '../../../behaviors/Busyable';
import { ContentAlignable } from '../../../behaviors/ContentAlignable';
import { Fitable } from '../../../behaviors/Fitable';
import { Iconable } from '../../../behaviors/Iconable';
import { Labelable } from '../../../behaviors/Labelable';
import { Orientable } from '../../../behaviors/Orientable';
import { Reversible } from '../../../behaviors/Reversible';
import { Themeable } from '../../../behaviors/Themeable';
import { Attribute } from '../../../decorators/AttributeDecorator';
import { Component } from '../../../decorators/ComponentDecorator';
import { RippleElement } from '../../effects/ripple/RippleElement';
import { StackElement } from '../../layouts/stack/StackElement';
import { IconElement } from '../../media/icon/IconElement';
import { FocusRingElement } from '../../primitives/focus-ring/FocusRingElement';
import { TextElement } from '../../primitives/text/TextElement';
import { ProgressRingElement } from '../../ranges/progress-ring/ProgressRingElement';
import { ButtonBaseElement } from '../abstracts/ButtonBaseElement';
import { repeatButtonElementTemplate } from './RepeatButtonElementTemplate';
import { repeatButtonElementCosmopolitanStyle } from './themes/RepeatButtonElement.Cosmopolitan';
import { repeatButtonElementJoyStyle } from './themes/RepeatButtonElement.Joy';
import { repeatButtonElementMemphisStyle } from './themes/RepeatButtonElement.Memphis';
import { repeatButtonElementSohoStyle } from './themes/RepeatButtonElement.Soho';
// #endregion
/**
 * Repeat Button - An interactive button element designed to trigger an action repeatedly when held down.
 *
 * @description
 * The Repeat Button is an interactive UI element that allows users to trigger an action repeatedly by holding down
 * the button. This component is often used for actions that require continuous input, such as adjusting a value or
 * repeatedly executing a command. It provides a user-friendly way to perform actions in a continuous manner.
 *
 * @name Repeat Button
 * @element mosaik-repeat-button
 * @category Buttons
 *
 * @slot icon - The icon slot for placing an icon inside the button.
 * @slot label - The label slot for text or labels inside the button.
 * @slot overlay - The overlay slot (useful for badges or additional visual elements).
 *
 * @csspart button - The button part of the Repeat Button.
 * @csspart focusRing - The focus ring part of the Repeat Button.
 * @csspart icon - The icon part of the Repeat Button.
 * @csspart innerStack - The innerStack part.
 * @csspart label - The label part of the Repeat Button.
 * @csspart progressRing - The progress ring part of the Repeat Button.
 * @csspart ripple - The ripple effect part of the Repeat Button.
 *
 * @cssprop {Color} --repeat-button-background-color - The background color of the Repeat Button.
 * @cssprop {Color} --repeat-button-border-color - The border color of the Repeat Button.
 * @cssprop {String} --repeat-button-border-radius - The border radius of the Repeat Button.
 * @cssprop {String} --repeat-button-border-style - The border style of the Repeat Button.
 * @cssprop {String} --repeat-button-border-width - The border width of the Repeat Button.
 * @cssprop {String} --repeat-button-focus-ring-active-width - The button focus ring active width CSS custom property.
 * @cssprop {String} --repeat-button-focus-ring-color - The button focus ring color CSS custom property.
 * @cssprop {String} --repeat-button-focus-ring-inward-offset - The button focus ring inward offset CSS custom property.
 * @cssprop {String} --repeat-button-focus-ring-outward-offset - The button focus ring outward offset CSS custom property.
 * @cssprop {String} --repeat-button-font-family - The font family of the Repeat Button.
 * @cssprop {String} --repeat-button-font-letter-spacing - The font letter spacing of the Repeat Button.
 * @cssprop {String} --repeat-button-font-line-height - The font line height of the Repeat Button.
 * @cssprop {String} --repeat-button-font-size - The font size of the Repeat Button.
 * @cssprop {String} --repeat-button-font-text-decoration - The font text decoration of the Repeat Button.
 * @cssprop {String} --repeat-button-font-text-transform - The font text transform of the Repeat Button.
 * @cssprop {String} --repeat-button-font-weight - The font weight of the Repeat Button.
 * @cssprop {Color} --repeat-button-foreground-color - The foreground color of the Repeat Button.
 * @cssprop {String} --repeat-button-gap - The gap between elements of the Repeat Button.
 * @cssprop {String} --repeat-button-height - The button height CSS custom property.
 * @cssprop {String} --repeat-button-icon-min-height - The button icon min height CSS custom property.
 * @cssprop {String} --repeat-button-icon-min-width - The button icon min width CSS custom property.
 * @cssprop {String} --repeat-button-line-height - The line height of the Repeat Button text.
 * @cssprop {String} --repeat-button-min-height - The button min height CSS custom property.
 * @cssprop {String} --repeat-button-min-width - The button min width CSS custom property.
 * @cssprop {String} --repeat-button-padding-bottom - The padding bottom of the Repeat Button.
 * @cssprop {String} --repeat-button-padding-left - The padding left of the Repeat Button.
 * @cssprop {String} --repeat-button-padding-right - The padding right of the Repeat Button.
 * @cssprop {String} --repeat-button-padding-top - The padding top of the Repeat Button.
 * @cssprop {String} --repeat-button-progress-ring-width - The button progress ring width CSS custom property.
 * @cssprop {String} --repeat-button-progress-thickness - The button progress thickness CSS custom property.
 * @cssprop {Color} --repeat-button-ripple-color - The button ripple color CSS custom property.
 * @cssprop {String} --repeat-button-ripple-duration - The button ripple duration CSS custom property.
 * @cssprop {String} --repeat-button-shadow - The shadow of the Repeat Button.
 * @cssprop {String} --repeat-button-shadow-blur - The button shadow blur CSS custom property.
 * @cssprop {String} --repeat-button-shadow-color - The button shadow color CSS custom property.
 * @cssprop {String} --repeat-button-shadow-offset-x - The button shadow offset x CSS custom property.
 * @cssprop {String} --repeat-button-shadow-offset-y - The button shadow offset y CSS custom property.
 * @cssprop {String} --repeat-button-shadow-spread - The button shadow spread CSS custom property.
 * @cssprop {String} --repeat-button-transition-duration - The transition duration for the Repeat Button.
 * @cssprop {String} --repeat-button-transition-mode - The transition mode for the Repeat Button.
 * @cssprop {String} --repeat-button-transition-property - The transition property for the Repeat Button.
 * @cssprop {String} --repeat-button-translate - The button translate CSS custom property.
 * @cssprop {String} --repeat-button-width - The button width CSS custom property.
 *
 * @fires repeated {RepeatedEvent} - Called when the button is repeated.
 *
 * @dependency {FocusRingElement} mosaik-focus-ring - The Focus Ring component, used for focus indication.
 * @dependency {IconElement} mosaik-icon - The Icon component, used for displaying the icon.
 * @dependency {ProgressRingElement} mosaik-progress-ring - The Progress Ring component, used for progress indication.
 * @dependency {RippleElement} mosaik-ripple - The Ripple component, used for the ripple effect.
 * @dependency {StackElement} mosaik-stack - The Stack component, used for layout management.
 * @dependency {TextElement} mosaik-text - The Text component, used for displaying the label text.
 *
 * @example
 * Basic repeat button:
 * ```html
 * <mosaik-repeat-button label="Increment"></mosaik-repeat-button>
 * ```
 *
 * @example
 * Repeat button with custom delay and interval:
 * ```html
 * <mosaik-repeat-button label="Hold to repeat" delay="300" interval="100"></mosaik-repeat-button>
 * ```
 *
 * @public
 */
let RepeatButtonElement = class RepeatButtonElement extends Themeable(Reversible(Orientable(ContentAlignable(Fitable(Busyable(Labelable(Iconable(ButtonBaseElement)))))))) {
    // #region Fields
    _delay;
    _interval;
    _isMouseKeydown;
    _delayHandler;
    _intervalHandler;
    _isRepeating;
    _pointerDownSubscription;
    _pointerUpSubscription;
    _pointerCancelSubscription;
    _repeated;
    // #endregion
    // #region Ctor
    /**
     * @public
     */
    constructor() {
        super();
        this._delay = 500;
        this._interval = 330;
        this._isMouseKeydown = false;
        this._delayHandler = null;
        this._intervalHandler = null;
        this._isRepeating = false;
        this._pointerDownSubscription = null;
        this._pointerUpSubscription = null;
        this._pointerCancelSubscription = null;
        this._repeated = new HTMLElementEventEmitter(this, 'repeated');
    }
    // #endregion
    // #region Properties
    /**
     * Returns the `is` property.
     * The `is` property represents natural name of this element.
     *
     * @public
     * @static
     * @readonly
     */
    static get is() {
        return 'mosaik-repeat-button';
    }
    /**
     * Gets or sets the `delay` property.
     *
     * @public
     * @attr delay
     */
    get delay() {
        return this._delay;
    }
    set delay(value) {
        if (this._delay !== value) {
            this._delay = value;
            this.requestUpdate('delay');
        }
    }
    /**
     * Gets or sets the `interval` property.
     *
     * @public
     * @attr interval
     */
    get interval() {
        return this._interval;
    }
    set interval(value) {
        if (this._interval !== value) {
            this._interval = value;
            this.requestUpdate('interval');
        }
    }
    /**
     * Gets or sets the `isRepeating` property.
     *
     * @public
     * @readonly
     * @attr is-repeating
     */
    get isRepeating() {
        return this._isRepeating;
    }
    /**
     * @private
     */
    set isRepeating(value) {
        if (this._isRepeating !== value) {
            this._isRepeating = value;
            this.requestUpdate('isRepeating');
        }
    }
    /**
     * Called when the button is repeated.
     * Provides reference to `IRepeatedEventDetail` as event detail.
     *
     * @public
     * @readonly
     * @eventProperty
     */
    get repeated() {
        return this._repeated;
    }
    // #endregion
    // #region Methods
    /**
     * @public
     * @override
     */
    connectedCallback() {
        super.connectedCallback();
        if (this.hasUpdated) {
            this.attachPointerDown();
        }
    }
    /**
     * @public
     * @override
     */
    disconnectedCallback() {
        super.disconnectedCallback();
        this._pointerDownSubscription?.dispose();
        this._pointerDownSubscription = null;
        this.release();
    }
    /**
     * @protected
     * @override
     */
    onApplyTemplate() {
        super.onApplyTemplate();
        if (this.isConnected) {
            this.attachPointerDown();
        }
    }
    /**
     * Emits the `repeated` event.
     *
     * @protected
     */
    onRepeated(args) {
        this._repeated.emit(args);
    }
    /**
     * @private
     */
    attachPointerDown() {
        this._pointerDownSubscription?.dispose();
        this._pointerDownSubscription = on(this.getTemplatePart('button'), 'pointerdown', (event) => this.onPointerDown(event));
    }
    /**
     * @private
     */
    onPointerDown(event) {
        // Only handle primary button (left mouse / touch)
        if (event.button !== 0 || this._isMouseKeydown) {
            return;
        }
        this._isMouseKeydown = true;
        // Register global listeners to catch pointer release anywhere
        this._pointerUpSubscription?.dispose();
        this._pointerCancelSubscription?.dispose();
        this._pointerUpSubscription = on(document, 'pointerup', () => this.release());
        this._pointerCancelSubscription = on(document, 'pointercancel', () => this.release());
        let repeatCount = 0;
        this._delayHandler = setTimeout(() => {
            if (!this._isMouseKeydown || this._intervalHandler !== null) {
                return;
            }
            this._intervalHandler = setInterval(() => {
                this.isRepeating = true;
                // Increment repeat count on each interval
                repeatCount++;
                this.onRepeated({
                    count: repeatCount
                });
            }, this.interval);
        }, this.delay);
    }
    /**
     * @private
     */
    release() {
        this._isMouseKeydown = false;
        clearTimeout(this._delayHandler ?? undefined);
        clearInterval(this._intervalHandler ?? undefined);
        this._delayHandler = null;
        this._intervalHandler = null;
        this.isRepeating = false;
        // Clean up global listeners
        this._pointerUpSubscription?.dispose();
        this._pointerCancelSubscription?.dispose();
        this._pointerUpSubscription = null;
        this._pointerCancelSubscription = null;
    }
};
__decorate([
    Attribute({ type: Number }),
    __metadata("design:type", Number),
    __metadata("design:paramtypes", [Number])
], RepeatButtonElement.prototype, "delay", null);
__decorate([
    Attribute({ type: Number }),
    __metadata("design:type", Number),
    __metadata("design:paramtypes", [Number])
], RepeatButtonElement.prototype, "interval", null);
__decorate([
    Attribute({
        type: Boolean,
        useDefault: true
    }),
    __metadata("design:type", Boolean),
    __metadata("design:paramtypes", [Boolean])
], RepeatButtonElement.prototype, "isRepeating", null);
__decorate([
    Emit({ eventName: 'repeated' }),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], RepeatButtonElement.prototype, "repeated", null);
RepeatButtonElement = __decorate([
    Component({
        selector: 'mosaik-repeat-button',
        template: repeatButtonElementTemplate,
        themes: {
            joy: repeatButtonElementJoyStyle,
            memphis: repeatButtonElementMemphisStyle,
            cosmopolitan: repeatButtonElementCosmopolitanStyle,
            soho: repeatButtonElementSohoStyle
        },
        options: {
            mode: 'open',
            delegatesFocus: true
        },
        imports: [
            StackElement,
            IconElement,
            RippleElement,
            FocusRingElement,
            TextElement,
            ProgressRingElement
        ]
    }),
    __metadata("design:paramtypes", [])
], RepeatButtonElement);
export { RepeatButtonElement };
//# sourceMappingURL=RepeatButtonElement.js.map