import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function repeatButtonElementSohoStyle(): CSSResult;
//# sourceMappingURL=RepeatButtonElement.Soho.d.ts.map