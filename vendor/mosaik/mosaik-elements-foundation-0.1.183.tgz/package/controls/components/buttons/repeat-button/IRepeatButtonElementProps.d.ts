import type { IBusyableProps } from '../../../behaviors/Busyable';
import type { IIconableProps } from '../../../behaviors/Iconable';
import type { ILabelableProps } from '../../../behaviors/Labelable';
import type { IOrientableProps } from '../../../behaviors/Orientable';
import type { IReversibleProps } from '../../../behaviors/Reversible';
import type { IThemeableProps } from '../../../behaviors/Themeable';
import type { IButtonBaseElementProps } from '../abstracts/IButtonBaseElementProps';
import type { IContentAlignableProps } from '../../../behaviors/ContentAlignable';
/**
 * Represents the `IRepeatButtonElementProps` interface.
 *
 * @public
 */
export interface IRepeatButtonElementProps extends IButtonBaseElementProps, IOrientableProps, IBusyableProps, IReversibleProps, ILabelableProps, IIconableProps, IThemeableProps, IContentAlignableProps {
    delay: number;
    interval: number;
}
//# sourceMappingURL=IRepeatButtonElementProps.d.ts.map