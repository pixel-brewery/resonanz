import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function repeatButtonElementCosmopolitanStyle(): CSSResult;
//# sourceMappingURL=RepeatButtonElement.Cosmopolitan.d.ts.map