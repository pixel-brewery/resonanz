import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function tileElementJoyStyle(): CSSResult;
//# sourceMappingURL=TileElement.Joy.d.ts.map