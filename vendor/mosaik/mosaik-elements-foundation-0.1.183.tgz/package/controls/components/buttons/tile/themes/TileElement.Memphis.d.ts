import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function tileElementMemphisStyle(): CSSResult;
//# sourceMappingURL=TileElement.Memphis.d.ts.map