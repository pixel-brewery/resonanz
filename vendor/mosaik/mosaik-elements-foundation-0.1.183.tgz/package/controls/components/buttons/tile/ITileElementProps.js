// #region Imports
export {};
//# sourceMappingURL=ITileElementProps.js.map