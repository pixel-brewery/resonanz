// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Appearanceable } from '../../../behaviors/Appearanceable';
import { Disableable } from '../../../behaviors/Disableable';
import { Elevatable } from '../../../behaviors/Elevatable';
import { Fitable } from '../../../behaviors/Fitable';
import { Focusable } from '../../../behaviors/Focusable';
import { Rippleable } from '../../../behaviors/Rippleable';
import { Themeable } from '../../../behaviors/Themeable';
import { Variantable } from '../../../behaviors/Variantable';
import { Attribute } from '../../../decorators/AttributeDecorator';
import { Component } from '../../../decorators/ComponentDecorator';
import { ButtonType } from '../../../types/ButtonType';
import { CustomElement } from '../../abstracts/CustomElement';
import { RippleElement } from '../../effects/ripple/RippleElement';
import { ElevationElement } from '../../primitives/elevation/ElevationElement';
import { FocusRingElement } from '../../primitives/focus-ring/FocusRingElement';
import { tileElementCosmopolitanStyle } from './themes/TileElement.Cosmopolitan';
import { tileElementJoyStyle } from './themes/TileElement.Joy';
import { tileElementMemphisStyle } from './themes/TileElement.Memphis';
import { tileElementSohoStyle } from './themes/TileElement.Soho';
import { tileElementTemplate } from './TileElementTemplate';
// #endregion
/**
 * Tile - A clickable card-like container for interactive content blocks.
 *
 * @description
 * The Tile component is a hybrid between a button and a card. It provides a clickable,
 * elevated container that can hold arbitrary content through a default slot. Tiles are designed
 * for use cases where a larger, card-like interactive surface is needed instead of a standard
 * button — such as dashboard widgets, selection grids, or navigation blocks. The component
 * supports elevation, ripple effects, focus rings, and multiple appearance/variant combinations
 * while remaining semantically a button for accessibility.
 *
 * @name Tile
 * @element mosaik-tile
 * @category Buttons
 *
 * @slot - Default slot for arbitrary tile content
 *
 * @csspart button - The native button element container
 * @csspart content - The content wrapper inside the button
 * @csspart elevation - The elevation/shadow layer
 * @csspart focusRing - The focus indicator ring for keyboard navigation
 * @csspart ripple - The touch feedback ripple effect container
 *
 * @cssprop {Color} --tile-background-color - Background color of the tile
 * @cssprop {Color} --tile-border-color - Border color around the tile
 * @cssprop {String} --tile-border-radius - Corner rounding radius
 * @cssprop {String} --tile-border-style - Border line style
 * @cssprop {String} --tile-border-width - Border width
 * @cssprop {String} --tile-focus-ring-active-width - Focus ring active width
 * @cssprop {String} --tile-focus-ring-color - Focus ring color
 * @cssprop {String} --tile-focus-ring-inward-offset - Focus ring inward offset
 * @cssprop {String} --tile-focus-ring-outward-offset - Focus ring outward offset
 * @cssprop {String} --tile-font-family - Font family for tile text
 * @cssprop {String} --tile-font-letter-spacing - Letter spacing
 * @cssprop {String} --tile-font-line-height - Line height
 * @cssprop {String} --tile-font-size - Font size
 * @cssprop {String} --tile-font-text-decoration - Text decoration
 * @cssprop {String} --tile-font-text-transform - Text transformation
 * @cssprop {String} --tile-font-weight - Font weight
 * @cssprop {Color} --tile-foreground-color - Text and icon color
 * @cssprop {String} --tile-gap - Spacing between child elements
 * @cssprop {String} --tile-padding-bottom - Bottom padding
 * @cssprop {String} --tile-padding-left - Left padding
 * @cssprop {String} --tile-padding-right - Right padding
 * @cssprop {String} --tile-padding-top - Top padding
 * @cssprop {Color} --tile-ripple-color - Ripple effect color
 * @cssprop {String} --tile-ripple-duration - Ripple animation duration
 * @cssprop {String} --tile-shadow - Box shadow
 * @cssprop {String} --tile-shadow-blur - Shadow blur radius
 * @cssprop {String} --tile-shadow-color - Shadow color
 * @cssprop {String} --tile-shadow-offset-x - Horizontal shadow offset
 * @cssprop {String} --tile-shadow-offset-y - Vertical shadow offset
 * @cssprop {String} --tile-shadow-spread - Shadow spread radius
 * @cssprop {String} --tile-transition-duration - Transition duration
 * @cssprop {String} --tile-transition-mode - Transition timing function
 * @cssprop {String} --tile-transition-property - Properties to transition
 * @cssprop {String} --tile-translate - Translate transform
 *
 * @dependency mosaik-elevation - The Elevation element.
 * @dependency mosaik-focus-ring - The Focus Ring element.
 * @dependency mosaik-ripple - The Ripple element.
 *
 * @example
 * Basic tile with text content:
 * ```html
 * <mosaik-tile>
 *   <mosaik-icon data="M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2z"></mosaik-icon>
 *   <mosaik-text text="Mail"></mosaik-text>
 * </mosaik-tile>
 * ```
 *
 * @example
 * Tile with variant and appearance:
 * ```html
 * <mosaik-tile variant="primary" appearance="solid">
 *   <mosaik-icon data="..."></mosaik-icon>
 *   <mosaik-text text="Dashboard"></mosaik-text>
 * </mosaik-tile>
 * ```
 *
 * @example
 * Disabled tile:
 * ```html
 * <mosaik-tile disabled>
 *   <mosaik-text text="Unavailable"></mosaik-text>
 * </mosaik-tile>
 * ```
 *
 * @public
 */
let TileElement = class TileElement extends Themeable(Elevatable(Variantable(Appearanceable(Fitable(Rippleable(Disableable(Focusable(CustomElement)))))))) {
    // #region Fields
    _type;
    // #endregion
    // #region Ctor
    /**
     * Constructs a new instance of the `TileElement` class.
     *
     * @public
     */
    constructor() {
        super();
        this._type = ButtonType.Button;
    }
    // #endregion
    // #region Properties
    /**
     * Returns the `is` property.
     *
     * @public
     * @static
     * @readonly
     */
    static get is() {
        return 'mosaik-tile';
    }
    /**
     * @public
     * @static
     * @override
     * @readonly
     */
    static get observedAttributes() {
        return [...super.observedAttributes, 'aria-label'];
    }
    /**
     * Gets or sets the `type` property.
     * It modifies the classification and default behavior of the tile button.
     *
     * @public
     * @attr type
     */
    get type() {
        return this._type;
    }
    set type(value) {
        if (this._type !== value) {
            this._type = value;
            this.requestUpdate('type');
        }
    }
    // #endregion
    // #region Methods
    /**
     * Keeps an explicit accessible name on the native tile button current.
     *
     * @public
     * @override
     */
    attributeChangedCallback(name, old, value) {
        super.attributeChangedCallback(name, old, value);
        if (name === 'aria-label' && old !== value) {
            this.requestUpdate();
        }
    }
};
__decorate([
    Attribute({ type: ButtonType }),
    __metadata("design:type", String),
    __metadata("design:paramtypes", [String])
], TileElement.prototype, "type", null);
TileElement = __decorate([
    Component({
        selector: 'mosaik-tile',
        template: tileElementTemplate,
        themes: {
            joy: tileElementJoyStyle,
            memphis: tileElementMemphisStyle,
            cosmopolitan: tileElementCosmopolitanStyle,
            soho: tileElementSohoStyle
        },
        options: {
            mode: 'open',
            delegatesFocus: true
        },
        imports: [
            RippleElement,
            FocusRingElement,
            ElevationElement
        ]
    }),
    __metadata("design:paramtypes", [])
], TileElement);
export { TileElement };
//# sourceMappingURL=TileElement.js.map