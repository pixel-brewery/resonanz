import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function tileElementSohoStyle(): CSSResult;
//# sourceMappingURL=TileElement.Soho.d.ts.map