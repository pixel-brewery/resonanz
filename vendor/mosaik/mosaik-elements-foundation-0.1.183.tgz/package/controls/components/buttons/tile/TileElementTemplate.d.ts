import { type TemplateResult } from '../../../../dom/Html';
import type { TileElement } from './TileElement';
/**
 * The template of the `TileElement`.
 *
 * @public
 */
export declare function tileElementTemplate<T extends TileElement>(e: T): TemplateResult;
//# sourceMappingURL=TileElementTemplate.d.ts.map