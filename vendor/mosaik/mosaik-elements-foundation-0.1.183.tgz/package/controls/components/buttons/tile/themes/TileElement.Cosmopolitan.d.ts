import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function tileElementCosmopolitanStyle(): CSSResult;
//# sourceMappingURL=TileElement.Cosmopolitan.d.ts.map