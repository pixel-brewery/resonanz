import type { IAppearanceableProps } from '../../../behaviors/Appearanceable';
import type { IDisableableProps } from '../../../behaviors/Disableable';
import type { IElevatableProps } from '../../../behaviors/Elevatable';
import type { IFitableProps } from '../../../behaviors/Fitable';
import type { IRippleableProps } from '../../../behaviors/Rippleable';
import type { IThemeableProps } from '../../../behaviors/Themeable';
import type { IVariantableProps } from '../../../behaviors/Variantable';
import { ButtonType } from '../../../types/ButtonType';
/**
 * Represents the `ITileElementProps` interface.
 *
 * @public
 */
export interface ITileElementProps extends IAppearanceableProps, IDisableableProps, IElevatableProps, IFitableProps, IRippleableProps, IVariantableProps, IThemeableProps {
    type: ButtonType;
}
//# sourceMappingURL=ITileElementProps.d.ts.map