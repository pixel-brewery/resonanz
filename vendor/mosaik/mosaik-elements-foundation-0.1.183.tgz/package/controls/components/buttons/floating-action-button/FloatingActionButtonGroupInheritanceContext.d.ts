import type { Appearance } from '../../../types/Appearance';
import type { Variant } from '../../../types/Variant';
/**
 * Interface for properties inherited by child FloatingActionButtonElements.
 *
 * @public
 */
export interface IFloatingActionButtonGroupInherited {
    /**
     * Inherited disabled state.
     */
    disabled?: boolean;
    /**
     * Inherited appearance.
     */
    appearance?: Appearance;
    /**
     * Inherited variant.
     */
    variant?: Variant;
}
/**
 * Context for FloatingActionButtonGroup → FloatingActionButton inheritance.
 *
 * @public
 */
export declare const FAB_GROUP_INHERITANCE_CONTEXT: {
    __context__: Partial<IFloatingActionButtonGroupInherited>;
};
//# sourceMappingURL=FloatingActionButtonGroupInheritanceContext.d.ts.map