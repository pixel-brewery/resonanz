// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Busyable } from '../../../behaviors/Busyable';
import { Iconable } from '../../../behaviors/Iconable';
import { Labelable } from '../../../behaviors/Labelable';
import { Themeable } from '../../../behaviors/Themeable';
import { addInheritanceConsumerController } from '../../../controllers/InheritanceConsumerController';
import { Component } from '../../../decorators/ComponentDecorator';
import { RippleElement } from '../../effects/ripple/RippleElement';
import { StackElement } from '../../layouts/stack/StackElement';
import { IconElement } from '../../media/icon/IconElement';
import { ElevationElement } from '../../primitives/elevation/ElevationElement';
import { FocusRingElement } from '../../primitives/focus-ring/FocusRingElement';
import { TextElement } from '../../primitives/text/TextElement';
import { ProgressRingElement } from '../../ranges/progress-ring/ProgressRingElement';
import { ButtonBaseElement } from '../abstracts/ButtonBaseElement';
import { floatingActionButtonElementTemplate } from './FloatingActionButtonElementTemplate';
import { FAB_GROUP_INHERITANCE_CONTEXT } from './FloatingActionButtonGroupInheritanceContext';
import { floatingActionButtonElementCosmopolitanStyle } from './themes/FloatingActionButtonElement.Cosmopolitan';
import { floatingActionButtonElementJoyStyle } from './themes/FloatingActionButtonElement.Joy';
import { floatingActionButtonElementMemphisStyle } from './themes/FloatingActionButtonElement.Memphis';
import { floatingActionButtonElementSohoStyle } from './themes/FloatingActionButtonElement.Soho';
// #endregion
/**
 * FloatingActionButton - A prominent circular button designed for primary actions with elevated visual prominence.
 *
 * @description
 * The FloatingActionButton component creates a distinctive, floating interactive element optimized
 * for triggering the most important action on a screen. It features elevated styling with shadow
 * effects, circular geometry, ripple feedback, and optional text labels for extended variations.
 * The component is designed to draw user attention to critical functionality such as creating content,
 * composing messages, or initiating primary workflows. It includes advanced features like elevation
 * shadows, ripple effects, focus rings, progress indicators, and comprehensive accessibility support,
 * making it ideal for Material Design-inspired interfaces requiring prominent action triggers.
 *
 * @name FloatingActionButton
 * @element mosaik-fab
 * @category Buttons
 *
 * @slot icon - Icon content area for the primary visual action indicator
 * @slot label - Optional text label for extended floating action button variations
 * @slot overlay - Overlay content area for badges, notifications, or status indicators
 *
 * @csspart button - The main button element container
 * @csspart elevation - The elevation shadow effect container for visual prominence
 * @csspart focusRing - The focus indicator ring for keyboard navigation accessibility
 * @csspart icon - The icon display area within the button
 * @csspart innerStack - The internal stack layout container for organizing icon and label
 * @csspart label - The text label display area for extended button variations
 * @csspart progressRing - The busy state progress indicator
 * @csspart ripple - The touch feedback ripple effect container
 *
 * @cssprop {String} --fab-background-color - The background fill color
 * @cssprop {String} --fab-border-color - The border outline color
 * @cssprop {String} --fab-border-radius - The corner rounding radius for circular shape
 * @cssprop {String} --fab-border-style - The border line style
 * @cssprop {String} --fab-border-width - The border thickness
 * @cssprop {String} --fab-focus-ring-active-width - The focus ring width when active (from focusRing mixin)
 * @cssprop {String} --fab-focus-ring-color - The focus ring color (from focusRing mixin)
 * @cssprop {String} --fab-focus-ring-inward-offset - The focus ring inward offset (from focusRing mixin)
 * @cssprop {String} --fab-focus-ring-outward-offset - The focus ring outward offset (from focusRing mixin)
 * @cssprop {String} --fab-font-family - The font family for button text and labels
 * @cssprop {String} --fab-font-letter-spacing - The letter spacing for button text
 * @cssprop {String} --fab-font-line-height - The line height for button text
 * @cssprop {String} --fab-font-size - The font size for button text
 * @cssprop {String} --fab-font-text-decoration - The text decoration style for button text
 * @cssprop {String} --fab-font-text-transform - The text transformation style for button text
 * @cssprop {String} --fab-font-weight - The font weight for button text
 * @cssprop {String} --fab-foreground-color - The icon and text color
 * @cssprop {String} --fab-gap - The spacing between icon and label elements
 * @cssprop {String} --fab-icon-min-height - The minimum height for icon display area
 * @cssprop {String} --fab-icon-min-width - The minimum width for icon display area
 * @cssprop {String} --fab-min-height - The minimum button height
 * @cssprop {String} --fab-min-width - The minimum button width
 * @cssprop {String} --fab-padding-bottom - The bottom padding inside the button
 * @cssprop {String} --fab-padding-left - The left padding inside the button
 * @cssprop {String} --fab-padding-right - The right padding inside the button
 * @cssprop {String} --fab-padding-top - The top padding inside the button
 * @cssprop {String} --fab-progress-ring-width - The action button progress ring width CSS custom property.
 * @cssprop {String} --fab-ripple-color - The ripple effect color (from ripple mixin)
 * @cssprop {String} --fab-ripple-duration - The ripple effect animation duration (from ripple mixin)
 * @cssprop {String} --fab-shadow - The drop shadow or elevation effect
 * @cssprop {String} --fab-shadow-blur - The action button shadow blur CSS custom property.
 * @cssprop {String} --fab-shadow-color - The action button shadow color CSS custom property.
 * @cssprop {String} --fab-shadow-offset-x - The action button shadow offset x CSS custom property.
 * @cssprop {String} --fab-shadow-offset-y - The action button shadow offset y CSS custom property.
 * @cssprop {String} --fab-shadow-spread - The action button shadow spread CSS custom property.
 * @cssprop {String} --fab-transition-duration - The duration of hover and focus transitions
 * @cssprop {String} --fab-transition-mode - The timing function for transitions
 * @cssprop {String} --fab-transition-property - The CSS properties to animate during transitions
 * @cssprop {String} --fab-translate - The action button translate CSS custom property.
 *
 * @dependency mosaik-elevation - The Elevation element.
 * @dependency mosaik-focus-ring - The Focus Ring element.
 * @dependency mosaik-icon - The Icon element.
 * @dependency mosaik-progress-ring - The Progress Ring element.
 * @dependency mosaik-ripple - The Ripple element.
 * @dependency mosaik-stack - The Stack element.
 * @dependency mosaik-text - The Text element.
 *
 * @example
 * Basic floating action button:
 * ```html
 * <mosaik-fab variant="primary"></mosaik-fab>
 * ```
 *
 * @example
 * Extended floating action button with label:
 * ```html
 * <mosaik-fab label="Compose"
 *             variant="primary"
 *             appearance="solid"></mosaik-fab>
 * ```
 *
 * @public
 */
let FloatingActionButtonElement = class FloatingActionButtonElement extends Themeable(Busyable(Labelable(Iconable(ButtonBaseElement)))) {
    // #region Fields
    _inheritance = addInheritanceConsumerController(this, {
        context: FAB_GROUP_INHERITANCE_CONTEXT
    });
    // #endregion
    // #region Ctor
    /**
     * @public
     */
    constructor() {
        super();
    }
    // #endregion
    // #region Properties
    /**
     * Returns the `is` property.
     * The `is` property represents natural name of this element.
     *
     * @public
     * @static
     * @readonly
     */
    static get is() {
        return 'mosaik-fab';
    }
    /**
     * @public
     * @override
     */
    get disabled() {
        return this._inheritance.get('disabled', super.disabled);
    }
    set disabled(value) {
        this._inheritance.markExplicit('disabled');
        super.disabled = value;
    }
    /**
     * @public
     * @override
     */
    get appearance() {
        return this._inheritance.get('appearance', super.appearance);
    }
    set appearance(value) {
        this._inheritance.markExplicit('appearance');
        super.appearance = value;
    }
    /**
     * @public
     * @override
     */
    get variant() {
        return this._inheritance.get('variant', super.variant);
    }
    set variant(value) {
        this._inheritance.markExplicit('variant');
        super.variant = value;
    }
};
FloatingActionButtonElement = __decorate([
    Component({
        selector: 'mosaik-fab',
        template: floatingActionButtonElementTemplate,
        themes: {
            joy: floatingActionButtonElementJoyStyle,
            memphis: floatingActionButtonElementMemphisStyle,
            cosmopolitan: floatingActionButtonElementCosmopolitanStyle,
            soho: floatingActionButtonElementSohoStyle
        },
        options: {
            mode: 'open',
            delegatesFocus: true
        },
        imports: [
            StackElement,
            IconElement,
            RippleElement,
            FocusRingElement,
            TextElement,
            ProgressRingElement,
            ElevationElement
        ]
    }),
    __metadata("design:paramtypes", [])
], FloatingActionButtonElement);
export { FloatingActionButtonElement };
//# sourceMappingURL=FloatingActionButtonElement.js.map