// #region Imports
import { createContext } from '@lit/context';
/**
 * Context for FloatingActionButtonGroup → FloatingActionButton inheritance.
 *
 * @public
 */
export const FAB_GROUP_INHERITANCE_CONTEXT = createContext(Symbol.for('mosaik:fab-group:inheritance'));
//# sourceMappingURL=FloatingActionButtonGroupInheritanceContext.js.map