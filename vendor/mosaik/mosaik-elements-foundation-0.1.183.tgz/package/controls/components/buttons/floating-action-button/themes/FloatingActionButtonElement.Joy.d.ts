import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function floatingActionButtonElementJoyStyle(): CSSResult;
//# sourceMappingURL=FloatingActionButtonElement.Joy.d.ts.map