import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function floatingActionButtonGroupElementSohoStyle(): CSSResult;
//# sourceMappingURL=FloatingActionButtonGroupElement.Soho.d.ts.map