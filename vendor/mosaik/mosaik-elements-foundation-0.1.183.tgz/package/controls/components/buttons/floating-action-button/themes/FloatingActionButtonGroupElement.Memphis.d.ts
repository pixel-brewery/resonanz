import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function floatingActionButtonGroupElementMemphisStyle(): CSSResult;
//# sourceMappingURL=FloatingActionButtonGroupElement.Memphis.d.ts.map