import type { IBusyableProps } from '../../../behaviors/Busyable';
import type { IIconableProps } from '../../../behaviors/Iconable';
import type { ILabelableProps } from '../../../behaviors/Labelable';
import type { IThemeableProps } from '../../../behaviors/Themeable';
import type { IButtonBaseElementProps } from '../abstracts/IButtonBaseElementProps';
/**
 * Represents the `IFabElementProps` interface.
 *
 * @public
 */
export interface IFloatingActionButtonElementProps extends IButtonBaseElementProps, IBusyableProps, ILabelableProps, IIconableProps, IThemeableProps {
}
//# sourceMappingURL=IFloatingActionButtonElementProps.d.ts.map