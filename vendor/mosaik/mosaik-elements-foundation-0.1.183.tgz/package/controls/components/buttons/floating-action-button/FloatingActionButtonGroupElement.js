// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Appearanceable } from '../../../behaviors/Appearanceable';
import { Closeable } from '../../../behaviors/Closeable';
import { Disableable } from '../../../behaviors/Disableable';
import { Iconable } from '../../../behaviors/Iconable';
import { Labelable } from '../../../behaviors/Labelable';
import { Openable } from '../../../behaviors/Openable';
import { Slottable } from '../../../behaviors/Slottable';
import { Themeable } from '../../../behaviors/Themeable';
import { Variantable } from '../../../behaviors/Variantable';
import { addClickOutsideController } from '../../../controllers/ClickOutsideController';
import { addInheritanceProviderController } from '../../../controllers/InheritanceProviderController';
import { Attribute } from '../../../decorators/AttributeDecorator';
import { Component } from '../../../decorators/ComponentDecorator';
import { FabGroupDirection } from '../../../types/FabGroupDirection';
import { CustomElement } from '../../abstracts/CustomElement';
import { FloatingActionButtonElement } from './FloatingActionButtonElement';
import { floatingActionButtonGroupElementTemplate } from './FloatingActionButtonGroupElementTemplate';
import { FAB_GROUP_INHERITANCE_CONTEXT } from './FloatingActionButtonGroupInheritanceContext';
import { floatingActionButtonGroupElementCosmopolitanStyle } from './themes/FloatingActionButtonGroupElement.Cosmopolitan';
import { floatingActionButtonGroupElementJoyStyle } from './themes/FloatingActionButtonGroupElement.Joy';
import { floatingActionButtonGroupElementMemphisStyle } from './themes/FloatingActionButtonGroupElement.Memphis';
import { floatingActionButtonGroupElementSohoStyle } from './themes/FloatingActionButtonGroupElement.Soho';
// #endregion
/**
 * Floating Action Button Group - A group of Floating Action Buttons that trigger primary actions in an application.
 *
 * @description
 * The Floating Action Button Group is a UI component that organizes multiple Floating Action Buttons (FABs) into a
 * cohesive group. This component is designed to provide users with multiple primary actions in a compact and accessible
 * format. Each button within the group can trigger a different action, making it ideal for applications that require
 * multiple high-priority actions to be easily accessible.
 *
 * @name Floating Action Button Group
 * @element mosaik-fab-group
 * @category Buttons
 *
 * @slot - The default slot for FABs.
 * @slot overlay - The overlay slot (useful for badges or additional visual elements).
 * @slot trigger - The trigger slot for initiating the FAB group.
 *
 * @csspart fab - The FAB part within the group.
 * @csspart menu - The menu part of the FAB group.
 *
 * @cssprop {String} --fab-group-font-family - The action button group font family CSS custom property.
 * @cssprop {String} --fab-group-font-letter-spacing - The action button group font letter spacing CSS custom property.
 * @cssprop {String} --fab-group-font-line-height - The action button group font line height CSS custom property.
 * @cssprop {String} --fab-group-font-size - The action button group font size CSS custom property.
 * @cssprop {String} --fab-group-font-text-decoration - The action button group font text decoration CSS custom property.
 * @cssprop {String} --fab-group-font-text-transform - The action button group font text transform CSS custom property.
 * @cssprop {String} --fab-group-font-weight - The action button group font weight CSS custom property.
 * @cssprop {String} --fab-group-gap - The action button group gap CSS custom property.
 * @cssprop {String} --fab-group-padding-bottom - The action button group padding bottom CSS custom property.
 * @cssprop {String} --fab-group-padding-left - The action button group padding left CSS custom property.
 * @cssprop {String} --fab-group-padding-right - The action button group padding right CSS custom property.
 * @cssprop {String} --fab-group-padding-top - The action button group padding top CSS custom property.
 * @cssprop {String} --fab-group-shadow - The action button group shadow CSS custom property.
 * @cssprop {String} --fab-group-shadow-blur - The action button group shadow blur CSS custom property.
 * @cssprop {String} --fab-group-shadow-color - The action button group shadow color CSS custom property.
 * @cssprop {String} --fab-group-shadow-offset-x - The action button group shadow offset x CSS custom property.
 * @cssprop {String} --fab-group-shadow-offset-y - The action button group shadow offset y CSS custom property.
 * @cssprop {String} --fab-group-shadow-spread - The action button group shadow spread CSS custom property.
 * @cssprop {String} --fab-group-transition-duration - The action button group transition duration CSS custom property.
 * @cssprop {String} --fab-group-transition-mode - The action button group transition mode CSS custom property.
 * @cssprop {String} --fab-group-transition-property - The action button group transition property CSS custom property.
 * @cssprop {String} --fab-group-translate - The action button group translate CSS custom property.
 *
 * @fires opened {OpenedEvent} - Called when the FAB group is opened.
 * @fires closed {ClosedEvent} - Called when the FAB group is closed.
 *
 * @dependency {FloatingActionButtonElement} mosaik-fab - The Floating Action Button component.
 *
 * @example
 * Basic FAB group with trigger and action buttons:
 * ```html
 * <mosaik-fab-group>
 *   <mosaik-fab slot="trigger" label="Menu" variant="primary"></mosaik-fab>
 *   <mosaik-fab label="Add"></mosaik-fab>
 *   <mosaik-fab label="Edit"></mosaik-fab>
 *   <mosaik-fab label="Delete"></mosaik-fab>
 * </mosaik-fab-group>
 * ```
 *
 * @example
 * FAB group that opens upward:
 * ```html
 * <mosaik-fab-group direction="top">
 *   <mosaik-fab slot="trigger" variant="primary"></mosaik-fab>
 *   <mosaik-fab label="Share"></mosaik-fab>
 *   <mosaik-fab label="Copy"></mosaik-fab>
 * </mosaik-fab-group>
 * ```
 *
 * @public
 */
let FloatingActionButtonGroupElement = class FloatingActionButtonGroupElement extends Themeable(Openable(Closeable(Disableable(Appearanceable(Variantable(Labelable(Iconable(Slottable(CustomElement))))))))) {
    // #region Fields
    _provider = addInheritanceProviderController(this, {
        context: FAB_GROUP_INHERITANCE_CONTEXT,
        values: () => ({
            disabled: this.disabled,
            appearance: this.appearance,
            variant: this.variant
        })
    });
    _clickOutsideController = addClickOutsideController(this, {
        skipInitial: true,
        callback: () => this.onClickedOutside()
    });
    _isOpen;
    _direction;
    // #endregion
    // #region Ctor
    /**
     * @public
     */
    constructor() {
        super();
        this._isOpen = false;
        this._direction = FabGroupDirection.Top;
    }
    // #endregion
    // #region Properties
    /**
     * Returns the `is` property.
     * The `is` property represents natural name of this element.
     *
     * @public
     * @static
     * @readonly
     */
    static get is() {
        return 'mosaik-fab-group';
    }
    /**
     * Gets or sets the `isOpen` property that allows you to show or hide the `FloatingActionButtonGroupElement` menu.
     *
     * @public
     * @attr is-open
     */
    get isOpen() {
        return this._isOpen;
    }
    set isOpen(value) {
        if (this._isOpen !== value) {
            if (value) {
                void this.open();
            }
            else {
                void this.close();
            }
        }
    }
    /**
     * Gets or sets the `direction` property.
     *
     * @public
     * @attr direction
     */
    get direction() {
        return this._direction;
    }
    set direction(value) {
        if (this._direction !== value) {
            this._direction = value;
            this.requestUpdate('direction');
        }
    }
    // #endregion
    // #region Methods
    /**
     * @public
     * @override
     */
    onSlotChanges() {
        const elements = this.getSlotAssignments('')
            .filter((x) => x instanceof FloatingActionButtonElement);
        for (const [i, e] of elements.entries()) {
            e.tabIndex = this.isOpen ? 0 : -1;
            e.style.transitionDelay = `${this.isOpen ? i * 25 : 0}ms`;
            e.classList.add('fab-group-button');
            e.classList.toggle('first', i === 0);
            e.classList.toggle('inner', i > 0 && i < elements.length - 1);
            e.classList.toggle('last', i === elements.length - 1);
        }
    }
    /**
     * Opens the FAB group.
     *
     * @public
     * @override
     */
    async open() {
        if (this.disabled) {
            return;
        }
        if (this._isOpen) {
            return;
        }
        return super.open()
            .then(() => {
            this._isOpen = true;
            this.requestUpdate('isOpen');
        })
            .then(() => {
            this._clickOutsideController.observe();
        });
    }
    /**
     * Close the FAB group.
     *
     * @public
     * @override
     */
    async close() {
        if (this.disabled) {
            return false;
        }
        if (!this._isOpen) {
            return false;
        }
        return super.close()
            .then((x) => {
            this._isOpen = false;
            this.requestUpdate('isOpen');
            return x;
        })
            .then((x) => {
            this._clickOutsideController.unobserve();
            return x;
        });
    }
    /**
     * Toggles the FAB group.
     *
     * @public
     */
    async toggle() {
        if (this._isOpen) {
            return this.close().then(() => void 0);
        }
        return this.open();
    }
    /**
     * @private
     */
    onClickedOutside() {
        void this.close();
    }
};
__decorate([
    Attribute({
        type: Boolean,
        useDefault: true
    }),
    __metadata("design:type", Boolean),
    __metadata("design:paramtypes", [Boolean])
], FloatingActionButtonGroupElement.prototype, "isOpen", null);
__decorate([
    Attribute({ type: FabGroupDirection }),
    __metadata("design:type", String),
    __metadata("design:paramtypes", [String])
], FloatingActionButtonGroupElement.prototype, "direction", null);
FloatingActionButtonGroupElement = __decorate([
    Component({
        selector: 'mosaik-fab-group',
        template: floatingActionButtonGroupElementTemplate,
        themes: {
            joy: floatingActionButtonGroupElementJoyStyle,
            memphis: floatingActionButtonGroupElementMemphisStyle,
            cosmopolitan: floatingActionButtonGroupElementCosmopolitanStyle,
            soho: floatingActionButtonGroupElementSohoStyle
        },
        host: {
            role: 'group'
        },
        imports: [FloatingActionButtonElement]
    }),
    __metadata("design:paramtypes", [])
], FloatingActionButtonGroupElement);
export { FloatingActionButtonGroupElement };
//# sourceMappingURL=FloatingActionButtonGroupElement.js.map