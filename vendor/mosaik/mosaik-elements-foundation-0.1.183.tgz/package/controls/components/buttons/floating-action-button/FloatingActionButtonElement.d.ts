import type { Appearance } from '../../../types/Appearance';
import type { Variant } from '../../../types/Variant';
import { ButtonBaseElement } from '../abstracts/ButtonBaseElement';
import type { IFloatingActionButtonElementProps } from './IFloatingActionButtonElementProps';
declare const FloatingActionButtonElement_base: (abstract new (...args: Array<any>) => import("../../../behaviors/Themeable").IThemeableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Busyable").IBusyableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Labelable").ILabelableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Iconable").IIconableProps) & typeof ButtonBaseElement & import("../../../behaviors/Themeable").IThemeableCtor;
/**
 * FloatingActionButton - A prominent circular button designed for primary actions with elevated visual prominence.
 *
 * @description
 * The FloatingActionButton component creates a distinctive, floating interactive element optimized
 * for triggering the most important action on a screen. It features elevated styling with shadow
 * effects, circular geometry, ripple feedback, and optional text labels for extended variations.
 * The component is designed to draw user attention to critical functionality such as creating content,
 * composing messages, or initiating primary workflows. It includes advanced features like elevation
 * shadows, ripple effects, focus rings, progress indicators, and comprehensive accessibility support,
 * making it ideal for Material Design-inspired interfaces requiring prominent action triggers.
 *
 * @name FloatingActionButton
 * @element mosaik-fab
 * @category Buttons
 *
 * @slot icon - Icon content area for the primary visual action indicator
 * @slot label - Optional text label for extended floating action button variations
 * @slot overlay - Overlay content area for badges, notifications, or status indicators
 *
 * @csspart button - The main button element container
 * @csspart elevation - The elevation shadow effect container for visual prominence
 * @csspart focusRing - The focus indicator ring for keyboard navigation accessibility
 * @csspart icon - The icon display area within the button
 * @csspart innerStack - The internal stack layout container for organizing icon and label
 * @csspart label - The text label display area for extended button variations
 * @csspart progressRing - The busy state progress indicator
 * @csspart ripple - The touch feedback ripple effect container
 *
 * @cssprop {String} --fab-background-color - The background fill color
 * @cssprop {String} --fab-border-color - The border outline color
 * @cssprop {String} --fab-border-radius - The corner rounding radius for circular shape
 * @cssprop {String} --fab-border-style - The border line style
 * @cssprop {String} --fab-border-width - The border thickness
 * @cssprop {String} --fab-focus-ring-active-width - The focus ring width when active (from focusRing mixin)
 * @cssprop {String} --fab-focus-ring-color - The focus ring color (from focusRing mixin)
 * @cssprop {String} --fab-focus-ring-inward-offset - The focus ring inward offset (from focusRing mixin)
 * @cssprop {String} --fab-focus-ring-outward-offset - The focus ring outward offset (from focusRing mixin)
 * @cssprop {String} --fab-font-family - The font family for button text and labels
 * @cssprop {String} --fab-font-letter-spacing - The letter spacing for button text
 * @cssprop {String} --fab-font-line-height - The line height for button text
 * @cssprop {String} --fab-font-size - The font size for button text
 * @cssprop {String} --fab-font-text-decoration - The text decoration style for button text
 * @cssprop {String} --fab-font-text-transform - The text transformation style for button text
 * @cssprop {String} --fab-font-weight - The font weight for button text
 * @cssprop {String} --fab-foreground-color - The icon and text color
 * @cssprop {String} --fab-gap - The spacing between icon and label elements
 * @cssprop {String} --fab-icon-min-height - The minimum height for icon display area
 * @cssprop {String} --fab-icon-min-width - The minimum width for icon display area
 * @cssprop {String} --fab-min-height - The minimum button height
 * @cssprop {String} --fab-min-width - The minimum button width
 * @cssprop {String} --fab-padding-bottom - The bottom padding inside the button
 * @cssprop {String} --fab-padding-left - The left padding inside the button
 * @cssprop {String} --fab-padding-right - The right padding inside the button
 * @cssprop {String} --fab-padding-top - The top padding inside the button
 * @cssprop {String} --fab-progress-ring-width - The action button progress ring width CSS custom property.
 * @cssprop {String} --fab-ripple-color - The ripple effect color (from ripple mixin)
 * @cssprop {String} --fab-ripple-duration - The ripple effect animation duration (from ripple mixin)
 * @cssprop {String} --fab-shadow - The drop shadow or elevation effect
 * @cssprop {String} --fab-shadow-blur - The action button shadow blur CSS custom property.
 * @cssprop {String} --fab-shadow-color - The action button shadow color CSS custom property.
 * @cssprop {String} --fab-shadow-offset-x - The action button shadow offset x CSS custom property.
 * @cssprop {String} --fab-shadow-offset-y - The action button shadow offset y CSS custom property.
 * @cssprop {String} --fab-shadow-spread - The action button shadow spread CSS custom property.
 * @cssprop {String} --fab-transition-duration - The duration of hover and focus transitions
 * @cssprop {String} --fab-transition-mode - The timing function for transitions
 * @cssprop {String} --fab-transition-property - The CSS properties to animate during transitions
 * @cssprop {String} --fab-translate - The action button translate CSS custom property.
 *
 * @dependency mosaik-elevation - The Elevation element.
 * @dependency mosaik-focus-ring - The Focus Ring element.
 * @dependency mosaik-icon - The Icon element.
 * @dependency mosaik-progress-ring - The Progress Ring element.
 * @dependency mosaik-ripple - The Ripple element.
 * @dependency mosaik-stack - The Stack element.
 * @dependency mosaik-text - The Text element.
 *
 * @example
 * Basic floating action button:
 * ```html
 * <mosaik-fab variant="primary"></mosaik-fab>
 * ```
 *
 * @example
 * Extended floating action button with label:
 * ```html
 * <mosaik-fab label="Compose"
 *             variant="primary"
 *             appearance="solid"></mosaik-fab>
 * ```
 *
 * @public
 */
export declare class FloatingActionButtonElement extends FloatingActionButtonElement_base implements IFloatingActionButtonElementProps {
    private readonly _inheritance;
    /**
     * @public
     */
    constructor();
    /**
     * Returns the `is` property.
     * The `is` property represents natural name of this element.
     *
     * @public
     * @static
     * @readonly
     */
    static get is(): string;
    /**
     * @public
     * @override
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * @public
     * @override
     */
    get appearance(): Appearance;
    set appearance(value: Appearance);
    /**
     * @public
     * @override
     */
    get variant(): Variant;
    set variant(value: Variant);
}
/**
 * @public
 */
export declare namespace FloatingActionButtonElement {
    type Props = IFloatingActionButtonElementProps;
}
/**
 * @public
 */
declare global {
    interface HTMLElementTagNameMap {
        'mosaik-fab': FloatingActionButtonElement;
    }
}
export {};
//# sourceMappingURL=FloatingActionButtonElement.d.ts.map