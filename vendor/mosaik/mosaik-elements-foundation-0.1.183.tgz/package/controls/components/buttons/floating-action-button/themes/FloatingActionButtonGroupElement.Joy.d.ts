import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function floatingActionButtonGroupElementJoyStyle(): CSSResult;
//# sourceMappingURL=FloatingActionButtonGroupElement.Joy.d.ts.map