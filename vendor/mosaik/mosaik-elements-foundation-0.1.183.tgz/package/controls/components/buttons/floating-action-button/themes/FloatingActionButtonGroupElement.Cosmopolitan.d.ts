import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function floatingActionButtonGroupElementCosmopolitanStyle(): CSSResult;
//# sourceMappingURL=FloatingActionButtonGroupElement.Cosmopolitan.d.ts.map