import type { IAppearanceableProps } from '../../../behaviors/Appearanceable';
import type { ICloseableProps } from '../../../behaviors/Closeable';
import type { IDisableableProps } from '../../../behaviors/Disableable';
import type { IIconableProps } from '../../../behaviors/Iconable';
import type { ILabelableProps } from '../../../behaviors/Labelable';
import type { ISlottableProps } from '../../../behaviors/Slottable';
import type { IThemeableProps } from '../../../behaviors/Themeable';
import type { IVariantableProps } from '../../../behaviors/Variantable';
import type { FabGroupDirection } from '../../../types/FabGroupDirection';
/**
 * Represents the `IFloatingActionButtonGroupElementProps` interface.
 *
 * @public
 */
export interface IFloatingActionButtonGroupElementProps extends IDisableableProps, ICloseableProps, IVariantableProps, IAppearanceableProps, ILabelableProps, IIconableProps, IThemeableProps, ISlottableProps {
    isOpen: boolean;
    direction: FabGroupDirection;
}
//# sourceMappingURL=IFloatingActionButtonGroupElementProps.d.ts.map