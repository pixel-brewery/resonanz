import { type TemplateResult } from '../../../../dom/Html';
import type { FloatingActionButtonElement } from './FloatingActionButtonElement';
/**
 * The template of the `FloatingActionButtonElement`.
 *
 * @public
 */
export declare function floatingActionButtonElementTemplate<T extends FloatingActionButtonElement>(e: T): TemplateResult;
//# sourceMappingURL=FloatingActionButtonElementTemplate.d.ts.map