import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function floatingActionButtonElementSohoStyle(): CSSResult;
//# sourceMappingURL=FloatingActionButtonElement.Soho.d.ts.map