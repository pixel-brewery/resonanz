import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function floatingActionButtonElementMemphisStyle(): CSSResult;
//# sourceMappingURL=FloatingActionButtonElement.Memphis.d.ts.map