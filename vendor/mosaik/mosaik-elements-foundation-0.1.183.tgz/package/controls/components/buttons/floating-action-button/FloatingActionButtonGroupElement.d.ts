import { type ICloseable } from '../../../behaviors/Closeable';
import { type IOpenable } from '../../../behaviors/Openable';
import { ISlottable } from '../../../behaviors/Slottable';
import { FabGroupDirection } from '../../../types/FabGroupDirection';
import { CustomElement } from '../../abstracts/CustomElement';
import type { IFloatingActionButtonGroupElementProps } from './IFloatingActionButtonGroupElementProps';
declare const FloatingActionButtonGroupElement_base: (abstract new (...args: Array<any>) => import("../../../behaviors/Themeable").IThemeableProps) & (abstract new (...args: Array<any>) => IOpenable & import("../../../behaviors/Openable").IOpenableEvents) & (abstract new (...args: Array<any>) => import("../../../behaviors/Closeable").ICloseableProps & import("../../../behaviors/Closeable").ICloseableEvents & ICloseable) & (abstract new (...args: Array<any>) => import("../../../behaviors/Disableable").IDisableableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Appearanceable").IAppearanceableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Variantable").IVariantableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Labelable").ILabelableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Iconable").IIconableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Slottable").ISlottableProps & ISlottable) & typeof CustomElement & import("../../../behaviors/Themeable").IThemeableCtor;
/**
 * Floating Action Button Group - A group of Floating Action Buttons that trigger primary actions in an application.
 *
 * @description
 * The Floating Action Button Group is a UI component that organizes multiple Floating Action Buttons (FABs) into a
 * cohesive group. This component is designed to provide users with multiple primary actions in a compact and accessible
 * format. Each button within the group can trigger a different action, making it ideal for applications that require
 * multiple high-priority actions to be easily accessible.
 *
 * @name Floating Action Button Group
 * @element mosaik-fab-group
 * @category Buttons
 *
 * @slot - The default slot for FABs.
 * @slot overlay - The overlay slot (useful for badges or additional visual elements).
 * @slot trigger - The trigger slot for initiating the FAB group.
 *
 * @csspart fab - The FAB part within the group.
 * @csspart menu - The menu part of the FAB group.
 *
 * @cssprop {String} --fab-group-font-family - The action button group font family CSS custom property.
 * @cssprop {String} --fab-group-font-letter-spacing - The action button group font letter spacing CSS custom property.
 * @cssprop {String} --fab-group-font-line-height - The action button group font line height CSS custom property.
 * @cssprop {String} --fab-group-font-size - The action button group font size CSS custom property.
 * @cssprop {String} --fab-group-font-text-decoration - The action button group font text decoration CSS custom property.
 * @cssprop {String} --fab-group-font-text-transform - The action button group font text transform CSS custom property.
 * @cssprop {String} --fab-group-font-weight - The action button group font weight CSS custom property.
 * @cssprop {String} --fab-group-gap - The action button group gap CSS custom property.
 * @cssprop {String} --fab-group-padding-bottom - The action button group padding bottom CSS custom property.
 * @cssprop {String} --fab-group-padding-left - The action button group padding left CSS custom property.
 * @cssprop {String} --fab-group-padding-right - The action button group padding right CSS custom property.
 * @cssprop {String} --fab-group-padding-top - The action button group padding top CSS custom property.
 * @cssprop {String} --fab-group-shadow - The action button group shadow CSS custom property.
 * @cssprop {String} --fab-group-shadow-blur - The action button group shadow blur CSS custom property.
 * @cssprop {String} --fab-group-shadow-color - The action button group shadow color CSS custom property.
 * @cssprop {String} --fab-group-shadow-offset-x - The action button group shadow offset x CSS custom property.
 * @cssprop {String} --fab-group-shadow-offset-y - The action button group shadow offset y CSS custom property.
 * @cssprop {String} --fab-group-shadow-spread - The action button group shadow spread CSS custom property.
 * @cssprop {String} --fab-group-transition-duration - The action button group transition duration CSS custom property.
 * @cssprop {String} --fab-group-transition-mode - The action button group transition mode CSS custom property.
 * @cssprop {String} --fab-group-transition-property - The action button group transition property CSS custom property.
 * @cssprop {String} --fab-group-translate - The action button group translate CSS custom property.
 *
 * @fires opened {OpenedEvent} - Called when the FAB group is opened.
 * @fires closed {ClosedEvent} - Called when the FAB group is closed.
 *
 * @dependency {FloatingActionButtonElement} mosaik-fab - The Floating Action Button component.
 *
 * @example
 * Basic FAB group with trigger and action buttons:
 * ```html
 * <mosaik-fab-group>
 *   <mosaik-fab slot="trigger" label="Menu" variant="primary"></mosaik-fab>
 *   <mosaik-fab label="Add"></mosaik-fab>
 *   <mosaik-fab label="Edit"></mosaik-fab>
 *   <mosaik-fab label="Delete"></mosaik-fab>
 * </mosaik-fab-group>
 * ```
 *
 * @example
 * FAB group that opens upward:
 * ```html
 * <mosaik-fab-group direction="top">
 *   <mosaik-fab slot="trigger" variant="primary"></mosaik-fab>
 *   <mosaik-fab label="Share"></mosaik-fab>
 *   <mosaik-fab label="Copy"></mosaik-fab>
 * </mosaik-fab-group>
 * ```
 *
 * @public
 */
export declare class FloatingActionButtonGroupElement extends FloatingActionButtonGroupElement_base implements IFloatingActionButtonGroupElementProps, IOpenable, ICloseable, ISlottable {
    private readonly _provider;
    private readonly _clickOutsideController;
    private _isOpen;
    private _direction;
    /**
     * @public
     */
    constructor();
    /**
     * Returns the `is` property.
     * The `is` property represents natural name of this element.
     *
     * @public
     * @static
     * @readonly
     */
    static get is(): string;
    /**
     * Gets or sets the `isOpen` property that allows you to show or hide the `FloatingActionButtonGroupElement` menu.
     *
     * @public
     * @attr is-open
     */
    get isOpen(): boolean;
    set isOpen(value: boolean);
    /**
     * Gets or sets the `direction` property.
     *
     * @public
     * @attr direction
     */
    get direction(): FabGroupDirection;
    set direction(value: FabGroupDirection);
    /**
     * @public
     * @override
     */
    onSlotChanges(): void;
    /**
     * Opens the FAB group.
     *
     * @public
     * @override
     */
    open(): Promise<void>;
    /**
     * Close the FAB group.
     *
     * @public
     * @override
     */
    close(): Promise<boolean>;
    /**
     * Toggles the FAB group.
     *
     * @public
     */
    toggle(): Promise<void>;
    /**
     * @private
     */
    private onClickedOutside;
}
/**
 * @public
 */
export declare namespace FloatingActionButtonGroupElement {
    type Props = IFloatingActionButtonGroupElementProps;
}
/**
 * @public
 */
declare global {
    interface HTMLElementTagNameMap {
        'mosaik-fab-group': FloatingActionButtonGroupElement;
    }
}
export {};
//# sourceMappingURL=FloatingActionButtonGroupElement.d.ts.map