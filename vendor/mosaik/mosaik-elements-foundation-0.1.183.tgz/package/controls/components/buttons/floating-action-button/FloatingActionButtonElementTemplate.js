// #region Imports
import { html } from '../../../../dom/Html';
import { ifDefined, when } from '../../../directives/Directives';
import { Appearance } from '../../../types/Appearance';
import { HorizontalAlignment } from '../../../types/HorizontalAlignment';
import { IconPosition } from '../../../types/IconPosition';
import { Orientation } from '../../../types/Orientation';
import { VerticalAlignment } from '../../../types/VerticalAlignment';
// #endregion
/**
 * The template of the `FloatingActionButtonElement`.
 *
 * @public
 */
export function floatingActionButtonElementTemplate(e) {
    return html `
        ${when(!e.disabled, () => html `
        <mosaik-focus-ring part="focusRing"
                           .variant="${e.variant}"
                           .visible="${e.isFocused}"
                           .controlled="${'manual'}"
                           .for="${'button'}"></mosaik-focus-ring>
        <mosaik-elevation part="elevation"
                          .weigh="${'light'}"
                          .for="${'button'}"></mosaik-elevation>
        `)}
        <button id="button"
                part="button"
                aria-label="${ifDefined(e.getAttribute('aria-label') ?? undefined)}"
                type="${e.type}">
            ${when(!e.disabled && e.ripple, () => html `
            <mosaik-ripple part="ripple"
                           .variant="${e.variant}"
                           .for="${'button'}"></mosaik-ripple>
            `)}
            <mosaik-stack part="innerStack" .orientation="${Orientation.Horizontal}"
                          .verticalAlignment="${VerticalAlignment.Center}"
                          .horizontalAlignment="${HorizontalAlignment.Center}"
                          ?reverse="${e.iconPosition === IconPosition.After}">
                <slot name="icon">
                ${when(e.icon, () => html `
                    <mosaik-icon part="icon"
                                 .appearance="${Appearance.Plain}"
                                 .variant="${e.variant}"
                                 .icon="${e.icon}"
                                 .size="${e.iconSize ?? e.size}"
                                 ?inline="${true}"
                                 ?disabled="${e.disabled}"></mosaik-icon>
                `)}
                </slot>
                <slot name="label">
                ${when(e.label, () => html `
                    <mosaik-text part="label"
                                 .text="${e.label}"
                                 .variant="${e.variant}"
                                 ?disabled="${e.disabled}"></mosaik-text>
                `)}
                </slot>
            </mosaik-stack>
        </button>
        ${when(e.isBusy, () => html `
        <mosaik-progress-ring part="progressRing"
                              .lang="${e.lang}"
                              .dir="${e.dir}"
                              .radius="${'12px'}"
                              .variant="${e.variant}"
                              .isIndeterminate="${true}"
                              ?disabled="${e.disabled}"></mosaik-progress-ring>
        `)}
        <slot name="overlay"></slot>
    `;
}
//# sourceMappingURL=FloatingActionButtonElementTemplate.js.map