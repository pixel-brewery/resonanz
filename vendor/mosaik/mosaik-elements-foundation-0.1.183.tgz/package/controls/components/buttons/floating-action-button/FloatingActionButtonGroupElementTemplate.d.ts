import { type TemplateResult } from '../../../../dom/Html';
import type { FloatingActionButtonGroupElement } from './FloatingActionButtonGroupElement';
/**
 * The template of the `FloatingActionButtonGroupElement`.
 *
 * @public
 */
export declare function floatingActionButtonGroupElementTemplate<T extends FloatingActionButtonGroupElement>(e: T): TemplateResult;
//# sourceMappingURL=FloatingActionButtonGroupElementTemplate.d.ts.map