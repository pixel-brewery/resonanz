// #region Imports
export {};
//# sourceMappingURL=IFloatingActionButtonElementProps.js.map