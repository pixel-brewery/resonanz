import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function floatingActionButtonElementCosmopolitanStyle(): CSSResult;
//# sourceMappingURL=FloatingActionButtonElement.Cosmopolitan.d.ts.map