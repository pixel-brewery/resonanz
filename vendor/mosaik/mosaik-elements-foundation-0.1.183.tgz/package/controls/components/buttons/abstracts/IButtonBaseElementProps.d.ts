import type { IAppearanceableProps } from '../../../behaviors/Appearanceable';
import type { IDisableableProps } from '../../../behaviors/Disableable';
import type { IFocusableProps } from '../../../behaviors/Focusable';
import type { IRippleableProps } from '../../../behaviors/Rippleable';
import type { ISizeableProps } from '../../../behaviors/Sizeable';
import type { IValueableProps } from '../../../behaviors/Valueable';
import type { IVariantableProps } from '../../../behaviors/Variantable';
import type { ButtonType } from '../../../types/ButtonType';
/**
 * Represents the `IButtonBaseElementProps` interface.
 *
 * @public
 */
export interface IButtonBaseElementProps extends IValueableProps, ISizeableProps, IAppearanceableProps, IVariantableProps, IDisableableProps, IFocusableProps, IRippleableProps {
    /**
     * The type of the button.
     */
    type: ButtonType;
}
//# sourceMappingURL=IButtonBaseElementProps.d.ts.map