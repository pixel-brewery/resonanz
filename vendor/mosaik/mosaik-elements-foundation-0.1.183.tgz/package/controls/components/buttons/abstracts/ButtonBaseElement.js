// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Appearanceable } from '../../../behaviors/Appearanceable';
import { Disableable } from '../../../behaviors/Disableable';
import { Focusable } from '../../../behaviors/Focusable';
import { Rippleable } from '../../../behaviors/Rippleable';
import { Sizeable } from '../../../behaviors/Sizeable';
import { Valueable } from '../../../behaviors/Valueable';
import { Variantable } from '../../../behaviors/Variantable';
import { Attribute } from '../../../decorators/AttributeDecorator';
import { ButtonType } from '../../../types/ButtonType';
import { CustomElement } from '../../abstracts/CustomElement';
// #endregion
/**
 * Button Base Element - The foundational base class for all button-type components.
 *
 * @description
 * ButtonBaseElement provides the core functionality and behavior patterns for all button-like
 * interactive controls in the Mosaik design system. It combines essential behaviors including
 * focus management, disabled states, visual variants, sizing, appearance modes, and value tracking.
 * This abstract class establishes the common API surface for buttons, icon buttons, toggle buttons,
 * and other clickable controls. It manages the button type attribute (button/submit/reset) which
 * determines how the button interacts with parent forms. All concrete button implementations
 * extend this base class to inherit consistent behavioral patterns and styling hooks.
 *
 * @remarks
 * The class applies multiple behavior mixins in a specific composition order: Focusable (innermost)
 * → Disableable → Valueable → Sizeable → Appearanceable → Variantable (outermost). This layering
 * ensures proper inheritance of lifecycle hooks and property override patterns.
 *
 * @name ButtonBaseElement
 * @category Abstract Elements
 *
 * @fires connected {ConnectedEvent} - Emitted when the element is connected to the DOM
 * @fires disconnected {DisconnectedEvent} - Emitted when the element is disconnected from the DOM
 * @fires changed {PropertyChangedEvent} - Emitted when any attribute changes before update
 *
 * @example
 * Extending ButtonBaseElement to create a custom button:
 * ```typescript
 * export class IconButtonElement extends ButtonBaseElement {
 *   constructor() {
 *     super();
 *   }
 *
 *   protected override render() {
 *     return html`<button type="${this.type}"><slot></slot></button>`;
 *   }
 * }
 * ```
 *
 * @abstract
 * @public
 */
export class ButtonBaseElement extends Rippleable(Variantable(Appearanceable(Sizeable(Valueable(Disableable(Focusable(CustomElement))))))) {
    // #region Fields
    _type;
    // #endregion
    // #region Ctor
    /**
     * @public
     */
    constructor() {
        super();
        this._type = ButtonType.Button;
    }
    // #endregion
    // #region Properties
    /**
     * Observes the accessible name shared by all primary native button variants.
     *
     * @public
     * @static
     * @override
     * @readonly
     */
    static get observedAttributes() {
        return [...super.observedAttributes, 'aria-label'];
    }
    /**
     * Gets or sets the `type` property.
     * It modifies the classification and default behavior of the `ButtonElement`.
     * `submit` and `reset` are only necessary when the `ButtonElement` is located in a form and should control this actions.
     *
     * @public
     * @attr type
     */
    get type() {
        return this._type;
    }
    set type(value) {
        if (this._type !== value) {
            this._type = value;
            this.requestUpdate('type');
        }
    }
    // #endregion
    // #region Methods
    /**
     * Forwards the standard focus API to this button's native interactive control.
     * Disabled and not-yet-rendered controls keep the current focus unchanged.
     *
     * @public
     * @override
     * @param options - Standard browser focus options.
     */
    focus(options) {
        if (!this.disabled) {
            this.shadowRoot?.querySelector('[part="button"]')?.focus(options);
        }
    }
    /**
     * Keeps the primary native button's explicit name current.
     *
     * @public
     * @override
     */
    attributeChangedCallback(name, old, value) {
        super.attributeChangedCallback(name, old, value);
        if (name === 'aria-label' && old !== value) {
            this.requestUpdate();
        }
    }
    /**
     * @protected
     * @override
     */
    onApplyTemplate() {
        super.onApplyTemplate();
    }
}
__decorate([
    Attribute({ type: ButtonType }),
    __metadata("design:type", String),
    __metadata("design:paramtypes", [String])
], ButtonBaseElement.prototype, "type", null);
//# sourceMappingURL=ButtonBaseElement.js.map