// #region Imports
export {};
//# sourceMappingURL=IButtonBaseElementProps.js.map