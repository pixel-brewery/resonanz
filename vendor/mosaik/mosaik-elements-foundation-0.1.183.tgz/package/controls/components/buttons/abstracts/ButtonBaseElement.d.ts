import { ButtonType } from '../../../types/ButtonType';
import { CustomElement } from '../../abstracts/CustomElement';
import type { IButtonBaseElementProps } from './IButtonBaseElementProps';
declare const ButtonBaseElement_base: import("../../../../Index").ControlBehaviorReturn<import("../../../../Index").ControlBehaviorReturn<import("../../../../Index").ControlBehaviorReturn<import("../../../../Index").ControlBehaviorReturn<import("../../../../Index").ControlBehaviorReturn<import("../../../../Index").ControlBehaviorReturn<import("../../../../Index").ControlBehaviorReturn<typeof CustomElement, import("../../../behaviors/Focusable").IFocusableProps>, import("../../../behaviors/Disableable").IDisableableProps>, import("../../../behaviors/Valueable").IValueableProps<unknown>>, import("../../../behaviors/Sizeable").ISizeableProps>, import("../../../behaviors/Appearanceable").IAppearanceableProps>, import("../../../behaviors/Variantable").IVariantableProps>, import("../../../behaviors/Rippleable").IRippleableProps>;
/**
 * Button Base Element - The foundational base class for all button-type components.
 *
 * @description
 * ButtonBaseElement provides the core functionality and behavior patterns for all button-like
 * interactive controls in the Mosaik design system. It combines essential behaviors including
 * focus management, disabled states, visual variants, sizing, appearance modes, and value tracking.
 * This abstract class establishes the common API surface for buttons, icon buttons, toggle buttons,
 * and other clickable controls. It manages the button type attribute (button/submit/reset) which
 * determines how the button interacts with parent forms. All concrete button implementations
 * extend this base class to inherit consistent behavioral patterns and styling hooks.
 *
 * @remarks
 * The class applies multiple behavior mixins in a specific composition order: Focusable (innermost)
 * → Disableable → Valueable → Sizeable → Appearanceable → Variantable (outermost). This layering
 * ensures proper inheritance of lifecycle hooks and property override patterns.
 *
 * @name ButtonBaseElement
 * @category Abstract Elements
 *
 * @fires connected {ConnectedEvent} - Emitted when the element is connected to the DOM
 * @fires disconnected {DisconnectedEvent} - Emitted when the element is disconnected from the DOM
 * @fires changed {PropertyChangedEvent} - Emitted when any attribute changes before update
 *
 * @example
 * Extending ButtonBaseElement to create a custom button:
 * ```typescript
 * export class IconButtonElement extends ButtonBaseElement {
 *   constructor() {
 *     super();
 *   }
 *
 *   protected override render() {
 *     return html`<button type="${this.type}"><slot></slot></button>`;
 *   }
 * }
 * ```
 *
 * @abstract
 * @public
 */
export declare abstract class ButtonBaseElement extends ButtonBaseElement_base implements IButtonBaseElementProps {
    private _type;
    /**
     * @public
     */
    constructor();
    /**
     * Observes the accessible name shared by all primary native button variants.
     *
     * @public
     * @static
     * @override
     * @readonly
     */
    static get observedAttributes(): Array<string>;
    /**
     * Gets or sets the `type` property.
     * It modifies the classification and default behavior of the `ButtonElement`.
     * `submit` and `reset` are only necessary when the `ButtonElement` is located in a form and should control this actions.
     *
     * @public
     * @attr type
     */
    get type(): ButtonType;
    set type(value: ButtonType);
    /**
     * Forwards the standard focus API to this button's native interactive control.
     * Disabled and not-yet-rendered controls keep the current focus unchanged.
     *
     * @public
     * @override
     * @param options - Standard browser focus options.
     */
    focus(options?: FocusOptions): void;
    /**
     * Keeps the primary native button's explicit name current.
     *
     * @public
     * @override
     */
    attributeChangedCallback(name: string, old: string | null, value: string | null): void;
    /**
     * @protected
     * @override
     */
    protected onApplyTemplate(): void;
}
export {};
//# sourceMappingURL=ButtonBaseElement.d.ts.map