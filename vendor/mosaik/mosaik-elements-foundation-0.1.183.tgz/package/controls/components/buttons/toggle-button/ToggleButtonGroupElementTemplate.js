// #region Imports
import { html } from '../../../../dom/Html';
// #endregion
/**
 * The template of the `ToggleButtonGroupElement`.
 *
 * @public
 */
export function toggleButtonGroupElementTemplate(_e) {
    return html `
        <slot></slot>
    `;
}
//# sourceMappingURL=ToggleButtonGroupElementTemplate.js.map