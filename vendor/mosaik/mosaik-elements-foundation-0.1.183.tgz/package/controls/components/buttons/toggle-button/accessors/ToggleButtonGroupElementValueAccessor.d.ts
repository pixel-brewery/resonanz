import { ElementValueAccessorBase } from '../../../../../forms/accessors/abstracts/ElementValueAccessorBase';
import type { ElementValueAccessorFn } from '../../../../../forms/accessors/functions/ElementValueAccessorFn';
import { type ToggleButtonGroupElement } from '../ToggleButtonGroupElement';
export declare class ToggleButtonGroupElementValueAccessor extends ElementValueAccessorBase<ToggleButtonGroupElement> {
    /**
     * @public
     */
    hostConnected(): void;
    /**
     * @public
     * @override
     */
    writeValue(value: unknown | null): void;
    /**
     * @public
     * @override
     */
    resetValue(): void;
}
/**
 * @public
 */
export declare const toggleButtonGroupElementValueAccessor: ElementValueAccessorFn<ToggleButtonGroupElement>;
//# sourceMappingURL=ToggleButtonGroupElementValueAccessor.d.ts.map