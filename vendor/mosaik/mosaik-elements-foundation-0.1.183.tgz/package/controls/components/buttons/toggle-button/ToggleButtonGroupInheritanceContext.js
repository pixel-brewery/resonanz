// #region Imports
import { createContext } from '@lit/context';
/**
 * Context for ToggleButtonGroup → ToggleButton inheritance.
 *
 * @public
 */
export const TOGGLE_BUTTON_GROUP_INHERITANCE_CONTEXT = createContext(Symbol.for('mosaik:toggle-button-group:inheritance'));
//# sourceMappingURL=ToggleButtonGroupInheritanceContext.js.map