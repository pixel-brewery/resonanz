import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function toggleButtonGroupElementJoyStyle(): CSSResult;
//# sourceMappingURL=ToggleButtonGroupElement.Joy.d.ts.map