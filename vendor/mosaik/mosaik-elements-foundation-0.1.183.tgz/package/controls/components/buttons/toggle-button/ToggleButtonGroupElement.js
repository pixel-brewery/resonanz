// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { HTMLElementEventEmitter } from '@pixel-brewery/mosaik-elements';
import { Emit } from '../../../../events/decorators/EmitDecorator';
import { Appearanceable } from '../../../behaviors/Appearanceable';
import { Disableable } from '../../../behaviors/Disableable';
import { Invalidable } from '../../../behaviors/Invalidable';
import { Orientable } from '../../../behaviors/Orientable';
import { Slottable } from '../../../behaviors/Slottable';
import { Themeable } from '../../../behaviors/Themeable';
import { Valueable } from '../../../behaviors/Valueable';
import { Variantable } from '../../../behaviors/Variantable';
import { addInheritanceProviderController } from '../../../controllers/InheritanceProviderController';
import { Component } from '../../../decorators/ComponentDecorator';
import { Watch } from '../../../decorators/WatchDecorator';
import { CustomElement } from '../../abstracts/CustomElement';
import { toggleButtonGroupElementValueAccessor } from './accessors/ToggleButtonGroupElementValueAccessor';
import { toggleButtonGroupElementCosmopolitanStyle } from './themes/ToggleButtonGroupElement.Cosmopolitan';
import { toggleButtonGroupElementJoyStyle } from './themes/ToggleButtonGroupElement.Joy';
import { toggleButtonGroupElementMemphisStyle } from './themes/ToggleButtonGroupElement.Memphis';
import { toggleButtonGroupElementSohoStyle } from './themes/ToggleButtonGroupElement.Soho';
import { ToggleButtonElement } from './ToggleButtonElement';
import { toggleButtonGroupElementTemplate } from './ToggleButtonGroupElementTemplate';
import { TOGGLE_BUTTON_GROUP_INHERITANCE_CONTEXT } from './ToggleButtonGroupInheritanceContext';
// #endregion
/**
 * Toggle Button Group - A container for grouping multiple toggle buttons with single-selection behavior.
 *
 * @description
 * Groups multiple Toggle Buttons to behave like a segmented control. Only one button can be selected at a time.
 * Inside a group, a toggle button cannot be deselected by clicking it again; clicking a selected button keeps it selected.
 * The `value` of the group selects the toggle button with the same `value`; a group without a value takes the
 * value of the first checked toggle button, and selects nothing while none is checked.
 * This component is useful for creating segmented controls, option selectors, and toggle-based navigation.
 *
 * @name Toggle Button Group
 * @element mosaik-toggle-button-group
 * @category Buttons
 *
 * @slot - The default slot for toggle buttons.
 *
 * @cssprop {String} --toggle-button-group-background-color - The button group background color CSS custom property.
 * @cssprop {String} --toggle-button-group-border-color - The button group border color CSS custom property.
 * @cssprop {String} --toggle-button-group-border-radius - The button group border radius CSS custom property.
 * @cssprop {String} --toggle-button-group-border-style - The button group border style CSS custom property.
 * @cssprop {String} --toggle-button-group-border-width - The button group border width CSS custom property.
 * @cssprop {String} --toggle-button-group-font-family - The button group font family CSS custom property.
 * @cssprop {String} --toggle-button-group-font-letter-spacing - The button group font letter spacing CSS custom property.
 * @cssprop {String} --toggle-button-group-font-line-height - The button group font line height CSS custom property.
 * @cssprop {String} --toggle-button-group-font-size - The button group font size CSS custom property.
 * @cssprop {String} --toggle-button-group-font-text-decoration - The button group font text decoration CSS custom property.
 * @cssprop {String} --toggle-button-group-font-text-transform - The button group font text transform CSS custom property.
 * @cssprop {String} --toggle-button-group-font-weight - The button group font weight CSS custom property.
 * @cssprop {String} --toggle-button-group-foreground-color - The button group foreground color CSS custom property.
 * @cssprop {String} --toggle-button-group-gap - The button group gap CSS custom property.
 * @cssprop {String} --toggle-button-group-padding-bottom - The button group padding bottom CSS custom property.
 * @cssprop {String} --toggle-button-group-padding-left - The button group padding left CSS custom property.
 * @cssprop {String} --toggle-button-group-padding-right - The button group padding right CSS custom property.
 * @cssprop {String} --toggle-button-group-padding-top - The button group padding top CSS custom property.
 * @cssprop {String} --toggle-button-group-shadow - The button group shadow CSS custom property.
 * @cssprop {String} --toggle-button-group-shadow-blur - The button group shadow blur CSS custom property.
 * @cssprop {String} --toggle-button-group-shadow-color - The button group shadow color CSS custom property.
 * @cssprop {String} --toggle-button-group-shadow-offset-x - The button group shadow offset x CSS custom property.
 * @cssprop {String} --toggle-button-group-shadow-offset-y - The button group shadow offset y CSS custom property.
 * @cssprop {String} --toggle-button-group-shadow-spread - The button group shadow spread CSS custom property.
 * @cssprop {String} --toggle-button-group-transition-duration - The button group transition duration CSS custom property.
 * @cssprop {String} --toggle-button-group-transition-mode - The button group transition mode CSS custom property.
 * @cssprop {String} --toggle-button-group-transition-property - The button group transition property CSS custom property.
 * @cssprop {String} --toggle-button-group-translate - The button group translate CSS custom property.
 *
 * @fires groupChanged {GroupChangedEvent} - Called when the selection in the group changes.
 *
 * @example
 * ```html
 * <mosaik-toggle-button-group>
 *   <mosaik-toggle-button value="1"></mosaik-toggle-button>
 *   <mosaik-toggle-button value="2"></mosaik-toggle-button>
 *   <mosaik-toggle-button value="3"></mosaik-toggle-button>
 * </mosaik-toggle-button-group>
 * ```
 *
 * @public
 */
let ToggleButtonGroupElement = class ToggleButtonGroupElement extends Themeable(Invalidable(Disableable(Orientable(Valueable(Appearanceable(Variantable(Slottable(CustomElement)))))))) {
    // #region Fields
    /**
     * Supplies this component's value accessor to framework integrations.
     *
     * @public
     * @readonly
     */
    controlValue = {
        property: 'value',
        create: () => toggleButtonGroupElementValueAccessor(this)
    };
    _provider = addInheritanceProviderController(this, {
        context: TOGGLE_BUTTON_GROUP_INHERITANCE_CONTEXT,
        values: () => ({
            disabled: this.disabled,
            appearance: this.appearance,
            variant: this.variant,
            dir: this.dir
        })
    });
    _toggleChanged;
    _eventSubscriptions;
    _isSwitching;
    // #endregion
    // #region Ctor
    /**
     * @public
     */
    constructor() {
        super();
        this._eventSubscriptions = [];
        this._toggleChanged = new HTMLElementEventEmitter(this, 'groupChanged');
        this._isSwitching = false;
    }
    // #endregion
    // #region Properties
    /**
     * Returns the `is` property.
     * The `is` property represents natural name of this element.
     *
     * @public
     * @static
     * @readonly
     */
    static get is() {
        return 'mosaik-toggle-button-group';
    }
    /**
     * Called when the selection in the group changes.
     * Provides reference to `IGroupChangedEventDetail` as event detail.
     *
     * @public
     * @readonly
     * @eventProperty
     */
    get toggleChanged() {
        return this._toggleChanged;
    }
    // #endregion
    // #region Methods
    /**
     * @public
     * @override
     */
    onSlotChanges() {
        this.clearEvents();
        const elements = this.getToggleButtons();
        // A group without a value keeps the first checked toggle button selected and takes its value.
        const selected = this.hasValue()
            ? null
            : elements.find((x) => x.isChecked) ?? null;
        for (const [i, e] of elements.entries()) {
            e.isChecked = selected === null
                ? this.isSelected(e)
                : e === selected;
            e.classList.add('button-group-button');
            e.classList.toggle('first', i === 0);
            e.classList.toggle('inner', i > 0 && i < elements.length - 1);
            e.classList.toggle('last', i === elements.length - 1);
            this._eventSubscriptions.push(e.on('checked', (evt) => this.onToggleChecked(evt), { passive: true }));
            this._eventSubscriptions.push(e.on('unchecked', (evt) => this.onToggleUnchecked(evt), { passive: true }));
        }
        if (selected !== null) {
            this.value = selected.value;
        }
    }
    /**
     * Returns whether a form will validate when it is submitted, without having to submit it.
     *
     * @public
     * @override
     */
    checkValidity() {
        return this.getToggleButtons().some((x) => x.isChecked);
    }
    /**
     * Resets the element to its initial state: no toggle button is selected and the value is cleared.
     *
     * @public
     */
    reset() {
        // Unchecking the selected button must not re-check it (see `onToggleUnchecked`).
        this._isSwitching = true;
        this.getToggleButtons().forEach((x) => x.uncheck());
        this._isSwitching = false;
        this.value = undefined;
        this.invalid = false;
    }
    /**
     * Emits the `toggleChanged` event.
     *
     * @protected
     */
    onToggleChanged(args) {
        const value = args.target.value;
        this._toggleChanged.emit({ value });
    }
    /**
     * @protected
     */
    onValuePropertyChange(_prev, _next) {
        // Without a value the buttons keep their state - a toggle button without a value can still be the selected one.
        if (!this.hasValue()) {
            return;
        }
        this.getToggleButtons().forEach((x) => x.isChecked = this.isSelected(x));
    }
    /**
     * @private
     */
    onToggleChecked(event) {
        const target = event.target;
        this._isSwitching = true;
        this.getToggleButtons()
            .filter((x) => x !== target)
            .forEach((x) => x.uncheck());
        this._isSwitching = false;
        this.value = target.value;
        this.onToggleChanged(event);
    }
    /**
     * Prevent deselection of the currently selected button inside the group.
     *
     * @private
     */
    onToggleUnchecked(event) {
        if (this._isSwitching) {
            return;
        }
        const target = event.target;
        // If the unchecked target was the current selection, re-check it to enforce single-selection.
        if (this.value === target.value) {
            target.check();
        }
    }
    /**
     * @private
     */
    clearEvents() {
        this._eventSubscriptions.forEach((x) => x.dispose());
        this._eventSubscriptions = [];
    }
    /**
     * Returns the slotted toggle buttons.
     *
     * @private
     */
    getToggleButtons() {
        return this.getSlotAssignments('')
            .filter((x) => x instanceof ToggleButtonElement);
    }
    /**
     * Determines whether the group has a value that selects a toggle button.
     *
     * @private
     */
    hasValue() {
        return this.value !== undefined && this.value !== null;
    }
    /**
     * Determines whether the value of the group selects the given toggle button.
     *
     * @private
     */
    isSelected(button) {
        return this.hasValue() && button.value === this.value;
    }
};
__decorate([
    Emit({ eventName: 'groupChanged' }),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], ToggleButtonGroupElement.prototype, "toggleChanged", null);
__decorate([
    Watch('value'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], ToggleButtonGroupElement.prototype, "onValuePropertyChange", null);
ToggleButtonGroupElement = __decorate([
    Component({
        selector: 'mosaik-toggle-button-group',
        template: toggleButtonGroupElementTemplate,
        themes: {
            joy: toggleButtonGroupElementJoyStyle,
            memphis: toggleButtonGroupElementMemphisStyle,
            cosmopolitan: toggleButtonGroupElementCosmopolitanStyle,
            soho: toggleButtonGroupElementSohoStyle
        },
        host: {
            role: 'group'
        },
        imports: [ToggleButtonElement]
    }),
    __metadata("design:paramtypes", [])
], ToggleButtonGroupElement);
export { ToggleButtonGroupElement };
//# sourceMappingURL=ToggleButtonGroupElement.js.map