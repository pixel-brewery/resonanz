import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function toggleButtonGroupElementMemphisStyle(): CSSResult;
//# sourceMappingURL=ToggleButtonGroupElement.Memphis.d.ts.map