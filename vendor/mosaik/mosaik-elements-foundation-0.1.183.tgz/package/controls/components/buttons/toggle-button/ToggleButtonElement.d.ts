import { ICheckable, ICheckableEvents } from '../../../behaviors/Checkable';
import type { Appearance } from '../../../types/Appearance';
import type { FlowDirection } from '../../../types/FlowDirection';
import type { Variant } from '../../../types/Variant';
import { ButtonBaseElement } from '../abstracts/ButtonBaseElement';
import type { IToggleButtonElementProps } from './IToggleButtonElementProps';
declare const ToggleButtonElement_base: (abstract new (...args: Array<any>) => import("../../../../controls/behaviors/Themeable").IThemeableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Reversible").IReversibleProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Orientable").IOrientableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/ContentAlignable").IContentAlignableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Fitable").IFitableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Busyable").IBusyableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Checkable").ICheckableProps & ICheckableEvents & ICheckable) & (abstract new (...args: Array<any>) => import("../../../behaviors/Labelable").ILabelableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Iconable").IIconableProps) & typeof ButtonBaseElement & import("../../../../controls/behaviors/Themeable").IThemeableCtor;
/**
 * ToggleButton - An interactive button component that maintains a binary checked/unchecked state.
 *
 * @description
 * The ToggleButton component provides stateful toggle functionality with visual feedback, allowing
 * users to switch between two states (on/off, enabled/disabled, selected/deselected). It features
 * persistent state management with visual indicators for both checked and unchecked states, keyboard
 * accessibility for binary preference controls, and comprehensive event handling for state changes.
 * The component includes advanced features like ripple effects, focus rings, progress indicators,
 * and support for toggle button groups with inherited styling. It is ideal for settings panels,
 * view mode switchers, feature toggles, and any interface requiring binary choice controls with
 * clear visual state representation.
 *
 * @name ToggleButton
 * @element mosaik-toggle-button
 * @category Buttons
 *
 * @slot icon - Icon content area for visual state representation and identification
 * @slot label - Text label content area for button identification and description
 * @slot overlay - Overlay content area for badges, notifications, or additional state indicators
 *
 * @csspart button - The main toggle button element container
 * @csspart focusRing - The focus indicator ring for keyboard navigation accessibility
 * @csspart icon - The icon display area within the button
 * @csspart innerStack - The internal stack layout container for organizing icon and label
 * @csspart label - The text label display area
 * @csspart progressRing - The busy state progress indicator
 * @csspart ripple - The touch feedback ripple effect container
 *
 * @cssprop {String} --toggle-button-background-color - The background fill color
 * @cssprop {String} --toggle-button-border-color - The border outline color
 * @cssprop {String} --toggle-button-border-radius - The corner rounding radius
 * @cssprop {String} --toggle-button-border-style - The border line style
 * @cssprop {String} --toggle-button-border-width - The border thickness
 * @cssprop {String} --toggle-button-focus-ring-active-width - The focus ring width when active (from focusRing mixin)
 * @cssprop {String} --toggle-button-focus-ring-color - The focus ring color (from focusRing mixin)
 * @cssprop {String} --toggle-button-focus-ring-inward-offset - The focus ring inward offset (from focusRing mixin)
 * @cssprop {String} --toggle-button-focus-ring-outward-offset - The focus ring outward offset (from focusRing mixin)
 * @cssprop {String} --toggle-button-font-family - The font family for button text content
 * @cssprop {String} --toggle-button-font-letter-spacing - The letter spacing for button text
 * @cssprop {String} --toggle-button-font-line-height - The line height for button text
 * @cssprop {String} --toggle-button-font-size - The font size for button text
 * @cssprop {String} --toggle-button-font-text-decoration - The text decoration style for button text
 * @cssprop {String} --toggle-button-font-text-transform - The text transformation style for button text
 * @cssprop {String} --toggle-button-font-weight - The font weight for button text
 * @cssprop {String} --toggle-button-foreground-color - The text and icon color
 * @cssprop {String} --toggle-button-gap - The spacing between icon and label elements
 * @cssprop {String} --toggle-button-height - The button height
 * @cssprop {String} --toggle-button-icon-min-height - The minimum height for icon display area
 * @cssprop {String} --toggle-button-icon-min-width - The minimum width for icon display area
 * @cssprop {String} --toggle-button-line-height - The calculated line height for content alignment
 * @cssprop {String} --toggle-button-min-height - The minimum button height
 * @cssprop {String} --toggle-button-min-width - The minimum button width
 * @cssprop {String} --toggle-button-padding-bottom - The bottom padding inside the button
 * @cssprop {String} --toggle-button-padding-left - The left padding inside the button
 * @cssprop {String} --toggle-button-padding-right - The right padding inside the button
 * @cssprop {String} --toggle-button-padding-top - The top padding inside the button
 * @cssprop {String} --toggle-button-progress-ring-width - The button progress ring width CSS custom property.
 * @cssprop {String} --toggle-button-ripple-color - The ripple effect color (from ripple mixin)
 * @cssprop {String} --toggle-button-ripple-duration - The ripple effect animation duration (from ripple mixin)
 * @cssprop {String} --toggle-button-shadow - The drop shadow or elevation effect
 * @cssprop {String} --toggle-button-shadow-blur - The button shadow blur CSS custom property.
 * @cssprop {String} --toggle-button-shadow-color - The button shadow color CSS custom property.
 * @cssprop {String} --toggle-button-shadow-offset-x - The button shadow offset x CSS custom property.
 * @cssprop {String} --toggle-button-shadow-offset-y - The button shadow offset y CSS custom property.
 * @cssprop {String} --toggle-button-shadow-spread - The button shadow spread CSS custom property.
 * @cssprop {String} --toggle-button-transition-duration - The duration of state change transitions
 * @cssprop {String} --toggle-button-transition-mode - The timing function for transitions
 * @cssprop {String} --toggle-button-transition-property - The CSS properties to animate during transitions
 * @cssprop {String} --toggle-button-translate - The transform translation offset
 * @cssprop {String} --toggle-button-width - The button width
 *
 * @fires checked {CheckedEvent} - Fired when the button transitions to checked state
 * @fires unchecked {UncheckedEvent} - Fired when the button transitions to unchecked state
 * @fires toggled {ToggledEvent} - Dispatched when the button is toggled, regardless of the new state
 *
 * @dependency mosaik-focus-ring - The Focus Ring element.
 * @dependency mosaik-icon - The Icon element.
 * @dependency mosaik-progress-ring - The Progress Ring element.
 * @dependency mosaik-ripple - The Ripple element.
 * @dependency mosaik-stack - The Stack element.
 * @dependency mosaik-text - The Text element.
 *
 * @example
 * Basic toggle button with slotted label:
 * ```html
 * <mosaik-toggle-button variant="primary">
 *   <span slot="label">Enable Notifications</span>
 * </mosaik-toggle-button>
 * ```
 *
 * @example
 * Pre-checked toggle button with solid appearance:
 * ```html
 * <mosaik-toggle-button is-checked appearance="solid" variant="primary"></mosaik-toggle-button>
 * ```
 *
 * @public
 */
export declare class ToggleButtonElement extends ToggleButtonElement_base implements IToggleButtonElementProps, ICheckable, ICheckableEvents {
    /**
     * Supplies this component's value accessor to framework integrations.
     *
     * @public
     * @readonly
     */
    readonly controlValue: {
        property: "value";
        create: () => import("../../../../Index").IElementValueAccessor;
    };
    private readonly _inheritance;
    /**
     * @public
     */
    constructor();
    /**
     * Returns the `is` property.
     * The `is` property represents natural name of this element.
     *
     * @public
     * @static
     * @readonly
     */
    static get is(): string;
    /**
     * @public
     * @override
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * @public
     * @override
     */
    get appearance(): Appearance;
    set appearance(value: Appearance);
    /**
     * @public
     * @override
     */
    get variant(): Variant;
    set variant(value: Variant);
    /**
     * @public
     * @override
     */
    get dir(): FlowDirection;
    set dir(value: FlowDirection);
    /**
     * Resets the element to its initial state.
     *
     * @public
     */
    reset(): void;
}
/**
 * @public
 */
export declare namespace ToggleButtonElement {
    type Props = IToggleButtonElementProps;
}
/**
 * @public
 */
declare global {
    interface HTMLElementTagNameMap {
        'mosaik-toggle-button': ToggleButtonElement;
    }
}
export {};
//# sourceMappingURL=ToggleButtonElement.d.ts.map