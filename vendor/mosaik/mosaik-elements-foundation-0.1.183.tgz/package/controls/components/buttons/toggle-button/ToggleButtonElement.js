// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Themeable } from '../../../../controls/behaviors/Themeable';
import { Busyable } from '../../../behaviors/Busyable';
import { Checkable } from '../../../behaviors/Checkable';
import { ContentAlignable } from '../../../behaviors/ContentAlignable';
import { Fitable } from '../../../behaviors/Fitable';
import { Iconable } from '../../../behaviors/Iconable';
import { Labelable } from '../../../behaviors/Labelable';
import { Orientable } from '../../../behaviors/Orientable';
import { Reversible } from '../../../behaviors/Reversible';
import { addInheritanceConsumerController } from '../../../controllers/InheritanceConsumerController';
import { Component } from '../../../decorators/ComponentDecorator';
import { RippleElement } from '../../effects/ripple/RippleElement';
import { StackElement } from '../../layouts/stack/StackElement';
import { IconElement } from '../../media/icon/IconElement';
import { FocusRingElement } from '../../primitives/focus-ring/FocusRingElement';
import { TextElement } from '../../primitives/text/TextElement';
import { ProgressRingElement } from '../../ranges/progress-ring/ProgressRingElement';
import { ButtonBaseElement } from '../abstracts/ButtonBaseElement';
import { toggleButtonElementValueAccessor } from './accessors/ToggleButtonElementValueAccessor';
import { toggleButtonElementCosmopolitanStyle } from './themes/ToggleButtonElement.Cosmopolitan';
import { toggleButtonElementJoyStyle } from './themes/ToggleButtonElement.Joy';
import { toggleButtonElementMemphisStyle } from './themes/ToggleButtonElement.Memphis';
import { toggleButtonElementSohoStyle } from './themes/ToggleButtonElement.Soho';
import { toggleButtonElementTemplate } from './ToggleButtonElementTemplate';
import { TOGGLE_BUTTON_GROUP_INHERITANCE_CONTEXT } from './ToggleButtonGroupInheritanceContext';
// #endregion
/**
 * ToggleButton - An interactive button component that maintains a binary checked/unchecked state.
 *
 * @description
 * The ToggleButton component provides stateful toggle functionality with visual feedback, allowing
 * users to switch between two states (on/off, enabled/disabled, selected/deselected). It features
 * persistent state management with visual indicators for both checked and unchecked states, keyboard
 * accessibility for binary preference controls, and comprehensive event handling for state changes.
 * The component includes advanced features like ripple effects, focus rings, progress indicators,
 * and support for toggle button groups with inherited styling. It is ideal for settings panels,
 * view mode switchers, feature toggles, and any interface requiring binary choice controls with
 * clear visual state representation.
 *
 * @name ToggleButton
 * @element mosaik-toggle-button
 * @category Buttons
 *
 * @slot icon - Icon content area for visual state representation and identification
 * @slot label - Text label content area for button identification and description
 * @slot overlay - Overlay content area for badges, notifications, or additional state indicators
 *
 * @csspart button - The main toggle button element container
 * @csspart focusRing - The focus indicator ring for keyboard navigation accessibility
 * @csspart icon - The icon display area within the button
 * @csspart innerStack - The internal stack layout container for organizing icon and label
 * @csspart label - The text label display area
 * @csspart progressRing - The busy state progress indicator
 * @csspart ripple - The touch feedback ripple effect container
 *
 * @cssprop {String} --toggle-button-background-color - The background fill color
 * @cssprop {String} --toggle-button-border-color - The border outline color
 * @cssprop {String} --toggle-button-border-radius - The corner rounding radius
 * @cssprop {String} --toggle-button-border-style - The border line style
 * @cssprop {String} --toggle-button-border-width - The border thickness
 * @cssprop {String} --toggle-button-focus-ring-active-width - The focus ring width when active (from focusRing mixin)
 * @cssprop {String} --toggle-button-focus-ring-color - The focus ring color (from focusRing mixin)
 * @cssprop {String} --toggle-button-focus-ring-inward-offset - The focus ring inward offset (from focusRing mixin)
 * @cssprop {String} --toggle-button-focus-ring-outward-offset - The focus ring outward offset (from focusRing mixin)
 * @cssprop {String} --toggle-button-font-family - The font family for button text content
 * @cssprop {String} --toggle-button-font-letter-spacing - The letter spacing for button text
 * @cssprop {String} --toggle-button-font-line-height - The line height for button text
 * @cssprop {String} --toggle-button-font-size - The font size for button text
 * @cssprop {String} --toggle-button-font-text-decoration - The text decoration style for button text
 * @cssprop {String} --toggle-button-font-text-transform - The text transformation style for button text
 * @cssprop {String} --toggle-button-font-weight - The font weight for button text
 * @cssprop {String} --toggle-button-foreground-color - The text and icon color
 * @cssprop {String} --toggle-button-gap - The spacing between icon and label elements
 * @cssprop {String} --toggle-button-height - The button height
 * @cssprop {String} --toggle-button-icon-min-height - The minimum height for icon display area
 * @cssprop {String} --toggle-button-icon-min-width - The minimum width for icon display area
 * @cssprop {String} --toggle-button-line-height - The calculated line height for content alignment
 * @cssprop {String} --toggle-button-min-height - The minimum button height
 * @cssprop {String} --toggle-button-min-width - The minimum button width
 * @cssprop {String} --toggle-button-padding-bottom - The bottom padding inside the button
 * @cssprop {String} --toggle-button-padding-left - The left padding inside the button
 * @cssprop {String} --toggle-button-padding-right - The right padding inside the button
 * @cssprop {String} --toggle-button-padding-top - The top padding inside the button
 * @cssprop {String} --toggle-button-progress-ring-width - The button progress ring width CSS custom property.
 * @cssprop {String} --toggle-button-ripple-color - The ripple effect color (from ripple mixin)
 * @cssprop {String} --toggle-button-ripple-duration - The ripple effect animation duration (from ripple mixin)
 * @cssprop {String} --toggle-button-shadow - The drop shadow or elevation effect
 * @cssprop {String} --toggle-button-shadow-blur - The button shadow blur CSS custom property.
 * @cssprop {String} --toggle-button-shadow-color - The button shadow color CSS custom property.
 * @cssprop {String} --toggle-button-shadow-offset-x - The button shadow offset x CSS custom property.
 * @cssprop {String} --toggle-button-shadow-offset-y - The button shadow offset y CSS custom property.
 * @cssprop {String} --toggle-button-shadow-spread - The button shadow spread CSS custom property.
 * @cssprop {String} --toggle-button-transition-duration - The duration of state change transitions
 * @cssprop {String} --toggle-button-transition-mode - The timing function for transitions
 * @cssprop {String} --toggle-button-transition-property - The CSS properties to animate during transitions
 * @cssprop {String} --toggle-button-translate - The transform translation offset
 * @cssprop {String} --toggle-button-width - The button width
 *
 * @fires checked {CheckedEvent} - Fired when the button transitions to checked state
 * @fires unchecked {UncheckedEvent} - Fired when the button transitions to unchecked state
 * @fires toggled {ToggledEvent} - Dispatched when the button is toggled, regardless of the new state
 *
 * @dependency mosaik-focus-ring - The Focus Ring element.
 * @dependency mosaik-icon - The Icon element.
 * @dependency mosaik-progress-ring - The Progress Ring element.
 * @dependency mosaik-ripple - The Ripple element.
 * @dependency mosaik-stack - The Stack element.
 * @dependency mosaik-text - The Text element.
 *
 * @example
 * Basic toggle button with slotted label:
 * ```html
 * <mosaik-toggle-button variant="primary">
 *   <span slot="label">Enable Notifications</span>
 * </mosaik-toggle-button>
 * ```
 *
 * @example
 * Pre-checked toggle button with solid appearance:
 * ```html
 * <mosaik-toggle-button is-checked appearance="solid" variant="primary"></mosaik-toggle-button>
 * ```
 *
 * @public
 */
let ToggleButtonElement = class ToggleButtonElement extends Themeable(Reversible(Orientable(ContentAlignable(Fitable(Busyable(Checkable(Labelable(Iconable(ButtonBaseElement))))))))) {
    // #region Fields
    /**
     * Supplies this component's value accessor to framework integrations.
     *
     * @public
     * @readonly
     */
    controlValue = {
        property: 'value',
        create: () => toggleButtonElementValueAccessor(this)
    };
    _inheritance = addInheritanceConsumerController(this, {
        context: TOGGLE_BUTTON_GROUP_INHERITANCE_CONTEXT
    });
    // #endregion
    // #region Ctor
    /**
     * @public
     */
    constructor() {
        super();
    }
    // #endregion
    // #region Properties
    /**
     * Returns the `is` property.
     * The `is` property represents natural name of this element.
     *
     * @public
     * @static
     * @readonly
     */
    static get is() {
        return 'mosaik-toggle-button';
    }
    /**
     * @public
     * @override
     */
    get disabled() {
        return this._inheritance.get('disabled', super.disabled);
    }
    set disabled(value) {
        this._inheritance.markExplicit('disabled');
        super.disabled = value;
    }
    /**
     * @public
     * @override
     */
    get appearance() {
        return this._inheritance.get('appearance', super.appearance);
    }
    set appearance(value) {
        this._inheritance.markExplicit('appearance');
        super.appearance = value;
    }
    /**
     * @public
     * @override
     */
    get variant() {
        return this._inheritance.get('variant', super.variant);
    }
    set variant(value) {
        this._inheritance.markExplicit('variant');
        super.variant = value;
    }
    /**
     * @public
     * @override
     */
    get dir() {
        return this._inheritance.get('dir', super.dir);
    }
    set dir(value) {
        this._inheritance.markExplicit('dir');
        super.dir = value;
    }
    // #endregion
    // #region Methods
    /**
     * Resets the element to its initial state.
     *
     * @public
     */
    reset() {
        this.isChecked = false;
    }
};
ToggleButtonElement = __decorate([
    Component({
        selector: 'mosaik-toggle-button',
        template: toggleButtonElementTemplate,
        themes: {
            joy: toggleButtonElementJoyStyle,
            memphis: toggleButtonElementMemphisStyle,
            cosmopolitan: toggleButtonElementCosmopolitanStyle,
            soho: toggleButtonElementSohoStyle
        },
        options: {
            mode: 'open',
            delegatesFocus: true
        },
        imports: [
            StackElement,
            IconElement,
            RippleElement,
            FocusRingElement,
            TextElement,
            ProgressRingElement
        ]
    }),
    __metadata("design:paramtypes", [])
], ToggleButtonElement);
export { ToggleButtonElement };
//# sourceMappingURL=ToggleButtonElement.js.map