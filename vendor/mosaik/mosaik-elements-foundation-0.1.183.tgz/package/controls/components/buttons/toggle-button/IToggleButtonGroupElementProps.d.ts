import type { IAppearanceableProps } from '../../../behaviors/Appearanceable';
import type { IDisableableProps } from '../../../behaviors/Disableable';
import type { IInvalidableProps } from '../../../behaviors/Invalidable';
import type { IOrientableProps } from '../../../behaviors/Orientable';
import type { ISlottableProps } from '../../../behaviors/Slottable';
import type { IValueableProps } from '../../../behaviors/Valueable';
import type { IVariantableProps } from '../../../behaviors/Variantable';
/**
 * Represents the `IToggleButtonGroupElementProps` interface.
 *
 * @public
 */
export interface IToggleButtonGroupElementProps extends IValueableProps, IDisableableProps, IVariantableProps, IAppearanceableProps, IOrientableProps, IInvalidableProps, ISlottableProps {
}
//# sourceMappingURL=IToggleButtonGroupElementProps.d.ts.map