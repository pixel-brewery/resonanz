import type { Appearance } from '../../../types/Appearance';
import type { FlowDirection } from '../../../types/FlowDirection';
import type { Variant } from '../../../types/Variant';
/**
 * Interface for properties inherited by child ToggleButtonElements.
 *
 * @public
 */
export interface IToggleButtonGroupInherited {
    /**
     * Inherited disabled state.
     */
    disabled?: boolean;
    /**
     * Inherited appearance.
     */
    appearance?: Appearance;
    /**
     * Inherited variant.
     */
    variant?: Variant;
    /**
     * Inherited flow direction.
     */
    dir?: FlowDirection;
}
/**
 * Context for ToggleButtonGroup → ToggleButton inheritance.
 *
 * @public
 */
export declare const TOGGLE_BUTTON_GROUP_INHERITANCE_CONTEXT: {
    __context__: Partial<IToggleButtonGroupInherited>;
};
//# sourceMappingURL=ToggleButtonGroupInheritanceContext.d.ts.map