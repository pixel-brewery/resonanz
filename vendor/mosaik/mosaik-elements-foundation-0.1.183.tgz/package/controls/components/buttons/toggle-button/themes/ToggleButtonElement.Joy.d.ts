import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function toggleButtonElementJoyStyle(): CSSResult;
//# sourceMappingURL=ToggleButtonElement.Joy.d.ts.map