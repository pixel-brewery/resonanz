import type { IBusyableProps } from '../../../behaviors/Busyable';
import type { ICheckableProps } from '../../../behaviors/Checkable';
import type { IContentAlignableProps } from '../../../behaviors/ContentAlignable';
import type { IFitableProps } from '../../../behaviors/Fitable';
import type { IIconableProps } from '../../../behaviors/Iconable';
import type { ILabelableProps } from '../../../behaviors/Labelable';
import type { IOrientableProps } from '../../../behaviors/Orientable';
import type { IReversibleProps } from '../../../behaviors/Reversible';
import type { IThemeableProps } from '../../../behaviors/Themeable';
import type { IButtonBaseElementProps } from '../abstracts/IButtonBaseElementProps';
/**
 * Represents the `IToggleButtonElementProps` interface.
 *
 * @public
 */
export interface IToggleButtonElementProps extends IButtonBaseElementProps, IOrientableProps, IContentAlignableProps, IFitableProps, IBusyableProps, IReversibleProps, ICheckableProps, ILabelableProps, IIconableProps, IThemeableProps {
}
//# sourceMappingURL=IToggleButtonElementProps.d.ts.map