import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function toggleButtonGroupElementSohoStyle(): CSSResult;
//# sourceMappingURL=ToggleButtonGroupElement.Soho.d.ts.map