import { ElementValueAccessorBase } from '../../../../../forms/accessors/abstracts/ElementValueAccessorBase';
import type { ElementValueAccessorFn } from '../../../../../forms/accessors/functions/ElementValueAccessorFn';
import type { ToggleButtonElement } from '../ToggleButtonElement';
/**
 * @public
 */
export declare class ToggleButtonElementValueAccessor extends ElementValueAccessorBase<ToggleButtonElement> {
    /**
     * @public
     */
    hostConnected(): void;
    /**
     * @public
     * @override
     */
    writeValue(value: unknown): void;
    /**
     * @public
     * @override
     */
    resetValue(): void;
}
/**
 * @public
 */
export declare const toggleButtonElementValueAccessor: ElementValueAccessorFn<ToggleButtonElement>;
//# sourceMappingURL=ToggleButtonElementValueAccessor.d.ts.map