import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function toggleButtonGroupElementCosmopolitanStyle(): CSSResult;
//# sourceMappingURL=ToggleButtonGroupElement.Cosmopolitan.d.ts.map