import { type IEventEmitter } from '@pixel-brewery/mosaik-elements';
import { type IInvalidable } from '../../../behaviors/Invalidable';
import { ISlottable } from '../../../behaviors/Slottable';
import type { CheckedEvent, IGroupChangedEventDetail } from '../../../events';
import { CustomElement } from '../../abstracts/CustomElement';
import type { IToggleButtonGroupElementProps } from './IToggleButtonGroupElementProps';
declare const ToggleButtonGroupElement_base: (abstract new (...args: Array<any>) => import("../../../behaviors/Themeable").IThemeableProps) & (abstract new (...args: Array<any>) => IInvalidable & import("../../../behaviors/Invalidable").IInvalidableProps<unknown>) & (abstract new (...args: Array<any>) => import("../../../behaviors/Disableable").IDisableableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Orientable").IOrientableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Valueable").IValueableProps<unknown>) & (abstract new (...args: Array<any>) => import("../../../behaviors/Appearanceable").IAppearanceableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Variantable").IVariantableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Slottable").ISlottableProps & ISlottable) & typeof CustomElement & import("../../../behaviors/Themeable").IThemeableCtor;
/**
 * Toggle Button Group - A container for grouping multiple toggle buttons with single-selection behavior.
 *
 * @description
 * Groups multiple Toggle Buttons to behave like a segmented control. Only one button can be selected at a time.
 * Inside a group, a toggle button cannot be deselected by clicking it again; clicking a selected button keeps it selected.
 * The `value` of the group selects the toggle button with the same `value`; a group without a value takes the
 * value of the first checked toggle button, and selects nothing while none is checked.
 * This component is useful for creating segmented controls, option selectors, and toggle-based navigation.
 *
 * @name Toggle Button Group
 * @element mosaik-toggle-button-group
 * @category Buttons
 *
 * @slot - The default slot for toggle buttons.
 *
 * @cssprop {String} --toggle-button-group-background-color - The button group background color CSS custom property.
 * @cssprop {String} --toggle-button-group-border-color - The button group border color CSS custom property.
 * @cssprop {String} --toggle-button-group-border-radius - The button group border radius CSS custom property.
 * @cssprop {String} --toggle-button-group-border-style - The button group border style CSS custom property.
 * @cssprop {String} --toggle-button-group-border-width - The button group border width CSS custom property.
 * @cssprop {String} --toggle-button-group-font-family - The button group font family CSS custom property.
 * @cssprop {String} --toggle-button-group-font-letter-spacing - The button group font letter spacing CSS custom property.
 * @cssprop {String} --toggle-button-group-font-line-height - The button group font line height CSS custom property.
 * @cssprop {String} --toggle-button-group-font-size - The button group font size CSS custom property.
 * @cssprop {String} --toggle-button-group-font-text-decoration - The button group font text decoration CSS custom property.
 * @cssprop {String} --toggle-button-group-font-text-transform - The button group font text transform CSS custom property.
 * @cssprop {String} --toggle-button-group-font-weight - The button group font weight CSS custom property.
 * @cssprop {String} --toggle-button-group-foreground-color - The button group foreground color CSS custom property.
 * @cssprop {String} --toggle-button-group-gap - The button group gap CSS custom property.
 * @cssprop {String} --toggle-button-group-padding-bottom - The button group padding bottom CSS custom property.
 * @cssprop {String} --toggle-button-group-padding-left - The button group padding left CSS custom property.
 * @cssprop {String} --toggle-button-group-padding-right - The button group padding right CSS custom property.
 * @cssprop {String} --toggle-button-group-padding-top - The button group padding top CSS custom property.
 * @cssprop {String} --toggle-button-group-shadow - The button group shadow CSS custom property.
 * @cssprop {String} --toggle-button-group-shadow-blur - The button group shadow blur CSS custom property.
 * @cssprop {String} --toggle-button-group-shadow-color - The button group shadow color CSS custom property.
 * @cssprop {String} --toggle-button-group-shadow-offset-x - The button group shadow offset x CSS custom property.
 * @cssprop {String} --toggle-button-group-shadow-offset-y - The button group shadow offset y CSS custom property.
 * @cssprop {String} --toggle-button-group-shadow-spread - The button group shadow spread CSS custom property.
 * @cssprop {String} --toggle-button-group-transition-duration - The button group transition duration CSS custom property.
 * @cssprop {String} --toggle-button-group-transition-mode - The button group transition mode CSS custom property.
 * @cssprop {String} --toggle-button-group-transition-property - The button group transition property CSS custom property.
 * @cssprop {String} --toggle-button-group-translate - The button group translate CSS custom property.
 *
 * @fires groupChanged {GroupChangedEvent} - Called when the selection in the group changes.
 *
 * @example
 * ```html
 * <mosaik-toggle-button-group>
 *   <mosaik-toggle-button value="1"></mosaik-toggle-button>
 *   <mosaik-toggle-button value="2"></mosaik-toggle-button>
 *   <mosaik-toggle-button value="3"></mosaik-toggle-button>
 * </mosaik-toggle-button-group>
 * ```
 *
 * @public
 */
export declare class ToggleButtonGroupElement extends ToggleButtonGroupElement_base implements IToggleButtonGroupElementProps, IInvalidable, ISlottable {
    /**
     * Supplies this component's value accessor to framework integrations.
     *
     * @public
     * @readonly
     */
    readonly controlValue: {
        property: "value";
        create: () => import("../../../../Index").IElementValueAccessor;
    };
    private readonly _provider;
    private readonly _toggleChanged;
    private _eventSubscriptions;
    private _isSwitching;
    /**
     * @public
     */
    constructor();
    /**
     * Returns the `is` property.
     * The `is` property represents natural name of this element.
     *
     * @public
     * @static
     * @readonly
     */
    static get is(): string;
    /**
     * Called when the selection in the group changes.
     * Provides reference to `IGroupChangedEventDetail` as event detail.
     *
     * @public
     * @readonly
     * @eventProperty
     */
    get toggleChanged(): IEventEmitter<IGroupChangedEventDetail>;
    /**
     * @public
     * @override
     */
    onSlotChanges(): void;
    /**
     * Returns whether a form will validate when it is submitted, without having to submit it.
     *
     * @public
     * @override
     */
    checkValidity(): boolean;
    /**
     * Resets the element to its initial state: no toggle button is selected and the value is cleared.
     *
     * @public
     */
    reset(): void;
    /**
     * Emits the `toggleChanged` event.
     *
     * @protected
     */
    protected onToggleChanged(args: CheckedEvent): void;
    /**
     * @protected
     */
    protected onValuePropertyChange(_prev?: unknown, _next?: unknown): void;
    /**
     * @private
     */
    private onToggleChecked;
    /**
     * Prevent deselection of the currently selected button inside the group.
     *
     * @private
     */
    private onToggleUnchecked;
    /**
     * @private
     */
    private clearEvents;
    /**
     * Returns the slotted toggle buttons.
     *
     * @private
     */
    private getToggleButtons;
    /**
     * Determines whether the group has a value that selects a toggle button.
     *
     * @private
     */
    private hasValue;
    /**
     * Determines whether the value of the group selects the given toggle button.
     *
     * @private
     */
    private isSelected;
}
/**
 * @public
 */
export declare namespace ToggleButtonGroupElement {
    type Props = IToggleButtonGroupElementProps;
}
/**
 * @public
 */
declare global {
    interface HTMLElementTagNameMap {
        'mosaik-toggle-button-group': ToggleButtonGroupElement;
    }
}
export {};
//# sourceMappingURL=ToggleButtonGroupElement.d.ts.map