import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function toggleButtonElementSohoStyle(): CSSResult;
//# sourceMappingURL=ToggleButtonElement.Soho.d.ts.map