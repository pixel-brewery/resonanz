import { type TemplateResult } from '../../../../dom/Html';
/**
 * The template of the `ToggleButtonGroupElement`.
 *
 * @public
 */
export declare function toggleButtonGroupElementTemplate(_e: unknown): TemplateResult;
//# sourceMappingURL=ToggleButtonGroupElementTemplate.d.ts.map