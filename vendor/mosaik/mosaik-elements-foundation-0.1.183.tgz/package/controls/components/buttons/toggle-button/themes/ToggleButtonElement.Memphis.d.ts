import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function toggleButtonElementMemphisStyle(): CSSResult;
//# sourceMappingURL=ToggleButtonElement.Memphis.d.ts.map