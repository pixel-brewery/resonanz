// #region Imports
import { ElementValueAccessorBase } from '../../../../../forms/accessors/abstracts/ElementValueAccessorBase';
// #endregion
export class ToggleButtonGroupElementValueAccessor extends ElementValueAccessorBase {
    // #region Methods
    /**
     * @public
     */
    hostConnected() {
        this.listen('groupChanged', (e) => this.value = e.detail.value ?? null);
        // Sync the initial host value without triggering onChange, because
        // the host element may already have a value before the accessor is connected.
        void this.host.updateComplete.then(() => {
            this.writeValue(this.host.value);
        });
    }
    /**
     * @public
     * @override
     */
    writeValue(value) {
        super.writeValue(value);
        this.host.value = value;
    }
    /**
     * @public
     * @override
     */
    resetValue() {
        super.resetValue();
        // host implements reset() on the custom element; guard in case of plain HTMLElement
        this.host.reset?.();
    }
}
/**
 * @public
 */
export const toggleButtonGroupElementValueAccessor = (host) => new ToggleButtonGroupElementValueAccessor(host);
//# sourceMappingURL=ToggleButtonGroupElementValueAccessor.js.map