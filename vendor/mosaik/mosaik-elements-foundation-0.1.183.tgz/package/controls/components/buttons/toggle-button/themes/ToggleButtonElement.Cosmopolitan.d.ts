import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function toggleButtonElementCosmopolitanStyle(): CSSResult;
//# sourceMappingURL=ToggleButtonElement.Cosmopolitan.d.ts.map