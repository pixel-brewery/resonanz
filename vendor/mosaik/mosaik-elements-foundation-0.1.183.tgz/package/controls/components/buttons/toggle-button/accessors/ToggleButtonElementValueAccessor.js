// #region Imports
import { ElementValueAccessorBase } from '../../../../../forms/accessors/abstracts/ElementValueAccessorBase';
// #endregion
/**
 * @public
 */
export class ToggleButtonElementValueAccessor extends ElementValueAccessorBase {
    // #region Methods
    /**
     * @public
     */
    hostConnected() {
        this.listen('checked', (e) => this.value = e.target.value);
        this.listen('blur', () => this.onTouched());
        // Sync the initial host value without triggering onChange, because
        // the host element may already have a value before the accessor is connected.
        void this.host.updateComplete.then(() => {
            this.writeValue(this.host.isChecked);
        });
    }
    /**
     * @public
     * @override
     */
    writeValue(value) {
        super.writeValue(value);
        this.host.value = value;
    }
    /**
     * @public
     * @override
     */
    resetValue() {
        super.resetValue();
        this.host.reset();
    }
}
/**
 * @public
 */
export const toggleButtonElementValueAccessor = (host) => new ToggleButtonElementValueAccessor(host);
//# sourceMappingURL=ToggleButtonElementValueAccessor.js.map