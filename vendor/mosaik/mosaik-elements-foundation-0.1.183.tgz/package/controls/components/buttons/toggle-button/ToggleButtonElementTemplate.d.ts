import { type TemplateResult } from '../../../../dom/Html';
import type { ToggleButtonElement } from './ToggleButtonElement';
/**
 * @public
 */
export declare function toggleButtonElementTemplate<T extends ToggleButtonElement>(e: T): TemplateResult;
//# sourceMappingURL=ToggleButtonElementTemplate.d.ts.map