import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function splitButtonElementJoyStyle(): CSSResult;
//# sourceMappingURL=SplitButtonElement.Joy.d.ts.map