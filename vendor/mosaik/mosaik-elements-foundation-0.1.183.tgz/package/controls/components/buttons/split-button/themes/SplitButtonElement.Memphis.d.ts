import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function splitButtonElementMemphisStyle(): CSSResult;
//# sourceMappingURL=SplitButtonElement.Memphis.d.ts.map