import { type IDropDownable } from '../../../behaviors/DropDownable';
import { ButtonBaseElement } from '../abstracts/ButtonBaseElement';
import type { ISplitButtonElementProps } from './ISplitButtonElementProps';
import { SplitButtonElementIntl } from './intl/SplitButtonElementIntl';
declare const SplitButtonElement_base: (abstract new (...args: Array<any>) => import("../../../behaviors/Themeable").IThemeableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Reversible").IReversibleProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Orientable").IOrientableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/ContentAlignable").IContentAlignableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Fitable").IFitableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/DropDownable").IDropDownableProps & IDropDownable) & (abstract new (...args: Array<any>) => import("../../../behaviors/Busyable").IBusyableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Labelable").ILabelableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Iconable").IIconableProps) & typeof ButtonBaseElement & import("../../../behaviors/Themeable").IThemeableCtor;
/**
 * Split Button - A user interface element that combines a regular button with a dropdown menu.
 *
 * @description
 * The Split Button is a versatile user interface component that merges the functionality of a standard button
 * with that of a dropdown menu. It typically consists of a visible button element and an attached dropdown menu.
 * When users click the button, it triggers a default action, while clicking the arrow or a designated part of the
 * button reveals a dropdown menu with additional options or actions. Split Buttons are commonly used for providing
 * both a primary action and a set of related secondary actions in applications.
 *
 * @name Split Button
 * @element mosaik-split-button
 * @category Buttons
 *
 * @slot - The default dropdown content slot.
 * @slot icon - The icon slot.
 * @slot label - The label slot.
 * @slot overlay - The overlay slot (useful for badge).
 *
 * @csspart ${part} - The ${part} part.
 * @csspart button - The button part of the split button.
 * @csspart buttonSplit - The part of the button responsible for splitting the button from the dropdown.
 * @csspart focusRingMain - The focusRingMain part.
 * @csspart focusRingSplit - The focusRingSplit part.
 * @csspart icon - The icon part of the split button.
 * @csspart iconCaret - The caret icon part used for dropdown indication.
 * @csspart innerStack - The innerStack part.
 * @csspart label - The label part of the split button.
 * @csspart popup - The popup part of the split button.
 * @csspart portal - The portal part.
 * @csspart progressRing - The progress ring part of the split button.
 * @csspart projection - The projection part.
 * @csspart rippleMain - The rippleMain part.
 * @csspart rippleSplit - The rippleSplit part.
 *
 * @cssprop {Color} --split-button-background-color - The background color of the split button.
 * @cssprop {Color} --split-button-border-color - The border color of the split button.
 * @cssprop {String} --split-button-border-radius - The border radius of the split button.
 * @cssprop {String} --split-button-border-style - The border style of the split button.
 * @cssprop {String} --split-button-border-width - The border width of the split button.
 * @cssprop {String} --split-button-focus-ring-active-width - The button focus ring active width CSS custom property.
 * @cssprop {String} --split-button-focus-ring-color - The button focus ring color CSS custom property.
 * @cssprop {String} --split-button-focus-ring-inward-offset - The button focus ring inward offset CSS custom property.
 * @cssprop {String} --split-button-focus-ring-outward-offset - The button focus ring outward offset CSS custom property.
 * @cssprop {String} --split-button-font-family - The font family of the split button.
 * @cssprop {String} --split-button-font-letter-spacing - The font letter spacing of the split button.
 * @cssprop {String} --split-button-font-line-height - The font line height of the split button.
 * @cssprop {String} --split-button-font-size - The font size of the split button.
 * @cssprop {String} --split-button-font-text-decoration - The font text decoration of the split button.
 * @cssprop {String} --split-button-font-text-transform - The font text transform of the split button.
 * @cssprop {String} --split-button-font-weight - The font weight of the split button.
 * @cssprop {Color} --split-button-foreground-color - The foreground color of the split button.
 * @cssprop {String} --split-button-gap - The gap between elements of the split button.
 * @cssprop {String} --split-button-height - The button height CSS custom property.
 * @cssprop {String} --split-button-icon-min-height - The button icon min height CSS custom property.
 * @cssprop {String} --split-button-icon-min-width - The button icon min width CSS custom property.
 * @cssprop {String} --split-button-line-height - The line height of the split button text.
 * @cssprop {String} --split-button-min-height - The button min height CSS custom property.
 * @cssprop {String} --split-button-min-width - The button min width CSS custom property.
 * @cssprop {String} --split-button-padding-bottom - The padding bottom of the split button.
 * @cssprop {String} --split-button-padding-left - The padding left of the split button.
 * @cssprop {String} --split-button-padding-right - The padding right of the split button.
 * @cssprop {String} --split-button-padding-top - The padding top of the split button.
 * @cssprop {String} --split-button-progress-ring-width - The button progress ring width CSS custom property.
 * @cssprop {String} --split-button-progress-thickness - The button progress thickness CSS custom property.
 * @cssprop {Color} --split-button-ripple-color - The button ripple color CSS custom property.
 * @cssprop {String} --split-button-ripple-duration - The button ripple duration CSS custom property.
 * @cssprop {String} --split-button-shadow - The shadow of the split button.
 * @cssprop {String} --split-button-shadow-blur - The button shadow blur CSS custom property.
 * @cssprop {String} --split-button-shadow-color - The button shadow color CSS custom property.
 * @cssprop {String} --split-button-shadow-offset-x - The button shadow offset x CSS custom property.
 * @cssprop {String} --split-button-shadow-offset-y - The button shadow offset y CSS custom property.
 * @cssprop {String} --split-button-shadow-spread - The button shadow spread CSS custom property.
 * @cssprop {String} --split-button-transition-duration - The transition duration for the split button.
 * @cssprop {String} --split-button-transition-mode - The transition mode for the split button.
 * @cssprop {String} --split-button-transition-property - The transition property for the split button.
 * @cssprop {String} --split-button-translate - The button translate CSS custom property.
 * @cssprop {String} --split-button-width - The button width CSS custom property.
 *
 * @dependency {FloatingElement} mosaik-floating - The Floating component, used for floating behavior.
 * @dependency {FocusRingElement} mosaik-focus-ring - The Focus Ring component, used for focus indication.
 * @dependency {IconElement} mosaik-icon - The Icon component, used for displaying the icon.
 * @dependency mosaik-portal - The Portal element.
 * @dependency {ProgressRingElement} mosaik-progress-ring - The Progress Ring component, used for progress indication.
 * @dependency {RippleElement} mosaik-ripple - The Ripple component, used for the ripple effect.
 * @dependency {StackElement} mosaik-stack - The Stack component, used for layout management.
 * @dependency {TextElement} mosaik-text - The Text component, used for displaying the label text.
 *
 * @example
 * Basic split button:
 * ```html
 * <mosaik-split-button label="Save">
 *   <mosaik-menu>
 *     <mosaik-menu-item label="Save as..."></mosaik-menu-item>
 *     <mosaik-menu-item label="Export"></mosaik-menu-item>
 *   </mosaik-menu>
 * </mosaik-split-button>
 * ```
 *
 * @example
 * Split button with variant:
 * ```html
 * <mosaik-split-button label="Submit" variant="primary">
 *   <mosaik-menu>
 *     <mosaik-menu-item label="Submit and notify"></mosaik-menu-item>
 *     <mosaik-menu-item label="Submit as draft"></mosaik-menu-item>
 *   </mosaik-menu>
 * </mosaik-split-button>
 * ```
 *
 * @public
 */
export declare class SplitButtonElement extends SplitButtonElement_base implements ISplitButtonElementProps, IDropDownable {
    private readonly _intlController;
    private readonly _projectionController;
    private readonly _portalActivationController;
    private readonly _clickOutsideController;
    /**
     * @public
     */
    constructor();
    /**
     * Returns the `is` property.
     * The `is` property represents natural name of this element.
     *
     * @public
     * @static
     * @readonly
     */
    static get is(): string;
    /**
     * Gets or sets the internationalized names of the internal actions.
     *
     * @public
     */
    get intl(): SplitButtonElementIntl;
    set intl(value: SplitButtonElementIntl);
    /**
     * @inheritdoc
     *
     * @public
     * @override
     */
    get isDropDownOpen(): boolean;
    set isDropDownOpen(value: boolean);
    /**
     * @protected
     */
    protected onIsDropDownOpenPropertyChanged(_prev?: boolean, next?: boolean): void;
    protected onIsBusyPropertyChanged(_prev?: boolean, next?: boolean): void;
    /**
     * Closes the drop down; Escape also returns the focus from the drop down content to the button.
     *
     * @private
     */
    private onClickedOutside;
}
/**
 * @public
 */
export declare namespace SplitButtonElement {
    type Props = ISplitButtonElementProps;
}
/**
 * @public
 */
declare global {
    interface HTMLElementTagNameMap {
        'mosaik-split-button': SplitButtonElement;
    }
}
export {};
//# sourceMappingURL=SplitButtonElement.d.ts.map