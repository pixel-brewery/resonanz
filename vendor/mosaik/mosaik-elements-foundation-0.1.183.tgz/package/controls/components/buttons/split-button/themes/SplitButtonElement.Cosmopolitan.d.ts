import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function splitButtonElementCosmopolitanStyle(): CSSResult;
//# sourceMappingURL=SplitButtonElement.Cosmopolitan.d.ts.map