import { ElementIntlBase } from '../../../../../intl/abstracts/ElementIntlBase';
/**
 * Internationalized action name for the separate menu button.
 *
 * @public
 */
export declare class SplitButtonElementIntl extends ElementIntlBase {
    private _toggleLabel;
    /**
     * @public
     */
    constructor(locale?: string);
    /**
     * Gets or sets the menu button's accessible name.
     *
     * @public
     */
    get toggleLabel(): string;
    set toggleLabel(value: string);
}
//# sourceMappingURL=SplitButtonElementIntl.d.ts.map