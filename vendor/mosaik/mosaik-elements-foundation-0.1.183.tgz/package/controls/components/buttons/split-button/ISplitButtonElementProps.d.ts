import type { SplitButtonElementIntl } from './intl/SplitButtonElementIntl';
import type { IBusyableProps } from '../../../behaviors/Busyable';
import type { IContentAlignableProps } from '../../../behaviors/ContentAlignable';
import type { IDropDownableProps } from '../../../behaviors/DropDownable';
import type { IFitableProps } from '../../../behaviors/Fitable';
import type { IIconableProps } from '../../../behaviors/Iconable';
import type { ILabelableProps } from '../../../behaviors/Labelable';
import type { IOrientableProps } from '../../../behaviors/Orientable';
import type { IReversibleProps } from '../../../behaviors/Reversible';
import type { IThemeableProps } from '../../../behaviors/Themeable';
import type { IButtonBaseElementProps } from '../abstracts/IButtonBaseElementProps';
/**
 * Represents the `ISplitButtonElementProps` interface.
 *
 * @public
 */
export interface ISplitButtonElementProps extends IButtonBaseElementProps, IOrientableProps, IContentAlignableProps, IFitableProps, IDropDownableProps, IBusyableProps, IReversibleProps, ILabelableProps, IIconableProps, IThemeableProps {
    intl: SplitButtonElementIntl;
}
//# sourceMappingURL=ISplitButtonElementProps.d.ts.map