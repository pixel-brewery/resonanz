// #region Imports
import { ElementIntlBase } from '../../../../../intl/abstracts/ElementIntlBase';
// #endregion
/**
 * Internationalized action name for the separate menu button.
 *
 * @public
 */
export class SplitButtonElementIntl extends ElementIntlBase {
    // #region Fields
    _toggleLabel;
    // #endregion
    // #region Ctor
    /**
     * @public
     */
    constructor(locale) {
        super(locale);
        this._toggleLabel = 'Toggle menu';
    }
    // #endregion
    // #region Properties
    /**
     * Gets or sets the menu button's accessible name.
     *
     * @public
     */
    get toggleLabel() {
        return this._toggleLabel;
    }
    set toggleLabel(value) {
        this._toggleLabel = value;
    }
}
//# sourceMappingURL=SplitButtonElementIntl.js.map