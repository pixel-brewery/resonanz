import { type TemplateResult } from '../../../../dom/Html';
import type { SplitButtonElement } from './SplitButtonElement';
/**
 * The template of the `SplitButtonElement`.
 *
 * @public
 */
export declare function splitButtonElementTemplate<T extends SplitButtonElement>(e: T): TemplateResult;
//# sourceMappingURL=SplitButtonElementTemplate.d.ts.map