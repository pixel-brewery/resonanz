import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function splitButtonElementSohoStyle(): CSSResult;
//# sourceMappingURL=SplitButtonElement.Soho.d.ts.map