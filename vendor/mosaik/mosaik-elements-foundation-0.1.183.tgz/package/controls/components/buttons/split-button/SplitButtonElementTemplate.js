// #region Imports
import { stop } from '@pixel-brewery/mosaik-elements';
import { html } from '../../../../dom/Html';
import { ifDefined, when } from '../../../directives/Directives';
import { Appearance } from '../../../types/Appearance';
import { IconPosition } from '../../../types/IconPosition';
import { Placement } from '../../../types/Placement';
import { Size } from '../../../types/Size';
/**
 * The template of the `SplitButtonElement`.
 *
 * @public
 */
export function splitButtonElementTemplate(e) {
    return html `
        <button id="button"
                part="button"
                aria-label="${ifDefined(e.getAttribute('aria-label') ?? undefined)}"
                type="${e.type}"
                @focusin="${(x) => showFocusRing(x, 'focusRingMain', 'focusRingSplit')}"
                @focusout="${(x) => hideFocusRing(x, 'focusRingMain')}"
                @click="${() => e.close()}">
            ${when(!e.disabled, () => html `
            <mosaik-focus-ring part="focusRingMain"
                               .lang="${e.lang}"
                               .dir="${e.dir}"
                               .variant="${e.variant}"
                               .controlled="${'manual'}"
                               .for="${'button'}"></mosaik-focus-ring>
            `)}
            ${when(!e.disabled && e.ripple, () => html `
            <mosaik-ripple part="rippleMain"
                           .lang="${e.lang}"
                           .dir="${e.dir}"
                           .variant="${e.variant}"
                           .for="${'button'}"></mosaik-ripple>
            `)}
            <mosaik-stack part="innerStack"
                          .lang="${e.lang}"
                          .dir="${e.dir}"
                          .orientation="${e.orientation}"
                          .verticalAlignment="${e.verticalContentAlignment}"
                          .horizontalAlignment="${e.horizontalContentAlignment}"
                          .reverse="${e.iconPosition === IconPosition.After}">
                <slot name="icon">
                ${when(e.icon, () => html `
                    <mosaik-icon part="icon"
                                 .lang="${e.lang}"
                                 .dir="${e.dir}"
                                 .appearance="${Appearance.Plain}"
                                 .variant="${e.variant}"
                                 .icon="${e.icon}"
                                 .size="${e.iconSize ?? e.size}"
                                 .inline="${true}"
                                 ?disabled="${e.disabled}"></mosaik-icon>
                `)}
                </slot>
                <slot name="label">
                ${when(e.label, () => html `
                    <mosaik-text part="label"
                                 .lang="${e.lang}"
                                 .dir="${e.dir}"
                                 .text="${e.label}"
                                 .variant="${e.variant}"
                                 ?disabled="${e.disabled}"></mosaik-text>
                `)}
                </slot>
            </mosaik-stack>
            ${when(e.isBusy, () => html `
            <mosaik-progress-ring part="progressRing"
                                  .lang="${e.lang}"
                                  .dir="${e.dir}"
                                  .radius="${'12px'}"
                                  .variant="${e.variant}"
                                  .isIndeterminate="${true}"
                                  ?disabled="${e.disabled}"></mosaik-progress-ring>
            `)}
        </button>
        <button part="buttonSplit"
                id="button_split"
                aria-label="${e.intl.toggleLabel}"
                type="button"
                ?disabled="${e.disabled}"
                @focusin="${(x) => showFocusRing(x, 'focusRingSplit', 'focusRingMain')}"
                @focusout="${(x) => hideFocusRing(x, 'focusRingSplit')}"
                @click="${(x) => stop(x, () => e.onSplit(x))}">
            ${when(!e.disabled, () => html `
            <mosaik-focus-ring part="focusRingSplit"
                               .lang="${e.lang}"
                               .dir="${e.dir}"
                               .variant="${e.variant}"
                               .controlled="${'manual'}"
                               .for="${'button_split'}"></mosaik-focus-ring>
            `)}
            ${when(!e.disabled && e.ripple, () => html `
            <mosaik-ripple part="rippleSplit"
                           .lang="${e.lang}"
                           .dir="${e.dir}"
                           .variant="${e.variant}"
                           .for="${'button_split'}"></mosaik-ripple>
            `)}
            <mosaik-icon part="iconCaret"
                         .lang="${e.lang}"
                         .dir="${e.dir}"
                         .inline="${true}"
                         .size="${Size.Small}"
                         .icon="${'caret-down'}"
                         .appearance="${Appearance.Plain}"
                         .variant="${e.variant}"
                         ?disabled="${e.disabled}"></mosaik-icon>
        </button>
        <slot name="overlay"></slot>
        <slot></slot>
        <mosaik-portal part="portal"
                       .isActive="${e.isDropDownOpen}">
            <mosaik-floating part="popup"
                             .lang="${e.lang}"
                             .dir="${e.dir}"
                             .anchor="${getSplitAnchor(e)}"
                             .placement="${e.dropDownPlacement}"
                             .distance="${e.dropDownDistance}"
                             .skidding="${e.dropDownSkidding}"
                             .strategy="${e.dropDownStrategy}"
                             .maxHeight="${e.dropDownMaxHeight}"
                             .height="${e.dropDownHeight}"
                             .maxWidth="${e.dropDownMaxWidth}"
                             .width="${e.dropDownWidth}"
                             .flipFallbackPlacements="${[Placement.Top, Placement.Bottom, Placement.Left, Placement.Right]}"
                             .sync="${'none'}"
                             ?flip="${true}"
                             ?shift="${true}"
                             ?active="${e.isDropDownOpen}">
                <div part="projection"></div>
            </mosaik-floating>
        </mosaik-portal>
    `;
}
function getSplitAnchor(element) {
    return element.shadowRoot?.getElementById('button_split') ?? element;
}
function showFocusRing(event, focusedPart, blurredPart) {
    setFocusRingVisible(event, focusedPart, true);
    setFocusRingVisible(event, blurredPart, false);
}
function hideFocusRing(event, part) {
    setFocusRingVisible(event, part, false);
}
function setFocusRingVisible(event, part, visible) {
    const root = event.currentTarget.getRootNode();
    const focusRing = root.querySelector(`[part="${part}"]`);
    if (focusRing) {
        focusRing.visible = visible;
    }
}
//# sourceMappingURL=SplitButtonElementTemplate.js.map