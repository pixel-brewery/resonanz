import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function pressButtonElementCosmopolitanStyle(): CSSResult;
//# sourceMappingURL=PressButtonElement.Cosmopolitan.d.ts.map