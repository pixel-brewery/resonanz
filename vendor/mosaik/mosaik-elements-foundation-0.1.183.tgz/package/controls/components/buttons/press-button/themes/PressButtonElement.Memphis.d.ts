import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function pressButtonElementMemphisStyle(): CSSResult;
//# sourceMappingURL=PressButtonElement.Memphis.d.ts.map