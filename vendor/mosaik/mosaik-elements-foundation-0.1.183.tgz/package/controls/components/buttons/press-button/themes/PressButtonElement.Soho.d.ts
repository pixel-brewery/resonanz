import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function pressButtonElementSohoStyle(): CSSResult;
//# sourceMappingURL=PressButtonElement.Soho.d.ts.map