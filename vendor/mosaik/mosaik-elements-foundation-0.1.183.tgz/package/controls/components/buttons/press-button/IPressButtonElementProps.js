// #region Imports
export {};
//# sourceMappingURL=IPressButtonElementProps.js.map