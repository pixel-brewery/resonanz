import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function pressButtonElementJoyStyle(): CSSResult;
//# sourceMappingURL=PressButtonElement.Joy.d.ts.map