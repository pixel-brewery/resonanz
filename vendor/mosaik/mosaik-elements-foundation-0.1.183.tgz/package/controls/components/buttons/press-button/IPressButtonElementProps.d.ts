import type { IBusyableProps } from '../../../behaviors/Busyable';
import type { IContentAlignableProps } from '../../../behaviors/ContentAlignable';
import type { IIconableProps } from '../../../behaviors/Iconable';
import type { ILabelableProps } from '../../../behaviors/Labelable';
import type { IOrientableProps } from '../../../behaviors/Orientable';
import type { IReversibleProps } from '../../../behaviors/Reversible';
import type { IThemeableProps } from '../../../behaviors/Themeable';
import type { IButtonBaseElementProps } from '../abstracts/IButtonBaseElementProps';
/**
 * Represents the `IPressButtonElementProps` interface.
 *
 * @public
 */
export interface IPressButtonElementProps extends IButtonBaseElementProps, IOrientableProps, IBusyableProps, IReversibleProps, ILabelableProps, IIconableProps, IThemeableProps, IContentAlignableProps {
    duration: number;
}
//# sourceMappingURL=IPressButtonElementProps.d.ts.map