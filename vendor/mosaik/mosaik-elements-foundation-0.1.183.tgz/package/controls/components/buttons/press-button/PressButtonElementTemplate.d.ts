import { type TemplateResult } from '../../../../dom/Html';
import type { PressButtonElement } from './PressButtonElement';
/**
 * @public
 */
export declare function pressButtonElementTemplate<T extends PressButtonElement>(e: T): TemplateResult;
//# sourceMappingURL=PressButtonElementTemplate.d.ts.map