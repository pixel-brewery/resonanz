import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function dropDownButtonElementSohoStyle(): CSSResult;
//# sourceMappingURL=DropDownButtonElement.Soho.d.ts.map