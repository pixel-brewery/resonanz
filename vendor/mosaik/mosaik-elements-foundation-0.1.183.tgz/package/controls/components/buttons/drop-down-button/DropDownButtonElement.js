// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var DropDownButtonElement_1;
import { Themeable } from '../../../../controls/behaviors/Themeable';
import { Busyable } from '../../../behaviors/Busyable';
import { ContentAlignable } from '../../../behaviors/ContentAlignable';
import { DropDownable } from '../../../behaviors/DropDownable';
import { Fitable } from '../../../behaviors/Fitable';
import { Iconable } from '../../../behaviors/Iconable';
import { Labelable } from '../../../behaviors/Labelable';
import { Orientable } from '../../../behaviors/Orientable';
import { Reversible } from '../../../behaviors/Reversible';
import { addClickOutsideController } from '../../../controllers/ClickOutsideController';
import { addPortalActivationController } from '../../../controllers/PortalActivationController';
import { Attribute } from '../../../decorators/AttributeDecorator';
import { Component } from '../../../decorators/ComponentDecorator';
import { Watch } from '../../../decorators/WatchDecorator';
import { CustomElement } from '../../abstracts/CustomElement';
import { RippleElement } from '../../effects/ripple/RippleElement';
import { StackElement } from '../../layouts/stack/StackElement';
import { IconElement } from '../../media/icon/IconElement';
import { FloatingElement } from '../../primitives/floating/FloatingElement';
import { FocusRingElement } from '../../primitives/focus-ring/FocusRingElement';
import { PortalElement } from '../../primitives/portal/PortalElement';
import { addProjectionController } from '../../primitives/portal/ProjectionController';
import { TextElement } from '../../primitives/text/TextElement';
import { ProgressRingElement } from '../../ranges/progress-ring/ProgressRingElement';
import { MenuElement } from '../../selectors/menu/MenuElement';
import { ButtonBaseElement } from '../abstracts/ButtonBaseElement';
import { dropDownButtonElementTemplate } from './DropDownButtonElementTemplate';
import { dropDownButtonElementCosmopolitanStyle } from './themes/DropDownButtonElement.Cosmopolitan';
import { dropDownButtonElementJoyStyle } from './themes/DropDownButtonElement.Joy';
import { dropDownButtonElementMemphisStyle } from './themes/DropDownButtonElement.Memphis';
import { dropDownButtonElementSohoStyle } from './themes/DropDownButtonElement.Soho';
// #endregion
/**
 * The ARIA attributes of the host that the inner button carries - the button takes the focus, so assistive technology
 * reads them there. `aria-haspopup` defaults to `menu`, `aria-expanded` follows `isDropDownOpen`. ID references
 * (`aria-controls`, `aria-describedby`) cannot cross the shadow root and stay on the host.
 *
 * @private
 */
const FORWARDED_ARIA_ATTRIBUTES = ['aria-haspopup'];
/**
 * Drop Down Button - A button that opens a menu when clicked, allowing users to select from a list of options.
 *
 * @description
 * The Drop Down Button is a versatile user interface component that triggers a dropdown menu containing additional
 * options or actions. When clicked, the button reveals a menu with a list of choices, providing users with multiple
 * actions or selections in a compact and organized manner. Drop Down Buttons are commonly used in navigation bars,
 * toolbars, and other interactive areas where a set of related options needs to be presented.
 *
 * @name Drop Down Button
 * @element mosaik-dropdown-button
 * @category Buttons
 *
 * @slot - The default dropdown content slot.
 * @slot icon - The icon slot.
 * @slot label - The label slot.
 * @slot overlay - The overlay slot (useful for badges).
 *
 * @csspart button - The button part.
 * @csspart focusRing - The focus ring part.
 * @csspart icon - The icon part.
 * @csspart iconCaret - The icon caret part.
 * @csspart innerStack - The innerStack part.
 * @csspart label - The label part.
 * @csspart popup - The popup part.
 * @csspart portal - The portal part.
 * @csspart progressRing - The progress ring part.
 * @csspart projection - The projection part.
 * @csspart ripple - The ripple part.
 *
 * @cssprop {Color} --dropdown-button-background-color - The background color of the drop down button.
 * @cssprop {Color} --dropdown-button-border-color - The border color of the drop down button.
 * @cssprop {String} --dropdown-button-border-radius - The border radius of the drop down button.
 * @cssprop {String} --dropdown-button-border-style - The down button border style CSS custom property.
 * @cssprop {String} --dropdown-button-border-width - The border width of the drop down button.
 * @cssprop {String} --dropdown-button-focus-ring-active-width - The down button focus ring active width CSS custom property.
 * @cssprop {String} --dropdown-button-focus-ring-color - The down button focus ring color CSS custom property.
 * @cssprop {String} --dropdown-button-focus-ring-inward-offset - The down button focus ring inward offset CSS custom property.
 * @cssprop {String} --dropdown-button-focus-ring-outward-offset - The down button focus ring outward offset CSS custom property.
 * @cssprop {String} --dropdown-button-font-family - The font family of the drop down button.
 * @cssprop {String} --dropdown-button-font-letter-spacing - The letter spacing of the drop down button font.
 * @cssprop {String} --dropdown-button-font-line-height - The line height of the drop down button font.
 * @cssprop {String} --dropdown-button-font-size - The font size of the drop down button.
 * @cssprop {String} --dropdown-button-font-text-decoration - The text decoration of the drop down button font.
 * @cssprop {String} --dropdown-button-font-text-transform - The text transform of the drop down button font.
 * @cssprop {String} --dropdown-button-font-weight - The font weight of the drop down button.
 * @cssprop {Color} --dropdown-button-foreground-color - The foreground color of the drop down button.
 * @cssprop {String} --dropdown-button-gap - The gap between elements in the drop down button.
 * @cssprop {String} --dropdown-button-height - The down button height CSS custom property.
 * @cssprop {String} --dropdown-button-icon-min-height - The down button icon min height CSS custom property.
 * @cssprop {String} --dropdown-button-icon-min-width - The down button icon min width CSS custom property.
 * @cssprop {String} --dropdown-button-line-height - The down button line height CSS custom property.
 * @cssprop {String} --dropdown-button-min-height - The down button min height CSS custom property.
 * @cssprop {String} --dropdown-button-min-width - The down button min width CSS custom property.
 * @cssprop {String} --dropdown-button-padding-bottom - The bottom padding of the drop down button.
 * @cssprop {String} --dropdown-button-padding-left - The left padding of the drop down button.
 * @cssprop {String} --dropdown-button-padding-right - The right padding of the drop down button.
 * @cssprop {String} --dropdown-button-padding-top - The top padding of the drop down button.
 * @cssprop {String} --dropdown-button-progress-ring-width - The down button progress ring width CSS custom property.
 * @cssprop {String} --dropdown-button-progress-thickness - The down button progress thickness CSS custom property.
 * @cssprop {Color} --dropdown-button-ripple-color - The down button ripple color CSS custom property.
 * @cssprop {String} --dropdown-button-ripple-duration - The down button ripple duration CSS custom property.
 * @cssprop {String} --dropdown-button-shadow - The shadow of the drop down button.
 * @cssprop {String} --dropdown-button-shadow-blur - The down button shadow blur CSS custom property.
 * @cssprop {String} --dropdown-button-shadow-color - The down button shadow color CSS custom property.
 * @cssprop {String} --dropdown-button-shadow-offset-x - The down button shadow offset x CSS custom property.
 * @cssprop {String} --dropdown-button-shadow-offset-y - The down button shadow offset y CSS custom property.
 * @cssprop {String} --dropdown-button-shadow-spread - The down button shadow spread CSS custom property.
 * @cssprop {String} --dropdown-button-transform - The down button transform CSS custom property.
 * @cssprop {String} --dropdown-button-transition-duration - The transition duration of the drop down button.
 * @cssprop {String} --dropdown-button-transition-mode - The down button transition mode CSS custom property.
 * @cssprop {String} --dropdown-button-transition-property - The down button transition property CSS custom property.
 * @cssprop {String} --dropdown-button-translate - The down button translate CSS custom property.
 * @cssprop {String} --dropdown-button-width - The down button width CSS custom property.
 *
 * @dependency mosaik-floating - The Floating element.
 * @dependency mosaik-focus-ring - The Focus Ring element.
 * @dependency mosaik-icon - The Icon element.
 * @dependency mosaik-portal - The Portal element.
 * @dependency mosaik-progress-ring - The Progress Ring element.
 * @dependency mosaik-ripple - The Ripple element.
 * @dependency mosaik-stack - The Stack element.
 * @dependency mosaik-text - The Text element.
 *
 * @example
 * Basic dropdown button:
 * ```html
 * <mosaik-dropdown-button label="Options">
 *   <mosaik-menu>
 *     <mosaik-menu-item label="Option 1"></mosaik-menu-item>
 *     <mosaik-menu-item label="Option 2"></mosaik-menu-item>
 *   </mosaik-menu>
 * </mosaik-dropdown-button>
 * ```
 *
 * @example
 * Dropdown button with variant and no caret:
 * ```html
 * <mosaik-dropdown-button label="Actions" variant="primary" caret-visible="false">
 *   <mosaik-menu>
 *     <mosaik-menu-item label="Edit"></mosaik-menu-item>
 *     <mosaik-menu-item label="Delete"></mosaik-menu-item>
 *   </mosaik-menu>
 * </mosaik-dropdown-button>
 * ```
 *
 * @public
 */
let DropDownButtonElement = DropDownButtonElement_1 = class DropDownButtonElement extends Themeable(Reversible(Orientable(ContentAlignable(Fitable(DropDownable(Busyable(Labelable(Iconable(ButtonBaseElement))))))))) {
    // #region Fields
    _projectionController = addProjectionController(this, {
        slotName: '',
        targetSelector: '[part="projection"]',
        projecting: (element) => {
            element.setAttribute(`${DropDownButtonElement_1.is}-projection`, '');
        }
    });
    _portalActivationController = addPortalActivationController(this, () => this._projectionController.elements, () => this.close());
    _clickOutsideController = addClickOutsideController(this, {
        skipInitial: true,
        ignored: () => this._projectionController.elements,
        callback: (event) => this.onClickedOutside(event)
    });
    _caretVisible;
    _focusRevision = 0;
    // #endregion
    // #region Ctor
    /**
     * @public
     */
    constructor() {
        super();
        this._caretVisible = true;
        this.addEventListener('keydown', (event) => this.onTriggerKeyDown(event));
        // REMARK: This is a workaround for the issue with the docs generation.
        Object.assign(this, { dropDownMaxHeight: 'auto' });
    }
    // #endregion
    // #region Properties
    /**
     * Returns the `is` property.
     * The `is` property represents natural name of this element.
     *
     * @public
     * @static
     * @readonly
     */
    static get is() {
        return 'mosaik-dropdown-button';
    }
    /**
     * The observed attributes, including the forwarded ARIA attributes of the host.
     *
     * @public
     * @static
     * @override
     * @readonly
     */
    static get observedAttributes() {
        return [...super.observedAttributes, ...FORWARDED_ARIA_ATTRIBUTES];
    }
    /**
     * @inheritdoc
     *
     * @public
     * @override
     */
    get isDropDownOpen() {
        return super.isDropDownOpen;
    }
    set isDropDownOpen(value) {
        if (!value && super.isDropDownOpen) {
            this._focusRevision++;
            for (const element of this._projectionController.elements) {
                if (element instanceof MenuElement) {
                    element.collapseSubmenus();
                }
            }
        }
        super.isDropDownOpen = value;
    }
    /**
     * Gets or sets the `caretVisible` property.
     *
     * @public
     * @attr caret-visible
     */
    get caretVisible() {
        return this._caretVisible;
    }
    set caretVisible(value) {
        if (this._caretVisible !== value) {
            this._caretVisible = value;
            this.requestUpdate('caretVisible');
        }
    }
    // #endregion
    // #region Methods
    /**
     * @public
     * @override
     */
    connectedCallback() {
        super.connectedCallback();
        this.on('click', (event) => {
            // check if the event.target is the button
            if (event.currentTarget !== this) {
                return;
            }
            this.toggle();
        });
        this.addEventListener('activated', () => {
            this.close();
        });
    }
    /**
     * Renders again when a forwarded ARIA attribute of the host changes, so the inner button follows it - e.g. the
     * `aria-label` of an icon-only drop down.
     *
     * @public
     * @override
     */
    attributeChangedCallback(name, old, value) {
        super.attributeChangedCallback(name, old, value);
        if (old !== value && FORWARDED_ARIA_ATTRIBUTES.includes(name)) {
            this.requestUpdate();
        }
    }
    /**
     * @protected
     */
    onIsDropDownOpenPropertyChanged(_prev, next) {
        // handle interaction outside of popup
        if (next) {
            // if busy, close the popup
            if (this.isBusy) {
                this.close();
                return;
            }
            this._portalActivationController.observe();
            this._clickOutsideController.observe();
        }
        else {
            this._portalActivationController.unobserve();
            this._clickOutsideController.unobserve();
        }
    }
    /**
     * @protected
     */
    onIsBusyPropertyChanged(_prev, next) {
        // if busy, close the popup
        if (next) {
            this.isDropDownOpen = false;
        }
    }
    /**
     * Opens the drop down from its trigger and transfers keyboard focus into the projected content.
     *
     * @private
     */
    onTriggerKeyDown(event) {
        const button = this.shadowRoot?.querySelector('[part="button"]');
        if (event.defaultPrevented || this.disabled || this.isBusy || event.altKey || event.ctrlKey || event.metaKey ||
            (event.target !== this && (!button || !event.composedPath().includes(button)))) {
            return;
        }
        if (event.key !== 'Enter' && event.key !== ' ' && event.key !== 'ArrowDown' && event.key !== 'ArrowUp') {
            return;
        }
        // Suppress the native synthesized click, which would toggle the freshly opened drop down closed again.
        event.preventDefault();
        this.open();
        void this.focusDropDownContent(event.key === 'ArrowUp', ++this._focusRevision);
    }
    /**
     * Waits for the portal and its content to render, then focuses a menu or an ordinary projected control.
     *
     * @private
     */
    async focusDropDownContent(last, revision) {
        await this.updateComplete;
        const portal = this.shadowRoot?.querySelector(PortalElement.is);
        await portal?.updateComplete;
        await portal?.projection?.updateComplete;
        const roots = this._projectionController.elements;
        const selector = 'mosaik-menu, a[href], button, input, select, textarea, [tabindex]';
        const candidates = roots.flatMap((root) => [root, ...root.querySelectorAll(selector)]);
        await Promise.all(candidates.filter((element) => element instanceof CustomElement).map((element) => element.updateComplete));
        if (!this.isConnected || !this.isDropDownOpen || this.disabled || this.isBusy || revision !== this._focusRevision) {
            return;
        }
        const focusable = candidates.filter((element) => (element instanceof MenuElement || element.tabIndex >= 0) &&
            !element.parentElement?.closest(MenuElement.is) &&
            !element.closest('[hidden], [inert], [aria-hidden="true"], [disabled]:not([disabled="false"]), [aria-disabled="true"]') &&
            !element.matches(':disabled'));
        const target = last ? focusable.at(-1) : focusable[0];
        if (target instanceof MenuElement) {
            if (last) {
                target.focusLastItem();
            }
            else {
                target.focusFirstItem();
            }
        }
        else {
            target?.focus();
        }
    }
    /**
     * Closes the drop down; Escape also returns the focus from the drop down content to the button.
     *
     * @private
     */
    onClickedOutside(event) {
        this.close();
        if (event instanceof KeyboardEvent) {
            this.focus();
        }
    }
    /**
     * @private
     * @template
     */
    onFloatingActiveChanged(active) {
        if (!active) {
            this.close();
        }
    }
};
__decorate([
    Attribute({
        type: Boolean
        // useDefault: true // TODO: dump naming, because the default is actually true, and should be false
    }),
    __metadata("design:type", Boolean),
    __metadata("design:paramtypes", [Boolean])
], DropDownButtonElement.prototype, "caretVisible", null);
__decorate([
    Watch('isDropDownOpen', { waitUntilFirstUpdate: true }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Boolean, Boolean]),
    __metadata("design:returntype", void 0)
], DropDownButtonElement.prototype, "onIsDropDownOpenPropertyChanged", null);
__decorate([
    Watch('isBusy', { waitUntilFirstUpdate: true }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Boolean, String]),
    __metadata("design:returntype", void 0)
], DropDownButtonElement.prototype, "onIsBusyPropertyChanged", null);
DropDownButtonElement = DropDownButtonElement_1 = __decorate([
    Component({
        selector: 'mosaik-dropdown-button',
        template: dropDownButtonElementTemplate,
        themes: {
            joy: dropDownButtonElementJoyStyle,
            memphis: dropDownButtonElementMemphisStyle,
            cosmopolitan: dropDownButtonElementCosmopolitanStyle,
            soho: dropDownButtonElementSohoStyle
        },
        options: {
            mode: 'open',
            delegatesFocus: true
        },
        imports: [
            StackElement,
            IconElement,
            RippleElement,
            FocusRingElement,
            TextElement,
            ProgressRingElement,
            FloatingElement,
            MenuElement,
            PortalElement
        ]
    }),
    __metadata("design:paramtypes", [])
], DropDownButtonElement);
export { DropDownButtonElement };
//# sourceMappingURL=DropDownButtonElement.js.map