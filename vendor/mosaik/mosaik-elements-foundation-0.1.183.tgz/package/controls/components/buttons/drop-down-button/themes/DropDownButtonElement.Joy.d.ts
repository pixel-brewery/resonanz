import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function dropDownButtonElementJoyStyle(): CSSResult;
//# sourceMappingURL=DropDownButtonElement.Joy.d.ts.map