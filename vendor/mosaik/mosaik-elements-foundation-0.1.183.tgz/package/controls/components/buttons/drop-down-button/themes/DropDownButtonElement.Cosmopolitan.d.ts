import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function dropDownButtonElementCosmopolitanStyle(): CSSResult;
//# sourceMappingURL=DropDownButtonElement.Cosmopolitan.d.ts.map