import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function dropDownButtonElementMemphisStyle(): CSSResult;
//# sourceMappingURL=DropDownButtonElement.Memphis.d.ts.map