// #region Imports
import { html } from '../../../../dom/Html';
import { ifDefined, when } from '../../../directives/Directives';
import { Appearance } from '../../../types/Appearance';
import { IconPosition } from '../../../types/IconPosition';
import { Placement } from '../../../types/Placement';
import { Size } from '../../../types/Size';
// #endregion
/**
 * The template of the `DropDownButtonElement`.
 *
 * @public
 */
export function dropDownButtonElementTemplate(e) {
    return html `
        ${when(!e.disabled, () => html `
        <mosaik-focus-ring part="focusRing"
                           .variant="${e.variant}"
                           .visible="${e.isFocused}"
                           .controlled="${'manual'}"
                           .for="${'button'}"></mosaik-focus-ring>
        `)}
        <button id="button"
                part="button"
                type="${e.type}"
                aria-label="${ifDefined(e.getAttribute('aria-label') ?? undefined)}"
                aria-haspopup="${e.getAttribute('aria-haspopup') ?? 'menu'}"
                aria-expanded="${e.isDropDownOpen ? 'true' : 'false'}">
            ${when(!e.disabled && e.ripple, () => html `
            <mosaik-ripple part="ripple"
                           .variant="${e.variant}"
                           .for="${'button'}"></mosaik-ripple>
            `)}
            <mosaik-stack part="innerStack" .orientation="${e.orientation}"
                          .verticalAlignment="${e.verticalContentAlignment}"
                          .horizontalAlignment="${e.horizontalContentAlignment}"
                          ?reverse="${e.iconPosition === IconPosition.After}">
                <slot name="icon">
                ${when(e.icon, () => html `
                    <mosaik-icon part="icon"
                                 .appearance="${Appearance.Plain}"
                                 .variant="${e.variant}"
                                 .icon="${e.icon}"
                                 .size="${e.iconSize ?? e.size}"
                                 .inline="${true}"
                                 ?disabled="${e.disabled}"></mosaik-icon>
                `)}
                </slot>
                <slot name="label">
                ${when(e.label, () => html `
                    <mosaik-text part="label"
                                 .text="${e.label}"
                                 .variant="${e.variant}"
                                 ?disabled="${e.disabled}"></mosaik-text>
                `)}
                </slot>
            </mosaik-stack>
            ${when(e.caretVisible, () => html `
            <mosaik-icon part="iconCaret"
                         slot="suffix"
                         .appearance="${Appearance.Plain}"
                         .variant="${e.variant}"
                         .size="${Size.Small}"
                         .icon="${'caret-down'}"
                         .inline="${true}"
                         ?disabled="${e.disabled}"></mosaik-icon>
            `)}
        </button>
        ${when(e.isBusy, () => html `
        <mosaik-progress-ring part="progressRing"
                              .lang="${e.lang}"
                              .dir="${e.dir}"
                              .radius="${'12px'}"
                              .variant="${e.variant}"
                              .isIndeterminate="${true}"
                              ?disabled="${e.disabled}"></mosaik-progress-ring>
        `)}
        <slot name="overlay"></slot>
        <slot></slot>
        <mosaik-portal part="portal"
                       .isActive="${e.isDropDownOpen}">
            <mosaik-floating part="popup"
                            .anchor="${e}"
                            .placement="${e.dropDownPlacement}"
                            .distance="${e.dropDownDistance}"
                            .skidding="${e.dropDownSkidding}"
                            .strategy="${e.dropDownStrategy}"
                            .sync="${'none'}"
                            .maxHeight="${e.dropDownMaxHeight}"
                            .height="${e.dropDownHeight}"
                            .maxWidth="${e.dropDownMaxWidth}"
                            .width="${e.dropDownWidth}"
                            .flipFallbackPlacements="${[Placement.Top, Placement.Bottom, Placement.Left, Placement.Right]}"
                            ?flip="${true}"
                            ?shift="${true}"
                            ?active="${e.isDropDownOpen}">
                <div part="projection"></div>
            </mosaik-floating>
        </mosaik-portal>
    `;
}
//# sourceMappingURL=DropDownButtonElementTemplate.js.map