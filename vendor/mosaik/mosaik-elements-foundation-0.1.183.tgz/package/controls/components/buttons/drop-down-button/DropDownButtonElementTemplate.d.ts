import { type TemplateResult } from '../../../../dom/Html';
import type { DropDownButtonElement } from './DropDownButtonElement';
/**
 * The template of the `DropDownButtonElement`.
 *
 * @public
 */
export declare function dropDownButtonElementTemplate<T extends DropDownButtonElement>(e: T): TemplateResult;
//# sourceMappingURL=DropDownButtonElementTemplate.d.ts.map