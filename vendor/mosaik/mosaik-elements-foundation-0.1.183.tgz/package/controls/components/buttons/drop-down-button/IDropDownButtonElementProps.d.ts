import type { IBusyableProps } from '../../../behaviors/Busyable';
import type { IContentAlignableProps } from '../../../behaviors/ContentAlignable';
import type { IDropDownableProps } from '../../../behaviors/DropDownable';
import type { IFitableProps } from '../../../behaviors/Fitable';
import type { IIconableProps } from '../../../behaviors/Iconable';
import type { ILabelableProps } from '../../../behaviors/Labelable';
import type { IOrientableProps } from '../../../behaviors/Orientable';
import type { IReversibleProps } from '../../../behaviors/Reversible';
import type { IThemeableProps } from '../../../behaviors/Themeable';
import type { IButtonBaseElementProps } from '../abstracts/IButtonBaseElementProps';
/**
 * Represents the `IDropDownButtonElementProps` interface.
 *
 * @public
 */
export interface IDropDownButtonElementProps extends IButtonBaseElementProps, IOrientableProps, IContentAlignableProps, IFitableProps, IDropDownableProps, IBusyableProps, IReversibleProps, ILabelableProps, IIconableProps, IThemeableProps {
    caretVisible: boolean;
}
//# sourceMappingURL=IDropDownButtonElementProps.d.ts.map