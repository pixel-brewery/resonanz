import { type CSSResult } from '../../../../dom/Css';
/**
 * @public
 */
export declare function chartToolboxElementSohoStyle(): CSSResult;
//# sourceMappingURL=ChartToolboxElement.Soho.d.ts.map