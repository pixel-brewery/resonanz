import { type CSSResult } from '../../../../dom/Css';
/**
 * @public
 */
export declare function chartToolboxElementJoyStyle(): CSSResult;
//# sourceMappingURL=ChartToolboxElement.Joy.d.ts.map