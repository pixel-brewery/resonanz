import { type CSSResult } from '../../../../dom/Css';
/**
 * @public
 */
export declare function chartElementSohoStyle(): CSSResult;
//# sourceMappingURL=ChartElement.Soho.d.ts.map