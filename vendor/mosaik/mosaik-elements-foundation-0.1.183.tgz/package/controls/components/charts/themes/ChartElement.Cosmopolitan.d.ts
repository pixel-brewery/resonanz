import { type CSSResult } from '../../../../dom/Css';
/**
 * @public
 */
export declare function chartElementCosmopolitanStyle(): CSSResult;
//# sourceMappingURL=ChartElement.Cosmopolitan.d.ts.map