import { type CSSResult } from '../../../../dom/Css';
/**
 * @public
 */
export declare function chartToolboxElementCosmopolitanStyle(): CSSResult;
//# sourceMappingURL=ChartToolboxElement.Cosmopolitan.d.ts.map