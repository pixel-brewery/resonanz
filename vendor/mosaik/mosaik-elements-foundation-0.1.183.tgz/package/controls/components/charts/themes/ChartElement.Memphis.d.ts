import { type CSSResult } from '../../../../dom/Css';
/**
 * @public
 */
export declare function chartElementMemphisStyle(): CSSResult;
//# sourceMappingURL=ChartElement.Memphis.d.ts.map