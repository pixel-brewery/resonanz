import { type CSSResult } from '../../../../dom/Css';
/**
 * @public
 */
export declare function chartToolboxElementMemphisStyle(): CSSResult;
//# sourceMappingURL=ChartToolboxElement.Memphis.d.ts.map