import { type CSSResult } from '../../../../dom/Css';
/**
 * @public
 */
export declare function chartElementJoyStyle(): CSSResult;
//# sourceMappingURL=ChartElement.Joy.d.ts.map