import { CustomElement } from '../abstracts/CustomElement';
import type { ChartElement } from './ChartElement';
import type { ChartToolVisibility } from './ChartToolVisibility';
import type { IChartToolboxElementProps } from './IChartToolboxElementProps';
import { ChartElementIntl } from './intl/ChartElementIntl';
declare const ChartToolboxElement_base: (abstract new (...args: Array<any>) => import("../../behaviors/Themeable").IThemeableProps) & typeof CustomElement & import("../../behaviors/Themeable").IThemeableCtor;
/**
 * Chart Toolbox - Reference-bound controls for a Mosaik chart.
 *
 * @description The toolbox exposes export, pointer-mode, zoom, measure, and reset
 * actions. It can be placed independently or shown by the chart itself.
 *
 * @name Chart Toolbox
 * @element mosaik-chart-toolbox
 * @category Charts
 *
 * @csspart divider - Separator between export and interaction actions
 * @csspart group - Group of related chart actions
 * @csspart tool-button - Button invoking a chart action
 * @csspart tool-tooltip - Tooltip wrapping a chart action
 *
 * @cssprop {String} --chart-toolbox-divider-height - Height of the group divider
 * @cssprop {String} --chart-toolbox-font-family - Font family inherited by the toolbox
 * @cssprop {String} --chart-toolbox-font-letter-spacing - Letter spacing inherited by the toolbox
 * @cssprop {String} --chart-toolbox-font-line-height - Text line height inherited by the toolbox
 * @cssprop {String} --chart-toolbox-font-size - Font size inherited by the toolbox
 * @cssprop {String} --chart-toolbox-font-text-decoration - Text decoration inherited by the toolbox
 * @cssprop {String} --chart-toolbox-font-text-transform - Text transformation inherited by the toolbox
 * @cssprop {String} --chart-toolbox-font-weight - Font weight inherited by the toolbox
 * @cssprop {String} --chart-toolbox-gap - Space between toolbox controls
 * @cssprop {String} --chart-toolbox-padding-bottom - Bottom inset of the toolbox
 * @cssprop {String} --chart-toolbox-padding-left - Left inset of the toolbox
 * @cssprop {String} --chart-toolbox-padding-right - Right inset of the toolbox
 * @cssprop {String} --chart-toolbox-padding-top - Top inset of the toolbox
 * @cssprop {String} --chart-toolbox-shadow - The toolbox shadow CSS custom property.
 * @cssprop {String} --chart-toolbox-shadow-blur - The toolbox shadow blur CSS custom property.
 * @cssprop {String} --chart-toolbox-shadow-color - The toolbox shadow color CSS custom property.
 * @cssprop {String} --chart-toolbox-shadow-offset-x - The toolbox shadow offset x CSS custom property.
 * @cssprop {String} --chart-toolbox-shadow-offset-y - The toolbox shadow offset y CSS custom property.
 * @cssprop {String} --chart-toolbox-shadow-spread - The toolbox shadow spread CSS custom property.
 * @cssprop {String} --chart-toolbox-transition-duration - Transition duration
 * @cssprop {String} --chart-toolbox-transition-mode - Transition timing function
 * @cssprop {String} --chart-toolbox-transition-property - Transition properties
 * @cssprop {String} --chart-toolbox-translate - Toolbox translation
 *
 * @dependency mosaik-button - Action button
 * @dependency mosaik-divider - Group separator
 * @dependency mosaik-tooltip - Action description
 *
 * @remarks
 * Import this family from `@pixel-brewery/mosaik-elements-foundation/components/chart`
 * and install its optional `apexcharts` peer dependency.
 *
 * @example
 * A sales dashboard with controls above its chart:
 * ```html
 * <mosaik-chart display="line" show-toolbox></mosaik-chart>
 * ```
 *
 * @public
 */
export declare class ChartToolboxElement extends ChartToolboxElement_base implements IChartToolboxElementProps {
    private readonly _intl;
    private readonly _onChartStateChange;
    private _chart;
    private _tools;
    /**
     * Creates a chart toolbox.
     *
     * @public
     */
    constructor();
    /**
     * The custom-element tag name.
     *
     * @public
     * @static
     * @readonly
     */
    static get is(): string;
    /**
     * Gets or sets the chart controlled by this toolbox.
     *
     * @public
     */
    get chart(): ChartElement | null;
    set chart(value: ChartElement | null);
    /**
     * Gets or sets visibility overrides for individual actions.
     *
     * @public
     */
    get tools(): ChartToolVisibility | null;
    set tools(value: ChartToolVisibility | null);
    /**
     * Gets or sets the translated action labels.
     *
     * @public
     */
    get intl(): ChartElementIntl;
    set intl(value: ChartElementIntl);
    private onChartStateChange;
    private listenToChart;
}
export declare namespace ChartToolboxElement {
    type Props = IChartToolboxElementProps;
}
declare global {
    interface HTMLElementTagNameMap {
        'mosaik-chart-toolbox': ChartToolboxElement;
    }
}
export {};
//# sourceMappingURL=ChartToolboxElement.d.ts.map