/** An action supported by a chart and its optional toolbox. @public */
export type ChartTool = 'exportSVG' | 'exportPNG' | 'exportCSV' | 'zoom' | 'zoomIn' | 'zoomOut' | 'selection' | 'pan' | 'measure' | 'reset';
//# sourceMappingURL=ChartTool.d.ts.map