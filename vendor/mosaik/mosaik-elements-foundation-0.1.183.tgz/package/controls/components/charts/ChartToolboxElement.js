// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { addIntlController } from '../../../intl/IntlController';
import { Themeable } from '../../behaviors/Themeable';
import { Component } from '../../decorators/ComponentDecorator';
import { Property } from '../../decorators/PropertyDecorator';
import { CustomElement } from '../abstracts/CustomElement';
import { ButtonElement } from '../buttons/button/ButtonElement';
import { DividerElement } from '../primitives/divider/DividerElement';
import { TooltipElement } from '../primitives/tooltip/TooltipElement';
import { Appearance } from '../../types/Appearance';
import { chartToolboxElementTemplate } from './ChartToolboxElementTemplate';
import { ChartElementIntl } from './intl/ChartElementIntl';
import { chartToolboxElementCosmopolitanStyle } from './themes/ChartToolboxElement.Cosmopolitan';
import { chartToolboxElementJoyStyle } from './themes/ChartToolboxElement.Joy';
import { chartToolboxElementMemphisStyle } from './themes/ChartToolboxElement.Memphis';
import { chartToolboxElementSohoStyle } from './themes/ChartToolboxElement.Soho';
// #endregion
const exportTools = ['exportSVG', 'exportPNG', 'exportCSV'];
const interactionTools = ['zoom', 'zoomIn', 'zoomOut', 'selection', 'pan', 'measure', 'reset'];
/**
 * Chart Toolbox - Reference-bound controls for a Mosaik chart.
 *
 * @description The toolbox exposes export, pointer-mode, zoom, measure, and reset
 * actions. It can be placed independently or shown by the chart itself.
 *
 * @name Chart Toolbox
 * @element mosaik-chart-toolbox
 * @category Charts
 *
 * @csspart divider - Separator between export and interaction actions
 * @csspart group - Group of related chart actions
 * @csspart tool-button - Button invoking a chart action
 * @csspart tool-tooltip - Tooltip wrapping a chart action
 *
 * @cssprop {String} --chart-toolbox-divider-height - Height of the group divider
 * @cssprop {String} --chart-toolbox-font-family - Font family inherited by the toolbox
 * @cssprop {String} --chart-toolbox-font-letter-spacing - Letter spacing inherited by the toolbox
 * @cssprop {String} --chart-toolbox-font-line-height - Text line height inherited by the toolbox
 * @cssprop {String} --chart-toolbox-font-size - Font size inherited by the toolbox
 * @cssprop {String} --chart-toolbox-font-text-decoration - Text decoration inherited by the toolbox
 * @cssprop {String} --chart-toolbox-font-text-transform - Text transformation inherited by the toolbox
 * @cssprop {String} --chart-toolbox-font-weight - Font weight inherited by the toolbox
 * @cssprop {String} --chart-toolbox-gap - Space between toolbox controls
 * @cssprop {String} --chart-toolbox-padding-bottom - Bottom inset of the toolbox
 * @cssprop {String} --chart-toolbox-padding-left - Left inset of the toolbox
 * @cssprop {String} --chart-toolbox-padding-right - Right inset of the toolbox
 * @cssprop {String} --chart-toolbox-padding-top - Top inset of the toolbox
 * @cssprop {String} --chart-toolbox-shadow - The toolbox shadow CSS custom property.
 * @cssprop {String} --chart-toolbox-shadow-blur - The toolbox shadow blur CSS custom property.
 * @cssprop {String} --chart-toolbox-shadow-color - The toolbox shadow color CSS custom property.
 * @cssprop {String} --chart-toolbox-shadow-offset-x - The toolbox shadow offset x CSS custom property.
 * @cssprop {String} --chart-toolbox-shadow-offset-y - The toolbox shadow offset y CSS custom property.
 * @cssprop {String} --chart-toolbox-shadow-spread - The toolbox shadow spread CSS custom property.
 * @cssprop {String} --chart-toolbox-transition-duration - Transition duration
 * @cssprop {String} --chart-toolbox-transition-mode - Transition timing function
 * @cssprop {String} --chart-toolbox-transition-property - Transition properties
 * @cssprop {String} --chart-toolbox-translate - Toolbox translation
 *
 * @dependency mosaik-button - Action button
 * @dependency mosaik-divider - Group separator
 * @dependency mosaik-tooltip - Action description
 *
 * @remarks
 * Import this family from `@pixel-brewery/mosaik-elements-foundation/components/chart`
 * and install its optional `apexcharts` peer dependency.
 *
 * @example
 * A sales dashboard with controls above its chart:
 * ```html
 * <mosaik-chart display="line" show-toolbox></mosaik-chart>
 * ```
 *
 * @public
 */
let ChartToolboxElement = class ChartToolboxElement extends Themeable(CustomElement) {
    // #region Fields
    _intl = addIntlController(this, {
        factory: () => new ChartElementIntl()
    });
    _onChartStateChange;
    _chart;
    _tools;
    // #endregion
    // #region Ctor
    /**
     * Creates a chart toolbox.
     *
     * @public
     */
    constructor() {
        super();
        this._onChartStateChange = this.onChartStateChange.bind(this);
        this._chart = null;
        this._tools = null;
    }
    // #endregion
    // #region Properties
    /**
     * The custom-element tag name.
     *
     * @public
     * @static
     * @readonly
     */
    static get is() {
        return 'mosaik-chart-toolbox';
    }
    /**
     * Gets or sets the chart controlled by this toolbox.
     *
     * @public
     */
    get chart() {
        return this._chart;
    }
    set chart(value) {
        if (this._chart === value)
            return;
        if (this.isConnected)
            this.listenToChart(this._chart, false);
        this._chart = value;
        if (this.isConnected)
            this.listenToChart(this._chart, true);
        this.requestUpdate('chart');
    }
    /**
     * Gets or sets visibility overrides for individual actions.
     *
     * @public
     */
    get tools() {
        return this._tools;
    }
    set tools(value) {
        if (this._tools !== value) {
            this._tools = value;
            this.requestUpdate('tools');
        }
    }
    /**
     * Gets or sets the translated action labels.
     *
     * @public
     */
    get intl() {
        return this._intl.intl;
    }
    set intl(value) {
        this._intl.provide(value);
    }
    // #endregion
    // #region Methods
    /**
     * Subscribes to state changes from the referenced chart.
     *
     * @internal
     */
    connectedCallback() {
        super.connectedCallback();
        this.listenToChart(this._chart, true);
    }
    /**
     * Removes subscriptions to the referenced chart.
     *
     * @internal
     */
    disconnectedCallback() {
        this.listenToChart(this._chart, false);
        super.disconnectedCallback();
    }
    /**
     * Export actions currently shown.
     *
     * @internal
     * @hidden
     * @ignore
     */
    getExportTools() {
        return exportTools.filter((tool) => this.isVisible(tool));
    }
    /**
     * Interaction actions currently shown.
     *
     * @internal
     * @hidden
     * @ignore
     */
    getInteractionTools() {
        return interactionTools.filter((tool) => this.isVisible(tool));
    }
    /**
     * Whether both action groups contain visible tools.
     *
     * @internal
     * @hidden
     * @ignore
     */
    needsSeparator() {
        return this.getExportTools().length > 0 && this.getInteractionTools().length > 0;
    }
    /**
     * Whether a tool is included by the current chart configuration.
     *
     * @internal
     * @hidden
     * @ignore
     */
    isVisible(tool) {
        return this._tools?.[tool] ?? this._chart?.isToolVisible(tool) ?? false;
    }
    /**
     * Whether a pointer tool is selected.
     *
     * @internal
     * @hidden
     * @ignore
     */
    isActive(tool) {
        return this._chart?.activeTool === tool;
    }
    /**
     * Visual appearance of a selected pointer tool.
     *
     * @internal
     * @hidden
     * @ignore
     */
    appearance(tool) {
        return this.isActive(tool) ? Appearance.Soft : Appearance.Plain;
    }
    /**
     * ARIA pressed state only applies to pointer-mode controls.
     *
     * @internal
     * @hidden
     * @ignore
     */
    pressedState(tool) {
        if (tool !== 'zoom' && tool !== 'selection' && tool !== 'pan' && tool !== 'measure')
            return undefined;
        return String(this.isActive(tool));
    }
    /**
     * Gets the icon ID of a tool.
     *
     * @internal
     * @hidden
     * @ignore
     */
    icon(tool) {
        switch (tool) {
            case 'exportSVG': return 'export';
            case 'exportPNG': return 'image';
            case 'exportCSV': return 'database';
            case 'zoom': return 'search';
            case 'zoomIn': return 'zoom-in';
            case 'zoomOut': return 'zoom-out';
            case 'selection': return 'cursor';
            case 'pan': return 'hand';
            case 'measure': return 'auto-fit-column';
            case 'reset': return 'reset';
        }
    }
    /**
     * Gets a translated action label.
     *
     * @internal
     * @hidden
     * @ignore
     */
    label(tool) {
        const options = this._chart?.chart;
        const locale = options?.locales?.find((item) => item.name === options.defaultLocale)?.options?.toolbar;
        switch (tool) {
            case 'exportSVG': return locale?.exportToSVG ?? this.intl.exportToSvgLabel;
            case 'exportPNG': return locale?.exportToPNG ?? this.intl.exportToPngLabel;
            case 'exportCSV': return locale?.exportToCSV ?? this.intl.exportToCsvLabel;
            case 'zoom': return locale?.selectionZoom ?? this.intl.zoomLabel;
            case 'zoomIn': return locale?.zoomIn ?? this.intl.zoomInLabel;
            case 'zoomOut': return locale?.zoomOut ?? this.intl.zoomOutLabel;
            case 'selection': return locale?.selection ?? this.intl.selectionLabel;
            case 'pan': return locale?.pan ?? this.intl.panLabel;
            case 'measure': return locale?.measure ?? this.intl.measureLabel;
            case 'reset': return locale?.reset ?? this.intl.resetLabel;
        }
    }
    /**
     * Invokes the clicked tool.
     *
     * @internal
     * @hidden
     * @ignore
     */
    handleToolAction(event) {
        const tool = event.currentTarget.dataset.tool;
        if (tool && this.isVisible(tool))
            this._chart?.command(tool);
    }
    onChartStateChange() {
        this.requestUpdate();
    }
    listenToChart(chart, listen) {
        if (listen) {
            chart?.addEventListener('chartReady', this._onChartStateChange);
            chart?.addEventListener('chartToolChanged', this._onChartStateChange);
        }
        else {
            chart?.removeEventListener('chartReady', this._onChartStateChange);
            chart?.removeEventListener('chartToolChanged', this._onChartStateChange);
        }
    }
};
__decorate([
    Property({ type: Object }),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [Object])
], ChartToolboxElement.prototype, "chart", null);
__decorate([
    Property({ type: Object }),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [Object])
], ChartToolboxElement.prototype, "tools", null);
__decorate([
    Property({ type: Object }),
    __metadata("design:type", ChartElementIntl),
    __metadata("design:paramtypes", [ChartElementIntl])
], ChartToolboxElement.prototype, "intl", null);
ChartToolboxElement = __decorate([
    Component({
        selector: 'mosaik-chart-toolbox',
        template: chartToolboxElementTemplate,
        themes: {
            joy: chartToolboxElementJoyStyle,
            memphis: chartToolboxElementMemphisStyle,
            cosmopolitan: chartToolboxElementCosmopolitanStyle,
            soho: chartToolboxElementSohoStyle
        },
        imports: [ButtonElement, DividerElement, TooltipElement]
    }),
    __metadata("design:paramtypes", [])
], ChartToolboxElement);
export { ChartToolboxElement };
//# sourceMappingURL=ChartToolboxElement.js.map