import type { ChartTool } from './ChartTool';
/** Explicit visibility overrides for individual chart-toolbox actions. @public */
export type ChartToolVisibility = Partial<Record<ChartTool, boolean>>;
//# sourceMappingURL=ChartToolVisibility.d.ts.map