import { CssLength } from '@pixel-brewery/mosaik-themes';
import { Fit } from '../../../types/Fit';
import { Variant } from '../../../types/Variant';
import { CustomElement } from '../../abstracts/CustomElement';
import type { IChartBaseElementProps } from './IChartBaseElementProps';
declare const ChartBaseElement_base: import("../../../../Index").ControlBehaviorReturn<import("../../../../Index").ControlBehaviorReturn<import("../../../../Index").ControlBehaviorReturn<typeof CustomElement, import("../../../behaviors/Dimensionable").IDimensionableProps>, import("../../../behaviors/Fitable").IFitableProps>, import("../../../behaviors/Variantable").IVariantableProps>;
/**
 * Chart Base Element - The foundational base class for all chart and data visualization components.
 *
 * @description
 * ChartBaseElement provides the core infrastructure for all chart-type components in the Mosaik
 * design system. It combines essential behaviors for data visualization including dimensional
 * control (width/height), fit modes (fill/contain), and visual variants (color schemes). This
 * abstract class establishes common properties like header and subheader for chart titles,
 * and provides lifecycle watch methods for property changes. All concrete chart implementations
 * (line charts, bar charts, pie charts, etc.) extend this base class to inherit consistent
 * sizing behavior, responsive capabilities, and theming support.
 *
 * @remarks
 * The class applies behavior mixins in composition order: Dimensionable (innermost) → Fitable
 * → Variantable (outermost). Watch decorators are provided as protected methods for subclasses
 * to react to property changes without overriding core behavior logic.
 *
 * @name ChartBaseElement
 * @category Abstract Elements
 *
 * @fires connected {ConnectedEvent} - Emitted when the element is connected to the DOM
 * @fires disconnected {DisconnectedEvent} - Emitted when the element is disconnected from the DOM
 * @fires changed {PropertyChangedEvent} - Emitted when any attribute changes before update
 *
 * @example
 * Extending ChartBaseElement for a line chart:
 * ```typescript
 * export class LineChartElement extends ChartBaseElement {
 *   constructor() {
 *     super();
 *   }
 *
 *   protected override onHeaderPropertyChanged(oldValue?: string, newValue?: string): void {
 *     this.updateChartTitle(newValue);
 *   }
 * }
 * ```
 *
 * @example
 * Using chart headers:
 * ```html
 * <mosaik-line-chart
 *   header="Sales Performance"
 *   subHeader="Q4 2024"
 *   width="800px"
 *   height="400px">
 * </mosaik-line-chart>
 * ```
 *
 * @example
 * Responsive chart with fit mode:
 * ```html
 * <mosaik-bar-chart
 *   fit="fill"
 *   variant="primary"
 *   header="Revenue Comparison">
 * </mosaik-bar-chart>
 * ```
 *
 * @example
 * Reacting to dimension changes:
 * ```typescript
 * protected override onWidthPropertyChanged(oldValue?: CssLength, newValue?: CssLength): void {
 *   this.recalculateLayout();
 *   this.redrawChart();
 * }
 * ```
 *
 * @abstract
 * @public
 */
export declare abstract class ChartBaseElement extends ChartBaseElement_base implements IChartBaseElementProps {
    private _header;
    private _subHeader;
    /**
     * @protected
     */
    constructor();
    /**
        * Gets or sets the `header` property.
        *
        * @public
        */
    get header(): string;
    set header(value: string);
    /**
     * Gets or sets the `subHeader` property.
     *
     * @public
     */
    get subHeader(): string;
    set subHeader(value: string);
    /**
     * @protected
     */
    protected onVariantPropertyChanged(oldValue?: Variant, newValue?: Variant): void;
    /**
     * @protected
     */
    protected onFitPropertyChanged(oldValue?: Fit, newValue?: Fit): void;
    /**
     * @protected
     */
    protected onWidthPropertyChanged(oldValue?: CssLength, newValue?: CssLength): void;
    /**
     * @protected
     */
    protected onHeightPropertyChanged(oldValue?: CssLength, newValue?: CssLength): void;
    /**
     * @protected
     */
    protected onHeaderPropertyChanged(oldValue?: string, newValue?: string): void;
    /**
     * @protected
     */
    protected onSubHeaderPropertyChanged(oldValue?: string, newValue?: string): void;
}
export {};
//# sourceMappingURL=ChartBaseElement.d.ts.map