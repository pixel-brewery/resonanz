// #region Imports
export {};
//# sourceMappingURL=IChartBaseElementProps.js.map