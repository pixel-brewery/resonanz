import type { CssLength } from '@pixel-brewery/mosaik-themes';
import type { IDimensionableProps } from '../../../behaviors/Dimensionable';
import type { IFitableProps } from '../../../behaviors/Fitable';
import type { IVariantableProps } from '../../../behaviors/Variantable';
/**
 * Represents the `IChartElementProps` interface.
 *
 * @public
 */
export interface IChartBaseElementProps extends IVariantableProps, IFitableProps, IDimensionableProps {
    width: CssLength;
    height: CssLength;
    header: string;
    subHeader: string;
}
//# sourceMappingURL=IChartBaseElementProps.d.ts.map