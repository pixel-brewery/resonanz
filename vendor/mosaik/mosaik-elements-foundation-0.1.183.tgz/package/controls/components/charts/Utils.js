/**
 * Merges the `options` of a chart over its `defaults` and returns the result: an option that is set wins, an unset one
 * (`undefined`) keeps the default, nested objects merge key by key and an array replaces the default one. Neither
 * argument is changed.
 */
export function mergeOptions(defaults, options) {
    return mergeDeep(structuredClone(defaults), options);
}
/**
 * Performs a deep merge of `source` into `target`.
 * Mutates `target` only but not its objects and arrays. *
 */
function mergeDeep(target, source) {
    const isObject = (obj) => obj && typeof obj === 'object';
    if (!isObject(target) || !isObject(source)) {
        return source;
    }
    Object.keys(source).forEach((key) => {
        const targetValue = target[key];
        const sourceValue = source[key];
        if (sourceValue === undefined) {
            return;
        }
        if (Array.isArray(sourceValue)) {
            target[key] = sourceValue;
        }
        else if (isObject(targetValue) && isObject(sourceValue)) {
            target[key] = mergeDeep({ ...targetValue }, sourceValue);
        }
        else {
            target[key] = sourceValue;
        }
    });
    return target;
}
//# sourceMappingURL=Utils.js.map