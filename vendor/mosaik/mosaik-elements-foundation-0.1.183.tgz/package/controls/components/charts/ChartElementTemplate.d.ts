import { type TemplateResult } from '../../../dom/Html';
import type { ChartElement } from './ChartElement';
/**
 * The template of the `ChartElement`.
 *
 * @public
 */
export declare function chartElementTemplate<T extends ChartElement>(e: T): TemplateResult;
//# sourceMappingURL=ChartElementTemplate.d.ts.map