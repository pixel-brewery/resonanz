import type { ApexOptions } from 'apexcharts';
/**
 * Merges the `options` of a chart over its `defaults` and returns the result: an option that is set wins, an unset one
 * (`undefined`) keeps the default, nested objects merge key by key and an array replaces the default one. Neither
 * argument is changed.
 */
export declare function mergeOptions(defaults: ApexOptions, options: ApexOptions): ApexOptions;
//# sourceMappingURL=Utils.d.ts.map