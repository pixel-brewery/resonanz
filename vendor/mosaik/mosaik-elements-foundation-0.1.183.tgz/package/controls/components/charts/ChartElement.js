/* eslint-disable @typescript-eslint/no-unnecessary-condition */
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var ChartElement_1;
// #region Imports
import { HTMLElementEventEmitter } from '@pixel-brewery/mosaik-elements';
import { ThemeObserverServiceLocator } from '@pixel-brewery/mosaik-themes';
import { Themeable } from '../../../controls/behaviors/Themeable';
import { Emit } from '../../../events/decorators/EmitDecorator';
import { IntersectionController } from '../../controllers/IntersectionController';
import { addResizeController } from '../../controllers/ResizeController';
import { Attribute } from '../../decorators/AttributeDecorator';
import { Component } from '../../decorators/ComponentDecorator';
import { Property } from '../../decorators/PropertyDecorator';
import { ChartDisplayType } from '../../types/ChartDisplayType';
import { ChartLegendPosition } from '../../types/ChartLegendPosition';
import { ChartStackType } from '../../types/ChartStackType';
import { Fit } from '../../types/Fit';
import { ChartBaseElement } from './abstracts/ChartBaseElement';
import { chartElementTemplate } from './ChartElementTemplate';
import { ChartToolboxElement } from './ChartToolboxElement';
import { ChartExportCommand } from './commands/ChartExportCommand';
import { ChartModeCommand } from './commands/ChartModeCommand';
import { ChartResetCommand } from './commands/ChartResetCommand';
import { ChartZoomCommand } from './commands/ChartZoomCommand';
import { chartElementCosmopolitanStyle } from './themes/ChartElement.Cosmopolitan';
import { chartElementJoyStyle } from './themes/ChartElement.Joy';
import { chartElementMemphisStyle } from './themes/ChartElement.Memphis';
import { chartElementSohoStyle } from './themes/ChartElement.Soho';
import { mergeOptions } from './Utils';
// #endregion
/**
 * Chart - A comprehensive data visualization component powered by ApexCharts for creating interactive charts and graphs.
 *
 * @description
 * The Chart component enables rich data visualization through multiple chart types including bar, line, area, pie,
 * donut, and scatter plots. Built on ApexCharts library, it provides extensive customization options for colors,
 * animations, legends, and interactivity. Perfect for creating compelling data presentations, analytics dashboards,
 * and real-time monitoring interfaces with responsive design and flexible configuration.
 *
 * Sizing: explicit `width` and `height` take precedence without `fit`; an `auto` dimension follows the CSS drawing
 * box, or the chart engine's intrinsic size while no box can be measured. `fit="width"` fills its container and
 * keeps the height it is given (the `height` property, or a height style), `fit="height"` the other way round, and
 * `fit="both"` fills both. The `xAxis` / `yAxis` options keep their labels, line and tick settings (a label formatter
 * or style) - `isXAxisVisible` / `isYAxisVisible` only show or hide those parts. `var()` colours of gradient and
 * pattern fills are resolved in the chart's own scope (a local theme or mode), not on the document body.
 * ApexCharts initializes when the chart enters the viewport. Use `chartReady` before invoking chart commands.
 *
 * @name Chart
 * @element mosaik-chart
 * @category Charts
 *
 * @csspart chart - Main chart rendering container element
 * @csspart toolbox - The optional built-in Mosaik chart toolbox
 *
 * @cssprop {String} --chart-background-color - Background color for the chart rendering area
 * @cssprop {String} --chart-font-family - Font family for all chart text elements
 * @cssprop {String} --chart-font-letter-spacing - Letter spacing for chart text
 * @cssprop {String} --chart-font-line-height - Line height for chart text elements
 * @cssprop {String} --chart-font-size - Font size for chart labels and text
 * @cssprop {String} --chart-font-text-decoration - Text decoration style for chart labels
 * @cssprop {String} --chart-font-text-transform - Text transformation for chart labels
 * @cssprop {String} --chart-font-weight - Font weight for chart text
 * @cssprop {String} --chart-foreground-color - Primary color for text and line elements
 * @cssprop {String} --chart-gap - The gap CSS custom property.
 * @cssprop {String} --chart-padding-bottom - The padding bottom CSS custom property.
 * @cssprop {String} --chart-padding-left - The padding left CSS custom property.
 * @cssprop {String} --chart-padding-right - The padding right CSS custom property.
 * @cssprop {String} --chart-padding-top - The padding top CSS custom property.
 * @cssprop {String} --chart-shadow - The shadow CSS custom property.
 * @cssprop {String} --chart-shadow-blur - The shadow blur CSS custom property.
 * @cssprop {String} --chart-shadow-color - The shadow color CSS custom property.
 * @cssprop {String} --chart-shadow-offset-x - The shadow offset x CSS custom property.
 * @cssprop {String} --chart-shadow-offset-y - The shadow offset y CSS custom property.
 * @cssprop {String} --chart-shadow-spread - The shadow spread CSS custom property.
 * @cssprop {String} --chart-transition-duration - The transition duration CSS custom property.
 * @cssprop {String} --chart-transition-mode - The transition mode CSS custom property.
 * @cssprop {String} --chart-transition-property - The transition property CSS custom property.
 * @cssprop {String} --chart-translate - The translate CSS custom property.
 *
 * @fires chartReady {ChartReadyEvent} - Fired after the Apex chart is rendered and its commands are ready
 * @fires chartToolChanged {ChartToolChangedEvent} - Fired when the active pointer mode changes
 *
 * @dependency mosaik-chart-toolbox - The Chart Toolbox element.
 *
 * @remarks
 * Import this family from `@pixel-brewery/mosaik-elements-foundation/components/chart`
 * and install its optional `apexcharts` peer dependency.
 *
 * @example
 * Compare category totals in a sales dashboard:
 * ```html
 * <mosaik-chart display="bar" is-x-axis-visible is-y-axis-visible></mosaik-chart>
 * ```
 *
 * @example
 * Compare several time series with a legend below the plot:
 * ```html
 * <mosaik-chart
 *   display="line"
 *   is-legend-visible
 *   legend-position="bottom"
 * ></mosaik-chart>
 * ```
 *
 * @example
 * Show a category breakdown with a legend beside the plot:
 * ```html
 * <mosaik-chart
 *   display="pie"
 *   is-legend-visible
 *   legend-position="right"
 * ></mosaik-chart>
 * ```
 *
 * @example
 * Show how segments contribute to a changing total:
 * ```html
 * <mosaik-chart
 *   display="area"
 *   stacked
 *   is-x-axis-visible
 *   is-y-axis-visible
 * ></mosaik-chart>
 * ```
 *
 * @example
 * Fill a resizable analytics panel with a line chart:
 * ```html
 * <mosaik-chart
 *   display="line"
 *   fit="both"
 * ></mosaik-chart>
 * ```
 *
 * @example
 * Analytics chart with built-in export controls:
 * ```html
 * <mosaik-chart id="trend" display="line" show-toolbox></mosaik-chart>
 * ```
 *
 * @public
 */
let ChartElement = class ChartElement extends Themeable(ChartBaseElement) {
    static { ChartElement_1 = this; }
    // #region Fields
    static _pendingCharts = new Set();
    static _isRenderingChart = false;
    // Former axis attribute names remain supported by existing markup.
    static _LEGACY_AXIS_ATTRIBUTES = new Map([
        ['is-xaxis-visible', 'isXAxisVisible'],
        ['is-yaxis-visible', 'isYAxisVisible']
    ]);
    // Shaded cells follow the page's light/dark mode; other displays retain Apex's mode-free defaults.
    static _MODE_SHADED_DISPLAYS = new Set([
        ChartDisplayType.HeatMap,
        ChartDisplayType.TreeMap
    ]);
    // Keep Apex's palette1 series colours while allowing only the cell shading to follow the page mode.
    static _APEX_SERIES_COLORS = ['#008FFB', '#00A86F', '#CA8501', '#FF4560', '#846DD5'];
    _defaultOptions;
    _themeModeSubscription;
    _themeSubscription;
    _appliedThemeMode;
    _hasResolvedColors;
    _host;
    _updateFrame;
    _chartCreationId;
    _isCreatingChart;
    _hasEnteredViewport;
    _intersectionController;
    _commands;
    _chartReady;
    _chartToolChanged;
    _showToolbox;
    _toolboxTools;
    _activeTool;
    _display;
    _isLegendVisible;
    _legendPosition;
    _isXAxisVisible;
    _isYAxisVisible;
    _stacked;
    _stackType;
    _pendingUpdate;
    _pendingSeriesUpdate;
    // wrapper for apex
    _chart;
    _annotations;
    _colors;
    _dataLabels;
    _series;
    _stroke;
    _labels;
    _legend;
    _markers;
    _noData;
    _fill;
    _tooltip;
    _plotOptions;
    _responsive;
    _xAxis;
    _yAxis;
    _grid;
    _states;
    _theme;
    // #endregion
    // #region Ctor
    /**
     * @public
     */
    constructor() {
        super();
        this._host = null;
        this._updateFrame = null;
        this._chartCreationId = 0;
        this._isCreatingChart = false;
        this._hasEnteredViewport = false;
        this._intersectionController = new IntersectionController(this, {
            callback: (entries) => {
                this._hasEnteredViewport = entries.some((entry) => entry.target === this && entry.isIntersecting);
                if (this._hasEnteredViewport && this.hasUpdated) {
                    this.renderChart();
                }
            }
        });
        addResizeController(this, { skipInitial: true });
        this._commands = new Map([
            ['exportSVG', new ChartExportCommand('SVG')],
            ['exportPNG', new ChartExportCommand('PNG')],
            ['exportCSV', new ChartExportCommand('CSV')],
            ['zoom', new ChartModeCommand('zoom')],
            ['zoomIn', new ChartZoomCommand('in')],
            ['zoomOut', new ChartZoomCommand('out')],
            ['selection', new ChartModeCommand('selection')],
            ['pan', new ChartModeCommand('pan')],
            ['measure', new ChartModeCommand('measure')],
            ['reset', new ChartResetCommand()]
        ]);
        this._chartReady = new HTMLElementEventEmitter(this, 'chartReady');
        this._chartToolChanged = new HTMLElementEventEmitter(this, 'chartToolChanged');
        this._themeModeSubscription = null;
        this._themeSubscription = null;
        this._appliedThemeMode = null;
        this._hasResolvedColors = false;
        this._showToolbox = false;
        this._toolboxTools = null;
        this._activeTool = null;
        this._defaultOptions = {
            chart: {
                // Transparent, not empty: with a theme mode Apex paints an empty background white or dark grey.
                background: 'transparent',
                foreColor: '',
                fontFamily: '',
                // The component already owns the drawing box. Apex's extra parent minimum height would grow an
                // intrinsically sized host on each resize and feed that larger height into the next render.
                parentHeightOffset: 0,
                toolbar: {
                    show: false
                },
                zoom: {
                    enabled: false
                },
                animations: {
                    enabled: true,
                    speed: 800,
                    animateGradually: {
                        enabled: true,
                        delay: 150
                    },
                    dynamicAnimation: {
                        enabled: true,
                        speed: 350
                    }
                }
            },
            dataLabels: {
                enabled: false
            },
            grid: {
                xaxis: {
                    lines: {
                        show: false
                    }
                },
                yaxis: {
                    lines: {
                        show: false
                    }
                }
            },
            stroke: {
                curve: 'straight',
                lineCap: 'round'
            },
            subtitle: {
                align: 'left'
            },
            title: {
                align: 'left'
            },
            tooltip: {
                style: {
                    fontFamily: '',
                    fontSize: ''
                }
            }
        };
        this._display = ChartDisplayType.Line;
        this._isLegendVisible = false;
        this._legendPosition = ChartLegendPosition.Right;
        this._isXAxisVisible = false;
        this._isYAxisVisible = false;
        this._stacked = false;
        this._stackType = ChartStackType.Normal;
        this._pendingUpdate = false;
        this._pendingSeriesUpdate = false;
        this._chart = null;
        this._annotations = null;
        this._colors = null;
        this._dataLabels = null;
        this._series = null;
        this._stroke = null;
        this._labels = null;
        this._legend = null;
        this._markers = null;
        this._noData = null;
        this._fill = null;
        this._tooltip = null;
        this._plotOptions = null;
        this._responsive = null;
        this._xAxis = null;
        this._yAxis = null;
        this._grid = null;
        this._states = null;
        this._theme = null;
    }
    // #endregion
    // #region Properties
    /**
     * Returns the `is` property.
     * The `is` property represents natural name of this element.
     *
     * @public
     * @static
     * @readonly
     */
    static get is() {
        return 'mosaik-chart';
    }
    /**
     * Returns the observed attributes, including the former axis attribute names.
     *
     * @public
     * @static
     * @readonly
     * @hidden
     */
    static get observedAttributes() {
        return [...super.observedAttributes, ...ChartElement_1._LEGACY_AXIS_ATTRIBUTES.keys()];
    }
    /**
     * Gets or sets the `display` property.
     *
     * @public
     * @attr display
     */
    get display() {
        return this._display;
    }
    set display(value) {
        if (this._display !== value) {
            this._display = value;
            this.requestUpdate('display');
        }
    }
    /**
     * Gets or sets the `stacked` property.
     *
     * @public
     * @attr stacked
     */
    get stacked() {
        return this._stacked;
    }
    set stacked(value) {
        if (this._stacked !== value) {
            this._stacked = value;
            this.requestUpdate('stacked');
        }
    }
    /**
     * Gets or sets the `stackType` property.
     *
     * @public
     * @attr stack-type
     */
    get stackType() {
        return this._stackType;
    }
    set stackType(value) {
        if (this._stackType !== value) {
            this._stackType = value;
            this.requestUpdate('stackType');
        }
    }
    /**
     * Gets or sets the `isLegendVisible` property.
     *
     * @public
     * @attr is-legend-visible
     */
    get isLegendVisible() {
        return this._isLegendVisible;
    }
    set isLegendVisible(value) {
        if (this._isLegendVisible !== value) {
            this._isLegendVisible = value;
            this.requestUpdate('isLegendVisible');
        }
    }
    /**
     * Gets or sets the `legendPosition` property.
     *
     * @public
     * @attr legend-position
     */
    get legendPosition() {
        return this._legendPosition;
    }
    set legendPosition(value) {
        if (this._legendPosition !== value) {
            this._legendPosition = value;
            this.requestUpdate('legendPosition');
        }
    }
    /**
     * Gets or sets the `isXAxisVisible` property.
     *
     * @public
     * @attr is-x-axis-visible
     */
    get isXAxisVisible() {
        return this._isXAxisVisible;
    }
    set isXAxisVisible(value) {
        if (this._isXAxisVisible !== value) {
            this._isXAxisVisible = value;
            this.requestUpdate('isXAxisVisible');
        }
    }
    /**
     * Gets or sets the `isYAxisVisible` property.
     *
     * @public
     * @attr is-y-axis-visible
     */
    get isYAxisVisible() {
        return this._isYAxisVisible;
    }
    set isYAxisVisible(value) {
        if (this._isYAxisVisible !== value) {
            this._isYAxisVisible = value;
            this.requestUpdate('isYAxisVisible');
        }
    }
    /**
     * Gets or sets the `chart` property. Explicit toolbar and zoom settings take precedence over the disabled defaults.
     *
     * @public
     */
    get chart() {
        return this._chart;
    }
    set chart(value) {
        if (this._chart !== value) {
            this._chart = value;
            this.requestUpdate('chart');
        }
    }
    /**
     * Shows the Mosaik toolbox without enabling Apex's own toolbar.
     * The default is `false`.
     *
     * @public
     * @attr show-toolbox
     */
    get showToolbox() {
        return this._showToolbox;
    }
    set showToolbox(value) {
        if (this._showToolbox !== value) {
            this._showToolbox = value;
            this.requestUpdate('showToolbox');
        }
    }
    /**
     * Overrides which actions the embedded toolbox shows.
     * Use JavaScript property assignment for this object-valued property.
     * The default is `null`, which follows the Apex chart configuration.
     *
     * @public
     */
    get toolboxTools() {
        return this._toolboxTools;
    }
    set toolboxTools(value) {
        if (this._toolboxTools !== value) {
            this._toolboxTools = value;
            this.requestUpdate('toolboxTools');
        }
    }
    /**
     * Currently armed pointer interaction, if any.
     * @public
     * @readonly
     */
    get activeTool() {
        return this._activeTool;
    }
    /**
     * Fired after the chart has rendered and commands are available.
     *
     * @public
     * @eventProperty
     * @readonly
     */
    get chartReady() {
        return this._chartReady;
    }
    /**
     * Fired when the active pointer tool changes.
     *
     * @public
     * @eventProperty
     * @readonly
     */
    get chartToolChanged() {
        return this._chartToolChanged;
    }
    /**
     * Whether the rendered Apex instance is ready for commands.
     * @public
     * @readonly
     */
    get isReady() {
        return this.isChartReady();
    }
    /**
     * Whether an action is available for this chart and visible in its toolbox by default.
     *
     * @param tool - Action to inspect.
     * @returns Whether the toolbox should display the action.
     * @public
     */
    isToolVisible(tool) {
        if (this._toolboxTools?.[tool] !== undefined)
            return this._toolboxTools[tool] === true;
        const nativeTools = this._chart?.toolbar?.tools;
        const zoomEnabled = this._chart?.zoom?.enabled === true;
        switch (tool) {
            case 'exportSVG':
            case 'exportPNG':
            case 'exportCSV':
                return nativeTools?.download !== false;
            case 'zoom': return zoomEnabled && nativeTools?.zoom !== false;
            case 'zoomIn': return zoomEnabled && nativeTools?.zoomin !== false;
            case 'zoomOut': return zoomEnabled && nativeTools?.zoomout !== false;
            case 'pan': return zoomEnabled && nativeTools?.pan !== false;
            case 'reset': return zoomEnabled && nativeTools?.reset !== false;
            case 'selection': return this._chart?.selection?.enabled === true && nativeTools?.selection !== false;
            case 'measure': return this._chart?.measure?.enabled === true && nativeTools?.measure !== false;
        }
    }
    /**
     * Runs a chart action without requiring the built-in toolbox or Apex toolbar.
     *
     * @param name - Action to run.
     * @returns Whether the action ran on a rendered chart.
     * @public
     */
    command(name) {
        if (!this.isReady)
            return false;
        const command = this._commands.get(name);
        if (!command?.execute())
            return false;
        if (command instanceof ChartModeCommand) {
            this._activeTool = command.isActive() ? command.mode : null;
            this._chartToolChanged.emit({ activeTool: this._activeTool });
        }
        return true;
    }
    /**
     * Gets or sets the `annotations` property.
     *
     * @public
     */
    get annotations() {
        return this._annotations;
    }
    set annotations(value) {
        if (this._annotations !== value) {
            this._annotations = value;
            this.requestUpdate('annotations');
        }
    }
    /**
     * Gets or sets the `colors` property.
     *
     * @public
     */
    get colors() {
        return this._colors;
    }
    set colors(value) {
        if (this._colors !== value) {
            this._colors = value;
            this.requestUpdate('colors');
        }
    }
    /**
     * Gets or sets the `dataLabels` property.
     *
     * @public
     */
    get dataLabels() {
        return this._dataLabels;
    }
    set dataLabels(value) {
        if (this._dataLabels !== value) {
            this._dataLabels = value;
            this.requestUpdate('dataLabels');
        }
    }
    /**
     * Gets or sets the `series` property.
     *
     * @public
     */
    get series() {
        return this._series;
    }
    set series(value) {
        if (this._series !== value) {
            this._series = value;
            this.requestUpdate('series');
        }
    }
    /**
     * Gets or sets the `stroke` property.
     *
     * @public
     */
    get stroke() {
        return this._stroke;
    }
    set stroke(value) {
        if (this._stroke !== value) {
            this._stroke = value;
            this.requestUpdate('stroke');
        }
    }
    /**
     * Gets or sets the `labels` property.
     *
     * @public
     */
    get labels() {
        return this._labels;
    }
    set labels(value) {
        if (this._labels !== value) {
            this._labels = value;
            this.requestUpdate('labels');
        }
    }
    /**
     * Gets or sets the `legend` property.
     *
     * @public
     */
    get legend() {
        return this._legend;
    }
    set legend(value) {
        if (this._legend !== value) {
            this._legend = value;
            this.requestUpdate('legend');
        }
    }
    /**
     * Gets or sets the `markers` property.
     *
     * @public
     */
    get markers() {
        return this._markers;
    }
    set markers(value) {
        if (this._markers !== value) {
            this._markers = value;
            this.requestUpdate('markers');
        }
    }
    /**
     * Gets or sets the `noData` property.
     *
     * @public
     */
    get noData() {
        return this._noData;
    }
    set noData(value) {
        if (this._noData !== value) {
            this._noData = value;
            this.requestUpdate('noData');
        }
    }
    /**
     * Gets or sets the `fill` property.
     *
     * @public
     */
    get fill() {
        return this._fill;
    }
    set fill(value) {
        if (this._fill !== value) {
            this._fill = value;
            this.requestUpdate('fill');
        }
    }
    /**
     * Gets or sets the `tooltip` property.
     *
     * @public
     */
    get tooltip() {
        return this._tooltip;
    }
    set tooltip(value) {
        if (this._tooltip !== value) {
            this._tooltip = value;
            this.requestUpdate('tooltip');
        }
    }
    /**
     * Gets or sets the `plotOptions` property.
     *
     * @public
     */
    get plotOptions() {
        return this._plotOptions;
    }
    set plotOptions(value) {
        if (this._plotOptions !== value) {
            this._plotOptions = value;
            this.requestUpdate('plotOptions');
        }
    }
    /**
     * Gets or sets the `responsive` property.
     *
     * @public
     */
    get responsive() {
        return this._responsive;
    }
    set responsive(value) {
        if (this._responsive !== value) {
            this._responsive = value;
            this.requestUpdate('responsive');
        }
    }
    /**
     * Gets or sets the `xAxis` property.
     *
     * @public
     */
    get xAxis() {
        return this._xAxis;
    }
    set xAxis(value) {
        if (this._xAxis !== value) {
            this._xAxis = value;
            this.requestUpdate('xAxis');
        }
    }
    /**
     * Gets or sets the `yAxis` property.
     *
     * @public
     */
    get yAxis() {
        return this._yAxis;
    }
    set yAxis(value) {
        if (this._yAxis !== value) {
            this._yAxis = value;
            this.requestUpdate('yAxis');
        }
    }
    /**
     * Gets or sets the `grid` property.
     *
     * @public
     */
    get grid() {
        return this._grid;
    }
    set grid(value) {
        if (this._grid !== value) {
            this._grid = value;
            this.requestUpdate('grid');
        }
    }
    /**
     * Gets or sets the `states` property.
     *
     * @public
     */
    get states() {
        return this._states;
    }
    set states(value) {
        if (this._states !== value) {
            this._states = value;
            this.requestUpdate('states');
        }
    }
    /**
     * Gets or sets the `theme` property.
     *
     * @public
     */
    get theme() {
        return this._theme;
    }
    set theme(value) {
        if (this._theme !== value) {
            this._theme = value;
            this.requestUpdate('theme');
        }
    }
    // #endregion
    // #region Methods
    /**
     * Renders the chart again when the element returns to the document after it was removed.
     *
     * @public
     * @override
     */
    connectedCallback() {
        super.connectedCallback();
        // A shaded chart (heatmap, treemap) follows the colour mode of the page, and so do the gradient colours the
        // chart resolved from theme variables (`resolveFillColors`) - also after a theme switch.
        this._themeModeSubscription = ThemeObserverServiceLocator.current.themeModeChanged.subscribe(() => {
            if (ChartElement_1._MODE_SHADED_DISPLAYS.has(this._display) || this._appliedThemeMode !== null || this._hasResolvedColors) {
                this.requestUpdate();
            }
        });
        this._themeSubscription = ThemeObserverServiceLocator.current.themeChanged.subscribe(() => {
            if (this._hasResolvedColors) {
                this.requestUpdate();
            }
        });
        if (this.hasUpdated && this._host === null) {
            this._intersectionController.observe(this);
        }
    }
    /**
     * Applies the former axis attribute names (`is-xaxis-visible`, `is-yaxis-visible`) to the axis properties.
     *
     * @public
     * @override
     * @hidden
     */
    attributeChangedCallback(name, old, value) {
        const property = ChartElement_1._LEGACY_AXIS_ATTRIBUTES.get(name);
        if (property !== undefined) {
            this[property] = value !== null && value !== 'false';
            return;
        }
        super.attributeChangedCallback(name, old, value);
    }
    /**
     * Destroys the chart once the element stays removed from the document. The Apex chart registers window and
     * resize listeners that would otherwise keep the chart and this element alive.
     *
     * @public
     * @override
     */
    disconnectedCallback() {
        super.disconnectedCallback();
        this._hasEnteredViewport = false;
        ChartElement_1._pendingCharts.delete(this);
        this._themeModeSubscription?.dispose();
        this._themeModeSubscription = null;
        this._themeSubscription?.dispose();
        this._themeSubscription = null;
        // Moving the element disconnects and connects it in one go - only a chart that stays removed is destroyed.
        queueMicrotask(() => {
            if (!this.isConnected) {
                this.destroyChart();
            }
        });
    }
    /**
     * @protected
     * @overload
     */
    createRenderRoot() {
        // we do not want to create a shadow DOM for this element
        return this;
    }
    /**
     * @protected
     * @override
     */
    onApplyTemplate() {
        super.onApplyTemplate();
        this.renderChart();
    }
    /**
     * @protected
     * @override
     */
    update(changes) {
        super.update(changes);
        if (changes.has('chart')) {
            this.querySelector('mosaik-chart-toolbox')?.requestUpdate();
        }
        if (changes.size > 0 && [...changes.keys()].every((key) => key === 'toolboxTools')) {
            return;
        }
        // Guard: ApexCharts must be fully initialized before calling update methods
        if (!this.isChartReady()) {
            // Queue updates for later execution after render completes
            if (changes.has('series') && this._series) {
                this._pendingSeriesUpdate = true;
            }
            else {
                this._pendingUpdate = true;
            }
            return;
        }
        // Apex's updateSeries fast path retains the legend DOM when only names change. Updating the
        // complete options keeps labels and simultaneous option changes in sync with the replacement data.
        void this.updateComplete.then(() => {
            if (!this.isChartReady() || this._updateFrame !== null) {
                return;
            }
            // A host resize can arrive during ResizeObserver delivery. Finish that delivery before Apex writes
            // layout again, and coalesce pending properties into the same drawing frame.
            this._updateFrame = requestAnimationFrame(() => {
                this._updateFrame = null;
                if (this.isChartReady()) {
                    void this._host?.updateOptions(this.computedOptions(), false, true);
                }
            });
        });
    }
    /**
     * Starts one visible chart per frame. ApexCharts performs synchronous layout work during initialization,
     * so a group entering the viewport must not all initialize in the same observer delivery.
     *
     * @private
     */
    static renderNextChart() {
        if (ChartElement_1._isRenderingChart || ChartElement_1._pendingCharts.size === 0) {
            return;
        }
        ChartElement_1._isRenderingChart = true;
        requestAnimationFrame(() => {
            const [chart] = ChartElement_1._pendingCharts;
            if (!chart) {
                ChartElement_1._isRenderingChart = false;
                return;
            }
            ChartElement_1._pendingCharts.delete(chart);
            const element = chart.querySelector('[part="chart"]');
            if (!chart._hasEnteredViewport || !chart.isConnected || chart.hidden || chart._host !== null || !element) {
                ChartElement_1._isRenderingChart = false;
                ChartElement_1.renderNextChart();
                return;
            }
            chart._isCreatingChart = true;
            const chartCreationId = ++chart._chartCreationId;
            void chart.createChart(element, chartCreationId).finally(() => {
                chart._isCreatingChart = false;
                ChartElement_1._isRenderingChart = false;
                // A reconnect may have reported visibility while the cancelled generation was still loading.
                if (chartCreationId !== chart._chartCreationId) {
                    chart.renderChart();
                }
                ChartElement_1.renderNextChart();
            });
        });
    }
    /**
     * Queues the initial render once the chart is visible and its template is available.
     *
     * @private
     */
    renderChart() {
        if (!this._hasEnteredViewport || !this.isConnected || this._host !== null || this._isCreatingChart) {
            return;
        }
        ChartElement_1._pendingCharts.add(this);
        ChartElement_1.renderNextChart();
    }
    /**
     * Destroys the current chart with its listeners and cancels a chart that is still being created.
     *
     * @private
     */
    destroyChart() {
        ChartElement_1._pendingCharts.delete(this);
        this._chartCreationId++;
        if (this._updateFrame !== null) {
            cancelAnimationFrame(this._updateFrame);
            this._updateFrame = null;
        }
        this._host?.destroy();
        this._host = null;
        this._commands.forEach((command) => command.attach(null));
        this._activeTool = null;
    }
    /**
     * Loads ApexCharts on demand and renders the current chart instance.
     *
     * @private
     */
    async createChart(element, chartCreationId) {
        try {
            const { default: ApexChartsConstructor } = await import('apexcharts');
            if (this._chart?.measure?.enabled) {
                await import('apexcharts/features/measure');
            }
            await this.updateComplete;
            if (chartCreationId !== this._chartCreationId || !this.isConnected || this.hidden || !this._hasEnteredViewport) {
                return;
            }
            const options = this.computedOptions();
            // The initial options already contain every update queued before construction.
            this._pendingUpdate = false;
            this._pendingSeriesUpdate = false;
            const chart = new ApexChartsConstructor(element, options);
            this._host = chart;
            await chart.render();
            if (chartCreationId === this._chartCreationId && this._host === chart && this.isConnected) {
                // Later intersection reports would request needless Lit updates and full Apex option updates.
                this._intersectionController.unobserve(this);
                this._commands.forEach((command) => command.attach(chart));
                const initial = this._chart?.toolbar?.autoSelected;
                this._activeTool = initial === 'zoom' || initial === 'selection' || initial === 'pan' || initial === 'measure'
                    ? initial
                    : null;
                this.applyPendingUpdates();
                this._chartReady.emit();
            }
        }
        catch (error) {
            console.warn('[mosaik-chart] Initial render failed:', error);
        }
    }
    /**
     * Applies any pending updates that were queued before the chart was ready.
     *
     * @private
     */
    applyPendingUpdates() {
        if (!this.isChartReady()) {
            return;
        }
        if (this._pendingSeriesUpdate || this._pendingUpdate) {
            void this._host?.updateOptions(this.computedOptions(), false, true);
            this._pendingSeriesUpdate = false;
            this._pendingUpdate = false;
        }
    }
    /**
     * Checks whether the ApexCharts instance is fully initialized and ready for updates.
     *
     * @private
     * @returns `true` if the chart is ready, `false` otherwise.
     */
    isChartReady() {
        // ApexCharts stores internal state in `w.globals.dom` after render completes.
        // Calling updateOptions/updateSeries before this exists causes TypeErrors.
        const host = this._host;
        return host?.w?.globals?.dom != null;
    }
    /**
     * Returns the colour mode the chart hands to Apex, or `null` for none: a shaded chart (heatmap, treemap) takes the
     * mode of its area so its cells shade towards the page colour; another chart passes `light` once only, to undo the
     * dark mode a former shaded display left in Apex.
     *
     * @private
     */
    computedThemeMode() {
        const mode = ChartElement_1._MODE_SHADED_DISPLAYS.has(this._display)
            ? this.resolveThemeMode()
            : this._appliedThemeMode === 'dark' ? 'light' : null;
        this._appliedThemeMode = mode === 'light' && !ChartElement_1._MODE_SHADED_DISPLAYS.has(this._display)
            ? null
            : mode;
        return mode;
    }
    /**
     * Returns the colour mode of the chart's area: the `theme-mode` of the nearest ancestor that sets one (a
     * `mosaik-theme2` scope, across shadow roots), else of the document.
     *
     * @private
     */
    resolveThemeMode() {
        let element = this;
        while (element) {
            const mode = element.getAttribute('theme-mode');
            if (mode === 'dark' || mode === 'light') {
                return mode;
            }
            const root = element.getRootNode();
            element = element.parentElement ?? (root instanceof ShadowRoot ? root.host : null);
        }
        return 'light';
    }
    /**
     * @private
     */
    computedOptions() {
        const themeMode = this.computedThemeMode();
        let options = {
            annotations: this._annotations ?? undefined,
            chart: {
                ...this._chart ?? undefined,
                // `stacked` / `stackType` stack the series; a `chart.stacked` of the options stacks them as well.
                ...this._stacked
                    ? {
                        stacked: true,
                        stackType: this._stackType
                    }
                    : {},
                type: this._display ?? undefined,
                ...this.computedSize()
            },
            colors: themeMode === 'dark' && !this._colors?.length && !this._theme?.palette && !this._theme?.monochrome?.enabled
                ? [...ChartElement_1._APEX_SERIES_COLORS]
                : [...this._colors ?? []],
            dataLabels: {
                ...this._dataLabels ?? undefined
            },
            fill: this._fill ?? undefined,
            grid: {
                ...this._grid ?? undefined
            },
            labels: this._labels ?? undefined,
            legend: {
                ...this._legend ?? undefined,
                show: this._isLegendVisible ?? undefined,
                // A sparkline never shows a legend, but beside the plot (the default `right`) Apex still keeps 12 px
                // free below it; at the bottom it keeps none.
                position: this._chart?.sparkline?.enabled ? ChartLegendPosition.Bottom : this._legendPosition ?? undefined
            },
            markers: this._markers ?? undefined,
            noData: this._noData ?? undefined,
            plotOptions: this._plotOptions ?? undefined,
            responsive: this._responsive ?? undefined,
            // Never `undefined`: an explicit `series: undefined` replaces Apex's default `[]`, and `create()` then
            // fails on `series.forEach` for a chart without data (the empty chart previews of the Studio picker).
            series: this._series ?? [],
            states: this._states ?? undefined,
            stroke: this._stroke ?? undefined,
            theme: themeMode
                ? { mode: themeMode,
                    ...this._theme }
                : this._theme ?? undefined,
            tooltip: {
                ...this._tooltip ?? undefined
            },
            xaxis: this.computedXAxis(),
            yaxis: Array.isArray(this._yAxis)
                ? this._yAxis.map((axis) => this.computedYAxis(axis))
                : this.computedYAxis(this._yAxis ?? undefined)
        };
        // The options of the chart win over its defaults.
        options = mergeOptions(this._defaultOptions, options);
        // Without a header or sub header Apex reserves no title block (an empty text reserved one - 10 px above an
        // axis chart, 20 px above a sparkline). The key is handed over even when it is unset, so an update clears a
        // header the chart had before (Apex merges an update into its options).
        options.title = { ...options.title,
            text: this.header || undefined };
        options.subtitle = { ...options.subtitle,
            text: this.subHeader || undefined };
        this.resolveFillColors(options);
        // Keep Apex's visual toolbar disabled when the Mosaik toolbox owns the UI.
        options.chart = {
            ...options.chart,
            toolbar: {
                ...options.chart?.toolbar,
                ...this._chart?.toolbar,
                show: this._showToolbox ? false : this._chart?.toolbar?.show ?? false
            },
            zoom: {
                ...options.chart?.zoom,
                ...this._chart?.zoom
            }
        };
        // Remove unset top-level options before handing them to ApexCharts.
        Object.keys(options).forEach((key) => {
            if (options[key] === undefined) {
                delete options[key];
            }
        });
        return options;
    }
    /**
     * Resolves automatic and fitted dimensions in CSS layout pixels. Viewport rectangles include canvas zoom or
     * transforms and would scale the drawing twice. Explicit dimensions keep their existing engine semantics;
     * an unmeasurable automatic dimension lets the engine choose its intrinsic size.
     *
     * @private
     */
    computedSize() {
        const chart = this.querySelector('[part="chart"]');
        const style = getComputedStyle(this);
        const horizontalPadding = (parseFloat(style.paddingLeft) || 0) + (parseFloat(style.paddingRight) || 0);
        const verticalPadding = (parseFloat(style.paddingTop) || 0) + (parseFloat(style.paddingBottom) || 0);
        const toolboxHeight = this.querySelector('[part="toolbox"]')?.offsetHeight ?? 0;
        const gap = toolboxHeight > 0 ? parseFloat(style.rowGap) || 0 : 0;
        // Apex writes a minimum height to its own container. Read the component's layout box first so that
        // engine-owned minimum never becomes the next requested drawing height.
        const measuredWidth = Math.max(0, this.clientWidth - horizontalPadding) || chart?.clientWidth;
        const measuredHeight = Math.max(0, this.clientHeight - verticalPadding - toolboxHeight - gap) || chart?.clientHeight;
        const fitsWidth = this.fit === Fit.Width || this.fit === Fit.Both;
        const fitsHeight = this.fit === Fit.Height || this.fit === Fit.Both;
        const isAuto = (value) => value === undefined || value === null || value === '' || value === 'auto';
        const width = fitsWidth || isAuto(this.width) ? measuredWidth || undefined : this.width;
        const height = fitsHeight || isAuto(this.height) ? measuredHeight || undefined : this.height;
        return {
            width: width ?? undefined,
            height: height ?? undefined
        };
    }
    /**
     * Returns the options of the x axis. `isXAxisVisible` shows or hides its title, labels, line and ticks; their own
     * options (a label formatter or style, the line colour) stay, and a part the options hide stays hidden.
     *
     * @private
     */
    computedXAxis() {
        const axis = this._xAxis ?? undefined;
        const visible = this._isXAxisVisible;
        return {
            ...axis,
            title: {
                ...axis?.title,
                text: visible ? axis?.title?.text : undefined
            },
            labels: {
                ...axis?.labels,
                show: visible && (axis?.labels?.show ?? true)
            },
            axisBorder: {
                ...axis?.axisBorder,
                show: visible && (axis?.axisBorder?.show ?? true)
            },
            axisTicks: {
                ...axis?.axisTicks,
                show: visible && (axis?.axisTicks?.show ?? true)
            }
        };
    }
    /**
     * Returns the options of a y axis (one of several when `yAxis` is an array), like `computedXAxis` with
     * `isYAxisVisible`.
     *
     * @private
     */
    computedYAxis(axis) {
        const visible = this._isYAxisVisible;
        return {
            ...axis,
            title: {
                ...axis?.title,
                text: visible ? axis?.title?.text : undefined
            },
            labels: {
                ...axis?.labels,
                show: visible && (axis?.labels?.show ?? true)
            },
            axisBorder: {
                ...axis?.axisBorder,
                show: visible && (axis?.axisBorder?.show ?? true)
            },
            axisTicks: {
                ...axis?.axisTicks,
                show: visible && (axis?.axisTicks?.show ?? true)
            }
        };
    }
    /**
     * Resolves the series colours of gradient and pattern fills that are a bare `var()`. ApexCharts resolves those
     * itself against the document body, where the theme of a local scope (a `mosaik-theme2` with its own mode, a design
     * frame) does not apply; here they are resolved against the chart. Solid fills keep their `var()` colours - the
     * SVG resolves them in the chart's scope itself.
     *
     * @private
     */
    resolveFillColors(options) {
        this._hasResolvedColors = false;
        const fillTypes = [options.fill?.type].flat();
        if (!this.isConnected || !fillTypes.some((type) => type === 'gradient' || type === 'pattern')) {
            return;
        }
        const probe = document.createElement('span');
        probe.style.display = 'none';
        this.append(probe);
        const resolve = (value) => {
            if (typeof value !== 'string' || !value.trim().startsWith('var(')) {
                return value;
            }
            probe.style.color = '';
            probe.style.color = value;
            const color = probe.style.color ? getComputedStyle(probe).color : '';
            if (!color) {
                return value;
            }
            this._hasResolvedColors = true;
            return color;
        };
        try {
            if (Array.isArray(options.colors)) {
                options.colors = options.colors.map(resolve);
            }
            // Copies: the fill and the series are the objects the chart was given.
            if (options.fill) {
                const fill = { ...options.fill };
                if (Array.isArray(fill.colors)) {
                    fill.colors = fill.colors.map(resolve);
                }
                if (Array.isArray(fill.gradient?.gradientToColors)) {
                    fill.gradient = {
                        ...fill.gradient,
                        gradientToColors: fill.gradient.gradientToColors.map(resolve)
                    };
                }
                options.fill = fill;
            }
            if (Array.isArray(options.series)) {
                options.series = options.series.map((series) => {
                    if (series === null || typeof series !== 'object' || !('color' in series)) {
                        return series;
                    }
                    return {
                        ...series,
                        color: resolve(series.color)
                    };
                });
            }
        }
        finally {
            probe.remove();
        }
    }
};
__decorate([
    Attribute({ type: ChartDisplayType }),
    __metadata("design:type", String),
    __metadata("design:paramtypes", [String])
], ChartElement.prototype, "display", null);
__decorate([
    Attribute({
        type: Boolean,
        useDefault: true
    }),
    __metadata("design:type", Boolean),
    __metadata("design:paramtypes", [Boolean])
], ChartElement.prototype, "stacked", null);
__decorate([
    Attribute({ type: ChartStackType }),
    __metadata("design:type", String),
    __metadata("design:paramtypes", [String])
], ChartElement.prototype, "stackType", null);
__decorate([
    Attribute({
        type: Boolean,
        useDefault: true
    }),
    __metadata("design:type", Boolean),
    __metadata("design:paramtypes", [Boolean])
], ChartElement.prototype, "isLegendVisible", null);
__decorate([
    Attribute({ type: String }),
    __metadata("design:type", String),
    __metadata("design:paramtypes", [String])
], ChartElement.prototype, "legendPosition", null);
__decorate([
    Attribute({
        type: Boolean,
        useDefault: true,
        // Named explicitly: derived from the property name it would be `is-xaxis-visible`.
        attribute: 'is-x-axis-visible'
    }),
    __metadata("design:type", Boolean),
    __metadata("design:paramtypes", [Boolean])
], ChartElement.prototype, "isXAxisVisible", null);
__decorate([
    Attribute({
        type: Boolean,
        useDefault: true,
        // Named explicitly: derived from the property name it would be `is-yaxis-visible`.
        attribute: 'is-y-axis-visible'
    }),
    __metadata("design:type", Boolean),
    __metadata("design:paramtypes", [Boolean])
], ChartElement.prototype, "isYAxisVisible", null);
__decorate([
    Property({ type: Object }),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [Object])
], ChartElement.prototype, "chart", null);
__decorate([
    Attribute({
        type: Boolean,
        useDefault: true
    }),
    __metadata("design:type", Boolean),
    __metadata("design:paramtypes", [Boolean])
], ChartElement.prototype, "showToolbox", null);
__decorate([
    Property({ type: Object }),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [Object])
], ChartElement.prototype, "toolboxTools", null);
__decorate([
    Emit({ eventName: 'chartReady' }),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], ChartElement.prototype, "chartReady", null);
__decorate([
    Emit({ eventName: 'chartToolChanged' }),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], ChartElement.prototype, "chartToolChanged", null);
__decorate([
    Property({ type: Object }),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [Object])
], ChartElement.prototype, "annotations", null);
__decorate([
    Property({ type: Array }),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [Object])
], ChartElement.prototype, "colors", null);
__decorate([
    Property({ type: Object }),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [Object])
], ChartElement.prototype, "dataLabels", null);
__decorate([
    Property({ type: Array }),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [Object])
], ChartElement.prototype, "series", null);
__decorate([
    Property({ type: Object }),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [Object])
], ChartElement.prototype, "stroke", null);
__decorate([
    Property({ type: Array }),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [Object])
], ChartElement.prototype, "labels", null);
__decorate([
    Property({ type: Object }),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [Object])
], ChartElement.prototype, "legend", null);
__decorate([
    Property({ type: Object }),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [Object])
], ChartElement.prototype, "markers", null);
__decorate([
    Property({ type: Object }),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [Object])
], ChartElement.prototype, "noData", null);
__decorate([
    Property({ type: Object }),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [Object])
], ChartElement.prototype, "fill", null);
__decorate([
    Property({ type: Object }),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [Object])
], ChartElement.prototype, "tooltip", null);
__decorate([
    Property({ type: Object }),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [Object])
], ChartElement.prototype, "plotOptions", null);
__decorate([
    Property({ type: Array }),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [Object])
], ChartElement.prototype, "responsive", null);
__decorate([
    Property({ type: Object }),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [Object])
], ChartElement.prototype, "xAxis", null);
__decorate([
    Property({ type: Array }),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [Object])
], ChartElement.prototype, "yAxis", null);
__decorate([
    Property({ type: Object }),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [Object])
], ChartElement.prototype, "grid", null);
__decorate([
    Property({ type: Object }),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [Object])
], ChartElement.prototype, "states", null);
__decorate([
    Property({ type: Object }),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [Object])
], ChartElement.prototype, "theme", null);
ChartElement = ChartElement_1 = __decorate([
    Component({
        selector: 'mosaik-chart',
        template: chartElementTemplate,
        themes: {
            joy: chartElementJoyStyle,
            memphis: chartElementMemphisStyle,
            cosmopolitan: chartElementCosmopolitanStyle,
            soho: chartElementSohoStyle
        },
        options: {
            mode: 'open',
            delegatesFocus: true,
            styleAdoption: 'inline'
        },
        imports: [ChartToolboxElement]
    }),
    __metadata("design:paramtypes", [])
], ChartElement);
export { ChartElement };
//# sourceMappingURL=ChartElement.js.map