// #region Imports
export {};
//# sourceMappingURL=IChartElementProps.js.map