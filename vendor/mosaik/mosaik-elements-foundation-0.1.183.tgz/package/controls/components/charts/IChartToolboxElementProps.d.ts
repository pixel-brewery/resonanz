import type { ChartElement } from './ChartElement';
import type { ChartToolVisibility } from './ChartToolVisibility';
import type { ChartElementIntl } from './intl/ChartElementIntl';
/** Public properties of the independently placeable chart toolbox. @public */
export interface IChartToolboxElementProps {
    chart: ChartElement | null;
    tools: ChartToolVisibility | null;
    intl: ChartElementIntl;
}
//# sourceMappingURL=IChartToolboxElementProps.d.ts.map