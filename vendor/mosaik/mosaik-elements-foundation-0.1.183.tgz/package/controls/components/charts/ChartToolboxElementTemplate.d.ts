import { type TemplateResult } from '../../../dom/Html';
import type { ChartToolboxElement } from './ChartToolboxElement';
/**
 * Renders the chart toolbox controls.
 *
 * @public
 */
export declare function chartToolboxElementTemplate<T extends ChartToolboxElement>(e: T): TemplateResult;
//# sourceMappingURL=ChartToolboxElementTemplate.d.ts.map