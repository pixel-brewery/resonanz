// #region Imports
import { ChartCommand } from './ChartCommand';
// #endregion
/** Restores the original chart viewport. @internal */
export class ChartResetCommand extends ChartCommand {
    // #region Methods
    execute() {
        if (!this._host)
            return false;
        this._host.resetSeries(true, true);
        return true;
    }
}
//# sourceMappingURL=ChartResetCommand.js.map