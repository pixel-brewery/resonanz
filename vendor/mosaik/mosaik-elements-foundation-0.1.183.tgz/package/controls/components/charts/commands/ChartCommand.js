// #region Imports
// #endregion
/** A chart action independent of the control that invokes it. @internal */
export class ChartCommand {
    // #region Fields
    _host = null;
    // #endregion
    // #region Methods
    /** Attaches the current Apex chart instance. @internal */
    attach(host) {
        this._host = host;
    }
}
//# sourceMappingURL=ChartCommand.js.map