// #region Imports
import { ChartCommand } from './ChartCommand';
// #endregion
/** Exports the rendered chart using Apex's export API. @internal */
export class ChartExportCommand extends ChartCommand {
    // #region Fields
    _format;
    // #endregion
    // #region Ctor
    constructor(format) {
        super();
        this._format = format;
    }
    // #endregion
    // #region Methods
    execute() {
        const host = this._host;
        if (!host)
            return false;
        switch (this._format) {
            case 'SVG':
                this.exportImage(() => host.exports.exportToSVG());
                break;
            case 'PNG':
                this.exportImage(() => host.exports.exportToPng());
                break;
            case 'CSV':
                host.exportToCSV();
                break;
        }
        return true;
    }
    /** Keeps inherited theme variables available in Apex's standalone SVG snapshot. */
    exportImage(exportAction) {
        const wrap = this._host?.w?.dom?.elWrap;
        const view = wrap?.ownerDocument.defaultView;
        if (!wrap || !view) {
            exportAction();
            return;
        }
        const variables = new Set(Array.from(wrap.outerHTML.matchAll(/var\(\s*(--[\w-]+)/g), (match) => match[1]));
        if (variables.size === 0) {
            exportAction();
            return;
        }
        const computed = view.getComputedStyle(wrap);
        const values = Array.from(variables, (variable) => [variable, computed.getPropertyValue(variable).trim()])
            .filter(([, value]) => value !== '');
        if (values.length === 0) {
            exportAction();
            return;
        }
        const originalStyle = wrap.getAttribute('style');
        try {
            for (const [variable, value] of values)
                wrap.style.setProperty(variable, value);
            // Apex clones elWrap synchronously before rasterizing the image asynchronously.
            exportAction();
        }
        finally {
            if (originalStyle === null)
                wrap.removeAttribute('style');
            else
                wrap.setAttribute('style', originalStyle);
        }
    }
}
//# sourceMappingURL=ChartExportCommand.js.map