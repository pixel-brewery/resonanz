// #region Imports
import { ChartCommand } from './ChartCommand';
/** Changes Apex pointer mode. Apex does not yet expose a public mode setter. @internal */
export class ChartModeCommand extends ChartCommand {
    // #region Fields
    _mode;
    // #endregion
    // #region Ctor
    constructor(mode) {
        super();
        this._mode = mode;
    }
    // #endregion
    // #region Methods
    execute() {
        if (!this._host)
            return false;
        const state = this._host.w?.interact;
        if (!state)
            return false;
        const key = `${this._mode}Enabled`;
        const enable = !state[key];
        if (state.measureEnabled)
            this._host.stopMeasure();
        state.zoomEnabled = false;
        state.selectionEnabled = false;
        state.panEnabled = false;
        state.measureEnabled = false;
        if (enable) {
            state[key] = true;
            if (this._mode === 'measure')
                this._host.startMeasure();
        }
        return true;
    }
    /** Reports the pointer mode after the last action. @internal */
    isActive() {
        const state = this._host?.w?.interact;
        return state?.[`${this._mode}Enabled`] ?? false;
    }
    // #endregion
    // #region Properties
    /** The pointer mode controlled by this command. @internal */
    get mode() {
        return this._mode;
    }
}
//# sourceMappingURL=ChartModeCommand.js.map