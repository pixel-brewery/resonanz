// #region Imports
import { ChartCommand } from './ChartCommand';
// #endregion
/** Zooms the current horizontal viewport using Apex's public chart API. @internal */
export class ChartZoomCommand extends ChartCommand {
    // #region Fields
    _direction;
    // #endregion
    // #region Ctor
    constructor(direction) {
        super();
        this._direction = direction;
    }
    // #endregion
    // #region Methods
    execute() {
        if (!this._host)
            return false;
        const { minX, maxX } = this._host.getState();
        const range = maxX - minX;
        if (!Number.isFinite(range) || range <= 0)
            return false;
        const center = (minX + maxX) / 2;
        const halfRange = range * (this._direction === 'in' ? 0.25 : 1);
        this._host.zoomX(center - halfRange, center + halfRange);
        return true;
    }
}
//# sourceMappingURL=ChartZoomCommand.js.map