import { type IEventEmitter } from '@pixel-brewery/mosaik-elements';
import type ApexCharts from 'apexcharts';
import type { IChartToolChangedEventDetail } from '../../events/ChartEvents';
import { ChartDisplayType } from '../../types/ChartDisplayType';
import { ChartLegendPosition } from '../../types/ChartLegendPosition';
import { ChartStackType } from '../../types/ChartStackType';
import { ChartBaseElement } from './abstracts/ChartBaseElement';
import type { ChartTool } from './ChartTool';
import type { ChartToolVisibility } from './ChartToolVisibility';
import type { IChartElementProps } from './IChartElementProps';
declare const ChartElement_base: (abstract new (...args: Array<any>) => import("../../../controls/behaviors/Themeable").IThemeableProps) & typeof ChartBaseElement & import("../../../controls/behaviors/Themeable").IThemeableCtor;
/**
 * Chart - A comprehensive data visualization component powered by ApexCharts for creating interactive charts and graphs.
 *
 * @description
 * The Chart component enables rich data visualization through multiple chart types including bar, line, area, pie,
 * donut, and scatter plots. Built on ApexCharts library, it provides extensive customization options for colors,
 * animations, legends, and interactivity. Perfect for creating compelling data presentations, analytics dashboards,
 * and real-time monitoring interfaces with responsive design and flexible configuration.
 *
 * Sizing: explicit `width` and `height` take precedence without `fit`; an `auto` dimension follows the CSS drawing
 * box, or the chart engine's intrinsic size while no box can be measured. `fit="width"` fills its container and
 * keeps the height it is given (the `height` property, or a height style), `fit="height"` the other way round, and
 * `fit="both"` fills both. The `xAxis` / `yAxis` options keep their labels, line and tick settings (a label formatter
 * or style) - `isXAxisVisible` / `isYAxisVisible` only show or hide those parts. `var()` colours of gradient and
 * pattern fills are resolved in the chart's own scope (a local theme or mode), not on the document body.
 * ApexCharts initializes when the chart enters the viewport. Use `chartReady` before invoking chart commands.
 *
 * @name Chart
 * @element mosaik-chart
 * @category Charts
 *
 * @csspart chart - Main chart rendering container element
 * @csspart toolbox - The optional built-in Mosaik chart toolbox
 *
 * @cssprop {String} --chart-background-color - Background color for the chart rendering area
 * @cssprop {String} --chart-font-family - Font family for all chart text elements
 * @cssprop {String} --chart-font-letter-spacing - Letter spacing for chart text
 * @cssprop {String} --chart-font-line-height - Line height for chart text elements
 * @cssprop {String} --chart-font-size - Font size for chart labels and text
 * @cssprop {String} --chart-font-text-decoration - Text decoration style for chart labels
 * @cssprop {String} --chart-font-text-transform - Text transformation for chart labels
 * @cssprop {String} --chart-font-weight - Font weight for chart text
 * @cssprop {String} --chart-foreground-color - Primary color for text and line elements
 * @cssprop {String} --chart-gap - The gap CSS custom property.
 * @cssprop {String} --chart-padding-bottom - The padding bottom CSS custom property.
 * @cssprop {String} --chart-padding-left - The padding left CSS custom property.
 * @cssprop {String} --chart-padding-right - The padding right CSS custom property.
 * @cssprop {String} --chart-padding-top - The padding top CSS custom property.
 * @cssprop {String} --chart-shadow - The shadow CSS custom property.
 * @cssprop {String} --chart-shadow-blur - The shadow blur CSS custom property.
 * @cssprop {String} --chart-shadow-color - The shadow color CSS custom property.
 * @cssprop {String} --chart-shadow-offset-x - The shadow offset x CSS custom property.
 * @cssprop {String} --chart-shadow-offset-y - The shadow offset y CSS custom property.
 * @cssprop {String} --chart-shadow-spread - The shadow spread CSS custom property.
 * @cssprop {String} --chart-transition-duration - The transition duration CSS custom property.
 * @cssprop {String} --chart-transition-mode - The transition mode CSS custom property.
 * @cssprop {String} --chart-transition-property - The transition property CSS custom property.
 * @cssprop {String} --chart-translate - The translate CSS custom property.
 *
 * @fires chartReady {ChartReadyEvent} - Fired after the Apex chart is rendered and its commands are ready
 * @fires chartToolChanged {ChartToolChangedEvent} - Fired when the active pointer mode changes
 *
 * @dependency mosaik-chart-toolbox - The Chart Toolbox element.
 *
 * @remarks
 * Import this family from `@pixel-brewery/mosaik-elements-foundation/components/chart`
 * and install its optional `apexcharts` peer dependency.
 *
 * @example
 * Compare category totals in a sales dashboard:
 * ```html
 * <mosaik-chart display="bar" is-x-axis-visible is-y-axis-visible></mosaik-chart>
 * ```
 *
 * @example
 * Compare several time series with a legend below the plot:
 * ```html
 * <mosaik-chart
 *   display="line"
 *   is-legend-visible
 *   legend-position="bottom"
 * ></mosaik-chart>
 * ```
 *
 * @example
 * Show a category breakdown with a legend beside the plot:
 * ```html
 * <mosaik-chart
 *   display="pie"
 *   is-legend-visible
 *   legend-position="right"
 * ></mosaik-chart>
 * ```
 *
 * @example
 * Show how segments contribute to a changing total:
 * ```html
 * <mosaik-chart
 *   display="area"
 *   stacked
 *   is-x-axis-visible
 *   is-y-axis-visible
 * ></mosaik-chart>
 * ```
 *
 * @example
 * Fill a resizable analytics panel with a line chart:
 * ```html
 * <mosaik-chart
 *   display="line"
 *   fit="both"
 * ></mosaik-chart>
 * ```
 *
 * @example
 * Analytics chart with built-in export controls:
 * ```html
 * <mosaik-chart id="trend" display="line" show-toolbox></mosaik-chart>
 * ```
 *
 * @public
 */
export declare class ChartElement extends ChartElement_base implements IChartElementProps {
    private static readonly _pendingCharts;
    private static _isRenderingChart;
    private static readonly _LEGACY_AXIS_ATTRIBUTES;
    private static readonly _MODE_SHADED_DISPLAYS;
    private static readonly _APEX_SERIES_COLORS;
    private readonly _defaultOptions;
    private _themeModeSubscription;
    private _themeSubscription;
    private _appliedThemeMode;
    private _hasResolvedColors;
    private _host;
    private _updateFrame;
    private _chartCreationId;
    private _isCreatingChart;
    private _hasEnteredViewport;
    private readonly _intersectionController;
    private readonly _commands;
    private readonly _chartReady;
    private readonly _chartToolChanged;
    private _showToolbox;
    private _toolboxTools;
    private _activeTool;
    private _display;
    private _isLegendVisible;
    private _legendPosition;
    private _isXAxisVisible;
    private _isYAxisVisible;
    private _stacked;
    private _stackType;
    private _pendingUpdate;
    private _pendingSeriesUpdate;
    private _chart;
    private _annotations;
    private _colors;
    private _dataLabels;
    private _series;
    private _stroke;
    private _labels;
    private _legend;
    private _markers;
    private _noData;
    private _fill;
    private _tooltip;
    private _plotOptions;
    private _responsive;
    private _xAxis;
    private _yAxis;
    private _grid;
    private _states;
    private _theme;
    /**
     * @public
     */
    constructor();
    /**
     * Returns the `is` property.
     * The `is` property represents natural name of this element.
     *
     * @public
     * @static
     * @readonly
     */
    static get is(): string;
    /**
     * Returns the observed attributes, including the former axis attribute names.
     *
     * @public
     * @static
     * @readonly
     * @hidden
     */
    static get observedAttributes(): Array<string>;
    /**
     * Gets or sets the `display` property.
     *
     * @public
     * @attr display
     */
    get display(): ChartDisplayType;
    set display(value: ChartDisplayType);
    /**
     * Gets or sets the `stacked` property.
     *
     * @public
     * @attr stacked
     */
    get stacked(): boolean;
    set stacked(value: boolean);
    /**
     * Gets or sets the `stackType` property.
     *
     * @public
     * @attr stack-type
     */
    get stackType(): ChartStackType;
    set stackType(value: ChartStackType);
    /**
     * Gets or sets the `isLegendVisible` property.
     *
     * @public
     * @attr is-legend-visible
     */
    get isLegendVisible(): boolean;
    set isLegendVisible(value: boolean);
    /**
     * Gets or sets the `legendPosition` property.
     *
     * @public
     * @attr legend-position
     */
    get legendPosition(): ChartLegendPosition;
    set legendPosition(value: ChartLegendPosition);
    /**
     * Gets or sets the `isXAxisVisible` property.
     *
     * @public
     * @attr is-x-axis-visible
     */
    get isXAxisVisible(): boolean;
    set isXAxisVisible(value: boolean);
    /**
     * Gets or sets the `isYAxisVisible` property.
     *
     * @public
     * @attr is-y-axis-visible
     */
    get isYAxisVisible(): boolean;
    set isYAxisVisible(value: boolean);
    /**
     * Gets or sets the `chart` property. Explicit toolbar and zoom settings take precedence over the disabled defaults.
     *
     * @public
     */
    get chart(): ApexCharts.ApexOptions['chart'] | null;
    set chart(value: ApexCharts.ApexOptions['chart'] | null);
    /**
     * Shows the Mosaik toolbox without enabling Apex's own toolbar.
     * The default is `false`.
     *
     * @public
     * @attr show-toolbox
     */
    get showToolbox(): boolean;
    set showToolbox(value: boolean);
    /**
     * Overrides which actions the embedded toolbox shows.
     * Use JavaScript property assignment for this object-valued property.
     * The default is `null`, which follows the Apex chart configuration.
     *
     * @public
     */
    get toolboxTools(): ChartToolVisibility | null;
    set toolboxTools(value: ChartToolVisibility | null);
    /**
     * Currently armed pointer interaction, if any.
     * @public
     * @readonly
     */
    get activeTool(): Extract<ChartTool, 'zoom' | 'selection' | 'pan' | 'measure'> | null;
    /**
     * Fired after the chart has rendered and commands are available.
     *
     * @public
     * @eventProperty
     * @readonly
     */
    get chartReady(): IEventEmitter;
    /**
     * Fired when the active pointer tool changes.
     *
     * @public
     * @eventProperty
     * @readonly
     */
    get chartToolChanged(): IEventEmitter<IChartToolChangedEventDetail>;
    /**
     * Whether the rendered Apex instance is ready for commands.
     * @public
     * @readonly
     */
    get isReady(): boolean;
    /**
     * Whether an action is available for this chart and visible in its toolbox by default.
     *
     * @param tool - Action to inspect.
     * @returns Whether the toolbox should display the action.
     * @public
     */
    isToolVisible(tool: ChartTool): boolean;
    /**
     * Runs a chart action without requiring the built-in toolbox or Apex toolbar.
     *
     * @param name - Action to run.
     * @returns Whether the action ran on a rendered chart.
     * @public
     */
    command(name: ChartTool): boolean;
    /**
     * Gets or sets the `annotations` property.
     *
     * @public
     */
    get annotations(): ApexCharts.ApexOptions['annotations'] | null;
    set annotations(value: ApexCharts.ApexOptions['annotations'] | null);
    /**
     * Gets or sets the `colors` property.
     *
     * @public
     */
    get colors(): ApexCharts.ApexOptions['colors'] | null;
    set colors(value: ApexCharts.ApexOptions['colors'] | null);
    /**
     * Gets or sets the `dataLabels` property.
     *
     * @public
     */
    get dataLabels(): ApexCharts.ApexOptions['dataLabels'] | null;
    set dataLabels(value: ApexCharts.ApexOptions['dataLabels'] | null);
    /**
     * Gets or sets the `series` property.
     *
     * @public
     */
    get series(): ApexCharts.ApexOptions['series'] | null;
    set series(value: ApexCharts.ApexOptions['series'] | null);
    /**
     * Gets or sets the `stroke` property.
     *
     * @public
     */
    get stroke(): ApexCharts.ApexOptions['stroke'] | null;
    set stroke(value: ApexCharts.ApexOptions['stroke'] | null);
    /**
     * Gets or sets the `labels` property.
     *
     * @public
     */
    get labels(): ApexCharts.ApexOptions['labels'] | null;
    set labels(value: ApexCharts.ApexOptions['labels'] | null);
    /**
     * Gets or sets the `legend` property.
     *
     * @public
     */
    get legend(): ApexCharts.ApexOptions['legend'] | null;
    set legend(value: ApexCharts.ApexOptions['legend'] | null);
    /**
     * Gets or sets the `markers` property.
     *
     * @public
     */
    get markers(): ApexCharts.ApexOptions['markers'] | null;
    set markers(value: ApexCharts.ApexOptions['markers'] | null);
    /**
     * Gets or sets the `noData` property.
     *
     * @public
     */
    get noData(): ApexCharts.ApexOptions['noData'] | null;
    set noData(value: ApexCharts.ApexOptions['noData'] | null);
    /**
     * Gets or sets the `fill` property.
     *
     * @public
     */
    get fill(): ApexCharts.ApexOptions['fill'] | null;
    set fill(value: ApexCharts.ApexOptions['fill'] | null);
    /**
     * Gets or sets the `tooltip` property.
     *
     * @public
     */
    get tooltip(): ApexCharts.ApexOptions['tooltip'] | null;
    set tooltip(value: ApexCharts.ApexOptions['tooltip'] | null);
    /**
     * Gets or sets the `plotOptions` property.
     *
     * @public
     */
    get plotOptions(): ApexCharts.ApexOptions['plotOptions'] | null;
    set plotOptions(value: ApexCharts.ApexOptions['plotOptions'] | null);
    /**
     * Gets or sets the `responsive` property.
     *
     * @public
     */
    get responsive(): ApexCharts.ApexOptions['responsive'] | null;
    set responsive(value: ApexCharts.ApexOptions['responsive'] | null);
    /**
     * Gets or sets the `xAxis` property.
     *
     * @public
     */
    get xAxis(): ApexCharts.ApexOptions['xaxis'] | null;
    set xAxis(value: ApexCharts.ApexOptions['xaxis'] | null);
    /**
     * Gets or sets the `yAxis` property.
     *
     * @public
     */
    get yAxis(): ApexCharts.ApexOptions['yaxis'] | null;
    set yAxis(value: ApexCharts.ApexOptions['yaxis'] | null);
    /**
     * Gets or sets the `grid` property.
     *
     * @public
     */
    get grid(): ApexCharts.ApexOptions['grid'] | null;
    set grid(value: ApexCharts.ApexOptions['grid'] | null);
    /**
     * Gets or sets the `states` property.
     *
     * @public
     */
    get states(): ApexCharts.ApexOptions['states'] | null;
    set states(value: ApexCharts.ApexOptions['states'] | null);
    /**
     * Gets or sets the `theme` property.
     *
     * @public
     */
    get theme(): ApexCharts.ApexOptions['theme'] | null;
    set theme(value: ApexCharts.ApexOptions['theme'] | null);
    /**
     * Renders the chart again when the element returns to the document after it was removed.
     *
     * @public
     * @override
     */
    connectedCallback(): void;
    /**
     * Applies the former axis attribute names (`is-xaxis-visible`, `is-yaxis-visible`) to the axis properties.
     *
     * @public
     * @override
     * @hidden
     */
    attributeChangedCallback(name: string, old: string | null, value: string | null): void;
    /**
     * Destroys the chart once the element stays removed from the document. The Apex chart registers window and
     * resize listeners that would otherwise keep the chart and this element alive.
     *
     * @public
     * @override
     */
    disconnectedCallback(): void;
    /**
     * @protected
     * @overload
     */
    protected createRenderRoot(): HTMLElement;
    /**
     * @protected
     * @override
     */
    protected onApplyTemplate(): void;
    /**
     * @protected
     * @override
     */
    protected update(changes: Map<keyof this, unknown>): void;
    /**
     * Starts one visible chart per frame. ApexCharts performs synchronous layout work during initialization,
     * so a group entering the viewport must not all initialize in the same observer delivery.
     *
     * @private
     */
    private static renderNextChart;
    /**
     * Queues the initial render once the chart is visible and its template is available.
     *
     * @private
     */
    private renderChart;
    /**
     * Destroys the current chart with its listeners and cancels a chart that is still being created.
     *
     * @private
     */
    private destroyChart;
    /**
     * Loads ApexCharts on demand and renders the current chart instance.
     *
     * @private
     */
    private createChart;
    /**
     * Applies any pending updates that were queued before the chart was ready.
     *
     * @private
     */
    private applyPendingUpdates;
    /**
     * Checks whether the ApexCharts instance is fully initialized and ready for updates.
     *
     * @private
     * @returns `true` if the chart is ready, `false` otherwise.
     */
    private isChartReady;
    /**
     * Returns the colour mode the chart hands to Apex, or `null` for none: a shaded chart (heatmap, treemap) takes the
     * mode of its area so its cells shade towards the page colour; another chart passes `light` once only, to undo the
     * dark mode a former shaded display left in Apex.
     *
     * @private
     */
    private computedThemeMode;
    /**
     * Returns the colour mode of the chart's area: the `theme-mode` of the nearest ancestor that sets one (a
     * `mosaik-theme2` scope, across shadow roots), else of the document.
     *
     * @private
     */
    private resolveThemeMode;
    /**
     * @private
     */
    private computedOptions;
    /**
     * Resolves automatic and fitted dimensions in CSS layout pixels. Viewport rectangles include canvas zoom or
     * transforms and would scale the drawing twice. Explicit dimensions keep their existing engine semantics;
     * an unmeasurable automatic dimension lets the engine choose its intrinsic size.
     *
     * @private
     */
    private computedSize;
    /**
     * Returns the options of the x axis. `isXAxisVisible` shows or hides its title, labels, line and ticks; their own
     * options (a label formatter or style, the line colour) stay, and a part the options hide stays hidden.
     *
     * @private
     */
    private computedXAxis;
    /**
     * Returns the options of a y axis (one of several when `yAxis` is an array), like `computedXAxis` with
     * `isYAxisVisible`.
     *
     * @private
     */
    private computedYAxis;
    /**
     * Resolves the series colours of gradient and pattern fills that are a bare `var()`. ApexCharts resolves those
     * itself against the document body, where the theme of a local scope (a `mosaik-theme2` with its own mode, a design
     * frame) does not apply; here they are resolved against the chart. Solid fills keep their `var()` colours - the
     * SVG resolves them in the chart's scope itself.
     *
     * @private
     */
    private resolveFillColors;
}
/**
 * @public
 */
export declare namespace ChartElement {
    type Props = IChartElementProps;
}
/**
 * @public
 */
declare global {
    interface HTMLElementTagNameMap {
        'mosaik-chart': ChartElement;
    }
}
export {};
//# sourceMappingURL=ChartElement.d.ts.map