// #region Imports
import { html } from '../../../dom/Html';
import { ifDefined, repeat, when } from '../../directives/Directives';
import { Orientation } from '../../types/Orientation';
import { Placement } from '../../types/Placement';
import { Size } from '../../types/Size';
// #endregion
/**
 * Renders the chart toolbox controls.
 *
 * @public
 */
export function chartToolboxElementTemplate(e) {
    return html `
        <div part="group">
            ${repeat(e.getExportTools(), (tool) => tool, (tool) => html `
                <mosaik-tooltip part="tool-tooltip"
                                .lang="${e.lang}" .dir="${e.dir}" .themeName="${e.themeName}"
                                .content="${e.label(tool)}" .placement="${Placement.Top}">
                    <mosaik-button part="tool-button"
                                   .lang="${e.lang}" .dir="${e.dir}" .themeName="${e.themeName}"
                                   .icon="${e.icon(tool)}" .appearance="${e.appearance(tool)}"
                                   .size="${Size.Small}" .disabled="${!e.chart?.isReady}"
                                   data-tool="${tool}" aria-label="${e.label(tool)}"
                                   aria-pressed="${ifDefined(e.pressedState(tool))}"
                                   @click="${(event) => e.handleToolAction(event)}"></mosaik-button>
                </mosaik-tooltip>
            `)}
        </div>
        ${when(e.needsSeparator(), () => html `
            <mosaik-divider part="divider"
                            .lang="${e.lang}" .dir="${e.dir}" .themeName="${e.themeName}"
                            .orientation="${Orientation.Vertical}"></mosaik-divider>
        `)}
        <div part="group">
            ${repeat(e.getInteractionTools(), (tool) => tool, (tool) => html `
                <mosaik-tooltip part="tool-tooltip"
                                .lang="${e.lang}" .dir="${e.dir}" .themeName="${e.themeName}"
                                .content="${e.label(tool)}" .placement="${Placement.Top}">
                    <mosaik-button part="tool-button"
                                   .lang="${e.lang}" .dir="${e.dir}" .themeName="${e.themeName}"
                                   .icon="${e.icon(tool)}" .appearance="${e.appearance(tool)}"
                                   .size="${Size.Small}" .disabled="${!e.chart?.isReady}"
                                   data-tool="${tool}" aria-label="${e.label(tool)}"
                                   aria-pressed="${ifDefined(e.pressedState(tool))}"
                                   @click="${(event) => e.handleToolAction(event)}"></mosaik-button>
                </mosaik-tooltip>
            `)}
        </div>
    `;
}
//# sourceMappingURL=ChartToolboxElementTemplate.js.map