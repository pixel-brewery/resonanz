// #region Imports
import { ElementIntlBase } from '../../../../intl/abstracts/ElementIntlBase';
// #endregion
/**
 * The `ChartElementIntl` class.
 *
 * @public
 */
export class ChartElementIntl extends ElementIntlBase {
    // #region Fields
    _downloadLabel;
    _selectionLabel;
    _zoomLabel;
    _zoomInLabel;
    _zoomOutLabel;
    _panLabel;
    _measureLabel;
    _resetLabel;
    _exportToSvgLabel;
    _exportToPngLabel;
    _exportToCsvLabel;
    // #endregion
    // #region Ctor
    /**
     * Constructs chart action labels for the requested locale.
     *
     * @public
     */
    constructor(locale) {
        super(locale);
        this._downloadLabel = 'Download';
        this._selectionLabel = 'Selection';
        this._zoomLabel = 'Selection zoom';
        this._zoomInLabel = 'Zoom in';
        this._zoomOutLabel = 'Zoom out';
        this._panLabel = 'Panning';
        this._measureLabel = 'Measure';
        this._resetLabel = 'Reset';
        this._exportToSvgLabel = 'Export to SVG';
        this._exportToPngLabel = 'Export to PNG';
        this._exportToCsvLabel = 'Export to CSV';
    }
    // #endregion
    // #region Properties
    /**
     * Gets or sets the `downloadLabel` property.
     *
     * @public
     */
    get downloadLabel() {
        return this._downloadLabel;
    }
    set downloadLabel(value) {
        this._downloadLabel = value;
    }
    /**
     * Gets or sets the `selectionLabel` property.
     *
     * @public
     */
    get selectionLabel() {
        return this._selectionLabel;
    }
    set selectionLabel(value) {
        this._selectionLabel = value;
    }
    /**
     * Gets or sets the `zoomLabel` property.
     *
     * @public
     */
    get zoomLabel() {
        return this._zoomLabel;
    }
    set zoomLabel(value) {
        this._zoomLabel = value;
    }
    /**
     * Gets or sets the `zoomInLabel` property.
     *
     * @public
     */
    get zoomInLabel() {
        return this._zoomInLabel;
    }
    set zoomInLabel(value) {
        this._zoomInLabel = value;
    }
    /**
     * Gets or sets the `zoomOutLabel` property.
     *
     * @public
     */
    get zoomOutLabel() {
        return this._zoomOutLabel;
    }
    set zoomOutLabel(value) {
        this._zoomOutLabel = value;
    }
    /**
     * Gets or sets the `panLabel` property.
     *
     * @public
     */
    get panLabel() {
        return this._panLabel;
    }
    set panLabel(value) {
        this._panLabel = value;
    }
    /**
     * Gets or sets the label for the measure action.
     *
     * @public
     */
    get measureLabel() {
        return this._measureLabel;
    }
    set measureLabel(value) {
        this._measureLabel = value;
    }
    /**
     * Gets or sets the `resetLabel` property.
     *
     * @public
     */
    get resetLabel() {
        return this._resetLabel;
    }
    set resetLabel(value) {
        this._resetLabel = value;
    }
    /**
     * Gets or sets the `exportToSvgLabel` property.
     *
     * @public
     */
    get exportToSvgLabel() {
        return this._exportToSvgLabel;
    }
    set exportToSvgLabel(value) {
        this._exportToSvgLabel = value;
    }
    /**
     * Gets or sets the `exportToPngLabel` property.
     *
     * @public
     */
    get exportToPngLabel() {
        return this._exportToPngLabel;
    }
    set exportToPngLabel(value) {
        this._exportToPngLabel = value;
    }
    /**
     * Gets or sets the `exportToCsvLabel` property.
     *
     * @public
     */
    get exportToCsvLabel() {
        return this._exportToCsvLabel;
    }
    set exportToCsvLabel(value) {
        this._exportToCsvLabel = value;
    }
}
//# sourceMappingURL=ChartElementIntl.js.map