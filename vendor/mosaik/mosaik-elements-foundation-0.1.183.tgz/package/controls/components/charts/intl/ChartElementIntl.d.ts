import { ElementIntlBase } from '../../../../intl/abstracts/ElementIntlBase';
/**
 * The `ChartElementIntl` class.
 *
 * @public
 */
export declare class ChartElementIntl extends ElementIntlBase {
    private _downloadLabel;
    private _selectionLabel;
    private _zoomLabel;
    private _zoomInLabel;
    private _zoomOutLabel;
    private _panLabel;
    private _measureLabel;
    private _resetLabel;
    private _exportToSvgLabel;
    private _exportToPngLabel;
    private _exportToCsvLabel;
    /**
     * Constructs chart action labels for the requested locale.
     *
     * @public
     */
    constructor(locale?: string);
    /**
     * Gets or sets the `downloadLabel` property.
     *
     * @public
     */
    get downloadLabel(): string;
    set downloadLabel(value: string);
    /**
     * Gets or sets the `selectionLabel` property.
     *
     * @public
     */
    get selectionLabel(): string;
    set selectionLabel(value: string);
    /**
     * Gets or sets the `zoomLabel` property.
     *
     * @public
     */
    get zoomLabel(): string;
    set zoomLabel(value: string);
    /**
     * Gets or sets the `zoomInLabel` property.
     *
     * @public
     */
    get zoomInLabel(): string;
    set zoomInLabel(value: string);
    /**
     * Gets or sets the `zoomOutLabel` property.
     *
     * @public
     */
    get zoomOutLabel(): string;
    set zoomOutLabel(value: string);
    /**
     * Gets or sets the `panLabel` property.
     *
     * @public
     */
    get panLabel(): string;
    set panLabel(value: string);
    /**
     * Gets or sets the label for the measure action.
     *
     * @public
     */
    get measureLabel(): string;
    set measureLabel(value: string);
    /**
     * Gets or sets the `resetLabel` property.
     *
     * @public
     */
    get resetLabel(): string;
    set resetLabel(value: string);
    /**
     * Gets or sets the `exportToSvgLabel` property.
     *
     * @public
     */
    get exportToSvgLabel(): string;
    set exportToSvgLabel(value: string);
    /**
     * Gets or sets the `exportToPngLabel` property.
     *
     * @public
     */
    get exportToPngLabel(): string;
    set exportToPngLabel(value: string);
    /**
     * Gets or sets the `exportToCsvLabel` property.
     *
     * @public
     */
    get exportToCsvLabel(): string;
    set exportToCsvLabel(value: string);
}
//# sourceMappingURL=ChartElementIntl.d.ts.map