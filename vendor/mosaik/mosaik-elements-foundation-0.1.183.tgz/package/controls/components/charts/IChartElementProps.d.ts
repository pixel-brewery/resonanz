import type ApexCharts from 'apexcharts';
import type { ChartDisplayType } from '../../types/ChartDisplayType';
import type { ChartLegendPosition } from '../../types/ChartLegendPosition';
import type { ChartStackType } from '../../types/ChartStackType';
import type { IChartBaseElementProps } from './abstracts/IChartBaseElementProps';
import type { ChartToolVisibility } from './ChartToolVisibility';
interface IChartElementLegendProps {
    isLegendVisible: boolean;
    legendPosition: ChartLegendPosition;
}
interface IChartElementXAxisProps {
    isXAxisVisible: boolean;
}
interface IChartElementYAxisProps {
    isYAxisVisible: boolean;
}
/**
 * Represents the `IChartElementProps` interface.
 *
 * @public
 */
export interface IChartElementProps extends IChartBaseElementProps, IChartElementLegendProps, IChartElementXAxisProps, IChartElementYAxisProps {
    chart: ApexCharts.ApexOptions['chart'] | null;
    showToolbox: boolean;
    toolboxTools: ChartToolVisibility | null;
    annotations: ApexCharts.ApexOptions['annotations'] | null;
    colors: ApexCharts.ApexOptions['colors'] | null;
    dataLabels: ApexCharts.ApexOptions['dataLabels'] | null;
    series: ApexCharts.ApexOptions['series'] | null;
    stroke: ApexCharts.ApexOptions['stroke'] | null;
    labels: ApexCharts.ApexOptions['labels'] | null;
    legend: ApexCharts.ApexOptions['legend'] | null;
    markers: ApexCharts.ApexOptions['markers'] | null;
    noData: ApexCharts.ApexOptions['noData'] | null;
    fill: ApexCharts.ApexOptions['fill'] | null;
    tooltip: ApexCharts.ApexOptions['tooltip'] | null;
    plotOptions: ApexCharts.ApexOptions['plotOptions'] | null;
    responsive: ApexCharts.ApexOptions['responsive'] | null;
    xAxis: ApexCharts.ApexOptions['xaxis'] | null;
    yAxis: ApexCharts.ApexOptions['yaxis'] | null;
    grid: ApexCharts.ApexOptions['grid'] | null;
    states: ApexCharts.ApexOptions['states'] | null;
    theme: ApexCharts.ApexOptions['theme'] | null;
    display: ChartDisplayType;
    stacked: boolean;
    stackType: ChartStackType;
}
export {};
//# sourceMappingURL=IChartElementProps.d.ts.map