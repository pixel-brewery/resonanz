// #region Imports
import { html } from '../../../dom/Html';
import { when } from '../../directives/Directives';
// #endregion
/**
 * The template of the `ChartElement`.
 *
 * @public
 */
export function chartElementTemplate(e) {
    return html `
        ${when(e.showToolbox, () => html `
            <mosaik-chart-toolbox part="toolbox"
                                  .lang="${e.lang}"
                                  .dir="${e.dir}"
                                  .themeName="${e.themeName}"
                                  .chart="${e}"
                                  .tools="${e.toolboxTools}"></mosaik-chart-toolbox>
        `)}
        <div part="chart"></div>
    `;
}
//# sourceMappingURL=ChartElementTemplate.js.map