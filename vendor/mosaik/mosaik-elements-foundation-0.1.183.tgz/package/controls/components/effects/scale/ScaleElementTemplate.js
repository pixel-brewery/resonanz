// #region Imports
import { html } from '../../../../dom/Html';
// #endregion
/**
 * The template of the `ScaleElement`.
 *
 * @public
 */
export function scaleElementTemplate(_e) {
    return html.nothing;
}
//# sourceMappingURL=ScaleElementTemplate.js.map