import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function scaleElementCosmopolitanStyle(): CSSResult;
//# sourceMappingURL=ScaleElement.Cosmopolitan.d.ts.map