import { CssTime } from '@pixel-brewery/mosaik-themes';
import { ScaleMode } from '../../../types/ScaleMode';
import { CustomElement } from '../../abstracts/CustomElement';
import { IScaleElementProps } from './IScaleElementProps';
declare const ScaleElement_base: (abstract new (...args: Array<any>) => import("../../../behaviors/Themeable").IThemeableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Disableable").IDisableableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Attachable").IAttachable) & typeof CustomElement & import("../../../behaviors/Themeable").IThemeableCtor;
/**
 * Scale - A component for displaying scales, such as sliders or rating scales.
 *
 * @description
 * The Scale component is designed to render various types of scales. This could include sliders for adjusting
 * values, rating scales for user feedback, or any other component that represents a range of values in a visual format.
 * It offers customizable options for scale appearance, behavior, and value representation.
 *
 * @name Scale
 * @element mosaik-scale
 * @category Effects
 *
 * @cssprop {String} --scale-font-family - The font family CSS custom property.
 * @cssprop {String} --scale-font-letter-spacing - The font letter spacing CSS custom property.
 * @cssprop {String} --scale-font-line-height - The font line height CSS custom property.
 * @cssprop {String} --scale-font-size - The font size CSS custom property.
 * @cssprop {String} --scale-font-text-decoration - The font text decoration CSS custom property.
 * @cssprop {String} --scale-font-text-transform - The font text transform CSS custom property.
 * @cssprop {String} --scale-font-weight - The font weight CSS custom property.
 * @cssprop {String} --scale-gap - The gap CSS custom property.
 * @cssprop {String} --scale-padding-bottom - The padding bottom CSS custom property.
 * @cssprop {String} --scale-padding-left - The padding left CSS custom property.
 * @cssprop {String} --scale-padding-right - The padding right CSS custom property.
 * @cssprop {String} --scale-padding-top - The padding top CSS custom property.
 * @cssprop {String} --scale-shadow - The shadow CSS custom property.
 * @cssprop {String} --scale-shadow-blur - The shadow blur CSS custom property.
 * @cssprop {String} --scale-shadow-color - The shadow color CSS custom property.
 * @cssprop {String} --scale-shadow-offset-x - The shadow offset x CSS custom property.
 * @cssprop {String} --scale-shadow-offset-y - The shadow offset y CSS custom property.
 * @cssprop {String} --scale-shadow-spread - The shadow spread CSS custom property.
 * @cssprop {String} --scale-transition-duration - The transition duration CSS custom property.
 * @cssprop {String} --scale-transition-mode - The transition mode CSS custom property.
 * @cssprop {String} --scale-transition-property - The transition property CSS custom property.
 * @cssprop {String} --scale-translate - The translate CSS custom property.
 *
 * @example
 * Scale effect attached to a card element:
 * ```html
 * <div id="product-card" style="width: 200px; height: 150px;">Product Card</div>
 * <mosaik-scale for="product-card"></mosaik-scale>
 * ```
 *
 * @example
 * Scale with shrink mode and custom factor:
 * ```html
 * <div id="button-el" style="display: inline-block; padding: 8px 16px;">Hover Me</div>
 * <mosaik-scale for="button-el" mode="shrink" factor="0.05"></mosaik-scale>
 * ```
 *
 * @public
 */
export declare class ScaleElement extends ScaleElement_base implements IScaleElementProps {
    private _mode;
    private _factor;
    private _duration;
    private _mouseEnterSubscription;
    private _mouseLeaveSubscription;
    /**
     * @public
     */
    constructor();
    /**
     * Returns the `is` property.
     * The `is` property represents natural name of this element.
     *
     * @public
     * @static
     * @readonly
     */
    static get is(): string;
    /**
     * Gets or sets the `mode` property.
     *
     * @public
     * @attr
     */
    get mode(): ScaleMode;
    set mode(value: ScaleMode);
    /**
     * Gets or sets the `factor` property.
     *
     * @public
     * @attr
     */
    get factor(): number;
    set factor(value: number);
    /**
     * Gets or sets the `duration` property.
     *
     * @public
     * @attr
     */
    get duration(): CssTime;
    set duration(value: CssTime);
    /**
     * @public
     * @override
     */
    disconnectedCallback(): void;
    /**
     * @public
     * @override
     */
    protected onApplyTemplate(): void;
    /**
     * @private
     */
    private onMouseEnter;
    /**
     * @private
     */
    private onMouseLeave;
    /**
     * Applies the animation as style to the element.
     *
     * @private
     */
    private applyAnimation;
    /**
     * @private
     */
    private calculateFactor;
}
/**
 * @public
 */
export declare namespace ScaleElement {
    type Props = IScaleElementProps;
}
/**
 * @public
 */
declare global {
    interface HTMLElementTagNameMap {
        'mosaik-scale': ScaleElement;
    }
}
export {};
//# sourceMappingURL=ScaleElement.d.ts.map