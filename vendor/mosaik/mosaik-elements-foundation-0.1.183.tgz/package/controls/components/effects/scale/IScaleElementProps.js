// #region Imports
export {};
//# sourceMappingURL=IScaleElementProps.js.map