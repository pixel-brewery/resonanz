/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-non-null-assertion */
// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { on, waitForEvent } from '@pixel-brewery/mosaik-elements';
import { CssTime } from '@pixel-brewery/mosaik-themes';
import { Attachable } from '../../../behaviors/Attachable';
import { Disableable } from '../../../behaviors/Disableable';
import { Themeable } from '../../../behaviors/Themeable';
import { Attribute } from '../../../decorators/AttributeDecorator';
import { Component } from '../../../decorators/ComponentDecorator';
import { ScaleMode } from '../../../types/ScaleMode';
import { CustomElement } from '../../abstracts/CustomElement';
import { scaleElementTemplate } from './ScaleElementTemplate';
import { scaleElementCosmopolitanStyle } from './themes/ScaleElement.Cosmopolitan';
import { scaleElementJoyStyle } from './themes/ScaleElement.Joy';
import { scaleElementMemphisStyle } from './themes/ScaleElement.Memphis';
import { scaleElementSohoStyle } from './themes/ScaleElement.Soho';
// #endregion
/**
 * Scale - A component for displaying scales, such as sliders or rating scales.
 *
 * @description
 * The Scale component is designed to render various types of scales. This could include sliders for adjusting
 * values, rating scales for user feedback, or any other component that represents a range of values in a visual format.
 * It offers customizable options for scale appearance, behavior, and value representation.
 *
 * @name Scale
 * @element mosaik-scale
 * @category Effects
 *
 * @cssprop {String} --scale-font-family - The font family CSS custom property.
 * @cssprop {String} --scale-font-letter-spacing - The font letter spacing CSS custom property.
 * @cssprop {String} --scale-font-line-height - The font line height CSS custom property.
 * @cssprop {String} --scale-font-size - The font size CSS custom property.
 * @cssprop {String} --scale-font-text-decoration - The font text decoration CSS custom property.
 * @cssprop {String} --scale-font-text-transform - The font text transform CSS custom property.
 * @cssprop {String} --scale-font-weight - The font weight CSS custom property.
 * @cssprop {String} --scale-gap - The gap CSS custom property.
 * @cssprop {String} --scale-padding-bottom - The padding bottom CSS custom property.
 * @cssprop {String} --scale-padding-left - The padding left CSS custom property.
 * @cssprop {String} --scale-padding-right - The padding right CSS custom property.
 * @cssprop {String} --scale-padding-top - The padding top CSS custom property.
 * @cssprop {String} --scale-shadow - The shadow CSS custom property.
 * @cssprop {String} --scale-shadow-blur - The shadow blur CSS custom property.
 * @cssprop {String} --scale-shadow-color - The shadow color CSS custom property.
 * @cssprop {String} --scale-shadow-offset-x - The shadow offset x CSS custom property.
 * @cssprop {String} --scale-shadow-offset-y - The shadow offset y CSS custom property.
 * @cssprop {String} --scale-shadow-spread - The shadow spread CSS custom property.
 * @cssprop {String} --scale-transition-duration - The transition duration CSS custom property.
 * @cssprop {String} --scale-transition-mode - The transition mode CSS custom property.
 * @cssprop {String} --scale-transition-property - The transition property CSS custom property.
 * @cssprop {String} --scale-translate - The translate CSS custom property.
 *
 * @example
 * Scale effect attached to a card element:
 * ```html
 * <div id="product-card" style="width: 200px; height: 150px;">Product Card</div>
 * <mosaik-scale for="product-card"></mosaik-scale>
 * ```
 *
 * @example
 * Scale with shrink mode and custom factor:
 * ```html
 * <div id="button-el" style="display: inline-block; padding: 8px 16px;">Hover Me</div>
 * <mosaik-scale for="button-el" mode="shrink" factor="0.05"></mosaik-scale>
 * ```
 *
 * @public
 */
let ScaleElement = class ScaleElement extends Themeable(Disableable(Attachable(CustomElement))) {
    // #region Fields
    _mode;
    _factor;
    _duration;
    _mouseEnterSubscription;
    _mouseLeaveSubscription;
    // #endregion
    // #region Ctor
    /**
     * @public
     */
    constructor() {
        super();
        this._mode = ScaleMode.Grow;
        this._factor = 0.02;
        this._duration = 600;
        this._mouseEnterSubscription = null;
        this._mouseLeaveSubscription = null;
    }
    // #endregion
    // #region Properties
    /**
     * Returns the `is` property.
     * The `is` property represents natural name of this element.
     *
     * @public
     * @static
     * @readonly
     */
    static get is() {
        return 'mosaik-scale';
    }
    /**
     * Gets or sets the `mode` property.
     *
     * @public
     * @attr
     */
    get mode() {
        return this._mode;
    }
    set mode(value) {
        if (this._mode !== value) {
            this._mode = value;
            this.requestUpdate('mode');
        }
    }
    /**
     * Gets or sets the `factor` property.
     *
     * @public
     * @attr
     */
    get factor() {
        return this._factor;
    }
    set factor(value) {
        if (this._factor !== value) {
            this._factor = value;
            this.requestUpdate('factor');
        }
    }
    /**
     * Gets or sets the `duration` property.
     *
     * @public
     * @attr
     */
    get duration() {
        return this._duration;
    }
    set duration(value) {
        if (this._duration !== value) {
            this._duration = value;
            this.requestUpdate('duration');
        }
    }
    // #endregion
    // #region Methods
    /**
     * @public
     * @override
     */
    disconnectedCallback() {
        super.disconnectedCallback();
        this._mouseEnterSubscription?.dispose();
        this._mouseLeaveSubscription?.dispose();
    }
    /**
     * @public
     * @override
     */
    onApplyTemplate() {
        super.onApplyTemplate();
        if (this.control) {
            this._mouseEnterSubscription = on(this.control, 'mousemove', () => this.onMouseEnter());
            this._mouseLeaveSubscription = on(this.control, 'mouseleave', () => this.onMouseLeave());
        }
    }
    /**
     * @private
     */
    onMouseEnter() {
        const animationProps = {
            transform: `scale(${this.calculateFactor()})`,
            curve: 'easeInOut'
        };
        const animation = this.control?.animate(animationProps, {
            duration: this.duration
        });
        if (animation) {
            void waitForEvent(animation, 'finish').then(() => {
                this.applyAnimation(animationProps);
            });
            animation.play();
        }
    }
    /**
     * @private
     */
    onMouseLeave() {
        const animationProps = {
            transform: 'scale(1)',
            curve: 'easeInOut'
        };
        const animation = this.control?.animate(animationProps, {
            duration: this.duration
        });
        if (animation) {
            void waitForEvent(animation, 'finish').then(() => {
                this.applyAnimation(animationProps);
            });
            animation.play();
        }
    }
    /**
     * Applies the animation as style to the element.
     *
     * @private
     */
    applyAnimation(prop) {
        if (!this.control) {
            return;
        }
        Object.entries(prop).forEach(([k, v]) => {
            if (k in this.control.style) {
                this.control.style.setProperty(k, v?.toString() ?? '');
            }
        });
    }
    /**
     * @private
     */
    calculateFactor() {
        switch (this._mode) {
            case ScaleMode.Grow:
                return 1 + this._factor;
            case ScaleMode.Shrink:
                return 1 - this._factor;
            default:
                throw Error('Invalid operation');
        }
    }
};
__decorate([
    Attribute({ type: ScaleMode }),
    __metadata("design:type", String),
    __metadata("design:paramtypes", [String])
], ScaleElement.prototype, "mode", null);
__decorate([
    Attribute({ type: Number }),
    __metadata("design:type", Number),
    __metadata("design:paramtypes", [Number])
], ScaleElement.prototype, "factor", null);
__decorate([
    Attribute({ type: String }),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [Object])
], ScaleElement.prototype, "duration", null);
ScaleElement = __decorate([
    Component({
        selector: 'mosaik-scale',
        template: scaleElementTemplate,
        themes: {
            joy: scaleElementJoyStyle,
            memphis: scaleElementMemphisStyle,
            cosmopolitan: scaleElementCosmopolitanStyle,
            soho: scaleElementSohoStyle
        },
        imports: []
    }),
    __metadata("design:paramtypes", [])
], ScaleElement);
export { ScaleElement };
//# sourceMappingURL=ScaleElement.js.map