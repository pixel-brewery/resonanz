import { type ElementPart } from 'lit/directive.js';
import { type DirectiveArgs, DirectiveBase } from '../../../directives/abstracts/DirectiveBase';
import { ScaleElement } from './ScaleElement';
/**
 * @private
 */
declare class ScaleDirective extends DirectiveBase {
    private _scaleElement;
    /**
     * Constructs a new instance of the `ScaleDirective` class.
     *
     * @public
     */
    constructor(args: DirectiveArgs);
    /**
     * @public
     */
    render(_config: Partial<ScaleElement>): unknown;
    /**
     * @public
     * @override
     */
    update(part: ElementPart, [config]: Parameters<this['render']>): unknown;
    /**
     * @public
     */
    disconnected(): void;
}
/**
 * @public
 */
export declare const scale: (...values: Parameters<ScaleDirective["render"]>) => any;
export {};
//# sourceMappingURL=ScaleDirective.d.ts.map