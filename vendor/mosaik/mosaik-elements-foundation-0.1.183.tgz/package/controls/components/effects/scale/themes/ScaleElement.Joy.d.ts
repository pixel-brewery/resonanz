import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function scaleElementJoyStyle(): CSSResult;
//# sourceMappingURL=ScaleElement.Joy.d.ts.map