import { type TemplateResult } from '../../../../dom/Html';
import type { ScaleElement } from './ScaleElement';
/**
 * The template of the `ScaleElement`.
 *
 * @public
 */
export declare function scaleElementTemplate<T extends ScaleElement>(_e: T): TemplateResult;
//# sourceMappingURL=ScaleElementTemplate.d.ts.map