import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function scaleElementMemphisStyle(): CSSResult;
//# sourceMappingURL=ScaleElement.Memphis.d.ts.map