// #region Imports
import { directive, PartType } from 'lit/directive.js';
import { RendererServiceLocator } from '../../../../dom/Renderer';
import { DirectiveBase } from '../../../directives/abstracts/DirectiveBase';
import { ScaleElement } from './ScaleElement';
// #endregion
/**
 * @private
 */
class ScaleDirective extends DirectiveBase {
    // #region Fields
    _scaleElement = null;
    // #endregion
    // #region Ctor
    /**
     * Constructs a new instance of the `ScaleDirective` class.
     *
     * @public
     */
    constructor(args) {
        super(args);
        // Ensure the directive is used on elements only
        if (args.type !== PartType.ELEMENT) {
            throw new Error('The `scale` directive can only be used on elements.');
        }
    }
    // #endregion
    // #region Methods
    /**
     * @public
     */
    render(_config) {
        // Config is passed for rendering but is handled in the update method
        return '';
    }
    /**
     * @public
     * @override
     */
    update(part, [config]) {
        const hostElement = part.element;
        if (!this._scaleElement) {
            this._scaleElement = new ScaleElement();
            RendererServiceLocator.current.appendChild(hostElement, this._scaleElement);
        }
        Object.assign(this._scaleElement, config);
        this._scaleElement.attach(hostElement);
        return this.render(config);
    }
    /**
     * @public
     */
    disconnected() {
        if (this._scaleElement) {
            this._scaleElement.detach();
            this._scaleElement.remove();
            this._scaleElement = null;
        }
    }
}
/**
 * @public
 */
export const scale = directive(ScaleDirective);
//# sourceMappingURL=ScaleDirective.js.map