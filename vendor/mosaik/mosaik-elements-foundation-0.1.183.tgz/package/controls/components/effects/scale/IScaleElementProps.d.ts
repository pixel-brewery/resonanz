import type { CssTime } from '@pixel-brewery/mosaik-themes';
import type { IAttachableProps } from '../../../behaviors/Attachable';
import type { IDisableableProps } from '../../../behaviors/Disableable';
import type { ScaleMode } from '../../../types/ScaleMode';
/**
 * Represents the `IScaleElementProps` interface.
 *
 * @public
 */
export interface IScaleElementProps extends IDisableableProps, IAttachableProps {
    mode: ScaleMode;
    factor: number;
    duration: CssTime;
}
//# sourceMappingURL=IScaleElementProps.d.ts.map