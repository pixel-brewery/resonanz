/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-non-null-assertion */
// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { on, waitForEvent } from '@pixel-brewery/mosaik-elements';
import { CssTime } from '@pixel-brewery/mosaik-themes';
import { Attachable } from '../../../behaviors/Attachable';
import { Disableable } from '../../../behaviors/Disableable';
import { Themeable } from '../../../behaviors/Themeable';
import { Attribute } from '../../../decorators/AttributeDecorator';
import { Component } from '../../../decorators/ComponentDecorator';
import { CustomElement } from '../../abstracts/CustomElement';
import { perspectiveElementTemplate } from './PerspectiveElementTemplate';
import { perspectiveElementCosmopolitanStyle } from './themes/PerspectiveElement.Cosmopolitan';
import { perspectiveElementJoyStyle } from './themes/PerspectiveElement.Joy';
import { perspectiveElementMemphisStyle } from './themes/PerspectiveElement.Memphis';
import { perspectiveElementSohoStyle } from './themes/PerspectiveElement.Soho';
// #endregion
/**
 * Perspective - A component that manages the perspective effect for 3D transformations.
 *
 * @description
 * The Perspective component allows you to apply a perspective effect to elements, giving them a 3D appearance by controlling the distance between the user and the object. This is useful for creating depth and enhancing visual presentations in web applications.
 *
 * @name Perspective
 * @element mosaik-perspective
 * @category Effects
 *
 * @cssprop {String} --perspective-font-family - The font family CSS custom property.
 * @cssprop {String} --perspective-font-letter-spacing - The font letter spacing CSS custom property.
 * @cssprop {String} --perspective-font-line-height - The font line height CSS custom property.
 * @cssprop {String} --perspective-font-size - The font size CSS custom property.
 * @cssprop {String} --perspective-font-text-decoration - The font text decoration CSS custom property.
 * @cssprop {String} --perspective-font-text-transform - The font text transform CSS custom property.
 * @cssprop {String} --perspective-font-weight - The font weight CSS custom property.
 * @cssprop {String} --perspective-gap - The gap CSS custom property.
 * @cssprop {String} --perspective-padding-bottom - The padding bottom CSS custom property.
 * @cssprop {String} --perspective-padding-left - The padding left CSS custom property.
 * @cssprop {String} --perspective-padding-right - The padding right CSS custom property.
 * @cssprop {String} --perspective-padding-top - The padding top CSS custom property.
 * @cssprop {String} --perspective-shadow - The shadow CSS custom property.
 * @cssprop {String} --perspective-shadow-blur - The shadow blur CSS custom property.
 * @cssprop {String} --perspective-shadow-color - The shadow color CSS custom property.
 * @cssprop {String} --perspective-shadow-offset-x - The shadow offset x CSS custom property.
 * @cssprop {String} --perspective-shadow-offset-y - The shadow offset y CSS custom property.
 * @cssprop {String} --perspective-shadow-spread - The shadow spread CSS custom property.
 * @cssprop {String} --perspective-transition-duration - The transition duration CSS custom property.
 * @cssprop {String} --perspective-transition-mode - The transition mode CSS custom property.
 * @cssprop {String} --perspective-transition-property - The transition property CSS custom property.
 * @cssprop {String} --perspective-translate - The translate CSS custom property.
 *
 * @example
 * Perspective effect attached to a card element:
 * ```html
 * <div id="my-card" style="width: 200px; height: 200px; background: #eee;">3D Content</div>
 * <mosaik-perspective for="my-card"></mosaik-perspective>
 * ```
 *
 * @example
 * Perspective with custom factor and duration:
 * ```html
 * <div id="hero-image" style="width: 400px; height: 200px;">Hero Image</div>
 * <mosaik-perspective for="hero-image" factor="12" duration="400"></mosaik-perspective>
 * ```
 *
 * @public
 */
let PerspectiveElement = class PerspectiveElement extends Themeable(Disableable(Attachable(CustomElement))) {
    // #region Fields
    _duration;
    _mouseMoveSubscription;
    _mouseLeaveSubscription;
    _factor;
    // #endregion
    // #region Ctor
    /**
     * @public
     */
    constructor() {
        super();
        this._duration = 600;
        this._factor = 8;
        this._mouseMoveSubscription = null;
        this._mouseLeaveSubscription = null;
    }
    // #endregion
    // #region Properties
    /**
     * Returns the `is` property.
     * The `is` property represents natural name of this element.
     *
     * @public
     * @static
     * @readonly
     */
    static get is() {
        return 'mosaik-perspective';
    }
    /**
     * Gets or sets the `duration` property.
     *
     * @public
     * @attr
     */
    get duration() {
        return this._duration;
    }
    set duration(value) {
        if (this._duration !== value) {
            this._duration = value;
            this.requestUpdate('duration');
        }
    }
    /**
     * Gets or sets the `factor` property.
     *
     * @public
     * @attr
     */
    get factor() {
        return this._factor;
    }
    set factor(value) {
        if (this._factor !== value) {
            this._factor = value;
            this.requestUpdate('factor');
        }
    }
    // #endregion
    // #region Methods
    /**
     * @public
     * @override
     */
    disconnectedCallback() {
        super.disconnectedCallback();
        this._mouseMoveSubscription?.dispose();
        this._mouseLeaveSubscription?.dispose();
    }
    /**
     * @public
     * @override
     */
    onApplyTemplate() {
        super.onApplyTemplate();
        if (this.control) {
            this._mouseMoveSubscription = on(this.control, 'mousemove', (e) => this.onMouseMove(e));
            this._mouseLeaveSubscription = on(this.control, 'mouseleave', (e) => this.onMouseLeave(e));
        }
    }
    /**
     * @private
     */
    onMouseMove(event) {
        const rect = event.currentTarget.getBoundingClientRect();
        const clientWidth = event.currentTarget.clientWidth;
        const clientHeight = event.currentTarget.clientHeight;
        const clientX = event.clientX;
        const clientY = event.clientY;
        const horizontal = (clientX - rect.left) / clientWidth;
        const vertical = (clientY - rect.top) / clientHeight;
        const rotateX = ((this._factor / 2) - (horizontal * this._factor)).toFixed(2);
        const rotateY = ((vertical * this._factor) - (this._factor / 2)).toFixed(2);
        const animationProps = {
            transform: `perspective(${clientWidth}px) rotateX(${rotateY}deg) rotateY(${rotateX}deg) scale3d(1, 1, 1)`,
            curve: 'easeInOut'
        };
        const animation = this.control?.animate(animationProps, {
            duration: this.duration
        });
        if (animation) {
            void waitForEvent(animation, 'finish').then(() => {
                this.applyAnimation(animationProps);
            });
            animation.play();
        }
    }
    /**
     * @private
     */
    onMouseLeave(event) {
        const clientWidth = event.target.clientWidth;
        const animationProps = {
            transform: `perspective(${clientWidth}px) rotateX(0deg) rotateY(0deg)`,
            curve: 'easeInOut'
        };
        const animation = this.control?.animate(animationProps, {
            duration: this.duration
        });
        if (animation) {
            void waitForEvent(animation, 'finish').then(() => {
                this.applyAnimation(animationProps);
            });
            animation.play();
        }
    }
    /**
     * Applies the animation as style to the element.
     *
     * @private
     */
    applyAnimation(prop) {
        if (!this.control) {
            return;
        }
        Object.entries(prop).forEach(([k, v]) => {
            if (k in this.control.style) {
                this.control.style.setProperty(k, v?.toString() ?? '');
            }
        });
    }
};
__decorate([
    Attribute({ type: String }),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [Object])
], PerspectiveElement.prototype, "duration", null);
__decorate([
    Attribute({ type: Number }),
    __metadata("design:type", Number),
    __metadata("design:paramtypes", [Number])
], PerspectiveElement.prototype, "factor", null);
PerspectiveElement = __decorate([
    Component({
        selector: 'mosaik-perspective',
        template: perspectiveElementTemplate,
        themes: {
            joy: perspectiveElementJoyStyle,
            memphis: perspectiveElementMemphisStyle,
            cosmopolitan: perspectiveElementCosmopolitanStyle,
            soho: perspectiveElementSohoStyle
        },
        imports: []
    }),
    __metadata("design:paramtypes", [])
], PerspectiveElement);
export { PerspectiveElement };
//# sourceMappingURL=PerspectiveElement.js.map