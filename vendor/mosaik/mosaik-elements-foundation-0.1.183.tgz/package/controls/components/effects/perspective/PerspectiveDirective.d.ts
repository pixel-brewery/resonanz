import { type ElementPart } from 'lit/directive.js';
import { type DirectiveArgs, DirectiveBase } from '../../../directives/abstracts/DirectiveBase';
import type { IPerspectiveElementProps } from './IPerspectiveElementProps';
/**
 * @private
 */
declare class PerspectiveDirective extends DirectiveBase {
    private _perspectiveElement;
    /**
     * Constructs a new instance of the `PerspectiveDirective` class.
     *
     * @public
     */
    constructor(args: DirectiveArgs);
    /**
     * @public
     */
    render(_config: Partial<IPerspectiveElementProps>): unknown;
    /**
     * @public
     * @override
     */
    update(part: ElementPart, [config]: Parameters<this['render']>): unknown;
    /**
     * @public
     */
    disconnected(): void;
}
/**
 * @public
 */
export declare const perspective: (...values: Parameters<PerspectiveDirective["render"]>) => any;
export {};
//# sourceMappingURL=PerspectiveDirective.d.ts.map