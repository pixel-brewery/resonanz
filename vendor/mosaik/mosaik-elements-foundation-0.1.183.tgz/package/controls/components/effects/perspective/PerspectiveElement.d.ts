import { CssTime } from '@pixel-brewery/mosaik-themes';
import { CustomElement } from '../../abstracts/CustomElement';
import { IPerspectiveElementProps } from './IPerspectiveElementProps';
declare const PerspectiveElement_base: (abstract new (...args: Array<any>) => import("../../../behaviors/Themeable").IThemeableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Disableable").IDisableableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Attachable").IAttachable) & typeof CustomElement & import("../../../behaviors/Themeable").IThemeableCtor;
/**
 * Perspective - A component that manages the perspective effect for 3D transformations.
 *
 * @description
 * The Perspective component allows you to apply a perspective effect to elements, giving them a 3D appearance by controlling the distance between the user and the object. This is useful for creating depth and enhancing visual presentations in web applications.
 *
 * @name Perspective
 * @element mosaik-perspective
 * @category Effects
 *
 * @cssprop {String} --perspective-font-family - The font family CSS custom property.
 * @cssprop {String} --perspective-font-letter-spacing - The font letter spacing CSS custom property.
 * @cssprop {String} --perspective-font-line-height - The font line height CSS custom property.
 * @cssprop {String} --perspective-font-size - The font size CSS custom property.
 * @cssprop {String} --perspective-font-text-decoration - The font text decoration CSS custom property.
 * @cssprop {String} --perspective-font-text-transform - The font text transform CSS custom property.
 * @cssprop {String} --perspective-font-weight - The font weight CSS custom property.
 * @cssprop {String} --perspective-gap - The gap CSS custom property.
 * @cssprop {String} --perspective-padding-bottom - The padding bottom CSS custom property.
 * @cssprop {String} --perspective-padding-left - The padding left CSS custom property.
 * @cssprop {String} --perspective-padding-right - The padding right CSS custom property.
 * @cssprop {String} --perspective-padding-top - The padding top CSS custom property.
 * @cssprop {String} --perspective-shadow - The shadow CSS custom property.
 * @cssprop {String} --perspective-shadow-blur - The shadow blur CSS custom property.
 * @cssprop {String} --perspective-shadow-color - The shadow color CSS custom property.
 * @cssprop {String} --perspective-shadow-offset-x - The shadow offset x CSS custom property.
 * @cssprop {String} --perspective-shadow-offset-y - The shadow offset y CSS custom property.
 * @cssprop {String} --perspective-shadow-spread - The shadow spread CSS custom property.
 * @cssprop {String} --perspective-transition-duration - The transition duration CSS custom property.
 * @cssprop {String} --perspective-transition-mode - The transition mode CSS custom property.
 * @cssprop {String} --perspective-transition-property - The transition property CSS custom property.
 * @cssprop {String} --perspective-translate - The translate CSS custom property.
 *
 * @example
 * Perspective effect attached to a card element:
 * ```html
 * <div id="my-card" style="width: 200px; height: 200px; background: #eee;">3D Content</div>
 * <mosaik-perspective for="my-card"></mosaik-perspective>
 * ```
 *
 * @example
 * Perspective with custom factor and duration:
 * ```html
 * <div id="hero-image" style="width: 400px; height: 200px;">Hero Image</div>
 * <mosaik-perspective for="hero-image" factor="12" duration="400"></mosaik-perspective>
 * ```
 *
 * @public
 */
export declare class PerspectiveElement extends PerspectiveElement_base implements IPerspectiveElementProps {
    private _duration;
    private _mouseMoveSubscription;
    private _mouseLeaveSubscription;
    private _factor;
    /**
     * @public
     */
    constructor();
    /**
     * Returns the `is` property.
     * The `is` property represents natural name of this element.
     *
     * @public
     * @static
     * @readonly
     */
    static get is(): string;
    /**
     * Gets or sets the `duration` property.
     *
     * @public
     * @attr
     */
    get duration(): CssTime;
    set duration(value: CssTime);
    /**
     * Gets or sets the `factor` property.
     *
     * @public
     * @attr
     */
    get factor(): number;
    set factor(value: number);
    /**
     * @public
     * @override
     */
    disconnectedCallback(): void;
    /**
     * @public
     * @override
     */
    protected onApplyTemplate(): void;
    /**
     * @private
     */
    protected onMouseMove(event: MouseEvent): void;
    /**
     * @private
     */
    protected onMouseLeave(event: MouseEvent): void;
    /**
     * Applies the animation as style to the element.
     *
     * @private
     */
    private applyAnimation;
}
/**
 * @public
 */
export declare namespace PerspectiveElement {
    type Props = IPerspectiveElementProps;
}
/**
 * @public
 */
declare global {
    interface HTMLElementTagNameMap {
        'mosaik-perspective': PerspectiveElement;
    }
}
export {};
//# sourceMappingURL=PerspectiveElement.d.ts.map