import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function perspectiveElementMemphisStyle(): CSSResult;
//# sourceMappingURL=PerspectiveElement.Memphis.d.ts.map