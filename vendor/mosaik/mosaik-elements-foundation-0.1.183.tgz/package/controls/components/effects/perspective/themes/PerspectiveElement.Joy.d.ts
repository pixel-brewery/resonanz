import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function perspectiveElementJoyStyle(): CSSResult;
//# sourceMappingURL=PerspectiveElement.Joy.d.ts.map