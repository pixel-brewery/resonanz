import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function perspectiveElementCosmopolitanStyle(): CSSResult;
//# sourceMappingURL=PerspectiveElement.Cosmopolitan.d.ts.map