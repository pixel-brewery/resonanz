// #region Imports
export {};
//# sourceMappingURL=IPerspectiveElementProps.js.map