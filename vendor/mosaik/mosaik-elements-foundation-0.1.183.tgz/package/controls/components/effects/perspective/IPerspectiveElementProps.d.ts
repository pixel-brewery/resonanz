import type { CssTime } from '@pixel-brewery/mosaik-themes';
import type { IAttachableProps } from '../../../behaviors/Attachable';
import type { IDisableableProps } from '../../../behaviors/Disableable';
/**
 * Represents the `IPerspectiveElementProps` interface.
 *
 * @public
 */
export interface IPerspectiveElementProps extends IDisableableProps, IAttachableProps {
    duration: CssTime;
    factor: number;
}
//# sourceMappingURL=IPerspectiveElementProps.d.ts.map