import { type TemplateResult } from '../../../../dom/Html';
import type { PerspectiveElement } from './PerspectiveElement';
/**
 * The template of the `PerspectiveElement`.
 *
 * @public
 */
export declare function perspectiveElementTemplate<T extends PerspectiveElement>(_e: T): TemplateResult;
//# sourceMappingURL=PerspectiveElementTemplate.d.ts.map