// #region Imports
import { html } from '../../../../dom/Html';
// #endregion
/**
 * The template of the `PerspectiveElement`.
 *
 * @public
 */
export function perspectiveElementTemplate(_e) {
    return html.nothing;
}
//# sourceMappingURL=PerspectiveElementTemplate.js.map