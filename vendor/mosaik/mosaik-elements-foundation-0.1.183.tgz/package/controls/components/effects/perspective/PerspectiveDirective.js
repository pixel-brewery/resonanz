// #region Imports
import { directive, PartType } from 'lit/directive.js';
import { RendererServiceLocator } from '../../../../dom/Renderer';
import { DirectiveBase } from '../../../directives/abstracts/DirectiveBase';
import { PerspectiveElement } from './PerspectiveElement';
// #endregion
/**
 * @private
 */
class PerspectiveDirective extends DirectiveBase {
    // #region Fields
    _perspectiveElement = null;
    // #endregion
    // #region Ctor
    /**
     * Constructs a new instance of the `PerspectiveDirective` class.
     *
     * @public
     */
    constructor(args) {
        super(args);
        // Ensure the directive is used on elements only
        if (args.type !== PartType.ELEMENT) {
            throw new Error('The `perspective` directive can only be used on elements.');
        }
    }
    // #endregion
    // #region Methods
    /**
     * @public
     */
    render(_config) {
        // Config is passed for rendering but is handled in the update method
        return '';
    }
    /**
     * @public
     * @override
     */
    update(part, [config]) {
        const hostElement = part.element;
        if (!this._perspectiveElement) {
            this._perspectiveElement = new PerspectiveElement();
            RendererServiceLocator.current.appendChild(hostElement, this._perspectiveElement);
        }
        Object.assign(this._perspectiveElement, config);
        this._perspectiveElement.attach(hostElement);
        return this.render(config);
    }
    /**
     * @public
     */
    disconnected() {
        if (this._perspectiveElement) {
            this._perspectiveElement.detach();
            this._perspectiveElement.remove();
            this._perspectiveElement = null;
        }
    }
}
/**
 * @public
 */
export const perspective = directive(PerspectiveDirective);
//# sourceMappingURL=PerspectiveDirective.js.map