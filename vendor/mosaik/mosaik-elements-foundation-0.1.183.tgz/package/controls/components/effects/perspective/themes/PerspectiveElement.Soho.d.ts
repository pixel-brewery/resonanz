import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function perspectiveElementSohoStyle(): CSSResult;
//# sourceMappingURL=PerspectiveElement.Soho.d.ts.map