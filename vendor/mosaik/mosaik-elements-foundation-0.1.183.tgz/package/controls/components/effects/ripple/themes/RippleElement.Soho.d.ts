import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function rippleElementSohoStyle(): CSSResult;
//# sourceMappingURL=RippleElement.Soho.d.ts.map