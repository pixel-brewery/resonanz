import type { CssTime } from '@pixel-brewery/mosaik-themes';
import type { IAttachableProps } from '../../../behaviors/Attachable';
import type { IDisableableProps } from '../../../behaviors/Disableable';
import type { IVariantableProps } from '../../../behaviors/Variantable';
/**
 * Represents the `IRippleElementProps` interface.
 *
 * @public
 */
export interface IRippleElementProps extends IDisableableProps, IVariantableProps, IAttachableProps {
    centered: boolean;
    duration: CssTime;
}
//# sourceMappingURL=IRippleElementProps.d.ts.map