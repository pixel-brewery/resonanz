import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function rippleElementCosmopolitanStyle(): CSSResult;
//# sourceMappingURL=RippleElement.Cosmopolitan.d.ts.map