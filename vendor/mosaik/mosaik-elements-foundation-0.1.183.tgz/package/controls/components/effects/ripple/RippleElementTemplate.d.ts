import { type TemplateResult } from '../../../../dom/Html';
import type { RippleElement } from './RippleElement';
/**
 * The template of the `RippleElement`.
 *
 * @public
 */
export declare function rippleElementTemplate<T extends RippleElement>(_e: T): TemplateResult;
//# sourceMappingURL=RippleElementTemplate.d.ts.map