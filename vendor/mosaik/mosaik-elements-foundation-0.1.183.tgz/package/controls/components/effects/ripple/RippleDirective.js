// #region Imports
import { directive, PartType } from 'lit/directive.js';
import { RendererServiceLocator } from '../../../../dom/Renderer';
import { DirectiveBase } from '../../../directives/abstracts/DirectiveBase';
import { RippleElement } from './RippleElement';
// #endregion
/**
 * @private
 */
class RippleDirective extends DirectiveBase {
    // #region Fields
    _rippleElement = null;
    // #endregion
    // #region Ctor
    /**
     * Constructs a new instance of the `RippleDirective` class.
     *
     * @public
     */
    constructor(args) {
        super(args);
        // Ensure the directive is used on elements only
        if (args.type !== PartType.ELEMENT) {
            throw new Error('The `ripple` directive can only be used on elements.');
        }
    }
    // #endregion
    // #region Methods
    /**
     * @public
     */
    render(_config) {
        // Config is passed for rendering but is handled in the update method
        return '';
    }
    /**
     * @public
     * @override
     */
    update(part, [config]) {
        const hostElement = part.element;
        if (!this._rippleElement) {
            this._rippleElement = new RippleElement();
            RendererServiceLocator.current.appendChild(hostElement, this._rippleElement);
        }
        Object.assign(this._rippleElement, config);
        this._rippleElement.attach(hostElement);
        return this.render(config);
    }
    /**
     * @public
     */
    disconnected() {
        if (this._rippleElement) {
            this._rippleElement.detach();
            this._rippleElement.remove();
            this._rippleElement = null;
        }
    }
}
/**
 * @public
 */
export const ripple = directive(RippleDirective);
//# sourceMappingURL=RippleDirective.js.map