import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function rippleElementJoyStyle(): CSSResult;
//# sourceMappingURL=RippleElement.Joy.d.ts.map