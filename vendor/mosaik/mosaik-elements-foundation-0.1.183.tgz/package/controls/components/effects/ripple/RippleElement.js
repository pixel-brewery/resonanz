// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { on } from '@pixel-brewery/mosaik-elements';
import { CssTime } from '@pixel-brewery/mosaik-themes';
import { RendererServiceLocator } from '../../../../dom/Renderer';
import { Attachable } from '../../../behaviors/Attachable';
import { Disableable } from '../../../behaviors/Disableable';
import { Themeable } from '../../../behaviors/Themeable';
import { Variantable } from '../../../behaviors/Variantable';
import { Attribute } from '../../../decorators/AttributeDecorator';
import { Component } from '../../../decorators/ComponentDecorator';
import { CustomElement } from '../../abstracts/CustomElement';
import { rippleElementTemplate } from './RippleElementTemplate';
import { rippleElementCosmopolitanStyle } from './themes/RippleElement.Cosmopolitan';
import { rippleElementJoyStyle } from './themes/RippleElement.Joy';
import { rippleElementMemphisStyle } from './themes/RippleElement.Memphis';
import { rippleElementSohoStyle } from './themes/RippleElement.Soho';
// #endregion
/**
 * Ripple - An interactive visual effect component that creates expanding circular animations on user interaction.
 *
 * @description
 * The Ripple component is a visual feedback effect that creates Material Design-inspired expanding
 * circular animations emanating from the point of user interaction. It provides immediate tactile
 * feedback through smooth, animated ripple effects that enhance user experience by giving visual
 * confirmation of clicks, taps, or other interactive events. The component can be attached to any
 * interactive element and supports customization through duration, color, centering, and variant
 * options. Ripple effects automatically originate from the exact point of user interaction (click
 * or touch coordinates) unless centered mode is enabled. The component leverages the Web Animations
 * API for performant, hardware-accelerated animations and can be attached to external elements via
 * the `for` attribute from the Attachable behavior.
 *
 * @name Ripple
 * @element mosaik-ripple
 * @category Effects
 *
 * @cssprop {String} --ripple-background-color - The background color of the ripple animation circles
 * @cssprop {String} --ripple-font-family - The font family CSS custom property.
 * @cssprop {String} --ripple-font-letter-spacing - The font letter spacing CSS custom property.
 * @cssprop {String} --ripple-font-line-height - The font line height CSS custom property.
 * @cssprop {String} --ripple-font-size - The font size CSS custom property.
 * @cssprop {String} --ripple-font-text-decoration - The font text decoration CSS custom property.
 * @cssprop {String} --ripple-font-text-transform - The font text transform CSS custom property.
 * @cssprop {String} --ripple-font-weight - The font weight CSS custom property.
 * @cssprop {String} --ripple-gap - The gap CSS custom property.
 * @cssprop {String} --ripple-padding-bottom - The padding bottom CSS custom property.
 * @cssprop {String} --ripple-padding-left - The padding left CSS custom property.
 * @cssprop {String} --ripple-padding-right - The padding right CSS custom property.
 * @cssprop {String} --ripple-padding-top - The padding top CSS custom property.
 * @cssprop {String} --ripple-shadow - The shadow CSS custom property.
 * @cssprop {String} --ripple-shadow-blur - The shadow blur CSS custom property.
 * @cssprop {String} --ripple-shadow-color - The shadow color CSS custom property.
 * @cssprop {String} --ripple-shadow-offset-x - The shadow offset x CSS custom property.
 * @cssprop {String} --ripple-shadow-offset-y - The shadow offset y CSS custom property.
 * @cssprop {String} --ripple-shadow-spread - The shadow spread CSS custom property.
 * @cssprop {String} --ripple-transition-duration - The transition duration CSS custom property.
 * @cssprop {String} --ripple-transition-mode - The transition mode CSS custom property.
 * @cssprop {String} --ripple-transition-property - The transition property CSS custom property.
 * @cssprop {String} --ripple-translate - The translate CSS custom property.
 *
 * @example
 * Basic ripple attached to an interactive element:
 * ```html
 * <div id="interactive-element" style="padding: 16px; cursor: pointer;">Click Me</div>
 * <mosaik-ripple for="interactive-element"></mosaik-ripple>
 * ```
 *
 * @example
 * Ripple with variant and centered mode:
 * ```html
 * <div id="custom-card" class="interactive-card">Click anywhere on this card</div>
 * <mosaik-ripple for="custom-card" variant="primary" centered></mosaik-ripple>
 * ```
 *
 * @public
 */
let RippleElement = class RippleElement extends Themeable(Variantable(Disableable(Attachable(CustomElement)))) {
    // #region Fields
    _mouseDownSubscription;
    _centered;
    _duration;
    // #endregion
    // #region Ctor
    /**
     * @public
     */
    constructor() {
        super();
        this._centered = false;
        this._duration = 400;
        this._mouseDownSubscription = null;
    }
    // #endregion
    // #region Properties
    /**
     * Returns the `is` property.
     * The `is` property represents natural name of this element.
     *
     * @public
     * @static
     * @readonly
     */
    static get is() {
        return 'mosaik-ripple';
    }
    /**
     * Gets or sets the `centered` property.
     *
     * @public
     * @attr
     */
    get centered() {
        return this._centered;
    }
    set centered(value) {
        if (this._centered !== value) {
            this._centered = value;
            this.requestUpdate('centered');
        }
    }
    /**
     * Gets or sets the `duration` property.
     *
     * @public
     * @attr
     */
    get duration() {
        return this._duration;
    }
    set duration(value) {
        if (this._duration !== value) {
            this._duration = value;
            this.requestUpdate('duration');
        }
    }
    // #endregion
    // #region Methods
    /**
     * @public
     * @override
     */
    disconnectedCallback() {
        super.disconnectedCallback();
        if (this.control && this._mouseDownSubscription) {
            this._mouseDownSubscription.dispose();
        }
    }
    /**
     * @protected
     * @override
     */
    onApplyTemplate() {
        super.onApplyTemplate();
        if (this.control) {
            this._mouseDownSubscription = on(this.control, 'mousedown', (e) => this.onMouseDown(e));
        }
    }
    /**
     * @private
     */
    onMouseDown(event) {
        const element = RendererServiceLocator.current.createElement('span');
        RendererServiceLocator.current.setAttribute(element, 'part', 'ripple');
        const dimension = this.getDimensions(event.clientX, event.clientY);
        if (this._centered) {
            dimension.top = 0;
            dimension.left = 0;
        }
        const styles = {
            width: `${dimension.radius}px`,
            height: `${dimension.radius}px`,
            top: `${dimension.top}px`,
            left: `${dimension.left}px`
        };
        const frames = [
            {
                opacity: 0.5,
                transform: 'scale(.3)'
            },
            {
                opacity: 0,
                transform: 'scale(2)'
            }
        ];
        const opts = {
            duration: this._duration,
            fill: 'forwards',
            easing: 'linear'
        };
        Object.assign(element.style, styles);
        this.shadowRoot?.appendChild(element);
        void element.animate(frames, opts).finished.then(() => element.remove());
    }
    /**
     * @private
     */
    getDimensions(x, y) {
        const rect = this.getBoundingClientRect();
        const radius = Math.max(rect.width, rect.height);
        const left = Math.round(x - rect.left - radius / 2);
        const top = Math.round(y - rect.top - radius / 2);
        return {
            radius,
            top: top,
            left: left
        };
    }
};
__decorate([
    Attribute({
        type: Boolean,
        useDefault: true
    }),
    __metadata("design:type", Boolean),
    __metadata("design:paramtypes", [Boolean])
], RippleElement.prototype, "centered", null);
__decorate([
    Attribute({ type: String }),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [Object])
], RippleElement.prototype, "duration", null);
RippleElement = __decorate([
    Component({
        selector: 'mosaik-ripple',
        template: rippleElementTemplate,
        themes: {
            joy: rippleElementJoyStyle,
            memphis: rippleElementMemphisStyle,
            cosmopolitan: rippleElementCosmopolitanStyle,
            soho: rippleElementSohoStyle
        },
        imports: []
    }),
    __metadata("design:paramtypes", [])
], RippleElement);
export { RippleElement };
//# sourceMappingURL=RippleElement.js.map