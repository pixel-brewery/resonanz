import { type ElementPart } from 'lit/directive.js';
import { type DirectiveArgs, DirectiveBase } from '../../../directives/abstracts/DirectiveBase';
import { RippleElement } from './RippleElement';
/**
 * @private
 */
declare class RippleDirective extends DirectiveBase {
    private _rippleElement;
    /**
     * Constructs a new instance of the `RippleDirective` class.
     *
     * @public
     */
    constructor(args: DirectiveArgs);
    /**
     * @public
     */
    render(_config?: Partial<RippleElement.Props>): unknown;
    /**
     * @public
     * @override
     */
    update(part: ElementPart, [config]: Parameters<this['render']>): unknown;
    /**
     * @public
     */
    disconnected(): void;
}
/**
 * @public
 */
export declare const ripple: (...values: Parameters<RippleDirective["render"]>) => any;
export {};
//# sourceMappingURL=RippleDirective.d.ts.map