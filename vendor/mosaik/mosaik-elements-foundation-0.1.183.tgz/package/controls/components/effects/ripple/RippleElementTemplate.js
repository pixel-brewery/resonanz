// #region Imports
import { html } from '../../../../dom/Html';
// #endregion
/**
 * The template of the `RippleElement`.
 *
 * @public
 */
export function rippleElementTemplate(_e) {
    return html.nothing;
}
//# sourceMappingURL=RippleElementTemplate.js.map