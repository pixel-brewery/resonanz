import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function rippleElementMemphisStyle(): CSSResult;
//# sourceMappingURL=RippleElement.Memphis.d.ts.map