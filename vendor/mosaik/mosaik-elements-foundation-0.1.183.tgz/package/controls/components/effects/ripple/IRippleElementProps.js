// #region Imports
export {};
//# sourceMappingURL=IRippleElementProps.js.map