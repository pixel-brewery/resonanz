import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function patternElementJoyStyle(): CSSResult;
//# sourceMappingURL=PatternElement.Joy.d.ts.map