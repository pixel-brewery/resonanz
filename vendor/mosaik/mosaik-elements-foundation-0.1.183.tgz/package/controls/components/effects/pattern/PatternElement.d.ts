import { IAttachable } from '../../../behaviors/Attachable';
import { CustomElement } from '../../abstracts/CustomElement';
import { IPatternElementProps } from './IPatternElementProps';
declare const PatternElement_base: (abstract new (...args: Array<any>) => import("../../../behaviors/Themeable").IThemeableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Variantable").IVariantableProps) & (abstract new (...args: Array<any>) => import("../../../behaviors/Disableable").IDisableableProps) & (abstract new (...args: Array<any>) => IAttachable) & typeof CustomElement & import("../../../behaviors/Themeable").IThemeableCtor;
/**
 * Pattern - A component for generating random patterns with a mask effect based on mouse position.
 *
 * @description
 * The Pattern component provides a decorative pattern effect by randomly selecting predefined patterns
 * and applying a mask based on the mouse position for interactive visuals.
 *
 * @name Pattern
 * @element mosaik-pattern
 * @category Effects
 *
 * @csspart gradient first - The first gradient layer of the pattern.
 * @csspart gradient second - The second gradient layer of the pattern.
 * @csspart root - The root container of the pattern.
 *
 * @cssprop {Color} --pattern-background-color - The background color of the pattern.
 * @cssprop {String} --pattern-font-family - The font family CSS custom property.
 * @cssprop {String} --pattern-font-letter-spacing - The font letter spacing CSS custom property.
 * @cssprop {String} --pattern-font-line-height - The font line height CSS custom property.
 * @cssprop {String} --pattern-font-size - The font size CSS custom property.
 * @cssprop {String} --pattern-font-text-decoration - The font text decoration CSS custom property.
 * @cssprop {String} --pattern-font-text-transform - The font text transform CSS custom property.
 * @cssprop {String} --pattern-font-weight - The font weight CSS custom property.
 * @cssprop {String} --pattern-gap - The gap CSS custom property.
 * @cssprop {String} --pattern-padding-bottom - The padding bottom CSS custom property.
 * @cssprop {String} --pattern-padding-left - The padding left CSS custom property.
 * @cssprop {String} --pattern-padding-right - The padding right CSS custom property.
 * @cssprop {String} --pattern-padding-top - The padding top CSS custom property.
 * @cssprop {String} --pattern-shadow - The shadow CSS custom property.
 * @cssprop {String} --pattern-shadow-blur - The shadow blur CSS custom property.
 * @cssprop {String} --pattern-shadow-color - The shadow color CSS custom property.
 * @cssprop {String} --pattern-shadow-offset-x - The shadow offset x CSS custom property.
 * @cssprop {String} --pattern-shadow-offset-y - The shadow offset y CSS custom property.
 * @cssprop {String} --pattern-shadow-spread - The shadow spread CSS custom property.
 * @cssprop {String} --pattern-transition-duration - The transition duration CSS custom property.
 * @cssprop {String} --pattern-transition-mode - The transition mode CSS custom property.
 * @cssprop {String} --pattern-transition-property - The transition property CSS custom property.
 * @cssprop {String} --pattern-translate - The translate CSS custom property.
 *
 * @example
 * ```html
 * <mosaik-pattern></mosaik-pattern>
 * ```
 *
 * @public
 */
export declare class PatternElement extends PatternElement_base implements IAttachable, IPatternElementProps {
    private _gradientFirstElement;
    private _gradientSecondElement;
    private _mouseX;
    private _mouseY;
    private _mouseMoveSubscription;
    /**
     * Constructs a new instance of the `PatternElement` class.
     *
     * @public
     */
    constructor();
    /**
     * Returns the `is` property.
     * The `is` property represents the natural name of this element.
     *
     * @public
     * @static
     * @readonly
     */
    static get is(): string;
    /**
     * Gets or sets the `mouseX` property.
     *
     * @public
     */
    get mouseX(): number;
    set mouseX(value: number);
    /**
     * Gets or sets the `mouseY` property.
     *
     * @public
     */
    get mouseY(): number;
    set mouseY(value: number);
    /**
     * @public
     * @override
     */
    disconnectedCallback(): void;
    /**
     * @protected
     * @override
     */
    protected onApplyTemplate(): void;
    /**
     * @private
     */
    private onMouseMove;
    /**
     * Updates the mask style based on the current mouse coordinates.
     *
     * @private
     */
    private updateMaskStyle;
}
/**
 * @public
 */
export declare namespace PatternElement {
    type Props = IPatternElementProps;
}
/**
 * @public
 */
declare global {
    interface HTMLElementTagNameMap {
        'mosaik-pattern': PatternElement;
    }
}
export {};
//# sourceMappingURL=PatternElement.d.ts.map