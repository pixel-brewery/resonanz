import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function patternElementMemphisStyle(): CSSResult;
//# sourceMappingURL=PatternElement.Memphis.d.ts.map