import type { IAttachableProps } from '../../../behaviors/Attachable';
import type { IDisableableProps } from '../../../behaviors/Disableable';
import type { IVariantableProps } from '../../../behaviors/Variantable';
/**
 * Represents the `IPatternElementProps` interface.
 *
 * @public
 */
export interface IPatternElementProps extends IDisableableProps, IAttachableProps, IVariantableProps {
}
//# sourceMappingURL=IPatternElementProps.d.ts.map