import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function patternElementCosmopolitanStyle(): CSSResult;
//# sourceMappingURL=PatternElement.Cosmopolitan.d.ts.map