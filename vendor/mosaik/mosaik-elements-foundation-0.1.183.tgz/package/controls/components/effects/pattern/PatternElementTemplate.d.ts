import { type TemplateResult } from '../../../../dom/Html';
import type { PatternElement } from './PatternElement';
/**
 * The template of the `PatternElement`.
 *
 * @public
 */
export declare function patternElementTemplate<T extends PatternElement>(_e: T): TemplateResult;
//# sourceMappingURL=PatternElementTemplate.d.ts.map