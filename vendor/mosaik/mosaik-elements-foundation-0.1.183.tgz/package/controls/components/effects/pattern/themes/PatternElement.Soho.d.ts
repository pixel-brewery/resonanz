import { type CSSResult } from '../../../../../dom/Css';
/**
 * @public
 */
export declare function patternElementSohoStyle(): CSSResult;
//# sourceMappingURL=PatternElement.Soho.d.ts.map