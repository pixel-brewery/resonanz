// #region Imports
export {};
//# sourceMappingURL=IPatternElementProps.js.map