// #region Imports
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { on } from '@pixel-brewery/mosaik-elements';
import { Attachable } from '../../../behaviors/Attachable';
import { Disableable } from '../../../behaviors/Disableable';
import { Themeable } from '../../../behaviors/Themeable';
import { Variantable } from '../../../behaviors/Variantable';
import { Component } from '../../../decorators/ComponentDecorator';
import { Property } from '../../../decorators/PropertyDecorator';
import { CustomElement } from '../../abstracts/CustomElement';
import { patternElementTemplate } from './PatternElementTemplate';
import { patternElementCosmopolitanStyle } from './themes/PatternElement.Cosmopolitan';
import { patternElementJoyStyle } from './themes/PatternElement.Joy';
import { patternElementMemphisStyle } from './themes/PatternElement.Memphis';
import { patternElementSohoStyle } from './themes/PatternElement.Soho';
// #endregion
/**
 * Pattern - A component for generating random patterns with a mask effect based on mouse position.
 *
 * @description
 * The Pattern component provides a decorative pattern effect by randomly selecting predefined patterns
 * and applying a mask based on the mouse position for interactive visuals.
 *
 * @name Pattern
 * @element mosaik-pattern
 * @category Effects
 *
 * @csspart gradient first - The first gradient layer of the pattern.
 * @csspart gradient second - The second gradient layer of the pattern.
 * @csspart root - The root container of the pattern.
 *
 * @cssprop {Color} --pattern-background-color - The background color of the pattern.
 * @cssprop {String} --pattern-font-family - The font family CSS custom property.
 * @cssprop {String} --pattern-font-letter-spacing - The font letter spacing CSS custom property.
 * @cssprop {String} --pattern-font-line-height - The font line height CSS custom property.
 * @cssprop {String} --pattern-font-size - The font size CSS custom property.
 * @cssprop {String} --pattern-font-text-decoration - The font text decoration CSS custom property.
 * @cssprop {String} --pattern-font-text-transform - The font text transform CSS custom property.
 * @cssprop {String} --pattern-font-weight - The font weight CSS custom property.
 * @cssprop {String} --pattern-gap - The gap CSS custom property.
 * @cssprop {String} --pattern-padding-bottom - The padding bottom CSS custom property.
 * @cssprop {String} --pattern-padding-left - The padding left CSS custom property.
 * @cssprop {String} --pattern-padding-right - The padding right CSS custom property.
 * @cssprop {String} --pattern-padding-top - The padding top CSS custom property.
 * @cssprop {String} --pattern-shadow - The shadow CSS custom property.
 * @cssprop {String} --pattern-shadow-blur - The shadow blur CSS custom property.
 * @cssprop {String} --pattern-shadow-color - The shadow color CSS custom property.
 * @cssprop {String} --pattern-shadow-offset-x - The shadow offset x CSS custom property.
 * @cssprop {String} --pattern-shadow-offset-y - The shadow offset y CSS custom property.
 * @cssprop {String} --pattern-shadow-spread - The shadow spread CSS custom property.
 * @cssprop {String} --pattern-transition-duration - The transition duration CSS custom property.
 * @cssprop {String} --pattern-transition-mode - The transition mode CSS custom property.
 * @cssprop {String} --pattern-transition-property - The transition property CSS custom property.
 * @cssprop {String} --pattern-translate - The translate CSS custom property.
 *
 * @example
 * ```html
 * <mosaik-pattern></mosaik-pattern>
 * ```
 *
 * @public
 */
let PatternElement = class PatternElement extends Themeable(Variantable(Disableable(Attachable(CustomElement)))) {
    // #region Fields
    _gradientFirstElement;
    _gradientSecondElement;
    _mouseX;
    _mouseY;
    _mouseMoveSubscription;
    // #endregion
    // #region Ctor
    /**
     * Constructs a new instance of the `PatternElement` class.
     *
     * @public
     */
    constructor() {
        super();
        this._mouseX = 0;
        this._mouseY = 0;
        this._mouseMoveSubscription = null;
    }
    // #endregion
    // #region Properties
    /**
     * Returns the `is` property.
     * The `is` property represents the natural name of this element.
     *
     * @public
     * @static
     * @readonly
     */
    static get is() {
        return 'mosaik-pattern';
    }
    /**
     * Gets or sets the `mouseX` property.
     *
     * @public
     */
    get mouseX() {
        return this._mouseX;
    }
    set mouseX(value) {
        if (this._mouseX !== value) {
            this._mouseX = value;
            this.requestUpdate('mouseX');
        }
    }
    /**
     * Gets or sets the `mouseY` property.
     *
     * @public
     */
    get mouseY() {
        return this._mouseY;
    }
    set mouseY(value) {
        if (this._mouseY !== value) {
            this._mouseY = value;
            this.requestUpdate('mouseY');
        }
    }
    // #endregion
    // #region Methods
    /**
     * @public
     * @override
     */
    disconnectedCallback() {
        super.disconnectedCallback();
        if (this._mouseMoveSubscription) {
            this._mouseMoveSubscription.dispose();
        }
    }
    /**
     * @protected
     * @override
     */
    onApplyTemplate() {
        super.onApplyTemplate();
        this._gradientFirstElement = this.getTemplatePart('gradient first');
        this._gradientSecondElement = this.getTemplatePart('gradient second');
        if (this.control) {
            this._mouseMoveSubscription = on(this.control, 'mousemove', (e) => this.onMouseMove(e));
        }
    }
    /**
     * @private
     */
    onMouseMove(event) {
        this._mouseX = event.offsetX;
        this._mouseY = event.offsetY;
        this.updateMaskStyle();
    }
    /**
     * Updates the mask style based on the current mouse coordinates.
     *
     * @private
     */
    updateMaskStyle() {
        const maskImage = `radial-gradient(180px at ${this._mouseX}px ${this._mouseY}px, white, transparent)`;
        this._gradientFirstElement.style.maskImage = maskImage;
        this._gradientSecondElement.style.maskImage = maskImage;
    }
};
__decorate([
    Property({ type: Number }),
    __metadata("design:type", Number),
    __metadata("design:paramtypes", [Number])
], PatternElement.prototype, "mouseX", null);
__decorate([
    Property({ type: Number }),
    __metadata("design:type", Number),
    __metadata("design:paramtypes", [Number])
], PatternElement.prototype, "mouseY", null);
PatternElement = __decorate([
    Component({
        selector: 'mosaik-pattern',
        template: patternElementTemplate,
        themes: {
            joy: patternElementJoyStyle,
            memphis: patternElementMemphisStyle,
            cosmopolitan: patternElementCosmopolitanStyle,
            soho: patternElementSohoStyle
        },
        imports: []
    }),
    __metadata("design:paramtypes", [])
], PatternElement);
export { PatternElement };
//# sourceMappingURL=PatternElement.js.map