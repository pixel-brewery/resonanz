// #region Imports
import { html } from '../../../../dom/Html';
// #endregion
/**
 * The template of the `PatternElement`.
 *
 * @public
 */
export function patternElementTemplate(_e) {
    return html `
        <div part="root">
            <div part="gradient first"></div>
            <div part="gradient second"></div>
        </div>
    `;
}
//# sourceMappingURL=PatternElementTemplate.js.map