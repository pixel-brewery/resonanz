import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { RatingElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/rating/RatingElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const RATING_DEFAULT_PROPS = new InjectionToken("MOSAIK_RATING_DEFAULT_PROPS");
let RatingComponent = class RatingComponent {
	hoverValue = input(...ngDevMode ? [void 0, { debugName: "hoverValue" }] : /* istanbul ignore next */ []);
	isHovering = input(...ngDevMode ? [void 0, { debugName: "isHovering" }] : /* istanbul ignore next */ []);
	length = input(...ngDevMode ? [void 0, { debugName: "length" }] : /* istanbul ignore next */ []);
	precision = input(...ngDevMode ? [void 0, { debugName: "precision" }] : /* istanbul ignore next */ []);
	readonly = input(...ngDevMode ? [void 0, { debugName: "readonly" }] : /* istanbul ignore next */ []);
	symbol = input(...ngDevMode ? [void 0, { debugName: "symbol" }] : /* istanbul ignore next */ []);
	activeSymbol = input(...ngDevMode ? [void 0, { debugName: "activeSymbol" }] : /* istanbul ignore next */ []);
	symbolAccessor = input(...ngDevMode ? [void 0, { debugName: "symbolAccessor" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	value = input(...ngDevMode ? [void 0, { debugName: "value" }] : /* istanbul ignore next */ []);
	label = input(...ngDevMode ? [void 0, { debugName: "label" }] : /* istanbul ignore next */ []);
	orientation = input(...ngDevMode ? [void 0, { debugName: "orientation" }] : /* istanbul ignore next */ []);
	size = input(...ngDevMode ? [void 0, { debugName: "size" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	change = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			change: this.change,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(RATING_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	focus(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "focus", args);
	}
	blur(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "blur", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const hoverValueValue = this.hoverValue();
			if (hoverValueValue !== void 0) this._elementRef.nativeElement.hoverValue = hoverValueValue;
			const isHoveringValue = this.isHovering();
			if (isHoveringValue !== void 0) this._elementRef.nativeElement.isHovering = isHoveringValue;
			const precisionValue = this.precision();
			if (precisionValue !== void 0) this._elementRef.nativeElement.precision = precisionValue;
			const readonlyValue = this.readonly();
			if (readonlyValue !== void 0) this._elementRef.nativeElement.readonly = readonlyValue;
			const symbolValue = this.symbol();
			if (symbolValue !== void 0) this._elementRef.nativeElement.symbol = symbolValue;
			const activeSymbolValue = this.activeSymbol();
			if (activeSymbolValue !== void 0) this._elementRef.nativeElement.activeSymbol = activeSymbolValue;
			const symbolAccessorValue = this.symbolAccessor();
			if (symbolAccessorValue !== void 0) this._elementRef.nativeElement.symbolAccessor = symbolAccessorValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const valueValue = this.value();
			if (valueValue !== void 0) this._elementRef.nativeElement.value = valueValue;
			const labelValue = this.label();
			if (labelValue !== void 0) this._elementRef.nativeElement.label = labelValue;
			const orientationValue = this.orientation();
			if (orientationValue !== void 0) this._elementRef.nativeElement.orientation = orientationValue;
			const sizeValue = this.size();
			if (sizeValue !== void 0) this._elementRef.nativeElement.size = sizeValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: RatingComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: RatingComponent,
		isStandalone: true,
		selector: "mosaik-rating",
		inputs: {
			hoverValue: {
				classPropertyName: "hoverValue",
				publicName: "hoverValue",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isHovering: {
				classPropertyName: "isHovering",
				publicName: "isHovering",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			length: {
				classPropertyName: "length",
				publicName: "length",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			precision: {
				classPropertyName: "precision",
				publicName: "precision",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			readonly: {
				classPropertyName: "readonly",
				publicName: "readonly",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			symbol: {
				classPropertyName: "symbol",
				publicName: "symbol",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			activeSymbol: {
				classPropertyName: "activeSymbol",
				publicName: "activeSymbol",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			symbolAccessor: {
				classPropertyName: "symbolAccessor",
				publicName: "symbolAccessor",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			orientation: {
				classPropertyName: "orientation",
				publicName: "orientation",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			change: "change",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
RatingComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-rating", RatingElement),
	inputs: [
		"hoverValue",
		"isHovering",
		"length",
		"precision",
		"readonly",
		"symbol",
		"activeSymbol",
		"symbolAccessor",
		"themeName",
		"disabled",
		"value",
		"label",
		"orientation",
		"size",
		"variant",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], RatingComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: RatingComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-rating",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		hoverValue: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hoverValue",
				required: false
			}]
		}],
		isHovering: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isHovering",
				required: false
			}]
		}],
		length: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "length",
				required: false
			}]
		}],
		precision: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "precision",
				required: false
			}]
		}],
		readonly: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "readonly",
				required: false
			}]
		}],
		symbol: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "symbol",
				required: false
			}]
		}],
		activeSymbol: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "activeSymbol",
				required: false
			}]
		}],
		symbolAccessor: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "symbolAccessor",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		orientation: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "orientation",
				required: false
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		change: [{
			type: i0.Output,
			args: ["change"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideRatingComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: RATING_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { RATING_DEFAULT_PROPS, RatingComponent, provideRatingComponent };

//# sourceMappingURL=mosaik-elements-angular-components-rating.mjs.map