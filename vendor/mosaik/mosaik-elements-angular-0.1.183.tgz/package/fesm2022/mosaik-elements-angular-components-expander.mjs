import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { ExpanderGroupElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/grouping/expander/ExpanderGroupElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { ExpanderHeaderElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/grouping/expander/ExpanderHeaderElement";
import { ExpanderSubHeaderElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/grouping/expander/ExpanderSubHeaderElement";
import { ExpanderElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/grouping/expander/ExpanderElement";
var __decorate$3 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$3 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const EXPANDER_GROUP_DEFAULT_PROPS = new InjectionToken("MOSAIK_EXPANDER_GROUP_DEFAULT_PROPS");
let ExpanderGroupComponent = class ExpanderGroupComponent {
	mode = input(...ngDevMode ? [void 0, { debugName: "mode" }] : /* istanbul ignore next */ []);
	direction = input(...ngDevMode ? [void 0, { debugName: "direction" }] : /* istanbul ignore next */ []);
	stacking = input(...ngDevMode ? [void 0, { debugName: "stacking" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	appearance = input(...ngDevMode ? [void 0, { debugName: "appearance" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	toggled = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			toggled: this.toggled,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(EXPANDER_GROUP_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	collapse(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "collapse", args);
	}
	expand(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "expand", args);
	}
	onSlotChanges(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onSlotChanges", args);
	}
	assignToSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "assignToSlot", args);
	}
	getSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getSlotContent", args);
	}
	hasSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlotContent", args);
	}
	hasSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlot", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const modeValue = this.mode();
			if (modeValue !== void 0) this._elementRef.nativeElement.mode = modeValue;
			const directionValue = this.direction();
			if (directionValue !== void 0) this._elementRef.nativeElement.direction = directionValue;
			const stackingValue = this.stacking();
			if (stackingValue !== void 0) this._elementRef.nativeElement.stacking = stackingValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const appearanceValue = this.appearance();
			if (appearanceValue !== void 0) this._elementRef.nativeElement.appearance = appearanceValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ExpanderGroupComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: ExpanderGroupComponent,
		isStandalone: true,
		selector: "mosaik-expander-group",
		inputs: {
			mode: {
				classPropertyName: "mode",
				publicName: "mode",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			direction: {
				classPropertyName: "direction",
				publicName: "direction",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			stacking: {
				classPropertyName: "stacking",
				publicName: "stacking",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			toggled: "toggled",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
ExpanderGroupComponent = __decorate$3([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-expander-group", ExpanderGroupElement),
	inputs: [
		"mode",
		"direction",
		"stacking",
		"themeName",
		"disabled",
		"variant",
		"appearance",
		"dir",
		"lang"
	],
	methods: ["getSlotAssignments", "getSlotAssignmentsOf"]
}), __metadata$3("design:paramtypes", [])], ExpanderGroupComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ExpanderGroupComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-expander-group",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		mode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mode",
				required: false
			}]
		}],
		direction: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "direction",
				required: false
			}]
		}],
		stacking: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "stacking",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		toggled: [{
			type: i0.Output,
			args: ["toggled"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideExpanderGroupComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: EXPANDER_GROUP_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$2 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$2 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const EXPANDER_HEADER_DEFAULT_PROPS = new InjectionToken("MOSAIK_EXPANDER_HEADER_DEFAULT_PROPS");
let ExpanderHeaderComponent = class ExpanderHeaderComponent {
	text = input(...ngDevMode ? [void 0, { debugName: "text" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(EXPANDER_HEADER_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const textValue = this.text();
			if (textValue !== void 0) this._elementRef.nativeElement.text = textValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ExpanderHeaderComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: ExpanderHeaderComponent,
		isStandalone: true,
		selector: "mosaik-expander-header",
		inputs: {
			text: {
				classPropertyName: "text",
				publicName: "text",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
ExpanderHeaderComponent = __decorate$2([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-expander-header", ExpanderHeaderElement),
	inputs: [
		"text",
		"themeName",
		"dir",
		"lang"
	]
}), __metadata$2("design:paramtypes", [])], ExpanderHeaderComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ExpanderHeaderComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-expander-header",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		text: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "text",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideExpanderHeaderComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: EXPANDER_HEADER_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$1 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$1 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const EXPANDER_SUB_HEADER_DEFAULT_PROPS = new InjectionToken("MOSAIK_EXPANDER_SUB_HEADER_DEFAULT_PROPS");
let ExpanderSubHeaderComponent = class ExpanderSubHeaderComponent {
	text = input(...ngDevMode ? [void 0, { debugName: "text" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(EXPANDER_SUB_HEADER_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const textValue = this.text();
			if (textValue !== void 0) this._elementRef.nativeElement.text = textValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ExpanderSubHeaderComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: ExpanderSubHeaderComponent,
		isStandalone: true,
		selector: "mosaik-expander-sub-header",
		inputs: {
			text: {
				classPropertyName: "text",
				publicName: "text",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
ExpanderSubHeaderComponent = __decorate$1([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-expander-sub-header", ExpanderSubHeaderElement),
	inputs: [
		"text",
		"themeName",
		"dir",
		"lang"
	]
}), __metadata$1("design:paramtypes", [])], ExpanderSubHeaderComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ExpanderSubHeaderComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-expander-sub-header",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		text: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "text",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideExpanderSubHeaderComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: EXPANDER_SUB_HEADER_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const EXPANDER_DEFAULT_PROPS = new InjectionToken("MOSAIK_EXPANDER_DEFAULT_PROPS");
let ExpanderComponent = class ExpanderComponent {
	header = input(...ngDevMode ? [void 0, { debugName: "header" }] : /* istanbul ignore next */ []);
	subHeader = input(...ngDevMode ? [void 0, { debugName: "subHeader" }] : /* istanbul ignore next */ []);
	icon = input(...ngDevMode ? [void 0, { debugName: "icon" }] : /* istanbul ignore next */ []);
	caretPosition = input(...ngDevMode ? [void 0, { debugName: "caretPosition" }] : /* istanbul ignore next */ []);
	caretVisible = input(...ngDevMode ? [void 0, { debugName: "caretVisible" }] : /* istanbul ignore next */ []);
	direction = input(...ngDevMode ? [void 0, { debugName: "direction" }] : /* istanbul ignore next */ []);
	isExpanded = input(...ngDevMode ? [void 0, { debugName: "isExpanded" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	ripple = input(...ngDevMode ? [void 0, { debugName: "ripple" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	enter = input(...ngDevMode ? [void 0, { debugName: "enter" }] : /* istanbul ignore next */ []);
	exit = input(...ngDevMode ? [void 0, { debugName: "exit" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	appearance = input(...ngDevMode ? [void 0, { debugName: "appearance" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	expanded = output();
	collapsed = output();
	toggled = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			expanded: this.expanded,
			collapsed: this.collapsed,
			toggled: this.toggled,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(EXPANDER_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	toggle(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "toggle", args);
	}
	expand(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "expand", args);
	}
	collapse(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "collapse", args);
	}
	play(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "play", args);
	}
	onEnterAnimation(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onEnterAnimation", args);
	}
	onExitAnimation(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onExitAnimation", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const headerValue = this.header();
			if (headerValue !== void 0) this._elementRef.nativeElement.header = headerValue;
			const subHeaderValue = this.subHeader();
			if (subHeaderValue !== void 0) this._elementRef.nativeElement.subHeader = subHeaderValue;
			const iconValue = this.icon();
			if (iconValue !== void 0) this._elementRef.nativeElement.icon = iconValue;
			const caretPositionValue = this.caretPosition();
			if (caretPositionValue !== void 0) this._elementRef.nativeElement.caretPosition = caretPositionValue;
			const caretVisibleValue = this.caretVisible();
			if (caretVisibleValue !== void 0) this._elementRef.nativeElement.caretVisible = caretVisibleValue;
			const directionValue = this.direction();
			if (directionValue !== void 0) this._elementRef.nativeElement.direction = directionValue;
			const isExpandedValue = this.isExpanded();
			if (isExpandedValue !== void 0) this._elementRef.nativeElement.isExpanded = isExpandedValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const rippleValue = this.ripple();
			if (rippleValue !== void 0) this._elementRef.nativeElement.ripple = rippleValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const enterValue = this.enter();
			if (enterValue !== void 0) this._elementRef.nativeElement.enter = enterValue;
			const exitValue = this.exit();
			if (exitValue !== void 0) this._elementRef.nativeElement.exit = exitValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const appearanceValue = this.appearance();
			if (appearanceValue !== void 0) this._elementRef.nativeElement.appearance = appearanceValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ExpanderComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: ExpanderComponent,
		isStandalone: true,
		selector: "mosaik-expander",
		inputs: {
			header: {
				classPropertyName: "header",
				publicName: "header",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			subHeader: {
				classPropertyName: "subHeader",
				publicName: "subHeader",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			icon: {
				classPropertyName: "icon",
				publicName: "icon",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			caretPosition: {
				classPropertyName: "caretPosition",
				publicName: "caretPosition",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			caretVisible: {
				classPropertyName: "caretVisible",
				publicName: "caretVisible",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			direction: {
				classPropertyName: "direction",
				publicName: "direction",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isExpanded: {
				classPropertyName: "isExpanded",
				publicName: "isExpanded",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			ripple: {
				classPropertyName: "ripple",
				publicName: "ripple",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			enter: {
				classPropertyName: "enter",
				publicName: "enter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			exit: {
				classPropertyName: "exit",
				publicName: "exit",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			expanded: "expanded",
			collapsed: "collapsed",
			toggled: "toggled",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
ExpanderComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-expander", ExpanderElement),
	inputs: [
		"header",
		"subHeader",
		"icon",
		"caretPosition",
		"caretVisible",
		"direction",
		"isExpanded",
		"themeName",
		"ripple",
		"disabled",
		"enter",
		"exit",
		"variant",
		"appearance",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], ExpanderComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ExpanderComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-expander",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		header: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "header",
				required: false
			}]
		}],
		subHeader: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "subHeader",
				required: false
			}]
		}],
		icon: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "icon",
				required: false
			}]
		}],
		caretPosition: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "caretPosition",
				required: false
			}]
		}],
		caretVisible: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "caretVisible",
				required: false
			}]
		}],
		direction: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "direction",
				required: false
			}]
		}],
		isExpanded: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isExpanded",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		ripple: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "ripple",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		enter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "enter",
				required: false
			}]
		}],
		exit: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "exit",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		expanded: [{
			type: i0.Output,
			args: ["expanded"]
		}],
		collapsed: [{
			type: i0.Output,
			args: ["collapsed"]
		}],
		toggled: [{
			type: i0.Output,
			args: ["toggled"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideExpanderComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: EXPANDER_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { EXPANDER_DEFAULT_PROPS, EXPANDER_GROUP_DEFAULT_PROPS, EXPANDER_HEADER_DEFAULT_PROPS, EXPANDER_SUB_HEADER_DEFAULT_PROPS, ExpanderComponent, ExpanderGroupComponent, ExpanderHeaderComponent, ExpanderSubHeaderComponent, provideExpanderComponent, provideExpanderGroupComponent, provideExpanderHeaderComponent, provideExpanderSubHeaderComponent };

//# sourceMappingURL=mosaik-elements-angular-components-expander.mjs.map