import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { GlobeElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/illustrations/globe/GlobeElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const GLOBE_DEFAULT_PROPS = new InjectionToken("MOSAIK_GLOBE_DEFAULT_PROPS");
let GlobeComponent = class GlobeComponent {
	duration = input(...ngDevMode ? [void 0, { debugName: "duration" }] : /* istanbul ignore next */ []);
	tilt = input(...ngDevMode ? [void 0, { debugName: "tilt" }] : /* istanbul ignore next */ []);
	density = input(...ngDevMode ? [void 0, { debugName: "density" }] : /* istanbul ignore next */ []);
	locations = input(...ngDevMode ? [void 0, { debugName: "locations" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(GLOBE_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const durationValue = this.duration();
			if (durationValue !== void 0) this._elementRef.nativeElement.duration = durationValue;
			const tiltValue = this.tilt();
			if (tiltValue !== void 0) this._elementRef.nativeElement.tilt = tiltValue;
			const densityValue = this.density();
			if (densityValue !== void 0) this._elementRef.nativeElement.density = densityValue;
			const locationsValue = this.locations();
			if (locationsValue !== void 0) this._elementRef.nativeElement.locations = locationsValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: GlobeComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: GlobeComponent,
		isStandalone: true,
		selector: "mosaik-globe",
		inputs: {
			duration: {
				classPropertyName: "duration",
				publicName: "duration",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			tilt: {
				classPropertyName: "tilt",
				publicName: "tilt",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			density: {
				classPropertyName: "density",
				publicName: "density",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			locations: {
				classPropertyName: "locations",
				publicName: "locations",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
GlobeComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-globe", GlobeElement),
	inputs: [
		"duration",
		"tilt",
		"density",
		"locations",
		"themeName",
		"variant",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], GlobeComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: GlobeComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-globe",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		duration: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "duration",
				required: false
			}]
		}],
		tilt: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tilt",
				required: false
			}]
		}],
		density: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "density",
				required: false
			}]
		}],
		locations: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "locations",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideGlobeComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: GLOBE_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { GLOBE_DEFAULT_PROPS, GlobeComponent, provideGlobeComponent };

//# sourceMappingURL=mosaik-elements-angular-components-globe.mjs.map