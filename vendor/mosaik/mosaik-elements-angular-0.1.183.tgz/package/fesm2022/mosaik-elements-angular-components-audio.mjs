import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { AudioElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/audio/AudioElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const AUDIO_DEFAULT_PROPS = new InjectionToken("MOSAIK_AUDIO_DEFAULT_PROPS");
let AudioComponent = class AudioComponent {
	src = input(...ngDevMode ? [void 0, { debugName: "src" }] : /* istanbul ignore next */ []);
	autoPlay = input(...ngDevMode ? [void 0, { debugName: "autoPlay" }] : /* istanbul ignore next */ []);
	showControls = input(...ngDevMode ? [void 0, { debugName: "showControls" }] : /* istanbul ignore next */ []);
	legend = input(...ngDevMode ? [void 0, { debugName: "legend" }] : /* istanbul ignore next */ []);
	legendPosition = input(...ngDevMode ? [void 0, { debugName: "legendPosition" }] : /* istanbul ignore next */ []);
	ratio = input(...ngDevMode ? [void 0, { debugName: "ratio" }] : /* istanbul ignore next */ []);
	muted = input(...ngDevMode ? [void 0, { debugName: "muted" }] : /* istanbul ignore next */ []);
	loop = input(...ngDevMode ? [void 0, { debugName: "loop" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	width = input(...ngDevMode ? [void 0, { debugName: "width" }] : /* istanbul ignore next */ []);
	height = input(...ngDevMode ? [void 0, { debugName: "height" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(AUDIO_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	play(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "play", args);
	}
	pause(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "pause", args);
	}
	toggle(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "toggle", args);
	}
	load(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "load", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const srcValue = this.src();
			if (srcValue !== void 0) this._elementRef.nativeElement.src = srcValue;
			const autoPlayValue = this.autoPlay();
			if (autoPlayValue !== void 0) this._elementRef.nativeElement.autoPlay = autoPlayValue;
			const showControlsValue = this.showControls();
			if (showControlsValue !== void 0) this._elementRef.nativeElement.showControls = showControlsValue;
			const legendValue = this.legend();
			if (legendValue !== void 0) this._elementRef.nativeElement.legend = legendValue;
			const legendPositionValue = this.legendPosition();
			if (legendPositionValue !== void 0) this._elementRef.nativeElement.legendPosition = legendPositionValue;
			const ratioValue = this.ratio();
			if (ratioValue !== void 0) this._elementRef.nativeElement.ratio = ratioValue;
			const mutedValue = this.muted();
			if (mutedValue !== void 0) this._elementRef.nativeElement.muted = mutedValue;
			const loopValue = this.loop();
			if (loopValue !== void 0) this._elementRef.nativeElement.loop = loopValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const widthValue = this.width();
			if (widthValue !== void 0) this._elementRef.nativeElement.width = widthValue;
			const heightValue = this.height();
			if (heightValue !== void 0) this._elementRef.nativeElement.height = heightValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: AudioComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: AudioComponent,
		isStandalone: true,
		selector: "mosaik-audio",
		inputs: {
			src: {
				classPropertyName: "src",
				publicName: "src",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			autoPlay: {
				classPropertyName: "autoPlay",
				publicName: "autoPlay",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showControls: {
				classPropertyName: "showControls",
				publicName: "showControls",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			legend: {
				classPropertyName: "legend",
				publicName: "legend",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			legendPosition: {
				classPropertyName: "legendPosition",
				publicName: "legendPosition",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			ratio: {
				classPropertyName: "ratio",
				publicName: "ratio",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			muted: {
				classPropertyName: "muted",
				publicName: "muted",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			loop: {
				classPropertyName: "loop",
				publicName: "loop",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			width: {
				classPropertyName: "width",
				publicName: "width",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			height: {
				classPropertyName: "height",
				publicName: "height",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
AudioComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-audio", AudioElement),
	inputs: [
		"src",
		"autoPlay",
		"showControls",
		"legend",
		"legendPosition",
		"ratio",
		"muted",
		"loop",
		"themeName",
		"disabled",
		"width",
		"height",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], AudioComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: AudioComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-audio",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		src: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "src",
				required: false
			}]
		}],
		autoPlay: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "autoPlay",
				required: false
			}]
		}],
		showControls: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showControls",
				required: false
			}]
		}],
		legend: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "legend",
				required: false
			}]
		}],
		legendPosition: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "legendPosition",
				required: false
			}]
		}],
		ratio: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "ratio",
				required: false
			}]
		}],
		muted: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "muted",
				required: false
			}]
		}],
		loop: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "loop",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		width: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "width",
				required: false
			}]
		}],
		height: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "height",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideAudioComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: AUDIO_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { AUDIO_DEFAULT_PROPS, AudioComponent, provideAudioComponent };

//# sourceMappingURL=mosaik-elements-angular-components-audio.mjs.map