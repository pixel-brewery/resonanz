import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, forwardRef, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { PromptBoxAttachmentListElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/prompt-box/attachments/PromptBoxAttachmentListElement";
import * as i1 from "@pixel-brewery/mosaik-elements-angular/runtime";
import { FORM_STATUS_HOST, FormFieldStatusHostDirective, FormStatusHostDirective, ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { PromptBoxAttachmentToolElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/prompt-box/tools/PromptBoxAttachmentToolElement";
import { PromptBoxQueueElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/prompt-box/queue/PromptBoxQueueElement";
import { PromptBoxVoiceRecorderToolElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/prompt-box/tools/PromptBoxVoiceRecorderToolElement";
import { NG_VALUE_ACCESSOR } from "@angular/forms";
import { PromptBoxElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/prompt-box/PromptBoxElement";
import { promptBoxElementValueAccessor } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/prompt-box/accessors/PromptBoxElementValueAccessor";
var __decorate$4 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$4 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const PROMPT_BOX_ATTACHMENT_LIST_DEFAULT_PROPS = new InjectionToken("MOSAIK_PROMPT_BOX_ATTACHMENT_LIST_DEFAULT_PROPS");
let PromptBoxAttachmentListComponent = class PromptBoxAttachmentListComponent {
	entries = input(...ngDevMode ? [void 0, { debugName: "entries" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	appearance = input(...ngDevMode ? [void 0, { debugName: "appearance" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	attachmentRemove = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			attachmentRemove: this.attachmentRemove,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(PROMPT_BOX_ATTACHMENT_LIST_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	assignToSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "assignToSlot", args);
	}
	getSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getSlotContent", args);
	}
	hasSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlotContent", args);
	}
	hasSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlot", args);
	}
	onSlotChanges(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onSlotChanges", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const entriesValue = this.entries();
			if (entriesValue !== void 0) this._elementRef.nativeElement.entries = entriesValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const appearanceValue = this.appearance();
			if (appearanceValue !== void 0) this._elementRef.nativeElement.appearance = appearanceValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: PromptBoxAttachmentListComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: PromptBoxAttachmentListComponent,
		isStandalone: true,
		selector: "mosaik-prompt-box-attachment-list",
		inputs: {
			entries: {
				classPropertyName: "entries",
				publicName: "entries",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			attachmentRemove: "attachmentRemove",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
PromptBoxAttachmentListComponent = __decorate$4([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-prompt-box-attachment-list", PromptBoxAttachmentListElement),
	inputs: [
		"entries",
		"themeName",
		"variant",
		"appearance",
		"disabled",
		"dir",
		"lang"
	],
	methods: ["getSlotAssignments", "getSlotAssignmentsOf"]
}), __metadata$4("design:paramtypes", [])], PromptBoxAttachmentListComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: PromptBoxAttachmentListComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-prompt-box-attachment-list",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		entries: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "entries",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		attachmentRemove: [{
			type: i0.Output,
			args: ["attachmentRemove"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function providePromptBoxAttachmentListComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: PROMPT_BOX_ATTACHMENT_LIST_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$3 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$3 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const PROMPT_BOX_ATTACHMENT_TOOL_DEFAULT_PROPS = new InjectionToken("MOSAIK_PROMPT_BOX_ATTACHMENT_TOOL_DEFAULT_PROPS");
const PROMPT_BOX_ATTACHMENT_TOOL_INTL = new InjectionToken("MOSAIK_PROMPT_BOX_ATTACHMENT_TOOL_INTL");
let PromptBoxAttachmentToolComponent = class PromptBoxAttachmentToolComponent {
	multiple = input(...ngDevMode ? [void 0, { debugName: "multiple" }] : /* istanbul ignore next */ []);
	accept = input(...ngDevMode ? [void 0, { debugName: "accept" }] : /* istanbul ignore next */ []);
	directory = input(...ngDevMode ? [void 0, { debugName: "directory" }] : /* istanbul ignore next */ []);
	intl = input(...ngDevMode ? [void 0, { debugName: "intl" }] : /* istanbul ignore next */ []);
	maxFiles = input(...ngDevMode ? [void 0, { debugName: "maxFiles" }] : /* istanbul ignore next */ []);
	maxFileSize = input(...ngDevMode ? [void 0, { debugName: "maxFileSize" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dock = input(...ngDevMode ? [void 0, { debugName: "dock" }] : /* istanbul ignore next */ []);
	disabledWhen = input(...ngDevMode ? [void 0, { debugName: "disabledWhen" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	attachmentReject = output();
	filesPicked = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			attachmentReject: this.attachmentReject,
			filesPicked: this.filesPicked,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(PROMPT_BOX_ATTACHMENT_TOOL_DEFAULT_PROPS, { optional: true }) ?? {}, ["intl"]);
		const injectedIntl = inject(PROMPT_BOX_ATTACHMENT_TOOL_INTL, { optional: true });
		if (injectedIntl) {
			Object.assign(this._elementRef.nativeElement.intl, injectedIntl);
			this._elementRef.nativeElement.intl.changes.emit();
		}
	}
	execute(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "execute", args);
	}
	attach(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "attach", args);
	}
	detach(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "detach", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const multipleValue = this.multiple();
			if (multipleValue !== void 0) this._elementRef.nativeElement.multiple = multipleValue;
			const acceptValue = this.accept();
			if (acceptValue !== void 0) this._elementRef.nativeElement.accept = acceptValue;
			const directoryValue = this.directory();
			if (directoryValue !== void 0) this._elementRef.nativeElement.directory = directoryValue;
			const maxFilesValue = this.maxFiles();
			if (maxFilesValue !== void 0) this._elementRef.nativeElement.maxFiles = maxFilesValue;
			const maxFileSizeValue = this.maxFileSize();
			if (maxFileSizeValue !== void 0) this._elementRef.nativeElement.maxFileSize = maxFileSizeValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dockValue = this.dock();
			if (dockValue !== void 0) this._elementRef.nativeElement.dock = dockValue;
			const disabledWhenValue = this.disabledWhen();
			if (disabledWhenValue !== void 0) this._elementRef.nativeElement.disabledWhen = disabledWhenValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
			const intlValue = this.intl();
			if (intlValue !== void 0) {
				Object.assign(this._elementRef.nativeElement.intl, intlValue);
				this._elementRef.nativeElement.intl.changes.emit();
			}
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: PromptBoxAttachmentToolComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: PromptBoxAttachmentToolComponent,
		isStandalone: true,
		selector: "mosaik-prompt-box-attachment-tool",
		inputs: {
			multiple: {
				classPropertyName: "multiple",
				publicName: "multiple",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			accept: {
				classPropertyName: "accept",
				publicName: "accept",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			directory: {
				classPropertyName: "directory",
				publicName: "directory",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			intl: {
				classPropertyName: "intl",
				publicName: "intl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			maxFiles: {
				classPropertyName: "maxFiles",
				publicName: "maxFiles",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			maxFileSize: {
				classPropertyName: "maxFileSize",
				publicName: "maxFileSize",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dock: {
				classPropertyName: "dock",
				publicName: "dock",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabledWhen: {
				classPropertyName: "disabledWhen",
				publicName: "disabledWhen",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			attachmentReject: "attachmentReject",
			filesPicked: "filesPicked",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
PromptBoxAttachmentToolComponent = __decorate$3([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-prompt-box-attachment-tool", PromptBoxAttachmentToolElement),
	inputs: [
		"multiple",
		"accept",
		"directory",
		"intl",
		"maxFiles",
		"maxFileSize",
		"themeName",
		"dock",
		"disabledWhen",
		"disabled",
		"dir",
		"lang"
	]
}), __metadata$3("design:paramtypes", [])], PromptBoxAttachmentToolComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: PromptBoxAttachmentToolComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-prompt-box-attachment-tool",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		multiple: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "multiple",
				required: false
			}]
		}],
		accept: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "accept",
				required: false
			}]
		}],
		directory: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "directory",
				required: false
			}]
		}],
		intl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "intl",
				required: false
			}]
		}],
		maxFiles: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maxFiles",
				required: false
			}]
		}],
		maxFileSize: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maxFileSize",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dock: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dock",
				required: false
			}]
		}],
		disabledWhen: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabledWhen",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		attachmentReject: [{
			type: i0.Output,
			args: ["attachmentReject"]
		}],
		filesPicked: [{
			type: i0.Output,
			args: ["filesPicked"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function providePromptBoxAttachmentToolComponent(config, intl) {
	const providers = [];
	if (config) providers.push({
		provide: PROMPT_BOX_ATTACHMENT_TOOL_DEFAULT_PROPS,
		useValue: config
	});
	if (intl) {
		if (typeof intl === "function") providers.push({
			provide: PROMPT_BOX_ATTACHMENT_TOOL_INTL,
			useClass: intl
		});
		else providers.push({
			provide: PROMPT_BOX_ATTACHMENT_TOOL_INTL,
			useValue: intl
		});
	}
	return makeEnvironmentProviders(providers);
}
var __decorate$2 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$2 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const PROMPT_BOX_QUEUE_DEFAULT_PROPS = new InjectionToken("MOSAIK_PROMPT_BOX_QUEUE_DEFAULT_PROPS");
const PROMPT_BOX_QUEUE_INTL = new InjectionToken("MOSAIK_PROMPT_BOX_QUEUE_INTL");
let PromptBoxQueueComponent = class PromptBoxQueueComponent {
	intl = input(...ngDevMode ? [void 0, { debugName: "intl" }] : /* istanbul ignore next */ []);
	entries = input(...ngDevMode ? [void 0, { debugName: "entries" }] : /* istanbul ignore next */ []);
	reorderable = input(...ngDevMode ? [void 0, { debugName: "reorderable" }] : /* istanbul ignore next */ []);
	steerable = input(...ngDevMode ? [void 0, { debugName: "steerable" }] : /* istanbul ignore next */ []);
	editable = input(...ngDevMode ? [void 0, { debugName: "editable" }] : /* istanbul ignore next */ []);
	pausable = input(...ngDevMode ? [void 0, { debugName: "pausable" }] : /* istanbul ignore next */ []);
	actions = input(...ngDevMode ? [void 0, { debugName: "actions" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	appearance = input(...ngDevMode ? [void 0, { debugName: "appearance" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(PROMPT_BOX_QUEUE_DEFAULT_PROPS, { optional: true }) ?? {}, ["intl"]);
		const injectedIntl = inject(PROMPT_BOX_QUEUE_INTL, { optional: true });
		if (injectedIntl) {
			Object.assign(this._elementRef.nativeElement.intl, injectedIntl);
			this._elementRef.nativeElement.intl.changes.emit();
		}
	}
	assignToSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "assignToSlot", args);
	}
	getSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getSlotContent", args);
	}
	hasSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlotContent", args);
	}
	hasSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlot", args);
	}
	onSlotChanges(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onSlotChanges", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const entriesValue = this.entries();
			if (entriesValue !== void 0) this._elementRef.nativeElement.entries = entriesValue;
			const reorderableValue = this.reorderable();
			if (reorderableValue !== void 0) this._elementRef.nativeElement.reorderable = reorderableValue;
			const steerableValue = this.steerable();
			if (steerableValue !== void 0) this._elementRef.nativeElement.steerable = steerableValue;
			const editableValue = this.editable();
			if (editableValue !== void 0) this._elementRef.nativeElement.editable = editableValue;
			const pausableValue = this.pausable();
			if (pausableValue !== void 0) this._elementRef.nativeElement.pausable = pausableValue;
			const actionsValue = this.actions();
			if (actionsValue !== void 0) this._elementRef.nativeElement.actions = actionsValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const appearanceValue = this.appearance();
			if (appearanceValue !== void 0) this._elementRef.nativeElement.appearance = appearanceValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
			const intlValue = this.intl();
			if (intlValue !== void 0) {
				Object.assign(this._elementRef.nativeElement.intl, intlValue);
				this._elementRef.nativeElement.intl.changes.emit();
			}
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: PromptBoxQueueComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: PromptBoxQueueComponent,
		isStandalone: true,
		selector: "mosaik-prompt-box-queue",
		inputs: {
			intl: {
				classPropertyName: "intl",
				publicName: "intl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			entries: {
				classPropertyName: "entries",
				publicName: "entries",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			reorderable: {
				classPropertyName: "reorderable",
				publicName: "reorderable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			steerable: {
				classPropertyName: "steerable",
				publicName: "steerable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			editable: {
				classPropertyName: "editable",
				publicName: "editable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			pausable: {
				classPropertyName: "pausable",
				publicName: "pausable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			actions: {
				classPropertyName: "actions",
				publicName: "actions",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
PromptBoxQueueComponent = __decorate$2([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-prompt-box-queue", PromptBoxQueueElement),
	inputs: [
		"intl",
		"entries",
		"reorderable",
		"steerable",
		"editable",
		"pausable",
		"actions",
		"themeName",
		"variant",
		"appearance",
		"disabled",
		"dir",
		"lang"
	],
	methods: ["getSlotAssignments", "getSlotAssignmentsOf"]
}), __metadata$2("design:paramtypes", [])], PromptBoxQueueComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: PromptBoxQueueComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-prompt-box-queue",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		intl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "intl",
				required: false
			}]
		}],
		entries: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "entries",
				required: false
			}]
		}],
		reorderable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "reorderable",
				required: false
			}]
		}],
		steerable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "steerable",
				required: false
			}]
		}],
		editable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "editable",
				required: false
			}]
		}],
		pausable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "pausable",
				required: false
			}]
		}],
		actions: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "actions",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function providePromptBoxQueueComponent(config, intl) {
	const providers = [];
	if (config) providers.push({
		provide: PROMPT_BOX_QUEUE_DEFAULT_PROPS,
		useValue: config
	});
	if (intl) {
		if (typeof intl === "function") providers.push({
			provide: PROMPT_BOX_QUEUE_INTL,
			useClass: intl
		});
		else providers.push({
			provide: PROMPT_BOX_QUEUE_INTL,
			useValue: intl
		});
	}
	return makeEnvironmentProviders(providers);
}
var __decorate$1 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$1 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const PROMPT_BOX_VOICE_RECORDER_TOOL_DEFAULT_PROPS = new InjectionToken("MOSAIK_PROMPT_BOX_VOICE_RECORDER_TOOL_DEFAULT_PROPS");
const PROMPT_BOX_VOICE_RECORDER_TOOL_INTL = new InjectionToken("MOSAIK_PROMPT_BOX_VOICE_RECORDER_TOOL_INTL");
let PromptBoxVoiceRecorderToolComponent = class PromptBoxVoiceRecorderToolComponent {
	intl = input(...ngDevMode ? [void 0, { debugName: "intl" }] : /* istanbul ignore next */ []);
	state = input(...ngDevMode ? [void 0, { debugName: "state" }] : /* istanbul ignore next */ []);
	elapsedTime = input(...ngDevMode ? [void 0, { debugName: "elapsedTime" }] : /* istanbul ignore next */ []);
	maxDurationTime = input(...ngDevMode ? [void 0, { debugName: "maxDurationTime" }] : /* istanbul ignore next */ []);
	objectUrl = input(...ngDevMode ? [void 0, { debugName: "objectUrl" }] : /* istanbul ignore next */ []);
	canPause = input(...ngDevMode ? [void 0, { debugName: "canPause" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dock = input(...ngDevMode ? [void 0, { debugName: "dock" }] : /* istanbul ignore next */ []);
	disabledWhen = input(...ngDevMode ? [void 0, { debugName: "disabledWhen" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	recorderCancel = output();
	recorderPause = output();
	recorderResume = output();
	recorderStart = output();
	recorderStop = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			recorderCancel: this.recorderCancel,
			recorderPause: this.recorderPause,
			recorderResume: this.recorderResume,
			recorderStart: this.recorderStart,
			recorderStop: this.recorderStop,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(PROMPT_BOX_VOICE_RECORDER_TOOL_DEFAULT_PROPS, { optional: true }) ?? {}, ["intl"]);
		const injectedIntl = inject(PROMPT_BOX_VOICE_RECORDER_TOOL_INTL, { optional: true });
		if (injectedIntl) {
			Object.assign(this._elementRef.nativeElement.intl, injectedIntl);
			this._elementRef.nativeElement.intl.changes.emit();
		}
	}
	execute(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "execute", args);
	}
	attach(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "attach", args);
	}
	detach(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "detach", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const stateValue = this.state();
			if (stateValue !== void 0) this._elementRef.nativeElement.state = stateValue;
			const elapsedTimeValue = this.elapsedTime();
			if (elapsedTimeValue !== void 0) this._elementRef.nativeElement.elapsedTime = elapsedTimeValue;
			const maxDurationTimeValue = this.maxDurationTime();
			if (maxDurationTimeValue !== void 0) this._elementRef.nativeElement.maxDurationTime = maxDurationTimeValue;
			const objectUrlValue = this.objectUrl();
			if (objectUrlValue !== void 0) this._elementRef.nativeElement.objectUrl = objectUrlValue;
			const canPauseValue = this.canPause();
			if (canPauseValue !== void 0) this._elementRef.nativeElement.canPause = canPauseValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dockValue = this.dock();
			if (dockValue !== void 0) this._elementRef.nativeElement.dock = dockValue;
			const disabledWhenValue = this.disabledWhen();
			if (disabledWhenValue !== void 0) this._elementRef.nativeElement.disabledWhen = disabledWhenValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
			const intlValue = this.intl();
			if (intlValue !== void 0) {
				Object.assign(this._elementRef.nativeElement.intl, intlValue);
				this._elementRef.nativeElement.intl.changes.emit();
			}
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: PromptBoxVoiceRecorderToolComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: PromptBoxVoiceRecorderToolComponent,
		isStandalone: true,
		selector: "mosaik-prompt-box-voice-recorder-tool",
		inputs: {
			intl: {
				classPropertyName: "intl",
				publicName: "intl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			state: {
				classPropertyName: "state",
				publicName: "state",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			elapsedTime: {
				classPropertyName: "elapsedTime",
				publicName: "elapsedTime",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			maxDurationTime: {
				classPropertyName: "maxDurationTime",
				publicName: "maxDurationTime",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			objectUrl: {
				classPropertyName: "objectUrl",
				publicName: "objectUrl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			canPause: {
				classPropertyName: "canPause",
				publicName: "canPause",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dock: {
				classPropertyName: "dock",
				publicName: "dock",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabledWhen: {
				classPropertyName: "disabledWhen",
				publicName: "disabledWhen",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			recorderCancel: "recorderCancel",
			recorderPause: "recorderPause",
			recorderResume: "recorderResume",
			recorderStart: "recorderStart",
			recorderStop: "recorderStop",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
PromptBoxVoiceRecorderToolComponent = __decorate$1([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-prompt-box-voice-recorder-tool", PromptBoxVoiceRecorderToolElement),
	inputs: [
		"intl",
		"state",
		"elapsedTime",
		"maxDurationTime",
		"objectUrl",
		"canPause",
		"themeName",
		"dock",
		"disabledWhen",
		"disabled",
		"dir",
		"lang"
	]
}), __metadata$1("design:paramtypes", [])], PromptBoxVoiceRecorderToolComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: PromptBoxVoiceRecorderToolComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-prompt-box-voice-recorder-tool",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		intl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "intl",
				required: false
			}]
		}],
		state: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "state",
				required: false
			}]
		}],
		elapsedTime: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "elapsedTime",
				required: false
			}]
		}],
		maxDurationTime: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maxDurationTime",
				required: false
			}]
		}],
		objectUrl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "objectUrl",
				required: false
			}]
		}],
		canPause: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "canPause",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dock: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dock",
				required: false
			}]
		}],
		disabledWhen: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabledWhen",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		recorderCancel: [{
			type: i0.Output,
			args: ["recorderCancel"]
		}],
		recorderPause: [{
			type: i0.Output,
			args: ["recorderPause"]
		}],
		recorderResume: [{
			type: i0.Output,
			args: ["recorderResume"]
		}],
		recorderStart: [{
			type: i0.Output,
			args: ["recorderStart"]
		}],
		recorderStop: [{
			type: i0.Output,
			args: ["recorderStop"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function providePromptBoxVoiceRecorderToolComponent(config, intl) {
	const providers = [];
	if (config) providers.push({
		provide: PROMPT_BOX_VOICE_RECORDER_TOOL_DEFAULT_PROPS,
		useValue: config
	});
	if (intl) {
		if (typeof intl === "function") providers.push({
			provide: PROMPT_BOX_VOICE_RECORDER_TOOL_INTL,
			useClass: intl
		});
		else providers.push({
			provide: PROMPT_BOX_VOICE_RECORDER_TOOL_INTL,
			useValue: intl
		});
	}
	return makeEnvironmentProviders(providers);
}
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const PROMPT_BOX_DEFAULT_PROPS = new InjectionToken("MOSAIK_PROMPT_BOX_DEFAULT_PROPS");
const PROMPT_BOX_INTL = new InjectionToken("MOSAIK_PROMPT_BOX_INTL");
let PromptBoxComponent = class PromptBoxComponent {
	label = input(...ngDevMode ? [void 0, { debugName: "label" }] : /* istanbul ignore next */ []);
	intl = input(...ngDevMode ? [void 0, { debugName: "intl" }] : /* istanbul ignore next */ []);
	value = input(...ngDevMode ? [void 0, { debugName: "value" }] : /* istanbul ignore next */ []);
	mentionDocument = input(...ngDevMode ? [void 0, { debugName: "mentionDocument" }] : /* istanbul ignore next */ []);
	suggestions = input(...ngDevMode ? [void 0, { debugName: "suggestions" }] : /* istanbul ignore next */ []);
	entries = input(...ngDevMode ? [void 0, { debugName: "entries" }] : /* istanbul ignore next */ []);
	queue = input(...ngDevMode ? [void 0, { debugName: "queue" }] : /* istanbul ignore next */ []);
	queueOnBusy = input(...ngDevMode ? [void 0, { debugName: "queueOnBusy" }] : /* istanbul ignore next */ []);
	queuePaused = input(...ngDevMode ? [void 0, { debugName: "queuePaused" }] : /* istanbul ignore next */ []);
	tools = input(...ngDevMode ? [void 0, { debugName: "tools" }] : /* istanbul ignore next */ []);
	placeholder = input(...ngDevMode ? [void 0, { debugName: "placeholder" }] : /* istanbul ignore next */ []);
	minRows = input(...ngDevMode ? [void 0, { debugName: "minRows" }] : /* istanbul ignore next */ []);
	maxRows = input(...ngDevMode ? [void 0, { debugName: "maxRows" }] : /* istanbul ignore next */ []);
	showSubmitButton = input(...ngDevMode ? [void 0, { debugName: "showSubmitButton" }] : /* istanbul ignore next */ []);
	submitOnEnter = input(...ngDevMode ? [void 0, { debugName: "submitOnEnter" }] : /* istanbul ignore next */ []);
	readonly = input(...ngDevMode ? [void 0, { debugName: "readonly" }] : /* istanbul ignore next */ []);
	required = input(...ngDevMode ? [void 0, { debugName: "required" }] : /* istanbul ignore next */ []);
	autofocus = input(...ngDevMode ? [void 0, { debugName: "autofocus" }] : /* istanbul ignore next */ []);
	name = input(...ngDevMode ? [void 0, { debugName: "name" }] : /* istanbul ignore next */ []);
	minlength = input(...ngDevMode ? [void 0, { debugName: "minlength" }] : /* istanbul ignore next */ []);
	maxlength = input(...ngDevMode ? [void 0, { debugName: "maxlength" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	appearance = input(...ngDevMode ? [void 0, { debugName: "appearance" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	isBusy = input(...ngDevMode ? [void 0, { debugName: "isBusy" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	formatter = input(...ngDevMode ? [void 0, { debugName: "formatter" }] : /* istanbul ignore next */ []);
	parser = input(...ngDevMode ? [void 0, { debugName: "parser" }] : /* istanbul ignore next */ []);
	isFocused = input(...ngDevMode ? [void 0, { debugName: "isFocused" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	entriesChanged = output();
	promptQueued = output();
	promptSubmitted = output();
	queueChanged = output();
	stopRequested = output();
	steerRequested = output();
	queuePausedChanged = output();
	queueActionInvoked = output();
	suggestionSelected = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	_accessor;
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._accessor = promptBoxElementValueAccessor(this._elementRef.nativeElement);
		this._elementRef.nativeElement.addController(this._accessor);
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			entriesChanged: this.entriesChanged,
			promptQueued: this.promptQueued,
			promptSubmitted: this.promptSubmitted,
			queueChanged: this.queueChanged,
			stopRequested: this.stopRequested,
			steerRequested: this.steerRequested,
			queuePausedChanged: this.queuePausedChanged,
			queueActionInvoked: this.queueActionInvoked,
			suggestionSelected: this.suggestionSelected,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
			this._accessor.releaseCallbacks();
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(PROMPT_BOX_DEFAULT_PROPS, { optional: true }) ?? {}, ["intl"]);
		const injectedIntl = inject(PROMPT_BOX_INTL, { optional: true });
		if (injectedIntl) {
			Object.assign(this._elementRef.nativeElement.intl, injectedIntl);
			this._elementRef.nativeElement.intl.changes.emit();
		}
	}
	writeValue(obj) {
		this._accessor.writeValue(obj);
	}
	registerOnChange(fn) {
		this._accessor.registerOnChange(fn);
	}
	registerOnTouched(fn) {
		this._accessor.registerOnTouched(fn);
	}
	setDisabledState(isDisabled) {
		this._accessor.setDisabled?.(isDisabled);
	}
	registerTool(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "registerTool", args);
	}
	unregisterTool(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "unregisterTool", args);
	}
	addEntry(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "addEntry", args);
	}
	updateEntry(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "updateEntry", args);
	}
	removeEntry(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "removeEntry", args);
	}
	clearEntries(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "clearEntries", args);
	}
	enqueue(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "enqueue", args);
	}
	dequeue(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "dequeue", args);
	}
	peekQueue(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "peekQueue", args);
	}
	removeQueued(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "removeQueued", args);
	}
	moveQueued(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "moveQueued", args);
	}
	clearQueue(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "clearQueue", args);
	}
	steerQueued(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "steerQueued", args);
	}
	editQueued(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "editQueued", args);
	}
	invokeQueuedAction(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "invokeQueuedAction", args);
	}
	clear(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "clear", args);
	}
	reset(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "reset", args);
	}
	checkValidity(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "checkValidity", args);
	}
	submit(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "submit", args);
	}
	stop(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "stop", args);
	}
	focus(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "focus", args);
	}
	blur(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "blur", args);
	}
	onSlotChanges(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onSlotChanges", args);
	}
	assignToSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "assignToSlot", args);
	}
	getSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getSlotContent", args);
	}
	hasSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlotContent", args);
	}
	hasSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlot", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const labelValue = this.label();
			if (labelValue !== void 0) this._elementRef.nativeElement.label = labelValue;
			const valueValue = this.value();
			if (valueValue !== void 0) this._elementRef.nativeElement.value = valueValue;
			const mentionDocumentValue = this.mentionDocument();
			if (mentionDocumentValue !== void 0) this._elementRef.nativeElement.mentionDocument = mentionDocumentValue;
			const suggestionsValue = this.suggestions();
			if (suggestionsValue !== void 0) this._elementRef.nativeElement.suggestions = suggestionsValue;
			const entriesValue = this.entries();
			if (entriesValue !== void 0) this._elementRef.nativeElement.entries = entriesValue;
			const queueValue = this.queue();
			if (queueValue !== void 0) this._elementRef.nativeElement.queue = queueValue;
			const queueOnBusyValue = this.queueOnBusy();
			if (queueOnBusyValue !== void 0) this._elementRef.nativeElement.queueOnBusy = queueOnBusyValue;
			const queuePausedValue = this.queuePaused();
			if (queuePausedValue !== void 0) this._elementRef.nativeElement.queuePaused = queuePausedValue;
			const toolsValue = this.tools();
			if (toolsValue !== void 0) this._elementRef.nativeElement.tools = toolsValue;
			const placeholderValue = this.placeholder();
			if (placeholderValue !== void 0) this._elementRef.nativeElement.placeholder = placeholderValue;
			const minRowsValue = this.minRows();
			if (minRowsValue !== void 0) this._elementRef.nativeElement.minRows = minRowsValue;
			const maxRowsValue = this.maxRows();
			if (maxRowsValue !== void 0) this._elementRef.nativeElement.maxRows = maxRowsValue;
			const showSubmitButtonValue = this.showSubmitButton();
			if (showSubmitButtonValue !== void 0) this._elementRef.nativeElement.showSubmitButton = showSubmitButtonValue;
			const submitOnEnterValue = this.submitOnEnter();
			if (submitOnEnterValue !== void 0) this._elementRef.nativeElement.submitOnEnter = submitOnEnterValue;
			const readonlyValue = this.readonly();
			if (readonlyValue !== void 0) this._elementRef.nativeElement.readonly = readonlyValue;
			const requiredValue = this.required();
			if (requiredValue !== void 0) this._elementRef.nativeElement.required = requiredValue;
			const autofocusValue = this.autofocus();
			if (autofocusValue !== void 0) this._elementRef.nativeElement.autofocus = autofocusValue;
			const nameValue = this.name();
			if (nameValue !== void 0) this._elementRef.nativeElement.name = nameValue;
			const minlengthValue = this.minlength();
			if (minlengthValue !== void 0) this._elementRef.nativeElement.minlength = minlengthValue;
			const maxlengthValue = this.maxlength();
			if (maxlengthValue !== void 0) this._elementRef.nativeElement.maxlength = maxlengthValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const appearanceValue = this.appearance();
			if (appearanceValue !== void 0) this._elementRef.nativeElement.appearance = appearanceValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const isBusyValue = this.isBusy();
			if (isBusyValue !== void 0) this._elementRef.nativeElement.isBusy = isBusyValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const formatterValue = this.formatter();
			if (formatterValue !== void 0) this._elementRef.nativeElement.formatter = formatterValue;
			const parserValue = this.parser();
			if (parserValue !== void 0) this._elementRef.nativeElement.parser = parserValue;
			const isFocusedValue = this.isFocused();
			if (isFocusedValue !== void 0) this._elementRef.nativeElement.isFocused = isFocusedValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
			const intlValue = this.intl();
			if (intlValue !== void 0) {
				Object.assign(this._elementRef.nativeElement.intl, intlValue);
				this._elementRef.nativeElement.intl.changes.emit();
			}
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: PromptBoxComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: PromptBoxComponent,
		isStandalone: true,
		selector: "mosaik-prompt-box",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			intl: {
				classPropertyName: "intl",
				publicName: "intl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			mentionDocument: {
				classPropertyName: "mentionDocument",
				publicName: "mentionDocument",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			suggestions: {
				classPropertyName: "suggestions",
				publicName: "suggestions",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			entries: {
				classPropertyName: "entries",
				publicName: "entries",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			queue: {
				classPropertyName: "queue",
				publicName: "queue",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			queueOnBusy: {
				classPropertyName: "queueOnBusy",
				publicName: "queueOnBusy",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			queuePaused: {
				classPropertyName: "queuePaused",
				publicName: "queuePaused",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			tools: {
				classPropertyName: "tools",
				publicName: "tools",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			placeholder: {
				classPropertyName: "placeholder",
				publicName: "placeholder",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			minRows: {
				classPropertyName: "minRows",
				publicName: "minRows",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			maxRows: {
				classPropertyName: "maxRows",
				publicName: "maxRows",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showSubmitButton: {
				classPropertyName: "showSubmitButton",
				publicName: "showSubmitButton",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			submitOnEnter: {
				classPropertyName: "submitOnEnter",
				publicName: "submitOnEnter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			readonly: {
				classPropertyName: "readonly",
				publicName: "readonly",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			required: {
				classPropertyName: "required",
				publicName: "required",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			autofocus: {
				classPropertyName: "autofocus",
				publicName: "autofocus",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			name: {
				classPropertyName: "name",
				publicName: "name",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			minlength: {
				classPropertyName: "minlength",
				publicName: "minlength",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			maxlength: {
				classPropertyName: "maxlength",
				publicName: "maxlength",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isBusy: {
				classPropertyName: "isBusy",
				publicName: "isBusy",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			formatter: {
				classPropertyName: "formatter",
				publicName: "formatter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			parser: {
				classPropertyName: "parser",
				publicName: "parser",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isFocused: {
				classPropertyName: "isFocused",
				publicName: "isFocused",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			entriesChanged: "entriesChanged",
			promptQueued: "promptQueued",
			promptSubmitted: "promptSubmitted",
			queueChanged: "queueChanged",
			stopRequested: "stopRequested",
			steerRequested: "steerRequested",
			queuePausedChanged: "queuePausedChanged",
			queueActionInvoked: "queueActionInvoked",
			suggestionSelected: "suggestionSelected",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		providers: [{
			provide: NG_VALUE_ACCESSOR,
			useExisting: forwardRef(() => PromptBoxComponent),
			multi: true
		}, {
			provide: FORM_STATUS_HOST,
			useExisting: forwardRef(() => PromptBoxComponent)
		}],
		hostDirectives: [{ directive: i1.FormStatusHostDirective }, { directive: i1.FormFieldStatusHostDirective }],
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
PromptBoxComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-prompt-box", PromptBoxElement),
	inputs: [
		"label",
		"intl",
		"value",
		"mentionDocument",
		"suggestions",
		"entries",
		"queue",
		"queueOnBusy",
		"queuePaused",
		"tools",
		"placeholder",
		"minRows",
		"maxRows",
		"showSubmitButton",
		"submitOnEnter",
		"readonly",
		"required",
		"autofocus",
		"name",
		"minlength",
		"maxlength",
		"themeName",
		"appearance",
		"variant",
		"isBusy",
		"disabled",
		"formatter",
		"parser",
		"isFocused",
		"dir",
		"lang"
	],
	methods: ["getSlotAssignments", "getSlotAssignmentsOf"]
}), __metadata("design:paramtypes", [])], PromptBoxComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: PromptBoxComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-prompt-box",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>",
			hostDirectives: [FormStatusHostDirective, FormFieldStatusHostDirective],
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => PromptBoxComponent),
				multi: true
			}, {
				provide: FORM_STATUS_HOST,
				useExisting: forwardRef(() => PromptBoxComponent)
			}]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		intl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "intl",
				required: false
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		mentionDocument: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mentionDocument",
				required: false
			}]
		}],
		suggestions: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "suggestions",
				required: false
			}]
		}],
		entries: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "entries",
				required: false
			}]
		}],
		queue: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "queue",
				required: false
			}]
		}],
		queueOnBusy: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "queueOnBusy",
				required: false
			}]
		}],
		queuePaused: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "queuePaused",
				required: false
			}]
		}],
		tools: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tools",
				required: false
			}]
		}],
		placeholder: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "placeholder",
				required: false
			}]
		}],
		minRows: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "minRows",
				required: false
			}]
		}],
		maxRows: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maxRows",
				required: false
			}]
		}],
		showSubmitButton: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showSubmitButton",
				required: false
			}]
		}],
		submitOnEnter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "submitOnEnter",
				required: false
			}]
		}],
		readonly: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "readonly",
				required: false
			}]
		}],
		required: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "required",
				required: false
			}]
		}],
		autofocus: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "autofocus",
				required: false
			}]
		}],
		name: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "name",
				required: false
			}]
		}],
		minlength: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "minlength",
				required: false
			}]
		}],
		maxlength: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maxlength",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		isBusy: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isBusy",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		formatter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "formatter",
				required: false
			}]
		}],
		parser: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "parser",
				required: false
			}]
		}],
		isFocused: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isFocused",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		entriesChanged: [{
			type: i0.Output,
			args: ["entriesChanged"]
		}],
		promptQueued: [{
			type: i0.Output,
			args: ["promptQueued"]
		}],
		promptSubmitted: [{
			type: i0.Output,
			args: ["promptSubmitted"]
		}],
		queueChanged: [{
			type: i0.Output,
			args: ["queueChanged"]
		}],
		stopRequested: [{
			type: i0.Output,
			args: ["stopRequested"]
		}],
		steerRequested: [{
			type: i0.Output,
			args: ["steerRequested"]
		}],
		queuePausedChanged: [{
			type: i0.Output,
			args: ["queuePausedChanged"]
		}],
		queueActionInvoked: [{
			type: i0.Output,
			args: ["queueActionInvoked"]
		}],
		suggestionSelected: [{
			type: i0.Output,
			args: ["suggestionSelected"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function providePromptBoxComponent(config, intl) {
	const providers = [];
	if (config) providers.push({
		provide: PROMPT_BOX_DEFAULT_PROPS,
		useValue: config
	});
	if (intl) {
		if (typeof intl === "function") providers.push({
			provide: PROMPT_BOX_INTL,
			useClass: intl
		});
		else providers.push({
			provide: PROMPT_BOX_INTL,
			useValue: intl
		});
	}
	return makeEnvironmentProviders(providers);
}
export { PROMPT_BOX_ATTACHMENT_LIST_DEFAULT_PROPS, PROMPT_BOX_ATTACHMENT_TOOL_DEFAULT_PROPS, PROMPT_BOX_ATTACHMENT_TOOL_INTL, PROMPT_BOX_DEFAULT_PROPS, PROMPT_BOX_INTL, PROMPT_BOX_QUEUE_DEFAULT_PROPS, PROMPT_BOX_QUEUE_INTL, PROMPT_BOX_VOICE_RECORDER_TOOL_DEFAULT_PROPS, PROMPT_BOX_VOICE_RECORDER_TOOL_INTL, PromptBoxAttachmentListComponent, PromptBoxAttachmentToolComponent, PromptBoxComponent, PromptBoxQueueComponent, PromptBoxVoiceRecorderToolComponent, providePromptBoxAttachmentListComponent, providePromptBoxAttachmentToolComponent, providePromptBoxComponent, providePromptBoxQueueComponent, providePromptBoxVoiceRecorderToolComponent };

//# sourceMappingURL=mosaik-elements-angular-components-prompt-box.mjs.map