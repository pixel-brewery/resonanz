import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { SkeletonElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/skeleton/SkeletonElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const SKELETON_DEFAULT_PROPS = new InjectionToken("MOSAIK_SKELETON_DEFAULT_PROPS");
let SkeletonComponent = class SkeletonComponent {
	target = input(...ngDevMode ? [void 0, { debugName: "target" }] : /* istanbul ignore next */ []);
	shape = input(...ngDevMode ? [void 0, { debugName: "shape" }] : /* istanbul ignore next */ []);
	shimmer = input(...ngDevMode ? [void 0, { debugName: "shimmer" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	width = input(...ngDevMode ? [void 0, { debugName: "width" }] : /* istanbul ignore next */ []);
	height = input(...ngDevMode ? [void 0, { debugName: "height" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(SKELETON_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const targetValue = this.target();
			if (targetValue !== void 0) this._elementRef.nativeElement.target = targetValue;
			const shapeValue = this.shape();
			if (shapeValue !== void 0) this._elementRef.nativeElement.shape = shapeValue;
			const shimmerValue = this.shimmer();
			if (shimmerValue !== void 0) this._elementRef.nativeElement.shimmer = shimmerValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const widthValue = this.width();
			if (widthValue !== void 0) this._elementRef.nativeElement.width = widthValue;
			const heightValue = this.height();
			if (heightValue !== void 0) this._elementRef.nativeElement.height = heightValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: SkeletonComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: SkeletonComponent,
		isStandalone: true,
		selector: "mosaik-skeleton",
		inputs: {
			target: {
				classPropertyName: "target",
				publicName: "target",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			shape: {
				classPropertyName: "shape",
				publicName: "shape",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			shimmer: {
				classPropertyName: "shimmer",
				publicName: "shimmer",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			width: {
				classPropertyName: "width",
				publicName: "width",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			height: {
				classPropertyName: "height",
				publicName: "height",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
SkeletonComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-skeleton", SkeletonElement),
	inputs: [
		"target",
		"shape",
		"shimmer",
		"themeName",
		"width",
		"height",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], SkeletonComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: SkeletonComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-skeleton",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		target: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "target",
				required: false
			}]
		}],
		shape: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "shape",
				required: false
			}]
		}],
		shimmer: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "shimmer",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		width: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "width",
				required: false
			}]
		}],
		height: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "height",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideSkeletonComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: SKELETON_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { SKELETON_DEFAULT_PROPS, SkeletonComponent, provideSkeletonComponent };

//# sourceMappingURL=mosaik-elements-angular-components-skeleton.mjs.map