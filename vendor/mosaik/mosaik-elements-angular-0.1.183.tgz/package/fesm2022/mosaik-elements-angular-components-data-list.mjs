import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, forwardRef, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { NG_VALUE_ACCESSOR } from "@angular/forms";
import { DataListElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/data-list/DataListElement";
import { dataListElementValueAccessor } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/data-list/accessors/DataListElementValueAccessor";
import * as i1 from "@pixel-brewery/mosaik-elements-angular/runtime";
import { FORM_STATUS_HOST, FormFieldStatusHostDirective, FormStatusHostDirective, ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const DATA_LIST_DEFAULT_PROPS = new InjectionToken("MOSAIK_DATA_LIST_DEFAULT_PROPS");
let DataListComponent = class DataListComponent {
	alternating = input(...ngDevMode ? [void 0, { debugName: "alternating" }] : /* istanbul ignore next */ []);
	itemDefinitions = input(...ngDevMode ? [void 0, { debugName: "itemDefinitions" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	source = input(...ngDevMode ? [void 0, { debugName: "source" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	changed = output();
	disconnected = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	_accessor;
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._accessor = dataListElementValueAccessor(this._elementRef.nativeElement);
		this._elementRef.nativeElement.addController(this._accessor);
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			changed: this.changed,
			disconnected: this.disconnected
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
			this._accessor.releaseCallbacks();
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(DATA_LIST_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	writeValue(obj) {
		this._accessor.writeValue(obj);
	}
	registerOnChange(fn) {
		this._accessor.registerOnChange(fn);
	}
	registerOnTouched(fn) {
		this._accessor.registerOnTouched(fn);
	}
	setDisabledState(isDisabled) {
		this._accessor.setDisabled?.(isDisabled);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const alternatingValue = this.alternating();
			if (alternatingValue !== void 0) this._elementRef.nativeElement.alternating = alternatingValue;
			const itemDefinitionsValue = this.itemDefinitions();
			if (itemDefinitionsValue !== void 0) this._elementRef.nativeElement.itemDefinitions = itemDefinitionsValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const sourceValue = this.source();
			if (sourceValue !== void 0) this._elementRef.nativeElement.source = sourceValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DataListComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: DataListComponent,
		isStandalone: true,
		selector: "mosaik-data-list",
		inputs: {
			alternating: {
				classPropertyName: "alternating",
				publicName: "alternating",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			itemDefinitions: {
				classPropertyName: "itemDefinitions",
				publicName: "itemDefinitions",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			source: {
				classPropertyName: "source",
				publicName: "source",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			changed: "changed",
			disconnected: "disconnected"
		},
		providers: [{
			provide: NG_VALUE_ACCESSOR,
			useExisting: forwardRef(() => DataListComponent),
			multi: true
		}, {
			provide: FORM_STATUS_HOST,
			useExisting: forwardRef(() => DataListComponent)
		}],
		hostDirectives: [{ directive: i1.FormStatusHostDirective }, { directive: i1.FormFieldStatusHostDirective }],
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
DataListComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-data-list", DataListElement),
	inputs: [
		"alternating",
		"itemDefinitions",
		"themeName",
		"disabled",
		"source",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], DataListComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DataListComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-data-list",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>",
			hostDirectives: [FormStatusHostDirective, FormFieldStatusHostDirective],
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => DataListComponent),
				multi: true
			}, {
				provide: FORM_STATUS_HOST,
				useExisting: forwardRef(() => DataListComponent)
			}]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		alternating: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "alternating",
				required: false
			}]
		}],
		itemDefinitions: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "itemDefinitions",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		source: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "source",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}]
	}
});
function provideDataListComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: DATA_LIST_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { DATA_LIST_DEFAULT_PROPS, DataListComponent, provideDataListComponent };

//# sourceMappingURL=mosaik-elements-angular-components-data-list.mjs.map