import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { CardStackElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/illustrations/card-stack/CardStackElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const CARD_STACK_DEFAULT_PROPS = new InjectionToken("MOSAIK_CARD_STACK_DEFAULT_PROPS");
let CardStackComponent = class CardStackComponent {
	intl = input(...ngDevMode ? [void 0, { debugName: "intl" }] : /* istanbul ignore next */ []);
	mode = input(...ngDevMode ? [void 0, { debugName: "mode" }] : /* istanbul ignore next */ []);
	interval = input(...ngDevMode ? [void 0, { debugName: "interval" }] : /* istanbul ignore next */ []);
	index = input(...ngDevMode ? [void 0, { debugName: "index" }] : /* istanbul ignore next */ []);
	visible = input(...ngDevMode ? [void 0, { debugName: "visible" }] : /* istanbul ignore next */ []);
	showDots = input(...ngDevMode ? [void 0, { debugName: "showDots" }] : /* istanbul ignore next */ []);
	threshold = input(...ngDevMode ? [void 0, { debugName: "threshold" }] : /* istanbul ignore next */ []);
	label = input(...ngDevMode ? [void 0, { debugName: "label" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	change = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			change: this.change,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(CARD_STACK_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	next(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "next", args);
	}
	previous(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "previous", args);
	}
	goTo(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "goTo", args);
	}
	onSlotChanges(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onSlotChanges", args);
	}
	assignToSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "assignToSlot", args);
	}
	getSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getSlotContent", args);
	}
	hasSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlotContent", args);
	}
	hasSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlot", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const modeValue = this.mode();
			if (modeValue !== void 0) this._elementRef.nativeElement.mode = modeValue;
			const intervalValue = this.interval();
			if (intervalValue !== void 0) this._elementRef.nativeElement.interval = intervalValue;
			const visibleValue = this.visible();
			if (visibleValue !== void 0) this._elementRef.nativeElement.visible = visibleValue;
			const showDotsValue = this.showDots();
			if (showDotsValue !== void 0) this._elementRef.nativeElement.showDots = showDotsValue;
			const thresholdValue = this.threshold();
			if (thresholdValue !== void 0) this._elementRef.nativeElement.threshold = thresholdValue;
			const labelValue = this.label();
			if (labelValue !== void 0) this._elementRef.nativeElement.label = labelValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: CardStackComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: CardStackComponent,
		isStandalone: true,
		selector: "mosaik-card-stack",
		inputs: {
			intl: {
				classPropertyName: "intl",
				publicName: "intl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			mode: {
				classPropertyName: "mode",
				publicName: "mode",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			interval: {
				classPropertyName: "interval",
				publicName: "interval",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			index: {
				classPropertyName: "index",
				publicName: "index",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			visible: {
				classPropertyName: "visible",
				publicName: "visible",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showDots: {
				classPropertyName: "showDots",
				publicName: "showDots",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			threshold: {
				classPropertyName: "threshold",
				publicName: "threshold",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			change: "change",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
CardStackComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-card-stack", CardStackElement),
	inputs: [
		"intl",
		"mode",
		"interval",
		"index",
		"visible",
		"showDots",
		"threshold",
		"label",
		"themeName",
		"dir",
		"lang"
	],
	methods: ["getSlotAssignments", "getSlotAssignmentsOf"]
}), __metadata("design:paramtypes", [])], CardStackComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: CardStackComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-card-stack",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		intl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "intl",
				required: false
			}]
		}],
		mode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mode",
				required: false
			}]
		}],
		interval: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "interval",
				required: false
			}]
		}],
		index: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "index",
				required: false
			}]
		}],
		visible: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "visible",
				required: false
			}]
		}],
		showDots: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showDots",
				required: false
			}]
		}],
		threshold: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "threshold",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		change: [{
			type: i0.Output,
			args: ["change"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideCardStackComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: CARD_STACK_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { CARD_STACK_DEFAULT_PROPS, CardStackComponent, provideCardStackComponent };

//# sourceMappingURL=mosaik-elements-angular-components-card-stack.mjs.map