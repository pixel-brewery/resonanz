import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { ParallaxElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/illustrations/parallax/ParallaxElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const PARALLAX_DEFAULT_PROPS = new InjectionToken("MOSAIK_PARALLAX_DEFAULT_PROPS");
let ParallaxComponent = class ParallaxComponent {
	distance = input(...ngDevMode ? [void 0, { debugName: "distance" }] : /* istanbul ignore next */ []);
	axis = input(...ngDevMode ? [void 0, { debugName: "axis" }] : /* istanbul ignore next */ []);
	reverse = input(...ngDevMode ? [void 0, { debugName: "reverse" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(PARALLAX_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const distanceValue = this.distance();
			if (distanceValue !== void 0) this._elementRef.nativeElement.distance = distanceValue;
			const axisValue = this.axis();
			if (axisValue !== void 0) this._elementRef.nativeElement.axis = axisValue;
			const reverseValue = this.reverse();
			if (reverseValue !== void 0) this._elementRef.nativeElement.reverse = reverseValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ParallaxComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: ParallaxComponent,
		isStandalone: true,
		selector: "mosaik-parallax",
		inputs: {
			distance: {
				classPropertyName: "distance",
				publicName: "distance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			axis: {
				classPropertyName: "axis",
				publicName: "axis",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			reverse: {
				classPropertyName: "reverse",
				publicName: "reverse",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
ParallaxComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-parallax", ParallaxElement),
	inputs: [
		"distance",
		"axis",
		"reverse",
		"themeName",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], ParallaxComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ParallaxComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-parallax",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		distance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "distance",
				required: false
			}]
		}],
		axis: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "axis",
				required: false
			}]
		}],
		reverse: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "reverse",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideParallaxComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: PARALLAX_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { PARALLAX_DEFAULT_PROPS, ParallaxComponent, provideParallaxComponent };

//# sourceMappingURL=mosaik-elements-angular-components-parallax.mjs.map