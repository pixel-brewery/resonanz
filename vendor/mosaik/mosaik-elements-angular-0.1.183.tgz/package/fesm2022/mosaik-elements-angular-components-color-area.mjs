import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { ColorAreaElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/color-area/ColorAreaElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const COLOR_AREA_DEFAULT_PROPS = new InjectionToken("MOSAIK_COLOR_AREA_DEFAULT_PROPS");
let ColorAreaComponent = class ColorAreaComponent {
	x = input(...ngDevMode ? [void 0, { debugName: "x" }] : /* istanbul ignore next */ []);
	y = input(...ngDevMode ? [void 0, { debugName: "y" }] : /* istanbul ignore next */ []);
	hue = input(...ngDevMode ? [void 0, { debugName: "hue" }] : /* istanbul ignore next */ []);
	step = input(...ngDevMode ? [void 0, { debugName: "step" }] : /* istanbul ignore next */ []);
	color = input(...ngDevMode ? [void 0, { debugName: "color" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	isFocused = input(...ngDevMode ? [void 0, { debugName: "isFocused" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	input = output();
	change = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			input: this.input,
			change: this.change,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(COLOR_AREA_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const xValue = this.x();
			if (xValue !== void 0) this._elementRef.nativeElement.x = xValue;
			const yValue = this.y();
			if (yValue !== void 0) this._elementRef.nativeElement.y = yValue;
			const hueValue = this.hue();
			if (hueValue !== void 0) this._elementRef.nativeElement.hue = hueValue;
			const stepValue = this.step();
			if (stepValue !== void 0) this._elementRef.nativeElement.step = stepValue;
			const colorValue = this.color();
			if (colorValue !== void 0) this._elementRef.nativeElement.color = colorValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const isFocusedValue = this.isFocused();
			if (isFocusedValue !== void 0) this._elementRef.nativeElement.isFocused = isFocusedValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ColorAreaComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: ColorAreaComponent,
		isStandalone: true,
		selector: "mosaik-color-area",
		inputs: {
			x: {
				classPropertyName: "x",
				publicName: "x",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			y: {
				classPropertyName: "y",
				publicName: "y",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			hue: {
				classPropertyName: "hue",
				publicName: "hue",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			step: {
				classPropertyName: "step",
				publicName: "step",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			color: {
				classPropertyName: "color",
				publicName: "color",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isFocused: {
				classPropertyName: "isFocused",
				publicName: "isFocused",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			input: "input",
			change: "change",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
ColorAreaComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-color-area", ColorAreaElement),
	inputs: [
		"x",
		"y",
		"hue",
		"step",
		"color",
		"themeName",
		"disabled",
		"isFocused",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], ColorAreaComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ColorAreaComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-color-area",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		x: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "x",
				required: false
			}]
		}],
		y: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "y",
				required: false
			}]
		}],
		hue: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hue",
				required: false
			}]
		}],
		step: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "step",
				required: false
			}]
		}],
		color: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "color",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		isFocused: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isFocused",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		input: [{
			type: i0.Output,
			args: ["input"]
		}],
		change: [{
			type: i0.Output,
			args: ["change"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideColorAreaComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: COLOR_AREA_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { COLOR_AREA_DEFAULT_PROPS, ColorAreaComponent, provideColorAreaComponent };

//# sourceMappingURL=mosaik-elements-angular-components-color-area.mjs.map