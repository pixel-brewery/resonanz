import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { TourAnchorElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/overlays/tour/TourAnchorElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { TourNavElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/overlays/tour/TourNavElement";
import { TourStepElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/overlays/tour/TourStepElement";
import { TourElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/overlays/tour/TourElement";
var __decorate$3 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$3 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const TOUR_ANCHOR_DEFAULT_PROPS = new InjectionToken("MOSAIK_TOUR_ANCHOR_DEFAULT_PROPS");
let TourAnchorComponent = class TourAnchorComponent {
	tourId = input(...ngDevMode ? [void 0, { debugName: "tourId" }] : /* istanbul ignore next */ []);
	anchorId = input(...ngDevMode ? [void 0, { debugName: "anchorId" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(TOUR_ANCHOR_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const tourIdValue = this.tourId();
			if (tourIdValue !== void 0) this._elementRef.nativeElement.tourId = tourIdValue;
			const anchorIdValue = this.anchorId();
			if (anchorIdValue !== void 0) this._elementRef.nativeElement.anchorId = anchorIdValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: TourAnchorComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: TourAnchorComponent,
		isStandalone: true,
		selector: "mosaik-tour-anchor",
		inputs: {
			tourId: {
				classPropertyName: "tourId",
				publicName: "tourId",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			anchorId: {
				classPropertyName: "anchorId",
				publicName: "anchorId",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
TourAnchorComponent = __decorate$3([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-tour-anchor", TourAnchorElement),
	inputs: [
		"tourId",
		"anchorId",
		"themeName",
		"dir",
		"lang"
	]
}), __metadata$3("design:paramtypes", [])], TourAnchorComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: TourAnchorComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-tour-anchor",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		tourId: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tourId",
				required: false
			}]
		}],
		anchorId: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "anchorId",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideTourAnchorComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: TOUR_ANCHOR_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$2 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$2 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const TOUR_NAV_DEFAULT_PROPS = new InjectionToken("MOSAIK_TOUR_NAV_DEFAULT_PROPS");
let TourNavComponent = class TourNavComponent {
	currentStepIndex = input(...ngDevMode ? [void 0, { debugName: "currentStepIndex" }] : /* istanbul ignore next */ []);
	stepCount = input(...ngDevMode ? [void 0, { debugName: "stepCount" }] : /* istanbul ignore next */ []);
	isFirstStep = input(...ngDevMode ? [void 0, { debugName: "isFirstStep" }] : /* istanbul ignore next */ []);
	isLastStep = input(...ngDevMode ? [void 0, { debugName: "isLastStep" }] : /* istanbul ignore next */ []);
	showProgress = input(...ngDevMode ? [void 0, { debugName: "showProgress" }] : /* istanbul ignore next */ []);
	showAutoAdvanceControls = input(...ngDevMode ? [void 0, { debugName: "showAutoAdvanceControls" }] : /* istanbul ignore next */ []);
	isAutoAdvancePaused = input(...ngDevMode ? [void 0, { debugName: "isAutoAdvancePaused" }] : /* istanbul ignore next */ []);
	stepDuration = input(...ngDevMode ? [void 0, { debugName: "stepDuration" }] : /* istanbul ignore next */ []);
	minimumStepDuration = input(...ngDevMode ? [void 0, { debugName: "minimumStepDuration" }] : /* istanbul ignore next */ []);
	maximumStepDuration = input(...ngDevMode ? [void 0, { debugName: "maximumStepDuration" }] : /* istanbul ignore next */ []);
	stepDurationIncrement = input(...ngDevMode ? [void 0, { debugName: "stepDurationIncrement" }] : /* istanbul ignore next */ []);
	labels = input(...ngDevMode ? [void 0, { debugName: "labels" }] : /* istanbul ignore next */ []);
	actions = input(...ngDevMode ? [void 0, { debugName: "actions" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(TOUR_NAV_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const currentStepIndexValue = this.currentStepIndex();
			if (currentStepIndexValue !== void 0) this._elementRef.nativeElement.currentStepIndex = currentStepIndexValue;
			const stepCountValue = this.stepCount();
			if (stepCountValue !== void 0) this._elementRef.nativeElement.stepCount = stepCountValue;
			const showProgressValue = this.showProgress();
			if (showProgressValue !== void 0) this._elementRef.nativeElement.showProgress = showProgressValue;
			const showAutoAdvanceControlsValue = this.showAutoAdvanceControls();
			if (showAutoAdvanceControlsValue !== void 0) this._elementRef.nativeElement.showAutoAdvanceControls = showAutoAdvanceControlsValue;
			const isAutoAdvancePausedValue = this.isAutoAdvancePaused();
			if (isAutoAdvancePausedValue !== void 0) this._elementRef.nativeElement.isAutoAdvancePaused = isAutoAdvancePausedValue;
			const stepDurationValue = this.stepDuration();
			if (stepDurationValue !== void 0) this._elementRef.nativeElement.stepDuration = stepDurationValue;
			const minimumStepDurationValue = this.minimumStepDuration();
			if (minimumStepDurationValue !== void 0) this._elementRef.nativeElement.minimumStepDuration = minimumStepDurationValue;
			const maximumStepDurationValue = this.maximumStepDuration();
			if (maximumStepDurationValue !== void 0) this._elementRef.nativeElement.maximumStepDuration = maximumStepDurationValue;
			const stepDurationIncrementValue = this.stepDurationIncrement();
			if (stepDurationIncrementValue !== void 0) this._elementRef.nativeElement.stepDurationIncrement = stepDurationIncrementValue;
			const actionsValue = this.actions();
			if (actionsValue !== void 0) this._elementRef.nativeElement.actions = actionsValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: TourNavComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: TourNavComponent,
		isStandalone: true,
		selector: "mosaik-tour-nav",
		inputs: {
			currentStepIndex: {
				classPropertyName: "currentStepIndex",
				publicName: "currentStepIndex",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			stepCount: {
				classPropertyName: "stepCount",
				publicName: "stepCount",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isFirstStep: {
				classPropertyName: "isFirstStep",
				publicName: "isFirstStep",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isLastStep: {
				classPropertyName: "isLastStep",
				publicName: "isLastStep",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showProgress: {
				classPropertyName: "showProgress",
				publicName: "showProgress",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showAutoAdvanceControls: {
				classPropertyName: "showAutoAdvanceControls",
				publicName: "showAutoAdvanceControls",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isAutoAdvancePaused: {
				classPropertyName: "isAutoAdvancePaused",
				publicName: "isAutoAdvancePaused",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			stepDuration: {
				classPropertyName: "stepDuration",
				publicName: "stepDuration",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			minimumStepDuration: {
				classPropertyName: "minimumStepDuration",
				publicName: "minimumStepDuration",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			maximumStepDuration: {
				classPropertyName: "maximumStepDuration",
				publicName: "maximumStepDuration",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			stepDurationIncrement: {
				classPropertyName: "stepDurationIncrement",
				publicName: "stepDurationIncrement",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			labels: {
				classPropertyName: "labels",
				publicName: "labels",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			actions: {
				classPropertyName: "actions",
				publicName: "actions",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
TourNavComponent = __decorate$2([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-tour-nav", TourNavElement),
	inputs: [
		"currentStepIndex",
		"stepCount",
		"isFirstStep",
		"isLastStep",
		"showProgress",
		"showAutoAdvanceControls",
		"isAutoAdvancePaused",
		"stepDuration",
		"minimumStepDuration",
		"maximumStepDuration",
		"stepDurationIncrement",
		"labels",
		"actions",
		"themeName",
		"dir",
		"lang"
	]
}), __metadata$2("design:paramtypes", [])], TourNavComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: TourNavComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-tour-nav",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		currentStepIndex: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "currentStepIndex",
				required: false
			}]
		}],
		stepCount: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "stepCount",
				required: false
			}]
		}],
		isFirstStep: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isFirstStep",
				required: false
			}]
		}],
		isLastStep: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isLastStep",
				required: false
			}]
		}],
		showProgress: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showProgress",
				required: false
			}]
		}],
		showAutoAdvanceControls: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showAutoAdvanceControls",
				required: false
			}]
		}],
		isAutoAdvancePaused: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isAutoAdvancePaused",
				required: false
			}]
		}],
		stepDuration: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "stepDuration",
				required: false
			}]
		}],
		minimumStepDuration: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "minimumStepDuration",
				required: false
			}]
		}],
		maximumStepDuration: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maximumStepDuration",
				required: false
			}]
		}],
		stepDurationIncrement: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "stepDurationIncrement",
				required: false
			}]
		}],
		labels: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "labels",
				required: false
			}]
		}],
		actions: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "actions",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideTourNavComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: TOUR_NAV_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$1 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$1 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const TOUR_STEP_DEFAULT_PROPS = new InjectionToken("MOSAIK_TOUR_STEP_DEFAULT_PROPS");
let TourStepComponent = class TourStepComponent {
	step = input(...ngDevMode ? [void 0, { debugName: "step" }] : /* istanbul ignore next */ []);
	isFirstStep = input(...ngDevMode ? [void 0, { debugName: "isFirstStep" }] : /* istanbul ignore next */ []);
	isLastStep = input(...ngDevMode ? [void 0, { debugName: "isLastStep" }] : /* istanbul ignore next */ []);
	stepIndex = input(...ngDevMode ? [void 0, { debugName: "stepIndex" }] : /* istanbul ignore next */ []);
	stepCount = input(...ngDevMode ? [void 0, { debugName: "stepCount" }] : /* istanbul ignore next */ []);
	showProgress = input(...ngDevMode ? [void 0, { debugName: "showProgress" }] : /* istanbul ignore next */ []);
	showAutoAdvanceControl = input(...ngDevMode ? [void 0, { debugName: "showAutoAdvanceControl" }] : /* istanbul ignore next */ []);
	isAutoAdvancePaused = input(...ngDevMode ? [void 0, { debugName: "isAutoAdvancePaused" }] : /* istanbul ignore next */ []);
	labels = input(...ngDevMode ? [void 0, { debugName: "labels" }] : /* istanbul ignore next */ []);
	actions = input(...ngDevMode ? [void 0, { debugName: "actions" }] : /* istanbul ignore next */ []);
	titleId = input(...ngDevMode ? [void 0, { debugName: "titleId" }] : /* istanbul ignore next */ []);
	descriptionId = input(...ngDevMode ? [void 0, { debugName: "descriptionId" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(TOUR_STEP_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const stepValue = this.step();
			if (stepValue !== void 0) this._elementRef.nativeElement.step = stepValue;
			const stepIndexValue = this.stepIndex();
			if (stepIndexValue !== void 0) this._elementRef.nativeElement.stepIndex = stepIndexValue;
			const stepCountValue = this.stepCount();
			if (stepCountValue !== void 0) this._elementRef.nativeElement.stepCount = stepCountValue;
			const showProgressValue = this.showProgress();
			if (showProgressValue !== void 0) this._elementRef.nativeElement.showProgress = showProgressValue;
			const showAutoAdvanceControlValue = this.showAutoAdvanceControl();
			if (showAutoAdvanceControlValue !== void 0) this._elementRef.nativeElement.showAutoAdvanceControl = showAutoAdvanceControlValue;
			const isAutoAdvancePausedValue = this.isAutoAdvancePaused();
			if (isAutoAdvancePausedValue !== void 0) this._elementRef.nativeElement.isAutoAdvancePaused = isAutoAdvancePausedValue;
			const actionsValue = this.actions();
			if (actionsValue !== void 0) this._elementRef.nativeElement.actions = actionsValue;
			const titleIdValue = this.titleId();
			if (titleIdValue !== void 0) this._elementRef.nativeElement.titleId = titleIdValue;
			const descriptionIdValue = this.descriptionId();
			if (descriptionIdValue !== void 0) this._elementRef.nativeElement.descriptionId = descriptionIdValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: TourStepComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: TourStepComponent,
		isStandalone: true,
		selector: "mosaik-tour-step",
		inputs: {
			step: {
				classPropertyName: "step",
				publicName: "step",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isFirstStep: {
				classPropertyName: "isFirstStep",
				publicName: "isFirstStep",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isLastStep: {
				classPropertyName: "isLastStep",
				publicName: "isLastStep",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			stepIndex: {
				classPropertyName: "stepIndex",
				publicName: "stepIndex",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			stepCount: {
				classPropertyName: "stepCount",
				publicName: "stepCount",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showProgress: {
				classPropertyName: "showProgress",
				publicName: "showProgress",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showAutoAdvanceControl: {
				classPropertyName: "showAutoAdvanceControl",
				publicName: "showAutoAdvanceControl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isAutoAdvancePaused: {
				classPropertyName: "isAutoAdvancePaused",
				publicName: "isAutoAdvancePaused",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			labels: {
				classPropertyName: "labels",
				publicName: "labels",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			actions: {
				classPropertyName: "actions",
				publicName: "actions",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			titleId: {
				classPropertyName: "titleId",
				publicName: "titleId",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			descriptionId: {
				classPropertyName: "descriptionId",
				publicName: "descriptionId",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
TourStepComponent = __decorate$1([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-tour-step", TourStepElement),
	inputs: [
		"step",
		"isFirstStep",
		"isLastStep",
		"stepIndex",
		"stepCount",
		"showProgress",
		"showAutoAdvanceControl",
		"isAutoAdvancePaused",
		"labels",
		"actions",
		"titleId",
		"descriptionId",
		"themeName",
		"variant",
		"dir",
		"lang"
	]
}), __metadata$1("design:paramtypes", [])], TourStepComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: TourStepComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-tour-step",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		step: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "step",
				required: false
			}]
		}],
		isFirstStep: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isFirstStep",
				required: false
			}]
		}],
		isLastStep: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isLastStep",
				required: false
			}]
		}],
		stepIndex: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "stepIndex",
				required: false
			}]
		}],
		stepCount: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "stepCount",
				required: false
			}]
		}],
		showProgress: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showProgress",
				required: false
			}]
		}],
		showAutoAdvanceControl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showAutoAdvanceControl",
				required: false
			}]
		}],
		isAutoAdvancePaused: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isAutoAdvancePaused",
				required: false
			}]
		}],
		labels: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "labels",
				required: false
			}]
		}],
		actions: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "actions",
				required: false
			}]
		}],
		titleId: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "titleId",
				required: false
			}]
		}],
		descriptionId: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "descriptionId",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideTourStepComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: TOUR_STEP_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const TOUR_DEFAULT_PROPS = new InjectionToken("MOSAIK_TOUR_DEFAULT_PROPS");
let TourComponent = class TourComponent {
	intl = input(...ngDevMode ? [void 0, { debugName: "intl" }] : /* istanbul ignore next */ []);
	tourId = input(...ngDevMode ? [void 0, { debugName: "tourId" }] : /* istanbul ignore next */ []);
	behaviors = input(...ngDevMode ? [void 0, { debugName: "behaviors" }] : /* istanbul ignore next */ []);
	steps = input(...ngDevMode ? [void 0, { debugName: "steps" }] : /* istanbul ignore next */ []);
	context = input(...ngDevMode ? [void 0, { debugName: "context" }] : /* istanbul ignore next */ []);
	labels = input(...ngDevMode ? [void 0, { debugName: "labels" }] : /* istanbul ignore next */ []);
	showProgress = input(...ngDevMode ? [void 0, { debugName: "showProgress" }] : /* istanbul ignore next */ []);
	showAutoAdvanceControls = input(...ngDevMode ? [void 0, { debugName: "showAutoAdvanceControls" }] : /* istanbul ignore next */ []);
	showFloatingControls = input(...ngDevMode ? [void 0, { debugName: "showFloatingControls" }] : /* istanbul ignore next */ []);
	minimumStepDuration = input(...ngDevMode ? [void 0, { debugName: "minimumStepDuration" }] : /* istanbul ignore next */ []);
	maximumStepDuration = input(...ngDevMode ? [void 0, { debugName: "maximumStepDuration" }] : /* istanbul ignore next */ []);
	stepDurationIncrement = input(...ngDevMode ? [void 0, { debugName: "stepDurationIncrement" }] : /* istanbul ignore next */ []);
	restoreFocus = input(...ngDevMode ? [void 0, { debugName: "restoreFocus" }] : /* istanbul ignore next */ []);
	blockScroll = input(...ngDevMode ? [void 0, { debugName: "blockScroll" }] : /* istanbul ignore next */ []);
	stepActivator = input(...ngDevMode ? [void 0, { debugName: "stepActivator" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	enter = input(...ngDevMode ? [void 0, { debugName: "enter" }] : /* istanbul ignore next */ []);
	exit = input(...ngDevMode ? [void 0, { debugName: "exit" }] : /* istanbul ignore next */ []);
	isOpen = input(...ngDevMode ? [void 0, { debugName: "isOpen" }] : /* istanbul ignore next */ []);
	hasBackdrop = input(...ngDevMode ? [void 0, { debugName: "hasBackdrop" }] : /* istanbul ignore next */ []);
	pressEscapeToClose = input(...ngDevMode ? [void 0, { debugName: "pressEscapeToClose" }] : /* istanbul ignore next */ []);
	clickOutsideToClose = input(...ngDevMode ? [void 0, { debugName: "clickOutsideToClose" }] : /* istanbul ignore next */ []);
	attention = input(...ngDevMode ? [void 0, { debugName: "attention" }] : /* istanbul ignore next */ []);
	closeable = input(...ngDevMode ? [void 0, { debugName: "closeable" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	tourStarted = output();
	tourEnded = output();
	tourStepChanged = output();
	tourFailed = output();
	opened = output();
	closed = output();
	closeAttempted = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			tourStarted: this.tourStarted,
			tourEnded: this.tourEnded,
			tourStepChanged: this.tourStepChanged,
			tourFailed: this.tourFailed,
			opened: this.opened,
			closed: this.closed,
			closeAttempted: this.closeAttempted,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(TOUR_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	start(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "start", args);
	}
	next(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "next", args);
	}
	previous(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "previous", args);
	}
	finish(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "finish", args);
	}
	skip(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "skip", args);
	}
	pauseAutoAdvance(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "pauseAutoAdvance", args);
	}
	resumeAutoAdvance(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "resumeAutoAdvance", args);
	}
	setStepDuration(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "setStepDuration", args);
	}
	end(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "end", args);
	}
	showStep(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "showStep", args);
	}
	close(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "close", args);
	}
	play(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "play", args);
	}
	onEnterAnimation(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onEnterAnimation", args);
	}
	onExitAnimation(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onExitAnimation", args);
	}
	open(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "open", args);
	}
	requestAttention(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "requestAttention", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const tourIdValue = this.tourId();
			if (tourIdValue !== void 0) this._elementRef.nativeElement.tourId = tourIdValue;
			const behaviorsValue = this.behaviors();
			if (behaviorsValue !== void 0) this._elementRef.nativeElement.behaviors = behaviorsValue;
			const stepsValue = this.steps();
			if (stepsValue !== void 0) this._elementRef.nativeElement.steps = stepsValue;
			const contextValue = this.context();
			if (contextValue !== void 0) this._elementRef.nativeElement.context = contextValue;
			const showProgressValue = this.showProgress();
			if (showProgressValue !== void 0) this._elementRef.nativeElement.showProgress = showProgressValue;
			const showAutoAdvanceControlsValue = this.showAutoAdvanceControls();
			if (showAutoAdvanceControlsValue !== void 0) this._elementRef.nativeElement.showAutoAdvanceControls = showAutoAdvanceControlsValue;
			const showFloatingControlsValue = this.showFloatingControls();
			if (showFloatingControlsValue !== void 0) this._elementRef.nativeElement.showFloatingControls = showFloatingControlsValue;
			const minimumStepDurationValue = this.minimumStepDuration();
			if (minimumStepDurationValue !== void 0) this._elementRef.nativeElement.minimumStepDuration = minimumStepDurationValue;
			const maximumStepDurationValue = this.maximumStepDuration();
			if (maximumStepDurationValue !== void 0) this._elementRef.nativeElement.maximumStepDuration = maximumStepDurationValue;
			const stepDurationIncrementValue = this.stepDurationIncrement();
			if (stepDurationIncrementValue !== void 0) this._elementRef.nativeElement.stepDurationIncrement = stepDurationIncrementValue;
			const restoreFocusValue = this.restoreFocus();
			if (restoreFocusValue !== void 0) this._elementRef.nativeElement.restoreFocus = restoreFocusValue;
			const blockScrollValue = this.blockScroll();
			if (blockScrollValue !== void 0) this._elementRef.nativeElement.blockScroll = blockScrollValue;
			const stepActivatorValue = this.stepActivator();
			if (stepActivatorValue !== void 0) this._elementRef.nativeElement.stepActivator = stepActivatorValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const enterValue = this.enter();
			if (enterValue !== void 0) this._elementRef.nativeElement.enter = enterValue;
			const exitValue = this.exit();
			if (exitValue !== void 0) this._elementRef.nativeElement.exit = exitValue;
			const isOpenValue = this.isOpen();
			if (isOpenValue !== void 0) this._elementRef.nativeElement.isOpen = isOpenValue;
			const hasBackdropValue = this.hasBackdrop();
			if (hasBackdropValue !== void 0) this._elementRef.nativeElement.hasBackdrop = hasBackdropValue;
			const pressEscapeToCloseValue = this.pressEscapeToClose();
			if (pressEscapeToCloseValue !== void 0) this._elementRef.nativeElement.pressEscapeToClose = pressEscapeToCloseValue;
			const clickOutsideToCloseValue = this.clickOutsideToClose();
			if (clickOutsideToCloseValue !== void 0) this._elementRef.nativeElement.clickOutsideToClose = clickOutsideToCloseValue;
			const attentionValue = this.attention();
			if (attentionValue !== void 0) this._elementRef.nativeElement.attention = attentionValue;
			const closeableValue = this.closeable();
			if (closeableValue !== void 0) this._elementRef.nativeElement.closeable = closeableValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: TourComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: TourComponent,
		isStandalone: true,
		selector: "mosaik-tour",
		inputs: {
			intl: {
				classPropertyName: "intl",
				publicName: "intl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			tourId: {
				classPropertyName: "tourId",
				publicName: "tourId",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			behaviors: {
				classPropertyName: "behaviors",
				publicName: "behaviors",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			steps: {
				classPropertyName: "steps",
				publicName: "steps",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			context: {
				classPropertyName: "context",
				publicName: "context",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			labels: {
				classPropertyName: "labels",
				publicName: "labels",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showProgress: {
				classPropertyName: "showProgress",
				publicName: "showProgress",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showAutoAdvanceControls: {
				classPropertyName: "showAutoAdvanceControls",
				publicName: "showAutoAdvanceControls",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showFloatingControls: {
				classPropertyName: "showFloatingControls",
				publicName: "showFloatingControls",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			minimumStepDuration: {
				classPropertyName: "minimumStepDuration",
				publicName: "minimumStepDuration",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			maximumStepDuration: {
				classPropertyName: "maximumStepDuration",
				publicName: "maximumStepDuration",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			stepDurationIncrement: {
				classPropertyName: "stepDurationIncrement",
				publicName: "stepDurationIncrement",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			restoreFocus: {
				classPropertyName: "restoreFocus",
				publicName: "restoreFocus",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			blockScroll: {
				classPropertyName: "blockScroll",
				publicName: "blockScroll",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			stepActivator: {
				classPropertyName: "stepActivator",
				publicName: "stepActivator",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			enter: {
				classPropertyName: "enter",
				publicName: "enter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			exit: {
				classPropertyName: "exit",
				publicName: "exit",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isOpen: {
				classPropertyName: "isOpen",
				publicName: "isOpen",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			hasBackdrop: {
				classPropertyName: "hasBackdrop",
				publicName: "hasBackdrop",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			pressEscapeToClose: {
				classPropertyName: "pressEscapeToClose",
				publicName: "pressEscapeToClose",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			clickOutsideToClose: {
				classPropertyName: "clickOutsideToClose",
				publicName: "clickOutsideToClose",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			attention: {
				classPropertyName: "attention",
				publicName: "attention",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			closeable: {
				classPropertyName: "closeable",
				publicName: "closeable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			tourStarted: "tourStarted",
			tourEnded: "tourEnded",
			tourStepChanged: "tourStepChanged",
			tourFailed: "tourFailed",
			opened: "opened",
			closed: "closed",
			closeAttempted: "closeAttempted",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
TourComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-tour", TourElement),
	inputs: [
		"intl",
		"tourId",
		"behaviors",
		"steps",
		"context",
		"labels",
		"showProgress",
		"showAutoAdvanceControls",
		"showFloatingControls",
		"minimumStepDuration",
		"maximumStepDuration",
		"stepDurationIncrement",
		"restoreFocus",
		"blockScroll",
		"stepActivator",
		"themeName",
		"enter",
		"exit",
		"isOpen",
		"hasBackdrop",
		"pressEscapeToClose",
		"clickOutsideToClose",
		"attention",
		"closeable",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], TourComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: TourComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-tour",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		intl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "intl",
				required: false
			}]
		}],
		tourId: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tourId",
				required: false
			}]
		}],
		behaviors: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "behaviors",
				required: false
			}]
		}],
		steps: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "steps",
				required: false
			}]
		}],
		context: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "context",
				required: false
			}]
		}],
		labels: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "labels",
				required: false
			}]
		}],
		showProgress: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showProgress",
				required: false
			}]
		}],
		showAutoAdvanceControls: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showAutoAdvanceControls",
				required: false
			}]
		}],
		showFloatingControls: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showFloatingControls",
				required: false
			}]
		}],
		minimumStepDuration: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "minimumStepDuration",
				required: false
			}]
		}],
		maximumStepDuration: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maximumStepDuration",
				required: false
			}]
		}],
		stepDurationIncrement: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "stepDurationIncrement",
				required: false
			}]
		}],
		restoreFocus: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "restoreFocus",
				required: false
			}]
		}],
		blockScroll: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "blockScroll",
				required: false
			}]
		}],
		stepActivator: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "stepActivator",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		enter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "enter",
				required: false
			}]
		}],
		exit: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "exit",
				required: false
			}]
		}],
		isOpen: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isOpen",
				required: false
			}]
		}],
		hasBackdrop: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hasBackdrop",
				required: false
			}]
		}],
		pressEscapeToClose: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "pressEscapeToClose",
				required: false
			}]
		}],
		clickOutsideToClose: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "clickOutsideToClose",
				required: false
			}]
		}],
		attention: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "attention",
				required: false
			}]
		}],
		closeable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "closeable",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		tourStarted: [{
			type: i0.Output,
			args: ["tourStarted"]
		}],
		tourEnded: [{
			type: i0.Output,
			args: ["tourEnded"]
		}],
		tourStepChanged: [{
			type: i0.Output,
			args: ["tourStepChanged"]
		}],
		tourFailed: [{
			type: i0.Output,
			args: ["tourFailed"]
		}],
		opened: [{
			type: i0.Output,
			args: ["opened"]
		}],
		closed: [{
			type: i0.Output,
			args: ["closed"]
		}],
		closeAttempted: [{
			type: i0.Output,
			args: ["closeAttempted"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideTourComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: TOUR_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { TOUR_ANCHOR_DEFAULT_PROPS, TOUR_DEFAULT_PROPS, TOUR_NAV_DEFAULT_PROPS, TOUR_STEP_DEFAULT_PROPS, TourAnchorComponent, TourComponent, TourNavComponent, TourStepComponent, provideTourAnchorComponent, provideTourComponent, provideTourNavComponent, provideTourStepComponent };

//# sourceMappingURL=mosaik-elements-angular-components-tour.mjs.map