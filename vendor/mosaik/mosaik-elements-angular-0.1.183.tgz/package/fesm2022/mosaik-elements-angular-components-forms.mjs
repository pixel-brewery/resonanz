import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { FormFieldElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/forms/FormFieldElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { FormElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/forms/FormElement";
var __decorate$1 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$1 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const FORM_FIELD_DEFAULT_PROPS = new InjectionToken("MOSAIK_FORM_FIELD_DEFAULT_PROPS");
let FormFieldComponent = class FormFieldComponent {
	hint = input(...ngDevMode ? [void 0, { debugName: "hint" }] : /* istanbul ignore next */ []);
	error = input(...ngDevMode ? [void 0, { debugName: "error" }] : /* istanbul ignore next */ []);
	info = input(...ngDevMode ? [void 0, { debugName: "info" }] : /* istanbul ignore next */ []);
	validators = input(...ngDevMode ? [void 0, { debugName: "validators" }] : /* istanbul ignore next */ []);
	accessor = input(...ngDevMode ? [void 0, { debugName: "accessor" }] : /* istanbul ignore next */ []);
	required = input(...ngDevMode ? [void 0, { debugName: "required" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	label = input(...ngDevMode ? [void 0, { debugName: "label" }] : /* istanbul ignore next */ []);
	name = input(...ngDevMode ? [void 0, { debugName: "name" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	form = input(...ngDevMode ? [void 0, { debugName: "form" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	invalid = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed,
			invalid: this.invalid
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(FORM_FIELD_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	checkValidity(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "checkValidity", args);
	}
	reportValidity(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "reportValidity", args);
	}
	getFormValue(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getFormValue", args);
	}
	getFormState(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getFormState", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const hintValue = this.hint();
			if (hintValue !== void 0) this._elementRef.nativeElement.hint = hintValue;
			const errorValue = this.error();
			if (errorValue !== void 0) this._elementRef.nativeElement.error = errorValue;
			const infoValue = this.info();
			if (infoValue !== void 0) this._elementRef.nativeElement.info = infoValue;
			const validatorsValue = this.validators();
			if (validatorsValue !== void 0) this._elementRef.nativeElement.validators = validatorsValue;
			const accessorValue = this.accessor();
			if (accessorValue !== void 0) this._elementRef.nativeElement.accessor = accessorValue;
			const requiredValue = this.required();
			if (requiredValue !== void 0) this._elementRef.nativeElement.required = requiredValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const labelValue = this.label();
			if (labelValue !== void 0) this._elementRef.nativeElement.label = labelValue;
			const nameValue = this.name();
			if (nameValue !== void 0) this._elementRef.nativeElement.name = nameValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const formValue = this.form();
			if (formValue !== void 0) this._elementRef.nativeElement.form = formValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FormFieldComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: FormFieldComponent,
		isStandalone: true,
		selector: "mosaik-form-field",
		inputs: {
			hint: {
				classPropertyName: "hint",
				publicName: "hint",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			error: {
				classPropertyName: "error",
				publicName: "error",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			info: {
				classPropertyName: "info",
				publicName: "info",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			validators: {
				classPropertyName: "validators",
				publicName: "validators",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			accessor: {
				classPropertyName: "accessor",
				publicName: "accessor",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			required: {
				classPropertyName: "required",
				publicName: "required",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			name: {
				classPropertyName: "name",
				publicName: "name",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			form: {
				classPropertyName: "form",
				publicName: "form",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed",
			invalid: "invalid"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
FormFieldComponent = __decorate$1([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-form-field", FormFieldElement),
	inputs: [
		"hint",
		"error",
		"info",
		"validators",
		"accessor",
		"required",
		"themeName",
		"label",
		"name",
		"disabled",
		"form",
		"dir",
		"lang"
	]
}), __metadata$1("design:paramtypes", [])], FormFieldComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FormFieldComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-form-field",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		hint: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hint",
				required: false
			}]
		}],
		error: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "error",
				required: false
			}]
		}],
		info: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "info",
				required: false
			}]
		}],
		validators: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "validators",
				required: false
			}]
		}],
		accessor: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "accessor",
				required: false
			}]
		}],
		required: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "required",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		name: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "name",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		form: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "form",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}],
		invalid: [{
			type: i0.Output,
			args: ["invalid"]
		}]
	}
});
function provideFormFieldComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: FORM_FIELD_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const FORM_DEFAULT_PROPS = new InjectionToken("MOSAIK_FORM_DEFAULT_PROPS");
let FormComponent = class FormComponent {
	novalidate = input(...ngDevMode ? [void 0, { debugName: "novalidate" }] : /* istanbul ignore next */ []);
	autocomplete = input(...ngDevMode ? [void 0, { debugName: "autocomplete" }] : /* istanbul ignore next */ []);
	name = input(...ngDevMode ? [void 0, { debugName: "name" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	submitted = output();
	formReset = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			submitted: this.submitted,
			formReset: this.formReset,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(FORM_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	submit(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "submit", args);
	}
	reset(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "reset", args);
	}
	reportValidity(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "reportValidity", args);
	}
	checkValidity(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "checkValidity", args);
	}
	assignToSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "assignToSlot", args);
	}
	getSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getSlotContent", args);
	}
	hasSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlotContent", args);
	}
	hasSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlot", args);
	}
	onSlotChanges(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onSlotChanges", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const novalidateValue = this.novalidate();
			if (novalidateValue !== void 0) this._elementRef.nativeElement.novalidate = novalidateValue;
			const autocompleteValue = this.autocomplete();
			if (autocompleteValue !== void 0) this._elementRef.nativeElement.autocomplete = autocompleteValue;
			const nameValue = this.name();
			if (nameValue !== void 0) this._elementRef.nativeElement.name = nameValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FormComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: FormComponent,
		isStandalone: true,
		selector: "mosaik-form",
		inputs: {
			novalidate: {
				classPropertyName: "novalidate",
				publicName: "novalidate",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			autocomplete: {
				classPropertyName: "autocomplete",
				publicName: "autocomplete",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			name: {
				classPropertyName: "name",
				publicName: "name",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			submitted: "submitted",
			formReset: "formReset",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
FormComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-form", FormElement),
	inputs: [
		"novalidate",
		"autocomplete",
		"name",
		"themeName",
		"dir",
		"lang"
	],
	methods: ["getSlotAssignments", "getSlotAssignmentsOf"]
}), __metadata("design:paramtypes", [])], FormComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FormComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-form",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		novalidate: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "novalidate",
				required: false
			}]
		}],
		autocomplete: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "autocomplete",
				required: false
			}]
		}],
		name: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "name",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		submitted: [{
			type: i0.Output,
			args: ["submitted"]
		}],
		formReset: [{
			type: i0.Output,
			args: ["formReset"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideFormComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: FORM_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { FORM_DEFAULT_PROPS, FORM_FIELD_DEFAULT_PROPS, FormComponent, FormFieldComponent, provideFormComponent, provideFormFieldComponent };

//# sourceMappingURL=mosaik-elements-angular-components-forms.mjs.map