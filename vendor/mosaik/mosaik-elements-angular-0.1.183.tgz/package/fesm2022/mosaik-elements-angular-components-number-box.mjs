import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, forwardRef, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { NG_VALUE_ACCESSOR } from "@angular/forms";
import { NumberBoxElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/number-box/NumberBoxElement";
import { numberBoxElementValueAccessor } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/number-box/accessors/NumberBoxElementValueAccessor";
import * as i1 from "@pixel-brewery/mosaik-elements-angular/runtime";
import { FORM_STATUS_HOST, FormFieldStatusHostDirective, FormStatusHostDirective, ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const NUMBER_BOX_DEFAULT_PROPS = new InjectionToken("MOSAIK_NUMBER_BOX_DEFAULT_PROPS");
const NUMBER_BOX_INTL = new InjectionToken("MOSAIK_NUMBER_BOX_INTL");
let NumberBoxComponent = class NumberBoxComponent {
	readonly = input(...ngDevMode ? [void 0, { debugName: "readonly" }] : /* istanbul ignore next */ []);
	required = input(...ngDevMode ? [void 0, { debugName: "required" }] : /* istanbul ignore next */ []);
	autofocus = input(...ngDevMode ? [void 0, { debugName: "autofocus" }] : /* istanbul ignore next */ []);
	name = input(...ngDevMode ? [void 0, { debugName: "name" }] : /* istanbul ignore next */ []);
	pattern = input(...ngDevMode ? [void 0, { debugName: "pattern" }] : /* istanbul ignore next */ []);
	placeholder = input(...ngDevMode ? [void 0, { debugName: "placeholder" }] : /* istanbul ignore next */ []);
	autocomplete = input(...ngDevMode ? [void 0, { debugName: "autocomplete" }] : /* istanbul ignore next */ []);
	keyboard = input(...ngDevMode ? [void 0, { debugName: "keyboard" }] : /* istanbul ignore next */ []);
	spinPosition = input(...ngDevMode ? [void 0, { debugName: "spinPosition" }] : /* istanbul ignore next */ []);
	spinner = input(...ngDevMode ? [void 0, { debugName: "spinner" }] : /* istanbul ignore next */ []);
	textAlign = input(...ngDevMode ? [void 0, { debugName: "textAlign" }] : /* istanbul ignore next */ []);
	intl = input(...ngDevMode ? [void 0, { debugName: "intl" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	size = input(...ngDevMode ? [void 0, { debugName: "size" }] : /* istanbul ignore next */ []);
	isClearable = input(...ngDevMode ? [void 0, { debugName: "isClearable" }] : /* istanbul ignore next */ []);
	appearance = input(...ngDevMode ? [void 0, { debugName: "appearance" }] : /* istanbul ignore next */ []);
	invalid = input(...ngDevMode ? [void 0, { debugName: "invalid" }] : /* istanbul ignore next */ []);
	value = input(...ngDevMode ? [void 0, { debugName: "value" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	label = input(...ngDevMode ? [void 0, { debugName: "label" }] : /* istanbul ignore next */ []);
	isBusy = input(...ngDevMode ? [void 0, { debugName: "isBusy" }] : /* istanbul ignore next */ []);
	step = input(...ngDevMode ? [void 0, { debugName: "step" }] : /* istanbul ignore next */ []);
	decimalPlaces = input(...ngDevMode ? [void 0, { debugName: "decimalPlaces" }] : /* istanbul ignore next */ []);
	min = input(...ngDevMode ? [void 0, { debugName: "min" }] : /* istanbul ignore next */ []);
	max = input(...ngDevMode ? [void 0, { debugName: "max" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	formatter = input(...ngDevMode ? [void 0, { debugName: "formatter" }] : /* istanbul ignore next */ []);
	parser = input(...ngDevMode ? [void 0, { debugName: "parser" }] : /* istanbul ignore next */ []);
	isFocused = input(...ngDevMode ? [void 0, { debugName: "isFocused" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	cleared = output();
	change = output();
	input = output();
	focus = output();
	blur = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	_accessor;
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._accessor = numberBoxElementValueAccessor(this._elementRef.nativeElement);
		this._elementRef.nativeElement.addController(this._accessor);
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			cleared: this.cleared,
			change: this.change,
			input: this.input,
			focus: this.focus,
			blur: this.blur,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
			this._accessor.releaseCallbacks();
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(NUMBER_BOX_DEFAULT_PROPS, { optional: true }) ?? {}, ["intl"]);
		const injectedIntl = inject(NUMBER_BOX_INTL, { optional: true });
		if (injectedIntl) {
			Object.assign(this._elementRef.nativeElement.intl, injectedIntl);
			this._elementRef.nativeElement.intl.changes.emit();
		}
	}
	writeValue(obj) {
		this._accessor.writeValue(obj);
	}
	registerOnChange(fn) {
		this._accessor.registerOnChange(fn);
	}
	registerOnTouched(fn) {
		this._accessor.registerOnTouched(fn);
	}
	setDisabledState(isDisabled) {
		this._accessor.setDisabled?.(isDisabled);
	}
	clear(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "clear", args);
	}
	reset(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "reset", args);
	}
	checkValidity(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "checkValidity", args);
	}
	assignToSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "assignToSlot", args);
	}
	getSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getSlotContent", args);
	}
	hasSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlotContent", args);
	}
	hasSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlot", args);
	}
	onSlotChanges(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onSlotChanges", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const readonlyValue = this.readonly();
			if (readonlyValue !== void 0) this._elementRef.nativeElement.readonly = readonlyValue;
			const requiredValue = this.required();
			if (requiredValue !== void 0) this._elementRef.nativeElement.required = requiredValue;
			const autofocusValue = this.autofocus();
			if (autofocusValue !== void 0) this._elementRef.nativeElement.autofocus = autofocusValue;
			const nameValue = this.name();
			if (nameValue !== void 0) this._elementRef.nativeElement.name = nameValue;
			const patternValue = this.pattern();
			if (patternValue !== void 0) this._elementRef.nativeElement.pattern = patternValue;
			const placeholderValue = this.placeholder();
			if (placeholderValue !== void 0) this._elementRef.nativeElement.placeholder = placeholderValue;
			const autocompleteValue = this.autocomplete();
			if (autocompleteValue !== void 0) this._elementRef.nativeElement.autocomplete = autocompleteValue;
			const keyboardValue = this.keyboard();
			if (keyboardValue !== void 0) this._elementRef.nativeElement.keyboard = keyboardValue;
			const spinPositionValue = this.spinPosition();
			if (spinPositionValue !== void 0) this._elementRef.nativeElement.spinPosition = spinPositionValue;
			const spinnerValue = this.spinner();
			if (spinnerValue !== void 0) this._elementRef.nativeElement.spinner = spinnerValue;
			const textAlignValue = this.textAlign();
			if (textAlignValue !== void 0) this._elementRef.nativeElement.textAlign = textAlignValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const sizeValue = this.size();
			if (sizeValue !== void 0) this._elementRef.nativeElement.size = sizeValue;
			const isClearableValue = this.isClearable();
			if (isClearableValue !== void 0) this._elementRef.nativeElement.isClearable = isClearableValue;
			const appearanceValue = this.appearance();
			if (appearanceValue !== void 0) this._elementRef.nativeElement.appearance = appearanceValue;
			const invalidValue = this.invalid();
			if (invalidValue !== void 0) this._elementRef.nativeElement.invalid = invalidValue;
			const valueValue = this.value();
			if (valueValue !== void 0) this._elementRef.nativeElement.value = valueValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const labelValue = this.label();
			if (labelValue !== void 0) this._elementRef.nativeElement.label = labelValue;
			const isBusyValue = this.isBusy();
			if (isBusyValue !== void 0) this._elementRef.nativeElement.isBusy = isBusyValue;
			const stepValue = this.step();
			if (stepValue !== void 0) this._elementRef.nativeElement.step = stepValue;
			const decimalPlacesValue = this.decimalPlaces();
			if (decimalPlacesValue !== void 0) this._elementRef.nativeElement.decimalPlaces = decimalPlacesValue;
			const minValue = this.min();
			if (minValue !== void 0) this._elementRef.nativeElement.min = minValue;
			const maxValue = this.max();
			if (maxValue !== void 0) this._elementRef.nativeElement.max = maxValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const formatterValue = this.formatter();
			if (formatterValue !== void 0) this._elementRef.nativeElement.formatter = formatterValue;
			const parserValue = this.parser();
			if (parserValue !== void 0) this._elementRef.nativeElement.parser = parserValue;
			const isFocusedValue = this.isFocused();
			if (isFocusedValue !== void 0) this._elementRef.nativeElement.isFocused = isFocusedValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
			const intlValue = this.intl();
			if (intlValue !== void 0) {
				Object.assign(this._elementRef.nativeElement.intl, intlValue);
				this._elementRef.nativeElement.intl.changes.emit();
			}
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NumberBoxComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: NumberBoxComponent,
		isStandalone: true,
		selector: "mosaik-numberbox",
		inputs: {
			readonly: {
				classPropertyName: "readonly",
				publicName: "readonly",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			required: {
				classPropertyName: "required",
				publicName: "required",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			autofocus: {
				classPropertyName: "autofocus",
				publicName: "autofocus",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			name: {
				classPropertyName: "name",
				publicName: "name",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			pattern: {
				classPropertyName: "pattern",
				publicName: "pattern",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			placeholder: {
				classPropertyName: "placeholder",
				publicName: "placeholder",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			autocomplete: {
				classPropertyName: "autocomplete",
				publicName: "autocomplete",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			keyboard: {
				classPropertyName: "keyboard",
				publicName: "keyboard",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			spinPosition: {
				classPropertyName: "spinPosition",
				publicName: "spinPosition",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			spinner: {
				classPropertyName: "spinner",
				publicName: "spinner",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			textAlign: {
				classPropertyName: "textAlign",
				publicName: "textAlign",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			intl: {
				classPropertyName: "intl",
				publicName: "intl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isClearable: {
				classPropertyName: "isClearable",
				publicName: "isClearable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			invalid: {
				classPropertyName: "invalid",
				publicName: "invalid",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isBusy: {
				classPropertyName: "isBusy",
				publicName: "isBusy",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			step: {
				classPropertyName: "step",
				publicName: "step",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			decimalPlaces: {
				classPropertyName: "decimalPlaces",
				publicName: "decimalPlaces",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			min: {
				classPropertyName: "min",
				publicName: "min",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			max: {
				classPropertyName: "max",
				publicName: "max",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			formatter: {
				classPropertyName: "formatter",
				publicName: "formatter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			parser: {
				classPropertyName: "parser",
				publicName: "parser",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isFocused: {
				classPropertyName: "isFocused",
				publicName: "isFocused",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			cleared: "cleared",
			change: "change",
			input: "input",
			focus: "focus",
			blur: "blur",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		providers: [{
			provide: NG_VALUE_ACCESSOR,
			useExisting: forwardRef(() => NumberBoxComponent),
			multi: true
		}, {
			provide: FORM_STATUS_HOST,
			useExisting: forwardRef(() => NumberBoxComponent)
		}],
		hostDirectives: [{ directive: i1.FormStatusHostDirective }, { directive: i1.FormFieldStatusHostDirective }],
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
NumberBoxComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-numberbox", NumberBoxElement),
	inputs: [
		"readonly",
		"required",
		"autofocus",
		"name",
		"pattern",
		"placeholder",
		"autocomplete",
		"keyboard",
		"spinPosition",
		"spinner",
		"textAlign",
		"intl",
		"themeName",
		"size",
		"isClearable",
		"appearance",
		"invalid",
		"value",
		"variant",
		"label",
		"isBusy",
		"step",
		"decimalPlaces",
		"min",
		"max",
		"disabled",
		"formatter",
		"parser",
		"isFocused",
		"dir",
		"lang"
	],
	methods: ["getSlotAssignments", "getSlotAssignmentsOf"]
}), __metadata("design:paramtypes", [])], NumberBoxComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NumberBoxComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-numberbox",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>",
			hostDirectives: [FormStatusHostDirective, FormFieldStatusHostDirective],
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => NumberBoxComponent),
				multi: true
			}, {
				provide: FORM_STATUS_HOST,
				useExisting: forwardRef(() => NumberBoxComponent)
			}]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		readonly: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "readonly",
				required: false
			}]
		}],
		required: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "required",
				required: false
			}]
		}],
		autofocus: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "autofocus",
				required: false
			}]
		}],
		name: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "name",
				required: false
			}]
		}],
		pattern: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "pattern",
				required: false
			}]
		}],
		placeholder: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "placeholder",
				required: false
			}]
		}],
		autocomplete: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "autocomplete",
				required: false
			}]
		}],
		keyboard: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "keyboard",
				required: false
			}]
		}],
		spinPosition: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "spinPosition",
				required: false
			}]
		}],
		spinner: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "spinner",
				required: false
			}]
		}],
		textAlign: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "textAlign",
				required: false
			}]
		}],
		intl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "intl",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		isClearable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isClearable",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		invalid: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "invalid",
				required: false
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		isBusy: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isBusy",
				required: false
			}]
		}],
		step: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "step",
				required: false
			}]
		}],
		decimalPlaces: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "decimalPlaces",
				required: false
			}]
		}],
		min: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "min",
				required: false
			}]
		}],
		max: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "max",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		formatter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "formatter",
				required: false
			}]
		}],
		parser: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "parser",
				required: false
			}]
		}],
		isFocused: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isFocused",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		cleared: [{
			type: i0.Output,
			args: ["cleared"]
		}],
		change: [{
			type: i0.Output,
			args: ["change"]
		}],
		input: [{
			type: i0.Output,
			args: ["input"]
		}],
		focus: [{
			type: i0.Output,
			args: ["focus"]
		}],
		blur: [{
			type: i0.Output,
			args: ["blur"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideNumberBoxComponent(config, intl) {
	const providers = [];
	if (config) providers.push({
		provide: NUMBER_BOX_DEFAULT_PROPS,
		useValue: config
	});
	if (intl) {
		if (typeof intl === "function") providers.push({
			provide: NUMBER_BOX_INTL,
			useClass: intl
		});
		else providers.push({
			provide: NUMBER_BOX_INTL,
			useValue: intl
		});
	}
	return makeEnvironmentProviders(providers);
}
export { NUMBER_BOX_DEFAULT_PROPS, NUMBER_BOX_INTL, NumberBoxComponent, provideNumberBoxComponent };

//# sourceMappingURL=mosaik-elements-angular-components-number-box.mjs.map