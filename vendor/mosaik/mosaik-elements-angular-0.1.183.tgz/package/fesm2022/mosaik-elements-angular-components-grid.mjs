import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { GridItemElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/grid/GridItemElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { GridElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/grid/GridElement";
var __decorate$1 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$1 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const GRID_ITEM_DEFAULT_PROPS = new InjectionToken("MOSAIK_GRID_ITEM_DEFAULT_PROPS");
let GridItemComponent = class GridItemComponent {
	column = input(...ngDevMode ? [void 0, { debugName: "column" }] : /* istanbul ignore next */ []);
	columnSpan = input(...ngDevMode ? [void 0, { debugName: "columnSpan" }] : /* istanbul ignore next */ []);
	row = input(...ngDevMode ? [void 0, { debugName: "row" }] : /* istanbul ignore next */ []);
	rowSpan = input(...ngDevMode ? [void 0, { debugName: "rowSpan" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(GRID_ITEM_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const columnValue = this.column();
			if (columnValue !== void 0) this._elementRef.nativeElement.column = columnValue;
			const columnSpanValue = this.columnSpan();
			if (columnSpanValue !== void 0) this._elementRef.nativeElement.columnSpan = columnSpanValue;
			const rowValue = this.row();
			if (rowValue !== void 0) this._elementRef.nativeElement.row = rowValue;
			const rowSpanValue = this.rowSpan();
			if (rowSpanValue !== void 0) this._elementRef.nativeElement.rowSpan = rowSpanValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: GridItemComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: GridItemComponent,
		isStandalone: true,
		selector: "mosaik-grid-item",
		inputs: {
			column: {
				classPropertyName: "column",
				publicName: "column",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			columnSpan: {
				classPropertyName: "columnSpan",
				publicName: "columnSpan",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			row: {
				classPropertyName: "row",
				publicName: "row",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			rowSpan: {
				classPropertyName: "rowSpan",
				publicName: "rowSpan",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
GridItemComponent = __decorate$1([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-grid-item", GridItemElement),
	inputs: [
		"column",
		"columnSpan",
		"row",
		"rowSpan",
		"themeName",
		"dir",
		"lang"
	]
}), __metadata$1("design:paramtypes", [])], GridItemComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: GridItemComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-grid-item",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		column: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "column",
				required: false
			}]
		}],
		columnSpan: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "columnSpan",
				required: false
			}]
		}],
		row: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "row",
				required: false
			}]
		}],
		rowSpan: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "rowSpan",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideGridItemComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: GRID_ITEM_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const GRID_DEFAULT_PROPS = new InjectionToken("MOSAIK_GRID_DEFAULT_PROPS");
let GridComponent = class GridComponent {
	rowDefinitions = input(...ngDevMode ? [void 0, { debugName: "rowDefinitions" }] : /* istanbul ignore next */ []);
	columnDefinitions = input(...ngDevMode ? [void 0, { debugName: "columnDefinitions" }] : /* istanbul ignore next */ []);
	gap = input(...ngDevMode ? [void 0, { debugName: "gap" }] : /* istanbul ignore next */ []);
	horizontalAlignment = input(...ngDevMode ? [void 0, { debugName: "horizontalAlignment" }] : /* istanbul ignore next */ []);
	verticalAlignment = input(...ngDevMode ? [void 0, { debugName: "verticalAlignment" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	changed = output();
	connected = output();
	disconnected = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			changed: this.changed,
			connected: this.connected,
			disconnected: this.disconnected
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(GRID_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const rowDefinitionsValue = this.rowDefinitions();
			if (rowDefinitionsValue !== void 0) this._elementRef.nativeElement.rowDefinitions = rowDefinitionsValue;
			const columnDefinitionsValue = this.columnDefinitions();
			if (columnDefinitionsValue !== void 0) this._elementRef.nativeElement.columnDefinitions = columnDefinitionsValue;
			const gapValue = this.gap();
			if (gapValue !== void 0) this._elementRef.nativeElement.gap = gapValue;
			const horizontalAlignmentValue = this.horizontalAlignment();
			if (horizontalAlignmentValue !== void 0) this._elementRef.nativeElement.horizontalAlignment = horizontalAlignmentValue;
			const verticalAlignmentValue = this.verticalAlignment();
			if (verticalAlignmentValue !== void 0) this._elementRef.nativeElement.verticalAlignment = verticalAlignmentValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: GridComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: GridComponent,
		isStandalone: true,
		selector: "mosaik-grid",
		inputs: {
			rowDefinitions: {
				classPropertyName: "rowDefinitions",
				publicName: "rowDefinitions",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			columnDefinitions: {
				classPropertyName: "columnDefinitions",
				publicName: "columnDefinitions",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			gap: {
				classPropertyName: "gap",
				publicName: "gap",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			horizontalAlignment: {
				classPropertyName: "horizontalAlignment",
				publicName: "horizontalAlignment",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			verticalAlignment: {
				classPropertyName: "verticalAlignment",
				publicName: "verticalAlignment",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			changed: "changed",
			connected: "connected",
			disconnected: "disconnected"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
GridComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-grid", GridElement),
	inputs: [
		"rowDefinitions",
		"columnDefinitions",
		"gap",
		"horizontalAlignment",
		"verticalAlignment",
		"themeName",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], GridComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: GridComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-grid",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		rowDefinitions: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "rowDefinitions",
				required: false
			}]
		}],
		columnDefinitions: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "columnDefinitions",
				required: false
			}]
		}],
		gap: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "gap",
				required: false
			}]
		}],
		horizontalAlignment: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "horizontalAlignment",
				required: false
			}]
		}],
		verticalAlignment: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "verticalAlignment",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}]
	}
});
function provideGridComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: GRID_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { GRID_DEFAULT_PROPS, GRID_ITEM_DEFAULT_PROPS, GridComponent, GridItemComponent, provideGridComponent, provideGridItemComponent };

//# sourceMappingURL=mosaik-elements-angular-components-grid.mjs.map