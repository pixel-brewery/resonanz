import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { PersonaElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/persona/PersonaElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const PERSONA_DEFAULT_PROPS = new InjectionToken("MOSAIK_PERSONA_DEFAULT_PROPS");
let PersonaComponent = class PersonaComponent {
	primaryText = input(...ngDevMode ? [void 0, { debugName: "primaryText" }] : /* istanbul ignore next */ []);
	secondaryText = input(...ngDevMode ? [void 0, { debugName: "secondaryText" }] : /* istanbul ignore next */ []);
	tertiaryText = input(...ngDevMode ? [void 0, { debugName: "tertiaryText" }] : /* istanbul ignore next */ []);
	quaternaryText = input(...ngDevMode ? [void 0, { debugName: "quaternaryText" }] : /* istanbul ignore next */ []);
	presence = input(...ngDevMode ? [void 0, { debugName: "presence" }] : /* istanbul ignore next */ []);
	orientation = input(...ngDevMode ? [void 0, { debugName: "orientation" }] : /* istanbul ignore next */ []);
	horizontalContentAlignment = input(...ngDevMode ? [void 0, { debugName: "horizontalContentAlignment" }] : /* istanbul ignore next */ []);
	verticalContentAlignment = input(...ngDevMode ? [void 0, { debugName: "verticalContentAlignment" }] : /* istanbul ignore next */ []);
	text = input(...ngDevMode ? [void 0, { debugName: "text" }] : /* istanbul ignore next */ []);
	textAccessor = input(...ngDevMode ? [void 0, { debugName: "textAccessor" }] : /* istanbul ignore next */ []);
	icon = input(...ngDevMode ? [void 0, { debugName: "icon" }] : /* istanbul ignore next */ []);
	src = input(...ngDevMode ? [void 0, { debugName: "src" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	size = input(...ngDevMode ? [void 0, { debugName: "size" }] : /* istanbul ignore next */ []);
	appearance = input(...ngDevMode ? [void 0, { debugName: "appearance" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(PERSONA_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	changeTextAccessor(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "changeTextAccessor", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const primaryTextValue = this.primaryText();
			if (primaryTextValue !== void 0) this._elementRef.nativeElement.primaryText = primaryTextValue;
			const secondaryTextValue = this.secondaryText();
			if (secondaryTextValue !== void 0) this._elementRef.nativeElement.secondaryText = secondaryTextValue;
			const tertiaryTextValue = this.tertiaryText();
			if (tertiaryTextValue !== void 0) this._elementRef.nativeElement.tertiaryText = tertiaryTextValue;
			const quaternaryTextValue = this.quaternaryText();
			if (quaternaryTextValue !== void 0) this._elementRef.nativeElement.quaternaryText = quaternaryTextValue;
			const presenceValue = this.presence();
			if (presenceValue !== void 0) this._elementRef.nativeElement.presence = presenceValue;
			const orientationValue = this.orientation();
			if (orientationValue !== void 0) this._elementRef.nativeElement.orientation = orientationValue;
			const horizontalContentAlignmentValue = this.horizontalContentAlignment();
			if (horizontalContentAlignmentValue !== void 0) this._elementRef.nativeElement.horizontalContentAlignment = horizontalContentAlignmentValue;
			const verticalContentAlignmentValue = this.verticalContentAlignment();
			if (verticalContentAlignmentValue !== void 0) this._elementRef.nativeElement.verticalContentAlignment = verticalContentAlignmentValue;
			const textValue = this.text();
			if (textValue !== void 0) this._elementRef.nativeElement.text = textValue;
			const textAccessorValue = this.textAccessor();
			if (textAccessorValue !== void 0) this._elementRef.nativeElement.textAccessor = textAccessorValue;
			const iconValue = this.icon();
			if (iconValue !== void 0) this._elementRef.nativeElement.icon = iconValue;
			const srcValue = this.src();
			if (srcValue !== void 0) this._elementRef.nativeElement.src = srcValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const sizeValue = this.size();
			if (sizeValue !== void 0) this._elementRef.nativeElement.size = sizeValue;
			const appearanceValue = this.appearance();
			if (appearanceValue !== void 0) this._elementRef.nativeElement.appearance = appearanceValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: PersonaComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: PersonaComponent,
		isStandalone: true,
		selector: "mosaik-persona",
		inputs: {
			primaryText: {
				classPropertyName: "primaryText",
				publicName: "primaryText",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			secondaryText: {
				classPropertyName: "secondaryText",
				publicName: "secondaryText",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			tertiaryText: {
				classPropertyName: "tertiaryText",
				publicName: "tertiaryText",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			quaternaryText: {
				classPropertyName: "quaternaryText",
				publicName: "quaternaryText",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			presence: {
				classPropertyName: "presence",
				publicName: "presence",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			orientation: {
				classPropertyName: "orientation",
				publicName: "orientation",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			horizontalContentAlignment: {
				classPropertyName: "horizontalContentAlignment",
				publicName: "horizontalContentAlignment",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			verticalContentAlignment: {
				classPropertyName: "verticalContentAlignment",
				publicName: "verticalContentAlignment",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			text: {
				classPropertyName: "text",
				publicName: "text",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			textAccessor: {
				classPropertyName: "textAccessor",
				publicName: "textAccessor",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			icon: {
				classPropertyName: "icon",
				publicName: "icon",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			src: {
				classPropertyName: "src",
				publicName: "src",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
PersonaComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-persona", PersonaElement),
	inputs: [
		"primaryText",
		"secondaryText",
		"tertiaryText",
		"quaternaryText",
		"presence",
		"orientation",
		"horizontalContentAlignment",
		"verticalContentAlignment",
		"text",
		"textAccessor",
		"icon",
		"src",
		"themeName",
		"size",
		"appearance",
		"variant",
		"disabled",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], PersonaComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: PersonaComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-persona",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		primaryText: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "primaryText",
				required: false
			}]
		}],
		secondaryText: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "secondaryText",
				required: false
			}]
		}],
		tertiaryText: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tertiaryText",
				required: false
			}]
		}],
		quaternaryText: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "quaternaryText",
				required: false
			}]
		}],
		presence: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "presence",
				required: false
			}]
		}],
		orientation: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "orientation",
				required: false
			}]
		}],
		horizontalContentAlignment: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "horizontalContentAlignment",
				required: false
			}]
		}],
		verticalContentAlignment: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "verticalContentAlignment",
				required: false
			}]
		}],
		text: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "text",
				required: false
			}]
		}],
		textAccessor: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "textAccessor",
				required: false
			}]
		}],
		icon: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "icon",
				required: false
			}]
		}],
		src: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "src",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function providePersonaComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: PERSONA_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { PERSONA_DEFAULT_PROPS, PersonaComponent, providePersonaComponent };

//# sourceMappingURL=mosaik-elements-angular-components-persona.mjs.map