import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { WalletCardElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/wallet-card/WalletCardElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const WALLET_CARD_DEFAULT_PROPS = new InjectionToken("MOSAIK_WALLET_CARD_DEFAULT_PROPS");
let WalletCardComponent = class WalletCardComponent {
	issuer = input(...ngDevMode ? [void 0, { debugName: "issuer" }] : /* istanbul ignore next */ []);
	title = input(...ngDevMode ? [void 0, { debugName: "title" }] : /* istanbul ignore next */ []);
	subtitle = input(...ngDevMode ? [void 0, { debugName: "subtitle" }] : /* istanbul ignore next */ []);
	holder = input(...ngDevMode ? [void 0, { debugName: "holder" }] : /* istanbul ignore next */ []);
	holderLabel = input(...ngDevMode ? [void 0, { debugName: "holderLabel" }] : /* istanbul ignore next */ []);
	identifier = input(...ngDevMode ? [void 0, { debugName: "identifier" }] : /* istanbul ignore next */ []);
	identifierLabel = input(...ngDevMode ? [void 0, { debugName: "identifierLabel" }] : /* istanbul ignore next */ []);
	validity = input(...ngDevMode ? [void 0, { debugName: "validity" }] : /* istanbul ignore next */ []);
	validityLabel = input(...ngDevMode ? [void 0, { debugName: "validityLabel" }] : /* istanbul ignore next */ []);
	image = input(...ngDevMode ? [void 0, { debugName: "image" }] : /* istanbul ignore next */ []);
	layout = input(...ngDevMode ? [void 0, { debugName: "layout" }] : /* istanbul ignore next */ []);
	ratio = input(...ngDevMode ? [void 0, { debugName: "ratio" }] : /* istanbul ignore next */ []);
	showChip = input(...ngDevMode ? [void 0, { debugName: "showChip" }] : /* istanbul ignore next */ []);
	showContactless = input(...ngDevMode ? [void 0, { debugName: "showContactless" }] : /* istanbul ignore next */ []);
	showMagneticStripe = input(...ngDevMode ? [void 0, { debugName: "showMagneticStripe" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	orientation = input(...ngDevMode ? [void 0, { debugName: "orientation" }] : /* istanbul ignore next */ []);
	label = input(...ngDevMode ? [void 0, { debugName: "label" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(WALLET_CARD_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	onSlotChanges(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onSlotChanges", args);
	}
	assignToSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "assignToSlot", args);
	}
	getSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getSlotContent", args);
	}
	hasSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlotContent", args);
	}
	hasSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlot", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const issuerValue = this.issuer();
			if (issuerValue !== void 0) this._elementRef.nativeElement.issuer = issuerValue;
			const titleValue = this.title();
			if (titleValue !== void 0) this._elementRef.nativeElement.title = titleValue;
			const subtitleValue = this.subtitle();
			if (subtitleValue !== void 0) this._elementRef.nativeElement.subtitle = subtitleValue;
			const holderValue = this.holder();
			if (holderValue !== void 0) this._elementRef.nativeElement.holder = holderValue;
			const holderLabelValue = this.holderLabel();
			if (holderLabelValue !== void 0) this._elementRef.nativeElement.holderLabel = holderLabelValue;
			const identifierValue = this.identifier();
			if (identifierValue !== void 0) this._elementRef.nativeElement.identifier = identifierValue;
			const identifierLabelValue = this.identifierLabel();
			if (identifierLabelValue !== void 0) this._elementRef.nativeElement.identifierLabel = identifierLabelValue;
			const validityLabelValue = this.validityLabel();
			if (validityLabelValue !== void 0) this._elementRef.nativeElement.validityLabel = validityLabelValue;
			const imageValue = this.image();
			if (imageValue !== void 0) this._elementRef.nativeElement.image = imageValue;
			const layoutValue = this.layout();
			if (layoutValue !== void 0) this._elementRef.nativeElement.layout = layoutValue;
			const ratioValue = this.ratio();
			if (ratioValue !== void 0) this._elementRef.nativeElement.ratio = ratioValue;
			const showChipValue = this.showChip();
			if (showChipValue !== void 0) this._elementRef.nativeElement.showChip = showChipValue;
			const showContactlessValue = this.showContactless();
			if (showContactlessValue !== void 0) this._elementRef.nativeElement.showContactless = showContactlessValue;
			const showMagneticStripeValue = this.showMagneticStripe();
			if (showMagneticStripeValue !== void 0) this._elementRef.nativeElement.showMagneticStripe = showMagneticStripeValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const orientationValue = this.orientation();
			if (orientationValue !== void 0) this._elementRef.nativeElement.orientation = orientationValue;
			const labelValue = this.label();
			if (labelValue !== void 0) this._elementRef.nativeElement.label = labelValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: WalletCardComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: WalletCardComponent,
		isStandalone: true,
		selector: "mosaik-wallet-card",
		inputs: {
			issuer: {
				classPropertyName: "issuer",
				publicName: "issuer",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			title: {
				classPropertyName: "title",
				publicName: "title",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			subtitle: {
				classPropertyName: "subtitle",
				publicName: "subtitle",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			holder: {
				classPropertyName: "holder",
				publicName: "holder",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			holderLabel: {
				classPropertyName: "holderLabel",
				publicName: "holderLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			identifier: {
				classPropertyName: "identifier",
				publicName: "identifier",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			identifierLabel: {
				classPropertyName: "identifierLabel",
				publicName: "identifierLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			validity: {
				classPropertyName: "validity",
				publicName: "validity",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			validityLabel: {
				classPropertyName: "validityLabel",
				publicName: "validityLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			image: {
				classPropertyName: "image",
				publicName: "image",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			layout: {
				classPropertyName: "layout",
				publicName: "layout",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			ratio: {
				classPropertyName: "ratio",
				publicName: "ratio",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showChip: {
				classPropertyName: "showChip",
				publicName: "showChip",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showContactless: {
				classPropertyName: "showContactless",
				publicName: "showContactless",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showMagneticStripe: {
				classPropertyName: "showMagneticStripe",
				publicName: "showMagneticStripe",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			orientation: {
				classPropertyName: "orientation",
				publicName: "orientation",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
WalletCardComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-wallet-card", WalletCardElement),
	inputs: [
		"issuer",
		"title",
		"subtitle",
		"holder",
		"holderLabel",
		"identifier",
		"identifierLabel",
		"validity",
		"validityLabel",
		"image",
		"layout",
		"ratio",
		"showChip",
		"showContactless",
		"showMagneticStripe",
		"themeName",
		"orientation",
		"label",
		"dir",
		"lang"
	],
	methods: ["getSlotAssignments", "getSlotAssignmentsOf"]
}), __metadata("design:paramtypes", [])], WalletCardComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: WalletCardComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-wallet-card",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		issuer: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "issuer",
				required: false
			}]
		}],
		title: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "title",
				required: false
			}]
		}],
		subtitle: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "subtitle",
				required: false
			}]
		}],
		holder: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "holder",
				required: false
			}]
		}],
		holderLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "holderLabel",
				required: false
			}]
		}],
		identifier: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "identifier",
				required: false
			}]
		}],
		identifierLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "identifierLabel",
				required: false
			}]
		}],
		validity: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "validity",
				required: false
			}]
		}],
		validityLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "validityLabel",
				required: false
			}]
		}],
		image: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "image",
				required: false
			}]
		}],
		layout: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "layout",
				required: false
			}]
		}],
		ratio: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "ratio",
				required: false
			}]
		}],
		showChip: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showChip",
				required: false
			}]
		}],
		showContactless: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showContactless",
				required: false
			}]
		}],
		showMagneticStripe: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showMagneticStripe",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		orientation: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "orientation",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideWalletCardComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: WALLET_CARD_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { WALLET_CARD_DEFAULT_PROPS, WalletCardComponent, provideWalletCardComponent };

//# sourceMappingURL=mosaik-elements-angular-components-wallet-card.mjs.map