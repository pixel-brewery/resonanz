import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { PaginatorElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/paginator/PaginatorElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const PAGINATOR_DEFAULT_PROPS = new InjectionToken("MOSAIK_PAGINATOR_DEFAULT_PROPS");
const PAGINATOR_INTL = new InjectionToken("MOSAIK_PAGINATOR_INTL");
let PaginatorComponent = class PaginatorComponent {
	intl = input(...ngDevMode ? [void 0, { debugName: "intl" }] : /* istanbul ignore next */ []);
	total = input(...ngDevMode ? [void 0, { debugName: "total" }] : /* istanbul ignore next */ []);
	totalRecords = input(...ngDevMode ? [void 0, { debugName: "totalRecords" }] : /* istanbul ignore next */ []);
	size = input(...ngDevMode ? [void 0, { debugName: "size" }] : /* istanbul ignore next */ []);
	rows = input(...ngDevMode ? [void 0, { debugName: "rows" }] : /* istanbul ignore next */ []);
	sizes = input(...ngDevMode ? [void 0, { debugName: "sizes" }] : /* istanbul ignore next */ []);
	showSizes = input(...ngDevMode ? [void 0, { debugName: "showSizes" }] : /* istanbul ignore next */ []);
	currentPage = input(...ngDevMode ? [void 0, { debugName: "currentPage" }] : /* istanbul ignore next */ []);
	first = input(...ngDevMode ? [void 0, { debugName: "first" }] : /* istanbul ignore next */ []);
	pageLinkSize = input(...ngDevMode ? [void 0, { debugName: "pageLinkSize" }] : /* istanbul ignore next */ []);
	alwaysShow = input(...ngDevMode ? [void 0, { debugName: "alwaysShow" }] : /* istanbul ignore next */ []);
	showPageLinks = input(...ngDevMode ? [void 0, { debugName: "showPageLinks" }] : /* istanbul ignore next */ []);
	showFirstLastIcon = input(...ngDevMode ? [void 0, { debugName: "showFirstLastIcon" }] : /* istanbul ignore next */ []);
	showFirstLastButtons = input(...ngDevMode ? [void 0, { debugName: "showFirstLastButtons" }] : /* istanbul ignore next */ []);
	showCurrentPageReport = input(...ngDevMode ? [void 0, { debugName: "showCurrentPageReport" }] : /* istanbul ignore next */ []);
	currentPageReportTemplate = input(...ngDevMode ? [void 0, { debugName: "currentPageReportTemplate" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	appearance = input(...ngDevMode ? [void 0, { debugName: "appearance" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	pageChanged = output();
	pageSizeChanged = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			pageChanged: this.pageChanged,
			pageSizeChanged: this.pageSizeChanged,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(PAGINATOR_DEFAULT_PROPS, { optional: true }) ?? {}, ["intl"]);
		const injectedIntl = inject(PAGINATOR_INTL, { optional: true });
		if (injectedIntl) {
			Object.assign(this._elementRef.nativeElement.intl, injectedIntl);
			this._elementRef.nativeElement.intl.changes.emit();
		}
	}
	goToFirstPage(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "goToFirstPage", args);
	}
	goToLastPage(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "goToLastPage", args);
	}
	goToNextPage(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "goToNextPage", args);
	}
	goToPreviousPage(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "goToPreviousPage", args);
	}
	goToPage(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "goToPage", args);
	}
	changePageSize(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "changePageSize", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const totalValue = this.total();
			if (totalValue !== void 0) this._elementRef.nativeElement.total = totalValue;
			const totalRecordsValue = this.totalRecords();
			if (totalRecordsValue !== void 0) this._elementRef.nativeElement.totalRecords = totalRecordsValue;
			const sizeValue = this.size();
			if (sizeValue !== void 0) this._elementRef.nativeElement.size = sizeValue;
			const rowsValue = this.rows();
			if (rowsValue !== void 0) this._elementRef.nativeElement.rows = rowsValue;
			const sizesValue = this.sizes();
			if (sizesValue !== void 0) this._elementRef.nativeElement.sizes = sizesValue;
			const showSizesValue = this.showSizes();
			if (showSizesValue !== void 0) this._elementRef.nativeElement.showSizes = showSizesValue;
			const currentPageValue = this.currentPage();
			if (currentPageValue !== void 0) this._elementRef.nativeElement.currentPage = currentPageValue;
			const firstValue = this.first();
			if (firstValue !== void 0) this._elementRef.nativeElement.first = firstValue;
			const pageLinkSizeValue = this.pageLinkSize();
			if (pageLinkSizeValue !== void 0) this._elementRef.nativeElement.pageLinkSize = pageLinkSizeValue;
			const alwaysShowValue = this.alwaysShow();
			if (alwaysShowValue !== void 0) this._elementRef.nativeElement.alwaysShow = alwaysShowValue;
			const showPageLinksValue = this.showPageLinks();
			if (showPageLinksValue !== void 0) this._elementRef.nativeElement.showPageLinks = showPageLinksValue;
			const showFirstLastIconValue = this.showFirstLastIcon();
			if (showFirstLastIconValue !== void 0) this._elementRef.nativeElement.showFirstLastIcon = showFirstLastIconValue;
			const showFirstLastButtonsValue = this.showFirstLastButtons();
			if (showFirstLastButtonsValue !== void 0) this._elementRef.nativeElement.showFirstLastButtons = showFirstLastButtonsValue;
			const showCurrentPageReportValue = this.showCurrentPageReport();
			if (showCurrentPageReportValue !== void 0) this._elementRef.nativeElement.showCurrentPageReport = showCurrentPageReportValue;
			const currentPageReportTemplateValue = this.currentPageReportTemplate();
			if (currentPageReportTemplateValue !== void 0) this._elementRef.nativeElement.currentPageReportTemplate = currentPageReportTemplateValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const appearanceValue = this.appearance();
			if (appearanceValue !== void 0) this._elementRef.nativeElement.appearance = appearanceValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
			const intlValue = this.intl();
			if (intlValue !== void 0) {
				Object.assign(this._elementRef.nativeElement.intl, intlValue);
				this._elementRef.nativeElement.intl.changes.emit();
			}
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: PaginatorComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: PaginatorComponent,
		isStandalone: true,
		selector: "mosaik-paginator",
		inputs: {
			intl: {
				classPropertyName: "intl",
				publicName: "intl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			total: {
				classPropertyName: "total",
				publicName: "total",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			totalRecords: {
				classPropertyName: "totalRecords",
				publicName: "totalRecords",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			rows: {
				classPropertyName: "rows",
				publicName: "rows",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			sizes: {
				classPropertyName: "sizes",
				publicName: "sizes",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showSizes: {
				classPropertyName: "showSizes",
				publicName: "showSizes",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			currentPage: {
				classPropertyName: "currentPage",
				publicName: "currentPage",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			first: {
				classPropertyName: "first",
				publicName: "first",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			pageLinkSize: {
				classPropertyName: "pageLinkSize",
				publicName: "pageLinkSize",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			alwaysShow: {
				classPropertyName: "alwaysShow",
				publicName: "alwaysShow",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showPageLinks: {
				classPropertyName: "showPageLinks",
				publicName: "showPageLinks",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showFirstLastIcon: {
				classPropertyName: "showFirstLastIcon",
				publicName: "showFirstLastIcon",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showFirstLastButtons: {
				classPropertyName: "showFirstLastButtons",
				publicName: "showFirstLastButtons",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showCurrentPageReport: {
				classPropertyName: "showCurrentPageReport",
				publicName: "showCurrentPageReport",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			currentPageReportTemplate: {
				classPropertyName: "currentPageReportTemplate",
				publicName: "currentPageReportTemplate",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			pageChanged: "pageChanged",
			pageSizeChanged: "pageSizeChanged",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
PaginatorComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-paginator", PaginatorElement),
	inputs: [
		"intl",
		"total",
		"totalRecords",
		"size",
		"rows",
		"sizes",
		"showSizes",
		"currentPage",
		"first",
		"pageLinkSize",
		"alwaysShow",
		"showPageLinks",
		"showFirstLastIcon",
		"showFirstLastButtons",
		"showCurrentPageReport",
		"currentPageReportTemplate",
		"themeName",
		"disabled",
		"variant",
		"appearance",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], PaginatorComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: PaginatorComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-paginator",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		intl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "intl",
				required: false
			}]
		}],
		total: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "total",
				required: false
			}]
		}],
		totalRecords: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "totalRecords",
				required: false
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		rows: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "rows",
				required: false
			}]
		}],
		sizes: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "sizes",
				required: false
			}]
		}],
		showSizes: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showSizes",
				required: false
			}]
		}],
		currentPage: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "currentPage",
				required: false
			}]
		}],
		first: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "first",
				required: false
			}]
		}],
		pageLinkSize: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "pageLinkSize",
				required: false
			}]
		}],
		alwaysShow: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "alwaysShow",
				required: false
			}]
		}],
		showPageLinks: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showPageLinks",
				required: false
			}]
		}],
		showFirstLastIcon: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showFirstLastIcon",
				required: false
			}]
		}],
		showFirstLastButtons: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showFirstLastButtons",
				required: false
			}]
		}],
		showCurrentPageReport: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showCurrentPageReport",
				required: false
			}]
		}],
		currentPageReportTemplate: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "currentPageReportTemplate",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		pageChanged: [{
			type: i0.Output,
			args: ["pageChanged"]
		}],
		pageSizeChanged: [{
			type: i0.Output,
			args: ["pageSizeChanged"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function providePaginatorComponent(config, intl) {
	const providers = [];
	if (config) providers.push({
		provide: PAGINATOR_DEFAULT_PROPS,
		useValue: config
	});
	if (intl) {
		if (typeof intl === "function") providers.push({
			provide: PAGINATOR_INTL,
			useClass: intl
		});
		else providers.push({
			provide: PAGINATOR_INTL,
			useValue: intl
		});
	}
	return makeEnvironmentProviders(providers);
}
export { PAGINATOR_DEFAULT_PROPS, PAGINATOR_INTL, PaginatorComponent, providePaginatorComponent };

//# sourceMappingURL=mosaik-elements-angular-components-paginator.mjs.map