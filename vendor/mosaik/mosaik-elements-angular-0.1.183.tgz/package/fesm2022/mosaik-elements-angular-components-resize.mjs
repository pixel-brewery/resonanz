import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { ResizeElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/resize/ResizeElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const RESIZE_DEFAULT_PROPS = new InjectionToken("MOSAIK_RESIZE_DEFAULT_PROPS");
let ResizeComponent = class ResizeComponent {
	ghostFactory = input(...ngDevMode ? [void 0, { debugName: "ghostFactory" }] : /* istanbul ignore next */ []);
	mode = input(...ngDevMode ? [void 0, { debugName: "mode" }] : /* istanbul ignore next */ []);
	active = input(...ngDevMode ? [void 0, { debugName: "active" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	resizeResizeStarted = output();
	resizeResized = output();
	resizeResizeEnded = output();
	resizeResizeCanceled = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			resizeResizeStarted: this.resizeResizeStarted,
			resizeResized: this.resizeResized,
			resizeResizeEnded: this.resizeResizeEnded,
			resizeResizeCanceled: this.resizeResizeCanceled,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(RESIZE_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	assignToSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "assignToSlot", args);
	}
	getSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getSlotContent", args);
	}
	hasSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlotContent", args);
	}
	hasSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlot", args);
	}
	onSlotChanges(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onSlotChanges", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const ghostFactoryValue = this.ghostFactory();
			if (ghostFactoryValue !== void 0) this._elementRef.nativeElement.ghostFactory = ghostFactoryValue;
			const modeValue = this.mode();
			if (modeValue !== void 0) this._elementRef.nativeElement.mode = modeValue;
			const activeValue = this.active();
			if (activeValue !== void 0) this._elementRef.nativeElement.active = activeValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ResizeComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: ResizeComponent,
		isStandalone: true,
		selector: "mosaik-resize",
		inputs: {
			ghostFactory: {
				classPropertyName: "ghostFactory",
				publicName: "ghostFactory",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			mode: {
				classPropertyName: "mode",
				publicName: "mode",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			active: {
				classPropertyName: "active",
				publicName: "active",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			resizeResizeStarted: "resizeResizeStarted",
			resizeResized: "resizeResized",
			resizeResizeEnded: "resizeResizeEnded",
			resizeResizeCanceled: "resizeResizeCanceled",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
ResizeComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-resize", ResizeElement),
	inputs: [
		"ghostFactory",
		"mode",
		"active",
		"themeName",
		"dir",
		"lang"
	],
	methods: ["getSlotAssignments", "getSlotAssignmentsOf"]
}), __metadata("design:paramtypes", [])], ResizeComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ResizeComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-resize",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		ghostFactory: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "ghostFactory",
				required: false
			}]
		}],
		mode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mode",
				required: false
			}]
		}],
		active: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "active",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		resizeResizeStarted: [{
			type: i0.Output,
			args: ["resizeResizeStarted"]
		}],
		resizeResized: [{
			type: i0.Output,
			args: ["resizeResized"]
		}],
		resizeResizeEnded: [{
			type: i0.Output,
			args: ["resizeResizeEnded"]
		}],
		resizeResizeCanceled: [{
			type: i0.Output,
			args: ["resizeResizeCanceled"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideResizeComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: RESIZE_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { RESIZE_DEFAULT_PROPS, ResizeComponent, provideResizeComponent };

//# sourceMappingURL=mosaik-elements-angular-components-resize.mjs.map