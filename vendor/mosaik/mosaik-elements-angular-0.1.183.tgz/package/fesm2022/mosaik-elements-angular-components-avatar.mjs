import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, forwardRef, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { AvatarGroupElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/avatar/AvatarGroupElement";
import * as i1 from "@pixel-brewery/mosaik-elements-angular/runtime";
import { FORM_STATUS_HOST, FormFieldStatusHostDirective, FormStatusHostDirective, ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { NG_VALUE_ACCESSOR } from "@angular/forms";
import { AvatarElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/avatar/AvatarElement";
import { avatarElementValueAccessor } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/avatar/accessors/AvatarElementValueAccessor";
var __decorate$1 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$1 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const AVATAR_GROUP_DEFAULT_PROPS = new InjectionToken("MOSAIK_AVATAR_GROUP_DEFAULT_PROPS");
let AvatarGroupComponent = class AvatarGroupComponent {
	maxLength = input(...ngDevMode ? [void 0, { debugName: "maxLength" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	size = input(...ngDevMode ? [void 0, { debugName: "size" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	appearance = input(...ngDevMode ? [void 0, { debugName: "appearance" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(AVATAR_GROUP_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const maxLengthValue = this.maxLength();
			if (maxLengthValue !== void 0) this._elementRef.nativeElement.maxLength = maxLengthValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const sizeValue = this.size();
			if (sizeValue !== void 0) this._elementRef.nativeElement.size = sizeValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const appearanceValue = this.appearance();
			if (appearanceValue !== void 0) this._elementRef.nativeElement.appearance = appearanceValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: AvatarGroupComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: AvatarGroupComponent,
		isStandalone: true,
		selector: "mosaik-avatar-group",
		inputs: {
			maxLength: {
				classPropertyName: "maxLength",
				publicName: "maxLength",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
AvatarGroupComponent = __decorate$1([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-avatar-group", AvatarGroupElement),
	inputs: [
		"maxLength",
		"themeName",
		"disabled",
		"size",
		"variant",
		"appearance",
		"dir",
		"lang"
	]
}), __metadata$1("design:paramtypes", [])], AvatarGroupComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: AvatarGroupComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-avatar-group",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		maxLength: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maxLength",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideAvatarGroupComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: AVATAR_GROUP_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const AVATAR_DEFAULT_PROPS = new InjectionToken("MOSAIK_AVATAR_DEFAULT_PROPS");
let AvatarComponent = class AvatarComponent {
	text = input(...ngDevMode ? [void 0, { debugName: "text" }] : /* istanbul ignore next */ []);
	textAccessor = input(...ngDevMode ? [void 0, { debugName: "textAccessor" }] : /* istanbul ignore next */ []);
	icon = input(...ngDevMode ? [void 0, { debugName: "icon" }] : /* istanbul ignore next */ []);
	src = input(...ngDevMode ? [void 0, { debugName: "src" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	size = input(...ngDevMode ? [void 0, { debugName: "size" }] : /* istanbul ignore next */ []);
	appearance = input(...ngDevMode ? [void 0, { debugName: "appearance" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	_accessor;
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._accessor = avatarElementValueAccessor(this._elementRef.nativeElement);
		this._elementRef.nativeElement.addController(this._accessor);
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
			this._accessor.releaseCallbacks();
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(AVATAR_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	writeValue(obj) {
		this._accessor.writeValue(obj);
	}
	registerOnChange(fn) {
		this._accessor.registerOnChange(fn);
	}
	registerOnTouched(fn) {
		this._accessor.registerOnTouched(fn);
	}
	setDisabledState(isDisabled) {
		this._accessor.setDisabled?.(isDisabled);
	}
	changeTextAccessor(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "changeTextAccessor", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const textValue = this.text();
			if (textValue !== void 0) this._elementRef.nativeElement.text = textValue;
			const textAccessorValue = this.textAccessor();
			if (textAccessorValue !== void 0) this._elementRef.nativeElement.textAccessor = textAccessorValue;
			const iconValue = this.icon();
			if (iconValue !== void 0) this._elementRef.nativeElement.icon = iconValue;
			const srcValue = this.src();
			if (srcValue !== void 0) this._elementRef.nativeElement.src = srcValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const sizeValue = this.size();
			if (sizeValue !== void 0) this._elementRef.nativeElement.size = sizeValue;
			const appearanceValue = this.appearance();
			if (appearanceValue !== void 0) this._elementRef.nativeElement.appearance = appearanceValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: AvatarComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: AvatarComponent,
		isStandalone: true,
		selector: "mosaik-avatar",
		inputs: {
			text: {
				classPropertyName: "text",
				publicName: "text",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			textAccessor: {
				classPropertyName: "textAccessor",
				publicName: "textAccessor",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			icon: {
				classPropertyName: "icon",
				publicName: "icon",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			src: {
				classPropertyName: "src",
				publicName: "src",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		providers: [{
			provide: NG_VALUE_ACCESSOR,
			useExisting: forwardRef(() => AvatarComponent),
			multi: true
		}, {
			provide: FORM_STATUS_HOST,
			useExisting: forwardRef(() => AvatarComponent)
		}],
		hostDirectives: [{ directive: i1.FormStatusHostDirective }, { directive: i1.FormFieldStatusHostDirective }],
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
AvatarComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-avatar", AvatarElement),
	inputs: [
		"text",
		"textAccessor",
		"icon",
		"src",
		"themeName",
		"size",
		"appearance",
		"variant",
		"disabled",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], AvatarComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: AvatarComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-avatar",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>",
			hostDirectives: [FormStatusHostDirective, FormFieldStatusHostDirective],
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => AvatarComponent),
				multi: true
			}, {
				provide: FORM_STATUS_HOST,
				useExisting: forwardRef(() => AvatarComponent)
			}]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		text: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "text",
				required: false
			}]
		}],
		textAccessor: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "textAccessor",
				required: false
			}]
		}],
		icon: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "icon",
				required: false
			}]
		}],
		src: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "src",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideAvatarComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: AVATAR_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { AVATAR_DEFAULT_PROPS, AVATAR_GROUP_DEFAULT_PROPS, AvatarComponent, AvatarGroupComponent, provideAvatarComponent, provideAvatarGroupComponent };

//# sourceMappingURL=mosaik-elements-angular-components-avatar.mjs.map