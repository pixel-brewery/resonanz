import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { OrbitElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/illustrations/orbit/OrbitElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const ORBIT_DEFAULT_PROPS = new InjectionToken("MOSAIK_ORBIT_DEFAULT_PROPS");
let OrbitComponent = class OrbitComponent {
	rings = input(...ngDevMode ? [void 0, { debugName: "rings" }] : /* istanbul ignore next */ []);
	radius = input(...ngDevMode ? [void 0, { debugName: "radius" }] : /* istanbul ignore next */ []);
	duration = input(...ngDevMode ? [void 0, { debugName: "duration" }] : /* istanbul ignore next */ []);
	steps = input(...ngDevMode ? [void 0, { debugName: "steps" }] : /* istanbul ignore next */ []);
	ringDurations = input(...ngDevMode ? [void 0, { debugName: "ringDurations" }] : /* istanbul ignore next */ []);
	ringReverse = input(...ngDevMode ? [void 0, { debugName: "ringReverse" }] : /* istanbul ignore next */ []);
	dashed = input(...ngDevMode ? [void 0, { debugName: "dashed" }] : /* istanbul ignore next */ []);
	startAngle = input(...ngDevMode ? [void 0, { debugName: "startAngle" }] : /* istanbul ignore next */ []);
	upright = input(...ngDevMode ? [void 0, { debugName: "upright" }] : /* istanbul ignore next */ []);
	fanOut = input(...ngDevMode ? [void 0, { debugName: "fanOut" }] : /* istanbul ignore next */ []);
	reverse = input(...ngDevMode ? [void 0, { debugName: "reverse" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(ORBIT_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	onSlotChanges(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onSlotChanges", args);
	}
	assignToSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "assignToSlot", args);
	}
	getSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getSlotContent", args);
	}
	hasSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlotContent", args);
	}
	hasSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlot", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const ringsValue = this.rings();
			if (ringsValue !== void 0) this._elementRef.nativeElement.rings = ringsValue;
			const radiusValue = this.radius();
			if (radiusValue !== void 0) this._elementRef.nativeElement.radius = radiusValue;
			const durationValue = this.duration();
			if (durationValue !== void 0) this._elementRef.nativeElement.duration = durationValue;
			const stepsValue = this.steps();
			if (stepsValue !== void 0) this._elementRef.nativeElement.steps = stepsValue;
			const ringDurationsValue = this.ringDurations();
			if (ringDurationsValue !== void 0) this._elementRef.nativeElement.ringDurations = ringDurationsValue;
			const ringReverseValue = this.ringReverse();
			if (ringReverseValue !== void 0) this._elementRef.nativeElement.ringReverse = ringReverseValue;
			const dashedValue = this.dashed();
			if (dashedValue !== void 0) this._elementRef.nativeElement.dashed = dashedValue;
			const startAngleValue = this.startAngle();
			if (startAngleValue !== void 0) this._elementRef.nativeElement.startAngle = startAngleValue;
			const uprightValue = this.upright();
			if (uprightValue !== void 0) this._elementRef.nativeElement.upright = uprightValue;
			const fanOutValue = this.fanOut();
			if (fanOutValue !== void 0) this._elementRef.nativeElement.fanOut = fanOutValue;
			const reverseValue = this.reverse();
			if (reverseValue !== void 0) this._elementRef.nativeElement.reverse = reverseValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: OrbitComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: OrbitComponent,
		isStandalone: true,
		selector: "mosaik-orbit",
		inputs: {
			rings: {
				classPropertyName: "rings",
				publicName: "rings",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			radius: {
				classPropertyName: "radius",
				publicName: "radius",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			duration: {
				classPropertyName: "duration",
				publicName: "duration",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			steps: {
				classPropertyName: "steps",
				publicName: "steps",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			ringDurations: {
				classPropertyName: "ringDurations",
				publicName: "ringDurations",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			ringReverse: {
				classPropertyName: "ringReverse",
				publicName: "ringReverse",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dashed: {
				classPropertyName: "dashed",
				publicName: "dashed",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			startAngle: {
				classPropertyName: "startAngle",
				publicName: "startAngle",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			upright: {
				classPropertyName: "upright",
				publicName: "upright",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			fanOut: {
				classPropertyName: "fanOut",
				publicName: "fanOut",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			reverse: {
				classPropertyName: "reverse",
				publicName: "reverse",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
OrbitComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-orbit", OrbitElement),
	inputs: [
		"rings",
		"radius",
		"duration",
		"steps",
		"ringDurations",
		"ringReverse",
		"dashed",
		"startAngle",
		"upright",
		"fanOut",
		"reverse",
		"themeName",
		"dir",
		"lang"
	],
	methods: ["getSlotAssignments", "getSlotAssignmentsOf"]
}), __metadata("design:paramtypes", [])], OrbitComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: OrbitComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-orbit",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		rings: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "rings",
				required: false
			}]
		}],
		radius: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "radius",
				required: false
			}]
		}],
		duration: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "duration",
				required: false
			}]
		}],
		steps: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "steps",
				required: false
			}]
		}],
		ringDurations: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "ringDurations",
				required: false
			}]
		}],
		ringReverse: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "ringReverse",
				required: false
			}]
		}],
		dashed: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dashed",
				required: false
			}]
		}],
		startAngle: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "startAngle",
				required: false
			}]
		}],
		upright: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "upright",
				required: false
			}]
		}],
		fanOut: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "fanOut",
				required: false
			}]
		}],
		reverse: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "reverse",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideOrbitComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: ORBIT_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { ORBIT_DEFAULT_PROPS, OrbitComponent, provideOrbitComponent };

//# sourceMappingURL=mosaik-elements-angular-components-orbit.mjs.map