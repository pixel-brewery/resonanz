import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { Theme2Element } from "@pixel-brewery/mosaik-elements-foundation/dist/theming/Theme2Element";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const THEME2_DEFAULT_PROPS = new InjectionToken("MOSAIK_THEME2_DEFAULT_PROPS");
let Theme2Component = class Theme2Component {
	name = input(...ngDevMode ? [void 0, { debugName: "name" }] : /* istanbul ignore next */ []);
	theme = input(...ngDevMode ? [void 0, { debugName: "theme" }] : /* istanbul ignore next */ []);
	global = input(...ngDevMode ? [void 0, { debugName: "global" }] : /* istanbul ignore next */ []);
	themeMode = input(...ngDevMode ? [void 0, { debugName: "themeMode" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(THEME2_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	applyTheme(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "applyTheme", args);
	}
	applyScheme(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "applyScheme", args);
	}
	applyPalette(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "applyPalette", args);
	}
	applyFontFamily(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "applyFontFamily", args);
	}
	applyTypography(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "applyTypography", args);
	}
	applyLayout(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "applyLayout", args);
	}
	applyElevation(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "applyElevation", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const nameValue = this.name();
			if (nameValue !== void 0) this._elementRef.nativeElement.name = nameValue;
			const themeValue = this.theme();
			if (themeValue !== void 0) this._elementRef.nativeElement.theme = themeValue;
			const globalValue = this.global();
			if (globalValue !== void 0) this._elementRef.nativeElement.global = globalValue;
			const themeModeValue = this.themeMode();
			if (themeModeValue !== void 0) this._elementRef.nativeElement.themeMode = themeModeValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: Theme2Component,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: Theme2Component,
		isStandalone: true,
		selector: "mosaik-theme2",
		inputs: {
			name: {
				classPropertyName: "name",
				publicName: "name",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			theme: {
				classPropertyName: "theme",
				publicName: "theme",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			global: {
				classPropertyName: "global",
				publicName: "global",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeMode: {
				classPropertyName: "themeMode",
				publicName: "themeMode",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
Theme2Component = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-theme2", Theme2Element),
	inputs: [
		"name",
		"theme",
		"global",
		"themeMode",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], Theme2Component);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: Theme2Component,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-theme2",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		name: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "name",
				required: false
			}]
		}],
		theme: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "theme",
				required: false
			}]
		}],
		global: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "global",
				required: false
			}]
		}],
		themeMode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeMode",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideTheme2Component(config) {
	const providers = [];
	if (config) providers.push({
		provide: THEME2_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { THEME2_DEFAULT_PROPS, Theme2Component, provideTheme2Component };

//# sourceMappingURL=mosaik-elements-angular-theming.mjs.map