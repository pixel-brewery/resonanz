import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { ResizeThumbElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/resize-thumb/ResizeThumbElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const RESIZE_THUMB_DEFAULT_PROPS = new InjectionToken("MOSAIK_RESIZE_THUMB_DEFAULT_PROPS");
let ResizeThumbComponent = class ResizeThumbComponent {
	direction = input(...ngDevMode ? [void 0, { debugName: "direction" }] : /* istanbul ignore next */ []);
	allowedDirections = input(...ngDevMode ? [void 0, { debugName: "allowedDirections" }] : /* istanbul ignore next */ []);
	minWidth = input(...ngDevMode ? [void 0, { debugName: "minWidth" }] : /* istanbul ignore next */ []);
	minHeight = input(...ngDevMode ? [void 0, { debugName: "minHeight" }] : /* istanbul ignore next */ []);
	maxWidth = input(...ngDevMode ? [void 0, { debugName: "maxWidth" }] : /* istanbul ignore next */ []);
	maxHeight = input(...ngDevMode ? [void 0, { debugName: "maxHeight" }] : /* istanbul ignore next */ []);
	autoApply = input(...ngDevMode ? [void 0, { debugName: "autoApply" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	for = input(...ngDevMode ? [void 0, { debugName: "for" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	resizeStart = output();
	resizing = output();
	resizeEnd = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			resizeStart: this.resizeStart,
			resizing: this.resizing,
			resizeEnd: this.resizeEnd,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(RESIZE_THUMB_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	attach(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "attach", args);
	}
	detach(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "detach", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const directionValue = this.direction();
			if (directionValue !== void 0) this._elementRef.nativeElement.direction = directionValue;
			const allowedDirectionsValue = this.allowedDirections();
			if (allowedDirectionsValue !== void 0) this._elementRef.nativeElement.allowedDirections = allowedDirectionsValue;
			const minWidthValue = this.minWidth();
			if (minWidthValue !== void 0) this._elementRef.nativeElement.minWidth = minWidthValue;
			const minHeightValue = this.minHeight();
			if (minHeightValue !== void 0) this._elementRef.nativeElement.minHeight = minHeightValue;
			const maxWidthValue = this.maxWidth();
			if (maxWidthValue !== void 0) this._elementRef.nativeElement.maxWidth = maxWidthValue;
			const maxHeightValue = this.maxHeight();
			if (maxHeightValue !== void 0) this._elementRef.nativeElement.maxHeight = maxHeightValue;
			const autoApplyValue = this.autoApply();
			if (autoApplyValue !== void 0) this._elementRef.nativeElement.autoApply = autoApplyValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const forValue = this.for();
			if (forValue !== void 0) this._elementRef.nativeElement.for = forValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ResizeThumbComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: ResizeThumbComponent,
		isStandalone: true,
		selector: "mosaik-resize-thumb",
		inputs: {
			direction: {
				classPropertyName: "direction",
				publicName: "direction",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			allowedDirections: {
				classPropertyName: "allowedDirections",
				publicName: "allowedDirections",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			minWidth: {
				classPropertyName: "minWidth",
				publicName: "minWidth",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			minHeight: {
				classPropertyName: "minHeight",
				publicName: "minHeight",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			maxWidth: {
				classPropertyName: "maxWidth",
				publicName: "maxWidth",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			maxHeight: {
				classPropertyName: "maxHeight",
				publicName: "maxHeight",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			autoApply: {
				classPropertyName: "autoApply",
				publicName: "autoApply",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			for: {
				classPropertyName: "for",
				publicName: "for",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			resizeStart: "resizeStart",
			resizing: "resizing",
			resizeEnd: "resizeEnd",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
ResizeThumbComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-resize-thumb", ResizeThumbElement),
	inputs: [
		"direction",
		"allowedDirections",
		"minWidth",
		"minHeight",
		"maxWidth",
		"maxHeight",
		"autoApply",
		"themeName",
		"disabled",
		"for",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], ResizeThumbComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ResizeThumbComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-resize-thumb",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		direction: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "direction",
				required: false
			}]
		}],
		allowedDirections: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "allowedDirections",
				required: false
			}]
		}],
		minWidth: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "minWidth",
				required: false
			}]
		}],
		minHeight: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "minHeight",
				required: false
			}]
		}],
		maxWidth: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maxWidth",
				required: false
			}]
		}],
		maxHeight: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maxHeight",
				required: false
			}]
		}],
		autoApply: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "autoApply",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		for: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "for",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		resizeStart: [{
			type: i0.Output,
			args: ["resizeStart"]
		}],
		resizing: [{
			type: i0.Output,
			args: ["resizing"]
		}],
		resizeEnd: [{
			type: i0.Output,
			args: ["resizeEnd"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideResizeThumbComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: RESIZE_THUMB_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { RESIZE_THUMB_DEFAULT_PROPS, ResizeThumbComponent, provideResizeThumbComponent };

//# sourceMappingURL=mosaik-elements-angular-components-resize-thumb.mjs.map