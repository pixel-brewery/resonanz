import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { ErrorStateElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/states/error/ErrorStateElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const ERROR_STATE_DEFAULT_PROPS = new InjectionToken("MOSAIK_ERROR_STATE_DEFAULT_PROPS");
let ErrorStateComponent = class ErrorStateComponent {
	icon = input(...ngDevMode ? [void 0, { debugName: "icon" }] : /* istanbul ignore next */ []);
	iconSize = input(...ngDevMode ? [void 0, { debugName: "iconSize" }] : /* istanbul ignore next */ []);
	header = input(...ngDevMode ? [void 0, { debugName: "header" }] : /* istanbul ignore next */ []);
	code = input(...ngDevMode ? [void 0, { debugName: "code" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	content = input(...ngDevMode ? [void 0, { debugName: "content" }] : /* istanbul ignore next */ []);
	formatter = input(...ngDevMode ? [void 0, { debugName: "formatter" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(ERROR_STATE_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	assignToSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "assignToSlot", args);
	}
	getSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getSlotContent", args);
	}
	hasSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlotContent", args);
	}
	hasSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlot", args);
	}
	onSlotChanges(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onSlotChanges", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const iconValue = this.icon();
			if (iconValue !== void 0) this._elementRef.nativeElement.icon = iconValue;
			const iconSizeValue = this.iconSize();
			if (iconSizeValue !== void 0) this._elementRef.nativeElement.iconSize = iconSizeValue;
			const headerValue = this.header();
			if (headerValue !== void 0) this._elementRef.nativeElement.header = headerValue;
			const codeValue = this.code();
			if (codeValue !== void 0) this._elementRef.nativeElement.code = codeValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const contentValue = this.content();
			if (contentValue !== void 0) this._elementRef.nativeElement.content = contentValue;
			const formatterValue = this.formatter();
			if (formatterValue !== void 0) this._elementRef.nativeElement.formatter = formatterValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ErrorStateComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: ErrorStateComponent,
		isStandalone: true,
		selector: "mosaik-error-state",
		inputs: {
			icon: {
				classPropertyName: "icon",
				publicName: "icon",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			iconSize: {
				classPropertyName: "iconSize",
				publicName: "iconSize",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			header: {
				classPropertyName: "header",
				publicName: "header",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			code: {
				classPropertyName: "code",
				publicName: "code",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			content: {
				classPropertyName: "content",
				publicName: "content",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			formatter: {
				classPropertyName: "formatter",
				publicName: "formatter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
ErrorStateComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-error-state", ErrorStateElement),
	inputs: [
		"icon",
		"iconSize",
		"header",
		"code",
		"themeName",
		"content",
		"formatter",
		"dir",
		"lang"
	],
	methods: ["getSlotAssignments", "getSlotAssignmentsOf"]
}), __metadata("design:paramtypes", [])], ErrorStateComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ErrorStateComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-error-state",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		icon: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "icon",
				required: false
			}]
		}],
		iconSize: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "iconSize",
				required: false
			}]
		}],
		header: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "header",
				required: false
			}]
		}],
		code: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "code",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		content: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "content",
				required: false
			}]
		}],
		formatter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "formatter",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideErrorStateComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: ERROR_STATE_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { ERROR_STATE_DEFAULT_PROPS, ErrorStateComponent, provideErrorStateComponent };

//# sourceMappingURL=mosaik-elements-angular-components-error-state.mjs.map