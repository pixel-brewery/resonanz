import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { PopupElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/popup/PopupElement";
import { PortalProjectionDirective, ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const POPUP_DEFAULT_PROPS = new InjectionToken("MOSAIK_POPUP_DEFAULT_PROPS");
let PopupComponent = class PopupComponent {
	placement = input(...ngDevMode ? [void 0, { debugName: "placement" }] : /* istanbul ignore next */ []);
	placements = input(...ngDevMode ? [void 0, { debugName: "placements" }] : /* istanbul ignore next */ []);
	distance = input(...ngDevMode ? [void 0, { debugName: "distance" }] : /* istanbul ignore next */ []);
	skidding = input(...ngDevMode ? [void 0, { debugName: "skidding" }] : /* istanbul ignore next */ []);
	trigger = input(...ngDevMode ? [void 0, { debugName: "trigger" }] : /* istanbul ignore next */ []);
	showDelay = input(...ngDevMode ? [void 0, { debugName: "showDelay" }] : /* istanbul ignore next */ []);
	hideDelay = input(...ngDevMode ? [void 0, { debugName: "hideDelay" }] : /* istanbul ignore next */ []);
	staysOpen = input(...ngDevMode ? [void 0, { debugName: "staysOpen" }] : /* istanbul ignore next */ []);
	closeOnScroll = input(...ngDevMode ? [void 0, { debugName: "closeOnScroll" }] : /* istanbul ignore next */ []);
	interactive = input(...ngDevMode ? [void 0, { debugName: "interactive" }] : /* istanbul ignore next */ []);
	flip = input(...ngDevMode ? [void 0, { debugName: "flip" }] : /* istanbul ignore next */ []);
	shift = input(...ngDevMode ? [void 0, { debugName: "shift" }] : /* istanbul ignore next */ []);
	boundary = input(...ngDevMode ? [void 0, { debugName: "boundary" }] : /* istanbul ignore next */ []);
	shiftBoundary = input(...ngDevMode ? [void 0, { debugName: "shiftBoundary" }] : /* istanbul ignore next */ []);
	shiftPadding = input(...ngDevMode ? [void 0, { debugName: "shiftPadding" }] : /* istanbul ignore next */ []);
	trapFocus = input(...ngDevMode ? [void 0, { debugName: "trapFocus" }] : /* istanbul ignore next */ []);
	restoreFocus = input(...ngDevMode ? [void 0, { debugName: "restoreFocus" }] : /* istanbul ignore next */ []);
	sync = input(...ngDevMode ? [void 0, { debugName: "sync" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	enter = input(...ngDevMode ? [void 0, { debugName: "enter" }] : /* istanbul ignore next */ []);
	exit = input(...ngDevMode ? [void 0, { debugName: "exit" }] : /* istanbul ignore next */ []);
	for = input(...ngDevMode ? [void 0, { debugName: "for" }] : /* istanbul ignore next */ []);
	elevation = input(...ngDevMode ? [void 0, { debugName: "elevation" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	appearance = input(...ngDevMode ? [void 0, { debugName: "appearance" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	isOpen = input(...ngDevMode ? [void 0, { debugName: "isOpen" }] : /* istanbul ignore next */ []);
	hasBackdrop = input(...ngDevMode ? [void 0, { debugName: "hasBackdrop" }] : /* istanbul ignore next */ []);
	pressEscapeToClose = input(...ngDevMode ? [void 0, { debugName: "pressEscapeToClose" }] : /* istanbul ignore next */ []);
	clickOutsideToClose = input(...ngDevMode ? [void 0, { debugName: "clickOutsideToClose" }] : /* istanbul ignore next */ []);
	attention = input(...ngDevMode ? [void 0, { debugName: "attention" }] : /* istanbul ignore next */ []);
	closeable = input(...ngDevMode ? [void 0, { debugName: "closeable" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	opened = output();
	closed = output();
	closeAttempted = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			opened: this.opened,
			closed: this.closed,
			closeAttempted: this.closeAttempted,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(POPUP_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	attach(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "attach", args);
	}
	detach(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "detach", args);
	}
	open(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "open", args);
	}
	close(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "close", args);
	}
	toggle(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "toggle", args);
	}
	requestAttention(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "requestAttention", args);
	}
	play(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "play", args);
	}
	onEnterAnimation(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onEnterAnimation", args);
	}
	onExitAnimation(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onExitAnimation", args);
	}
	assignToSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "assignToSlot", args);
	}
	getSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getSlotContent", args);
	}
	hasSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlotContent", args);
	}
	hasSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlot", args);
	}
	onSlotChanges(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onSlotChanges", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const placementValue = this.placement();
			if (placementValue !== void 0) this._elementRef.nativeElement.placement = placementValue;
			const placementsValue = this.placements();
			if (placementsValue !== void 0) this._elementRef.nativeElement.placements = placementsValue;
			const distanceValue = this.distance();
			if (distanceValue !== void 0) this._elementRef.nativeElement.distance = distanceValue;
			const skiddingValue = this.skidding();
			if (skiddingValue !== void 0) this._elementRef.nativeElement.skidding = skiddingValue;
			const triggerValue = this.trigger();
			if (triggerValue !== void 0) this._elementRef.nativeElement.trigger = triggerValue;
			const showDelayValue = this.showDelay();
			if (showDelayValue !== void 0) this._elementRef.nativeElement.showDelay = showDelayValue;
			const hideDelayValue = this.hideDelay();
			if (hideDelayValue !== void 0) this._elementRef.nativeElement.hideDelay = hideDelayValue;
			const staysOpenValue = this.staysOpen();
			if (staysOpenValue !== void 0) this._elementRef.nativeElement.staysOpen = staysOpenValue;
			const closeOnScrollValue = this.closeOnScroll();
			if (closeOnScrollValue !== void 0) this._elementRef.nativeElement.closeOnScroll = closeOnScrollValue;
			const interactiveValue = this.interactive();
			if (interactiveValue !== void 0) this._elementRef.nativeElement.interactive = interactiveValue;
			const flipValue = this.flip();
			if (flipValue !== void 0) this._elementRef.nativeElement.flip = flipValue;
			const shiftValue = this.shift();
			if (shiftValue !== void 0) this._elementRef.nativeElement.shift = shiftValue;
			const boundaryValue = this.boundary();
			if (boundaryValue !== void 0) this._elementRef.nativeElement.boundary = boundaryValue;
			const shiftBoundaryValue = this.shiftBoundary();
			if (shiftBoundaryValue !== void 0) this._elementRef.nativeElement.shiftBoundary = shiftBoundaryValue;
			const shiftPaddingValue = this.shiftPadding();
			if (shiftPaddingValue !== void 0) this._elementRef.nativeElement.shiftPadding = shiftPaddingValue;
			const trapFocusValue = this.trapFocus();
			if (trapFocusValue !== void 0) this._elementRef.nativeElement.trapFocus = trapFocusValue;
			const restoreFocusValue = this.restoreFocus();
			if (restoreFocusValue !== void 0) this._elementRef.nativeElement.restoreFocus = restoreFocusValue;
			const syncValue = this.sync();
			if (syncValue !== void 0) this._elementRef.nativeElement.sync = syncValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const enterValue = this.enter();
			if (enterValue !== void 0) this._elementRef.nativeElement.enter = enterValue;
			const exitValue = this.exit();
			if (exitValue !== void 0) this._elementRef.nativeElement.exit = exitValue;
			const forValue = this.for();
			if (forValue !== void 0) this._elementRef.nativeElement.for = forValue;
			const elevationValue = this.elevation();
			if (elevationValue !== void 0) this._elementRef.nativeElement.elevation = elevationValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const appearanceValue = this.appearance();
			if (appearanceValue !== void 0) this._elementRef.nativeElement.appearance = appearanceValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const isOpenValue = this.isOpen();
			if (isOpenValue !== void 0) this._elementRef.nativeElement.isOpen = isOpenValue;
			const hasBackdropValue = this.hasBackdrop();
			if (hasBackdropValue !== void 0) this._elementRef.nativeElement.hasBackdrop = hasBackdropValue;
			const pressEscapeToCloseValue = this.pressEscapeToClose();
			if (pressEscapeToCloseValue !== void 0) this._elementRef.nativeElement.pressEscapeToClose = pressEscapeToCloseValue;
			const clickOutsideToCloseValue = this.clickOutsideToClose();
			if (clickOutsideToCloseValue !== void 0) this._elementRef.nativeElement.clickOutsideToClose = clickOutsideToCloseValue;
			const attentionValue = this.attention();
			if (attentionValue !== void 0) this._elementRef.nativeElement.attention = attentionValue;
			const closeableValue = this.closeable();
			if (closeableValue !== void 0) this._elementRef.nativeElement.closeable = closeableValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: PopupComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: PopupComponent,
		isStandalone: true,
		selector: "mosaik-popup",
		inputs: {
			placement: {
				classPropertyName: "placement",
				publicName: "placement",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			placements: {
				classPropertyName: "placements",
				publicName: "placements",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			distance: {
				classPropertyName: "distance",
				publicName: "distance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			skidding: {
				classPropertyName: "skidding",
				publicName: "skidding",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			trigger: {
				classPropertyName: "trigger",
				publicName: "trigger",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showDelay: {
				classPropertyName: "showDelay",
				publicName: "showDelay",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			hideDelay: {
				classPropertyName: "hideDelay",
				publicName: "hideDelay",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			staysOpen: {
				classPropertyName: "staysOpen",
				publicName: "staysOpen",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			closeOnScroll: {
				classPropertyName: "closeOnScroll",
				publicName: "closeOnScroll",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			interactive: {
				classPropertyName: "interactive",
				publicName: "interactive",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			flip: {
				classPropertyName: "flip",
				publicName: "flip",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			shift: {
				classPropertyName: "shift",
				publicName: "shift",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			boundary: {
				classPropertyName: "boundary",
				publicName: "boundary",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			shiftBoundary: {
				classPropertyName: "shiftBoundary",
				publicName: "shiftBoundary",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			shiftPadding: {
				classPropertyName: "shiftPadding",
				publicName: "shiftPadding",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			trapFocus: {
				classPropertyName: "trapFocus",
				publicName: "trapFocus",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			restoreFocus: {
				classPropertyName: "restoreFocus",
				publicName: "restoreFocus",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			sync: {
				classPropertyName: "sync",
				publicName: "sync",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			enter: {
				classPropertyName: "enter",
				publicName: "enter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			exit: {
				classPropertyName: "exit",
				publicName: "exit",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			for: {
				classPropertyName: "for",
				publicName: "for",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			elevation: {
				classPropertyName: "elevation",
				publicName: "elevation",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isOpen: {
				classPropertyName: "isOpen",
				publicName: "isOpen",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			hasBackdrop: {
				classPropertyName: "hasBackdrop",
				publicName: "hasBackdrop",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			pressEscapeToClose: {
				classPropertyName: "pressEscapeToClose",
				publicName: "pressEscapeToClose",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			clickOutsideToClose: {
				classPropertyName: "clickOutsideToClose",
				publicName: "clickOutsideToClose",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			attention: {
				classPropertyName: "attention",
				publicName: "attention",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			closeable: {
				classPropertyName: "closeable",
				publicName: "closeable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			opened: "opened",
			closed: "closed",
			closeAttempted: "closeAttempted",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<span slot=\"content\" mosaikPortalProjection><ng-content select=\"[slot=content]\"></ng-content></span><ng-content select=\"[slot=footer]\"></ng-content><ng-content select=\"[slot=header]\"></ng-content><ng-content select=\"[slot=style]\"></ng-content><ng-content></ng-content>",
		isInline: true,
		dependencies: [{
			kind: "directive",
			type: PortalProjectionDirective,
			selector: "[mosaikPortalProjection]"
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
PopupComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-popup", PopupElement),
	inputs: [
		"placement",
		"placements",
		"distance",
		"skidding",
		"trigger",
		"showDelay",
		"hideDelay",
		"staysOpen",
		"closeOnScroll",
		"interactive",
		"flip",
		"shift",
		"boundary",
		"shiftBoundary",
		"shiftPadding",
		"trapFocus",
		"restoreFocus",
		"sync",
		"themeName",
		"enter",
		"exit",
		"for",
		"elevation",
		"variant",
		"appearance",
		"disabled",
		"isOpen",
		"hasBackdrop",
		"pressEscapeToClose",
		"clickOutsideToClose",
		"attention",
		"closeable",
		"dir",
		"lang"
	],
	methods: ["getSlotAssignments", "getSlotAssignmentsOf"]
}), __metadata("design:paramtypes", [])], PopupComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: PopupComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-popup",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<span slot=\"content\" mosaikPortalProjection><ng-content select=\"[slot=content]\"></ng-content></span><ng-content select=\"[slot=footer]\"></ng-content><ng-content select=\"[slot=header]\"></ng-content><ng-content select=\"[slot=style]\"></ng-content><ng-content></ng-content>",
			imports: [PortalProjectionDirective]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		placement: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "placement",
				required: false
			}]
		}],
		placements: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "placements",
				required: false
			}]
		}],
		distance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "distance",
				required: false
			}]
		}],
		skidding: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "skidding",
				required: false
			}]
		}],
		trigger: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "trigger",
				required: false
			}]
		}],
		showDelay: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showDelay",
				required: false
			}]
		}],
		hideDelay: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hideDelay",
				required: false
			}]
		}],
		staysOpen: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "staysOpen",
				required: false
			}]
		}],
		closeOnScroll: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "closeOnScroll",
				required: false
			}]
		}],
		interactive: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "interactive",
				required: false
			}]
		}],
		flip: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "flip",
				required: false
			}]
		}],
		shift: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "shift",
				required: false
			}]
		}],
		boundary: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "boundary",
				required: false
			}]
		}],
		shiftBoundary: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "shiftBoundary",
				required: false
			}]
		}],
		shiftPadding: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "shiftPadding",
				required: false
			}]
		}],
		trapFocus: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "trapFocus",
				required: false
			}]
		}],
		restoreFocus: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "restoreFocus",
				required: false
			}]
		}],
		sync: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "sync",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		enter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "enter",
				required: false
			}]
		}],
		exit: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "exit",
				required: false
			}]
		}],
		for: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "for",
				required: false
			}]
		}],
		elevation: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "elevation",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		isOpen: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isOpen",
				required: false
			}]
		}],
		hasBackdrop: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hasBackdrop",
				required: false
			}]
		}],
		pressEscapeToClose: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "pressEscapeToClose",
				required: false
			}]
		}],
		clickOutsideToClose: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "clickOutsideToClose",
				required: false
			}]
		}],
		attention: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "attention",
				required: false
			}]
		}],
		closeable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "closeable",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		opened: [{
			type: i0.Output,
			args: ["opened"]
		}],
		closed: [{
			type: i0.Output,
			args: ["closed"]
		}],
		closeAttempted: [{
			type: i0.Output,
			args: ["closeAttempted"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function providePopupComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: POPUP_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { POPUP_DEFAULT_PROPS, PopupComponent, providePopupComponent };

//# sourceMappingURL=mosaik-elements-angular-components-popup.mjs.map