import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { PerspectiveElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/effects/perspective/PerspectiveElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const PERSPECTIVE_DEFAULT_PROPS = new InjectionToken("MOSAIK_PERSPECTIVE_DEFAULT_PROPS");
let PerspectiveComponent = class PerspectiveComponent {
	duration = input(...ngDevMode ? [void 0, { debugName: "duration" }] : /* istanbul ignore next */ []);
	factor = input(...ngDevMode ? [void 0, { debugName: "factor" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	for = input(...ngDevMode ? [void 0, { debugName: "for" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(PERSPECTIVE_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	attach(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "attach", args);
	}
	detach(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "detach", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const durationValue = this.duration();
			if (durationValue !== void 0) this._elementRef.nativeElement.duration = durationValue;
			const factorValue = this.factor();
			if (factorValue !== void 0) this._elementRef.nativeElement.factor = factorValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const forValue = this.for();
			if (forValue !== void 0) this._elementRef.nativeElement.for = forValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: PerspectiveComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: PerspectiveComponent,
		isStandalone: true,
		selector: "mosaik-perspective",
		inputs: {
			duration: {
				classPropertyName: "duration",
				publicName: "duration",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			factor: {
				classPropertyName: "factor",
				publicName: "factor",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			for: {
				classPropertyName: "for",
				publicName: "for",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
PerspectiveComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-perspective", PerspectiveElement),
	inputs: [
		"duration",
		"factor",
		"themeName",
		"disabled",
		"for",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], PerspectiveComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: PerspectiveComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-perspective",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		duration: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "duration",
				required: false
			}]
		}],
		factor: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "factor",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		for: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "for",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function providePerspectiveComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: PERSPECTIVE_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { PERSPECTIVE_DEFAULT_PROPS, PerspectiveComponent, providePerspectiveComponent };

//# sourceMappingURL=mosaik-elements-angular-components-perspective.mjs.map