import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { BannerGroupElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/grouping/banner-group/BannerGroupElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const BANNER_GROUP_DEFAULT_PROPS = new InjectionToken("MOSAIK_BANNER_GROUP_DEFAULT_PROPS");
let BannerGroupComponent = class BannerGroupComponent {
	intl = input(...ngDevMode ? [void 0, { debugName: "intl" }] : /* istanbul ignore next */ []);
	index = input(...ngDevMode ? [void 0, { debugName: "index" }] : /* istanbul ignore next */ []);
	loop = input(...ngDevMode ? [void 0, { debugName: "loop" }] : /* istanbul ignore next */ []);
	pager = input(...ngDevMode ? [void 0, { debugName: "pager" }] : /* istanbul ignore next */ []);
	maxLength = input(...ngDevMode ? [void 0, { debugName: "maxLength" }] : /* istanbul ignore next */ []);
	dismissBehavior = input(...ngDevMode ? [void 0, { debugName: "dismissBehavior" }] : /* istanbul ignore next */ []);
	stacking = input(...ngDevMode ? [void 0, { debugName: "stacking" }] : /* istanbul ignore next */ []);
	reverse = input(...ngDevMode ? [void 0, { debugName: "reverse" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	orientation = input(...ngDevMode ? [void 0, { debugName: "orientation" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	appearance = input(...ngDevMode ? [void 0, { debugName: "appearance" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	change = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			change: this.change,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(BANNER_GROUP_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	previous(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "previous", args);
	}
	next(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "next", args);
	}
	first(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "first", args);
	}
	last(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "last", args);
	}
	goTo(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "goTo", args);
	}
	assignToSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "assignToSlot", args);
	}
	getSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getSlotContent", args);
	}
	hasSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlotContent", args);
	}
	hasSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlot", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const loopValue = this.loop();
			if (loopValue !== void 0) this._elementRef.nativeElement.loop = loopValue;
			const pagerValue = this.pager();
			if (pagerValue !== void 0) this._elementRef.nativeElement.pager = pagerValue;
			const maxLengthValue = this.maxLength();
			if (maxLengthValue !== void 0) this._elementRef.nativeElement.maxLength = maxLengthValue;
			const dismissBehaviorValue = this.dismissBehavior();
			if (dismissBehaviorValue !== void 0) this._elementRef.nativeElement.dismissBehavior = dismissBehaviorValue;
			const stackingValue = this.stacking();
			if (stackingValue !== void 0) this._elementRef.nativeElement.stacking = stackingValue;
			const reverseValue = this.reverse();
			if (reverseValue !== void 0) this._elementRef.nativeElement.reverse = reverseValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const orientationValue = this.orientation();
			if (orientationValue !== void 0) this._elementRef.nativeElement.orientation = orientationValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const appearanceValue = this.appearance();
			if (appearanceValue !== void 0) this._elementRef.nativeElement.appearance = appearanceValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: BannerGroupComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: BannerGroupComponent,
		isStandalone: true,
		selector: "mosaik-banner-group",
		inputs: {
			intl: {
				classPropertyName: "intl",
				publicName: "intl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			index: {
				classPropertyName: "index",
				publicName: "index",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			loop: {
				classPropertyName: "loop",
				publicName: "loop",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			pager: {
				classPropertyName: "pager",
				publicName: "pager",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			maxLength: {
				classPropertyName: "maxLength",
				publicName: "maxLength",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dismissBehavior: {
				classPropertyName: "dismissBehavior",
				publicName: "dismissBehavior",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			stacking: {
				classPropertyName: "stacking",
				publicName: "stacking",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			reverse: {
				classPropertyName: "reverse",
				publicName: "reverse",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			orientation: {
				classPropertyName: "orientation",
				publicName: "orientation",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			change: "change",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
BannerGroupComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-banner-group", BannerGroupElement),
	inputs: [
		"intl",
		"index",
		"loop",
		"pager",
		"maxLength",
		"dismissBehavior",
		"stacking",
		"reverse",
		"themeName",
		"orientation",
		"disabled",
		"appearance",
		"variant",
		"dir",
		"lang"
	],
	methods: ["getSlotAssignments", "getSlotAssignmentsOf"]
}), __metadata("design:paramtypes", [])], BannerGroupComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: BannerGroupComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-banner-group",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		intl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "intl",
				required: false
			}]
		}],
		index: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "index",
				required: false
			}]
		}],
		loop: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "loop",
				required: false
			}]
		}],
		pager: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "pager",
				required: false
			}]
		}],
		maxLength: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maxLength",
				required: false
			}]
		}],
		dismissBehavior: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dismissBehavior",
				required: false
			}]
		}],
		stacking: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "stacking",
				required: false
			}]
		}],
		reverse: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "reverse",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		orientation: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "orientation",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		change: [{
			type: i0.Output,
			args: ["change"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideBannerGroupComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: BANNER_GROUP_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { BANNER_GROUP_DEFAULT_PROPS, BannerGroupComponent, provideBannerGroupComponent };

//# sourceMappingURL=mosaik-elements-angular-components-banner-group.mjs.map