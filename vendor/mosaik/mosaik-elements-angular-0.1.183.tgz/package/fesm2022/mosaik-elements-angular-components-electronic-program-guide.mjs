import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { EpgChannelElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/electronic-program-guide/EpgChannelElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { EpgProgramElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/electronic-program-guide/EpgProgramElement";
import { EpgElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/electronic-program-guide/EpgElement";
var __decorate$2 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$2 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const EPG_CHANNEL_DEFAULT_PROPS = new InjectionToken("MOSAIK_EPG_CHANNEL_DEFAULT_PROPS");
let EpgChannelComponent = class EpgChannelComponent {
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	locale = input(...ngDevMode ? [void 0, { debugName: "locale" }] : /* istanbul ignore next */ []);
	value = input(...ngDevMode ? [void 0, { debugName: "value" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	appearance = input(...ngDevMode ? [void 0, { debugName: "appearance" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	label = input(...ngDevMode ? [void 0, { debugName: "label" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(EPG_CHANNEL_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const localeValue = this.locale();
			if (localeValue !== void 0) this._elementRef.nativeElement.locale = localeValue;
			const valueValue = this.value();
			if (valueValue !== void 0) this._elementRef.nativeElement.value = valueValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const appearanceValue = this.appearance();
			if (appearanceValue !== void 0) this._elementRef.nativeElement.appearance = appearanceValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const labelValue = this.label();
			if (labelValue !== void 0) this._elementRef.nativeElement.label = labelValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: EpgChannelComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: EpgChannelComponent,
		isStandalone: true,
		selector: "mosaik-epg-channel",
		inputs: {
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			locale: {
				classPropertyName: "locale",
				publicName: "locale",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
EpgChannelComponent = __decorate$2([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-epg-channel", EpgChannelElement),
	inputs: [
		"themeName",
		"locale",
		"value",
		"variant",
		"appearance",
		"disabled",
		"label",
		"dir",
		"lang"
	]
}), __metadata$2("design:paramtypes", [])], EpgChannelComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: EpgChannelComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-epg-channel",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		locale: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "locale",
				required: false
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideEpgChannelComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: EPG_CHANNEL_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$1 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$1 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const EPG_PROGRAM_DEFAULT_PROPS = new InjectionToken("MOSAIK_EPG_PROGRAM_DEFAULT_PROPS");
let EpgProgramComponent = class EpgProgramComponent {
	intl = input(...ngDevMode ? [void 0, { debugName: "intl" }] : /* istanbul ignore next */ []);
	header = input(...ngDevMode ? [void 0, { debugName: "header" }] : /* istanbul ignore next */ []);
	lane = input(...ngDevMode ? [void 0, { debugName: "lane" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	isFiltered = input(...ngDevMode ? [void 0, { debugName: "isFiltered" }] : /* istanbul ignore next */ []);
	locale = input(...ngDevMode ? [void 0, { debugName: "locale" }] : /* istanbul ignore next */ []);
	start = input(...ngDevMode ? [void 0, { debugName: "start" }] : /* istanbul ignore next */ []);
	end = input(...ngDevMode ? [void 0, { debugName: "end" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	appearance = input(...ngDevMode ? [void 0, { debugName: "appearance" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	isFocused = input(...ngDevMode ? [void 0, { debugName: "isFocused" }] : /* istanbul ignore next */ []);
	value = input(...ngDevMode ? [void 0, { debugName: "value" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	select = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			select: this.select,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(EPG_PROGRAM_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const headerValue = this.header();
			if (headerValue !== void 0) this._elementRef.nativeElement.header = headerValue;
			const laneValue = this.lane();
			if (laneValue !== void 0) this._elementRef.nativeElement.lane = laneValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const isFilteredValue = this.isFiltered();
			if (isFilteredValue !== void 0) this._elementRef.nativeElement.isFiltered = isFilteredValue;
			const localeValue = this.locale();
			if (localeValue !== void 0) this._elementRef.nativeElement.locale = localeValue;
			const startValue = this.start();
			if (startValue !== void 0) this._elementRef.nativeElement.start = startValue;
			const endValue = this.end();
			if (endValue !== void 0) this._elementRef.nativeElement.end = endValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const appearanceValue = this.appearance();
			if (appearanceValue !== void 0) this._elementRef.nativeElement.appearance = appearanceValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const isFocusedValue = this.isFocused();
			if (isFocusedValue !== void 0) this._elementRef.nativeElement.isFocused = isFocusedValue;
			const valueValue = this.value();
			if (valueValue !== void 0) this._elementRef.nativeElement.value = valueValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: EpgProgramComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: EpgProgramComponent,
		isStandalone: true,
		selector: "mosaik-epg-program",
		inputs: {
			intl: {
				classPropertyName: "intl",
				publicName: "intl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			header: {
				classPropertyName: "header",
				publicName: "header",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lane: {
				classPropertyName: "lane",
				publicName: "lane",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isFiltered: {
				classPropertyName: "isFiltered",
				publicName: "isFiltered",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			locale: {
				classPropertyName: "locale",
				publicName: "locale",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			start: {
				classPropertyName: "start",
				publicName: "start",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			end: {
				classPropertyName: "end",
				publicName: "end",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isFocused: {
				classPropertyName: "isFocused",
				publicName: "isFocused",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			select: "select",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
EpgProgramComponent = __decorate$1([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-epg-program", EpgProgramElement),
	inputs: [
		"intl",
		"header",
		"lane",
		"themeName",
		"isFiltered",
		"locale",
		"start",
		"end",
		"variant",
		"appearance",
		"disabled",
		"isFocused",
		"value",
		"dir",
		"lang"
	]
}), __metadata$1("design:paramtypes", [])], EpgProgramComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: EpgProgramComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-epg-program",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		intl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "intl",
				required: false
			}]
		}],
		header: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "header",
				required: false
			}]
		}],
		lane: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lane",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		isFiltered: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isFiltered",
				required: false
			}]
		}],
		locale: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "locale",
				required: false
			}]
		}],
		start: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "start",
				required: false
			}]
		}],
		end: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "end",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		isFocused: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isFocused",
				required: false
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		select: [{
			type: i0.Output,
			args: ["select"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideEpgProgramComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: EPG_PROGRAM_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const EPG_DEFAULT_PROPS = new InjectionToken("MOSAIK_EPG_DEFAULT_PROPS");
let EpgComponent = class EpgComponent {
	intl = input(...ngDevMode ? [void 0, { debugName: "intl" }] : /* istanbul ignore next */ []);
	zoom = input(...ngDevMode ? [void 0, { debugName: "zoom" }] : /* istanbul ignore next */ []);
	showNowLine = input(...ngDevMode ? [void 0, { debugName: "showNowLine" }] : /* istanbul ignore next */ []);
	showMinimap = input(...ngDevMode ? [void 0, { debugName: "showMinimap" }] : /* istanbul ignore next */ []);
	timelineFormat = input(...ngDevMode ? [void 0, { debugName: "timelineFormat" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	showFilter = input(...ngDevMode ? [void 0, { debugName: "showFilter" }] : /* istanbul ignore next */ []);
	filterMemberPath = input(...ngDevMode ? [void 0, { debugName: "filterMemberPath" }] : /* istanbul ignore next */ []);
	filter = input(...ngDevMode ? [void 0, { debugName: "filter" }] : /* istanbul ignore next */ []);
	filterPlaceholder = input(...ngDevMode ? [void 0, { debugName: "filterPlaceholder" }] : /* istanbul ignore next */ []);
	start = input(...ngDevMode ? [void 0, { debugName: "start" }] : /* istanbul ignore next */ []);
	end = input(...ngDevMode ? [void 0, { debugName: "end" }] : /* istanbul ignore next */ []);
	locale = input(...ngDevMode ? [void 0, { debugName: "locale" }] : /* istanbul ignore next */ []);
	appearance = input(...ngDevMode ? [void 0, { debugName: "appearance" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(EPG_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	zoomIn(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "zoomIn", args);
	}
	zoomOut(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "zoomOut", args);
	}
	nextDate(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "nextDate", args);
	}
	previousDate(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "previousDate", args);
	}
	scrollToNow(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "scrollToNow", args);
	}
	dragStart(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "dragStart", args);
	}
	touchStart(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "touchStart", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const zoomValue = this.zoom();
			if (zoomValue !== void 0) this._elementRef.nativeElement.zoom = zoomValue;
			const showNowLineValue = this.showNowLine();
			if (showNowLineValue !== void 0) this._elementRef.nativeElement.showNowLine = showNowLineValue;
			const showMinimapValue = this.showMinimap();
			if (showMinimapValue !== void 0) this._elementRef.nativeElement.showMinimap = showMinimapValue;
			const timelineFormatValue = this.timelineFormat();
			if (timelineFormatValue !== void 0) this._elementRef.nativeElement.timelineFormat = timelineFormatValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const showFilterValue = this.showFilter();
			if (showFilterValue !== void 0) this._elementRef.nativeElement.showFilter = showFilterValue;
			const filterMemberPathValue = this.filterMemberPath();
			if (filterMemberPathValue !== void 0) this._elementRef.nativeElement.filterMemberPath = filterMemberPathValue;
			const filterValue = this.filter();
			if (filterValue !== void 0) this._elementRef.nativeElement.filter = filterValue;
			const filterPlaceholderValue = this.filterPlaceholder();
			if (filterPlaceholderValue !== void 0) this._elementRef.nativeElement.filterPlaceholder = filterPlaceholderValue;
			const startValue = this.start();
			if (startValue !== void 0) this._elementRef.nativeElement.start = startValue;
			const endValue = this.end();
			if (endValue !== void 0) this._elementRef.nativeElement.end = endValue;
			const localeValue = this.locale();
			if (localeValue !== void 0) this._elementRef.nativeElement.locale = localeValue;
			const appearanceValue = this.appearance();
			if (appearanceValue !== void 0) this._elementRef.nativeElement.appearance = appearanceValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: EpgComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: EpgComponent,
		isStandalone: true,
		selector: "mosaik-epg",
		inputs: {
			intl: {
				classPropertyName: "intl",
				publicName: "intl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			zoom: {
				classPropertyName: "zoom",
				publicName: "zoom",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showNowLine: {
				classPropertyName: "showNowLine",
				publicName: "showNowLine",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showMinimap: {
				classPropertyName: "showMinimap",
				publicName: "showMinimap",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			timelineFormat: {
				classPropertyName: "timelineFormat",
				publicName: "timelineFormat",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showFilter: {
				classPropertyName: "showFilter",
				publicName: "showFilter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			filterMemberPath: {
				classPropertyName: "filterMemberPath",
				publicName: "filterMemberPath",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			filter: {
				classPropertyName: "filter",
				publicName: "filter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			filterPlaceholder: {
				classPropertyName: "filterPlaceholder",
				publicName: "filterPlaceholder",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			start: {
				classPropertyName: "start",
				publicName: "start",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			end: {
				classPropertyName: "end",
				publicName: "end",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			locale: {
				classPropertyName: "locale",
				publicName: "locale",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
EpgComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-epg", EpgElement),
	inputs: [
		"intl",
		"zoom",
		"showNowLine",
		"showMinimap",
		"timelineFormat",
		"themeName",
		"showFilter",
		"filterMemberPath",
		"filter",
		"filterPlaceholder",
		"start",
		"end",
		"locale",
		"appearance",
		"variant",
		"disabled",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], EpgComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: EpgComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-epg",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		intl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "intl",
				required: false
			}]
		}],
		zoom: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "zoom",
				required: false
			}]
		}],
		showNowLine: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showNowLine",
				required: false
			}]
		}],
		showMinimap: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showMinimap",
				required: false
			}]
		}],
		timelineFormat: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "timelineFormat",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		showFilter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showFilter",
				required: false
			}]
		}],
		filterMemberPath: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "filterMemberPath",
				required: false
			}]
		}],
		filter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "filter",
				required: false
			}]
		}],
		filterPlaceholder: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "filterPlaceholder",
				required: false
			}]
		}],
		start: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "start",
				required: false
			}]
		}],
		end: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "end",
				required: false
			}]
		}],
		locale: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "locale",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideEpgComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: EPG_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { EPG_CHANNEL_DEFAULT_PROPS, EPG_DEFAULT_PROPS, EPG_PROGRAM_DEFAULT_PROPS, EpgChannelComponent, EpgComponent, EpgProgramComponent, provideEpgChannelComponent, provideEpgComponent, provideEpgProgramComponent };

//# sourceMappingURL=mosaik-elements-angular-components-electronic-program-guide.mjs.map