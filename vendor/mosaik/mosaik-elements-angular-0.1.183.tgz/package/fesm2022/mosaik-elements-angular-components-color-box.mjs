import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, forwardRef, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { NG_VALUE_ACCESSOR } from "@angular/forms";
import { ColorBoxElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/color-box/ColorBoxElement";
import { colorBoxElementValueAccessor } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/color-box/accessors/ColorBoxElementValueAccessor";
import * as i1 from "@pixel-brewery/mosaik-elements-angular/runtime";
import { FORM_STATUS_HOST, FormFieldStatusHostDirective, FormStatusHostDirective, ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const COLOR_BOX_DEFAULT_PROPS = new InjectionToken("MOSAIK_COLOR_BOX_DEFAULT_PROPS");
const COLOR_BOX_INTL = new InjectionToken("MOSAIK_COLOR_BOX_INTL");
let ColorBoxComponent = class ColorBoxComponent {
	readonly = input(...ngDevMode ? [void 0, { debugName: "readonly" }] : /* istanbul ignore next */ []);
	required = input(...ngDevMode ? [void 0, { debugName: "required" }] : /* istanbul ignore next */ []);
	autofocus = input(...ngDevMode ? [void 0, { debugName: "autofocus" }] : /* istanbul ignore next */ []);
	name = input(...ngDevMode ? [void 0, { debugName: "name" }] : /* istanbul ignore next */ []);
	pattern = input(...ngDevMode ? [void 0, { debugName: "pattern" }] : /* istanbul ignore next */ []);
	placeholder = input(...ngDevMode ? [void 0, { debugName: "placeholder" }] : /* istanbul ignore next */ []);
	autocomplete = input(...ngDevMode ? [void 0, { debugName: "autocomplete" }] : /* istanbul ignore next */ []);
	format = input(...ngDevMode ? [void 0, { debugName: "format" }] : /* istanbul ignore next */ []);
	swatches = input(...ngDevMode ? [void 0, { debugName: "swatches" }] : /* istanbul ignore next */ []);
	textAlign = input(...ngDevMode ? [void 0, { debugName: "textAlign" }] : /* istanbul ignore next */ []);
	colorPosition = input(...ngDevMode ? [void 0, { debugName: "colorPosition" }] : /* istanbul ignore next */ []);
	editorFormat = input(...ngDevMode ? [void 0, { debugName: "editorFormat" }] : /* istanbul ignore next */ []);
	showAlpha = input(...ngDevMode ? [void 0, { debugName: "showAlpha" }] : /* istanbul ignore next */ []);
	showInputs = input(...ngDevMode ? [void 0, { debugName: "showInputs" }] : /* istanbul ignore next */ []);
	showPalette = input(...ngDevMode ? [void 0, { debugName: "showPalette" }] : /* istanbul ignore next */ []);
	showEyeDropper = input(...ngDevMode ? [void 0, { debugName: "showEyeDropper" }] : /* istanbul ignore next */ []);
	showSwatch = input(...ngDevMode ? [void 0, { debugName: "showSwatch" }] : /* istanbul ignore next */ []);
	palettes = input(...ngDevMode ? [void 0, { debugName: "palettes" }] : /* istanbul ignore next */ []);
	selectedPalette = input(...ngDevMode ? [void 0, { debugName: "selectedPalette" }] : /* istanbul ignore next */ []);
	intl = input(...ngDevMode ? [void 0, { debugName: "intl" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	size = input(...ngDevMode ? [void 0, { debugName: "size" }] : /* istanbul ignore next */ []);
	isClearable = input(...ngDevMode ? [void 0, { debugName: "isClearable" }] : /* istanbul ignore next */ []);
	invalid = input(...ngDevMode ? [void 0, { debugName: "invalid" }] : /* istanbul ignore next */ []);
	value = input(...ngDevMode ? [void 0, { debugName: "value" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	appearance = input(...ngDevMode ? [void 0, { debugName: "appearance" }] : /* istanbul ignore next */ []);
	dropDownPlacement = input(...ngDevMode ? [void 0, { debugName: "dropDownPlacement" }] : /* istanbul ignore next */ []);
	dropDownStrategy = input(...ngDevMode ? [void 0, { debugName: "dropDownStrategy" }] : /* istanbul ignore next */ []);
	dropDownDistance = input(...ngDevMode ? [void 0, { debugName: "dropDownDistance" }] : /* istanbul ignore next */ []);
	dropDownSkidding = input(...ngDevMode ? [void 0, { debugName: "dropDownSkidding" }] : /* istanbul ignore next */ []);
	dropDownStaysOpen = input(...ngDevMode ? [void 0, { debugName: "dropDownStaysOpen" }] : /* istanbul ignore next */ []);
	dropDownMaxHeight = input(...ngDevMode ? [void 0, { debugName: "dropDownMaxHeight" }] : /* istanbul ignore next */ []);
	dropDownHeight = input(...ngDevMode ? [void 0, { debugName: "dropDownHeight" }] : /* istanbul ignore next */ []);
	dropDownWidth = input(...ngDevMode ? [void 0, { debugName: "dropDownWidth" }] : /* istanbul ignore next */ []);
	dropDownMaxWidth = input(...ngDevMode ? [void 0, { debugName: "dropDownMaxWidth" }] : /* istanbul ignore next */ []);
	isDropDownOpen = input(...ngDevMode ? [void 0, { debugName: "isDropDownOpen" }] : /* istanbul ignore next */ []);
	label = input(...ngDevMode ? [void 0, { debugName: "label" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	formatter = input(...ngDevMode ? [void 0, { debugName: "formatter" }] : /* istanbul ignore next */ []);
	parser = input(...ngDevMode ? [void 0, { debugName: "parser" }] : /* istanbul ignore next */ []);
	isFocused = input(...ngDevMode ? [void 0, { debugName: "isFocused" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	cleared = output();
	change = output();
	input = output();
	focus = output();
	blur = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	_accessor;
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._accessor = colorBoxElementValueAccessor(this._elementRef.nativeElement);
		this._elementRef.nativeElement.addController(this._accessor);
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			cleared: this.cleared,
			change: this.change,
			input: this.input,
			focus: this.focus,
			blur: this.blur,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
			this._accessor.releaseCallbacks();
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(COLOR_BOX_DEFAULT_PROPS, { optional: true }) ?? {}, ["intl"]);
		const injectedIntl = inject(COLOR_BOX_INTL, { optional: true });
		if (injectedIntl) {
			Object.assign(this._elementRef.nativeElement.intl, injectedIntl);
			this._elementRef.nativeElement.intl.changes.emit();
		}
	}
	writeValue(obj) {
		this._accessor.writeValue(obj);
	}
	registerOnChange(fn) {
		this._accessor.registerOnChange(fn);
	}
	registerOnTouched(fn) {
		this._accessor.registerOnTouched(fn);
	}
	setDisabledState(isDisabled) {
		this._accessor.setDisabled?.(isDisabled);
	}
	clear(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "clear", args);
	}
	reset(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "reset", args);
	}
	checkValidity(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "checkValidity", args);
	}
	assignToSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "assignToSlot", args);
	}
	getSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getSlotContent", args);
	}
	hasSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlotContent", args);
	}
	hasSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlot", args);
	}
	onSlotChanges(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onSlotChanges", args);
	}
	open(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "open", args);
	}
	close(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "close", args);
	}
	toggle(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "toggle", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const readonlyValue = this.readonly();
			if (readonlyValue !== void 0) this._elementRef.nativeElement.readonly = readonlyValue;
			const requiredValue = this.required();
			if (requiredValue !== void 0) this._elementRef.nativeElement.required = requiredValue;
			const autofocusValue = this.autofocus();
			if (autofocusValue !== void 0) this._elementRef.nativeElement.autofocus = autofocusValue;
			const nameValue = this.name();
			if (nameValue !== void 0) this._elementRef.nativeElement.name = nameValue;
			const patternValue = this.pattern();
			if (patternValue !== void 0) this._elementRef.nativeElement.pattern = patternValue;
			const placeholderValue = this.placeholder();
			if (placeholderValue !== void 0) this._elementRef.nativeElement.placeholder = placeholderValue;
			const autocompleteValue = this.autocomplete();
			if (autocompleteValue !== void 0) this._elementRef.nativeElement.autocomplete = autocompleteValue;
			const formatValue = this.format();
			if (formatValue !== void 0) this._elementRef.nativeElement.format = formatValue;
			const swatchesValue = this.swatches();
			if (swatchesValue !== void 0) this._elementRef.nativeElement.swatches = swatchesValue;
			const textAlignValue = this.textAlign();
			if (textAlignValue !== void 0) this._elementRef.nativeElement.textAlign = textAlignValue;
			const colorPositionValue = this.colorPosition();
			if (colorPositionValue !== void 0) this._elementRef.nativeElement.colorPosition = colorPositionValue;
			const editorFormatValue = this.editorFormat();
			if (editorFormatValue !== void 0) this._elementRef.nativeElement.editorFormat = editorFormatValue;
			const showAlphaValue = this.showAlpha();
			if (showAlphaValue !== void 0) this._elementRef.nativeElement.showAlpha = showAlphaValue;
			const showInputsValue = this.showInputs();
			if (showInputsValue !== void 0) this._elementRef.nativeElement.showInputs = showInputsValue;
			const showPaletteValue = this.showPalette();
			if (showPaletteValue !== void 0) this._elementRef.nativeElement.showPalette = showPaletteValue;
			const showEyeDropperValue = this.showEyeDropper();
			if (showEyeDropperValue !== void 0) this._elementRef.nativeElement.showEyeDropper = showEyeDropperValue;
			const showSwatchValue = this.showSwatch();
			if (showSwatchValue !== void 0) this._elementRef.nativeElement.showSwatch = showSwatchValue;
			const palettesValue = this.palettes();
			if (palettesValue !== void 0) this._elementRef.nativeElement.palettes = palettesValue;
			const selectedPaletteValue = this.selectedPalette();
			if (selectedPaletteValue !== void 0) this._elementRef.nativeElement.selectedPalette = selectedPaletteValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const sizeValue = this.size();
			if (sizeValue !== void 0) this._elementRef.nativeElement.size = sizeValue;
			const isClearableValue = this.isClearable();
			if (isClearableValue !== void 0) this._elementRef.nativeElement.isClearable = isClearableValue;
			const invalidValue = this.invalid();
			if (invalidValue !== void 0) this._elementRef.nativeElement.invalid = invalidValue;
			const valueValue = this.value();
			if (valueValue !== void 0) this._elementRef.nativeElement.value = valueValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const appearanceValue = this.appearance();
			if (appearanceValue !== void 0) this._elementRef.nativeElement.appearance = appearanceValue;
			const dropDownPlacementValue = this.dropDownPlacement();
			if (dropDownPlacementValue !== void 0) this._elementRef.nativeElement.dropDownPlacement = dropDownPlacementValue;
			const dropDownStrategyValue = this.dropDownStrategy();
			if (dropDownStrategyValue !== void 0) this._elementRef.nativeElement.dropDownStrategy = dropDownStrategyValue;
			const dropDownDistanceValue = this.dropDownDistance();
			if (dropDownDistanceValue !== void 0) this._elementRef.nativeElement.dropDownDistance = dropDownDistanceValue;
			const dropDownSkiddingValue = this.dropDownSkidding();
			if (dropDownSkiddingValue !== void 0) this._elementRef.nativeElement.dropDownSkidding = dropDownSkiddingValue;
			const dropDownStaysOpenValue = this.dropDownStaysOpen();
			if (dropDownStaysOpenValue !== void 0) this._elementRef.nativeElement.dropDownStaysOpen = dropDownStaysOpenValue;
			const dropDownMaxHeightValue = this.dropDownMaxHeight();
			if (dropDownMaxHeightValue !== void 0) this._elementRef.nativeElement.dropDownMaxHeight = dropDownMaxHeightValue;
			const dropDownHeightValue = this.dropDownHeight();
			if (dropDownHeightValue !== void 0) this._elementRef.nativeElement.dropDownHeight = dropDownHeightValue;
			const dropDownWidthValue = this.dropDownWidth();
			if (dropDownWidthValue !== void 0) this._elementRef.nativeElement.dropDownWidth = dropDownWidthValue;
			const dropDownMaxWidthValue = this.dropDownMaxWidth();
			if (dropDownMaxWidthValue !== void 0) this._elementRef.nativeElement.dropDownMaxWidth = dropDownMaxWidthValue;
			const isDropDownOpenValue = this.isDropDownOpen();
			if (isDropDownOpenValue !== void 0) this._elementRef.nativeElement.isDropDownOpen = isDropDownOpenValue;
			const labelValue = this.label();
			if (labelValue !== void 0) this._elementRef.nativeElement.label = labelValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const formatterValue = this.formatter();
			if (formatterValue !== void 0) this._elementRef.nativeElement.formatter = formatterValue;
			const parserValue = this.parser();
			if (parserValue !== void 0) this._elementRef.nativeElement.parser = parserValue;
			const isFocusedValue = this.isFocused();
			if (isFocusedValue !== void 0) this._elementRef.nativeElement.isFocused = isFocusedValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
			const intlValue = this.intl();
			if (intlValue !== void 0) {
				Object.assign(this._elementRef.nativeElement.intl, intlValue);
				this._elementRef.nativeElement.intl.changes.emit();
			}
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ColorBoxComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: ColorBoxComponent,
		isStandalone: true,
		selector: "mosaik-colorbox",
		inputs: {
			readonly: {
				classPropertyName: "readonly",
				publicName: "readonly",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			required: {
				classPropertyName: "required",
				publicName: "required",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			autofocus: {
				classPropertyName: "autofocus",
				publicName: "autofocus",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			name: {
				classPropertyName: "name",
				publicName: "name",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			pattern: {
				classPropertyName: "pattern",
				publicName: "pattern",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			placeholder: {
				classPropertyName: "placeholder",
				publicName: "placeholder",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			autocomplete: {
				classPropertyName: "autocomplete",
				publicName: "autocomplete",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			format: {
				classPropertyName: "format",
				publicName: "format",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			swatches: {
				classPropertyName: "swatches",
				publicName: "swatches",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			textAlign: {
				classPropertyName: "textAlign",
				publicName: "textAlign",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			colorPosition: {
				classPropertyName: "colorPosition",
				publicName: "colorPosition",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			editorFormat: {
				classPropertyName: "editorFormat",
				publicName: "editorFormat",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showAlpha: {
				classPropertyName: "showAlpha",
				publicName: "showAlpha",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showInputs: {
				classPropertyName: "showInputs",
				publicName: "showInputs",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showPalette: {
				classPropertyName: "showPalette",
				publicName: "showPalette",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showEyeDropper: {
				classPropertyName: "showEyeDropper",
				publicName: "showEyeDropper",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showSwatch: {
				classPropertyName: "showSwatch",
				publicName: "showSwatch",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			palettes: {
				classPropertyName: "palettes",
				publicName: "palettes",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			selectedPalette: {
				classPropertyName: "selectedPalette",
				publicName: "selectedPalette",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			intl: {
				classPropertyName: "intl",
				publicName: "intl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isClearable: {
				classPropertyName: "isClearable",
				publicName: "isClearable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			invalid: {
				classPropertyName: "invalid",
				publicName: "invalid",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownPlacement: {
				classPropertyName: "dropDownPlacement",
				publicName: "dropDownPlacement",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownStrategy: {
				classPropertyName: "dropDownStrategy",
				publicName: "dropDownStrategy",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownDistance: {
				classPropertyName: "dropDownDistance",
				publicName: "dropDownDistance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownSkidding: {
				classPropertyName: "dropDownSkidding",
				publicName: "dropDownSkidding",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownStaysOpen: {
				classPropertyName: "dropDownStaysOpen",
				publicName: "dropDownStaysOpen",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownMaxHeight: {
				classPropertyName: "dropDownMaxHeight",
				publicName: "dropDownMaxHeight",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownHeight: {
				classPropertyName: "dropDownHeight",
				publicName: "dropDownHeight",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownWidth: {
				classPropertyName: "dropDownWidth",
				publicName: "dropDownWidth",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownMaxWidth: {
				classPropertyName: "dropDownMaxWidth",
				publicName: "dropDownMaxWidth",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isDropDownOpen: {
				classPropertyName: "isDropDownOpen",
				publicName: "isDropDownOpen",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			formatter: {
				classPropertyName: "formatter",
				publicName: "formatter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			parser: {
				classPropertyName: "parser",
				publicName: "parser",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isFocused: {
				classPropertyName: "isFocused",
				publicName: "isFocused",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			cleared: "cleared",
			change: "change",
			input: "input",
			focus: "focus",
			blur: "blur",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		providers: [{
			provide: NG_VALUE_ACCESSOR,
			useExisting: forwardRef(() => ColorBoxComponent),
			multi: true
		}, {
			provide: FORM_STATUS_HOST,
			useExisting: forwardRef(() => ColorBoxComponent)
		}],
		hostDirectives: [{ directive: i1.FormStatusHostDirective }, { directive: i1.FormFieldStatusHostDirective }],
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
ColorBoxComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-colorbox", ColorBoxElement),
	inputs: [
		"readonly",
		"required",
		"autofocus",
		"name",
		"pattern",
		"placeholder",
		"autocomplete",
		"format",
		"swatches",
		"textAlign",
		"colorPosition",
		"editorFormat",
		"showAlpha",
		"showInputs",
		"showPalette",
		"showEyeDropper",
		"showSwatch",
		"palettes",
		"selectedPalette",
		"intl",
		"themeName",
		"size",
		"isClearable",
		"invalid",
		"value",
		"variant",
		"appearance",
		"dropDownPlacement",
		"dropDownStrategy",
		"dropDownDistance",
		"dropDownSkidding",
		"dropDownStaysOpen",
		"dropDownMaxHeight",
		"dropDownHeight",
		"dropDownWidth",
		"dropDownMaxWidth",
		"isDropDownOpen",
		"label",
		"disabled",
		"formatter",
		"parser",
		"isFocused",
		"dir",
		"lang"
	],
	methods: ["getSlotAssignments", "getSlotAssignmentsOf"]
}), __metadata("design:paramtypes", [])], ColorBoxComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ColorBoxComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-colorbox",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>",
			hostDirectives: [FormStatusHostDirective, FormFieldStatusHostDirective],
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => ColorBoxComponent),
				multi: true
			}, {
				provide: FORM_STATUS_HOST,
				useExisting: forwardRef(() => ColorBoxComponent)
			}]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		readonly: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "readonly",
				required: false
			}]
		}],
		required: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "required",
				required: false
			}]
		}],
		autofocus: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "autofocus",
				required: false
			}]
		}],
		name: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "name",
				required: false
			}]
		}],
		pattern: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "pattern",
				required: false
			}]
		}],
		placeholder: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "placeholder",
				required: false
			}]
		}],
		autocomplete: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "autocomplete",
				required: false
			}]
		}],
		format: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "format",
				required: false
			}]
		}],
		swatches: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "swatches",
				required: false
			}]
		}],
		textAlign: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "textAlign",
				required: false
			}]
		}],
		colorPosition: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "colorPosition",
				required: false
			}]
		}],
		editorFormat: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "editorFormat",
				required: false
			}]
		}],
		showAlpha: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showAlpha",
				required: false
			}]
		}],
		showInputs: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showInputs",
				required: false
			}]
		}],
		showPalette: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showPalette",
				required: false
			}]
		}],
		showEyeDropper: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showEyeDropper",
				required: false
			}]
		}],
		showSwatch: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showSwatch",
				required: false
			}]
		}],
		palettes: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "palettes",
				required: false
			}]
		}],
		selectedPalette: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "selectedPalette",
				required: false
			}]
		}],
		intl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "intl",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		isClearable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isClearable",
				required: false
			}]
		}],
		invalid: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "invalid",
				required: false
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		dropDownPlacement: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownPlacement",
				required: false
			}]
		}],
		dropDownStrategy: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownStrategy",
				required: false
			}]
		}],
		dropDownDistance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownDistance",
				required: false
			}]
		}],
		dropDownSkidding: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownSkidding",
				required: false
			}]
		}],
		dropDownStaysOpen: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownStaysOpen",
				required: false
			}]
		}],
		dropDownMaxHeight: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownMaxHeight",
				required: false
			}]
		}],
		dropDownHeight: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownHeight",
				required: false
			}]
		}],
		dropDownWidth: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownWidth",
				required: false
			}]
		}],
		dropDownMaxWidth: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownMaxWidth",
				required: false
			}]
		}],
		isDropDownOpen: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isDropDownOpen",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		formatter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "formatter",
				required: false
			}]
		}],
		parser: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "parser",
				required: false
			}]
		}],
		isFocused: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isFocused",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		cleared: [{
			type: i0.Output,
			args: ["cleared"]
		}],
		change: [{
			type: i0.Output,
			args: ["change"]
		}],
		input: [{
			type: i0.Output,
			args: ["input"]
		}],
		focus: [{
			type: i0.Output,
			args: ["focus"]
		}],
		blur: [{
			type: i0.Output,
			args: ["blur"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideColorBoxComponent(config, intl) {
	const providers = [];
	if (config) providers.push({
		provide: COLOR_BOX_DEFAULT_PROPS,
		useValue: config
	});
	if (intl) {
		if (typeof intl === "function") providers.push({
			provide: COLOR_BOX_INTL,
			useClass: intl
		});
		else providers.push({
			provide: COLOR_BOX_INTL,
			useValue: intl
		});
	}
	return makeEnvironmentProviders(providers);
}
export { COLOR_BOX_DEFAULT_PROPS, COLOR_BOX_INTL, ColorBoxComponent, provideColorBoxComponent };

//# sourceMappingURL=mosaik-elements-angular-components-color-box.mjs.map