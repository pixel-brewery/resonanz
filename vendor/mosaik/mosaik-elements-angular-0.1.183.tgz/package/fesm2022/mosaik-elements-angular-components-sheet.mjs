import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { SheetContentElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/overlays/sheet/SheetContentElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { SheetFooterElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/overlays/sheet/SheetFooterElement";
import { SheetHeaderSubTextElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/overlays/sheet/SheetHeaderSubTextElement";
import { SheetHeaderTextElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/overlays/sheet/SheetHeaderTextElement";
import { SheetHeaderElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/overlays/sheet/SheetHeaderElement";
import { SheetElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/overlays/sheet/SheetElement";
var __decorate$5 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$5 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const SHEET_CONTENT_DEFAULT_PROPS = new InjectionToken("MOSAIK_SHEET_CONTENT_DEFAULT_PROPS");
let SheetContentComponent = class SheetContentComponent {
	text = input(...ngDevMode ? [void 0, { debugName: "text" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	formatter = input(...ngDevMode ? [void 0, { debugName: "formatter" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(SHEET_CONTENT_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	assignToSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "assignToSlot", args);
	}
	getSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getSlotContent", args);
	}
	hasSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlotContent", args);
	}
	hasSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlot", args);
	}
	onSlotChanges(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onSlotChanges", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const textValue = this.text();
			if (textValue !== void 0) this._elementRef.nativeElement.text = textValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const formatterValue = this.formatter();
			if (formatterValue !== void 0) this._elementRef.nativeElement.formatter = formatterValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: SheetContentComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: SheetContentComponent,
		isStandalone: true,
		selector: "mosaik-sheet-content",
		inputs: {
			text: {
				classPropertyName: "text",
				publicName: "text",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			formatter: {
				classPropertyName: "formatter",
				publicName: "formatter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
SheetContentComponent = __decorate$5([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-sheet-content", SheetContentElement),
	inputs: [
		"text",
		"themeName",
		"formatter",
		"dir",
		"lang"
	],
	methods: ["getSlotAssignments", "getSlotAssignmentsOf"]
}), __metadata$5("design:paramtypes", [])], SheetContentComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: SheetContentComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-sheet-content",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		text: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "text",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		formatter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "formatter",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideSheetContentComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: SHEET_CONTENT_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$4 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$4 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const SHEET_FOOTER_DEFAULT_PROPS = new InjectionToken("MOSAIK_SHEET_FOOTER_DEFAULT_PROPS");
let SheetFooterComponent = class SheetFooterComponent {
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(SHEET_FOOTER_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	assignToSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "assignToSlot", args);
	}
	getSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getSlotContent", args);
	}
	hasSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlotContent", args);
	}
	hasSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlot", args);
	}
	onSlotChanges(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onSlotChanges", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: SheetFooterComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: SheetFooterComponent,
		isStandalone: true,
		selector: "mosaik-sheet-footer",
		inputs: {
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
SheetFooterComponent = __decorate$4([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-sheet-footer", SheetFooterElement),
	inputs: [
		"themeName",
		"dir",
		"lang"
	],
	methods: ["getSlotAssignments", "getSlotAssignmentsOf"]
}), __metadata$4("design:paramtypes", [])], SheetFooterComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: SheetFooterComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-sheet-footer",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideSheetFooterComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: SHEET_FOOTER_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$3 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$3 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const SHEET_HEADER_SUB_TEXT_DEFAULT_PROPS = new InjectionToken("MOSAIK_SHEET_HEADER_SUB_TEXT_DEFAULT_PROPS");
let SheetHeaderSubTextComponent = class SheetHeaderSubTextComponent {
	text = input(...ngDevMode ? [void 0, { debugName: "text" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	formatter = input(...ngDevMode ? [void 0, { debugName: "formatter" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(SHEET_HEADER_SUB_TEXT_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const textValue = this.text();
			if (textValue !== void 0) this._elementRef.nativeElement.text = textValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const formatterValue = this.formatter();
			if (formatterValue !== void 0) this._elementRef.nativeElement.formatter = formatterValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: SheetHeaderSubTextComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: SheetHeaderSubTextComponent,
		isStandalone: true,
		selector: "mosaik-sheet-header-sub-text",
		inputs: {
			text: {
				classPropertyName: "text",
				publicName: "text",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			formatter: {
				classPropertyName: "formatter",
				publicName: "formatter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
SheetHeaderSubTextComponent = __decorate$3([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-sheet-header-sub-text", SheetHeaderSubTextElement),
	inputs: [
		"text",
		"themeName",
		"formatter",
		"dir",
		"lang"
	]
}), __metadata$3("design:paramtypes", [])], SheetHeaderSubTextComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: SheetHeaderSubTextComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-sheet-header-sub-text",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		text: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "text",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		formatter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "formatter",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideSheetHeaderSubTextComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: SHEET_HEADER_SUB_TEXT_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$2 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$2 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const SHEET_HEADER_TEXT_DEFAULT_PROPS = new InjectionToken("MOSAIK_SHEET_HEADER_TEXT_DEFAULT_PROPS");
let SheetHeaderTextComponent = class SheetHeaderTextComponent {
	text = input(...ngDevMode ? [void 0, { debugName: "text" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	formatter = input(...ngDevMode ? [void 0, { debugName: "formatter" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(SHEET_HEADER_TEXT_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const textValue = this.text();
			if (textValue !== void 0) this._elementRef.nativeElement.text = textValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const formatterValue = this.formatter();
			if (formatterValue !== void 0) this._elementRef.nativeElement.formatter = formatterValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: SheetHeaderTextComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: SheetHeaderTextComponent,
		isStandalone: true,
		selector: "mosaik-sheet-header-text",
		inputs: {
			text: {
				classPropertyName: "text",
				publicName: "text",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			formatter: {
				classPropertyName: "formatter",
				publicName: "formatter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
SheetHeaderTextComponent = __decorate$2([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-sheet-header-text", SheetHeaderTextElement),
	inputs: [
		"text",
		"themeName",
		"formatter",
		"dir",
		"lang"
	]
}), __metadata$2("design:paramtypes", [])], SheetHeaderTextComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: SheetHeaderTextComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-sheet-header-text",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		text: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "text",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		formatter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "formatter",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideSheetHeaderTextComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: SHEET_HEADER_TEXT_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$1 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$1 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const SHEET_HEADER_DEFAULT_PROPS = new InjectionToken("MOSAIK_SHEET_HEADER_DEFAULT_PROPS");
let SheetHeaderComponent = class SheetHeaderComponent {
	text = input(...ngDevMode ? [void 0, { debugName: "text" }] : /* istanbul ignore next */ []);
	subText = input(...ngDevMode ? [void 0, { debugName: "subText" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	formatter = input(...ngDevMode ? [void 0, { debugName: "formatter" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(SHEET_HEADER_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	onApplyTemplate(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onApplyTemplate", args);
	}
	assignToSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "assignToSlot", args);
	}
	getSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getSlotContent", args);
	}
	hasSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlotContent", args);
	}
	hasSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlot", args);
	}
	onSlotChanges(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onSlotChanges", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const textValue = this.text();
			if (textValue !== void 0) this._elementRef.nativeElement.text = textValue;
			const subTextValue = this.subText();
			if (subTextValue !== void 0) this._elementRef.nativeElement.subText = subTextValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const formatterValue = this.formatter();
			if (formatterValue !== void 0) this._elementRef.nativeElement.formatter = formatterValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: SheetHeaderComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: SheetHeaderComponent,
		isStandalone: true,
		selector: "mosaik-sheet-header",
		inputs: {
			text: {
				classPropertyName: "text",
				publicName: "text",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			subText: {
				classPropertyName: "subText",
				publicName: "subText",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			formatter: {
				classPropertyName: "formatter",
				publicName: "formatter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
SheetHeaderComponent = __decorate$1([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-sheet-header", SheetHeaderElement),
	inputs: [
		"text",
		"subText",
		"themeName",
		"formatter",
		"dir",
		"lang"
	],
	methods: ["getSlotAssignments", "getSlotAssignmentsOf"]
}), __metadata$1("design:paramtypes", [])], SheetHeaderComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: SheetHeaderComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-sheet-header",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		text: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "text",
				required: false
			}]
		}],
		subText: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "subText",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		formatter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "formatter",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideSheetHeaderComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: SHEET_HEADER_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const SHEET_DEFAULT_PROPS = new InjectionToken("MOSAIK_SHEET_DEFAULT_PROPS");
let SheetComponent = class SheetComponent {
	width = input(...ngDevMode ? [void 0, { debugName: "width" }] : /* istanbul ignore next */ []);
	height = input(...ngDevMode ? [void 0, { debugName: "height" }] : /* istanbul ignore next */ []);
	position = input(...ngDevMode ? [void 0, { debugName: "position" }] : /* istanbul ignore next */ []);
	snaps = input(...ngDevMode ? [void 0, { debugName: "snaps" }] : /* istanbul ignore next */ []);
	activeSnapIndex = input(...ngDevMode ? [void 0, { debugName: "activeSnapIndex" }] : /* istanbul ignore next */ []);
	closeThreshold = input(...ngDevMode ? [void 0, { debugName: "closeThreshold" }] : /* istanbul ignore next */ []);
	elastic = input(...ngDevMode ? [void 0, { debugName: "elastic" }] : /* istanbul ignore next */ []);
	inertia = input(...ngDevMode ? [void 0, { debugName: "inertia" }] : /* istanbul ignore next */ []);
	dragMode = input(...ngDevMode ? [void 0, { debugName: "dragMode" }] : /* istanbul ignore next */ []);
	hasHandle = input(...ngDevMode ? [void 0, { debugName: "hasHandle" }] : /* istanbul ignore next */ []);
	hasSnapIndicator = input(...ngDevMode ? [void 0, { debugName: "hasSnapIndicator" }] : /* istanbul ignore next */ []);
	isModal = input(...ngDevMode ? [void 0, { debugName: "isModal" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	isOpen = input(...ngDevMode ? [void 0, { debugName: "isOpen" }] : /* istanbul ignore next */ []);
	hasBackdrop = input(...ngDevMode ? [void 0, { debugName: "hasBackdrop" }] : /* istanbul ignore next */ []);
	pressEscapeToClose = input(...ngDevMode ? [void 0, { debugName: "pressEscapeToClose" }] : /* istanbul ignore next */ []);
	clickOutsideToClose = input(...ngDevMode ? [void 0, { debugName: "clickOutsideToClose" }] : /* istanbul ignore next */ []);
	attention = input(...ngDevMode ? [void 0, { debugName: "attention" }] : /* istanbul ignore next */ []);
	closeable = input(...ngDevMode ? [void 0, { debugName: "closeable" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	activeSnapChanged = output();
	dragStart = output();
	dragging = output();
	dragEnd = output();
	opened = output();
	closed = output();
	closeAttempted = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			activeSnapChanged: this.activeSnapChanged,
			dragStart: this.dragStart,
			dragging: this.dragging,
			dragEnd: this.dragEnd,
			opened: this.opened,
			closed: this.closed,
			closeAttempted: this.closeAttempted,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(SHEET_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	open(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "open", args);
	}
	close(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "close", args);
	}
	snapTo(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "snapTo", args);
	}
	assignToSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "assignToSlot", args);
	}
	getSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getSlotContent", args);
	}
	hasSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlotContent", args);
	}
	hasSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlot", args);
	}
	onSlotChanges(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onSlotChanges", args);
	}
	requestAttention(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "requestAttention", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const widthValue = this.width();
			if (widthValue !== void 0) this._elementRef.nativeElement.width = widthValue;
			const heightValue = this.height();
			if (heightValue !== void 0) this._elementRef.nativeElement.height = heightValue;
			const positionValue = this.position();
			if (positionValue !== void 0) this._elementRef.nativeElement.position = positionValue;
			const snapsValue = this.snaps();
			if (snapsValue !== void 0) this._elementRef.nativeElement.snaps = snapsValue;
			const activeSnapIndexValue = this.activeSnapIndex();
			if (activeSnapIndexValue !== void 0) this._elementRef.nativeElement.activeSnapIndex = activeSnapIndexValue;
			const closeThresholdValue = this.closeThreshold();
			if (closeThresholdValue !== void 0) this._elementRef.nativeElement.closeThreshold = closeThresholdValue;
			const elasticValue = this.elastic();
			if (elasticValue !== void 0) this._elementRef.nativeElement.elastic = elasticValue;
			const inertiaValue = this.inertia();
			if (inertiaValue !== void 0) this._elementRef.nativeElement.inertia = inertiaValue;
			const dragModeValue = this.dragMode();
			if (dragModeValue !== void 0) this._elementRef.nativeElement.dragMode = dragModeValue;
			const hasHandleValue = this.hasHandle();
			if (hasHandleValue !== void 0) this._elementRef.nativeElement.hasHandle = hasHandleValue;
			const hasSnapIndicatorValue = this.hasSnapIndicator();
			if (hasSnapIndicatorValue !== void 0) this._elementRef.nativeElement.hasSnapIndicator = hasSnapIndicatorValue;
			const isModalValue = this.isModal();
			if (isModalValue !== void 0) this._elementRef.nativeElement.isModal = isModalValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const isOpenValue = this.isOpen();
			if (isOpenValue !== void 0) this._elementRef.nativeElement.isOpen = isOpenValue;
			const hasBackdropValue = this.hasBackdrop();
			if (hasBackdropValue !== void 0) this._elementRef.nativeElement.hasBackdrop = hasBackdropValue;
			const pressEscapeToCloseValue = this.pressEscapeToClose();
			if (pressEscapeToCloseValue !== void 0) this._elementRef.nativeElement.pressEscapeToClose = pressEscapeToCloseValue;
			const clickOutsideToCloseValue = this.clickOutsideToClose();
			if (clickOutsideToCloseValue !== void 0) this._elementRef.nativeElement.clickOutsideToClose = clickOutsideToCloseValue;
			const attentionValue = this.attention();
			if (attentionValue !== void 0) this._elementRef.nativeElement.attention = attentionValue;
			const closeableValue = this.closeable();
			if (closeableValue !== void 0) this._elementRef.nativeElement.closeable = closeableValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: SheetComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: SheetComponent,
		isStandalone: true,
		selector: "mosaik-sheet",
		inputs: {
			width: {
				classPropertyName: "width",
				publicName: "width",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			height: {
				classPropertyName: "height",
				publicName: "height",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			position: {
				classPropertyName: "position",
				publicName: "position",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			snaps: {
				classPropertyName: "snaps",
				publicName: "snaps",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			activeSnapIndex: {
				classPropertyName: "activeSnapIndex",
				publicName: "activeSnapIndex",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			closeThreshold: {
				classPropertyName: "closeThreshold",
				publicName: "closeThreshold",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			elastic: {
				classPropertyName: "elastic",
				publicName: "elastic",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			inertia: {
				classPropertyName: "inertia",
				publicName: "inertia",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dragMode: {
				classPropertyName: "dragMode",
				publicName: "dragMode",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			hasHandle: {
				classPropertyName: "hasHandle",
				publicName: "hasHandle",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			hasSnapIndicator: {
				classPropertyName: "hasSnapIndicator",
				publicName: "hasSnapIndicator",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isModal: {
				classPropertyName: "isModal",
				publicName: "isModal",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isOpen: {
				classPropertyName: "isOpen",
				publicName: "isOpen",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			hasBackdrop: {
				classPropertyName: "hasBackdrop",
				publicName: "hasBackdrop",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			pressEscapeToClose: {
				classPropertyName: "pressEscapeToClose",
				publicName: "pressEscapeToClose",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			clickOutsideToClose: {
				classPropertyName: "clickOutsideToClose",
				publicName: "clickOutsideToClose",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			attention: {
				classPropertyName: "attention",
				publicName: "attention",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			closeable: {
				classPropertyName: "closeable",
				publicName: "closeable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			activeSnapChanged: "activeSnapChanged",
			dragStart: "dragStart",
			dragging: "dragging",
			dragEnd: "dragEnd",
			opened: "opened",
			closed: "closed",
			closeAttempted: "closeAttempted",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
SheetComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-sheet", SheetElement),
	inputs: [
		"width",
		"height",
		"position",
		"snaps",
		"activeSnapIndex",
		"closeThreshold",
		"elastic",
		"inertia",
		"dragMode",
		"hasHandle",
		"hasSnapIndicator",
		"isModal",
		"themeName",
		"isOpen",
		"hasBackdrop",
		"pressEscapeToClose",
		"clickOutsideToClose",
		"attention",
		"closeable",
		"dir",
		"lang"
	],
	methods: ["getSlotAssignments", "getSlotAssignmentsOf"]
}), __metadata("design:paramtypes", [])], SheetComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: SheetComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-sheet",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		width: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "width",
				required: false
			}]
		}],
		height: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "height",
				required: false
			}]
		}],
		position: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "position",
				required: false
			}]
		}],
		snaps: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "snaps",
				required: false
			}]
		}],
		activeSnapIndex: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "activeSnapIndex",
				required: false
			}]
		}],
		closeThreshold: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "closeThreshold",
				required: false
			}]
		}],
		elastic: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "elastic",
				required: false
			}]
		}],
		inertia: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "inertia",
				required: false
			}]
		}],
		dragMode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dragMode",
				required: false
			}]
		}],
		hasHandle: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hasHandle",
				required: false
			}]
		}],
		hasSnapIndicator: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hasSnapIndicator",
				required: false
			}]
		}],
		isModal: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isModal",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		isOpen: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isOpen",
				required: false
			}]
		}],
		hasBackdrop: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hasBackdrop",
				required: false
			}]
		}],
		pressEscapeToClose: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "pressEscapeToClose",
				required: false
			}]
		}],
		clickOutsideToClose: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "clickOutsideToClose",
				required: false
			}]
		}],
		attention: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "attention",
				required: false
			}]
		}],
		closeable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "closeable",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		activeSnapChanged: [{
			type: i0.Output,
			args: ["activeSnapChanged"]
		}],
		dragStart: [{
			type: i0.Output,
			args: ["dragStart"]
		}],
		dragging: [{
			type: i0.Output,
			args: ["dragging"]
		}],
		dragEnd: [{
			type: i0.Output,
			args: ["dragEnd"]
		}],
		opened: [{
			type: i0.Output,
			args: ["opened"]
		}],
		closed: [{
			type: i0.Output,
			args: ["closed"]
		}],
		closeAttempted: [{
			type: i0.Output,
			args: ["closeAttempted"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideSheetComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: SHEET_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { SHEET_CONTENT_DEFAULT_PROPS, SHEET_DEFAULT_PROPS, SHEET_FOOTER_DEFAULT_PROPS, SHEET_HEADER_DEFAULT_PROPS, SHEET_HEADER_SUB_TEXT_DEFAULT_PROPS, SHEET_HEADER_TEXT_DEFAULT_PROPS, SheetComponent, SheetContentComponent, SheetFooterComponent, SheetHeaderComponent, SheetHeaderSubTextComponent, SheetHeaderTextComponent, provideSheetComponent, provideSheetContentComponent, provideSheetFooterComponent, provideSheetHeaderComponent, provideSheetHeaderSubTextComponent, provideSheetHeaderTextComponent };

//# sourceMappingURL=mosaik-elements-angular-components-sheet.mjs.map