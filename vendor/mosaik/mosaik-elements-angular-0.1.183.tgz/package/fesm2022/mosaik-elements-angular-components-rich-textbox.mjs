import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, forwardRef, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { RichTextBoxElement, RichTextBoxToolboxElement, richTextBoxElementValueAccessor } from "@pixel-brewery/mosaik-elements-foundation/components/rich-textbox";
import * as i1 from "@pixel-brewery/mosaik-elements-angular/runtime";
import { FORM_STATUS_HOST, FormFieldStatusHostDirective, FormStatusHostDirective, ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { NG_VALUE_ACCESSOR } from "@angular/forms";
var __decorate$1 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$1 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const RICH_TEXT_BOX_TOOLBOX_DEFAULT_PROPS = new InjectionToken("MOSAIK_RICH_TEXT_BOX_TOOLBOX_DEFAULT_PROPS");
let RichTextBoxToolboxComponent = class RichTextBoxToolboxComponent {
	intl = input(...ngDevMode ? [void 0, { debugName: "intl" }] : /* istanbul ignore next */ []);
	editor = input(...ngDevMode ? [void 0, { debugName: "editor" }] : /* istanbul ignore next */ []);
	tools = input(...ngDevMode ? [void 0, { debugName: "tools" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(RICH_TEXT_BOX_TOOLBOX_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	execute(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "execute", args);
	}
	openLink(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "openLink", args);
	}
	removeLink(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "removeLink", args);
	}
	openImage(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "openImage", args);
	}
	cancelPopup(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "cancelPopup", args);
	}
	cancelLink(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "cancelLink", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const editorValue = this.editor();
			if (editorValue !== void 0) this._elementRef.nativeElement.editor = editorValue;
			const toolsValue = this.tools();
			if (toolsValue !== void 0) this._elementRef.nativeElement.tools = toolsValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: RichTextBoxToolboxComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: RichTextBoxToolboxComponent,
		isStandalone: true,
		selector: "mosaik-richtextbox-toolbox",
		inputs: {
			intl: {
				classPropertyName: "intl",
				publicName: "intl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			editor: {
				classPropertyName: "editor",
				publicName: "editor",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			tools: {
				classPropertyName: "tools",
				publicName: "tools",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
RichTextBoxToolboxComponent = __decorate$1([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-richtextbox-toolbox", RichTextBoxToolboxElement),
	inputs: [
		"intl",
		"editor",
		"tools",
		"themeName",
		"dir",
		"lang"
	]
}), __metadata$1("design:paramtypes", [])], RichTextBoxToolboxComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: RichTextBoxToolboxComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-richtextbox-toolbox",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		intl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "intl",
				required: false
			}]
		}],
		editor: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "editor",
				required: false
			}]
		}],
		tools: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tools",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideRichTextBoxToolboxComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: RICH_TEXT_BOX_TOOLBOX_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const RICH_TEXT_BOX_DEFAULT_PROPS = new InjectionToken("MOSAIK_RICH_TEXT_BOX_DEFAULT_PROPS");
const RICH_TEXT_BOX_INTL = new InjectionToken("MOSAIK_RICH_TEXT_BOX_INTL");
let RichTextBoxComponent = class RichTextBoxComponent {
	intl = input(...ngDevMode ? [void 0, { debugName: "intl" }] : /* istanbul ignore next */ []);
	readonly = input(...ngDevMode ? [void 0, { debugName: "readonly" }] : /* istanbul ignore next */ []);
	required = input(...ngDevMode ? [void 0, { debugName: "required" }] : /* istanbul ignore next */ []);
	autofocus = input(...ngDevMode ? [void 0, { debugName: "autofocus" }] : /* istanbul ignore next */ []);
	name = input(...ngDevMode ? [void 0, { debugName: "name" }] : /* istanbul ignore next */ []);
	pattern = input(...ngDevMode ? [void 0, { debugName: "pattern" }] : /* istanbul ignore next */ []);
	placeholder = input(...ngDevMode ? [void 0, { debugName: "placeholder" }] : /* istanbul ignore next */ []);
	autocomplete = input(...ngDevMode ? [void 0, { debugName: "autocomplete" }] : /* istanbul ignore next */ []);
	minlength = input(...ngDevMode ? [void 0, { debugName: "minlength" }] : /* istanbul ignore next */ []);
	maxlength = input(...ngDevMode ? [void 0, { debugName: "maxlength" }] : /* istanbul ignore next */ []);
	multilineRows = input(...ngDevMode ? [void 0, { debugName: "multilineRows" }] : /* istanbul ignore next */ []);
	resize = input(...ngDevMode ? [void 0, { debugName: "resize" }] : /* istanbul ignore next */ []);
	showToolbar = input(...ngDevMode ? [void 0, { debugName: "showToolbar" }] : /* istanbul ignore next */ []);
	showToolbox = input(...ngDevMode ? [void 0, { debugName: "showToolbox" }] : /* istanbul ignore next */ []);
	submitOnEnter = input(...ngDevMode ? [void 0, { debugName: "submitOnEnter" }] : /* istanbul ignore next */ []);
	plainTextPaste = input(...ngDevMode ? [void 0, { debugName: "plainTextPaste" }] : /* istanbul ignore next */ []);
	extensions = input(...ngDevMode ? [void 0, { debugName: "extensions" }] : /* istanbul ignore next */ []);
	suggestions = input(...ngDevMode ? [void 0, { debugName: "suggestions" }] : /* istanbul ignore next */ []);
	mentionDocument = input(...ngDevMode ? [void 0, { debugName: "mentionDocument" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	isClearable = input(...ngDevMode ? [void 0, { debugName: "isClearable" }] : /* istanbul ignore next */ []);
	appearance = input(...ngDevMode ? [void 0, { debugName: "appearance" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	invalid = input(...ngDevMode ? [void 0, { debugName: "invalid" }] : /* istanbul ignore next */ []);
	value = input(...ngDevMode ? [void 0, { debugName: "value" }] : /* istanbul ignore next */ []);
	label = input(...ngDevMode ? [void 0, { debugName: "label" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	formatter = input(...ngDevMode ? [void 0, { debugName: "formatter" }] : /* istanbul ignore next */ []);
	parser = input(...ngDevMode ? [void 0, { debugName: "parser" }] : /* istanbul ignore next */ []);
	isFocused = input(...ngDevMode ? [void 0, { debugName: "isFocused" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	editorStateChanged = output();
	documentChanged = output();
	suggestionSelected = output();
	submitRequested = output();
	linkRequested = output();
	cleared = output();
	input = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	_accessor;
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._accessor = richTextBoxElementValueAccessor(this._elementRef.nativeElement);
		this._elementRef.nativeElement.addController(this._accessor);
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			editorStateChanged: this.editorStateChanged,
			documentChanged: this.documentChanged,
			suggestionSelected: this.suggestionSelected,
			submitRequested: this.submitRequested,
			linkRequested: this.linkRequested,
			cleared: this.cleared,
			input: this.input,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
			this._accessor.releaseCallbacks();
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(RICH_TEXT_BOX_DEFAULT_PROPS, { optional: true }) ?? {}, ["intl"]);
		const injectedIntl = inject(RICH_TEXT_BOX_INTL, { optional: true });
		if (injectedIntl) {
			Object.assign(this._elementRef.nativeElement.intl, injectedIntl);
			this._elementRef.nativeElement.intl.changes.emit();
		}
	}
	writeValue(obj) {
		this._accessor.writeValue(obj);
	}
	registerOnChange(fn) {
		this._accessor.registerOnChange(fn);
	}
	registerOnTouched(fn) {
		this._accessor.registerOnTouched(fn);
	}
	setDisabledState(isDisabled) {
		this._accessor.setDisabled?.(isDisabled);
	}
	command(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "command", args);
	}
	canCommand(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "canCommand", args);
	}
	isCommandActive(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "isCommandActive", args);
	}
	select(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "select", args);
	}
	focus(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "focus", args);
	}
	blur(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "blur", args);
	}
	attachPromptBox(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "attachPromptBox", args);
	}
	reset(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "reset", args);
	}
	clear(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "clear", args);
	}
	checkValidity(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "checkValidity", args);
	}
	chooseSuggestion(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "chooseSuggestion", args);
	}
	dismissSuggestions(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "dismissSuggestions", args);
	}
	assignToSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "assignToSlot", args);
	}
	getSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getSlotContent", args);
	}
	hasSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlotContent", args);
	}
	hasSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlot", args);
	}
	onSlotChanges(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onSlotChanges", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const readonlyValue = this.readonly();
			if (readonlyValue !== void 0) this._elementRef.nativeElement.readonly = readonlyValue;
			const requiredValue = this.required();
			if (requiredValue !== void 0) this._elementRef.nativeElement.required = requiredValue;
			const autofocusValue = this.autofocus();
			if (autofocusValue !== void 0) this._elementRef.nativeElement.autofocus = autofocusValue;
			const nameValue = this.name();
			if (nameValue !== void 0) this._elementRef.nativeElement.name = nameValue;
			const patternValue = this.pattern();
			if (patternValue !== void 0) this._elementRef.nativeElement.pattern = patternValue;
			const placeholderValue = this.placeholder();
			if (placeholderValue !== void 0) this._elementRef.nativeElement.placeholder = placeholderValue;
			const autocompleteValue = this.autocomplete();
			if (autocompleteValue !== void 0) this._elementRef.nativeElement.autocomplete = autocompleteValue;
			const minlengthValue = this.minlength();
			if (minlengthValue !== void 0) this._elementRef.nativeElement.minlength = minlengthValue;
			const maxlengthValue = this.maxlength();
			if (maxlengthValue !== void 0) this._elementRef.nativeElement.maxlength = maxlengthValue;
			const multilineRowsValue = this.multilineRows();
			if (multilineRowsValue !== void 0) this._elementRef.nativeElement.multilineRows = multilineRowsValue;
			const resizeValue = this.resize();
			if (resizeValue !== void 0) this._elementRef.nativeElement.resize = resizeValue;
			const showToolbarValue = this.showToolbar();
			if (showToolbarValue !== void 0) this._elementRef.nativeElement.showToolbar = showToolbarValue;
			const showToolboxValue = this.showToolbox();
			if (showToolboxValue !== void 0) this._elementRef.nativeElement.showToolbox = showToolboxValue;
			const submitOnEnterValue = this.submitOnEnter();
			if (submitOnEnterValue !== void 0) this._elementRef.nativeElement.submitOnEnter = submitOnEnterValue;
			const plainTextPasteValue = this.plainTextPaste();
			if (plainTextPasteValue !== void 0) this._elementRef.nativeElement.plainTextPaste = plainTextPasteValue;
			const extensionsValue = this.extensions();
			if (extensionsValue !== void 0) this._elementRef.nativeElement.extensions = extensionsValue;
			const suggestionsValue = this.suggestions();
			if (suggestionsValue !== void 0) this._elementRef.nativeElement.suggestions = suggestionsValue;
			const mentionDocumentValue = this.mentionDocument();
			if (mentionDocumentValue !== void 0) this._elementRef.nativeElement.mentionDocument = mentionDocumentValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const isClearableValue = this.isClearable();
			if (isClearableValue !== void 0) this._elementRef.nativeElement.isClearable = isClearableValue;
			const appearanceValue = this.appearance();
			if (appearanceValue !== void 0) this._elementRef.nativeElement.appearance = appearanceValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const invalidValue = this.invalid();
			if (invalidValue !== void 0) this._elementRef.nativeElement.invalid = invalidValue;
			const valueValue = this.value();
			if (valueValue !== void 0) this._elementRef.nativeElement.value = valueValue;
			const labelValue = this.label();
			if (labelValue !== void 0) this._elementRef.nativeElement.label = labelValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const formatterValue = this.formatter();
			if (formatterValue !== void 0) this._elementRef.nativeElement.formatter = formatterValue;
			const parserValue = this.parser();
			if (parserValue !== void 0) this._elementRef.nativeElement.parser = parserValue;
			const isFocusedValue = this.isFocused();
			if (isFocusedValue !== void 0) this._elementRef.nativeElement.isFocused = isFocusedValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
			const intlValue = this.intl();
			if (intlValue !== void 0) {
				Object.assign(this._elementRef.nativeElement.intl, intlValue);
				this._elementRef.nativeElement.intl.changes.emit();
			}
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: RichTextBoxComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: RichTextBoxComponent,
		isStandalone: true,
		selector: "mosaik-richtextbox",
		inputs: {
			intl: {
				classPropertyName: "intl",
				publicName: "intl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			readonly: {
				classPropertyName: "readonly",
				publicName: "readonly",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			required: {
				classPropertyName: "required",
				publicName: "required",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			autofocus: {
				classPropertyName: "autofocus",
				publicName: "autofocus",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			name: {
				classPropertyName: "name",
				publicName: "name",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			pattern: {
				classPropertyName: "pattern",
				publicName: "pattern",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			placeholder: {
				classPropertyName: "placeholder",
				publicName: "placeholder",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			autocomplete: {
				classPropertyName: "autocomplete",
				publicName: "autocomplete",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			minlength: {
				classPropertyName: "minlength",
				publicName: "minlength",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			maxlength: {
				classPropertyName: "maxlength",
				publicName: "maxlength",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			multilineRows: {
				classPropertyName: "multilineRows",
				publicName: "multilineRows",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			resize: {
				classPropertyName: "resize",
				publicName: "resize",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showToolbar: {
				classPropertyName: "showToolbar",
				publicName: "showToolbar",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showToolbox: {
				classPropertyName: "showToolbox",
				publicName: "showToolbox",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			submitOnEnter: {
				classPropertyName: "submitOnEnter",
				publicName: "submitOnEnter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			plainTextPaste: {
				classPropertyName: "plainTextPaste",
				publicName: "plainTextPaste",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			extensions: {
				classPropertyName: "extensions",
				publicName: "extensions",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			suggestions: {
				classPropertyName: "suggestions",
				publicName: "suggestions",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			mentionDocument: {
				classPropertyName: "mentionDocument",
				publicName: "mentionDocument",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isClearable: {
				classPropertyName: "isClearable",
				publicName: "isClearable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			invalid: {
				classPropertyName: "invalid",
				publicName: "invalid",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			formatter: {
				classPropertyName: "formatter",
				publicName: "formatter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			parser: {
				classPropertyName: "parser",
				publicName: "parser",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isFocused: {
				classPropertyName: "isFocused",
				publicName: "isFocused",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			editorStateChanged: "editorStateChanged",
			documentChanged: "documentChanged",
			suggestionSelected: "suggestionSelected",
			submitRequested: "submitRequested",
			linkRequested: "linkRequested",
			cleared: "cleared",
			input: "input",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		providers: [{
			provide: NG_VALUE_ACCESSOR,
			useExisting: forwardRef(() => RichTextBoxComponent),
			multi: true
		}, {
			provide: FORM_STATUS_HOST,
			useExisting: forwardRef(() => RichTextBoxComponent)
		}],
		hostDirectives: [{ directive: i1.FormStatusHostDirective }, { directive: i1.FormFieldStatusHostDirective }],
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
RichTextBoxComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-richtextbox", RichTextBoxElement),
	inputs: [
		"intl",
		"readonly",
		"required",
		"autofocus",
		"name",
		"pattern",
		"placeholder",
		"autocomplete",
		"minlength",
		"maxlength",
		"multilineRows",
		"resize",
		"showToolbar",
		"showToolbox",
		"submitOnEnter",
		"plainTextPaste",
		"extensions",
		"suggestions",
		"mentionDocument",
		"themeName",
		"isClearable",
		"appearance",
		"variant",
		"invalid",
		"value",
		"label",
		"disabled",
		"formatter",
		"parser",
		"isFocused",
		"dir",
		"lang"
	],
	methods: ["getSlotAssignments", "getSlotAssignmentsOf"]
}), __metadata("design:paramtypes", [])], RichTextBoxComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: RichTextBoxComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-richtextbox",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>",
			hostDirectives: [FormStatusHostDirective, FormFieldStatusHostDirective],
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => RichTextBoxComponent),
				multi: true
			}, {
				provide: FORM_STATUS_HOST,
				useExisting: forwardRef(() => RichTextBoxComponent)
			}]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		intl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "intl",
				required: false
			}]
		}],
		readonly: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "readonly",
				required: false
			}]
		}],
		required: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "required",
				required: false
			}]
		}],
		autofocus: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "autofocus",
				required: false
			}]
		}],
		name: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "name",
				required: false
			}]
		}],
		pattern: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "pattern",
				required: false
			}]
		}],
		placeholder: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "placeholder",
				required: false
			}]
		}],
		autocomplete: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "autocomplete",
				required: false
			}]
		}],
		minlength: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "minlength",
				required: false
			}]
		}],
		maxlength: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maxlength",
				required: false
			}]
		}],
		multilineRows: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "multilineRows",
				required: false
			}]
		}],
		resize: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "resize",
				required: false
			}]
		}],
		showToolbar: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showToolbar",
				required: false
			}]
		}],
		showToolbox: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showToolbox",
				required: false
			}]
		}],
		submitOnEnter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "submitOnEnter",
				required: false
			}]
		}],
		plainTextPaste: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "plainTextPaste",
				required: false
			}]
		}],
		extensions: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "extensions",
				required: false
			}]
		}],
		suggestions: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "suggestions",
				required: false
			}]
		}],
		mentionDocument: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mentionDocument",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		isClearable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isClearable",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		invalid: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "invalid",
				required: false
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		formatter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "formatter",
				required: false
			}]
		}],
		parser: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "parser",
				required: false
			}]
		}],
		isFocused: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isFocused",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		editorStateChanged: [{
			type: i0.Output,
			args: ["editorStateChanged"]
		}],
		documentChanged: [{
			type: i0.Output,
			args: ["documentChanged"]
		}],
		suggestionSelected: [{
			type: i0.Output,
			args: ["suggestionSelected"]
		}],
		submitRequested: [{
			type: i0.Output,
			args: ["submitRequested"]
		}],
		linkRequested: [{
			type: i0.Output,
			args: ["linkRequested"]
		}],
		cleared: [{
			type: i0.Output,
			args: ["cleared"]
		}],
		input: [{
			type: i0.Output,
			args: ["input"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideRichTextBoxComponent(config, intl) {
	const providers = [];
	if (config) providers.push({
		provide: RICH_TEXT_BOX_DEFAULT_PROPS,
		useValue: config
	});
	if (intl) {
		if (typeof intl === "function") providers.push({
			provide: RICH_TEXT_BOX_INTL,
			useClass: intl
		});
		else providers.push({
			provide: RICH_TEXT_BOX_INTL,
			useValue: intl
		});
	}
	return makeEnvironmentProviders(providers);
}
export { RICH_TEXT_BOX_DEFAULT_PROPS, RICH_TEXT_BOX_INTL, RICH_TEXT_BOX_TOOLBOX_DEFAULT_PROPS, RichTextBoxComponent, RichTextBoxToolboxComponent, provideRichTextBoxComponent, provideRichTextBoxToolboxComponent };

//# sourceMappingURL=mosaik-elements-angular-components-rich-textbox.mjs.map