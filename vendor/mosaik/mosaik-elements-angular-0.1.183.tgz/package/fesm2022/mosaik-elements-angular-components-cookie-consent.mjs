import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { CookiesConsentElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/misc/cookie-consent/CookiesConsentElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const COOKIES_CONSENT_DEFAULT_PROPS = new InjectionToken("MOSAIK_COOKIES_CONSENT_DEFAULT_PROPS");
const COOKIES_CONSENT_INTL = new InjectionToken("MOSAIK_COOKIES_CONSENT_INTL");
let CookiesConsentComponent = class CookiesConsentComponent {
	intl = input(...ngDevMode ? [void 0, { debugName: "intl" }] : /* istanbul ignore next */ []);
	hasAcceptedCookies = input(...ngDevMode ? [void 0, { debugName: "hasAcceptedCookies" }] : /* istanbul ignore next */ []);
	acceptable = input(...ngDevMode ? [void 0, { debugName: "acceptable" }] : /* istanbul ignore next */ []);
	dismissable = input(...ngDevMode ? [void 0, { debugName: "dismissable" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	enter = input(...ngDevMode ? [void 0, { debugName: "enter" }] : /* istanbul ignore next */ []);
	exit = input(...ngDevMode ? [void 0, { debugName: "exit" }] : /* istanbul ignore next */ []);
	elevation = input(...ngDevMode ? [void 0, { debugName: "elevation" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	cookiesAccepted = output();
	cookiesDismissed = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			cookiesAccepted: this.cookiesAccepted,
			cookiesDismissed: this.cookiesDismissed,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(COOKIES_CONSENT_DEFAULT_PROPS, { optional: true }) ?? {}, ["intl"]);
		const injectedIntl = inject(COOKIES_CONSENT_INTL, { optional: true });
		if (injectedIntl) {
			Object.assign(this._elementRef.nativeElement.intl, injectedIntl);
			this._elementRef.nativeElement.intl.changes.emit();
		}
	}
	onEnterAnimation(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onEnterAnimation", args);
	}
	onExitAnimation(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onExitAnimation", args);
	}
	play(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "play", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const hasAcceptedCookiesValue = this.hasAcceptedCookies();
			if (hasAcceptedCookiesValue !== void 0) this._elementRef.nativeElement.hasAcceptedCookies = hasAcceptedCookiesValue;
			const acceptableValue = this.acceptable();
			if (acceptableValue !== void 0) this._elementRef.nativeElement.acceptable = acceptableValue;
			const dismissableValue = this.dismissable();
			if (dismissableValue !== void 0) this._elementRef.nativeElement.dismissable = dismissableValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const enterValue = this.enter();
			if (enterValue !== void 0) this._elementRef.nativeElement.enter = enterValue;
			const exitValue = this.exit();
			if (exitValue !== void 0) this._elementRef.nativeElement.exit = exitValue;
			const elevationValue = this.elevation();
			if (elevationValue !== void 0) this._elementRef.nativeElement.elevation = elevationValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
			const intlValue = this.intl();
			if (intlValue !== void 0) {
				Object.assign(this._elementRef.nativeElement.intl, intlValue);
				this._elementRef.nativeElement.intl.changes.emit();
			}
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: CookiesConsentComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: CookiesConsentComponent,
		isStandalone: true,
		selector: "mosaik-cookies-consent",
		inputs: {
			intl: {
				classPropertyName: "intl",
				publicName: "intl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			hasAcceptedCookies: {
				classPropertyName: "hasAcceptedCookies",
				publicName: "hasAcceptedCookies",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			acceptable: {
				classPropertyName: "acceptable",
				publicName: "acceptable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dismissable: {
				classPropertyName: "dismissable",
				publicName: "dismissable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			enter: {
				classPropertyName: "enter",
				publicName: "enter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			exit: {
				classPropertyName: "exit",
				publicName: "exit",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			elevation: {
				classPropertyName: "elevation",
				publicName: "elevation",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			cookiesAccepted: "cookiesAccepted",
			cookiesDismissed: "cookiesDismissed",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
CookiesConsentComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-cookies-consent", CookiesConsentElement),
	inputs: [
		"intl",
		"hasAcceptedCookies",
		"acceptable",
		"dismissable",
		"themeName",
		"enter",
		"exit",
		"elevation",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], CookiesConsentComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: CookiesConsentComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-cookies-consent",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		intl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "intl",
				required: false
			}]
		}],
		hasAcceptedCookies: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hasAcceptedCookies",
				required: false
			}]
		}],
		acceptable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "acceptable",
				required: false
			}]
		}],
		dismissable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dismissable",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		enter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "enter",
				required: false
			}]
		}],
		exit: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "exit",
				required: false
			}]
		}],
		elevation: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "elevation",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		cookiesAccepted: [{
			type: i0.Output,
			args: ["cookiesAccepted"]
		}],
		cookiesDismissed: [{
			type: i0.Output,
			args: ["cookiesDismissed"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideCookiesConsentComponent(config, intl) {
	const providers = [];
	if (config) providers.push({
		provide: COOKIES_CONSENT_DEFAULT_PROPS,
		useValue: config
	});
	if (intl) {
		if (typeof intl === "function") providers.push({
			provide: COOKIES_CONSENT_INTL,
			useClass: intl
		});
		else providers.push({
			provide: COOKIES_CONSENT_INTL,
			useValue: intl
		});
	}
	return makeEnvironmentProviders(providers);
}
export { COOKIES_CONSENT_DEFAULT_PROPS, COOKIES_CONSENT_INTL, CookiesConsentComponent, provideCookiesConsentComponent };

//# sourceMappingURL=mosaik-elements-angular-components-cookie-consent.mjs.map