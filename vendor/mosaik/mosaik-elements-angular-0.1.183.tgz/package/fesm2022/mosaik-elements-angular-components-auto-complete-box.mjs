import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, forwardRef, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { NG_VALUE_ACCESSOR } from "@angular/forms";
import { AutoCompleteBoxElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/auto-complete-box/AutoCompleteBoxElement";
import { autoCompleteBoxElementValueAccessor } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/auto-complete-box/accessors/AutoCompleteBoxElementValueAccessor";
import * as i1 from "@pixel-brewery/mosaik-elements-angular/runtime";
import { FORM_STATUS_HOST, FormFieldStatusHostDirective, FormStatusHostDirective, ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const AUTO_COMPLETE_BOX_DEFAULT_PROPS = new InjectionToken("MOSAIK_AUTO_COMPLETE_BOX_DEFAULT_PROPS");
const AUTO_COMPLETE_BOX_INTL = new InjectionToken("MOSAIK_AUTO_COMPLETE_BOX_INTL");
let AutoCompleteBoxComponent = class AutoCompleteBoxComponent {
	text = input(...ngDevMode ? [void 0, { debugName: "text" }] : /* istanbul ignore next */ []);
	filterText = input(...ngDevMode ? [void 0, { debugName: "filterText" }] : /* istanbul ignore next */ []);
	intl = input(...ngDevMode ? [void 0, { debugName: "intl" }] : /* istanbul ignore next */ []);
	placeholder = input(...ngDevMode ? [void 0, { debugName: "placeholder" }] : /* istanbul ignore next */ []);
	filterPlaceholder = input(...ngDevMode ? [void 0, { debugName: "filterPlaceholder" }] : /* istanbul ignore next */ []);
	required = input(...ngDevMode ? [void 0, { debugName: "required" }] : /* istanbul ignore next */ []);
	readonly = input(...ngDevMode ? [void 0, { debugName: "readonly" }] : /* istanbul ignore next */ []);
	textAlign = input(...ngDevMode ? [void 0, { debugName: "textAlign" }] : /* istanbul ignore next */ []);
	renderItem = input(...ngDevMode ? [void 0, { debugName: "renderItem" }] : /* istanbul ignore next */ []);
	dropDownSync = input(...ngDevMode ? [void 0, { debugName: "dropDownSync" }] : /* istanbul ignore next */ []);
	dropDownPlacement = input(...ngDevMode ? [void 0, { debugName: "dropDownPlacement" }] : /* istanbul ignore next */ []);
	dropDownStrategy = input(...ngDevMode ? [void 0, { debugName: "dropDownStrategy" }] : /* istanbul ignore next */ []);
	dropDownDistance = input(...ngDevMode ? [void 0, { debugName: "dropDownDistance" }] : /* istanbul ignore next */ []);
	dropDownSkidding = input(...ngDevMode ? [void 0, { debugName: "dropDownSkidding" }] : /* istanbul ignore next */ []);
	dropDownStaysOpen = input(...ngDevMode ? [void 0, { debugName: "dropDownStaysOpen" }] : /* istanbul ignore next */ []);
	dropDownMaxHeight = input(...ngDevMode ? [void 0, { debugName: "dropDownMaxHeight" }] : /* istanbul ignore next */ []);
	dropDownHeight = input(...ngDevMode ? [void 0, { debugName: "dropDownHeight" }] : /* istanbul ignore next */ []);
	dropDownWidth = input(...ngDevMode ? [void 0, { debugName: "dropDownWidth" }] : /* istanbul ignore next */ []);
	dropDownMaxWidth = input(...ngDevMode ? [void 0, { debugName: "dropDownMaxWidth" }] : /* istanbul ignore next */ []);
	isDropDownOpen = input(...ngDevMode ? [void 0, { debugName: "isDropDownOpen" }] : /* istanbul ignore next */ []);
	appearance = input(...ngDevMode ? [void 0, { debugName: "appearance" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	size = input(...ngDevMode ? [void 0, { debugName: "size" }] : /* istanbul ignore next */ []);
	label = input(...ngDevMode ? [void 0, { debugName: "label" }] : /* istanbul ignore next */ []);
	isClearable = input(...ngDevMode ? [void 0, { debugName: "isClearable" }] : /* istanbul ignore next */ []);
	invalid = input(...ngDevMode ? [void 0, { debugName: "invalid" }] : /* istanbul ignore next */ []);
	value = input(...ngDevMode ? [void 0, { debugName: "value" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	minimumPrefixLength = input(...ngDevMode ? [void 0, { debugName: "minimumPrefixLength" }] : /* istanbul ignore next */ []);
	minimumPopulateDelay = input(...ngDevMode ? [void 0, { debugName: "minimumPopulateDelay" }] : /* istanbul ignore next */ []);
	isTextCompletionEnabled = input(...ngDevMode ? [void 0, { debugName: "isTextCompletionEnabled" }] : /* istanbul ignore next */ []);
	searchMode = input(...ngDevMode ? [void 0, { debugName: "searchMode" }] : /* istanbul ignore next */ []);
	displayMemberPath = input(...ngDevMode ? [void 0, { debugName: "displayMemberPath" }] : /* istanbul ignore next */ []);
	valueMemberPath = input(...ngDevMode ? [void 0, { debugName: "valueMemberPath" }] : /* istanbul ignore next */ []);
	items = input(...ngDevMode ? [void 0, { debugName: "items" }] : /* istanbul ignore next */ []);
	itemsProvider = input(...ngDevMode ? [void 0, { debugName: "itemsProvider" }] : /* istanbul ignore next */ []);
	populating = input(...ngDevMode ? [void 0, { debugName: "populating" }] : /* istanbul ignore next */ []);
	populated = input(...ngDevMode ? [void 0, { debugName: "populated" }] : /* istanbul ignore next */ []);
	itemSelected = input(...ngDevMode ? [void 0, { debugName: "itemSelected" }] : /* istanbul ignore next */ []);
	filteredItems = input(...ngDevMode ? [void 0, { debugName: "filteredItems" }] : /* istanbul ignore next */ []);
	isPopulating = input(...ngDevMode ? [void 0, { debugName: "isPopulating" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	formatter = input(...ngDevMode ? [void 0, { debugName: "formatter" }] : /* istanbul ignore next */ []);
	parser = input(...ngDevMode ? [void 0, { debugName: "parser" }] : /* istanbul ignore next */ []);
	isFocused = input(...ngDevMode ? [void 0, { debugName: "isFocused" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	cleared = output();
	autoCompletePopulating = output();
	autoCompletePopulated = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	_accessor;
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._accessor = autoCompleteBoxElementValueAccessor(this._elementRef.nativeElement);
		this._elementRef.nativeElement.addController(this._accessor);
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			cleared: this.cleared,
			autoCompletePopulating: this.autoCompletePopulating,
			autoCompletePopulated: this.autoCompletePopulated,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
			this._accessor.releaseCallbacks();
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(AUTO_COMPLETE_BOX_DEFAULT_PROPS, { optional: true }) ?? {}, ["intl"]);
		const injectedIntl = inject(AUTO_COMPLETE_BOX_INTL, { optional: true });
		if (injectedIntl) {
			Object.assign(this._elementRef.nativeElement.intl, injectedIntl);
			this._elementRef.nativeElement.intl.changes.emit();
		}
	}
	writeValue(obj) {
		this._accessor.writeValue(obj);
	}
	registerOnChange(fn) {
		this._accessor.registerOnChange(fn);
	}
	registerOnTouched(fn) {
		this._accessor.registerOnTouched(fn);
	}
	setDisabledState(isDisabled) {
		this._accessor.setDisabled?.(isDisabled);
	}
	checkValidity(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "checkValidity", args);
	}
	clear(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "clear", args);
	}
	assignToSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "assignToSlot", args);
	}
	getSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getSlotContent", args);
	}
	hasSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlotContent", args);
	}
	hasSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlot", args);
	}
	onSlotChanges(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onSlotChanges", args);
	}
	open(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "open", args);
	}
	close(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "close", args);
	}
	toggle(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "toggle", args);
	}
	reset(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "reset", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const textValue = this.text();
			if (textValue !== void 0) this._elementRef.nativeElement.text = textValue;
			const filterTextValue = this.filterText();
			if (filterTextValue !== void 0) this._elementRef.nativeElement.filterText = filterTextValue;
			const placeholderValue = this.placeholder();
			if (placeholderValue !== void 0) this._elementRef.nativeElement.placeholder = placeholderValue;
			const filterPlaceholderValue = this.filterPlaceholder();
			if (filterPlaceholderValue !== void 0) this._elementRef.nativeElement.filterPlaceholder = filterPlaceholderValue;
			const requiredValue = this.required();
			if (requiredValue !== void 0) this._elementRef.nativeElement.required = requiredValue;
			const readonlyValue = this.readonly();
			if (readonlyValue !== void 0) this._elementRef.nativeElement.readonly = readonlyValue;
			const textAlignValue = this.textAlign();
			if (textAlignValue !== void 0) this._elementRef.nativeElement.textAlign = textAlignValue;
			const renderItemValue = this.renderItem();
			if (renderItemValue !== void 0) this._elementRef.nativeElement.renderItem = renderItemValue;
			const dropDownSyncValue = this.dropDownSync();
			if (dropDownSyncValue !== void 0) this._elementRef.nativeElement.dropDownSync = dropDownSyncValue;
			const dropDownPlacementValue = this.dropDownPlacement();
			if (dropDownPlacementValue !== void 0) this._elementRef.nativeElement.dropDownPlacement = dropDownPlacementValue;
			const dropDownStrategyValue = this.dropDownStrategy();
			if (dropDownStrategyValue !== void 0) this._elementRef.nativeElement.dropDownStrategy = dropDownStrategyValue;
			const dropDownDistanceValue = this.dropDownDistance();
			if (dropDownDistanceValue !== void 0) this._elementRef.nativeElement.dropDownDistance = dropDownDistanceValue;
			const dropDownSkiddingValue = this.dropDownSkidding();
			if (dropDownSkiddingValue !== void 0) this._elementRef.nativeElement.dropDownSkidding = dropDownSkiddingValue;
			const dropDownStaysOpenValue = this.dropDownStaysOpen();
			if (dropDownStaysOpenValue !== void 0) this._elementRef.nativeElement.dropDownStaysOpen = dropDownStaysOpenValue;
			const dropDownMaxHeightValue = this.dropDownMaxHeight();
			if (dropDownMaxHeightValue !== void 0) this._elementRef.nativeElement.dropDownMaxHeight = dropDownMaxHeightValue;
			const dropDownHeightValue = this.dropDownHeight();
			if (dropDownHeightValue !== void 0) this._elementRef.nativeElement.dropDownHeight = dropDownHeightValue;
			const dropDownWidthValue = this.dropDownWidth();
			if (dropDownWidthValue !== void 0) this._elementRef.nativeElement.dropDownWidth = dropDownWidthValue;
			const dropDownMaxWidthValue = this.dropDownMaxWidth();
			if (dropDownMaxWidthValue !== void 0) this._elementRef.nativeElement.dropDownMaxWidth = dropDownMaxWidthValue;
			const isDropDownOpenValue = this.isDropDownOpen();
			if (isDropDownOpenValue !== void 0) this._elementRef.nativeElement.isDropDownOpen = isDropDownOpenValue;
			const appearanceValue = this.appearance();
			if (appearanceValue !== void 0) this._elementRef.nativeElement.appearance = appearanceValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const sizeValue = this.size();
			if (sizeValue !== void 0) this._elementRef.nativeElement.size = sizeValue;
			const labelValue = this.label();
			if (labelValue !== void 0) this._elementRef.nativeElement.label = labelValue;
			const isClearableValue = this.isClearable();
			if (isClearableValue !== void 0) this._elementRef.nativeElement.isClearable = isClearableValue;
			const invalidValue = this.invalid();
			if (invalidValue !== void 0) this._elementRef.nativeElement.invalid = invalidValue;
			const valueValue = this.value();
			if (valueValue !== void 0) this._elementRef.nativeElement.value = valueValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const minimumPrefixLengthValue = this.minimumPrefixLength();
			if (minimumPrefixLengthValue !== void 0) this._elementRef.nativeElement.minimumPrefixLength = minimumPrefixLengthValue;
			const minimumPopulateDelayValue = this.minimumPopulateDelay();
			if (minimumPopulateDelayValue !== void 0) this._elementRef.nativeElement.minimumPopulateDelay = minimumPopulateDelayValue;
			const isTextCompletionEnabledValue = this.isTextCompletionEnabled();
			if (isTextCompletionEnabledValue !== void 0) this._elementRef.nativeElement.isTextCompletionEnabled = isTextCompletionEnabledValue;
			const searchModeValue = this.searchMode();
			if (searchModeValue !== void 0) this._elementRef.nativeElement.searchMode = searchModeValue;
			const displayMemberPathValue = this.displayMemberPath();
			if (displayMemberPathValue !== void 0) this._elementRef.nativeElement.displayMemberPath = displayMemberPathValue;
			const valueMemberPathValue = this.valueMemberPath();
			if (valueMemberPathValue !== void 0) this._elementRef.nativeElement.valueMemberPath = valueMemberPathValue;
			const itemsProviderValue = this.itemsProvider();
			if (itemsProviderValue !== void 0) this._elementRef.nativeElement.itemsProvider = itemsProviderValue;
			const populatingValue = this.populating();
			if (populatingValue !== void 0) this._elementRef.nativeElement.populating = populatingValue;
			const populatedValue = this.populated();
			if (populatedValue !== void 0) this._elementRef.nativeElement.populated = populatedValue;
			const itemSelectedValue = this.itemSelected();
			if (itemSelectedValue !== void 0) this._elementRef.nativeElement.itemSelected = itemSelectedValue;
			const filteredItemsValue = this.filteredItems();
			if (filteredItemsValue !== void 0) this._elementRef.nativeElement.filteredItems = filteredItemsValue;
			const isPopulatingValue = this.isPopulating();
			if (isPopulatingValue !== void 0) this._elementRef.nativeElement.isPopulating = isPopulatingValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const formatterValue = this.formatter();
			if (formatterValue !== void 0) this._elementRef.nativeElement.formatter = formatterValue;
			const parserValue = this.parser();
			if (parserValue !== void 0) this._elementRef.nativeElement.parser = parserValue;
			const isFocusedValue = this.isFocused();
			if (isFocusedValue !== void 0) this._elementRef.nativeElement.isFocused = isFocusedValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
			const intlValue = this.intl();
			if (intlValue !== void 0) {
				Object.assign(this._elementRef.nativeElement.intl, intlValue);
				this._elementRef.nativeElement.intl.changes.emit();
			}
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: AutoCompleteBoxComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: AutoCompleteBoxComponent,
		isStandalone: true,
		selector: "mosaik-autocompletebox",
		inputs: {
			text: {
				classPropertyName: "text",
				publicName: "text",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			filterText: {
				classPropertyName: "filterText",
				publicName: "filterText",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			intl: {
				classPropertyName: "intl",
				publicName: "intl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			placeholder: {
				classPropertyName: "placeholder",
				publicName: "placeholder",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			filterPlaceholder: {
				classPropertyName: "filterPlaceholder",
				publicName: "filterPlaceholder",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			required: {
				classPropertyName: "required",
				publicName: "required",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			readonly: {
				classPropertyName: "readonly",
				publicName: "readonly",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			textAlign: {
				classPropertyName: "textAlign",
				publicName: "textAlign",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			renderItem: {
				classPropertyName: "renderItem",
				publicName: "renderItem",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownSync: {
				classPropertyName: "dropDownSync",
				publicName: "dropDownSync",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownPlacement: {
				classPropertyName: "dropDownPlacement",
				publicName: "dropDownPlacement",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownStrategy: {
				classPropertyName: "dropDownStrategy",
				publicName: "dropDownStrategy",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownDistance: {
				classPropertyName: "dropDownDistance",
				publicName: "dropDownDistance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownSkidding: {
				classPropertyName: "dropDownSkidding",
				publicName: "dropDownSkidding",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownStaysOpen: {
				classPropertyName: "dropDownStaysOpen",
				publicName: "dropDownStaysOpen",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownMaxHeight: {
				classPropertyName: "dropDownMaxHeight",
				publicName: "dropDownMaxHeight",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownHeight: {
				classPropertyName: "dropDownHeight",
				publicName: "dropDownHeight",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownWidth: {
				classPropertyName: "dropDownWidth",
				publicName: "dropDownWidth",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownMaxWidth: {
				classPropertyName: "dropDownMaxWidth",
				publicName: "dropDownMaxWidth",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isDropDownOpen: {
				classPropertyName: "isDropDownOpen",
				publicName: "isDropDownOpen",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isClearable: {
				classPropertyName: "isClearable",
				publicName: "isClearable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			invalid: {
				classPropertyName: "invalid",
				publicName: "invalid",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			minimumPrefixLength: {
				classPropertyName: "minimumPrefixLength",
				publicName: "minimumPrefixLength",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			minimumPopulateDelay: {
				classPropertyName: "minimumPopulateDelay",
				publicName: "minimumPopulateDelay",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isTextCompletionEnabled: {
				classPropertyName: "isTextCompletionEnabled",
				publicName: "isTextCompletionEnabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			searchMode: {
				classPropertyName: "searchMode",
				publicName: "searchMode",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			displayMemberPath: {
				classPropertyName: "displayMemberPath",
				publicName: "displayMemberPath",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			valueMemberPath: {
				classPropertyName: "valueMemberPath",
				publicName: "valueMemberPath",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			items: {
				classPropertyName: "items",
				publicName: "items",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			itemsProvider: {
				classPropertyName: "itemsProvider",
				publicName: "itemsProvider",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			populating: {
				classPropertyName: "populating",
				publicName: "populating",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			populated: {
				classPropertyName: "populated",
				publicName: "populated",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			itemSelected: {
				classPropertyName: "itemSelected",
				publicName: "itemSelected",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			filteredItems: {
				classPropertyName: "filteredItems",
				publicName: "filteredItems",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isPopulating: {
				classPropertyName: "isPopulating",
				publicName: "isPopulating",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			formatter: {
				classPropertyName: "formatter",
				publicName: "formatter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			parser: {
				classPropertyName: "parser",
				publicName: "parser",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isFocused: {
				classPropertyName: "isFocused",
				publicName: "isFocused",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			cleared: "cleared",
			autoCompletePopulating: "autoCompletePopulating",
			autoCompletePopulated: "autoCompletePopulated",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		providers: [{
			provide: NG_VALUE_ACCESSOR,
			useExisting: forwardRef(() => AutoCompleteBoxComponent),
			multi: true
		}, {
			provide: FORM_STATUS_HOST,
			useExisting: forwardRef(() => AutoCompleteBoxComponent)
		}],
		hostDirectives: [{ directive: i1.FormStatusHostDirective }, { directive: i1.FormFieldStatusHostDirective }],
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
AutoCompleteBoxComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-autocompletebox", AutoCompleteBoxElement),
	inputs: [
		"text",
		"filterText",
		"intl",
		"placeholder",
		"filterPlaceholder",
		"required",
		"readonly",
		"textAlign",
		"renderItem",
		"dropDownSync",
		"dropDownPlacement",
		"dropDownStrategy",
		"dropDownDistance",
		"dropDownSkidding",
		"dropDownStaysOpen",
		"dropDownMaxHeight",
		"dropDownHeight",
		"dropDownWidth",
		"dropDownMaxWidth",
		"isDropDownOpen",
		"appearance",
		"variant",
		"size",
		"label",
		"isClearable",
		"invalid",
		"value",
		"themeName",
		"minimumPrefixLength",
		"minimumPopulateDelay",
		"isTextCompletionEnabled",
		"searchMode",
		"displayMemberPath",
		"valueMemberPath",
		"items",
		"itemsProvider",
		"populating",
		"populated",
		"itemSelected",
		"filteredItems",
		"isPopulating",
		"disabled",
		"formatter",
		"parser",
		"isFocused",
		"dir",
		"lang"
	],
	methods: ["getSlotAssignments", "getSlotAssignmentsOf"]
}), __metadata("design:paramtypes", [])], AutoCompleteBoxComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: AutoCompleteBoxComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-autocompletebox",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>",
			hostDirectives: [FormStatusHostDirective, FormFieldStatusHostDirective],
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => AutoCompleteBoxComponent),
				multi: true
			}, {
				provide: FORM_STATUS_HOST,
				useExisting: forwardRef(() => AutoCompleteBoxComponent)
			}]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		text: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "text",
				required: false
			}]
		}],
		filterText: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "filterText",
				required: false
			}]
		}],
		intl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "intl",
				required: false
			}]
		}],
		placeholder: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "placeholder",
				required: false
			}]
		}],
		filterPlaceholder: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "filterPlaceholder",
				required: false
			}]
		}],
		required: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "required",
				required: false
			}]
		}],
		readonly: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "readonly",
				required: false
			}]
		}],
		textAlign: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "textAlign",
				required: false
			}]
		}],
		renderItem: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "renderItem",
				required: false
			}]
		}],
		dropDownSync: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownSync",
				required: false
			}]
		}],
		dropDownPlacement: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownPlacement",
				required: false
			}]
		}],
		dropDownStrategy: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownStrategy",
				required: false
			}]
		}],
		dropDownDistance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownDistance",
				required: false
			}]
		}],
		dropDownSkidding: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownSkidding",
				required: false
			}]
		}],
		dropDownStaysOpen: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownStaysOpen",
				required: false
			}]
		}],
		dropDownMaxHeight: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownMaxHeight",
				required: false
			}]
		}],
		dropDownHeight: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownHeight",
				required: false
			}]
		}],
		dropDownWidth: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownWidth",
				required: false
			}]
		}],
		dropDownMaxWidth: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownMaxWidth",
				required: false
			}]
		}],
		isDropDownOpen: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isDropDownOpen",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		isClearable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isClearable",
				required: false
			}]
		}],
		invalid: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "invalid",
				required: false
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		minimumPrefixLength: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "minimumPrefixLength",
				required: false
			}]
		}],
		minimumPopulateDelay: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "minimumPopulateDelay",
				required: false
			}]
		}],
		isTextCompletionEnabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isTextCompletionEnabled",
				required: false
			}]
		}],
		searchMode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "searchMode",
				required: false
			}]
		}],
		displayMemberPath: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "displayMemberPath",
				required: false
			}]
		}],
		valueMemberPath: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "valueMemberPath",
				required: false
			}]
		}],
		items: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "items",
				required: false
			}]
		}],
		itemsProvider: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "itemsProvider",
				required: false
			}]
		}],
		populating: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "populating",
				required: false
			}]
		}],
		populated: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "populated",
				required: false
			}]
		}],
		itemSelected: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "itemSelected",
				required: false
			}]
		}],
		filteredItems: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "filteredItems",
				required: false
			}]
		}],
		isPopulating: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isPopulating",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		formatter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "formatter",
				required: false
			}]
		}],
		parser: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "parser",
				required: false
			}]
		}],
		isFocused: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isFocused",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		cleared: [{
			type: i0.Output,
			args: ["cleared"]
		}],
		autoCompletePopulating: [{
			type: i0.Output,
			args: ["autoCompletePopulating"]
		}],
		autoCompletePopulated: [{
			type: i0.Output,
			args: ["autoCompletePopulated"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideAutoCompleteBoxComponent(config, intl) {
	const providers = [];
	if (config) providers.push({
		provide: AUTO_COMPLETE_BOX_DEFAULT_PROPS,
		useValue: config
	});
	if (intl) {
		if (typeof intl === "function") providers.push({
			provide: AUTO_COMPLETE_BOX_INTL,
			useClass: intl
		});
		else providers.push({
			provide: AUTO_COMPLETE_BOX_INTL,
			useValue: intl
		});
	}
	return makeEnvironmentProviders(providers);
}
export { AUTO_COMPLETE_BOX_DEFAULT_PROPS, AUTO_COMPLETE_BOX_INTL, AutoCompleteBoxComponent, provideAutoCompleteBoxComponent };

//# sourceMappingURL=mosaik-elements-angular-components-auto-complete-box.mjs.map