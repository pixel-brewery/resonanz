import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { AnchorElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/buttons/anchor/AnchorElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const ANCHOR_DEFAULT_PROPS = new InjectionToken("MOSAIK_ANCHOR_DEFAULT_PROPS");
let AnchorComponent = class AnchorComponent {
	underline = input(...ngDevMode ? [void 0, { debugName: "underline" }] : /* istanbul ignore next */ []);
	download = input(...ngDevMode ? [void 0, { debugName: "download" }] : /* istanbul ignore next */ []);
	href = input(...ngDevMode ? [void 0, { debugName: "href" }] : /* istanbul ignore next */ []);
	rel = input(...ngDevMode ? [void 0, { debugName: "rel" }] : /* istanbul ignore next */ []);
	target = input(...ngDevMode ? [void 0, { debugName: "target" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	label = input(...ngDevMode ? [void 0, { debugName: "label" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(ANCHOR_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const underlineValue = this.underline();
			if (underlineValue !== void 0) this._elementRef.nativeElement.underline = underlineValue;
			const downloadValue = this.download();
			if (downloadValue !== void 0) this._elementRef.nativeElement.download = downloadValue;
			const hrefValue = this.href();
			if (hrefValue !== void 0) this._elementRef.nativeElement.href = hrefValue;
			const relValue = this.rel();
			if (relValue !== void 0) this._elementRef.nativeElement.rel = relValue;
			const targetValue = this.target();
			if (targetValue !== void 0) this._elementRef.nativeElement.target = targetValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const labelValue = this.label();
			if (labelValue !== void 0) this._elementRef.nativeElement.label = labelValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: AnchorComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: AnchorComponent,
		isStandalone: true,
		selector: "mosaik-anchor",
		inputs: {
			underline: {
				classPropertyName: "underline",
				publicName: "underline",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			download: {
				classPropertyName: "download",
				publicName: "download",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			href: {
				classPropertyName: "href",
				publicName: "href",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			rel: {
				classPropertyName: "rel",
				publicName: "rel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			target: {
				classPropertyName: "target",
				publicName: "target",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
AnchorComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-anchor", AnchorElement),
	inputs: [
		"underline",
		"download",
		"href",
		"rel",
		"target",
		"themeName",
		"variant",
		"disabled",
		"label",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], AnchorComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: AnchorComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-anchor",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		underline: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "underline",
				required: false
			}]
		}],
		download: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "download",
				required: false
			}]
		}],
		href: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "href",
				required: false
			}]
		}],
		rel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "rel",
				required: false
			}]
		}],
		target: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "target",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideAnchorComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: ANCHOR_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { ANCHOR_DEFAULT_PROPS, AnchorComponent, provideAnchorComponent };

//# sourceMappingURL=mosaik-elements-angular-components-anchor.mjs.map