import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { VirtualizeElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/virtualize/VirtualizeElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const VIRTUALIZE_DEFAULT_PROPS = new InjectionToken("MOSAIK_VIRTUALIZE_DEFAULT_PROPS");
let VirtualizeComponent = class VirtualizeComponent {
	items = input(...ngDevMode ? [void 0, { debugName: "items" }] : /* istanbul ignore next */ []);
	renderItem = input(...ngDevMode ? [void 0, { debugName: "renderItem" }] : /* istanbul ignore next */ []);
	keyFunction = input(...ngDevMode ? [void 0, { debugName: "keyFunction" }] : /* istanbul ignore next */ []);
	layout = input(...ngDevMode ? [void 0, { debugName: "layout" }] : /* istanbul ignore next */ []);
	scroller = input(...ngDevMode ? [void 0, { debugName: "scroller" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(VIRTUALIZE_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const renderItemValue = this.renderItem();
			if (renderItemValue !== void 0) this._elementRef.nativeElement.renderItem = renderItemValue;
			const keyFunctionValue = this.keyFunction();
			if (keyFunctionValue !== void 0) this._elementRef.nativeElement.keyFunction = keyFunctionValue;
			const layoutValue = this.layout();
			if (layoutValue !== void 0) this._elementRef.nativeElement.layout = layoutValue;
			const scrollerValue = this.scroller();
			if (scrollerValue !== void 0) this._elementRef.nativeElement.scroller = scrollerValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: VirtualizeComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: VirtualizeComponent,
		isStandalone: true,
		selector: "mosaik-virtualize",
		inputs: {
			items: {
				classPropertyName: "items",
				publicName: "items",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			renderItem: {
				classPropertyName: "renderItem",
				publicName: "renderItem",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			keyFunction: {
				classPropertyName: "keyFunction",
				publicName: "keyFunction",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			layout: {
				classPropertyName: "layout",
				publicName: "layout",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			scroller: {
				classPropertyName: "scroller",
				publicName: "scroller",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
VirtualizeComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-virtualize", VirtualizeElement),
	inputs: [
		"items",
		"renderItem",
		"keyFunction",
		"layout",
		"scroller",
		"themeName",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], VirtualizeComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: VirtualizeComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-virtualize",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		items: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "items",
				required: false
			}]
		}],
		renderItem: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "renderItem",
				required: false
			}]
		}],
		keyFunction: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "keyFunction",
				required: false
			}]
		}],
		layout: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "layout",
				required: false
			}]
		}],
		scroller: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "scroller",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideVirtualizeComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: VIRTUALIZE_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { VIRTUALIZE_DEFAULT_PROPS, VirtualizeComponent, provideVirtualizeComponent };

//# sourceMappingURL=mosaik-elements-angular-components-virtualize.mjs.map