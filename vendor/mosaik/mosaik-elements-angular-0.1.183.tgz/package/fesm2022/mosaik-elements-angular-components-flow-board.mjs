import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { FlowBoardColumnComposerElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/flow-board/FlowBoardColumnComposerElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { FlowBoardColumnItemComposerElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/flow-board/FlowBoardColumnItemComposerElement";
import { FlowBoardColumnItemGroupElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/flow-board/FlowBoardColumnItemGroupElement";
import { FlowBoardColumnItemElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/flow-board/FlowBoardColumnItemElement";
import { FlowBoardColumnElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/flow-board/FlowBoardColumnElement";
import { FlowBoardElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/flow-board/FlowBoardElement";
var __decorate$5 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$5 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const FLOW_BOARD_COLUMN_COMPOSER_DEFAULT_PROPS = new InjectionToken("MOSAIK_FLOW_BOARD_COLUMN_COMPOSER_DEFAULT_PROPS");
let FlowBoardColumnComposerComponent = class FlowBoardColumnComposerComponent {
	open = input(...ngDevMode ? [void 0, { debugName: "open" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	flowBoardBeforeColumnCreate = output();
	flowBoardColumnCreate = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			flowBoardBeforeColumnCreate: this.flowBoardBeforeColumnCreate,
			flowBoardColumnCreate: this.flowBoardColumnCreate,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(FLOW_BOARD_COLUMN_COMPOSER_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	create(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "create", args);
	}
	toggle(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "toggle", args);
	}
	close(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "close", args);
	}
	assignToSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "assignToSlot", args);
	}
	getSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getSlotContent", args);
	}
	hasSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlotContent", args);
	}
	hasSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlot", args);
	}
	onSlotChanges(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onSlotChanges", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const openValue = this.open();
			if (openValue !== void 0) this._elementRef.nativeElement.open = openValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FlowBoardColumnComposerComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: FlowBoardColumnComposerComponent,
		isStandalone: true,
		selector: "mosaik-flow-board-column-composer",
		inputs: {
			open: {
				classPropertyName: "open",
				publicName: "open",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			flowBoardBeforeColumnCreate: "flowBoardBeforeColumnCreate",
			flowBoardColumnCreate: "flowBoardColumnCreate",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
FlowBoardColumnComposerComponent = __decorate$5([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-flow-board-column-composer", FlowBoardColumnComposerElement),
	inputs: [
		"open",
		"themeName",
		"dir",
		"lang"
	],
	methods: ["getSlotAssignments", "getSlotAssignmentsOf"]
}), __metadata$5("design:paramtypes", [])], FlowBoardColumnComposerComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FlowBoardColumnComposerComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-flow-board-column-composer",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		open: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "open",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		flowBoardBeforeColumnCreate: [{
			type: i0.Output,
			args: ["flowBoardBeforeColumnCreate"]
		}],
		flowBoardColumnCreate: [{
			type: i0.Output,
			args: ["flowBoardColumnCreate"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideFlowBoardColumnComposerComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: FLOW_BOARD_COLUMN_COMPOSER_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$4 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$4 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const FLOW_BOARD_COLUMN_ITEM_COMPOSER_DEFAULT_PROPS = new InjectionToken("MOSAIK_FLOW_BOARD_COLUMN_ITEM_COMPOSER_DEFAULT_PROPS");
let FlowBoardColumnItemComposerComponent = class FlowBoardColumnItemComposerComponent {
	open = input(...ngDevMode ? [void 0, { debugName: "open" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	flowBoardBeforeItemCreate = output();
	flowBoardItemCreate = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			flowBoardBeforeItemCreate: this.flowBoardBeforeItemCreate,
			flowBoardItemCreate: this.flowBoardItemCreate,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(FLOW_BOARD_COLUMN_ITEM_COMPOSER_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	create(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "create", args);
	}
	toggle(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "toggle", args);
	}
	close(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "close", args);
	}
	assignToSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "assignToSlot", args);
	}
	getSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getSlotContent", args);
	}
	hasSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlotContent", args);
	}
	hasSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlot", args);
	}
	onSlotChanges(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onSlotChanges", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const openValue = this.open();
			if (openValue !== void 0) this._elementRef.nativeElement.open = openValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FlowBoardColumnItemComposerComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: FlowBoardColumnItemComposerComponent,
		isStandalone: true,
		selector: "mosaik-flow-board-column-item-composer",
		inputs: {
			open: {
				classPropertyName: "open",
				publicName: "open",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			flowBoardBeforeItemCreate: "flowBoardBeforeItemCreate",
			flowBoardItemCreate: "flowBoardItemCreate",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
FlowBoardColumnItemComposerComponent = __decorate$4([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-flow-board-column-item-composer", FlowBoardColumnItemComposerElement),
	inputs: [
		"open",
		"themeName",
		"dir",
		"lang"
	],
	methods: ["getSlotAssignments", "getSlotAssignmentsOf"]
}), __metadata$4("design:paramtypes", [])], FlowBoardColumnItemComposerComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FlowBoardColumnItemComposerComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-flow-board-column-item-composer",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		open: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "open",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		flowBoardBeforeItemCreate: [{
			type: i0.Output,
			args: ["flowBoardBeforeItemCreate"]
		}],
		flowBoardItemCreate: [{
			type: i0.Output,
			args: ["flowBoardItemCreate"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideFlowBoardColumnItemComposerComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: FLOW_BOARD_COLUMN_ITEM_COMPOSER_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$3 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$3 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const FLOW_BOARD_COLUMN_ITEM_GROUP_DEFAULT_PROPS = new InjectionToken("MOSAIK_FLOW_BOARD_COLUMN_ITEM_GROUP_DEFAULT_PROPS");
let FlowBoardColumnItemGroupComponent = class FlowBoardColumnItemGroupComponent {
	groupKey = input(...ngDevMode ? [void 0, { debugName: "groupKey" }] : /* istanbul ignore next */ []);
	rootItemKey = input(...ngDevMode ? [void 0, { debugName: "rootItemKey" }] : /* istanbul ignore next */ []);
	stacking = input(...ngDevMode ? [void 0, { debugName: "stacking" }] : /* istanbul ignore next */ []);
	maxStackDepth = input(...ngDevMode ? [void 0, { debugName: "maxStackDepth" }] : /* istanbul ignore next */ []);
	revealTrigger = input(...ngDevMode ? [void 0, { debugName: "revealTrigger" }] : /* istanbul ignore next */ []);
	intl = input(...ngDevMode ? [void 0, { debugName: "intl" }] : /* istanbul ignore next */ []);
	itemKey = input(...ngDevMode ? [void 0, { debugName: "itemKey" }] : /* istanbul ignore next */ []);
	draggable = input(...ngDevMode ? [void 0, { debugName: "draggable" }] : /* istanbul ignore next */ []);
	reorderable = input(...ngDevMode ? [void 0, { debugName: "reorderable" }] : /* istanbul ignore next */ []);
	pinned = input(...ngDevMode ? [void 0, { debugName: "pinned" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	ripple = input(...ngDevMode ? [void 0, { debugName: "ripple" }] : /* istanbul ignore next */ []);
	isFocused = input(...ngDevMode ? [void 0, { debugName: "isFocused" }] : /* istanbul ignore next */ []);
	isSelected = input(...ngDevMode ? [void 0, { debugName: "isSelected" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	value = input(...ngDevMode ? [void 0, { debugName: "value" }] : /* istanbul ignore next */ []);
	appearance = input(...ngDevMode ? [void 0, { debugName: "appearance" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	flowBoardBeforeItemActivate = output();
	flowBoardItemActivate = output();
	flowBoardBeforeItemPinChange = output();
	flowBoardItemPinChange = output();
	selected = output();
	deselected = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			flowBoardBeforeItemActivate: this.flowBoardBeforeItemActivate,
			flowBoardItemActivate: this.flowBoardItemActivate,
			flowBoardBeforeItemPinChange: this.flowBoardBeforeItemPinChange,
			flowBoardItemPinChange: this.flowBoardItemPinChange,
			selected: this.selected,
			deselected: this.deselected,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(FLOW_BOARD_COLUMN_ITEM_GROUP_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	expand(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "expand", args);
	}
	collapse(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "collapse", args);
	}
	suppressReveal(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "suppressReveal", args);
	}
	activate(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "activate", args);
	}
	pin(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "pin", args);
	}
	unpin(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "unpin", args);
	}
	assignToSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "assignToSlot", args);
	}
	getSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getSlotContent", args);
	}
	hasSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlotContent", args);
	}
	hasSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlot", args);
	}
	onSlotChanges(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onSlotChanges", args);
	}
	select(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "select", args);
	}
	deselect(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "deselect", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const groupKeyValue = this.groupKey();
			if (groupKeyValue !== void 0) this._elementRef.nativeElement.groupKey = groupKeyValue;
			const rootItemKeyValue = this.rootItemKey();
			if (rootItemKeyValue !== void 0) this._elementRef.nativeElement.rootItemKey = rootItemKeyValue;
			const stackingValue = this.stacking();
			if (stackingValue !== void 0) this._elementRef.nativeElement.stacking = stackingValue;
			const maxStackDepthValue = this.maxStackDepth();
			if (maxStackDepthValue !== void 0) this._elementRef.nativeElement.maxStackDepth = maxStackDepthValue;
			const revealTriggerValue = this.revealTrigger();
			if (revealTriggerValue !== void 0) this._elementRef.nativeElement.revealTrigger = revealTriggerValue;
			const itemKeyValue = this.itemKey();
			if (itemKeyValue !== void 0) this._elementRef.nativeElement.itemKey = itemKeyValue;
			const draggableValue = this.draggable();
			if (draggableValue !== void 0) this._elementRef.nativeElement.draggable = draggableValue;
			const reorderableValue = this.reorderable();
			if (reorderableValue !== void 0) this._elementRef.nativeElement.reorderable = reorderableValue;
			const pinnedValue = this.pinned();
			if (pinnedValue !== void 0) this._elementRef.nativeElement.pinned = pinnedValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const rippleValue = this.ripple();
			if (rippleValue !== void 0) this._elementRef.nativeElement.ripple = rippleValue;
			const isFocusedValue = this.isFocused();
			if (isFocusedValue !== void 0) this._elementRef.nativeElement.isFocused = isFocusedValue;
			const isSelectedValue = this.isSelected();
			if (isSelectedValue !== void 0) this._elementRef.nativeElement.isSelected = isSelectedValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const valueValue = this.value();
			if (valueValue !== void 0) this._elementRef.nativeElement.value = valueValue;
			const appearanceValue = this.appearance();
			if (appearanceValue !== void 0) this._elementRef.nativeElement.appearance = appearanceValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FlowBoardColumnItemGroupComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: FlowBoardColumnItemGroupComponent,
		isStandalone: true,
		selector: "mosaik-flow-board-column-item-group",
		inputs: {
			groupKey: {
				classPropertyName: "groupKey",
				publicName: "groupKey",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			rootItemKey: {
				classPropertyName: "rootItemKey",
				publicName: "rootItemKey",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			stacking: {
				classPropertyName: "stacking",
				publicName: "stacking",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			maxStackDepth: {
				classPropertyName: "maxStackDepth",
				publicName: "maxStackDepth",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			revealTrigger: {
				classPropertyName: "revealTrigger",
				publicName: "revealTrigger",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			intl: {
				classPropertyName: "intl",
				publicName: "intl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			itemKey: {
				classPropertyName: "itemKey",
				publicName: "itemKey",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			draggable: {
				classPropertyName: "draggable",
				publicName: "draggable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			reorderable: {
				classPropertyName: "reorderable",
				publicName: "reorderable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			pinned: {
				classPropertyName: "pinned",
				publicName: "pinned",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			ripple: {
				classPropertyName: "ripple",
				publicName: "ripple",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isFocused: {
				classPropertyName: "isFocused",
				publicName: "isFocused",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isSelected: {
				classPropertyName: "isSelected",
				publicName: "isSelected",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			flowBoardBeforeItemActivate: "flowBoardBeforeItemActivate",
			flowBoardItemActivate: "flowBoardItemActivate",
			flowBoardBeforeItemPinChange: "flowBoardBeforeItemPinChange",
			flowBoardItemPinChange: "flowBoardItemPinChange",
			selected: "selected",
			deselected: "deselected",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
FlowBoardColumnItemGroupComponent = __decorate$3([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-flow-board-column-item-group", FlowBoardColumnItemGroupElement),
	inputs: [
		"groupKey",
		"rootItemKey",
		"stacking",
		"maxStackDepth",
		"revealTrigger",
		"intl",
		"itemKey",
		"draggable",
		"reorderable",
		"pinned",
		"themeName",
		"ripple",
		"isFocused",
		"isSelected",
		"disabled",
		"variant",
		"value",
		"appearance",
		"dir",
		"lang"
	],
	methods: ["getSlotAssignments", "getSlotAssignmentsOf"]
}), __metadata$3("design:paramtypes", [])], FlowBoardColumnItemGroupComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FlowBoardColumnItemGroupComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-flow-board-column-item-group",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		groupKey: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "groupKey",
				required: false
			}]
		}],
		rootItemKey: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "rootItemKey",
				required: false
			}]
		}],
		stacking: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "stacking",
				required: false
			}]
		}],
		maxStackDepth: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maxStackDepth",
				required: false
			}]
		}],
		revealTrigger: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "revealTrigger",
				required: false
			}]
		}],
		intl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "intl",
				required: false
			}]
		}],
		itemKey: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "itemKey",
				required: false
			}]
		}],
		draggable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "draggable",
				required: false
			}]
		}],
		reorderable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "reorderable",
				required: false
			}]
		}],
		pinned: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "pinned",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		ripple: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "ripple",
				required: false
			}]
		}],
		isFocused: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isFocused",
				required: false
			}]
		}],
		isSelected: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isSelected",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		flowBoardBeforeItemActivate: [{
			type: i0.Output,
			args: ["flowBoardBeforeItemActivate"]
		}],
		flowBoardItemActivate: [{
			type: i0.Output,
			args: ["flowBoardItemActivate"]
		}],
		flowBoardBeforeItemPinChange: [{
			type: i0.Output,
			args: ["flowBoardBeforeItemPinChange"]
		}],
		flowBoardItemPinChange: [{
			type: i0.Output,
			args: ["flowBoardItemPinChange"]
		}],
		selected: [{
			type: i0.Output,
			args: ["selected"]
		}],
		deselected: [{
			type: i0.Output,
			args: ["deselected"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideFlowBoardColumnItemGroupComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: FLOW_BOARD_COLUMN_ITEM_GROUP_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$2 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$2 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const FLOW_BOARD_COLUMN_ITEM_DEFAULT_PROPS = new InjectionToken("MOSAIK_FLOW_BOARD_COLUMN_ITEM_DEFAULT_PROPS");
let FlowBoardColumnItemComponent = class FlowBoardColumnItemComponent {
	intl = input(...ngDevMode ? [void 0, { debugName: "intl" }] : /* istanbul ignore next */ []);
	itemKey = input(...ngDevMode ? [void 0, { debugName: "itemKey" }] : /* istanbul ignore next */ []);
	draggable = input(...ngDevMode ? [void 0, { debugName: "draggable" }] : /* istanbul ignore next */ []);
	reorderable = input(...ngDevMode ? [void 0, { debugName: "reorderable" }] : /* istanbul ignore next */ []);
	pinned = input(...ngDevMode ? [void 0, { debugName: "pinned" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	ripple = input(...ngDevMode ? [void 0, { debugName: "ripple" }] : /* istanbul ignore next */ []);
	isFocused = input(...ngDevMode ? [void 0, { debugName: "isFocused" }] : /* istanbul ignore next */ []);
	isSelected = input(...ngDevMode ? [void 0, { debugName: "isSelected" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	value = input(...ngDevMode ? [void 0, { debugName: "value" }] : /* istanbul ignore next */ []);
	appearance = input(...ngDevMode ? [void 0, { debugName: "appearance" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	flowBoardBeforeItemActivate = output();
	flowBoardItemActivate = output();
	flowBoardBeforeItemPinChange = output();
	flowBoardItemPinChange = output();
	selected = output();
	deselected = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			flowBoardBeforeItemActivate: this.flowBoardBeforeItemActivate,
			flowBoardItemActivate: this.flowBoardItemActivate,
			flowBoardBeforeItemPinChange: this.flowBoardBeforeItemPinChange,
			flowBoardItemPinChange: this.flowBoardItemPinChange,
			selected: this.selected,
			deselected: this.deselected,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(FLOW_BOARD_COLUMN_ITEM_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	activate(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "activate", args);
	}
	pin(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "pin", args);
	}
	unpin(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "unpin", args);
	}
	assignToSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "assignToSlot", args);
	}
	getSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getSlotContent", args);
	}
	hasSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlotContent", args);
	}
	hasSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlot", args);
	}
	onSlotChanges(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onSlotChanges", args);
	}
	select(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "select", args);
	}
	deselect(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "deselect", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const itemKeyValue = this.itemKey();
			if (itemKeyValue !== void 0) this._elementRef.nativeElement.itemKey = itemKeyValue;
			const draggableValue = this.draggable();
			if (draggableValue !== void 0) this._elementRef.nativeElement.draggable = draggableValue;
			const reorderableValue = this.reorderable();
			if (reorderableValue !== void 0) this._elementRef.nativeElement.reorderable = reorderableValue;
			const pinnedValue = this.pinned();
			if (pinnedValue !== void 0) this._elementRef.nativeElement.pinned = pinnedValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const rippleValue = this.ripple();
			if (rippleValue !== void 0) this._elementRef.nativeElement.ripple = rippleValue;
			const isFocusedValue = this.isFocused();
			if (isFocusedValue !== void 0) this._elementRef.nativeElement.isFocused = isFocusedValue;
			const isSelectedValue = this.isSelected();
			if (isSelectedValue !== void 0) this._elementRef.nativeElement.isSelected = isSelectedValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const valueValue = this.value();
			if (valueValue !== void 0) this._elementRef.nativeElement.value = valueValue;
			const appearanceValue = this.appearance();
			if (appearanceValue !== void 0) this._elementRef.nativeElement.appearance = appearanceValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FlowBoardColumnItemComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: FlowBoardColumnItemComponent,
		isStandalone: true,
		selector: "mosaik-flow-board-column-item",
		inputs: {
			intl: {
				classPropertyName: "intl",
				publicName: "intl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			itemKey: {
				classPropertyName: "itemKey",
				publicName: "itemKey",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			draggable: {
				classPropertyName: "draggable",
				publicName: "draggable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			reorderable: {
				classPropertyName: "reorderable",
				publicName: "reorderable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			pinned: {
				classPropertyName: "pinned",
				publicName: "pinned",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			ripple: {
				classPropertyName: "ripple",
				publicName: "ripple",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isFocused: {
				classPropertyName: "isFocused",
				publicName: "isFocused",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isSelected: {
				classPropertyName: "isSelected",
				publicName: "isSelected",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			flowBoardBeforeItemActivate: "flowBoardBeforeItemActivate",
			flowBoardItemActivate: "flowBoardItemActivate",
			flowBoardBeforeItemPinChange: "flowBoardBeforeItemPinChange",
			flowBoardItemPinChange: "flowBoardItemPinChange",
			selected: "selected",
			deselected: "deselected",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
FlowBoardColumnItemComponent = __decorate$2([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-flow-board-column-item", FlowBoardColumnItemElement),
	inputs: [
		"intl",
		"itemKey",
		"draggable",
		"reorderable",
		"pinned",
		"themeName",
		"ripple",
		"isFocused",
		"isSelected",
		"disabled",
		"variant",
		"value",
		"appearance",
		"dir",
		"lang"
	],
	methods: ["getSlotAssignments", "getSlotAssignmentsOf"]
}), __metadata$2("design:paramtypes", [])], FlowBoardColumnItemComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FlowBoardColumnItemComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-flow-board-column-item",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		intl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "intl",
				required: false
			}]
		}],
		itemKey: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "itemKey",
				required: false
			}]
		}],
		draggable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "draggable",
				required: false
			}]
		}],
		reorderable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "reorderable",
				required: false
			}]
		}],
		pinned: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "pinned",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		ripple: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "ripple",
				required: false
			}]
		}],
		isFocused: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isFocused",
				required: false
			}]
		}],
		isSelected: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isSelected",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		flowBoardBeforeItemActivate: [{
			type: i0.Output,
			args: ["flowBoardBeforeItemActivate"]
		}],
		flowBoardItemActivate: [{
			type: i0.Output,
			args: ["flowBoardItemActivate"]
		}],
		flowBoardBeforeItemPinChange: [{
			type: i0.Output,
			args: ["flowBoardBeforeItemPinChange"]
		}],
		flowBoardItemPinChange: [{
			type: i0.Output,
			args: ["flowBoardItemPinChange"]
		}],
		selected: [{
			type: i0.Output,
			args: ["selected"]
		}],
		deselected: [{
			type: i0.Output,
			args: ["deselected"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideFlowBoardColumnItemComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: FLOW_BOARD_COLUMN_ITEM_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$1 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$1 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const FLOW_BOARD_COLUMN_DEFAULT_PROPS = new InjectionToken("MOSAIK_FLOW_BOARD_COLUMN_DEFAULT_PROPS");
let FlowBoardColumnComponent = class FlowBoardColumnComponent {
	intl = input(...ngDevMode ? [void 0, { debugName: "intl" }] : /* istanbul ignore next */ []);
	columnKey = input(...ngDevMode ? [void 0, { debugName: "columnKey" }] : /* istanbul ignore next */ []);
	reorderable = input(...ngDevMode ? [void 0, { debugName: "reorderable" }] : /* istanbul ignore next */ []);
	pinned = input(...ngDevMode ? [void 0, { debugName: "pinned" }] : /* istanbul ignore next */ []);
	collapsible = input(...ngDevMode ? [void 0, { debugName: "collapsible" }] : /* istanbul ignore next */ []);
	showItemCount = input(...ngDevMode ? [void 0, { debugName: "showItemCount" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	isExpanded = input(...ngDevMode ? [void 0, { debugName: "isExpanded" }] : /* istanbul ignore next */ []);
	expanded = input(...ngDevMode ? [void 0, { debugName: "expanded" }] : /* istanbul ignore next */ []);
	collapsed = input(...ngDevMode ? [void 0, { debugName: "collapsed" }] : /* istanbul ignore next */ []);
	toggled = input(...ngDevMode ? [void 0, { debugName: "toggled" }] : /* istanbul ignore next */ []);
	showScrollButtons = input(...ngDevMode ? [void 0, { debugName: "showScrollButtons" }] : /* istanbul ignore next */ []);
	showScrollbar = input(...ngDevMode ? [void 0, { debugName: "showScrollbar" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	appearance = input(...ngDevMode ? [void 0, { debugName: "appearance" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	flowBoardBeforeColumnPinChange = output();
	flowBoardColumnPinChange = output();
	flowBoardBeforeColumnExpandChange = output();
	flowBoardColumnExpandChange = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			flowBoardBeforeColumnPinChange: this.flowBoardBeforeColumnPinChange,
			flowBoardColumnPinChange: this.flowBoardColumnPinChange,
			flowBoardBeforeColumnExpandChange: this.flowBoardBeforeColumnExpandChange,
			flowBoardColumnExpandChange: this.flowBoardColumnExpandChange,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(FLOW_BOARD_COLUMN_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	getScrollableElement(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getScrollableElement", args);
	}
	getItems(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getItems", args);
	}
	getPinnedItems(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getPinnedItems", args);
	}
	getNonPinnedItems(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getNonPinnedItems", args);
	}
	setPinned(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "setPinned", args);
	}
	expand(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "expand", args);
	}
	collapse(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "collapse", args);
	}
	toggle(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "toggle", args);
	}
	assignToSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "assignToSlot", args);
	}
	getSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getSlotContent", args);
	}
	hasSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlotContent", args);
	}
	hasSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlot", args);
	}
	onSlotChanges(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onSlotChanges", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const columnKeyValue = this.columnKey();
			if (columnKeyValue !== void 0) this._elementRef.nativeElement.columnKey = columnKeyValue;
			const reorderableValue = this.reorderable();
			if (reorderableValue !== void 0) this._elementRef.nativeElement.reorderable = reorderableValue;
			const pinnedValue = this.pinned();
			if (pinnedValue !== void 0) this._elementRef.nativeElement.pinned = pinnedValue;
			const collapsibleValue = this.collapsible();
			if (collapsibleValue !== void 0) this._elementRef.nativeElement.collapsible = collapsibleValue;
			const showItemCountValue = this.showItemCount();
			if (showItemCountValue !== void 0) this._elementRef.nativeElement.showItemCount = showItemCountValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const isExpandedValue = this.isExpanded();
			if (isExpandedValue !== void 0) this._elementRef.nativeElement.isExpanded = isExpandedValue;
			const expandedValue = this.expanded();
			if (expandedValue !== void 0) this._elementRef.nativeElement.expanded = expandedValue;
			const collapsedValue = this.collapsed();
			if (collapsedValue !== void 0) this._elementRef.nativeElement.collapsed = collapsedValue;
			const toggledValue = this.toggled();
			if (toggledValue !== void 0) this._elementRef.nativeElement.toggled = toggledValue;
			const showScrollButtonsValue = this.showScrollButtons();
			if (showScrollButtonsValue !== void 0) this._elementRef.nativeElement.showScrollButtons = showScrollButtonsValue;
			const showScrollbarValue = this.showScrollbar();
			if (showScrollbarValue !== void 0) this._elementRef.nativeElement.showScrollbar = showScrollbarValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const appearanceValue = this.appearance();
			if (appearanceValue !== void 0) this._elementRef.nativeElement.appearance = appearanceValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FlowBoardColumnComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: FlowBoardColumnComponent,
		isStandalone: true,
		selector: "mosaik-flow-board-column",
		inputs: {
			intl: {
				classPropertyName: "intl",
				publicName: "intl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			columnKey: {
				classPropertyName: "columnKey",
				publicName: "columnKey",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			reorderable: {
				classPropertyName: "reorderable",
				publicName: "reorderable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			pinned: {
				classPropertyName: "pinned",
				publicName: "pinned",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			collapsible: {
				classPropertyName: "collapsible",
				publicName: "collapsible",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showItemCount: {
				classPropertyName: "showItemCount",
				publicName: "showItemCount",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isExpanded: {
				classPropertyName: "isExpanded",
				publicName: "isExpanded",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			expanded: {
				classPropertyName: "expanded",
				publicName: "expanded",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			collapsed: {
				classPropertyName: "collapsed",
				publicName: "collapsed",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			toggled: {
				classPropertyName: "toggled",
				publicName: "toggled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showScrollButtons: {
				classPropertyName: "showScrollButtons",
				publicName: "showScrollButtons",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showScrollbar: {
				classPropertyName: "showScrollbar",
				publicName: "showScrollbar",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			flowBoardBeforeColumnPinChange: "flowBoardBeforeColumnPinChange",
			flowBoardColumnPinChange: "flowBoardColumnPinChange",
			flowBoardBeforeColumnExpandChange: "flowBoardBeforeColumnExpandChange",
			flowBoardColumnExpandChange: "flowBoardColumnExpandChange",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
FlowBoardColumnComponent = __decorate$1([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-flow-board-column", FlowBoardColumnElement),
	inputs: [
		"intl",
		"columnKey",
		"reorderable",
		"pinned",
		"collapsible",
		"showItemCount",
		"themeName",
		"isExpanded",
		"expanded",
		"collapsed",
		"toggled",
		"showScrollButtons",
		"showScrollbar",
		"disabled",
		"appearance",
		"dir",
		"lang"
	],
	methods: ["getSlotAssignments", "getSlotAssignmentsOf"]
}), __metadata$1("design:paramtypes", [])], FlowBoardColumnComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FlowBoardColumnComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-flow-board-column",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		intl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "intl",
				required: false
			}]
		}],
		columnKey: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "columnKey",
				required: false
			}]
		}],
		reorderable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "reorderable",
				required: false
			}]
		}],
		pinned: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "pinned",
				required: false
			}]
		}],
		collapsible: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "collapsible",
				required: false
			}]
		}],
		showItemCount: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showItemCount",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		isExpanded: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isExpanded",
				required: false
			}]
		}],
		expanded: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "expanded",
				required: false
			}]
		}],
		collapsed: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "collapsed",
				required: false
			}]
		}],
		toggled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "toggled",
				required: false
			}]
		}],
		showScrollButtons: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showScrollButtons",
				required: false
			}]
		}],
		showScrollbar: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showScrollbar",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		flowBoardBeforeColumnPinChange: [{
			type: i0.Output,
			args: ["flowBoardBeforeColumnPinChange"]
		}],
		flowBoardColumnPinChange: [{
			type: i0.Output,
			args: ["flowBoardColumnPinChange"]
		}],
		flowBoardBeforeColumnExpandChange: [{
			type: i0.Output,
			args: ["flowBoardBeforeColumnExpandChange"]
		}],
		flowBoardColumnExpandChange: [{
			type: i0.Output,
			args: ["flowBoardColumnExpandChange"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideFlowBoardColumnComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: FLOW_BOARD_COLUMN_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const FLOW_BOARD_DEFAULT_PROPS = new InjectionToken("MOSAIK_FLOW_BOARD_DEFAULT_PROPS");
let FlowBoardComponent = class FlowBoardComponent {
	intl = input(...ngDevMode ? [void 0, { debugName: "intl" }] : /* istanbul ignore next */ []);
	displayMode = input(...ngDevMode ? [void 0, { debugName: "displayMode" }] : /* istanbul ignore next */ []);
	dragdrop = input(...ngDevMode ? [void 0, { debugName: "dragdrop" }] : /* istanbul ignore next */ []);
	mutationMode = input(...ngDevMode ? [void 0, { debugName: "mutationMode" }] : /* istanbul ignore next */ []);
	selectionMode = input(...ngDevMode ? [void 0, { debugName: "selectionMode" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	size = input(...ngDevMode ? [void 0, { debugName: "size" }] : /* istanbul ignore next */ []);
	gap = input(...ngDevMode ? [void 0, { debugName: "gap" }] : /* istanbul ignore next */ []);
	isFocused = input(...ngDevMode ? [void 0, { debugName: "isFocused" }] : /* istanbul ignore next */ []);
	showScrollButtons = input(...ngDevMode ? [void 0, { debugName: "showScrollButtons" }] : /* istanbul ignore next */ []);
	showScrollbar = input(...ngDevMode ? [void 0, { debugName: "showScrollbar" }] : /* istanbul ignore next */ []);
	orientation = input(...ngDevMode ? [void 0, { debugName: "orientation" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	flowBoardBeforeColumnReorder = output();
	flowBoardColumnReorder = output();
	flowBoardBeforeItemReorder = output();
	flowBoardItemReorder = output();
	flowBoardBeforeItemMove = output();
	flowBoardItemMove = output();
	flowBoardBeforeItemGroup = output();
	flowBoardItemGroup = output();
	flowBoardDragStart = output();
	flowBoardSelectionChanged = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			flowBoardBeforeColumnReorder: this.flowBoardBeforeColumnReorder,
			flowBoardColumnReorder: this.flowBoardColumnReorder,
			flowBoardBeforeItemReorder: this.flowBoardBeforeItemReorder,
			flowBoardItemReorder: this.flowBoardItemReorder,
			flowBoardBeforeItemMove: this.flowBoardBeforeItemMove,
			flowBoardItemMove: this.flowBoardItemMove,
			flowBoardBeforeItemGroup: this.flowBoardBeforeItemGroup,
			flowBoardItemGroup: this.flowBoardItemGroup,
			flowBoardDragStart: this.flowBoardDragStart,
			flowBoardSelectionChanged: this.flowBoardSelectionChanged,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(FLOW_BOARD_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	getScrollableElement(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getScrollableElement", args);
	}
	getColumns(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getColumns", args);
	}
	getColumnByKey(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getColumnByKey", args);
	}
	selectAll(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "selectAll", args);
	}
	clearSelection(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "clearSelection", args);
	}
	getSelectableItems(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getSelectableItems", args);
	}
	moveItem(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "moveItem", args);
	}
	reorderColumn(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "reorderColumn", args);
	}
	assignToSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "assignToSlot", args);
	}
	getSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getSlotContent", args);
	}
	hasSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlotContent", args);
	}
	hasSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlot", args);
	}
	onSlotChanges(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onSlotChanges", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const displayModeValue = this.displayMode();
			if (displayModeValue !== void 0) this._elementRef.nativeElement.displayMode = displayModeValue;
			const dragdropValue = this.dragdrop();
			if (dragdropValue !== void 0) this._elementRef.nativeElement.dragdrop = dragdropValue;
			const mutationModeValue = this.mutationMode();
			if (mutationModeValue !== void 0) this._elementRef.nativeElement.mutationMode = mutationModeValue;
			const selectionModeValue = this.selectionMode();
			if (selectionModeValue !== void 0) this._elementRef.nativeElement.selectionMode = selectionModeValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const sizeValue = this.size();
			if (sizeValue !== void 0) this._elementRef.nativeElement.size = sizeValue;
			const gapValue = this.gap();
			if (gapValue !== void 0) this._elementRef.nativeElement.gap = gapValue;
			const isFocusedValue = this.isFocused();
			if (isFocusedValue !== void 0) this._elementRef.nativeElement.isFocused = isFocusedValue;
			const showScrollButtonsValue = this.showScrollButtons();
			if (showScrollButtonsValue !== void 0) this._elementRef.nativeElement.showScrollButtons = showScrollButtonsValue;
			const showScrollbarValue = this.showScrollbar();
			if (showScrollbarValue !== void 0) this._elementRef.nativeElement.showScrollbar = showScrollbarValue;
			const orientationValue = this.orientation();
			if (orientationValue !== void 0) this._elementRef.nativeElement.orientation = orientationValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FlowBoardComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: FlowBoardComponent,
		isStandalone: true,
		selector: "mosaik-flow-board",
		inputs: {
			intl: {
				classPropertyName: "intl",
				publicName: "intl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			displayMode: {
				classPropertyName: "displayMode",
				publicName: "displayMode",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dragdrop: {
				classPropertyName: "dragdrop",
				publicName: "dragdrop",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			mutationMode: {
				classPropertyName: "mutationMode",
				publicName: "mutationMode",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			selectionMode: {
				classPropertyName: "selectionMode",
				publicName: "selectionMode",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			gap: {
				classPropertyName: "gap",
				publicName: "gap",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isFocused: {
				classPropertyName: "isFocused",
				publicName: "isFocused",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showScrollButtons: {
				classPropertyName: "showScrollButtons",
				publicName: "showScrollButtons",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showScrollbar: {
				classPropertyName: "showScrollbar",
				publicName: "showScrollbar",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			orientation: {
				classPropertyName: "orientation",
				publicName: "orientation",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			flowBoardBeforeColumnReorder: "flowBoardBeforeColumnReorder",
			flowBoardColumnReorder: "flowBoardColumnReorder",
			flowBoardBeforeItemReorder: "flowBoardBeforeItemReorder",
			flowBoardItemReorder: "flowBoardItemReorder",
			flowBoardBeforeItemMove: "flowBoardBeforeItemMove",
			flowBoardItemMove: "flowBoardItemMove",
			flowBoardBeforeItemGroup: "flowBoardBeforeItemGroup",
			flowBoardItemGroup: "flowBoardItemGroup",
			flowBoardDragStart: "flowBoardDragStart",
			flowBoardSelectionChanged: "flowBoardSelectionChanged",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
FlowBoardComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-flow-board", FlowBoardElement),
	inputs: [
		"intl",
		"displayMode",
		"dragdrop",
		"mutationMode",
		"selectionMode",
		"themeName",
		"size",
		"gap",
		"isFocused",
		"showScrollButtons",
		"showScrollbar",
		"orientation",
		"dir",
		"lang"
	],
	methods: ["getSlotAssignments", "getSlotAssignmentsOf"]
}), __metadata("design:paramtypes", [])], FlowBoardComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FlowBoardComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-flow-board",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		intl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "intl",
				required: false
			}]
		}],
		displayMode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "displayMode",
				required: false
			}]
		}],
		dragdrop: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dragdrop",
				required: false
			}]
		}],
		mutationMode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mutationMode",
				required: false
			}]
		}],
		selectionMode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "selectionMode",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		gap: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "gap",
				required: false
			}]
		}],
		isFocused: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isFocused",
				required: false
			}]
		}],
		showScrollButtons: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showScrollButtons",
				required: false
			}]
		}],
		showScrollbar: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showScrollbar",
				required: false
			}]
		}],
		orientation: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "orientation",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		flowBoardBeforeColumnReorder: [{
			type: i0.Output,
			args: ["flowBoardBeforeColumnReorder"]
		}],
		flowBoardColumnReorder: [{
			type: i0.Output,
			args: ["flowBoardColumnReorder"]
		}],
		flowBoardBeforeItemReorder: [{
			type: i0.Output,
			args: ["flowBoardBeforeItemReorder"]
		}],
		flowBoardItemReorder: [{
			type: i0.Output,
			args: ["flowBoardItemReorder"]
		}],
		flowBoardBeforeItemMove: [{
			type: i0.Output,
			args: ["flowBoardBeforeItemMove"]
		}],
		flowBoardItemMove: [{
			type: i0.Output,
			args: ["flowBoardItemMove"]
		}],
		flowBoardBeforeItemGroup: [{
			type: i0.Output,
			args: ["flowBoardBeforeItemGroup"]
		}],
		flowBoardItemGroup: [{
			type: i0.Output,
			args: ["flowBoardItemGroup"]
		}],
		flowBoardDragStart: [{
			type: i0.Output,
			args: ["flowBoardDragStart"]
		}],
		flowBoardSelectionChanged: [{
			type: i0.Output,
			args: ["flowBoardSelectionChanged"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideFlowBoardComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: FLOW_BOARD_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { FLOW_BOARD_COLUMN_COMPOSER_DEFAULT_PROPS, FLOW_BOARD_COLUMN_DEFAULT_PROPS, FLOW_BOARD_COLUMN_ITEM_COMPOSER_DEFAULT_PROPS, FLOW_BOARD_COLUMN_ITEM_DEFAULT_PROPS, FLOW_BOARD_COLUMN_ITEM_GROUP_DEFAULT_PROPS, FLOW_BOARD_DEFAULT_PROPS, FlowBoardColumnComponent, FlowBoardColumnComposerComponent, FlowBoardColumnItemComponent, FlowBoardColumnItemComposerComponent, FlowBoardColumnItemGroupComponent, FlowBoardComponent, provideFlowBoardColumnComponent, provideFlowBoardColumnComposerComponent, provideFlowBoardColumnItemComponent, provideFlowBoardColumnItemComposerComponent, provideFlowBoardColumnItemGroupComponent, provideFlowBoardComponent };

//# sourceMappingURL=mosaik-elements-angular-components-flow-board.mjs.map