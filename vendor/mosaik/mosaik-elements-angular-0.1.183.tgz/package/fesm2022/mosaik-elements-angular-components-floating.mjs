import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { FloatingTriggerElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/floating/FloatingTriggerElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { FloatingElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/floating/FloatingElement";
var __decorate$1 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$1 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const FLOATING_TRIGGER_DEFAULT_PROPS = new InjectionToken("MOSAIK_FLOATING_TRIGGER_DEFAULT_PROPS");
let FloatingTriggerComponent = class FloatingTriggerComponent {
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(FLOATING_TRIGGER_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FloatingTriggerComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: FloatingTriggerComponent,
		isStandalone: true,
		selector: "mosaik-floating-trigger",
		inputs: {
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
FloatingTriggerComponent = __decorate$1([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-floating-trigger", FloatingTriggerElement),
	inputs: [
		"themeName",
		"dir",
		"lang"
	]
}), __metadata$1("design:paramtypes", [])], FloatingTriggerComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FloatingTriggerComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-floating-trigger",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideFloatingTriggerComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: FLOATING_TRIGGER_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const FLOATING_DEFAULT_PROPS = new InjectionToken("MOSAIK_FLOATING_DEFAULT_PROPS");
let FloatingComponent = class FloatingComponent {
	anchor = input(...ngDevMode ? [void 0, { debugName: "anchor" }] : /* istanbul ignore next */ []);
	active = input(...ngDevMode ? [void 0, { debugName: "active" }] : /* istanbul ignore next */ []);
	placement = input(...ngDevMode ? [void 0, { debugName: "placement" }] : /* istanbul ignore next */ []);
	strategy = input(...ngDevMode ? [void 0, { debugName: "strategy" }] : /* istanbul ignore next */ []);
	distance = input(...ngDevMode ? [void 0, { debugName: "distance" }] : /* istanbul ignore next */ []);
	skidding = input(...ngDevMode ? [void 0, { debugName: "skidding" }] : /* istanbul ignore next */ []);
	arrow = input(...ngDevMode ? [void 0, { debugName: "arrow" }] : /* istanbul ignore next */ []);
	arrowPlacement = input(...ngDevMode ? [void 0, { debugName: "arrowPlacement" }] : /* istanbul ignore next */ []);
	arrowPadding = input(...ngDevMode ? [void 0, { debugName: "arrowPadding" }] : /* istanbul ignore next */ []);
	flip = input(...ngDevMode ? [void 0, { debugName: "flip" }] : /* istanbul ignore next */ []);
	flipFallbackPlacements = input(...ngDevMode ? [void 0, { debugName: "flipFallbackPlacements" }] : /* istanbul ignore next */ []);
	flipBoundary = input(...ngDevMode ? [void 0, { debugName: "flipBoundary" }] : /* istanbul ignore next */ []);
	flipPadding = input(...ngDevMode ? [void 0, { debugName: "flipPadding" }] : /* istanbul ignore next */ []);
	flipFallbackStrategy = input(...ngDevMode ? [void 0, { debugName: "flipFallbackStrategy" }] : /* istanbul ignore next */ []);
	shift = input(...ngDevMode ? [void 0, { debugName: "shift" }] : /* istanbul ignore next */ []);
	shiftCrossAxis = input(...ngDevMode ? [void 0, { debugName: "shiftCrossAxis" }] : /* istanbul ignore next */ []);
	shiftBoundary = input(...ngDevMode ? [void 0, { debugName: "shiftBoundary" }] : /* istanbul ignore next */ []);
	shiftPadding = input(...ngDevMode ? [void 0, { debugName: "shiftPadding" }] : /* istanbul ignore next */ []);
	autoSize = input(...ngDevMode ? [void 0, { debugName: "autoSize" }] : /* istanbul ignore next */ []);
	autoSizeBoundary = input(...ngDevMode ? [void 0, { debugName: "autoSizeBoundary" }] : /* istanbul ignore next */ []);
	autoSizePadding = input(...ngDevMode ? [void 0, { debugName: "autoSizePadding" }] : /* istanbul ignore next */ []);
	sync = input(...ngDevMode ? [void 0, { debugName: "sync" }] : /* istanbul ignore next */ []);
	maxWidth = input(...ngDevMode ? [void 0, { debugName: "maxWidth" }] : /* istanbul ignore next */ []);
	width = input(...ngDevMode ? [void 0, { debugName: "width" }] : /* istanbul ignore next */ []);
	maxHeight = input(...ngDevMode ? [void 0, { debugName: "maxHeight" }] : /* istanbul ignore next */ []);
	height = input(...ngDevMode ? [void 0, { debugName: "height" }] : /* istanbul ignore next */ []);
	isFullScreen = input(...ngDevMode ? [void 0, { debugName: "isFullScreen" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	enter = input(...ngDevMode ? [void 0, { debugName: "enter" }] : /* istanbul ignore next */ []);
	exit = input(...ngDevMode ? [void 0, { debugName: "exit" }] : /* istanbul ignore next */ []);
	elevation = input(...ngDevMode ? [void 0, { debugName: "elevation" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	repositioned = output();
	activeChanged = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			repositioned: this.repositioned,
			activeChanged: this.activeChanged,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(FLOATING_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	open(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "open", args);
	}
	close(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "close", args);
	}
	reposition(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "reposition", args);
	}
	getScrollableElement(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getScrollableElement", args);
	}
	play(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "play", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const anchorValue = this.anchor();
			if (anchorValue !== void 0) this._elementRef.nativeElement.anchor = anchorValue;
			const activeValue = this.active();
			if (activeValue !== void 0) this._elementRef.nativeElement.active = activeValue;
			const placementValue = this.placement();
			if (placementValue !== void 0) this._elementRef.nativeElement.placement = placementValue;
			const strategyValue = this.strategy();
			if (strategyValue !== void 0) this._elementRef.nativeElement.strategy = strategyValue;
			const distanceValue = this.distance();
			if (distanceValue !== void 0) this._elementRef.nativeElement.distance = distanceValue;
			const skiddingValue = this.skidding();
			if (skiddingValue !== void 0) this._elementRef.nativeElement.skidding = skiddingValue;
			const arrowValue = this.arrow();
			if (arrowValue !== void 0) this._elementRef.nativeElement.arrow = arrowValue;
			const arrowPlacementValue = this.arrowPlacement();
			if (arrowPlacementValue !== void 0) this._elementRef.nativeElement.arrowPlacement = arrowPlacementValue;
			const arrowPaddingValue = this.arrowPadding();
			if (arrowPaddingValue !== void 0) this._elementRef.nativeElement.arrowPadding = arrowPaddingValue;
			const flipValue = this.flip();
			if (flipValue !== void 0) this._elementRef.nativeElement.flip = flipValue;
			const flipFallbackPlacementsValue = this.flipFallbackPlacements();
			if (flipFallbackPlacementsValue !== void 0) this._elementRef.nativeElement.flipFallbackPlacements = flipFallbackPlacementsValue;
			const flipBoundaryValue = this.flipBoundary();
			if (flipBoundaryValue !== void 0) this._elementRef.nativeElement.flipBoundary = flipBoundaryValue;
			const flipPaddingValue = this.flipPadding();
			if (flipPaddingValue !== void 0) this._elementRef.nativeElement.flipPadding = flipPaddingValue;
			const flipFallbackStrategyValue = this.flipFallbackStrategy();
			if (flipFallbackStrategyValue !== void 0) this._elementRef.nativeElement.flipFallbackStrategy = flipFallbackStrategyValue;
			const shiftValue = this.shift();
			if (shiftValue !== void 0) this._elementRef.nativeElement.shift = shiftValue;
			const shiftCrossAxisValue = this.shiftCrossAxis();
			if (shiftCrossAxisValue !== void 0) this._elementRef.nativeElement.shiftCrossAxis = shiftCrossAxisValue;
			const shiftBoundaryValue = this.shiftBoundary();
			if (shiftBoundaryValue !== void 0) this._elementRef.nativeElement.shiftBoundary = shiftBoundaryValue;
			const shiftPaddingValue = this.shiftPadding();
			if (shiftPaddingValue !== void 0) this._elementRef.nativeElement.shiftPadding = shiftPaddingValue;
			const autoSizeValue = this.autoSize();
			if (autoSizeValue !== void 0) this._elementRef.nativeElement.autoSize = autoSizeValue;
			const autoSizeBoundaryValue = this.autoSizeBoundary();
			if (autoSizeBoundaryValue !== void 0) this._elementRef.nativeElement.autoSizeBoundary = autoSizeBoundaryValue;
			const autoSizePaddingValue = this.autoSizePadding();
			if (autoSizePaddingValue !== void 0) this._elementRef.nativeElement.autoSizePadding = autoSizePaddingValue;
			const syncValue = this.sync();
			if (syncValue !== void 0) this._elementRef.nativeElement.sync = syncValue;
			const maxWidthValue = this.maxWidth();
			if (maxWidthValue !== void 0) this._elementRef.nativeElement.maxWidth = maxWidthValue;
			const widthValue = this.width();
			if (widthValue !== void 0) this._elementRef.nativeElement.width = widthValue;
			const maxHeightValue = this.maxHeight();
			if (maxHeightValue !== void 0) this._elementRef.nativeElement.maxHeight = maxHeightValue;
			const heightValue = this.height();
			if (heightValue !== void 0) this._elementRef.nativeElement.height = heightValue;
			const isFullScreenValue = this.isFullScreen();
			if (isFullScreenValue !== void 0) this._elementRef.nativeElement.isFullScreen = isFullScreenValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const enterValue = this.enter();
			if (enterValue !== void 0) this._elementRef.nativeElement.enter = enterValue;
			const exitValue = this.exit();
			if (exitValue !== void 0) this._elementRef.nativeElement.exit = exitValue;
			const elevationValue = this.elevation();
			if (elevationValue !== void 0) this._elementRef.nativeElement.elevation = elevationValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FloatingComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: FloatingComponent,
		isStandalone: true,
		selector: "mosaik-floating",
		inputs: {
			anchor: {
				classPropertyName: "anchor",
				publicName: "anchor",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			active: {
				classPropertyName: "active",
				publicName: "active",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			placement: {
				classPropertyName: "placement",
				publicName: "placement",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			strategy: {
				classPropertyName: "strategy",
				publicName: "strategy",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			distance: {
				classPropertyName: "distance",
				publicName: "distance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			skidding: {
				classPropertyName: "skidding",
				publicName: "skidding",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			arrow: {
				classPropertyName: "arrow",
				publicName: "arrow",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			arrowPlacement: {
				classPropertyName: "arrowPlacement",
				publicName: "arrowPlacement",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			arrowPadding: {
				classPropertyName: "arrowPadding",
				publicName: "arrowPadding",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			flip: {
				classPropertyName: "flip",
				publicName: "flip",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			flipFallbackPlacements: {
				classPropertyName: "flipFallbackPlacements",
				publicName: "flipFallbackPlacements",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			flipBoundary: {
				classPropertyName: "flipBoundary",
				publicName: "flipBoundary",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			flipPadding: {
				classPropertyName: "flipPadding",
				publicName: "flipPadding",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			flipFallbackStrategy: {
				classPropertyName: "flipFallbackStrategy",
				publicName: "flipFallbackStrategy",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			shift: {
				classPropertyName: "shift",
				publicName: "shift",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			shiftCrossAxis: {
				classPropertyName: "shiftCrossAxis",
				publicName: "shiftCrossAxis",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			shiftBoundary: {
				classPropertyName: "shiftBoundary",
				publicName: "shiftBoundary",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			shiftPadding: {
				classPropertyName: "shiftPadding",
				publicName: "shiftPadding",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			autoSize: {
				classPropertyName: "autoSize",
				publicName: "autoSize",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			autoSizeBoundary: {
				classPropertyName: "autoSizeBoundary",
				publicName: "autoSizeBoundary",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			autoSizePadding: {
				classPropertyName: "autoSizePadding",
				publicName: "autoSizePadding",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			sync: {
				classPropertyName: "sync",
				publicName: "sync",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			maxWidth: {
				classPropertyName: "maxWidth",
				publicName: "maxWidth",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			width: {
				classPropertyName: "width",
				publicName: "width",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			maxHeight: {
				classPropertyName: "maxHeight",
				publicName: "maxHeight",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			height: {
				classPropertyName: "height",
				publicName: "height",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isFullScreen: {
				classPropertyName: "isFullScreen",
				publicName: "isFullScreen",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			enter: {
				classPropertyName: "enter",
				publicName: "enter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			exit: {
				classPropertyName: "exit",
				publicName: "exit",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			elevation: {
				classPropertyName: "elevation",
				publicName: "elevation",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			repositioned: "repositioned",
			activeChanged: "activeChanged",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
FloatingComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-floating", FloatingElement),
	inputs: [
		"anchor",
		"active",
		"placement",
		"strategy",
		"distance",
		"skidding",
		"arrow",
		"arrowPlacement",
		"arrowPadding",
		"flip",
		"flipFallbackPlacements",
		"flipBoundary",
		"flipPadding",
		"flipFallbackStrategy",
		"shift",
		"shiftCrossAxis",
		"shiftBoundary",
		"shiftPadding",
		"autoSize",
		"autoSizeBoundary",
		"autoSizePadding",
		"sync",
		"maxWidth",
		"width",
		"maxHeight",
		"height",
		"isFullScreen",
		"themeName",
		"enter",
		"exit",
		"elevation",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], FloatingComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FloatingComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-floating",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		anchor: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "anchor",
				required: false
			}]
		}],
		active: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "active",
				required: false
			}]
		}],
		placement: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "placement",
				required: false
			}]
		}],
		strategy: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "strategy",
				required: false
			}]
		}],
		distance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "distance",
				required: false
			}]
		}],
		skidding: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "skidding",
				required: false
			}]
		}],
		arrow: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "arrow",
				required: false
			}]
		}],
		arrowPlacement: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "arrowPlacement",
				required: false
			}]
		}],
		arrowPadding: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "arrowPadding",
				required: false
			}]
		}],
		flip: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "flip",
				required: false
			}]
		}],
		flipFallbackPlacements: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "flipFallbackPlacements",
				required: false
			}]
		}],
		flipBoundary: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "flipBoundary",
				required: false
			}]
		}],
		flipPadding: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "flipPadding",
				required: false
			}]
		}],
		flipFallbackStrategy: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "flipFallbackStrategy",
				required: false
			}]
		}],
		shift: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "shift",
				required: false
			}]
		}],
		shiftCrossAxis: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "shiftCrossAxis",
				required: false
			}]
		}],
		shiftBoundary: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "shiftBoundary",
				required: false
			}]
		}],
		shiftPadding: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "shiftPadding",
				required: false
			}]
		}],
		autoSize: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "autoSize",
				required: false
			}]
		}],
		autoSizeBoundary: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "autoSizeBoundary",
				required: false
			}]
		}],
		autoSizePadding: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "autoSizePadding",
				required: false
			}]
		}],
		sync: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "sync",
				required: false
			}]
		}],
		maxWidth: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maxWidth",
				required: false
			}]
		}],
		width: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "width",
				required: false
			}]
		}],
		maxHeight: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maxHeight",
				required: false
			}]
		}],
		height: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "height",
				required: false
			}]
		}],
		isFullScreen: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isFullScreen",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		enter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "enter",
				required: false
			}]
		}],
		exit: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "exit",
				required: false
			}]
		}],
		elevation: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "elevation",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		repositioned: [{
			type: i0.Output,
			args: ["repositioned"]
		}],
		activeChanged: [{
			type: i0.Output,
			args: ["activeChanged"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideFloatingComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: FLOATING_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { FLOATING_DEFAULT_PROPS, FLOATING_TRIGGER_DEFAULT_PROPS, FloatingComponent, FloatingTriggerComponent, provideFloatingComponent, provideFloatingTriggerComponent };

//# sourceMappingURL=mosaik-elements-angular-components-floating.mjs.map