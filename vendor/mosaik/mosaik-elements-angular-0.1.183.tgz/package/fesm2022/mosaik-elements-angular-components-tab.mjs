import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { TabItemElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/tab/TabItemElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { TabPanelElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/tab/TabPanelElement";
import { TabElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/tab/TabElement";
var __decorate$2 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$2 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const TAB_ITEM_DEFAULT_PROPS = new InjectionToken("MOSAIK_TAB_ITEM_DEFAULT_PROPS");
let TabItemComponent = class TabItemComponent {
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	enter = input(...ngDevMode ? [void 0, { debugName: "enter" }] : /* istanbul ignore next */ []);
	exit = input(...ngDevMode ? [void 0, { debugName: "exit" }] : /* istanbul ignore next */ []);
	orientation = input(...ngDevMode ? [void 0, { debugName: "orientation" }] : /* istanbul ignore next */ []);
	closeable = input(...ngDevMode ? [void 0, { debugName: "closeable" }] : /* istanbul ignore next */ []);
	isSelected = input(...ngDevMode ? [void 0, { debugName: "isSelected" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	label = input(...ngDevMode ? [void 0, { debugName: "label" }] : /* istanbul ignore next */ []);
	icon = input(...ngDevMode ? [void 0, { debugName: "icon" }] : /* istanbul ignore next */ []);
	iconPosition = input(...ngDevMode ? [void 0, { debugName: "iconPosition" }] : /* istanbul ignore next */ []);
	iconSize = input(...ngDevMode ? [void 0, { debugName: "iconSize" }] : /* istanbul ignore next */ []);
	value = input(...ngDevMode ? [void 0, { debugName: "value" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	selected = output();
	deselected = output();
	closed = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			selected: this.selected,
			deselected: this.deselected,
			closed: this.closed,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(TAB_ITEM_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	play(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "play", args);
	}
	onEnterAnimation(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onEnterAnimation", args);
	}
	onExitAnimation(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onExitAnimation", args);
	}
	close(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "close", args);
	}
	select(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "select", args);
	}
	deselect(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "deselect", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const enterValue = this.enter();
			if (enterValue !== void 0) this._elementRef.nativeElement.enter = enterValue;
			const exitValue = this.exit();
			if (exitValue !== void 0) this._elementRef.nativeElement.exit = exitValue;
			const orientationValue = this.orientation();
			if (orientationValue !== void 0) this._elementRef.nativeElement.orientation = orientationValue;
			const closeableValue = this.closeable();
			if (closeableValue !== void 0) this._elementRef.nativeElement.closeable = closeableValue;
			const isSelectedValue = this.isSelected();
			if (isSelectedValue !== void 0) this._elementRef.nativeElement.isSelected = isSelectedValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const labelValue = this.label();
			if (labelValue !== void 0) this._elementRef.nativeElement.label = labelValue;
			const iconValue = this.icon();
			if (iconValue !== void 0) this._elementRef.nativeElement.icon = iconValue;
			const iconPositionValue = this.iconPosition();
			if (iconPositionValue !== void 0) this._elementRef.nativeElement.iconPosition = iconPositionValue;
			const iconSizeValue = this.iconSize();
			if (iconSizeValue !== void 0) this._elementRef.nativeElement.iconSize = iconSizeValue;
			const valueValue = this.value();
			if (valueValue !== void 0) this._elementRef.nativeElement.value = valueValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: TabItemComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: TabItemComponent,
		isStandalone: true,
		selector: "mosaik-tab-item",
		inputs: {
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			enter: {
				classPropertyName: "enter",
				publicName: "enter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			exit: {
				classPropertyName: "exit",
				publicName: "exit",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			orientation: {
				classPropertyName: "orientation",
				publicName: "orientation",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			closeable: {
				classPropertyName: "closeable",
				publicName: "closeable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isSelected: {
				classPropertyName: "isSelected",
				publicName: "isSelected",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			icon: {
				classPropertyName: "icon",
				publicName: "icon",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			iconPosition: {
				classPropertyName: "iconPosition",
				publicName: "iconPosition",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			iconSize: {
				classPropertyName: "iconSize",
				publicName: "iconSize",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			selected: "selected",
			deselected: "deselected",
			closed: "closed",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
TabItemComponent = __decorate$2([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-tab-item", TabItemElement),
	inputs: [
		"themeName",
		"enter",
		"exit",
		"orientation",
		"closeable",
		"isSelected",
		"disabled",
		"label",
		"icon",
		"iconPosition",
		"iconSize",
		"value",
		"dir",
		"lang"
	]
}), __metadata$2("design:paramtypes", [])], TabItemComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: TabItemComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-tab-item",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		enter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "enter",
				required: false
			}]
		}],
		exit: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "exit",
				required: false
			}]
		}],
		orientation: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "orientation",
				required: false
			}]
		}],
		closeable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "closeable",
				required: false
			}]
		}],
		isSelected: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isSelected",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		icon: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "icon",
				required: false
			}]
		}],
		iconPosition: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "iconPosition",
				required: false
			}]
		}],
		iconSize: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "iconSize",
				required: false
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		selected: [{
			type: i0.Output,
			args: ["selected"]
		}],
		deselected: [{
			type: i0.Output,
			args: ["deselected"]
		}],
		closed: [{
			type: i0.Output,
			args: ["closed"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideTabItemComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: TAB_ITEM_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$1 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$1 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const TAB_PANEL_DEFAULT_PROPS = new InjectionToken("MOSAIK_TAB_PANEL_DEFAULT_PROPS");
let TabPanelComponent = class TabPanelComponent {
	alignment = input(...ngDevMode ? [void 0, { debugName: "alignment" }] : /* istanbul ignore next */ []);
	placement = input(...ngDevMode ? [void 0, { debugName: "placement" }] : /* istanbul ignore next */ []);
	hasIndicator = input(...ngDevMode ? [void 0, { debugName: "hasIndicator" }] : /* istanbul ignore next */ []);
	enableGestures = input(...ngDevMode ? [void 0, { debugName: "enableGestures" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	appearance = input(...ngDevMode ? [void 0, { debugName: "appearance" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	changed = output();
	disconnected = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			changed: this.changed,
			disconnected: this.disconnected
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(TAB_PANEL_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	assignToSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "assignToSlot", args);
	}
	getSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getSlotContent", args);
	}
	hasSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlotContent", args);
	}
	hasSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlot", args);
	}
	onSlotChanges(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onSlotChanges", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const alignmentValue = this.alignment();
			if (alignmentValue !== void 0) this._elementRef.nativeElement.alignment = alignmentValue;
			const placementValue = this.placement();
			if (placementValue !== void 0) this._elementRef.nativeElement.placement = placementValue;
			const hasIndicatorValue = this.hasIndicator();
			if (hasIndicatorValue !== void 0) this._elementRef.nativeElement.hasIndicator = hasIndicatorValue;
			const enableGesturesValue = this.enableGestures();
			if (enableGesturesValue !== void 0) this._elementRef.nativeElement.enableGestures = enableGesturesValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const appearanceValue = this.appearance();
			if (appearanceValue !== void 0) this._elementRef.nativeElement.appearance = appearanceValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: TabPanelComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: TabPanelComponent,
		isStandalone: true,
		selector: "mosaik-tab-panel",
		inputs: {
			alignment: {
				classPropertyName: "alignment",
				publicName: "alignment",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			placement: {
				classPropertyName: "placement",
				publicName: "placement",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			hasIndicator: {
				classPropertyName: "hasIndicator",
				publicName: "hasIndicator",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			enableGestures: {
				classPropertyName: "enableGestures",
				publicName: "enableGestures",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			changed: "changed",
			disconnected: "disconnected"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
TabPanelComponent = __decorate$1([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-tab-panel", TabPanelElement),
	inputs: [
		"alignment",
		"placement",
		"hasIndicator",
		"enableGestures",
		"themeName",
		"appearance",
		"dir",
		"lang"
	],
	methods: ["getSlotAssignments", "getSlotAssignmentsOf"]
}), __metadata$1("design:paramtypes", [])], TabPanelComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: TabPanelComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-tab-panel",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		alignment: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "alignment",
				required: false
			}]
		}],
		placement: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "placement",
				required: false
			}]
		}],
		hasIndicator: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hasIndicator",
				required: false
			}]
		}],
		enableGestures: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "enableGestures",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}]
	}
});
function provideTabPanelComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: TAB_PANEL_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const TAB_DEFAULT_PROPS = new InjectionToken("MOSAIK_TAB_DEFAULT_PROPS");
let TabComponent = class TabComponent {
	alignment = input(...ngDevMode ? [void 0, { debugName: "alignment" }] : /* istanbul ignore next */ []);
	placement = input(...ngDevMode ? [void 0, { debugName: "placement" }] : /* istanbul ignore next */ []);
	hasIndicator = input(...ngDevMode ? [void 0, { debugName: "hasIndicator" }] : /* istanbul ignore next */ []);
	enableGestures = input(...ngDevMode ? [void 0, { debugName: "enableGestures" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	appearance = input(...ngDevMode ? [void 0, { debugName: "appearance" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	changed = output();
	disconnected = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			changed: this.changed,
			disconnected: this.disconnected
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(TAB_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	select(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "select", args);
	}
	selectByIndex(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "selectByIndex", args);
	}
	selectByValue(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "selectByValue", args);
	}
	assignToSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "assignToSlot", args);
	}
	getSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getSlotContent", args);
	}
	hasSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlotContent", args);
	}
	hasSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlot", args);
	}
	onSlotChanges(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onSlotChanges", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const alignmentValue = this.alignment();
			if (alignmentValue !== void 0) this._elementRef.nativeElement.alignment = alignmentValue;
			const placementValue = this.placement();
			if (placementValue !== void 0) this._elementRef.nativeElement.placement = placementValue;
			const hasIndicatorValue = this.hasIndicator();
			if (hasIndicatorValue !== void 0) this._elementRef.nativeElement.hasIndicator = hasIndicatorValue;
			const enableGesturesValue = this.enableGestures();
			if (enableGesturesValue !== void 0) this._elementRef.nativeElement.enableGestures = enableGesturesValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const appearanceValue = this.appearance();
			if (appearanceValue !== void 0) this._elementRef.nativeElement.appearance = appearanceValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: TabComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: TabComponent,
		isStandalone: true,
		selector: "mosaik-tab",
		inputs: {
			alignment: {
				classPropertyName: "alignment",
				publicName: "alignment",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			placement: {
				classPropertyName: "placement",
				publicName: "placement",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			hasIndicator: {
				classPropertyName: "hasIndicator",
				publicName: "hasIndicator",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			enableGestures: {
				classPropertyName: "enableGestures",
				publicName: "enableGestures",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			changed: "changed",
			disconnected: "disconnected"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
TabComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-tab", TabElement),
	inputs: [
		"alignment",
		"placement",
		"hasIndicator",
		"enableGestures",
		"themeName",
		"disabled",
		"variant",
		"appearance",
		"dir",
		"lang"
	],
	methods: ["getSlotAssignments", "getSlotAssignmentsOf"]
}), __metadata("design:paramtypes", [])], TabComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: TabComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-tab",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		alignment: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "alignment",
				required: false
			}]
		}],
		placement: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "placement",
				required: false
			}]
		}],
		hasIndicator: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hasIndicator",
				required: false
			}]
		}],
		enableGestures: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "enableGestures",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}]
	}
});
function provideTabComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: TAB_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { TAB_DEFAULT_PROPS, TAB_ITEM_DEFAULT_PROPS, TAB_PANEL_DEFAULT_PROPS, TabComponent, TabItemComponent, TabPanelComponent, provideTabComponent, provideTabItemComponent, provideTabPanelComponent };

//# sourceMappingURL=mosaik-elements-angular-components-tab.mjs.map