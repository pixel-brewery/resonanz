import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { ImageElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/image/ImageElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const IMAGE_DEFAULT_PROPS = new InjectionToken("MOSAIK_IMAGE_DEFAULT_PROPS");
let ImageComponent = class ImageComponent {
	alt = input(...ngDevMode ? [void 0, { debugName: "alt" }] : /* istanbul ignore next */ []);
	src = input(...ngDevMode ? [void 0, { debugName: "src" }] : /* istanbul ignore next */ []);
	srcset = input(...ngDevMode ? [void 0, { debugName: "srcset" }] : /* istanbul ignore next */ []);
	fit = input(...ngDevMode ? [void 0, { debugName: "fit" }] : /* istanbul ignore next */ []);
	thumbnailSrc = input(...ngDevMode ? [void 0, { debugName: "thumbnailSrc" }] : /* istanbul ignore next */ []);
	hoverZoom = input(...ngDevMode ? [void 0, { debugName: "hoverZoom" }] : /* istanbul ignore next */ []);
	showFailed = input(...ngDevMode ? [void 0, { debugName: "showFailed" }] : /* istanbul ignore next */ []);
	showEmpty = input(...ngDevMode ? [void 0, { debugName: "showEmpty" }] : /* istanbul ignore next */ []);
	showPending = input(...ngDevMode ? [void 0, { debugName: "showPending" }] : /* istanbul ignore next */ []);
	legend = input(...ngDevMode ? [void 0, { debugName: "legend" }] : /* istanbul ignore next */ []);
	legendPosition = input(...ngDevMode ? [void 0, { debugName: "legendPosition" }] : /* istanbul ignore next */ []);
	ratio = input(...ngDevMode ? [void 0, { debugName: "ratio" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	width = input(...ngDevMode ? [void 0, { debugName: "width" }] : /* istanbul ignore next */ []);
	height = input(...ngDevMode ? [void 0, { debugName: "height" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	imageLoaded = output();
	imageFailed = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			imageLoaded: this.imageLoaded,
			imageFailed: this.imageFailed,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(IMAGE_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const altValue = this.alt();
			if (altValue !== void 0) this._elementRef.nativeElement.alt = altValue;
			const srcValue = this.src();
			if (srcValue !== void 0) this._elementRef.nativeElement.src = srcValue;
			const srcsetValue = this.srcset();
			if (srcsetValue !== void 0) this._elementRef.nativeElement.srcset = srcsetValue;
			const fitValue = this.fit();
			if (fitValue !== void 0) this._elementRef.nativeElement.fit = fitValue;
			const thumbnailSrcValue = this.thumbnailSrc();
			if (thumbnailSrcValue !== void 0) this._elementRef.nativeElement.thumbnailSrc = thumbnailSrcValue;
			const hoverZoomValue = this.hoverZoom();
			if (hoverZoomValue !== void 0) this._elementRef.nativeElement.hoverZoom = hoverZoomValue;
			const showFailedValue = this.showFailed();
			if (showFailedValue !== void 0) this._elementRef.nativeElement.showFailed = showFailedValue;
			const showEmptyValue = this.showEmpty();
			if (showEmptyValue !== void 0) this._elementRef.nativeElement.showEmpty = showEmptyValue;
			const showPendingValue = this.showPending();
			if (showPendingValue !== void 0) this._elementRef.nativeElement.showPending = showPendingValue;
			const legendValue = this.legend();
			if (legendValue !== void 0) this._elementRef.nativeElement.legend = legendValue;
			const legendPositionValue = this.legendPosition();
			if (legendPositionValue !== void 0) this._elementRef.nativeElement.legendPosition = legendPositionValue;
			const ratioValue = this.ratio();
			if (ratioValue !== void 0) this._elementRef.nativeElement.ratio = ratioValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const widthValue = this.width();
			if (widthValue !== void 0) this._elementRef.nativeElement.width = widthValue;
			const heightValue = this.height();
			if (heightValue !== void 0) this._elementRef.nativeElement.height = heightValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ImageComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: ImageComponent,
		isStandalone: true,
		selector: "mosaik-image",
		inputs: {
			alt: {
				classPropertyName: "alt",
				publicName: "alt",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			src: {
				classPropertyName: "src",
				publicName: "src",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			srcset: {
				classPropertyName: "srcset",
				publicName: "srcset",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			fit: {
				classPropertyName: "fit",
				publicName: "fit",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			thumbnailSrc: {
				classPropertyName: "thumbnailSrc",
				publicName: "thumbnailSrc",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			hoverZoom: {
				classPropertyName: "hoverZoom",
				publicName: "hoverZoom",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showFailed: {
				classPropertyName: "showFailed",
				publicName: "showFailed",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showEmpty: {
				classPropertyName: "showEmpty",
				publicName: "showEmpty",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showPending: {
				classPropertyName: "showPending",
				publicName: "showPending",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			legend: {
				classPropertyName: "legend",
				publicName: "legend",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			legendPosition: {
				classPropertyName: "legendPosition",
				publicName: "legendPosition",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			ratio: {
				classPropertyName: "ratio",
				publicName: "ratio",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			width: {
				classPropertyName: "width",
				publicName: "width",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			height: {
				classPropertyName: "height",
				publicName: "height",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			imageLoaded: "imageLoaded",
			imageFailed: "imageFailed",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
ImageComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-image", ImageElement),
	inputs: [
		"alt",
		"src",
		"srcset",
		"fit",
		"thumbnailSrc",
		"hoverZoom",
		"showFailed",
		"showEmpty",
		"showPending",
		"legend",
		"legendPosition",
		"ratio",
		"themeName",
		"disabled",
		"variant",
		"width",
		"height",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], ImageComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ImageComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-image",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		alt: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "alt",
				required: false
			}]
		}],
		src: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "src",
				required: false
			}]
		}],
		srcset: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "srcset",
				required: false
			}]
		}],
		fit: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "fit",
				required: false
			}]
		}],
		thumbnailSrc: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "thumbnailSrc",
				required: false
			}]
		}],
		hoverZoom: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hoverZoom",
				required: false
			}]
		}],
		showFailed: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showFailed",
				required: false
			}]
		}],
		showEmpty: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showEmpty",
				required: false
			}]
		}],
		showPending: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showPending",
				required: false
			}]
		}],
		legend: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "legend",
				required: false
			}]
		}],
		legendPosition: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "legendPosition",
				required: false
			}]
		}],
		ratio: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "ratio",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		width: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "width",
				required: false
			}]
		}],
		height: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "height",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		imageLoaded: [{
			type: i0.Output,
			args: ["imageLoaded"]
		}],
		imageFailed: [{
			type: i0.Output,
			args: ["imageFailed"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideImageComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: IMAGE_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { IMAGE_DEFAULT_PROPS, ImageComponent, provideImageComponent };

//# sourceMappingURL=mosaik-elements-angular-components-image.mjs.map