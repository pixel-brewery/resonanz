import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { BeamElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/illustrations/beam/BeamElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const BEAM_DEFAULT_PROPS = new InjectionToken("MOSAIK_BEAM_DEFAULT_PROPS");
let BeamComponent = class BeamComponent {
	source = input(...ngDevMode ? [void 0, { debugName: "source" }] : /* istanbul ignore next */ []);
	target = input(...ngDevMode ? [void 0, { debugName: "target" }] : /* istanbul ignore next */ []);
	mode = input(...ngDevMode ? [void 0, { debugName: "mode" }] : /* istanbul ignore next */ []);
	routing = input(...ngDevMode ? [void 0, { debugName: "routing" }] : /* istanbul ignore next */ []);
	sourceSide = input(...ngDevMode ? [void 0, { debugName: "sourceSide" }] : /* istanbul ignore next */ []);
	targetSide = input(...ngDevMode ? [void 0, { debugName: "targetSide" }] : /* istanbul ignore next */ []);
	offset = input(...ngDevMode ? [void 0, { debugName: "offset" }] : /* istanbul ignore next */ []);
	cornerRadius = input(...ngDevMode ? [void 0, { debugName: "cornerRadius" }] : /* istanbul ignore next */ []);
	duration = input(...ngDevMode ? [void 0, { debugName: "duration" }] : /* istanbul ignore next */ []);
	delay = input(...ngDevMode ? [void 0, { debugName: "delay" }] : /* istanbul ignore next */ []);
	reverse = input(...ngDevMode ? [void 0, { debugName: "reverse" }] : /* istanbul ignore next */ []);
	travel = input(...ngDevMode ? [void 0, { debugName: "travel" }] : /* istanbul ignore next */ []);
	step = input(...ngDevMode ? [void 0, { debugName: "step" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(BEAM_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	refresh(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "refresh", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const sourceValue = this.source();
			if (sourceValue !== void 0) this._elementRef.nativeElement.source = sourceValue;
			const targetValue = this.target();
			if (targetValue !== void 0) this._elementRef.nativeElement.target = targetValue;
			const modeValue = this.mode();
			if (modeValue !== void 0) this._elementRef.nativeElement.mode = modeValue;
			const routingValue = this.routing();
			if (routingValue !== void 0) this._elementRef.nativeElement.routing = routingValue;
			const sourceSideValue = this.sourceSide();
			if (sourceSideValue !== void 0) this._elementRef.nativeElement.sourceSide = sourceSideValue;
			const targetSideValue = this.targetSide();
			if (targetSideValue !== void 0) this._elementRef.nativeElement.targetSide = targetSideValue;
			const offsetValue = this.offset();
			if (offsetValue !== void 0) this._elementRef.nativeElement.offset = offsetValue;
			const cornerRadiusValue = this.cornerRadius();
			if (cornerRadiusValue !== void 0) this._elementRef.nativeElement.cornerRadius = cornerRadiusValue;
			const durationValue = this.duration();
			if (durationValue !== void 0) this._elementRef.nativeElement.duration = durationValue;
			const delayValue = this.delay();
			if (delayValue !== void 0) this._elementRef.nativeElement.delay = delayValue;
			const reverseValue = this.reverse();
			if (reverseValue !== void 0) this._elementRef.nativeElement.reverse = reverseValue;
			const travelValue = this.travel();
			if (travelValue !== void 0) this._elementRef.nativeElement.travel = travelValue;
			const stepValue = this.step();
			if (stepValue !== void 0) this._elementRef.nativeElement.step = stepValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: BeamComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: BeamComponent,
		isStandalone: true,
		selector: "mosaik-beam",
		inputs: {
			source: {
				classPropertyName: "source",
				publicName: "source",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			target: {
				classPropertyName: "target",
				publicName: "target",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			mode: {
				classPropertyName: "mode",
				publicName: "mode",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			routing: {
				classPropertyName: "routing",
				publicName: "routing",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			sourceSide: {
				classPropertyName: "sourceSide",
				publicName: "sourceSide",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			targetSide: {
				classPropertyName: "targetSide",
				publicName: "targetSide",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			offset: {
				classPropertyName: "offset",
				publicName: "offset",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			cornerRadius: {
				classPropertyName: "cornerRadius",
				publicName: "cornerRadius",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			duration: {
				classPropertyName: "duration",
				publicName: "duration",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			delay: {
				classPropertyName: "delay",
				publicName: "delay",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			reverse: {
				classPropertyName: "reverse",
				publicName: "reverse",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			travel: {
				classPropertyName: "travel",
				publicName: "travel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			step: {
				classPropertyName: "step",
				publicName: "step",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
BeamComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-beam", BeamElement),
	inputs: [
		"source",
		"target",
		"mode",
		"routing",
		"sourceSide",
		"targetSide",
		"offset",
		"cornerRadius",
		"duration",
		"delay",
		"reverse",
		"travel",
		"step",
		"themeName",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], BeamComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: BeamComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-beam",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		source: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "source",
				required: false
			}]
		}],
		target: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "target",
				required: false
			}]
		}],
		mode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mode",
				required: false
			}]
		}],
		routing: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "routing",
				required: false
			}]
		}],
		sourceSide: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "sourceSide",
				required: false
			}]
		}],
		targetSide: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "targetSide",
				required: false
			}]
		}],
		offset: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "offset",
				required: false
			}]
		}],
		cornerRadius: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "cornerRadius",
				required: false
			}]
		}],
		duration: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "duration",
				required: false
			}]
		}],
		delay: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "delay",
				required: false
			}]
		}],
		reverse: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "reverse",
				required: false
			}]
		}],
		travel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "travel",
				required: false
			}]
		}],
		step: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "step",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideBeamComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: BEAM_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { BEAM_DEFAULT_PROPS, BeamComponent, provideBeamComponent };

//# sourceMappingURL=mosaik-elements-angular-components-beam.mjs.map