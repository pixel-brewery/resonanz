import * as i0 from "@angular/core";
import { DestroyRef, Directive, ElementRef, InjectionToken, computed, effect, forwardRef, inject, input, untracked } from "@angular/core";
import { FORM_FIELD } from "@angular/forms/signals";
import { takeUntilDestroyed } from "@angular/core/rxjs-interop";
import { NgControl, TouchedChangeEvent } from "@angular/forms";
import { filter } from "rxjs";
import { on } from "@pixel-brewery/mosaik-elements";
const FORM_STATUS_HOST = new InjectionToken("MOSAIK_FORM_STATUS_HOST");
var FormStatusHostDirective = class FormStatusHostDirective {
	_host;
	_ngControl;
	_destroyRef;
	constructor() {
		this._host = inject(FORM_STATUS_HOST);
		this._destroyRef = inject(DestroyRef);
		this._ngControl = inject(NgControl, { optional: true });
	}
	ngOnInit() {
		if (this._ngControl?.statusChanges) {
			this._ngControl.valueAccessor = this._host;
			this._ngControl.control?.events.pipe(takeUntilDestroyed(this._destroyRef), filter((x) => x instanceof TouchedChangeEvent && x.touched)).subscribe(() => this.invalidate());
			this._ngControl.statusChanges.pipe(takeUntilDestroyed(this._destroyRef)).subscribe(() => this.invalidate());
		}
	}
	invalidate() {
		const invalid = !!(this._ngControl?.invalid && this._ngControl.touched);
		if (this._host.setInput) this._host.setInput("invalid", invalid);
		else if ("invalid" in this._host && typeof this._host.invalid !== "function") this._host.invalid = invalid;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FormStatusHostDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: FormStatusHostDirective,
		isStandalone: true,
		selector: ".ng-invalid, .ng-dirty, .ng-touched",
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FormStatusHostDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: ".ng-invalid, .ng-dirty, .ng-touched" }]
	}],
	ctorParameters: () => []
});
var FormFieldDirective = class FormFieldDirective {
	_hostComponent;
	_isWritingValue = false;
	constructor() {
		this._hostComponent = inject(FORM_STATUS_HOST, { optional: true });
		effect(() => {
			const fieldFn = this.formField();
			if (!fieldFn || !this._hostComponent) return;
			const value = fieldFn().value();
			if (!this._isWritingValue) this._hostComponent.writeValue(value);
		});
		if (this._hostComponent) {
			this._hostComponent.registerOnChange((value) => {
				const fieldFn = untracked(() => this.formField());
				if (fieldFn) {
					this._isWritingValue = true;
					try {
						const fieldState = fieldFn();
						fieldState.value.set(value);
						fieldState.markAsDirty();
					} finally {
						this._isWritingValue = false;
					}
				}
			});
			this._hostComponent.registerOnTouched(() => {
				const fieldFn = untracked(() => this.formField());
				if (fieldFn) fieldFn().markAsTouched();
			});
		}
	}
	formField = input.required(...ngDevMode ? [{ debugName: "formField" }] : /* istanbul ignore next */ []);
	state = computed(() => {
		const fieldFn = this.formField();
		return fieldFn ? fieldFn() : null;
	}, ...ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FormFieldDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: FormFieldDirective,
		isStandalone: true,
		selector: "[formField]",
		inputs: { formField: {
			classPropertyName: "formField",
			publicName: "formField",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		providers: [{
			provide: FORM_FIELD,
			useExisting: forwardRef(() => FormFieldDirective)
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FormFieldDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[formField]",
			standalone: true,
			providers: [{
				provide: FORM_FIELD,
				useExisting: forwardRef(() => FormFieldDirective)
			}]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { formField: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "formField",
			required: true
		}]
	}] }
});
var FormFieldStatusHostDirective = class FormFieldStatusHostDirective {
	_host;
	_field;
	constructor() {
		this._host = inject(ElementRef).nativeElement;
		this._field = inject(FORM_FIELD, { optional: true });
		effect(() => {
			const field = untracked(() => this._field);
			if (!field) return;
			const state = field.state();
			if (!state) return;
			const isInvalid = state.invalid() && state.touched();
			if ("invalid" in this._host) this._host.invalid = isInvalid;
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FormFieldStatusHostDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: FormFieldStatusHostDirective,
		isStandalone: true,
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FormFieldStatusHostDirective,
	decorators: [{
		type: Directive,
		args: [{ standalone: true }]
	}],
	ctorParameters: () => []
});
var PortalProjectionDirective = class PortalProjectionDirective {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: PortalProjectionDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: PortalProjectionDirective,
		isStandalone: true,
		selector: "[mosaikPortalProjection]",
		host: {
			attributes: { "data-mosaik-portal-projection-root": "" },
			styleAttribute: "display: contents"
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: PortalProjectionDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[mosaikPortalProjection]",
			host: {
				"data-mosaik-portal-projection-root": "",
				"style": "display: contents"
			}
		}]
	}]
});
const blockedProxyMethods = /* @__PURE__ */ new Set([
	"addController",
	"removeController",
	"addEventListener",
	"removeEventListener",
	"dispatchEvent",
	"connectedCallback",
	"disconnectedCallback",
	"attributeChangedCallback",
	"createRenderRoot",
	"performUpdate",
	"scheduleUpdate",
	"shouldUpdate",
	"willUpdate",
	"update",
	"updated",
	"firstUpdated",
	"render",
	"adoptStyle",
	"on",
	"off",
	"emit",
	"requestUpdate"
]);
function isProxyMethodAllowed(methodName) {
	return methodName !== "constructor" && !methodName.startsWith("_") && !methodName.endsWith("Callback") && !blockedProxyMethods.has(methodName);
}
function resolveProxyElement(target) {
	if (target === void 0) return;
	const host = target;
	if (host.elementRef?.nativeElement !== void 0) return host.elementRef.nativeElement;
	if (host._elementRef?.nativeElement !== void 0) return host._elementRef.nativeElement;
	if (host.element !== void 0) return host.element;
	const elementRef = target;
	if (elementRef.nativeElement !== void 0) return elementRef.nativeElement;
	return target;
}
function readProxyProperty(target, propertyName) {
	return resolveProxyElement(target)?.[propertyName];
}
const proxyMethods = (cmp, methods) => {
	const prototype = cmp.prototype;
	methods.forEach((methodName) => {
		if (!isProxyMethodAllowed(methodName)) return;
		try {
			prototype[methodName] = function(...args) {
				return invokeProxyMethod(this, methodName, ...args);
			};
		} catch (_e) {}
	});
};
function invokeProxyMethod(target, methodName, ...args) {
	if (!isProxyMethodAllowed(methodName)) throw new Error(`The method '${methodName}' is an internal custom-element lifecycle method and cannot be invoked through the Angular proxy.`);
	const element = resolveProxyElement(target);
	const method = element?.[methodName];
	if (typeof method !== "function" || element === void 0) return;
	const invoke = () => Reflect.apply(method, element, args);
	const zone = target.zone;
	return zone !== void 0 ? zone.runOutsideAngular(invoke) : invoke();
}
function invokeElementMethod(element, methodName, args) {
	return invokeProxyMethod(element, methodName, ...args);
}
const defineCustomElement = (tagName, customElement) => {
	if (customElement !== void 0 && typeof customElements !== "undefined" && !customElements.get(tagName)) customElements.define(tagName, customElement);
};
const ANGULAR_UNWRAP_TOKEN = "__ngUnwrap__";
function unwrapAngularBindingListener(listener, target) {
	if (typeof listener !== "function" || !Function.prototype.toString.call(listener).includes("__ngUnwrap__")) return null;
	const binding = listener(ANGULAR_UNWRAP_TOKEN);
	return typeof binding === "function" && binding["__ngNativeEl__"] === target ? binding : null;
}
function trackOutputSubscribers(output) {
	const subscribers = /* @__PURE__ */ new Set();
	const subscribe = output.subscribe.bind(output);
	output.subscribe = (callback) => {
		subscribers.add(callback);
		const subscription = subscribe(callback);
		return { unsubscribe: () => {
			subscribers.delete(callback);
			subscription.unsubscribe();
		} };
	};
	return subscribers;
}
function forwardProxyOutputs(target, outputs) {
	const subscribers = /* @__PURE__ */ new Map();
	const forwarded = /* @__PURE__ */ new WeakSet();
	const subscriptions = Object.entries(outputs).map(([eventName, output]) => {
		subscribers.set(eventName, trackOutputSubscribers(output));
		return on(target, eventName, (event) => {
			if (event instanceof CustomEvent && event.composedPath()[0] === target) {
				forwarded.add(event);
				output.emit(event.detail);
			}
		});
	});
	const guarded = /* @__PURE__ */ new WeakMap();
	const addEventListener = target.addEventListener;
	const removeEventListener = target.removeEventListener;
	target.addEventListener = function(type, listener, options) {
		const outputSubscribers = subscribers.get(type);
		const binding = outputSubscribers ? unwrapAngularBindingListener(listener, target) : null;
		if (listener && outputSubscribers && binding) {
			const guard = (event) => {
				if (!(forwarded.has(event) && outputSubscribers.has(binding))) listener(event);
			};
			guarded.set(listener, guard);
			addEventListener.call(this, type, guard, options);
			return;
		}
		addEventListener.call(this, type, listener, options);
	};
	target.removeEventListener = function(type, listener, options) {
		removeEventListener.call(this, type, (listener && guarded.get(listener)) ?? listener, options);
	};
	return subscriptions;
}
function ProxyCmp(opts) {
	const decorator = function(cls) {
		const inputs = opts.inputs;
		const methods = opts.methods;
		if (opts.defineCustomElementFn !== void 0) opts.defineCustomElementFn();
		if (inputs) {}
		if (methods) proxyMethods(cls, methods);
	};
	return decorator;
}
function applyDefaults(target, defaults, mergeKeys) {
	Object.keys(defaults).forEach((p) => {
		if (p in target) {
			const key = p;
			if (mergeKeys?.includes(p) && typeof target[key] === "object" && target[key] !== null) Object.assign(target[key], defaults[key]);
			else target[p] = defaults[p];
		}
	});
}
export { FORM_STATUS_HOST, FormFieldDirective, FormFieldStatusHostDirective, FormStatusHostDirective, PortalProjectionDirective, ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod, readProxyProperty };

//# sourceMappingURL=mosaik-elements-angular-runtime.mjs.map