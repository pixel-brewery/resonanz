import { ButtonComponent } from "@pixel-brewery/mosaik-elements-angular/components/button";
import { ComboItemComponent } from "@pixel-brewery/mosaik-elements-angular/components/combo";
import { DataListComponent } from "@pixel-brewery/mosaik-elements-angular/components/data-list";
import { DataTableComponent } from "@pixel-brewery/mosaik-elements-angular/components/data-table";
import { DialogActionsComponent, DialogComponent, DialogFooterComponent, DialogHeaderComponent, DialogHeaderSubTextComponent, DialogHeaderTextComponent } from "@pixel-brewery/mosaik-elements-angular/components/dialog";
import { DismissComponent } from "@pixel-brewery/mosaik-elements-angular/components/dismiss";
import { DrawerActionsComponent, DrawerComponent, DrawerContentComponent, DrawerFooterComponent, DrawerHeaderComponent, DrawerHeaderSubTextComponent, DrawerHeaderTextComponent, DrawerRailComponent } from "@pixel-brewery/mosaik-elements-angular/components/drawer";
import { ExpandableComponent } from "@pixel-brewery/mosaik-elements-angular/components/expandable";
import { FlipComponent } from "@pixel-brewery/mosaik-elements-angular/components/flip";
import { MessageBoxComponent } from "@pixel-brewery/mosaik-elements-angular/components/message-box";
import { ProgressRingComponent } from "@pixel-brewery/mosaik-elements-angular/components/progress-ring";
import * as i1 from "@pixel-brewery/mosaik-elements-angular/components/scheduler";
import { SchedulerEventComponent } from "@pixel-brewery/mosaik-elements-angular/components/scheduler";
import { SelectItemComponent } from "@pixel-brewery/mosaik-elements-angular/components/select";
import { SheetComponent, SheetContentComponent, SheetFooterComponent, SheetHeaderComponent, SheetHeaderSubTextComponent, SheetHeaderTextComponent } from "@pixel-brewery/mosaik-elements-angular/components/sheet";
import { StepperComponent } from "@pixel-brewery/mosaik-elements-angular/components/stepper";
import { ToastActionsComponent, ToastComponent } from "@pixel-brewery/mosaik-elements-angular/components/toast";
import { TOUR_DEFAULT_PROPS } from "@pixel-brewery/mosaik-elements-angular/components/tour";
import { WizardComponent } from "@pixel-brewery/mosaik-elements-angular/components/wizard";
import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, ContentChild, ContentChildren, DEFAULT_CURRENCY_CODE, DOCUMENT, DestroyRef, Directive, ElementRef, HostBinding, HostListener, Inject, Injectable, InjectionToken, Injector, Input, LOCALE_ID, Optional, Pipe, Renderer2, SkipSelf, TemplateRef, ViewChild, ViewContainerRef, ViewEncapsulation, afterNextRender, afterRenderEffect, booleanAttribute, computed, effect, forwardRef, inject, input, isDevMode, makeEnvironmentProviders, numberAttribute, provideAppInitializer, provideEnvironmentInitializer, runInInjectionContext, signal } from "@angular/core";
import * as i2 from "@pixel-brewery/mosaik-elements-foundation/dist/animations/AnimationPlayer";
import { AnimationPlayer } from "@pixel-brewery/mosaik-elements-foundation/dist/animations/AnimationPlayer";
import { Animation } from "@pixel-brewery/mosaik-elements-foundation/dist/animations/presets/AnimationPresets";
import { BreakpointObserver } from "@angular/cdk/layout";
import { BehaviorSubject, EMPTY, Observable, Subject, Subscription, filter, fromEvent, isObservable, map, merge, of, share, takeUntil, timer } from "rxjs";
import { BREAKPOINTS } from "@pixel-brewery/mosaik-elements-foundation/dist/layout/breakpoint/Breakpoints";
import { PerspectiveElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/effects/perspective/PerspectiveElement";
import { RippleElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/effects/ripple/RippleElement";
import { ScaleElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/effects/scale/ScaleElement";
import { CssLength, ThemeGenerator, ThemeGeneratorServiceLocator, ThemeObserver, ThemeObserverServiceLocator } from "@pixel-brewery/mosaik-themes";
import { takeUntilDestroyed, toSignal } from "@angular/core/rxjs-interop";
import { InputFormatters } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/abstracts/InputFormatterFn";
import { InputParsers } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/abstracts/InputParserFn";
import { NumberKeyboardMode } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/types/VirtualKeyboardMode";
import * as i1$1 from "@pixel-brewery/mosaik-elements-foundation/dist/translations/TranslatorService";
import { Translator, TranslatorService, TranslatorServiceLocator } from "@pixel-brewery/mosaik-elements-foundation/dist/translations/TranslatorService";
import { AbstractControl, FormArray, FormControl, FormGroup, FormGroupDirective, NG_VALUE_ACCESSOR } from "@angular/forms";
import "@pixel-brewery/mosaik-elements-foundation/dist/controls/types/Placement";
import { TooltipElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/tooltip/TooltipElement";
import "@pixel-brewery/mosaik-elements-foundation/dist/controls/types/Trigger";
import { FORM_STATUS_HOST, FormFieldDirective, FormFieldStatusHostDirective, FormStatusHostDirective, PortalProjectionDirective, ProxyCmp, applyDefaults, applyDefaults as applyDefaults$1, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod, readProxyProperty } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { ComboItemVisualElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/combo/ComboItemVisualElement";
import { SelectItemVisualElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/select/SelectItemVisualElement";
import { Size } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/types/Size";
import { Spacing } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/types/Spacing";
import { TextFormatters } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/types/TextFormatter";
import { validate } from "@angular/forms/signals";
import { IconRegistry as IconRegistry$1 } from "@pixel-brewery/mosaik-icons";
import { DIALOG_STACK_BEHAVIOR_DEFAULT_CONFIG } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/overlays/dialog/behaviors/IDialogStackBehaviorConfig";
import { BasePortalOutlet, CdkPortalOutlet, ComponentPortal, TemplatePortal } from "@angular/cdk/portal";
import { CdkScrollable } from "@angular/cdk/scrolling";
import { AsyncPipe, DOCUMENT as DOCUMENT$1, NgComponentOutlet, NgTemplateOutlet } from "@angular/common";
import { ConfigurableFocusTrapFactory } from "@angular/cdk/a11y";
import { MOSAIK_PORTAL_SCOPE_ATTRIBUTE } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/portal/MosaikPortalScopeAttribute";
import { EID } from "@pixel-brewery/mosaik-elements-foundation/dist/utilities/EId";
import { Overlay, OverlayPositionBuilder } from "@angular/cdk/overlay";
import { ClickOutsideController } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/controllers/ClickOutsideController";
import { Key } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/types/Key";
import { DRAWER_STACK_BEHAVIOR_DEFAULT_CONFIG } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/overlays/drawer/behaviors/IDrawerStackBehaviorConfig";
import { MessageBoxResult } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/types/MessageBoxResult";
import { ToastStackBehavior as ToastStackBehavior$1 } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/overlays/toast/behaviors/ToastStackBehavior";
import { LayerManager } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/portal/LayerManager";
import { TourAnchorRegistry } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/overlays/tour/TourAnchorRegistry";
import { NavigationStart, Router } from "@angular/router";
import { TOUR_DEFAULT_ENTER_ANIMATION, TOUR_DEFAULT_EXIT_ANIMATION, TourElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/overlays/tour/TourElement";
import { TourCameraBehavior } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/overlays/tour/behaviors/TourCameraBehavior";
import { DateAgoIntl } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/directives/date-ago/intl/DateAgoIntl";
import { map as map$1, startWith } from "rxjs/operators";
import { emit, filterByMemberPath, orderByMemberPath } from "@pixel-brewery/mosaik-elements";
import { TimeAgoIntl } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/directives/time-ago/intl/TimeAgoIntl";
import { ThemeService as ThemeService$1 } from "@pixel-brewery/mosaik-elements-foundation/dist/theming/ThemeService";
export * from "@pixel-brewery/mosaik-elements-angular/components/absolute";
export * from "@pixel-brewery/mosaik-elements-angular/components/actionbar";
export * from "@pixel-brewery/mosaik-elements-angular/components/anchor";
export * from "@pixel-brewery/mosaik-elements-angular/components/shell";
export * from "@pixel-brewery/mosaik-elements-angular/components/chat";
export * from "@pixel-brewery/mosaik-elements-angular/components/audio";
export * from "@pixel-brewery/mosaik-elements-angular/components/auto-complete-box";
export * from "@pixel-brewery/mosaik-elements-angular/components/avatar";
export * from "@pixel-brewery/mosaik-elements-angular/components/backdrop";
export * from "@pixel-brewery/mosaik-elements-angular/components/badge";
export * from "@pixel-brewery/mosaik-elements-angular/components/banner-group";
export * from "@pixel-brewery/mosaik-elements-angular/components/banner";
export * from "@pixel-brewery/mosaik-elements-angular/components/beam";
export * from "@pixel-brewery/mosaik-elements-angular/components/box";
export * from "@pixel-brewery/mosaik-elements-angular/components/breadcrumb";
export * from "@pixel-brewery/mosaik-elements-angular/components/breakpoint-container";
export * from "@pixel-brewery/mosaik-elements-angular/components/bubbles";
export * from "@pixel-brewery/mosaik-elements-angular/components/busy";
export * from "@pixel-brewery/mosaik-elements-angular/components/button";
export * from "@pixel-brewery/mosaik-elements-angular/components/calendar";
export * from "@pixel-brewery/mosaik-elements-angular/components/camera";
export * from "@pixel-brewery/mosaik-elements-angular/components/card";
export * from "@pixel-brewery/mosaik-elements-angular/components/card-stack";
export * from "@pixel-brewery/mosaik-elements-angular/components/carousel";
export * from "@pixel-brewery/mosaik-elements-angular/components/cells";
export * from "@pixel-brewery/mosaik-elements-angular/components/check-box";
export * from "@pixel-brewery/mosaik-elements-angular/components/checkmark";
export * from "@pixel-brewery/mosaik-elements-angular/components/chip";
export * from "@pixel-brewery/mosaik-elements-angular/components/chip-box";
export * from "@pixel-brewery/mosaik-elements-angular/components/choice";
export * from "@pixel-brewery/mosaik-elements-angular/components/clickable";
export * from "@pixel-brewery/mosaik-elements-angular/components/code";
export * from "@pixel-brewery/mosaik-elements-angular/components/color-area";
export * from "@pixel-brewery/mosaik-elements-angular/components/color-editor";
export * from "@pixel-brewery/mosaik-elements-angular/components/color-picker";
export * from "@pixel-brewery/mosaik-elements-angular/components/color-slider";
export * from "@pixel-brewery/mosaik-elements-angular/components/color-swatch";
export * from "@pixel-brewery/mosaik-elements-angular/components/color-thumb";
export * from "@pixel-brewery/mosaik-elements-angular/components/color-box";
export * from "@pixel-brewery/mosaik-elements-angular/components/combo";
export * from "@pixel-brewery/mosaik-elements-angular/components/comment";
export * from "@pixel-brewery/mosaik-elements-angular/components/compound-button";
export * from "@pixel-brewery/mosaik-elements-angular/components/cookie-consent";
export * from "@pixel-brewery/mosaik-elements-angular/components/cursor-effect";
export * from "@pixel-brewery/mosaik-elements-angular/components/data-list";
export * from "@pixel-brewery/mosaik-elements-angular/components/data-table";
export * from "@pixel-brewery/mosaik-elements-angular/components/date-box";
export * from "@pixel-brewery/mosaik-elements-angular/components/date-time-box";
export * from "@pixel-brewery/mosaik-elements-angular/components/designer";
export * from "@pixel-brewery/mosaik-elements-angular/components/dialog";
export * from "@pixel-brewery/mosaik-elements-angular/components/disclosure";
export * from "@pixel-brewery/mosaik-elements-angular/components/dismiss";
export * from "@pixel-brewery/mosaik-elements-angular/components/divider";
export * from "@pixel-brewery/mosaik-elements-angular/components/dock";
export * from "@pixel-brewery/mosaik-elements-angular/components/dot";
export * from "@pixel-brewery/mosaik-elements-angular/components/drawer";
export * from "@pixel-brewery/mosaik-elements-angular/components/drop-zone";
export * from "@pixel-brewery/mosaik-elements-angular/components/dropdown";
export * from "@pixel-brewery/mosaik-elements-angular/components/drop-down-button";
export * from "@pixel-brewery/mosaik-elements-angular/components/duration-box";
export * from "@pixel-brewery/mosaik-elements-angular/components/elevation";
export * from "@pixel-brewery/mosaik-elements-angular/components/emoji";
export * from "@pixel-brewery/mosaik-elements-angular/components/empty";
export * from "@pixel-brewery/mosaik-elements-angular/components/electronic-program-guide";
export * from "@pixel-brewery/mosaik-elements-angular/components/error-state";
export * from "@pixel-brewery/mosaik-elements-angular/components/error";
export * from "@pixel-brewery/mosaik-elements-angular/components/expandable";
export * from "@pixel-brewery/mosaik-elements-angular/components/expander";
export * from "@pixel-brewery/mosaik-elements-angular/components/floating-action-button";
export * from "@pixel-brewery/mosaik-elements-angular/components/file-upload";
export * from "@pixel-brewery/mosaik-elements-angular/components/file-box";
export * from "@pixel-brewery/mosaik-elements-angular/components/flip";
export * from "@pixel-brewery/mosaik-elements-angular/components/floating";
export * from "@pixel-brewery/mosaik-elements-angular/components/flow-board";
export * from "@pixel-brewery/mosaik-elements-angular/components/focus-ring";
export * from "@pixel-brewery/mosaik-elements-angular/components/font-editor";
export * from "@pixel-brewery/mosaik-elements-angular/components/footer";
export * from "@pixel-brewery/mosaik-elements-angular/components/forms";
export * from "@pixel-brewery/mosaik-elements-angular/components/ghost";
export * from "@pixel-brewery/mosaik-elements-angular/components/globe";
export * from "@pixel-brewery/mosaik-elements-angular/components/grid";
export * from "@pixel-brewery/mosaik-elements-angular/components/helmet";
export * from "@pixel-brewery/mosaik-elements-angular/components/hint";
export * from "@pixel-brewery/mosaik-elements-angular/components/icon";
export * from "@pixel-brewery/mosaik-elements-angular/components/illustration";
export * from "@pixel-brewery/mosaik-elements-angular/components/image";
export * from "@pixel-brewery/mosaik-elements-angular/components/indicator";
export * from "@pixel-brewery/mosaik-elements-angular/components/jumbotron";
export * from "@pixel-brewery/mosaik-elements-angular/components/kbd";
export * from "@pixel-brewery/mosaik-elements-angular/components/knob";
export * from "@pixel-brewery/mosaik-elements-angular/components/light-chain";
export * from "@pixel-brewery/mosaik-elements-angular/components/list";
export * from "@pixel-brewery/mosaik-elements-angular/components/listing";
export * from "@pixel-brewery/mosaik-elements-angular/components/marquee";
export * from "@pixel-brewery/mosaik-elements-angular/components/masonry";
export * from "@pixel-brewery/mosaik-elements-angular/components/menu";
export * from "@pixel-brewery/mosaik-elements-angular/components/message-box";
export * from "@pixel-brewery/mosaik-elements-angular/components/message";
export * from "@pixel-brewery/mosaik-elements-angular/components/meter-bar";
export * from "@pixel-brewery/mosaik-elements-angular/components/meter-ring";
export * from "@pixel-brewery/mosaik-elements-angular/components/number";
export * from "@pixel-brewery/mosaik-elements-angular/components/number-ticker";
export * from "@pixel-brewery/mosaik-elements-angular/components/number-box";
export * from "@pixel-brewery/mosaik-elements-angular/components/orbit";
export * from "@pixel-brewery/mosaik-elements-angular/components/page";
export * from "@pixel-brewery/mosaik-elements-angular/components/paginator";
export * from "@pixel-brewery/mosaik-elements-angular/components/parallax";
export * from "@pixel-brewery/mosaik-elements-angular/components/particles";
export * from "@pixel-brewery/mosaik-elements-angular/components/password-box";
export * from "@pixel-brewery/mosaik-elements-angular/components/pattern";
export * from "@pixel-brewery/mosaik-elements-angular/components/persona";
export * from "@pixel-brewery/mosaik-elements-angular/components/perspective";
export * from "@pixel-brewery/mosaik-elements-angular/components/pin-box";
export * from "@pixel-brewery/mosaik-elements-angular/components/pip";
export * from "@pixel-brewery/mosaik-elements-angular/components/placeholder";
export * from "@pixel-brewery/mosaik-elements-angular/components/popup";
export * from "@pixel-brewery/mosaik-elements-angular/components/portal";
export * from "@pixel-brewery/mosaik-elements-angular/components/press-button";
export * from "@pixel-brewery/mosaik-elements-angular/components/progress-bar";
export * from "@pixel-brewery/mosaik-elements-angular/components/progress-ring";
export * from "@pixel-brewery/mosaik-elements-angular/components/prompt-box";
export * from "@pixel-brewery/mosaik-elements-angular/components/pulse";
export * from "@pixel-brewery/mosaik-elements-angular/components/qr-code";
export * from "@pixel-brewery/mosaik-elements-angular/components/radio";
export * from "@pixel-brewery/mosaik-elements-angular/components/rating";
export * from "@pixel-brewery/mosaik-elements-angular/components/region";
export * from "@pixel-brewery/mosaik-elements-angular/components/repeat-button";
export * from "@pixel-brewery/mosaik-elements-angular/components/resize-adorner";
export * from "@pixel-brewery/mosaik-elements-angular/components/resize-thumb";
export * from "@pixel-brewery/mosaik-elements-angular/components/resize";
export * from "@pixel-brewery/mosaik-elements-angular/components/reveal";
export * from "@pixel-brewery/mosaik-elements-angular/components/ribbon";
export * from "@pixel-brewery/mosaik-elements-angular/components/ripple";
export * from "@pixel-brewery/mosaik-elements-angular/components/scale";
export * from "@pixel-brewery/mosaik-elements-angular/components/scheduler";
export * from "@pixel-brewery/mosaik-elements-angular/components/scroll";
export * from "@pixel-brewery/mosaik-elements-angular/components/scrub-slider";
export * from "@pixel-brewery/mosaik-elements-angular/components/search-box";
export * from "@pixel-brewery/mosaik-elements-angular/components/segment-bar";
export * from "@pixel-brewery/mosaik-elements-angular/components/segment";
export * from "@pixel-brewery/mosaik-elements-angular/components/segment-legend";
export * from "@pixel-brewery/mosaik-elements-angular/components/segment-ring";
export * from "@pixel-brewery/mosaik-elements-angular/components/select";
export * from "@pixel-brewery/mosaik-elements-angular/components/sheet";
export * from "@pixel-brewery/mosaik-elements-angular/components/skeleton";
export * from "@pixel-brewery/mosaik-elements-angular/components/slider";
export * from "@pixel-brewery/mosaik-elements-angular/components/slider2";
export * from "@pixel-brewery/mosaik-elements-angular/components/spacer";
export * from "@pixel-brewery/mosaik-elements-angular/components/split-button";
export * from "@pixel-brewery/mosaik-elements-angular/components/split";
export * from "@pixel-brewery/mosaik-elements-angular/components/stack";
export * from "@pixel-brewery/mosaik-elements-angular/components/stepper";
export * from "@pixel-brewery/mosaik-elements-angular/components/sticky";
export * from "@pixel-brewery/mosaik-elements-angular/components/success";
export * from "@pixel-brewery/mosaik-elements-angular/components/text-suggestions";
export * from "@pixel-brewery/mosaik-elements-angular/components/summary";
export * from "@pixel-brewery/mosaik-elements-angular/components/swipe";
export * from "@pixel-brewery/mosaik-elements-angular/components/tab";
export * from "@pixel-brewery/mosaik-elements-angular/components/tab-strip";
export * from "@pixel-brewery/mosaik-elements-angular/components/table";
export * from "@pixel-brewery/mosaik-elements-angular/components/text-effect";
export * from "@pixel-brewery/mosaik-elements-angular/components/text-format";
export * from "@pixel-brewery/mosaik-elements-angular/components/text";
export * from "@pixel-brewery/mosaik-elements-angular/components/text-box";
export * from "@pixel-brewery/mosaik-elements-angular/components/theming";
export * from "@pixel-brewery/mosaik-elements-angular/components/thumb";
export * from "@pixel-brewery/mosaik-elements-angular/components/thumbnail";
export * from "@pixel-brewery/mosaik-elements-angular/components/tick-bar";
export * from "@pixel-brewery/mosaik-elements-angular/components/tile-list";
export * from "@pixel-brewery/mosaik-elements-angular/components/tile-manager";
export * from "@pixel-brewery/mosaik-elements-angular/components/tile";
export * from "@pixel-brewery/mosaik-elements-angular/components/time-box";
export * from "@pixel-brewery/mosaik-elements-angular/components/timeline";
export * from "@pixel-brewery/mosaik-elements-angular/components/toast";
export * from "@pixel-brewery/mosaik-elements-angular/components/toggle-button";
export * from "@pixel-brewery/mosaik-elements-angular/components/toggle-switch";
export * from "@pixel-brewery/mosaik-elements-angular/components/toggletip";
export * from "@pixel-brewery/mosaik-elements-angular/components/toolbar";
export * from "@pixel-brewery/mosaik-elements-angular/components/tooltip";
export * from "@pixel-brewery/mosaik-elements-angular/components/tour";
export * from "@pixel-brewery/mosaik-elements-angular/components/tree";
export * from "@pixel-brewery/mosaik-elements-angular/components/up-down-spinner";
export * from "@pixel-brewery/mosaik-elements-angular/components/video";
export * from "@pixel-brewery/mosaik-elements-angular/components/virtualize";
export * from "@pixel-brewery/mosaik-elements-angular/components/wallet-card";
export * from "@pixel-brewery/mosaik-elements-angular/components/wheel-picker";
export * from "@pixel-brewery/mosaik-elements-angular/components/wizard";
export * from "@pixel-brewery/mosaik-elements-angular/components/wrap";
var AnimationRegistry = class AnimationRegistry {
	_animations;
	constructor() {
		this._animations = {};
	}
	get animations() {
		return this._animations;
	}
	register(name, animation) {
		if (name.trim() === "") throw new Error("Animation name must be provided.");
		this._animations[name] = animation;
	}
	unregister(name) {
		if (name.trim() === "") throw new Error("Animation name must be provided.");
		delete this._animations[name];
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: AnimationRegistry,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: AnimationRegistry
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: AnimationRegistry,
	decorators: [{ type: Injectable }],
	ctorParameters: () => []
});
var AnimateDirective = class AnimateDirective {
	_animationRegistry;
	_element;
	_animationPlayer;
	_renderer;
	_wasTriggered;
	_animate;
	_options;
	constructor(animationRegistry = inject(AnimationRegistry), element = inject(ElementRef), animationPlayer = inject(AnimationPlayer), renderer = inject(Renderer2)) {
		this._animationRegistry = animationRegistry;
		this._element = element;
		this._animationPlayer = animationPlayer;
		this._renderer = renderer;
		this._wasTriggered = false;
		this._animate = void 0;
		this._options = void 0;
	}
	ngOnInit() {
		this.tryTrigger();
	}
	tryTrigger() {
		if (this._wasTriggered) return;
		const resolvedAnimation = this.resolveAnimation();
		if (!resolvedAnimation) {
			console.warn("[AnimateDirective]: No valid animation steps provided.");
			return;
		}
		this._wasTriggered = true;
		this.applyInitialStyles(resolvedAnimation);
		if (resolvedAnimation.steps.length === 0) return;
		if (resolvedAnimation.trigger) {
			resolvedAnimation.trigger(() => this.play(resolvedAnimation));
			return;
		}
		this.play(resolvedAnimation);
	}
	resolveAnimation() {
		if (!this._animate) return;
		if (typeof this._animate === "string") return this.resolveRegisteredAnimation(this._animate);
		if (this._animate.name) {
			const registeredAnimation = this.resolveRegisteredAnimation(this._animate.name);
			if (!registeredAnimation) return;
			return {
				initial: this._animate.initial ?? registeredAnimation.initial,
				steps: this._animate.steps ?? registeredAnimation.steps,
				options: this.mergeOptions(registeredAnimation.options, this._animate.options),
				trigger: this._animate.trigger,
				onFinished: this._animate.onFinished
			};
		}
		if (!this._animate.steps) return;
		return {
			initial: this._animate.initial,
			steps: this._animate.steps,
			options: this._animate.options,
			trigger: this._animate.trigger,
			onFinished: this._animate.onFinished
		};
	}
	resolveRegisteredAnimation(name) {
		const registeredAnimation = this._animationRegistry.animations[name];
		if (!registeredAnimation) {
			console.warn(`[AnimateDirective]: The animation with name "${name}" was not found in the registry.`);
			return;
		}
		return { ...registeredAnimation };
	}
	mergeOptions(baseOptions, overrideOptions) {
		if (!baseOptions && !overrideOptions) return;
		return {
			...baseOptions,
			...overrideOptions
		};
	}
	applyInitialStyles(animation) {
		if (!animation.initial) return;
		for (const [key, value] of Object.entries(animation.initial)) {
			if (this.isKeyframeMetadataProperty(key)) continue;
			if (key in this._element.nativeElement.style) this._renderer.setStyle(this._element.nativeElement, key, value?.toString() ?? "");
		}
	}
	play(animation) {
		this._animationPlayer.playToFinal(this._element.nativeElement, animation, this._options).then(() => {
			animation.onFinished?.();
		});
	}
	isKeyframeMetadataProperty(key) {
		return key === "offset" || key === "easing" || key === "composite";
	}
	get animate() {
		return this._animate;
	}
	set animate(value) {
		this._animate = value;
	}
	get options() {
		return this._options;
	}
	set options(value) {
		this._options = value;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: AnimateDirective,
		deps: [
			{ token: AnimationRegistry },
			{ token: i0.ElementRef },
			{ token: i2.AnimationPlayer },
			{ token: i0.Renderer2 }
		],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: AnimateDirective,
		isStandalone: true,
		selector: "[mosaikAnimate]",
		inputs: {
			animate: ["mosaikAnimate", "animate"],
			options: ["mosaikAnimateOptions", "options"]
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: AnimateDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "[mosaikAnimate]" }]
	}],
	ctorParameters: () => [
		{ type: AnimationRegistry },
		{ type: i0.ElementRef },
		{ type: i2.AnimationPlayer },
		{ type: i0.Renderer2 }
	],
	propDecorators: {
		animate: [{
			type: Input,
			args: [{
				alias: "mosaikAnimate",
				required: true
			}]
		}],
		options: [{
			type: Input,
			args: [{
				alias: "mosaikAnimateOptions",
				required: false
			}]
		}]
	}
});
function provideAnimate(config) {
	return makeEnvironmentProviders([{
		provide: AnimationRegistry,
		useFactory: () => {
			const service = new AnimationRegistry();
			for (const [name, animation] of Object.entries(Animation)) service.register(name, animation);
			if (config?.animations) for (const [name, animation] of Object.entries(config.animations)) service.register(name, animation);
			return service;
		}
	}, {
		provide: AnimationPlayer,
		useClass: AnimationPlayer
	}]);
}
var BreakpointRegistry = class BreakpointRegistry {
	_items;
	_findByMap = /* @__PURE__ */ new Map();
	constructor() {
		this._items = new Array();
	}
	get overlapping() {
		return this._items.filter((it) => it.overlapping);
	}
	get aliases() {
		return this._items.map((it) => it.alias);
	}
	get suffixes() {
		return this._items.map((it) => it.suffix ?? "");
	}
	register(breakpoint) {
		(Array.isArray(breakpoint) ? breakpoint : [breakpoint]).forEach((x) => {
			this._items.push(x);
		});
		reset(this._items, [...this._items].sort(sortAscendingPriority));
	}
	findByAlias(alias) {
		return !alias ? null : this.findWithPredicate(alias, (bp) => bp.alias === alias);
	}
	findByQuery(query) {
		return this.findWithPredicate(query, (bp) => bp.mediaQuery === query);
	}
	findWithPredicate(key, searchFn) {
		let response = this._findByMap.get(key);
		if (!response) {
			response = this._items.find(searchFn) ?? null;
			this._findByMap.set(key, response);
		}
		return response ?? null;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: BreakpointRegistry,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: BreakpointRegistry
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: BreakpointRegistry,
	decorators: [{ type: Injectable }],
	ctorParameters: () => []
});
function sortAscendingPriority(a, b) {
	return (a.priority ?? 0) - (b.priority ?? 0);
}
function clear(self, fn) {
	const splicedItems = self.splice(0, self.length);
	if (fn) each(splicedItems, fn);
	return self;
}
function reset(self, values) {
	clear(self).push(...values);
	return self;
}
function each(self, fn) {
	self.forEach((x, i) => {
		fn(x, i);
	});
	return self;
}
var BreakpointService = class BreakpointService {
	_breakpointObserver;
	_breakpointRegistry;
	_changed;
	_subscriptions;
	constructor() {
		this._breakpointObserver = inject(BreakpointObserver);
		this._breakpointRegistry = inject(BreakpointRegistry);
		this._changed = new Subject();
		this._subscriptions = /* @__PURE__ */ new Map();
	}
	get changed() {
		return this._changed.asObservable();
	}
	ngOnDestroy() {
		for (const subscription of this._subscriptions.values()) subscription.unsubscribe();
		this._subscriptions.clear();
		this._changed.complete();
	}
	isMatched(alias) {
		const mediaQueries = this.resolveMediaQueries(alias);
		return this._breakpointObserver.isMatched(mediaQueries);
	}
	observe(alias) {
		const mediaQueries = this.resolveMediaQueries(alias);
		return this._breakpointObserver.observe(mediaQueries).pipe(map((state) => state.matches));
	}
	watch(alias) {
		const key = this.resolveKey(alias);
		const existingSubscription = this._subscriptions.get(key);
		if (existingSubscription) existingSubscription.unsubscribe();
		const mediaQueries = this.resolveMediaQueries(alias);
		const subscription = this._breakpointObserver.observe(mediaQueries).subscribe(() => {
			this._changed.next();
		});
		this._subscriptions.set(key, subscription);
		return () => {
			subscription.unsubscribe();
			this._subscriptions.delete(key);
		};
	}
	resolveMediaQueries(alias) {
		const aliases = Array.isArray(alias) ? alias : [alias];
		const mediaQueries = aliases.map((x) => this._breakpointRegistry.findByAlias(x)).filter((x) => x).map((x) => x.mediaQuery);
		if (isDevMode() && mediaQueries.length === 0) throw new Error(`The alias or aliases ${aliases.join(", ")} are not defined.`);
		return mediaQueries;
	}
	resolveKey(alias) {
		return (Array.isArray(alias) ? alias : [alias]).sort().join(",");
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: BreakpointService,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: BreakpointService
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: BreakpointService,
	decorators: [{ type: Injectable }],
	ctorParameters: () => []
});
var BreakpointDirective = class BreakpointDirective {
	_vcr;
	_templateRef;
	_cdr;
	_breakpointService;
	_view;
	_changedSubscription;
	constructor() {
		this._vcr = inject(ViewContainerRef);
		this._templateRef = inject(TemplateRef);
		this._cdr = inject(ChangeDetectorRef);
		this._breakpointService = inject(BreakpointService);
		this._changedSubscription = null;
		this._view = null;
	}
	ngOnInit() {
		this.invalidate();
	}
	ngOnDestroy() {
		this._changedSubscription?.unsubscribe();
	}
	invalidate() {
		if (this._view) this._view.context.$implicit = this.getImplicitFn();
		else this._view = this._vcr.createEmbeddedView(this._templateRef, { $implicit: this.getImplicitFn() });
	}
	getImplicitFn() {
		return (alias) => {
			const isMatched = this._breakpointService.isMatched(alias);
			this._changedSubscription?.unsubscribe();
			this._changedSubscription = this._breakpointService.observe(alias).subscribe(() => this.onObserve());
			return isMatched;
		};
	}
	onObserve() {
		this.invalidate();
		this._cdr.markForCheck();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: BreakpointDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: BreakpointDirective,
		isStandalone: true,
		selector: "[mosaikBreakpoint]",
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: BreakpointDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "[mosaikBreakpoint]" }]
	}],
	ctorParameters: () => []
});
function provideBreakpoints(config) {
	return makeEnvironmentProviders([{
		provide: BreakpointService,
		useClass: BreakpointService
	}, {
		provide: BreakpointRegistry,
		useFactory: () => {
			const service = new BreakpointRegistry();
			BREAKPOINTS.forEach((bp) => {
				service.register(bp);
			});
			if (config?.breakpoints) service.register(config.breakpoints);
			return service;
		}
	}]);
}
var Cancel = class Cancel {
	_result;
	_reason;
	constructor(reason, result) {
		this._reason = reason;
		this._result = result;
	}
	get reason() {
		return this._reason;
	}
	get result() {
		return this._result;
	}
	static positive(result) {
		return new Cancel("positive", result);
	}
	static negative(result) {
		return new Cancel("negative", result);
	}
	static none(result) {
		return new Cancel("none", result);
	}
};
var PerspectiveDirective = class PerspectiveDirective {
	_element;
	_renderer;
	_config;
	_perspectiveElement;
	_cleanup;
	constructor() {
		this._element = inject(ElementRef);
		this._renderer = inject(Renderer2);
		this._config = signal({}, ...ngDevMode ? [{ debugName: "_config" }] : /* istanbul ignore next */ []);
		this._perspectiveElement = new PerspectiveElement();
		this._cleanup = effect(() => {
			const config = this._config();
			Object.assign(this._perspectiveElement, config);
			this._perspectiveElement.attach(this._element.nativeElement);
		}, ...ngDevMode ? [{ debugName: "_cleanup" }] : /* istanbul ignore next */ []);
	}
	set config(value) {
		this._config.set(value);
	}
	get config() {
		return this._config();
	}
	ngOnInit() {
		this._renderer.appendChild(this._element.nativeElement, this._perspectiveElement);
	}
	ngOnDestroy() {
		this._cleanup.destroy();
		this._perspectiveElement.detach();
		this._perspectiveElement.remove();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: PerspectiveDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: PerspectiveDirective,
		isStandalone: true,
		selector: "[mosaikPerspective]",
		inputs: { config: ["mosaikPerspective", "config"] },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: PerspectiveDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "[mosaikPerspective]" }]
	}],
	ctorParameters: () => [],
	propDecorators: { config: [{
		type: Input,
		args: ["mosaikPerspective"]
	}] }
});
var RippleDirective = class RippleDirective {
	_element;
	_renderer;
	_config;
	_rippleElement;
	_cleanup;
	constructor() {
		this._element = inject(ElementRef);
		this._renderer = inject(Renderer2);
		this._config = signal({}, ...ngDevMode ? [{ debugName: "_config" }] : /* istanbul ignore next */ []);
		this._rippleElement = new RippleElement();
		this._cleanup = effect(() => {
			const config = this._config();
			Object.assign(this._rippleElement, config);
			this._rippleElement.attach(this._element.nativeElement);
		}, ...ngDevMode ? [{ debugName: "_cleanup" }] : /* istanbul ignore next */ []);
	}
	set config(value) {
		this._config.set(value);
	}
	get config() {
		return this._config();
	}
	ngOnInit() {
		const hostElement = this._element.nativeElement;
		this._renderer.appendChild(hostElement, this._rippleElement);
	}
	ngOnDestroy() {
		this._cleanup.destroy();
		this._rippleElement.detach();
		this._rippleElement.remove();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: RippleDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: RippleDirective,
		isStandalone: true,
		selector: "[mosaikRipple]",
		inputs: { config: ["mosaikRipple", "config"] },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: RippleDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "[mosaikRipple]" }]
	}],
	ctorParameters: () => [],
	propDecorators: { config: [{
		type: Input,
		args: ["mosaikRipple"]
	}] }
});
var ScaleDirective = class ScaleDirective {
	_element;
	_renderer;
	_config;
	_scaleElement;
	_cleanup;
	constructor() {
		this._element = inject(ElementRef);
		this._renderer = inject(Renderer2);
		this._config = signal({}, ...ngDevMode ? [{ debugName: "_config" }] : /* istanbul ignore next */ []);
		this._scaleElement = new ScaleElement();
		this._cleanup = effect(() => {
			const config = this._config();
			Object.assign(this._scaleElement, config);
			this._scaleElement.attach(this._element.nativeElement);
		}, ...ngDevMode ? [{ debugName: "_cleanup" }] : /* istanbul ignore next */ []);
	}
	get config() {
		return this._config();
	}
	set config(value) {
		this._config.set(value);
	}
	ngOnInit() {
		const hostElement = this._element.nativeElement;
		this._renderer.appendChild(hostElement, this._scaleElement);
	}
	ngOnDestroy() {
		this._cleanup.destroy();
		this._scaleElement.detach();
		this._scaleElement.remove();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ScaleDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: ScaleDirective,
		isStandalone: true,
		selector: "[mosaikScale]",
		inputs: { config: ["mosaikScale", "config"] },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ScaleDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "[mosaikScale]" }]
	}],
	ctorParameters: () => [],
	propDecorators: { config: [{
		type: Input,
		args: ["mosaikScale"]
	}] }
});
var FlexDirective = class FlexDirective {
	_element;
	_renderer;
	constructor(element, renderer) {
		this._element = element;
		this._renderer = renderer;
	}
	justify;
	alignItems;
	alignContent;
	direction;
	wrap;
	gap;
	fill;
	ngOnChanges(_changes) {
		let hasFlexProperties = false;
		hasFlexProperties = this.setStyle("flex-direction", this.direction) || hasFlexProperties;
		hasFlexProperties = this.setStyle("justify-content", this.justify) || hasFlexProperties;
		hasFlexProperties = this.setStyle("align-items", this.alignItems) || hasFlexProperties;
		hasFlexProperties = this.setStyle("align-content", this.alignContent) || hasFlexProperties;
		hasFlexProperties = this.setStyle("flex-wrap", this.wrap) || hasFlexProperties;
		hasFlexProperties = this.setStyle("gap", this.gap) || hasFlexProperties;
		if (this.fill !== void 0) {
			this.setFillStyle(this.fill);
			hasFlexProperties = true;
		}
		if (hasFlexProperties) this.setStyle("display", "flex");
	}
	setStyle(property, value) {
		if (value !== void 0) {
			this._renderer.setStyle(this._element.nativeElement, property, value);
			return true;
		}
		return false;
	}
	setFillStyle(fill) {
		const value = typeof fill === "boolean" ? fill ? "1" : "0" : String(fill);
		this._renderer.setStyle(this._element.nativeElement, "flex", value);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FlexDirective,
		deps: [{ token: i0.ElementRef }, { token: i0.Renderer2 }],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: FlexDirective,
		isStandalone: true,
		selector: "[mosaikFlex]",
		inputs: {
			justify: ["mosaikFlexJustify", "justify"],
			alignItems: ["mosaikFlexAlignItems", "alignItems"],
			alignContent: ["mosaikFlexAlignContent", "alignContent"],
			direction: ["mosaikFlexDirection", "direction"],
			wrap: ["mosaikFlexWrap", "wrap"],
			gap: ["mosaikFlexGap", "gap"],
			fill: ["mosaikFlexFill", "fill"]
		},
		usesOnChanges: true,
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FlexDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "[mosaikFlex]" }]
	}],
	ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.Renderer2 }],
	propDecorators: {
		justify: [{
			type: Input,
			args: ["mosaikFlexJustify"]
		}],
		alignItems: [{
			type: Input,
			args: ["mosaikFlexAlignItems"]
		}],
		alignContent: [{
			type: Input,
			args: ["mosaikFlexAlignContent"]
		}],
		direction: [{
			type: Input,
			args: ["mosaikFlexDirection"]
		}],
		wrap: [{
			type: Input,
			args: ["mosaikFlexWrap"]
		}],
		gap: [{
			type: Input,
			args: ["mosaikFlexGap"]
		}],
		fill: [{
			type: Input,
			args: ["mosaikFlexFill"]
		}]
	}
});
var CardIsBusyDirective = class CardIsBusyDirective {
	_elementRef;
	_viewContainerRef;
	_renderer;
	_spinner;
	constructor() {
		this._elementRef = inject(ElementRef);
		this._viewContainerRef = inject(ViewContainerRef);
		this._renderer = inject(Renderer2);
		this._spinner = null;
	}
	isBusy = false;
	ngOnChanges(changes) {
		if (!changes.isBusy) return;
		if (changes.isBusy.currentValue) {
			this._elementRef.nativeElement.setAttribute("isBusy", "true");
			if (!this._spinner) {
				this._spinner = this._viewContainerRef.createComponent(ProgressRingComponent);
				this._spinner.setInput("radius", 24);
				this._spinner.setInput("isIndeterminate", true);
				const spinnerElement = this._spinner.location.nativeElement;
				this._renderer.appendChild(this._elementRef.nativeElement, spinnerElement);
			}
		} else if (!changes.isBusy.firstChange) {
			this._elementRef.nativeElement.removeAttribute("isBusy");
			if (this._spinner) {
				this._spinner.destroy();
				this._spinner = null;
			}
		}
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: CardIsBusyDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "16.1.0",
		version: "22.2.3",
		type: CardIsBusyDirective,
		isStandalone: true,
		selector: "mosaik-card[isBusy]",
		inputs: { isBusy: [
			"isBusy",
			"isBusy",
			booleanAttribute
		] },
		usesOnChanges: true,
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: CardIsBusyDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "mosaik-card[isBusy]" }]
	}],
	ctorParameters: () => [],
	propDecorators: { isBusy: [{
		type: Input,
		args: [{ transform: booleanAttribute }]
	}] }
});
var TranslateService = class TranslateService {
	_translator;
	_languageChanged;
	constructor(translator = inject(TranslatorService)) {
		this._translator = translator;
		this._languageChanged = new Observable((observer) => {
			const dispose = this._translator.languageChanged.subscribe((x) => observer.next(x ?? ""));
			return () => {
				dispose.dispose();
			};
		});
	}
	get currentLanguage() {
		return this._translator.currentLanguage;
	}
	set currentLanguage(value) {
		this._translator.currentLanguage = value;
	}
	get languageChanged() {
		return this._languageChanged;
	}
	addTranslations(lang, translations) {
		this._translator.addTranslations(lang, translations);
	}
	translate(key, ...args) {
		return this._translator.translate(key, ...args);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: TranslateService,
		deps: [{ token: i1$1.TranslatorService }],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: TranslateService
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: TranslateService,
	decorators: [{ type: Injectable }],
	ctorParameters: () => [{ type: i1$1.TranslatorService }]
});
var NumberBoxCurrencyDirective = class NumberBoxCurrencyDirective {
	_defaultCurrencyCode = inject(DEFAULT_CURRENCY_CODE);
	_element = inject(ElementRef).nativeElement;
	_fallbackLocale = inject(LOCALE_ID);
	_translateService = inject(TranslateService, { optional: true });
	_translatedLocale = toSignal(this._translateService?.languageChanged ?? EMPTY, { initialValue: this._translateService?.currentLanguage || this._fallbackLocale });
	constructor() {
		afterRenderEffect(() => this.applyConfiguration());
	}
	currencyCode = input("", {
		...ngDevMode ? { debugName: "currencyCode" } : /* istanbul ignore next */ {},
		alias: "mosaikCurrency"
	});
	locale = input(void 0, {
		...ngDevMode ? { debugName: "locale" } : /* istanbul ignore next */ {},
		alias: "mosaikCurrencyLocale"
	});
	decimalPlaces = input(void 0, {
		...ngDevMode ? { debugName: "decimalPlaces" } : /* istanbul ignore next */ {},
		alias: "mosaikCurrencyDecimalPlaces",
		transform: numberAttribute
	});
	step = input(void 0, {
		...ngDevMode ? { debugName: "step" } : /* istanbul ignore next */ {},
		alias: "mosaikCurrencyStep",
		transform: numberAttribute
	});
	applyConfiguration() {
		const locale = this.locale()?.trim() || this._translatedLocale() || this._fallbackLocale;
		const currencyCode = this.currencyCode().trim().toUpperCase() || this._defaultCurrencyCode;
		const intlLocale = locale === "default" ? void 0 : locale;
		const defaultDecimalPlaces = new Intl.NumberFormat(intlLocale, {
			style: "currency",
			currency: currencyCode
		}).resolvedOptions().maximumFractionDigits ?? 2;
		const decimalPlaces = this.decimalPlaces() ?? defaultDecimalPlaces;
		const step = this.step() ?? 10 ** -decimalPlaces;
		if (!Number.isInteger(decimalPlaces) || decimalPlaces < 0 || decimalPlaces > 100) throw new RangeError("Decimal places must be an integer between 0 and 100.");
		if (!Number.isFinite(step) || step < 0) throw new RangeError("Step must be a finite, non-negative number.");
		this._element.formatter = InputFormatters.currency(currencyCode, locale, decimalPlaces);
		this._element.parser = InputParsers.currency(locale, currencyCode, decimalPlaces);
		this._element.decimalPlaces = decimalPlaces;
		this._element.step = step;
		this._element.keyboard = NumberKeyboardMode.Decimal;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NumberBoxCurrencyDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: NumberBoxCurrencyDirective,
		isStandalone: true,
		selector: "mosaik-numberbox[mosaikCurrency]",
		inputs: {
			currencyCode: {
				classPropertyName: "currencyCode",
				publicName: "mosaikCurrency",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			locale: {
				classPropertyName: "locale",
				publicName: "mosaikCurrencyLocale",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			decimalPlaces: {
				classPropertyName: "decimalPlaces",
				publicName: "mosaikCurrencyDecimalPlaces",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			step: {
				classPropertyName: "step",
				publicName: "mosaikCurrencyStep",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NumberBoxCurrencyDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "mosaik-numberbox[mosaikCurrency]" }]
	}],
	ctorParameters: () => [],
	propDecorators: {
		currencyCode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mosaikCurrency",
				required: false
			}]
		}],
		locale: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mosaikCurrencyLocale",
				required: false
			}]
		}],
		decimalPlaces: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mosaikCurrencyDecimalPlaces",
				required: false
			}]
		}],
		step: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mosaikCurrencyStep",
				required: false
			}]
		}]
	}
});
var NumberBoxDecimalDirective = class NumberBoxDecimalDirective {
	_element = inject(ElementRef).nativeElement;
	_fallbackLocale = inject(LOCALE_ID);
	_translateService = inject(TranslateService, { optional: true });
	_translatedLocale = toSignal(this._translateService?.languageChanged ?? EMPTY, { initialValue: this._translateService?.currentLanguage || this._fallbackLocale });
	constructor() {
		afterRenderEffect(() => this.applyConfiguration());
	}
	locale = input(void 0, {
		...ngDevMode ? { debugName: "locale" } : /* istanbul ignore next */ {},
		alias: "mosaikDecimalLocale"
	});
	decimalPlaces = input(void 0, {
		...ngDevMode ? { debugName: "decimalPlaces" } : /* istanbul ignore next */ {},
		alias: "mosaikDecimalPlaces",
		transform: numberAttribute
	});
	step = input(void 0, {
		...ngDevMode ? { debugName: "step" } : /* istanbul ignore next */ {},
		alias: "mosaikDecimalStep",
		transform: numberAttribute
	});
	useGrouping = input(true, {
		...ngDevMode ? { debugName: "useGrouping" } : /* istanbul ignore next */ {},
		alias: "mosaikDecimalUseGrouping",
		transform: booleanAttribute
	});
	applyConfiguration() {
		const locale = this.locale()?.trim() || this._translatedLocale() || this._fallbackLocale;
		const decimalPlaces = this.decimalPlaces() ?? 2;
		const step = this.step() ?? 10 ** -decimalPlaces;
		if (!Number.isInteger(decimalPlaces) || decimalPlaces < 0 || decimalPlaces > 100) throw new RangeError("Decimal places must be an integer between 0 and 100.");
		if (!Number.isFinite(step) || step < 0) throw new RangeError("Step must be a finite, non-negative number.");
		this._element.formatter = InputFormatters.number(decimalPlaces, locale, this.useGrouping());
		this._element.parser = InputParsers.number(decimalPlaces, locale);
		this._element.decimalPlaces = decimalPlaces;
		this._element.step = step;
		this._element.keyboard = NumberKeyboardMode.Decimal;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NumberBoxDecimalDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: NumberBoxDecimalDirective,
		isStandalone: true,
		selector: "mosaik-numberbox[mosaikDecimal]",
		inputs: {
			locale: {
				classPropertyName: "locale",
				publicName: "mosaikDecimalLocale",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			decimalPlaces: {
				classPropertyName: "decimalPlaces",
				publicName: "mosaikDecimalPlaces",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			step: {
				classPropertyName: "step",
				publicName: "mosaikDecimalStep",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			useGrouping: {
				classPropertyName: "useGrouping",
				publicName: "mosaikDecimalUseGrouping",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NumberBoxDecimalDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "mosaik-numberbox[mosaikDecimal]" }]
	}],
	ctorParameters: () => [],
	propDecorators: {
		locale: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mosaikDecimalLocale",
				required: false
			}]
		}],
		decimalPlaces: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mosaikDecimalPlaces",
				required: false
			}]
		}],
		step: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mosaikDecimalStep",
				required: false
			}]
		}],
		useGrouping: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mosaikDecimalUseGrouping",
				required: false
			}]
		}]
	}
});
var NumberBoxPercentageDirective = class NumberBoxPercentageDirective {
	_element = inject(ElementRef).nativeElement;
	_fallbackLocale = inject(LOCALE_ID);
	_translateService = inject(TranslateService, { optional: true });
	_translatedLocale = toSignal(this._translateService?.languageChanged ?? EMPTY, { initialValue: this._translateService?.currentLanguage || this._fallbackLocale });
	constructor() {
		afterRenderEffect(() => this.applyConfiguration());
	}
	locale = input(void 0, {
		...ngDevMode ? { debugName: "locale" } : /* istanbul ignore next */ {},
		alias: "mosaikPercentageLocale"
	});
	decimalPlaces = input(void 0, {
		...ngDevMode ? { debugName: "decimalPlaces" } : /* istanbul ignore next */ {},
		alias: "mosaikPercentageDecimalPlaces",
		transform: numberAttribute
	});
	step = input(void 0, {
		...ngDevMode ? { debugName: "step" } : /* istanbul ignore next */ {},
		alias: "mosaikPercentageStep",
		transform: numberAttribute
	});
	applyConfiguration() {
		const locale = this.locale()?.trim() || this._translatedLocale() || this._fallbackLocale;
		const displayedDecimalPlaces = this.decimalPlaces() ?? 2;
		const modelDecimalPlaces = displayedDecimalPlaces + 2;
		const step = this.step() ?? 10 ** -modelDecimalPlaces;
		if (!Number.isInteger(displayedDecimalPlaces) || displayedDecimalPlaces < 0 || displayedDecimalPlaces > 100) throw new RangeError("Decimal places must be an integer between 0 and 100.");
		if (modelDecimalPlaces > 100) throw new RangeError("Decimal places must be an integer between 0 and 100.");
		if (!Number.isFinite(step) || step < 0) throw new RangeError("Step must be a finite, non-negative number.");
		this._element.formatter = InputFormatters.percentage(displayedDecimalPlaces, locale);
		this._element.parser = InputParsers.percentage(locale, displayedDecimalPlaces);
		this._element.decimalPlaces = modelDecimalPlaces;
		this._element.step = step;
		this._element.keyboard = NumberKeyboardMode.Decimal;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NumberBoxPercentageDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: NumberBoxPercentageDirective,
		isStandalone: true,
		selector: "mosaik-numberbox[mosaikPercentage]",
		inputs: {
			locale: {
				classPropertyName: "locale",
				publicName: "mosaikPercentageLocale",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			decimalPlaces: {
				classPropertyName: "decimalPlaces",
				publicName: "mosaikPercentageDecimalPlaces",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			step: {
				classPropertyName: "step",
				publicName: "mosaikPercentageStep",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NumberBoxPercentageDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "mosaik-numberbox[mosaikPercentage]" }]
	}],
	ctorParameters: () => [],
	propDecorators: {
		locale: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mosaikPercentageLocale",
				required: false
			}]
		}],
		decimalPlaces: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mosaikPercentageDecimalPlaces",
				required: false
			}]
		}],
		step: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mosaikPercentageStep",
				required: false
			}]
		}]
	}
});
var DockDirective = class DockDirective {
	_element;
	_renderer;
	constructor(element, renderer) {
		this._element = element;
		this._renderer = renderer;
	}
	dock;
	ngOnChanges(_changes) {
		const v = this.normalize(this.dock);
		if (v) this._renderer.setAttribute(this._element.nativeElement, "dock", v);
		else this._renderer.removeAttribute(this._element.nativeElement, "dock");
	}
	normalize(value) {
		if (value === null) return null;
		const v = String(value).toLowerCase().trim();
		return v === "left" || v === "right" || v === "top" || v === "bottom" ? v : null;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DockDirective,
		deps: [{ token: i0.ElementRef }, { token: i0.Renderer2 }],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: DockDirective,
		isStandalone: true,
		selector: "[mosaikDock]",
		inputs: { dock: ["mosaikDock", "dock"] },
		usesOnChanges: true,
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DockDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "[mosaikDock]" }]
	}],
	ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.Renderer2 }],
	propDecorators: { dock: [{
		type: Input,
		args: ["mosaikDock"]
	}] }
});
var ErrorKindDirective = class ErrorKindDirective {
	_kind;
	_hidden;
	constructor() {
		this._kind = "";
		this._hidden = true;
	}
	get kind() {
		return this._kind;
	}
	set kind(value) {
		this._kind = value;
	}
	get hidden() {
		return this._hidden;
	}
	set hidden(value) {
		this._hidden = value;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ErrorKindDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: ErrorKindDirective,
		isStandalone: true,
		selector: "mosaik-error[kind]",
		inputs: {
			kind: "kind",
			hidden: "hidden"
		},
		host: { attributes: {
			"attr.hidden": "hidden",
			"attr.kind": "kind"
		} },
		exportAs: ["mosaikError"],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ErrorKindDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "mosaik-error[kind]",
			exportAs: "mosaikError",
			host: {
				"attr.hidden": "hidden",
				"attr.kind": "kind"
			}
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		kind: [{
			type: Input,
			args: [{ required: true }]
		}],
		hidden: [{ type: Input }]
	}
});
var ReactiveErrorGroupHandler = class {
	_formGroup;
	_targetOption;
	_components;
	_cdr;
	_targetInfo;
	_control;
	_statusSubscription;
	constructor(formGroup, targetOption, components, cdr, targetInfo) {
		this._formGroup = formGroup;
		this._targetOption = targetOption;
		this._components = components;
		this._cdr = cdr;
		this._targetInfo = targetInfo;
		this._control = null;
		this._statusSubscription = Subscription.EMPTY;
	}
	initialize() {
		this._control = this.resolveControl();
		this._statusSubscription = this._control.statusChanges.subscribe(() => this.onStatusChanged());
	}
	validate() {
		if (!this._control) return;
		if ((this._control.dirty || this._control.touched) && this._control.errors) this.onStatusChanged();
	}
	destroy() {
		this._statusSubscription.unsubscribe();
	}
	resolveControl() {
		if (this._targetOption instanceof AbstractControl) {
			this._targetInfo.control = this._targetOption;
			this._targetInfo.path = "";
			return this._targetOption;
		}
		if (Array.isArray(this._targetOption)) {
			const name = this._targetOption[0];
			const ctrl = this.getControlByName(name);
			this._targetInfo.control = ctrl;
			this._targetInfo.path = name;
			return ctrl;
		}
		const ctrl = this.getControlByName(this._targetOption);
		this._targetInfo.control = ctrl;
		this._targetInfo.path = this._targetOption;
		return ctrl;
	}
	getControlByName(name) {
		const ctrl = this._formGroup.control.get(name);
		if (!ctrl) throw new Error(`Control with name '${name}' not found.`);
		return ctrl;
	}
	onStatusChanged() {
		if (!this._control) return;
		if (this._control.status === "INVALID") {
			const firstKey = Object.keys(this._control.errors ?? {})[0];
			this._components.forEach((c) => c.hidden = true);
			const targetComp = this._components.find((c) => {
				return (Array.isArray(c.kind) ? c.kind : [c.kind]).includes(firstKey);
			});
			if (targetComp) targetComp.hidden = false;
		} else this._components.forEach((c) => c.hidden = true);
		this._cdr.markForCheck();
	}
};
var SignalErrorGroupHandler = class {
	_targetOption;
	_components;
	_cdr;
	_targets;
	constructor(targetOption, components, cdr) {
		this._targetOption = targetOption;
		this._components = components;
		this._cdr = cdr;
		this._targets = new Array();
	}
	initialize() {
		const fieldStates = Array.isArray(this._targetOption) ? this._targetOption : [this._targetOption];
		this._targets = fieldStates.map((fs, idx) => ({
			fieldState: fs,
			path: `fieldState[${idx}]`
		}));
	}
	validate() {
		for (const target of this._targets) {
			const field = target.fieldState;
			const errs = field?.errors() ?? [];
			if (errs.length > 0 && field?.touched()) this.showFirst(field, errs);
			else this.hideAll();
		}
		this._cdr.markForCheck();
	}
	destroy() {}
	showFirst(field, errs) {
		const kind = errs[0].kind;
		this._components.forEach((c) => c.hidden = true);
		const comp = this._components.find((c) => {
			return (Array.isArray(c.kind) ? c.kind : [c.kind]).includes(kind);
		});
		if (comp) comp.hidden = false;
	}
	hideAll() {
		this._components.forEach((c) => c.hidden = true);
	}
};
var ErrorGroupDirective = class ErrorGroupDirective {
	_components;
	_targetInfo;
	_cdr;
	_formGroup;
	_handler;
	constructor(cdr = inject(ChangeDetectorRef)) {
		this._cdr = cdr;
		this._formGroup = inject(FormGroupDirective, { optional: true }) ?? void 0;
		this._targetInfo = { path: "" };
	}
	field;
	ngAfterViewInit() {
		this.selectHandler();
		this._handler.initialize();
	}
	ngDoCheck() {
		this._handler.validate();
	}
	ngOnDestroy() {
		this._handler.destroy();
	}
	selectHandler() {
		if (this.field instanceof AbstractControl || this._formGroup && (typeof this.field === "string" || Array.isArray(this.field))) {
			if (!this._formGroup) throw new Error("FormGroupDirective required for reactive mode.");
			this._handler = new ReactiveErrorGroupHandler(this._formGroup, this.field, this._components, this._cdr, this._targetInfo);
		} else {
			const targetOption = Array.isArray(this.field) ? this.field : this.field;
			this._handler = new SignalErrorGroupHandler(targetOption, this._components, this._cdr);
		}
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ErrorGroupDirective,
		deps: [{ token: i0.ChangeDetectorRef }],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: ErrorGroupDirective,
		isStandalone: true,
		selector: "[mosaikErrorGroup]",
		inputs: { field: "field" },
		queries: [{
			propertyName: "_components",
			predicate: i0.forwardRef(() => ErrorKindDirective),
			descendants: true
		}],
		exportAs: ["errorGroup"],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ErrorGroupDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[mosaikErrorGroup]",
			exportAs: "errorGroup"
		}]
	}],
	ctorParameters: () => [{ type: i0.ChangeDetectorRef }],
	propDecorators: {
		_components: [{
			type: ContentChildren,
			args: [forwardRef(() => ErrorKindDirective), { descendants: true }]
		}],
		field: [{
			type: Input,
			args: [{ required: true }]
		}]
	}
});
var FormFieldStateDirective = class FormFieldStateDirective {
	_elementRef;
	constructor(elementRef = inject(ElementRef)) {
		this._elementRef = elementRef;
		effect(() => {
			const fs = this.fieldState();
			this.setError(fs);
		});
	}
	fieldState = input(...ngDevMode ? [void 0, { debugName: "fieldState" }] : /* istanbul ignore next */ []);
	setError(fieldState) {
		const el = this._elementRef.nativeElement;
		if (!fieldState) {
			el.error = "";
			return;
		}
		const errors = fieldState.errors();
		const isTouched = fieldState.touched();
		const isInvalid = fieldState.invalid();
		if (errors.length > 0 && isTouched && isInvalid) el.error = errors[errors.length - 1].message ?? "";
		else el.error = "";
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FormFieldStateDirective,
		deps: [{ token: i0.ElementRef }],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: FormFieldStateDirective,
		isStandalone: true,
		selector: "mosaik-form-field",
		inputs: { fieldState: {
			classPropertyName: "fieldState",
			publicName: "fieldState",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		exportAs: ["formFieldState"],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FormFieldStateDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "mosaik-form-field",
			exportAs: "formFieldState"
		}]
	}],
	ctorParameters: () => [{ type: i0.ElementRef }],
	propDecorators: { fieldState: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "fieldState",
			required: false
		}]
	}] }
});
var ExpandableToggleDirective = class ExpandableToggleDirective {
	_component;
	constructor() {
		this._component = inject(ExpandableComponent, { optional: true });
	}
	expandableToggle = input(void 0, {
		...ngDevMode ? { debugName: "expandableToggle" } : /* istanbul ignore next */ {},
		alias: "mosaikExpandableToggle"
	});
	isExpanded = computed(() => {
		return (this.expandableToggle() ?? this._component)?.isExpanded() ?? false;
	}, ...ngDevMode ? [{ debugName: "isExpanded" }] : /* istanbul ignore next */ []);
	onClick(_event) {
		const component = this.expandableToggle() ?? this._component;
		if (!component) return;
		if (component.disabled()) return;
		component.toggle();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ExpandableToggleDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: ExpandableToggleDirective,
		isStandalone: true,
		selector: "[mosaikExpandableToggle]",
		inputs: { expandableToggle: {
			classPropertyName: "expandableToggle",
			publicName: "mosaikExpandableToggle",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: { listeners: { "click": "onClick($event)" } },
		exportAs: ["mosaikExpandableToggle"],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ExpandableToggleDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[mosaikExpandableToggle]",
			exportAs: "mosaikExpandableToggle",
			host: { "(click)": "onClick($event)" }
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { expandableToggle: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "mosaikExpandableToggle",
			required: false
		}]
	}] }
});
var FlipToDirective = class FlipToDirective {
	_component;
	constructor() {
		this._component = inject(FlipComponent);
	}
	to;
	isDisabled;
	onClick(_event) {
		if (this.isDisabled) return;
		if (this.to === void 0) return;
		this._component.setInput("side", this.to);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FlipToDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: FlipToDirective,
		isStandalone: true,
		selector: "[mosaikFlipTo]",
		inputs: {
			to: ["mosaikFlipTo", "to"],
			isDisabled: ["mosaikFlipToDisabled", "isDisabled"]
		},
		host: { listeners: { "click": "onClick($event)" } },
		exportAs: ["mosaikFlipTo"],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FlipToDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[mosaikFlipTo]",
			exportAs: "mosaikFlipTo"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		to: [{
			type: Input,
			args: [{
				alias: "mosaikFlipTo",
				required: true
			}]
		}],
		isDisabled: [{
			type: Input,
			args: [{ alias: "mosaikFlipToDisabled" }]
		}],
		onClick: [{
			type: HostListener,
			args: ["click", ["$event"]]
		}]
	}
});
var TooltipDirective = class TooltipDirective {
	_element;
	_renderer;
	_config;
	_placement;
	_horizontalOffset;
	_verticalOffset;
	_showDelay;
	_hideDelay;
	_trigger;
	_staysOpen;
	_disabled;
	_tooltipElement;
	_cleanup;
	constructor() {
		this._element = inject(ElementRef);
		this._renderer = inject(Renderer2);
		this._config = signal("", ...ngDevMode ? [{ debugName: "_config" }] : /* istanbul ignore next */ []);
		this._placement = signal(void 0, ...ngDevMode ? [{ debugName: "_placement" }] : /* istanbul ignore next */ []);
		this._horizontalOffset = signal(void 0, ...ngDevMode ? [{ debugName: "_horizontalOffset" }] : /* istanbul ignore next */ []);
		this._verticalOffset = signal(void 0, ...ngDevMode ? [{ debugName: "_verticalOffset" }] : /* istanbul ignore next */ []);
		this._showDelay = signal(void 0, ...ngDevMode ? [{ debugName: "_showDelay" }] : /* istanbul ignore next */ []);
		this._hideDelay = signal(void 0, ...ngDevMode ? [{ debugName: "_hideDelay" }] : /* istanbul ignore next */ []);
		this._trigger = signal(void 0, ...ngDevMode ? [{ debugName: "_trigger" }] : /* istanbul ignore next */ []);
		this._staysOpen = signal(void 0, ...ngDevMode ? [{ debugName: "_staysOpen" }] : /* istanbul ignore next */ []);
		this._disabled = signal(void 0, ...ngDevMode ? [{ debugName: "_disabled" }] : /* istanbul ignore next */ []);
		this._tooltipElement = new TooltipElement();
		afterNextRender(() => {
			const parent = this._element.nativeElement.parentElement;
			if (parent) this._renderer.appendChild(parent, this._tooltipElement);
		});
		this._cleanup = effect(() => {
			const config = this._config();
			const placement = this._placement();
			const horizontalOffset = this._horizontalOffset();
			const verticalOffset = this._verticalOffset();
			const showDelay = this._showDelay();
			const hideDelay = this._hideDelay();
			const trigger = this._trigger();
			const staysOpen = this._staysOpen();
			const disabled = this._disabled();
			if (typeof config === "string") this._tooltipElement.content = config;
			else {
				if (config.content !== void 0) this._tooltipElement.content = config.content;
				if (config.placement !== void 0) this._tooltipElement.placement = config.placement;
				if (config.horizontalOffset !== void 0) this._tooltipElement.horizontalOffset = config.horizontalOffset;
				if (config.verticalOffset !== void 0) this._tooltipElement.verticalOffset = config.verticalOffset;
				if (config.showDelay !== void 0) this._tooltipElement.showDelay = config.showDelay;
				if (config.hideDelay !== void 0) this._tooltipElement.hideDelay = config.hideDelay;
				if (config.trigger !== void 0) this._tooltipElement.trigger = config.trigger;
				if (config.staysOpen !== void 0) this._tooltipElement.staysOpen = config.staysOpen;
				if (config.disabled !== void 0) this._tooltipElement.disabled = config.disabled;
			}
			if (placement !== void 0) this._tooltipElement.placement = placement;
			if (horizontalOffset !== void 0) this._tooltipElement.horizontalOffset = horizontalOffset;
			if (verticalOffset !== void 0) this._tooltipElement.verticalOffset = verticalOffset;
			if (showDelay !== void 0) this._tooltipElement.showDelay = showDelay;
			if (hideDelay !== void 0) this._tooltipElement.hideDelay = hideDelay;
			if (trigger !== void 0) this._tooltipElement.trigger = trigger;
			if (staysOpen !== void 0) this._tooltipElement.staysOpen = staysOpen;
			if (disabled !== void 0) this._tooltipElement.disabled = disabled;
			this._tooltipElement.attach(this._element.nativeElement);
		}, ...ngDevMode ? [{ debugName: "_cleanup" }] : /* istanbul ignore next */ []);
	}
	set config(value) {
		this._config.set(value);
	}
	get config() {
		return this._config();
	}
	set placement(value) {
		this._placement.set(value);
	}
	get placement() {
		return this._placement();
	}
	set horizontalOffset(value) {
		this._horizontalOffset.set(value);
	}
	get horizontalOffset() {
		return this._horizontalOffset();
	}
	set verticalOffset(value) {
		this._verticalOffset.set(value);
	}
	get verticalOffset() {
		return this._verticalOffset();
	}
	set showDelay(value) {
		this._showDelay.set(value);
	}
	get showDelay() {
		return this._showDelay();
	}
	set hideDelay(value) {
		this._hideDelay.set(value);
	}
	get hideDelay() {
		return this._hideDelay();
	}
	set trigger(value) {
		this._trigger.set(value);
	}
	get trigger() {
		return this._trigger();
	}
	set staysOpen(value) {
		this._staysOpen.set(value);
	}
	get staysOpen() {
		return this._staysOpen();
	}
	set disabled(value) {
		this._disabled.set(value);
	}
	get disabled() {
		return this._disabled();
	}
	ngOnDestroy() {
		this._cleanup.destroy();
		this._tooltipElement.detach();
		this._tooltipElement.remove();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: TooltipDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: TooltipDirective,
		isStandalone: true,
		selector: "[mosaikTooltip]",
		inputs: {
			config: ["mosaikTooltip", "config"],
			placement: ["mosaikTooltipPlacement", "placement"],
			horizontalOffset: ["mosaikTooltipHorizontalOffset", "horizontalOffset"],
			verticalOffset: ["mosaikTooltipVerticalOffset", "verticalOffset"],
			showDelay: ["mosaikTooltipShowDelay", "showDelay"],
			hideDelay: ["mosaikTooltipHideDelay", "hideDelay"],
			trigger: ["mosaikTooltipTrigger", "trigger"],
			staysOpen: ["mosaikTooltipStaysOpen", "staysOpen"],
			disabled: ["mosaikTooltipDisabled", "disabled"]
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: TooltipDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "[mosaikTooltip]" }]
	}],
	ctorParameters: () => [],
	propDecorators: {
		config: [{
			type: Input,
			args: ["mosaikTooltip"]
		}],
		placement: [{
			type: Input,
			args: ["mosaikTooltipPlacement"]
		}],
		horizontalOffset: [{
			type: Input,
			args: ["mosaikTooltipHorizontalOffset"]
		}],
		verticalOffset: [{
			type: Input,
			args: ["mosaikTooltipVerticalOffset"]
		}],
		showDelay: [{
			type: Input,
			args: ["mosaikTooltipShowDelay"]
		}],
		hideDelay: [{
			type: Input,
			args: ["mosaikTooltipHideDelay"]
		}],
		trigger: [{
			type: Input,
			args: ["mosaikTooltipTrigger"]
		}],
		staysOpen: [{
			type: Input,
			args: ["mosaikTooltipStaysOpen"]
		}],
		disabled: [{
			type: Input,
			args: ["mosaikTooltipDisabled"]
		}]
	}
});
function defineItem(key, title, options) {
	return {
		key,
		title,
		...options
	};
}
function defineItems(...items) {
	return items;
}
var ItemCellDefDirective = class ItemCellDefDirective {
	_template;
	constructor() {
		this._template = inject(TemplateRef);
	}
	get template() {
		return this._template;
	}
	static ngTemplateContextGuard(_dir, _ctx) {
		return true;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ItemCellDefDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: ItemCellDefDirective,
		isStandalone: true,
		selector: "[mosaikItemCellDef]",
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ItemCellDefDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "[mosaikItemCellDef]" }]
	}],
	ctorParameters: () => []
});
const TEMPLATE_OVERRIDES$1 = /* @__PURE__ */ new WeakMap();
const PATCHED_ELEMENTS$1 = /* @__PURE__ */ new WeakSet();
function ensureGetItemDefinitionsPatched(element) {
	if (PATCHED_ELEMENTS$1.has(element)) return;
	const original = element.getItemDefinitions.bind(element);
	element.getItemDefinitions = () => {
		const definitions = original();
		const overrides = TEMPLATE_OVERRIDES$1.get(element);
		if (!overrides || overrides.size === 0) return definitions;
		return definitions.map((def) => {
			const override = overrides.get(def.key);
			if (override) return {
				...def,
				...override
			};
			return def;
		});
	};
	PATCHED_ELEMENTS$1.add(element);
}
function registerTemplateOverrides$1(element, itemKey, overrides) {
	ensureGetItemDefinitionsPatched(element);
	let map = TEMPLATE_OVERRIDES$1.get(element);
	if (!map) {
		map = /* @__PURE__ */ new Map();
		TEMPLATE_OVERRIDES$1.set(element, map);
	}
	map.set(itemKey, overrides);
	element.requestUpdate("itemDefinitions");
}
function unregisterTemplateOverrides$1(element, itemKey) {
	const map = TEMPLATE_OVERRIDES$1.get(element);
	if (map) {
		map.delete(itemKey);
		element.requestUpdate("itemDefinitions");
	}
}
var ItemDefDirective = class ItemDefDirective {
	_dataList;
	_vcr;
	_injector;
	_views;
	_nativeElement;
	_cleanupScheduled;
	constructor() {
		this._dataList = inject(DataListComponent);
		this._vcr = inject(ViewContainerRef);
		this._injector = inject(Injector);
		this._views = [];
		this._nativeElement = null;
		this._cleanupScheduled = false;
	}
	itemKey;
	itemCellDef;
	ngAfterContentInit() {
		afterNextRender(() => {
			this.applyTemplates();
		}, { injector: this._injector });
	}
	ngOnDestroy() {
		if (this._nativeElement) unregisterTemplateOverrides$1(this._nativeElement, this.itemKey);
		for (const view of this._views) view.destroy();
		this._views.length = 0;
	}
	applyTemplates() {
		this._nativeElement = this._dataList.elementRef.nativeElement;
		const overrides = {};
		if (this.itemCellDef) overrides.itemTemplate = this.createItemTemplateCallback(this.itemCellDef);
		registerTemplateOverrides$1(this._nativeElement, this.itemKey, overrides);
	}
	createItemTemplateCallback(itemCellDef) {
		return (item, definition) => {
			this.scheduleViewCleanup();
			const viewRef = this._vcr.createEmbeddedView(itemCellDef.template, {
				$implicit: item,
				definition
			});
			viewRef.detectChanges();
			this._views.push(viewRef);
			const fragment = document.createDocumentFragment();
			for (const node of viewRef.rootNodes) fragment.appendChild(node);
			return fragment;
		};
	}
	scheduleViewCleanup() {
		if (this._cleanupScheduled) return;
		this._cleanupScheduled = true;
		requestAnimationFrame(() => {
			this._cleanupScheduled = false;
			this.cleanupDisconnectedViews();
		});
	}
	cleanupDisconnectedViews() {
		let writeIndex = 0;
		for (let readIndex = 0; readIndex < this._views.length; readIndex++) {
			const view = this._views[readIndex];
			if (view.rootNodes.some((node) => node.isConnected)) {
				this._views[writeIndex] = view;
				writeIndex++;
			} else view.destroy();
		}
		this._views.length = writeIndex;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ItemDefDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: ItemDefDirective,
		isStandalone: true,
		selector: "[mosaikItemDef]",
		inputs: { itemKey: ["mosaikItemDef", "itemKey"] },
		queries: [{
			propertyName: "itemCellDef",
			first: true,
			predicate: ItemCellDefDirective,
			descendants: true
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ItemDefDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "[mosaikItemDef]" }]
	}],
	ctorParameters: () => [],
	propDecorators: {
		itemKey: [{
			type: Input,
			args: [{
				required: true,
				alias: "mosaikItemDef"
			}]
		}],
		itemCellDef: [{
			type: ContentChild,
			args: [ItemCellDefDirective]
		}]
	}
});
var CellDefDirective = class CellDefDirective {
	_template;
	constructor() {
		this._template = inject(TemplateRef);
	}
	get template() {
		return this._template;
	}
	static ngTemplateContextGuard(_dir, _ctx) {
		return true;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: CellDefDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: CellDefDirective,
		isStandalone: true,
		selector: "[mosaikCellDef]",
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: CellDefDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "[mosaikCellDef]" }]
	}],
	ctorParameters: () => []
});
var FooterCellDefDirective = class FooterCellDefDirective {
	_template;
	constructor() {
		this._template = inject(TemplateRef);
	}
	get template() {
		return this._template;
	}
	static ngTemplateContextGuard(_dir, _ctx) {
		return true;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FooterCellDefDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: FooterCellDefDirective,
		isStandalone: true,
		selector: "[mosaikFooterCellDef]",
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FooterCellDefDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "[mosaikFooterCellDef]" }]
	}],
	ctorParameters: () => []
});
var HeaderCellDefDirective = class HeaderCellDefDirective {
	_template;
	constructor() {
		this._template = inject(TemplateRef);
	}
	get template() {
		return this._template;
	}
	static ngTemplateContextGuard(_dir, _ctx) {
		return true;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: HeaderCellDefDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: HeaderCellDefDirective,
		isStandalone: true,
		selector: "[mosaikHeaderCellDef]",
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: HeaderCellDefDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "[mosaikHeaderCellDef]" }]
	}],
	ctorParameters: () => []
});
const TEMPLATE_OVERRIDES = /* @__PURE__ */ new WeakMap();
const PATCHED_ELEMENTS = /* @__PURE__ */ new WeakSet();
function ensureGetColumnsPatched(element) {
	if (PATCHED_ELEMENTS.has(element)) return;
	const original = element.getColumns.bind(element);
	element.getColumns = () => {
		const columns = original();
		const overrides = TEMPLATE_OVERRIDES.get(element);
		if (!overrides || overrides.size === 0) return columns;
		return columns.map((col) => {
			const override = overrides.get(col.key);
			if (override) return {
				...col,
				...override
			};
			return col;
		});
	};
	PATCHED_ELEMENTS.add(element);
}
function registerTemplateOverrides(element, columnKey, overrides) {
	ensureGetColumnsPatched(element);
	let map = TEMPLATE_OVERRIDES.get(element);
	if (!map) {
		map = /* @__PURE__ */ new Map();
		TEMPLATE_OVERRIDES.set(element, map);
	}
	map.set(columnKey, overrides);
	element.requestUpdate("columnDefinitions");
}
function unregisterTemplateOverrides(element, columnKey) {
	const map = TEMPLATE_OVERRIDES.get(element);
	if (map) {
		map.delete(columnKey);
		element.requestUpdate("columnDefinitions");
	}
}
var ColumnDefDirective = class ColumnDefDirective {
	_dataTable;
	_vcr;
	_injector;
	_views;
	_nativeElement;
	_cleanupScheduled;
	constructor() {
		this._dataTable = inject(DataTableComponent);
		this._vcr = inject(ViewContainerRef);
		this._injector = inject(Injector);
		this._views = [];
		this._nativeElement = null;
		this._cleanupScheduled = false;
	}
	columnKey;
	cellDef;
	headerCellDef;
	footerCellDef;
	ngAfterContentInit() {
		afterNextRender(() => {
			this.applyTemplates();
		}, { injector: this._injector });
	}
	ngOnDestroy() {
		if (this._nativeElement) unregisterTemplateOverrides(this._nativeElement, this.columnKey);
		for (const view of this._views) view.destroy();
		this._views.length = 0;
	}
	applyTemplates() {
		this._nativeElement = this._dataTable.elementRef.nativeElement;
		const overrides = {};
		if (this.cellDef) overrides.cellTemplate = this.createCellTemplateCallback(this.cellDef);
		if (this.headerCellDef) overrides.headerCellTemplate = this.createHeaderCellTemplateCallback(this.headerCellDef);
		if (this.footerCellDef) overrides.footerCellTemplate = this.createFooterCellTemplateCallback(this.footerCellDef);
		registerTemplateOverrides(this._nativeElement, this.columnKey, overrides);
	}
	createCellTemplateCallback(cellDef) {
		return (item, column, resolvedValue) => {
			this.scheduleViewCleanup();
			const viewRef = this._vcr.createEmbeddedView(cellDef.template, {
				$implicit: item,
				column,
				value: resolvedValue
			});
			viewRef.detectChanges();
			this._views.push(viewRef);
			const fragment = document.createDocumentFragment();
			for (const node of viewRef.rootNodes) fragment.appendChild(node);
			return fragment;
		};
	}
	createHeaderCellTemplateCallback(headerCellDef) {
		return (column) => {
			this.scheduleViewCleanup();
			const viewRef = this._vcr.createEmbeddedView(headerCellDef.template, { $implicit: column });
			viewRef.detectChanges();
			this._views.push(viewRef);
			const fragment = document.createDocumentFragment();
			for (const node of viewRef.rootNodes) fragment.appendChild(node);
			return fragment;
		};
	}
	createFooterCellTemplateCallback(footerCellDef) {
		return (column) => {
			this.scheduleViewCleanup();
			const viewRef = this._vcr.createEmbeddedView(footerCellDef.template, { $implicit: column });
			viewRef.detectChanges();
			this._views.push(viewRef);
			const fragment = document.createDocumentFragment();
			for (const node of viewRef.rootNodes) fragment.appendChild(node);
			return fragment;
		};
	}
	scheduleViewCleanup() {
		if (this._cleanupScheduled) return;
		this._cleanupScheduled = true;
		requestAnimationFrame(() => {
			this._cleanupScheduled = false;
			this.cleanupDisconnectedViews();
		});
	}
	cleanupDisconnectedViews() {
		let writeIndex = 0;
		for (let readIndex = 0; readIndex < this._views.length; readIndex++) {
			const view = this._views[readIndex];
			if (view.rootNodes.some((node) => node.isConnected)) {
				this._views[writeIndex] = view;
				writeIndex++;
			} else view.destroy();
		}
		this._views.length = writeIndex;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ColumnDefDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: ColumnDefDirective,
		isStandalone: true,
		selector: "[mosaikColumnDef]",
		inputs: { columnKey: ["mosaikColumnDef", "columnKey"] },
		queries: [
			{
				propertyName: "cellDef",
				first: true,
				predicate: CellDefDirective,
				descendants: true
			},
			{
				propertyName: "headerCellDef",
				first: true,
				predicate: HeaderCellDefDirective,
				descendants: true
			},
			{
				propertyName: "footerCellDef",
				first: true,
				predicate: FooterCellDefDirective,
				descendants: true
			}
		],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ColumnDefDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "[mosaikColumnDef]" }]
	}],
	ctorParameters: () => [],
	propDecorators: {
		columnKey: [{
			type: Input,
			args: [{
				required: true,
				alias: "mosaikColumnDef"
			}]
		}],
		cellDef: [{
			type: ContentChild,
			args: [CellDefDirective]
		}],
		headerCellDef: [{
			type: ContentChild,
			args: [HeaderCellDefDirective]
		}],
		footerCellDef: [{
			type: ContentChild,
			args: [FooterCellDefDirective]
		}]
	}
});
var DataTableColumnEditorToggleDirective = class DataTableColumnEditorToggleDirective {
	_component;
	_editorChanged = signal(0, ...ngDevMode ? [{ debugName: "_editorChanged" }] : /* istanbul ignore next */ []);
	constructor() {
		this._component = inject(DataTableComponent, { optional: true });
		effect((onCleanup) => {
			const component = this.dataTableColumnEditorToggle() ?? this._component;
			if (!component) return;
			const onChange = () => this._editorChanged.update((value) => value + 1);
			const opened = component.dataTableEditorOpened.subscribe(onChange);
			const closed = component.dataTableEditorClosed.subscribe(onChange);
			onCleanup(() => {
				opened.unsubscribe();
				closed.unsubscribe();
			});
		});
	}
	dataTableColumnEditorToggle = input(void 0, {
		...ngDevMode ? { debugName: "dataTableColumnEditorToggle" } : /* istanbul ignore next */ {},
		alias: "mosaikDataTableColumnEditorToggle"
	});
	editorOpened = computed(() => {
		this._editorChanged();
		const component = this.dataTableColumnEditorToggle() ?? this._component;
		return readProxyProperty(component ?? void 0, "editorOpened") ?? false;
	}, ...ngDevMode ? [{ debugName: "editorOpened" }] : /* istanbul ignore next */ []);
	onClick(_event) {
		const component = this.dataTableColumnEditorToggle() ?? this._component;
		if (!component) return;
		if (component.disabled()) return;
		if (!readProxyProperty(component, "editorOpened")) component.openEditor();
		else component.closeEditor();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DataTableColumnEditorToggleDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: DataTableColumnEditorToggleDirective,
		isStandalone: true,
		selector: "[mosaikDataTableColumnEditorToggle]",
		inputs: { dataTableColumnEditorToggle: {
			classPropertyName: "dataTableColumnEditorToggle",
			publicName: "mosaikDataTableColumnEditorToggle",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: { listeners: { "click": "onClick($event)" } },
		exportAs: ["mosaikDataTableColumnEditorToggle"],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DataTableColumnEditorToggleDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[mosaikDataTableColumnEditorToggle]",
			exportAs: "mosaikDataTableColumnEditorToggle",
			host: { "(click)": "onClick($event)" }
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { dataTableColumnEditorToggle: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "mosaikDataTableColumnEditorToggle",
			required: false
		}]
	}] }
});
function defineColumn(key, title, options) {
	return {
		key,
		title,
		...options
	};
}
function defineColumns(...columns) {
	return columns;
}
var ComboItemVisualDirective = class ComboItemVisualDirective {
	_itemComponent;
	_renderer;
	_template;
	_viewContainer;
	_optionView;
	_selectionView;
	_visual;
	constructor() {
		this._itemComponent = inject(ComboItemComponent);
		this._renderer = inject(Renderer2);
		this._template = inject(TemplateRef);
		this._viewContainer = inject(ViewContainerRef);
		this._optionView = null;
		this._selectionView = null;
		this._visual = null;
	}
	ngOnInit() {
		const item = this._itemComponent.elementRef.nativeElement;
		this._optionView = this._viewContainer.createEmbeddedView(this._template, {
			$implicit: item,
			mode: "option"
		});
		this._selectionView = this._viewContainer.createEmbeddedView(this._template, {
			$implicit: item,
			mode: "selection"
		});
		this._visual = this._renderer.createElement(ComboItemVisualElement.is);
		this._renderer.setAttribute(this._visual, "slot", "selection");
		this._selectionView.rootNodes.forEach((node) => this._renderer.appendChild(this._visual, node));
		this._renderer.appendChild(item, this._visual);
		this._optionView.detectChanges();
		this._selectionView.detectChanges();
	}
	ngOnDestroy() {
		this._visual?.remove();
		this._optionView?.destroy();
		this._selectionView?.destroy();
		this._visual = null;
		this._optionView = null;
		this._selectionView = null;
	}
	ngDoCheck() {
		this.detectChanges();
	}
	static ngTemplateContextGuard(_directive, context) {
		return true;
	}
	detectChanges() {
		if (this._optionView && !this._optionView.destroyed) this._optionView.detectChanges();
		if (this._selectionView && !this._selectionView.destroyed) this._selectionView.detectChanges();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ComboItemVisualDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: ComboItemVisualDirective,
		isStandalone: true,
		selector: "ng-template[mosaikComboItemVisual]",
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ComboItemVisualDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "ng-template[mosaikComboItemVisual]" }]
	}],
	ctorParameters: () => []
});
var ComboTriggerDirective = class ComboTriggerDirective {
	_anchor;
	_accessors;
	_renderer;
	_subscriptions;
	_template;
	_viewContainer;
	_hostElement;
	_combo;
	_view;
	constructor() {
		this._anchor = inject(ElementRef);
		this._accessors = inject(NG_VALUE_ACCESSOR, {
			optional: true,
			skipSelf: true
		});
		this._renderer = inject(Renderer2);
		this._subscriptions = [];
		this._template = inject(TemplateRef);
		this._viewContainer = inject(ViewContainerRef);
		this._hostElement = null;
		this._combo = null;
		this._view = null;
	}
	ngOnInit() {
		const combo = this._accessors?.map((accessor) => "elementRef" in accessor ? accessor.elementRef?.nativeElement : null).find((element) => element?.localName === "mosaik-combo") ?? this._anchor.nativeElement.parentElement;
		if (combo?.localName !== "mosaik-combo") throw new Error("mosaikComboTrigger must be placed inside mosaik-combo.");
		this._combo = combo;
		const selection = combo.selectedItems;
		this._view = this._viewContainer.createEmbeddedView(this._template, {
			$implicit: selection,
			selection,
			value: combo.value
		});
		this._hostElement = this._renderer.createElement("span");
		this._renderer.setAttribute(this._hostElement, "slot", "trigger");
		this._view.rootNodes.forEach((node) => this._renderer.appendChild(this._hostElement, node));
		this._renderer.appendChild(combo, this._hostElement);
		this._view.detectChanges();
		this._subscriptions.push(combo.on("selectionChanged", () => this.updateContext()), combo.on("changed", () => this.updateContext()));
	}
	ngOnDestroy() {
		this._subscriptions.forEach((subscription) => subscription.dispose());
		this._subscriptions.length = 0;
		this._hostElement?.remove();
		this._view?.destroy();
		this._hostElement = null;
		this._combo = null;
		this._view = null;
	}
	static ngTemplateContextGuard(_directive, context) {
		return true;
	}
	updateContext() {
		if (!this._view) return;
		const combo = this._combo;
		if (!combo) return;
		const selection = combo.selectedItems;
		this._view.context.$implicit = selection;
		this._view.context.selection = selection;
		this._view.context.value = combo.value;
		this._view.detectChanges();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ComboTriggerDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: ComboTriggerDirective,
		isStandalone: true,
		selector: "ng-template[mosaikComboTrigger]",
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ComboTriggerDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "ng-template[mosaikComboTrigger]" }]
	}],
	ctorParameters: () => []
});
var SelectItemVisualDirective = class SelectItemVisualDirective {
	_itemComponent;
	_renderer;
	_template;
	_viewContainer;
	_optionView;
	_selectionView;
	_visual;
	constructor() {
		this._itemComponent = inject(SelectItemComponent);
		this._renderer = inject(Renderer2);
		this._template = inject(TemplateRef);
		this._viewContainer = inject(ViewContainerRef);
		this._optionView = null;
		this._selectionView = null;
		this._visual = null;
	}
	ngOnInit() {
		const item = this._itemComponent.elementRef.nativeElement;
		this._optionView = this._viewContainer.createEmbeddedView(this._template, {
			$implicit: item,
			mode: "option"
		});
		this._selectionView = this._viewContainer.createEmbeddedView(this._template, {
			$implicit: item,
			mode: "selection"
		});
		this._visual = this._renderer.createElement(SelectItemVisualElement.is);
		this._renderer.setAttribute(this._visual, "slot", "selection");
		this._selectionView.rootNodes.forEach((node) => this._renderer.appendChild(this._visual, node));
		this._renderer.appendChild(item, this._visual);
		this._optionView.detectChanges();
		this._selectionView.detectChanges();
	}
	ngOnDestroy() {
		this._visual?.remove();
		this._optionView?.destroy();
		this._selectionView?.destroy();
		this._visual = null;
		this._optionView = null;
		this._selectionView = null;
	}
	ngDoCheck() {
		this.detectChanges();
	}
	static ngTemplateContextGuard(_directive, context) {
		return true;
	}
	detectChanges() {
		if (this._optionView && !this._optionView.destroyed) this._optionView.detectChanges();
		if (this._selectionView && !this._selectionView.destroyed) this._selectionView.detectChanges();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: SelectItemVisualDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: SelectItemVisualDirective,
		isStandalone: true,
		selector: "ng-template[mosaikSelectItemVisual]",
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: SelectItemVisualDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "ng-template[mosaikSelectItemVisual]" }]
	}],
	ctorParameters: () => []
});
var SelectTriggerDirective = class SelectTriggerDirective {
	_renderer;
	_anchor;
	_accessors;
	_subscriptions;
	_template;
	_viewContainer;
	_hostElement;
	_select;
	_view;
	constructor() {
		this._renderer = inject(Renderer2);
		this._anchor = inject(ElementRef);
		this._accessors = inject(NG_VALUE_ACCESSOR, {
			optional: true,
			skipSelf: true
		});
		this._subscriptions = [];
		this._template = inject(TemplateRef);
		this._viewContainer = inject(ViewContainerRef);
		this._hostElement = null;
		this._select = null;
		this._view = null;
	}
	ngOnInit() {
		const select = this._accessors?.map((accessor) => "elementRef" in accessor ? accessor.elementRef?.nativeElement : null).find((element) => element?.localName === "mosaik-select") ?? this._anchor.nativeElement.parentElement;
		if (select?.localName !== "mosaik-select") throw new Error("mosaikSelectTrigger must be placed inside mosaik-select.");
		this._select = select;
		const selection = select.selectedItem;
		this._view = this._viewContainer.createEmbeddedView(this._template, {
			$implicit: selection,
			selection,
			value: select.value
		});
		this._hostElement = this._renderer.createElement("span");
		this._renderer.setAttribute(this._hostElement, "slot", "trigger");
		this._view.rootNodes.forEach((node) => this._renderer.appendChild(this._hostElement, node));
		this._renderer.appendChild(select, this._hostElement);
		this._view.detectChanges();
		this._subscriptions.push(select.on("selectionChanged", () => this.updateContext()), select.on("changed", () => this.updateContext()));
	}
	ngOnDestroy() {
		this._subscriptions.forEach((subscription) => subscription.dispose());
		this._subscriptions.length = 0;
		this._hostElement?.remove();
		this._view?.destroy();
		this._hostElement = null;
		this._select = null;
		this._view = null;
	}
	static ngTemplateContextGuard(_directive, context) {
		return true;
	}
	updateContext() {
		if (!this._view) return;
		const select = this._select;
		if (!select) return;
		const selection = select.selectedItem;
		this._view.context.$implicit = selection;
		this._view.context.selection = selection;
		this._view.context.value = select.value;
		this._view.detectChanges();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: SelectTriggerDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: SelectTriggerDirective,
		isStandalone: true,
		selector: "ng-template[mosaikSelectTrigger]",
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: SelectTriggerDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "ng-template[mosaikSelectTrigger]" }]
	}],
	ctorParameters: () => []
});
var StepperNextDirective = class StepperNextDirective {
	_component;
	constructor() {
		this._component = inject(StepperComponent);
	}
	onClick(_event) {
		if (this._component.disabled()) return;
		this._component.selectNext();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: StepperNextDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: StepperNextDirective,
		isStandalone: true,
		selector: "[mosaikStepperNext]",
		host: { listeners: { "click": "onClick($event)" } },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: StepperNextDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "[mosaikStepperNext]" }]
	}],
	ctorParameters: () => [],
	propDecorators: { onClick: [{
		type: HostListener,
		args: ["click", ["$event"]]
	}] }
});
var StepperPrevDirective = class StepperPrevDirective {
	_component;
	constructor() {
		this._component = inject(StepperComponent);
	}
	onClick(_event) {
		if (this._component.disabled()) return;
		this._component.selectPrevious();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: StepperPrevDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: StepperPrevDirective,
		isStandalone: true,
		selector: "[mosaikStepperPrev]",
		host: { listeners: { "click": "onClick($event)" } },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: StepperPrevDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "[mosaikStepperPrev]" }]
	}],
	ctorParameters: () => [],
	propDecorators: { onClick: [{
		type: HostListener,
		args: ["click", ["$event"]]
	}] }
});
var WizardNextDirective = class WizardNextDirective {
	_component;
	constructor() {
		this._component = inject(WizardComponent);
	}
	onClick(_event) {
		if (this._component.disabled()) return;
		this._component.selectNext();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: WizardNextDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: WizardNextDirective,
		isStandalone: true,
		selector: "[mosaikWizardNext]",
		host: { listeners: { "click": "onClick($event)" } },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: WizardNextDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "[mosaikWizardNext]" }]
	}],
	ctorParameters: () => [],
	propDecorators: { onClick: [{
		type: HostListener,
		args: ["click", ["$event"]]
	}] }
});
var WizardPrevDirective = class WizardPrevDirective {
	_component;
	constructor() {
		this._component = inject(WizardComponent);
	}
	onClick(_event) {
		if (this._component.disabled()) return;
		this._component.selectPrevious();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: WizardPrevDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: WizardPrevDirective,
		isStandalone: true,
		selector: "[mosaikWizardPrev]",
		host: { listeners: { "click": "onClick($event)" } },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: WizardPrevDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "[mosaikWizardPrev]" }]
	}],
	ctorParameters: () => [],
	propDecorators: { onClick: [{
		type: HostListener,
		args: ["click", ["$event"]]
	}] }
});
var SpacerDirective = class SpacerDirective {
	_el = inject(ElementRef);
	_renderer = inject(Renderer2);
	_multiplier = signal(void 0, ...ngDevMode ? [{ debugName: "_multiplier" }] : /* istanbul ignore next */ []);
	_size = signal(void 0, ...ngDevMode ? [{ debugName: "_size" }] : /* istanbul ignore next */ []);
	_thickness = signal(void 0, ...ngDevMode ? [{ debugName: "_thickness" }] : /* istanbul ignore next */ []);
	_invert = signal(void 0, ...ngDevMode ? [{ debugName: "_invert" }] : /* istanbul ignore next */ []);
	_multiplierValidator = signal(void 0, ...ngDevMode ? [{ debugName: "_multiplierValidator" }] : /* istanbul ignore next */ []);
	constructor() {
		const options = computed(() => ({
			multiplier: this._multiplier() ?? 8,
			size: this._size() ?? Size.Medium,
			thickness: this._thickness() ?? [],
			invert: this._invert() ?? false,
			multiplierValidator: this._multiplierValidator() ?? ((m) => !(m / 4 % 1))
		}), ...ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []);
		effect(() => {
			const { multiplier, size, thickness, invert, multiplierValidator } = options();
			if (!multiplierValidator(multiplier)) throw new Error("Invalid space multiplier.");
			const getDensityAsNumber = (s) => {
				switch (s) {
					case Size.Tiny: return 1;
					case Size.Small: return 2;
					case Size.Medium: return 3;
					case Size.Large: return 4;
					case Size.Giant: return 5;
					default: return 3;
				}
			};
			const parseSize = (sz) => `${sz}px`;
			const parseThickness = (t) => {
				if (!t) return [];
				if (Array.isArray(t)) return t;
				return [t];
			};
			const tryGetThickness = (keys, thicknessArr) => {
				let sizePx = multiplier * getDensityAsNumber(size);
				sizePx = invert ? -Math.abs(sizePx) : Math.abs(sizePx);
				for (const k of keys) if (thicknessArr.includes(k)) return parseSize(sizePx);
				return "0px";
			};
			const thicknessArr = parseThickness(thickness);
			this._renderer.setStyle(this._el.nativeElement, "margin-top", tryGetThickness([
				Spacing.Top,
				Spacing.Vertical,
				Spacing.All
			], thicknessArr));
			this._renderer.setStyle(this._el.nativeElement, "margin-right", tryGetThickness([
				Spacing.Right,
				Spacing.Horizontal,
				Spacing.All
			], thicknessArr));
			this._renderer.setStyle(this._el.nativeElement, "margin-bottom", tryGetThickness([
				Spacing.Bottom,
				Spacing.Vertical,
				Spacing.All
			], thicknessArr));
			this._renderer.setStyle(this._el.nativeElement, "margin-left", tryGetThickness([
				Spacing.Left,
				Spacing.Horizontal,
				Spacing.All
			], thicknessArr));
		});
	}
	get multiplier() {
		return this._multiplier();
	}
	set multiplier(value) {
		this._multiplier.set(value);
	}
	get size() {
		return this._size();
	}
	set size(value) {
		this._size.set(value);
	}
	get thickness() {
		return this._thickness();
	}
	set thickness(value) {
		this._thickness.set(value);
	}
	get invert() {
		return this._invert();
	}
	set invert(value) {
		this._invert.set(value);
	}
	get multiplierValidator() {
		return this._multiplierValidator();
	}
	set multiplierValidator(value) {
		this._multiplierValidator.set(value);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: SpacerDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: SpacerDirective,
		isStandalone: true,
		selector: "[mosaikSpacer]",
		inputs: {
			multiplier: ["mosaikSpacerMultiplier", "multiplier"],
			size: ["mosaikSpacerSize", "size"],
			thickness: ["mosaikSpacerThickness", "thickness"],
			invert: ["mosaikSpacerInvert", "invert"],
			multiplierValidator: ["mosaikSpacerMultiplierValidator", "multiplierValidator"]
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: SpacerDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "[mosaikSpacer]" }]
	}],
	ctorParameters: () => [],
	propDecorators: {
		multiplier: [{
			type: Input,
			args: ["mosaikSpacerMultiplier"]
		}],
		size: [{
			type: Input,
			args: ["mosaikSpacerSize"]
		}],
		thickness: [{
			type: Input,
			args: ["mosaikSpacerThickness"]
		}],
		invert: [{
			type: Input,
			args: ["mosaikSpacerInvert"]
		}],
		multiplierValidator: [{
			type: Input,
			args: ["mosaikSpacerMultiplierValidator"]
		}]
	}
});
var TextFormatterDirective = class TextFormatterDirective {
	_element = inject(ElementRef);
	_renderer = inject(Renderer2);
	_defaultFormatter;
	_formatterFn = computed(() => {
		const current = this.formatter();
		if (typeof current === "function") return current;
		if (typeof this._defaultFormatter === "function") return this._defaultFormatter;
		return TextFormatters.DEFAULT;
	}, ...ngDevMode ? [{ debugName: "_formatterFn" }] : /* istanbul ignore next */ []);
	_formattedText = computed(() => {
		return this._formatterFn()(this.value());
	}, ...ngDevMode ? [{ debugName: "_formattedText" }] : /* istanbul ignore next */ []);
	constructor() {
		const defaults = inject(TEXT_FORMATTER_DEFAULT_PROPS, { optional: true });
		this._defaultFormatter = this.resolveFormatter(defaults?.formatter ?? null);
		effect(() => {
			const html = this._formattedText();
			this._renderer.setProperty(this._element.nativeElement, "innerHTML", html);
		});
	}
	formatter = input(null, {
		...ngDevMode ? { debugName: "formatter" } : /* istanbul ignore next */ {},
		alias: "mosaikTextFormatter",
		transform: (value) => this.resolveFormatter(value)
	});
	value = input("", {
		...ngDevMode ? { debugName: "value" } : /* istanbul ignore next */ {},
		alias: "mosaikTextFormatterValue"
	});
	resolveFormatter(value) {
		if (typeof value === "function") return value;
		if (typeof value === "string") {
			for (const [key, formatter] of Object.entries(TextFormatters)) if (key.toLowerCase() === value.toLowerCase()) return formatter;
		}
		return null;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: TextFormatterDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: TextFormatterDirective,
		isStandalone: true,
		selector: "[mosaikTextFormatter]",
		inputs: {
			formatter: {
				classPropertyName: "formatter",
				publicName: "mosaikTextFormatter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "mosaikTextFormatterValue",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: TextFormatterDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "[mosaikTextFormatter]" }]
	}],
	ctorParameters: () => [],
	propDecorators: {
		formatter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mosaikTextFormatter",
				required: false
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mosaikTextFormatterValue",
				required: false
			}]
		}]
	}
});
const TEXT_FORMATTER_DEFAULT_PROPS = new InjectionToken("MOSAIK_TEXT_FORMATTER_DEFAULT_PROPS");
function provideTextFormatter(config) {
	return makeEnvironmentProviders([{
		provide: TEXT_FORMATTER_DEFAULT_PROPS,
		useValue: config
	}]);
}
var TypographyDirective = class TypographyDirective {
	_el = inject(ElementRef);
	_renderer = inject(Renderer2);
	_typography = signal(void 0, ...ngDevMode ? [{ debugName: "_typography" }] : /* istanbul ignore next */ []);
	_themeName = signal(void 0, ...ngDevMode ? [{ debugName: "_themeName" }] : /* istanbul ignore next */ []);
	constructor() {
		const document = inject(DOCUMENT);
		const typographyConfig = computed(() => {
			return {
				type: this._typography(),
				theme: this._themeName() ?? document.documentElement.getAttribute("theme") ?? void 0
			};
		}, ...ngDevMode ? [{ debugName: "typographyConfig" }] : /* istanbul ignore next */ []);
		effect(() => {
			const { type, theme } = typographyConfig();
			if (!type || !theme) return;
			this._renderer.setStyle(this._el.nativeElement, "font-family", `var(--${theme}-typography-${type}-font-family)`);
			this._renderer.setStyle(this._el.nativeElement, "font-size", `var(--${theme}-typography-${type}-font-size)`);
			this._renderer.setStyle(this._el.nativeElement, "line-height", `var(--${theme}-typography-${type}-line-height)`);
			this._renderer.setStyle(this._el.nativeElement, "font-weight", `var(--${theme}-typography-${type}-font-weight)`);
			this._renderer.setStyle(this._el.nativeElement, "letter-spacing", `var(--${theme}-typography-${type}-letter-spacing)`);
			this._renderer.setStyle(this._el.nativeElement, "text-decoration", `var(--${theme}-typography-${type}-text-decoration)`);
			this._renderer.setStyle(this._el.nativeElement, "text-transform", `var(--${theme}-typography-${type}-text-transform)`);
		});
	}
	get typography() {
		return this._typography();
	}
	set typography(type) {
		this._typography.set(type);
	}
	get themeName() {
		return this._themeName();
	}
	set themeName(value) {
		this._themeName.set(value?.trim());
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: TypographyDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "16.1.0",
		version: "22.2.3",
		type: TypographyDirective,
		isStandalone: true,
		selector: "[mosaikTypography]",
		inputs: {
			typography: [
				"mosaikTypography",
				"typography",
				(value) => value?.trim()
			],
			themeName: ["mosaikTypographyThemeName", "themeName"]
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: TypographyDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "[mosaikTypography]" }]
	}],
	ctorParameters: () => [],
	propDecorators: {
		typography: [{
			type: Input,
			args: [{
				alias: "mosaikTypography",
				transform: (value) => value?.trim()
			}]
		}],
		themeName: [{
			type: Input,
			args: ["mosaikTypographyThemeName"]
		}]
	}
});
var GlobalDomRef = class GlobalDomRef {
	_window;
	constructor() {
		this._window = window;
	}
	getWindow() {
		return this._window;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: GlobalDomRef,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: GlobalDomRef
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: GlobalDomRef,
	decorators: [{ type: Injectable }],
	ctorParameters: () => []
});
function provideGlobalDom() {
	return makeEnvironmentProviders([{
		provide: GlobalDomRef,
		useClass: GlobalDomRef
	}]);
}
var ReactiveFormValidator = class ReactiveFormValidator {
	constructor() {}
	validate(formGroup, hooks) {
		const issues = [];
		this.traverse(formGroup, "", {
			onControl: (ctrl) => {
				if (ctrl instanceof FormControl) ctrl.markAsTouched({ onlySelf: true });
				else if (ctrl instanceof FormArray) ctrl.controls.forEach((child) => child.markAsTouched({ onlySelf: true }));
			},
			onErrors: (issue) => {
				hooks?.onEachError?.(issue);
				issues.push(issue);
			}
		});
		if (issues.length === 0) hooks?.onSuccess?.(formGroup.getRawValue());
		else hooks?.onErrors?.(issues);
	}
	pristine(formGroup, hooks) {
		const issues = [];
		this.traverse(formGroup, "", {
			onControl: (ctrl) => {
				if (ctrl instanceof FormControl) ctrl.markAsPristine({ onlySelf: true });
				else if (ctrl instanceof FormArray) ctrl.controls.forEach((child) => child.markAsPristine({ onlySelf: true }));
			},
			onErrors: (issue) => {
				hooks?.onEachError?.(issue);
				issues.push(issue);
			}
		});
		if (issues.length === 0) hooks?.onSuccess?.(formGroup.getRawValue());
		else hooks?.onErrors?.(issues);
	}
	collectErrors(formGroup) {
		const issues = [];
		this.traverse(formGroup, "", {
			onControl: () => {},
			onErrors: (issue) => issues.push(issue)
		});
		return issues;
	}
	isValid(formGroup) {
		return this.collectErrors(formGroup).length === 0;
	}
	toPathMap(issues) {
		const map = Object.create(null);
		for (const i of issues) map[i.path] = i.errors;
		return map;
	}
	session(formGroup) {
		return new ReactiveValidationSession(this, formGroup);
	}
	traverse(control, path, hooks) {
		if (control.errors) hooks.onErrors({
			path,
			errors: control.errors
		});
		hooks.onControl(control, path);
		if (control instanceof FormGroup) Object.keys(control.controls).forEach((key) => {
			const child = control.get(key);
			const childPath = path ? `${path}.${key}` : key;
			this.traverse(child, childPath, hooks);
		});
		else if (control instanceof FormArray) control.controls.forEach((child, index) => {
			const childPath = `${path}[${index}]`;
			this.traverse(child, childPath, hooks);
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ReactiveFormValidator,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ReactiveFormValidator
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ReactiveFormValidator,
	decorators: [{ type: Injectable }],
	ctorParameters: () => []
});
var ReactiveValidationSession = class {
	_validator;
	_root;
	_touch;
	_pristine;
	_onErrors;
	_onEachError;
	_onSuccess;
	constructor(validator, root) {
		this._validator = validator;
		this._root = root;
		this._touch = false;
		this._pristine = false;
	}
	touch() {
		this._touch = true;
		return this;
	}
	pristine() {
		this._pristine = true;
		return this;
	}
	onEachError(cb) {
		this._onEachError = cb;
		return this;
	}
	onErrors(cb) {
		this._onErrors = cb;
		return this;
	}
	onSuccess(cb) {
		this._onSuccess = cb;
		return this;
	}
	run() {
		if (this._touch && !this._pristine) {
			this._validator.validate(this._root, {
				onErrors: this._onErrors,
				onEachError: this._onEachError,
				onSuccess: this._onSuccess
			});
			return;
		}
		if (this._pristine && !this._touch) {
			this._validator.pristine(this._root, {
				onErrors: this._onErrors,
				onEachError: this._onEachError,
				onSuccess: this._onSuccess
			});
			return;
		}
		const issues = this._validator.collectErrors(this._root);
		if (issues.length === 0) this._onSuccess?.();
		else {
			this._onEachError && issues.forEach(this._onEachError);
			this._onErrors?.(issues);
		}
		if (this._touch) this._validator.validate(this._root);
		if (this._pristine) this._validator.pristine(this._root);
	}
};
var SignalFormValidator = class SignalFormValidator {
	validate(form, hooks) {
		const issues = [];
		this.traverse(form, "", (path, state) => {
			state.markAsTouched();
			const errs = state.errors();
			if (errs.length > 0) {
				const issue = {
					path,
					errors: errs,
					fieldRef: state
				};
				hooks?.onEachError?.(issue);
				issues.push(issue);
			}
		});
		if (issues.length === 0) hooks?.onSuccess?.(form().value());
		else hooks?.onErrors?.(issues);
	}
	collectErrors(form) {
		const issues = [];
		this.traverse(form, "", (path, state) => {
			const errs = state.errors();
			if (errs.length > 0) issues.push({
				path,
				errors: errs,
				fieldRef: state
			});
		});
		return issues;
	}
	isValid(form) {
		return this.collectErrors(form).length === 0;
	}
	build(form) {
		return new SignalValidationBuilder(this, form);
	}
	traverse(tree, currentPath, callback) {
		const state = tree();
		callback(currentPath, state);
		const isArray = Array.isArray(state.value());
		for (const [key, child] of Object.entries(tree)) {
			if (child === void 0) continue;
			const nextPath = isArray ? `${currentPath}[${key}]` : currentPath ? `${currentPath}.${key}` : key;
			this.traverse(child, nextPath, callback);
		}
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: SignalFormValidator,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: SignalFormValidator
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: SignalFormValidator,
	decorators: [{ type: Injectable }]
});
var SignalValidationBuilder = class {
	_validator;
	_form;
	_onEachError;
	_onErrors;
	_onSuccess;
	constructor(validator, form) {
		this._validator = validator;
		this._form = form;
	}
	onEachError(cb) {
		this._onEachError = cb;
		return this;
	}
	onErrors(cb) {
		this._onErrors = cb;
		return this;
	}
	onSuccess(cb) {
		this._onSuccess = cb;
		return this;
	}
	run() {
		this._validator.validate(this._form, {
			onEachError: this._onEachError,
			onErrors: this._onErrors,
			onSuccess: this._onSuccess
		});
	}
};
function provideForms() {
	return makeEnvironmentProviders([{
		provide: ReactiveFormValidator,
		useClass: ReactiveFormValidator
	}, {
		provide: SignalFormValidator,
		useClass: SignalFormValidator
	}]);
}
var Validators = class {
	static numeric() {
		const fn = (control) => {
			if (control.pristine || control.value === null || !Number.isNaN(+control.value)) return null;
			control.markAsTouched();
			return {
				numeric: false,
				actualValue: control.value
			};
		};
		return fn;
	}
	static equalsTo(other) {
		const fn = (control) => {
			const otherValue = typeof other === "function" ? other() : other;
			if (control.value === otherValue) return null;
			control.markAsTouched();
			return {
				equalsTo: false,
				actualValue: control.value
			};
		};
		return fn;
	}
	static blank() {
		const fn = (control) => {
			if ((/* @__PURE__ */ new RegExp("\\s")).test(control.value)) return { blank: true };
			control.markAsTouched();
			return { blank: false };
		};
		return fn;
	}
	static emailEndsWithDomain(domains) {
		const pattern = `^\w+([-+.']\w+)*@?(${domains.join("|")})$`;
		const regex = new RegExp(pattern);
		return (control) => {
			if (control.value === null || control.value.length === 0) return null;
			return regex.test(control.value) ? null : { emailEndsWithDomain: {
				requiredDomains: domains,
				actualValue: control.value
			} };
		};
	}
	static phoneNumber() {
		const regex = /* @__PURE__ */ new RegExp("^[+]*[(]{0,1}[0-9]{1,4}[)]{0,1}[-s./0-9]*$");
		return (control) => {
			if (control.value === null || control.value.length === 0) return null;
			return regex.test(control.value) ? null : { phoneNumber: false };
		};
	}
};
function getOption(opt, ctx) {
	return opt instanceof Function ? opt(ctx) : opt;
}
function isComparableDate(value) {
	return value instanceof Date && !Number.isNaN(value.getTime());
}
function numeric(path, config) {
	validate(path, (ctx) => {
		const value = ctx.value();
		if (value === null || value === void 0 || !Number.isNaN(+value)) return null;
		if (config?.error) return getOption(config.error, ctx);
		return {
			kind: "numeric",
			actualValue: value,
			message: typeof config?.message === "function" ? config.message(ctx) : config?.message
		};
	});
}
function equalsTo(path, other, config) {
	validate(path, (ctx) => {
		const value = ctx.value();
		const otherValue = typeof other === "function" ? other() : other;
		if (value === otherValue) return null;
		if (config?.error) return getOption(config.error, ctx);
		return {
			kind: "equalsTo",
			actualValue: value,
			other: otherValue,
			message: typeof config?.message === "function" ? config.message(ctx) : config?.message
		};
	});
}
function dateNotBefore(path, minDate, config) {
	validate(path, (context) => {
		const value = context.value();
		const minDateValue = getOption(minDate, context);
		if (value === null || minDateValue === null || minDateValue === void 0 || !isComparableDate(minDateValue)) return null;
		if (isComparableDate(value) && value.getTime() >= minDateValue.getTime()) return null;
		if (config?.error) return getOption(config.error, context);
		return {
			kind: "dateNotBefore",
			actualValue: value,
			minDate: minDateValue,
			message: getOption(config?.message, context)
		};
	});
}
function dateNotAfter(path, maxDate, config) {
	validate(path, (context) => {
		const value = context.value();
		const maxDateValue = getOption(maxDate, context);
		if (value === null || maxDateValue === null || maxDateValue === void 0 || !isComparableDate(maxDateValue)) return null;
		if (isComparableDate(value) && value.getTime() <= maxDateValue.getTime()) return null;
		if (config?.error) return getOption(config.error, context);
		return {
			kind: "dateNotAfter",
			actualValue: value,
			maxDate: maxDateValue,
			message: getOption(config?.message, context)
		};
	});
}
function blank(path, config) {
	validate(path, (ctx) => {
		const value = ctx.value();
		if (!(typeof value === "string" && /\s/.test(value))) return null;
		if (config?.error) return getOption(config.error, ctx);
		return {
			kind: "blank",
			actualValue: value,
			message: typeof config?.message === "function" ? config.message(ctx) : config?.message
		};
	});
}
function emailEndsWithDomain(path, domains, config) {
	const pattern = `^\\w+([-.']\\w+)*@(?:(${domains.join("|")}))$`;
	const regex = new RegExp(pattern);
	validate(path, (ctx) => {
		const value = ctx.value();
		if (typeof value === "string" && value.length === 0) return null;
		if (regex.test(value)) return null;
		if (config?.error) return getOption(config.error, ctx);
		return {
			kind: "emailEndsWithDomain",
			requiredDomains: domains,
			actualValue: value
		};
	});
}
function phoneNumber(path, config) {
	const regex = /* @__PURE__ */ new RegExp("^[+]*[(]{0,1}[0-9]{1,4}[)]{0,1}[-\\s\\.\\/0-9]*$");
	validate(path, (ctx) => {
		const value = ctx.value();
		if (typeof value === "string" && value.length === 0) return null;
		if (regex.test(value)) return null;
		if (config?.error) return getOption(config.error, ctx);
		return {
			kind: "phoneNumber",
			actualValue: value
		};
	});
}
var IconDirective = class IconDirective {
	_element = inject(ElementRef).nativeElement;
	name = "";
	ngOnChanges(changes) {
		if ("name" in changes) this._element.icon = this.name?.trim() ?? "";
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: IconDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: IconDirective,
		isStandalone: true,
		selector: "mosaik-icon[name]",
		inputs: { name: "name" },
		usesOnChanges: true,
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: IconDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "mosaik-icon[name]" }]
	}],
	propDecorators: { name: [{ type: Input }] }
});
var IconNameDirective = class IconNameDirective {
	_element = inject(ElementRef).nativeElement;
	iconName = "";
	ngOnChanges(changes) {
		if ("iconName" in changes) this._element.icon = this.iconName?.trim() ?? "";
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: IconNameDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: IconNameDirective,
		isStandalone: true,
		selector: "\n        mosaik-avatar[iconName],\n        mosaik-badge[iconName],\n        mosaik-banner[iconName],\n        mosaik-busy-state[iconName],\n        mosaik-button[iconName],\n        mosaik-chat-marker[iconName],\n        mosaik-chat-message-avatar[iconName],\n        mosaik-chip[iconName],\n        mosaik-choice[iconName],\n        mosaik-combo-item[iconName],\n        mosaik-compound-button[iconName],\n        mosaik-dropdown-button[iconName],\n        mosaik-empty-state[iconName],\n        mosaik-error-state[iconName],\n        mosaik-expander[iconName],\n        mosaik-fab-group[iconName],\n        mosaik-fab[iconName],\n        mosaik-icon[iconName],\n        mosaik-menu-item[iconName],\n        mosaik-message-box[iconName],\n        mosaik-message[iconName],\n        mosaik-persona[iconName],\n        mosaik-pip[iconName],\n        mosaik-press-button[iconName],\n        mosaik-repeat-button[iconName],\n        mosaik-ribbon[iconName],\n        mosaik-segment-item[iconName],\n        mosaik-select-item[iconName],\n        mosaik-sheet[iconName],\n        mosaik-split-button[iconName],\n        mosaik-stepper-item[iconName],\n        mosaik-success-state[iconName],\n        mosaik-tab-item[iconName],\n        mosaik-tab-strip-item[iconName],\n        mosaik-timeline-marker[iconName],\n        mosaik-titlebar[iconName],\n        mosaik-toast[iconName],\n        mosaik-toggle-button[iconName],\n        mosaik-updown-spinner[iconName]\n    ",
		inputs: { iconName: "iconName" },
		usesOnChanges: true,
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: IconNameDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: `
        mosaik-avatar[iconName],
        mosaik-badge[iconName],
        mosaik-banner[iconName],
        mosaik-busy-state[iconName],
        mosaik-button[iconName],
        mosaik-chat-marker[iconName],
        mosaik-chat-message-avatar[iconName],
        mosaik-chip[iconName],
        mosaik-choice[iconName],
        mosaik-combo-item[iconName],
        mosaik-compound-button[iconName],
        mosaik-dropdown-button[iconName],
        mosaik-empty-state[iconName],
        mosaik-error-state[iconName],
        mosaik-expander[iconName],
        mosaik-fab-group[iconName],
        mosaik-fab[iconName],
        mosaik-icon[iconName],
        mosaik-menu-item[iconName],
        mosaik-message-box[iconName],
        mosaik-message[iconName],
        mosaik-persona[iconName],
        mosaik-pip[iconName],
        mosaik-press-button[iconName],
        mosaik-repeat-button[iconName],
        mosaik-ribbon[iconName],
        mosaik-segment-item[iconName],
        mosaik-select-item[iconName],
        mosaik-sheet[iconName],
        mosaik-split-button[iconName],
        mosaik-stepper-item[iconName],
        mosaik-success-state[iconName],
        mosaik-tab-item[iconName],
        mosaik-tab-strip-item[iconName],
        mosaik-timeline-marker[iconName],
        mosaik-titlebar[iconName],
        mosaik-toast[iconName],
        mosaik-toggle-button[iconName],
        mosaik-updown-spinner[iconName]
    ` }]
	}],
	propDecorators: { iconName: [{ type: Input }] }
});
var IconRegistry = class IconRegistry {
	get sets() {
		return IconRegistry$1.instance.sets;
	}
	get defaultSet() {
		return IconRegistry$1.instance.defaultSet;
	}
	register(icons) {
		IconRegistry$1.instance.register(icons);
	}
	registerSet(set, icons) {
		IconRegistry$1.instance.registerSet(set, icons);
	}
	setDefaultSet(set) {
		IconRegistry$1.instance.setDefaultSet(set);
	}
	setLoader(loader) {
		IconRegistry$1.instance.setLoader(loader);
	}
	resolve(name) {
		return IconRegistry$1.instance.resolve(name);
	}
	get(name) {
		if (!name) throw new Error("[IconRegistry]: Icon name must be provided.");
		const definition = this.resolve(name);
		if (!definition) throw new Error(`[IconRegistry]: Icon with name "${name}" is not registered.`);
		return definition.body;
	}
	subscribe(listener) {
		return IconRegistry$1.instance.subscribe(listener);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: IconRegistry,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: IconRegistry,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: IconRegistry,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
var IconPipe = class IconPipe {
	_registry = inject(IconRegistry);
	transform(value) {
		const name = value?.trim();
		return name ? this._registry.get(name) : "";
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: IconPipe,
		deps: [],
		target: i0.ɵɵFactoryTarget.Pipe
	});
	static ɵpipe = i0.ɵɵngDeclarePipe({
		minVersion: "14.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: IconPipe,
		isStandalone: true,
		name: "icon"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: IconPipe,
	decorators: [{
		type: Pipe,
		args: [{ name: "icon" }]
	}]
});
function provideIcons(icons) {
	return makeEnvironmentProviders([provideEnvironmentInitializer(() => {
		IconRegistry$1.instance.register(icons);
	})]);
}
function provideIconRegistry(config) {
	return provideIcons(config?.icons ?? {});
}
function provideIconSet(set, icons) {
	return makeEnvironmentProviders([provideEnvironmentInitializer(() => {
		IconRegistry$1.instance.registerSet(set, icons);
	})]);
}
function provideDefaultIconSet(set) {
	return makeEnvironmentProviders([provideEnvironmentInitializer(() => {
		IconRegistry$1.instance.setDefaultSet(set);
	})]);
}
function provideIconLoader(loader) {
	return makeEnvironmentProviders([provideEnvironmentInitializer(() => {
		IconRegistry$1.instance.setLoader(loader);
	})]);
}
var LocaleDirective = class LocaleDirective {
	_destroyRef = inject(DestroyRef);
	_elementRef = inject(ElementRef);
	_fallbackLocale = inject(LOCALE_ID);
	_translateService = inject(TranslateService, { optional: true });
	constructor() {
		this._elementRef.nativeElement.locale = this._translateService?.currentLanguage || this._fallbackLocale;
		this._translateService?.languageChanged.pipe(takeUntilDestroyed(this._destroyRef)).subscribe((locale) => {
			this._elementRef.nativeElement.locale = locale || this._fallbackLocale;
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: LocaleDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: LocaleDirective,
		isStandalone: true,
		selector: "\n        mosaik-calendar,\n        mosaik-calendar-days-view,\n        mosaik-calendar-months-view,\n        mosaik-calendar-years-view,\n        mosaik-datebox,\n        mosaik-datetimebox,\n        mosaik-epg,\n        mosaik-epg-channel,\n        mosaik-epg-program,\n        mosaik-epg-timeline,\n        mosaik-scheduler,\n        mosaik-scheduler-agenda-view,\n        mosaik-scheduler-datescale,\n        mosaik-scheduler-month-view,\n        mosaik-scheduler-time-grid-view,\n        mosaik-scheduler-timescale,\n        mosaik-timebox\n    ",
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: LocaleDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: `
        mosaik-calendar,
        mosaik-calendar-days-view,
        mosaik-calendar-months-view,
        mosaik-calendar-years-view,
        mosaik-datebox,
        mosaik-datetimebox,
        mosaik-epg,
        mosaik-epg-channel,
        mosaik-epg-program,
        mosaik-epg-timeline,
        mosaik-scheduler,
        mosaik-scheduler-agenda-view,
        mosaik-scheduler-datescale,
        mosaik-scheduler-month-view,
        mosaik-scheduler-time-grid-view,
        mosaik-scheduler-timescale,
        mosaik-timebox
    ` }]
	}],
	ctorParameters: () => []
});
var PromptBoxContentDirective = class PromptBoxContentDirective {
	constructor() {
		const elementRef = inject(ElementRef);
		inject(Renderer2).setAttribute(elementRef.nativeElement, "slot", "content");
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: PromptBoxContentDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: PromptBoxContentDirective,
		isStandalone: true,
		selector: "[mosaikPromptBoxContent]",
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: PromptBoxContentDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "[mosaikPromptBoxContent]" }]
	}],
	ctorParameters: () => []
});
const PROMPT_BOX = new InjectionToken("PROMPT_BOX");
var PromptBoxDirective = class PromptBoxDirective {
	_elementRef;
	constructor() {
		this._elementRef = inject(ElementRef);
	}
	get element() {
		return this._elementRef.nativeElement;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: PromptBoxDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: PromptBoxDirective,
		isStandalone: true,
		selector: "mosaik-prompt-box[mosaikPromptBox], mosaik-chat-prompt-box[mosaikPromptBox]",
		providers: [{
			provide: PROMPT_BOX,
			useFactory: () => inject(ElementRef).nativeElement
		}],
		exportAs: ["mosaikPromptBox"],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: PromptBoxDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "mosaik-prompt-box[mosaikPromptBox], mosaik-chat-prompt-box[mosaikPromptBox]",
			exportAs: "mosaikPromptBox",
			providers: [{
				provide: PROMPT_BOX,
				useFactory: () => inject(ElementRef).nativeElement
			}]
		}]
	}],
	ctorParameters: () => []
});
var PromptBoxToolDirective = class PromptBoxToolDirective {
	_changeDetectorRef = inject(ChangeDetectorRef);
	_elementRef = inject(ElementRef);
	_onPromptBoxStateChanged = () => this._changeDetectorRef.markForCheck();
	_promptBox = inject(PROMPT_BOX);
	_renderer = inject(Renderer2);
	_registeredTool;
	_unregister;
	constructor() {
		this._renderer.setAttribute(this._elementRef.nativeElement, "slot", "tools");
		this._promptBox.addEventListener("input", this._onPromptBoxStateChanged);
		this._promptBox.addEventListener("entriesChanged", this._onPromptBoxStateChanged);
		this._promptBox.addEventListener("changed", this._onPromptBoxStateChanged);
	}
	tool;
	get hostDisabled() {
		if (!this._registeredTool || this._registeredTool === this._elementRef.nativeElement) return this.isPromptBoxTool(this._elementRef.nativeElement) ? this._elementRef.nativeElement.disabled : false;
		return this._registeredTool.disabled || this._registeredTool.disabledWhen?.(this._promptBox) === true;
	}
	ngOnChanges(_changes) {
		this._unregister?.();
		this._registeredTool = void 0;
		this._unregister = void 0;
		const tool = this.isPromptBoxTool(this.tool) ? this.tool : this.isPromptBoxTool(this._elementRef.nativeElement) ? this._elementRef.nativeElement : void 0;
		if (tool) {
			this._registeredTool = tool;
			this._unregister = this._promptBox.registerTool(tool);
		}
	}
	ngOnDestroy() {
		this._unregister?.();
		this._promptBox.removeEventListener("input", this._onPromptBoxStateChanged);
		this._promptBox.removeEventListener("entriesChanged", this._onPromptBoxStateChanged);
		this._promptBox.removeEventListener("changed", this._onPromptBoxStateChanged);
		this._registeredTool = void 0;
		this._unregister = void 0;
	}
	isPromptBoxTool(value) {
		const candidate = value;
		return typeof candidate?.disabled === "boolean" && typeof candidate.attach === "function" && typeof candidate.detach === "function" && typeof candidate.execute === "function";
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: PromptBoxToolDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: PromptBoxToolDirective,
		isStandalone: true,
		selector: "[mosaikPromptBoxTool]",
		inputs: { tool: ["mosaikPromptBoxTool", "tool"] },
		host: { properties: { "disabled": "this.hostDisabled" } },
		usesOnChanges: true,
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: PromptBoxToolDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "[mosaikPromptBoxTool]" }]
	}],
	ctorParameters: () => [],
	propDecorators: {
		tool: [{
			type: Input,
			args: ["mosaikPromptBoxTool"]
		}],
		hostDisabled: [{
			type: HostBinding,
			args: ["disabled"]
		}]
	}
});
var DialogBehavior = class {
	_ref;
	_attached;
	_dialogConfig;
	constructor() {
		this._ref = null;
		this._attached = false;
		this._dialogConfig = null;
	}
	get ref() {
		if (!this._attached) throw new Error("Must be attached before use the element property.");
		return this._ref;
	}
	get config() {
		return this._dialogConfig;
	}
	configure(config) {
		this._dialogConfig = config;
	}
	attach(element, _portal) {
		this._ref = element;
		this._attached = true;
	}
	detach(ref) {
		this._attached = false;
	}
};
const DIALOG_BREAKPOINT_BEHAVIOR_CONFIG = new InjectionToken("DIALOG_BREAKPOINT_OBSERVER_BEHAVIOR_CONFIG");
var DialogBreakpointBehavior = class extends DialogBehavior {
	_breakpointObserver;
	_breakpointRegistry;
	_config;
	_mediaQueryToAliasMap;
	_subscription;
	constructor(config = inject(DIALOG_BREAKPOINT_BEHAVIOR_CONFIG, { optional: true })) {
		super();
		this._breakpointObserver = inject(BreakpointObserver);
		this._breakpointRegistry = inject(BreakpointRegistry);
		this._config = config;
		this._mediaQueryToAliasMap = /* @__PURE__ */ new Map();
		this._subscription = Subscription.EMPTY;
	}
	attach(dialogRef, _portal) {
		if (this._config?.breakpoints.length) {
			this._mediaQueryToAliasMap.clear();
			const breakpoints = this._config.breakpoints.map((x) => {
				const breakpoint = this._breakpointRegistry.findByAlias(x.breakpoint);
				if (breakpoint?.mediaQuery) this._mediaQueryToAliasMap.set(breakpoint.mediaQuery, x.breakpoint);
				return breakpoint?.mediaQuery;
			}).filter((x) => x !== void 0);
			this._subscription = this._breakpointObserver.observe(breakpoints).subscribe((x) => this.onBreakpoint(x, dialogRef, this.config ?? void 0));
		}
	}
	detach(_ref) {
		this._subscription.unsubscribe();
	}
	onBreakpoint(state, dialogRef, config) {
		if (!config?.isFullScreen) {
			if (state.matches) Object.entries(state.breakpoints).forEach(([mediaQuery, match]) => {
				if (match) {
					const alias = this._mediaQueryToAliasMap.get(mediaQuery);
					const breakpointConfig = alias ? this._config?.breakpoints.find((x) => x.breakpoint === alias) ?? null : null;
					dialogRef.updateSize({
						width: breakpointConfig?.size.width,
						height: breakpointConfig?.size.height
					});
					dialogRef.component.setInput("isFullScreen", true);
				}
			});
			else {
				dialogRef.updateSize({
					width: config?.size?.width,
					height: config?.size?.height
				});
				dialogRef.component.setInput("isFullScreen", false);
			}
		}
	}
};
const DIALOG_STACK_BEHAVIOR_CONFIG = new InjectionToken("DIALOG_STACK_BEHAVIOR_CONFIG");
var DialogStackBehavior = class extends DialogBehavior {
	_stack;
	_config;
	constructor(config = inject(DIALOG_STACK_BEHAVIOR_CONFIG, { optional: true })) {
		super();
		this._config = {
			...DIALOG_STACK_BEHAVIOR_DEFAULT_CONFIG,
			...config
		};
		this._stack = new Array();
	}
	get stackSize() {
		return this._stack.length;
	}
	get stackConfig() {
		return this._config;
	}
	attach(dialogRef, portal) {
		super.attach(dialogRef, portal);
		if (this._config.maxStackDepth !== void 0 && this._stack.length >= this._config.maxStackDepth) throw new Error(`Cannot open dialog: maximum stack depth (${this._config.maxStackDepth}) reached.`);
		const stackLevel = this._stack.length;
		this.updateStackOffsets();
		this._stack.push({
			ref: dialogRef,
			portal
		});
		this.applyStackStyles(dialogRef, stackLevel, 0);
		this.applyStackedClasses();
	}
	detach(ref) {
		super.detach(ref);
		if (this._stack.length === 0) return;
		let indexToRemove;
		if (ref) {
			indexToRemove = this._stack.findIndex((entry) => entry.ref.id === ref.id);
			if (indexToRemove === -1) return;
		} else indexToRemove = this._stack.length - 1;
		this._stack.splice(indexToRemove, 1);
		this.recalculateStackOffsets();
		this.applyStackedClasses();
	}
	calculateZIndex(stackLevel) {
		return 1e3 + stackLevel * this._config.zIndexIncrement;
	}
	calculateOffset(offsetFromTop) {
		if (offsetFromTop === 0) return 0;
		return -(offsetFromTop * this._config.stackIndicatorOffset);
	}
	applyStackStyles(dialogRef, stackLevel, offsetY) {
		dialogRef.element.setAttribute("data-stack-level", String(stackLevel));
		dialogRef.element.setAttribute("data-stack-offset", String(offsetY));
		dialogRef.element.style.setProperty("--dialog-stack-level", String(stackLevel));
		dialogRef.element.style.setProperty("--dialog-z-index", String(this.calculateZIndex(stackLevel)));
		requestAnimationFrame(() => {
			dialogRef.element.style.setProperty("--dialog-stack-offset", `${offsetY}px`);
		});
	}
	updateStackOffsets() {
		const stackLength = this._stack.length;
		for (let i = 0; i < stackLength; i++) {
			const entry = this._stack[i];
			const offsetFromTop = stackLength - i;
			const offsetY = this.calculateOffset(offsetFromTop);
			this.applyStackStyles(entry.ref, i, offsetY);
		}
	}
	recalculateStackOffsets() {
		const stackLength = this._stack.length;
		for (let i = 0; i < stackLength; i++) {
			const entry = this._stack[i];
			const offsetFromTop = stackLength - 1 - i;
			const offsetY = this.calculateOffset(offsetFromTop);
			this.applyStackStyles(entry.ref, i, offsetY);
		}
	}
	applyStackedClasses() {
		for (let i = 0; i < this._stack.length; i++) {
			const entry = this._stack[i];
			if (i === this._stack.length - 1) entry.ref.element.classList.remove("mosaik-dialog-stacked");
			else entry.ref.element.classList.add("mosaik-dialog-stacked");
		}
	}
};
var OfPipe = class OfPipe {
	transform(value) {
		return isObservable(value) ? value : of(value);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: OfPipe,
		deps: [],
		target: i0.ɵɵFactoryTarget.Pipe
	});
	static ɵpipe = i0.ɵɵngDeclarePipe({
		minVersion: "14.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: OfPipe,
		isStandalone: true,
		name: "of"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: OfPipe,
	decorators: [{
		type: Pipe,
		args: [{ name: "of" }]
	}]
});
const OVERLAY_INTERACTION_STATE = getOverlayInteractionState();
var OverlayInteractionCoordinator = class OverlayInteractionCoordinator {
	static register(overlayRef) {
		const focusTrap = OverlayInteractionCoordinator.findEntry(overlayRef)?.focusTrap ?? null;
		OverlayInteractionCoordinator.remove(overlayRef);
		OVERLAY_INTERACTION_STATE.entries.push({
			overlayRef,
			order: ++OVERLAY_INTERACTION_STATE.order,
			focusTrap
		});
		OverlayInteractionCoordinator.updateFocusTrapStates();
	}
	static unregister(overlayRef) {
		OverlayInteractionCoordinator.remove(overlayRef);
		OverlayInteractionCoordinator.updateFocusTrapStates();
	}
	static registerFocusTrap(overlayRef, focusTrap) {
		let entry = OverlayInteractionCoordinator.findEntry(overlayRef);
		if (!entry) {
			entry = {
				overlayRef,
				order: ++OVERLAY_INTERACTION_STATE.order,
				focusTrap: null
			};
			OVERLAY_INTERACTION_STATE.entries.push(entry);
		}
		entry.focusTrap = focusTrap;
		OverlayInteractionCoordinator.updateFocusTrapStates();
	}
	static unregisterFocusTrap(overlayRef) {
		const entry = OverlayInteractionCoordinator.findEntry(overlayRef);
		if (entry) {
			if (entry.focusTrap) entry.focusTrap.enabled = false;
			entry.focusTrap = null;
		}
		OverlayInteractionCoordinator.updateFocusTrapStates();
	}
	static isTopMost(overlayRef) {
		return OverlayInteractionCoordinator.getTopMostOverlayRef() === overlayRef;
	}
	static isTopMostForInteraction(overlayRef, event) {
		return OverlayInteractionCoordinator.getOrCreateInteractionOwner(event) === overlayRef;
	}
	static remove(overlayRef) {
		const index = OVERLAY_INTERACTION_STATE.entries.findIndex((entry) => entry.overlayRef === overlayRef);
		if (index >= 0) {
			const entry = OVERLAY_INTERACTION_STATE.entries[index];
			if (entry.focusTrap) entry.focusTrap.enabled = false;
			OVERLAY_INTERACTION_STATE.entries.splice(index, 1);
		}
	}
	static getOrCreateInteractionOwner(event) {
		if (!OVERLAY_INTERACTION_STATE.eventOwners.has(event)) OVERLAY_INTERACTION_STATE.eventOwners.set(event, OverlayInteractionCoordinator.getTopMostOverlayRef());
		return OVERLAY_INTERACTION_STATE.eventOwners.get(event) ?? null;
	}
	static findEntry(overlayRef) {
		return OVERLAY_INTERACTION_STATE.entries.find((entry) => entry.overlayRef === overlayRef) ?? null;
	}
	static getTopMostOverlayRef() {
		let topMostEntry = null;
		for (const entry of OVERLAY_INTERACTION_STATE.entries) if (entry.overlayRef.hasAttached() && (!topMostEntry || entry.order > topMostEntry.order)) topMostEntry = entry;
		return topMostEntry?.overlayRef ?? null;
	}
	static getTopMostFocusTrapOverlayRef() {
		let topMostEntry = null;
		for (const entry of OVERLAY_INTERACTION_STATE.entries) if (entry.focusTrap && entry.overlayRef.hasAttached() && (!topMostEntry || entry.order > topMostEntry.order)) topMostEntry = entry;
		return topMostEntry?.overlayRef ?? null;
	}
	static updateFocusTrapStates() {
		const topMostOverlayRef = OverlayInteractionCoordinator.getTopMostFocusTrapOverlayRef();
		for (const entry of OVERLAY_INTERACTION_STATE.entries) if (entry.focusTrap) entry.focusTrap.enabled = entry.overlayRef === topMostOverlayRef;
	}
};
function getOverlayInteractionState() {
	const root = globalThis;
	root.__mosaikOverlayInteractionState__ ??= {
		entries: new Array(),
		eventOwners: /* @__PURE__ */ new WeakMap(),
		order: 0
	};
	return root.__mosaikOverlayInteractionState__;
}
const PORTAL_OVERLAY_REF = new InjectionToken("MOSAIK_PORTAL_OVERLAY_REF");
var PortalComponent = class PortalComponent extends BasePortalOutlet {
	_element;
	_focusTrapFactory;
	_document;
	_overlayRef;
	_focusTrap;
	_elementFocusedBeforeOpened;
	constructor() {
		super();
		this._element = inject(ElementRef);
		this._focusTrapFactory = inject(ConfigurableFocusTrapFactory);
		this._document = inject(DOCUMENT);
		this._overlayRef = inject(PORTAL_OVERLAY_REF, { optional: true });
		this._focusTrap = null;
		this._elementFocusedBeforeOpened = null;
		this._element.nativeElement.setAttribute(MOSAIK_PORTAL_SCOPE_ATTRIBUTE, "");
		this._element.nativeElement.tabIndex = -1;
	}
	get managesFocus() {
		return true;
	}
	ngOnInit() {
		this.trapFocus();
	}
	ngOnDestroy() {
		this.restoreFocus();
	}
	attachComponentPortal(portal) {
		this.savePreviouslyFocusedElement();
		const componentRef = this.portal.attachComponentPortal(portal);
		this.trapFocus();
		return componentRef;
	}
	attachTemplatePortal(portal) {
		this.savePreviouslyFocusedElement();
		const embeddedViewRef = this.portal.attachTemplatePortal(portal);
		this.trapFocus();
		return embeddedViewRef;
	}
	trapFocus() {
		if (!this.managesFocus) return;
		const element = this._element.nativeElement;
		this._focusTrap ??= this._focusTrapFactory.create(element);
		if (this._overlayRef) OverlayInteractionCoordinator.registerFocusTrap(this._overlayRef, this._focusTrap);
		const focusPromise = this._focusTrap.focusInitialElementWhenReady();
		const activeElement = this._document.activeElement;
		if (activeElement !== element && !element.contains(activeElement)) {
			element.focus();
			this.focusFirstTabbableDescendant(element);
		}
		focusPromise.then((focused) => {
			if (!this._focusTrap || !element.isConnected) return;
			if (!focused || this._document.activeElement === element || !element.contains(this._document.activeElement)) this.focusFirstTabbableDescendant(element);
		});
	}
	restoreFocus() {
		if (!this.managesFocus) return;
		const toFocus = this._elementFocusedBeforeOpened;
		if (this._overlayRef) OverlayInteractionCoordinator.unregisterFocusTrap(this._overlayRef);
		if (toFocus && typeof toFocus.focus === "function") toFocus.focus();
		if (this._focusTrap) {
			this._focusTrap.destroy();
			this._focusTrap = null;
		}
	}
	savePreviouslyFocusedElement() {
		if (!this.managesFocus) return;
		this._elementFocusedBeforeOpened = this._document.activeElement;
		if (this._element.nativeElement.focus) Promise.resolve().then(() => this._element.nativeElement.focus());
	}
	focusFirstTabbableDescendant(element) {
		this.findFirstTabbableDescendant(element)?.focus();
	}
	findFirstTabbableDescendant(element) {
		for (const child of Array.from(element.children)) {
			if (!(child instanceof HTMLElement)) continue;
			if (this.isTabbable(child)) return child;
			const descendant = this.findFirstTabbableDescendant(child);
			if (descendant) return descendant;
		}
		return null;
	}
	isTabbable(element) {
		if (element.tabIndex < 0 || element.hidden || element.hasAttribute("disabled") || element.getAttribute("aria-hidden") === "true") return false;
		return element.getClientRects().length > 0;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: PortalComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: PortalComponent,
		isStandalone: true,
		usesInheritance: true,
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: PortalComponent,
	decorators: [{ type: Directive }],
	ctorParameters: () => []
});
const DIALOG_CONFIG = new InjectionToken("MOSAIK_DIALOG_CONFIG");
const DIALOG_REF = new InjectionToken("MOSAIK_DIALOG_REF");
const DIALOG_REF_DATA = new InjectionToken("MOSAIK_DIALOG_REF_DATA");
const DIALOG_BEHAVIORS = new InjectionToken("MOSAIK_DIALOG_BEHAVIORS");
const DIALOG_SLOTS = new InjectionToken("MOSAIK_DIALOG_SLOTS");
function provideDialogSlots() {
	return {
		provide: DIALOG_SLOTS,
		useFactory: () => {
			const header = signal(null, ...ngDevMode ? [{ debugName: "header" }] : /* istanbul ignore next */ []);
			const content = signal(null, ...ngDevMode ? [{ debugName: "content" }] : /* istanbul ignore next */ []);
			const actions = signal(null, ...ngDevMode ? [{ debugName: "actions" }] : /* istanbul ignore next */ []);
			const footer = signal(null, ...ngDevMode ? [{ debugName: "footer" }] : /* istanbul ignore next */ []);
			return {
				header: header.asReadonly(),
				content: content.asReadonly(),
				actions: actions.asReadonly(),
				footer: footer.asReadonly(),
				setHeader: (t) => header.set(t),
				setContent: (t) => content.set(t),
				setActions: (t) => actions.set(t),
				setFooter: (t) => footer.set(t)
			};
		}
	};
}
var DialogPortalComponent = class DialogPortalComponent extends PortalComponent {
	_portal;
	_component;
	_config;
	_slots;
	_warnedHeader;
	_warnedActions;
	constructor() {
		super();
		this._config = inject(DIALOG_CONFIG, { optional: true }) ?? void 0;
		this._slots = inject(DIALOG_SLOTS);
		this._warnedHeader = false;
		this._warnedActions = false;
		effect(() => {
			const hasHeaderTemplate = this._slots.header() !== null;
			const hasHeaderConfig = Boolean(this._config?.header) || Boolean(this._config?.subheader);
			if (hasHeaderTemplate && hasHeaderConfig && !this._warnedHeader) {
				console.warn("[DialogPortalComponent] Header template provided while dialogConfig.header/subheader is set. The template takes precedence.");
				this._warnedHeader = true;
			}
			const hasActionsTemplate = this._slots.actions() !== null;
			const actions = this._config?.actions;
			const hasActionsConfig = Array.isArray(actions) && actions.length > 0;
			if (hasActionsTemplate && hasActionsConfig && !this._warnedActions) {
				console.warn("[DialogPortalComponent] Actions template provided while dialogConfig.actions is set. The template takes precedence.");
				this._warnedActions = true;
			}
		});
	}
	get dialog() {
		return this._component;
	}
	get dialogConfig() {
		return this._config;
	}
	get portal() {
		return this._portal;
	}
	get headerTemplate() {
		return this._slots.header();
	}
	get actionsTemplate() {
		return this._slots.actions();
	}
	get footerTemplate() {
		return this._slots.footer();
	}
	get contentTemplate() {
		return this._slots.content();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DialogPortalComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: DialogPortalComponent,
		isStandalone: true,
		selector: "mosaik-dialog-portal",
		host: { classAttribute: "dialog-portal" },
		providers: [provideDialogSlots()],
		viewQueries: [{
			propertyName: "_portal",
			first: true,
			predicate: CdkPortalOutlet,
			descendants: true,
			static: true
		}, {
			propertyName: "_component",
			first: true,
			predicate: DialogComponent,
			descendants: true,
			static: true
		}],
		exportAs: ["mosaikDialogPortal"],
		usesInheritance: true,
		ngImport: i0,
		template: "<mosaik-dialog [closeable]=\"this.dialogConfig?.closeable ?? false\"\n               [appearance]=\"this.dialogConfig?.appearance ?? 'default'\"\n               [isDraggable]=\"this.dialogConfig?.isDraggable ?? false\"\n               [enter]=\"this.dialogConfig?.enter\"\n               [exit]=\"this.dialogConfig?.exit\"\n               [width]=\"this.dialogConfig?.size?.width ?? 'auto'\"\n               [height]=\"this.dialogConfig?.size?.height ?? 'auto'\">\n    @if (this.headerTemplate; as template) {\n    <ng-container [ngTemplateOutlet]=\"template\" />\n    } @else if ((this.dialogConfig?.header | of | async) || this.dialogConfig?.closeable) {\n    <mosaik-dialog-header>\n        <mosaik-dialog-header-text [text]=\"(this.dialogConfig?.header | of | async) ?? ''\" />\n        <mosaik-dialog-header-sub-text [text]=\"(this.dialogConfig?.subheader | of | async) ?? ''\" />\n    </mosaik-dialog-header>\n    }\n    <mosaik-dialog-content cdkScrollable>\n        @if (this.contentTemplate; as template) {\n        <ng-container [ngTemplateOutlet]=\"template\" />\n        }\n        <ng-template cdkPortalOutlet />\n    </mosaik-dialog-content>\n    @if (this.actionsTemplate; as template) {\n    <ng-container [ngTemplateOutlet]=\"template\" />\n    } @else if (this.dialogConfig?.actions) {\n    <mosaik-dialog-actions>\n        @for (action of this.dialogConfig.actions; track action.label) {\n        @if ((action?.visible | of | async) ?? true) {\n        <mosaik-button [appearance]=\"action?.kind === 'primary' ? 'solid' : 'plain'\"\n                       [label]=\"(action?.label | of | async) ?? ''\"\n                       [disabled]=\"(action?.disabled | of | async) ?? false\"\n                       [variant]=\"'primary'\"\n                       (click)=\"action?.handler()\" />\n        }\n        }\n    </mosaik-dialog-actions>\n    }\n    @if (this.footerTemplate; as template) {\n    <mosaik-dialog-footer>\n        <ng-container [ngTemplateOutlet]=\"template\" />\n    </mosaik-dialog-footer>\n    }\n</mosaik-dialog>\n",
		styles: [".cdk-overlay-backdrop.mosaik-cdk-backdrop{--backdrop-background-color: var(--joy-scheme-semi-transparent);--backdrop-blur: 4px;--backdrop-transition-duration: var(--mosaik-duration-short);--backdrop-transition-mode: ease;--backdrop-transition-property: opacity, backdrop-filter;background:var(--backdrop-background-color);-webkit-backdrop-filter:blur(var(--backdrop-blur));backdrop-filter:blur(var(--backdrop-blur));opacity:1;transition-duration:var(--backdrop-transition-duration);transition-timing-function:var(--backdrop-transition-mode);transition-property:var(--backdrop-transition-property)}:root[theme=joy] .cdk-overlay-backdrop.mosaik-cdk-backdrop{--backdrop-background-color: var(--joy-scheme-semi-transparent);--backdrop-blur: 4px;--backdrop-transition-duration: var(--mosaik-duration-short);--backdrop-transition-mode: ease;--backdrop-transition-property: opacity, backdrop-filter}:root[theme=memphis] .cdk-overlay-backdrop.mosaik-cdk-backdrop{--backdrop-background-color: var(--memphis-scheme-semi-transparent);--backdrop-blur: none;--backdrop-transition-duration: var(--memphis-duration-short);--backdrop-transition-mode: ease;--backdrop-transition-property: opacity}:root[theme=cosmopolitan] .cdk-overlay-backdrop.mosaik-cdk-backdrop{--backdrop-background-color: var(--cosmopolitan-scheme-semi-transparent);--backdrop-blur: none;--backdrop-transition-duration: var(--cosmopolitan-duration-short);--backdrop-transition-mode: ease;--backdrop-transition-property: opacity}@media screen and (prefers-reduced-motion:reduce){.cdk-overlay-backdrop.mosaik-cdk-backdrop{transition-duration:.01ms}}.cdk-overlay-pane.mosaik-cdk-overlay-pane{pointer-events:none}.mosaik-cdk-overlay-pane mosaik-dialog::part(backdrop),.mosaik-cdk-overlay-pane mosaik-drawer::part(backdrop),.mosaik-cdk-overlay-pane mosaik-message-box::part(backdrop),.mosaik-cdk-overlay-pane mosaik-sheet::part(backdrop),.mosaik-cdk-overlay-pane mosaik-toast::part(backdrop){opacity:0;pointer-events:none;background:transparent;-webkit-backdrop-filter:none;backdrop-filter:none}\n"],
		dependencies: [
			{
				kind: "directive",
				type: NgTemplateOutlet,
				selector: "[ngTemplateOutlet]",
				inputs: [
					"ngTemplateOutletContext",
					"ngTemplateOutlet",
					"ngTemplateOutletInjector"
				]
			},
			{
				kind: "directive",
				type: CdkScrollable,
				selector: "[cdk-scrollable], [cdkScrollable]"
			},
			{
				kind: "directive",
				type: CdkPortalOutlet,
				selector: "[cdkPortalOutlet]",
				inputs: ["cdkPortalOutlet"],
				outputs: ["attached"],
				exportAs: ["cdkPortalOutlet"]
			},
			{
				kind: "component",
				type: DialogComponent,
				selector: "mosaik-dialog",
				inputs: [
					"isFullScreen",
					"isDraggable",
					"themeName",
					"enter",
					"exit",
					"width",
					"height",
					"elevation",
					"appearance",
					"isOpen",
					"hasBackdrop",
					"pressEscapeToClose",
					"clickOutsideToClose",
					"attention",
					"closeable",
					"dir",
					"lang"
				],
				outputs: [
					"opened",
					"closed",
					"closeAttempted",
					"connected",
					"disconnected",
					"changed"
				]
			},
			{
				kind: "component",
				type: DialogHeaderComponent,
				selector: "mosaik-dialog-header",
				inputs: [
					"text",
					"subText",
					"themeName",
					"formatter",
					"dir",
					"lang"
				],
				outputs: [
					"connected",
					"disconnected",
					"changed"
				]
			},
			{
				kind: "component",
				type: DialogHeaderTextComponent,
				selector: "mosaik-dialog-header-text",
				inputs: [
					"text",
					"themeName",
					"formatter",
					"dir",
					"lang"
				],
				outputs: [
					"connected",
					"disconnected",
					"changed"
				]
			},
			{
				kind: "component",
				type: DialogHeaderSubTextComponent,
				selector: "mosaik-dialog-header-sub-text",
				inputs: [
					"text",
					"themeName",
					"formatter",
					"dir",
					"lang"
				],
				outputs: [
					"connected",
					"disconnected",
					"changed"
				]
			},
			{
				kind: "component",
				type: DialogActionsComponent,
				selector: "mosaik-dialog-actions",
				inputs: [
					"themeName",
					"dir",
					"lang"
				],
				outputs: [
					"connected",
					"disconnected",
					"changed"
				]
			},
			{
				kind: "component",
				type: DialogFooterComponent,
				selector: "mosaik-dialog-footer",
				inputs: [
					"themeName",
					"dir",
					"lang"
				],
				outputs: [
					"connected",
					"disconnected",
					"changed"
				]
			},
			{
				kind: "component",
				type: ButtonComponent,
				selector: "mosaik-button",
				inputs: [
					"download",
					"href",
					"rel",
					"target",
					"themeName",
					"reverse",
					"orientation",
					"horizontalContentAlignment",
					"verticalContentAlignment",
					"fit",
					"isBusy",
					"label",
					"icon",
					"iconPosition",
					"iconSize",
					"type",
					"ripple",
					"variant",
					"appearance",
					"size",
					"value",
					"disabled",
					"isFocused",
					"dir",
					"lang"
				],
				outputs: [
					"connected",
					"disconnected",
					"changed"
				]
			},
			{
				kind: "pipe",
				type: AsyncPipe,
				name: "async"
			},
			{
				kind: "pipe",
				type: OfPipe,
				name: "of"
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush,
		encapsulation: i0.ViewEncapsulation.None
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DialogPortalComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-dialog-portal",
			exportAs: "mosaikDialogPortal",
			host: { class: "dialog-portal" },
			changeDetection: ChangeDetectionStrategy.OnPush,
			encapsulation: ViewEncapsulation.None,
			providers: [provideDialogSlots()],
			imports: [
				AsyncPipe,
				NgTemplateOutlet,
				OfPipe,
				CdkScrollable,
				CdkPortalOutlet,
				DialogComponent,
				DialogHeaderComponent,
				DialogHeaderTextComponent,
				DialogHeaderSubTextComponent,
				DialogActionsComponent,
				DialogFooterComponent,
				ButtonComponent
			],
			template: "<mosaik-dialog [closeable]=\"this.dialogConfig?.closeable ?? false\"\n               [appearance]=\"this.dialogConfig?.appearance ?? 'default'\"\n               [isDraggable]=\"this.dialogConfig?.isDraggable ?? false\"\n               [enter]=\"this.dialogConfig?.enter\"\n               [exit]=\"this.dialogConfig?.exit\"\n               [width]=\"this.dialogConfig?.size?.width ?? 'auto'\"\n               [height]=\"this.dialogConfig?.size?.height ?? 'auto'\">\n    @if (this.headerTemplate; as template) {\n    <ng-container [ngTemplateOutlet]=\"template\" />\n    } @else if ((this.dialogConfig?.header | of | async) || this.dialogConfig?.closeable) {\n    <mosaik-dialog-header>\n        <mosaik-dialog-header-text [text]=\"(this.dialogConfig?.header | of | async) ?? ''\" />\n        <mosaik-dialog-header-sub-text [text]=\"(this.dialogConfig?.subheader | of | async) ?? ''\" />\n    </mosaik-dialog-header>\n    }\n    <mosaik-dialog-content cdkScrollable>\n        @if (this.contentTemplate; as template) {\n        <ng-container [ngTemplateOutlet]=\"template\" />\n        }\n        <ng-template cdkPortalOutlet />\n    </mosaik-dialog-content>\n    @if (this.actionsTemplate; as template) {\n    <ng-container [ngTemplateOutlet]=\"template\" />\n    } @else if (this.dialogConfig?.actions) {\n    <mosaik-dialog-actions>\n        @for (action of this.dialogConfig.actions; track action.label) {\n        @if ((action?.visible | of | async) ?? true) {\n        <mosaik-button [appearance]=\"action?.kind === 'primary' ? 'solid' : 'plain'\"\n                       [label]=\"(action?.label | of | async) ?? ''\"\n                       [disabled]=\"(action?.disabled | of | async) ?? false\"\n                       [variant]=\"'primary'\"\n                       (click)=\"action?.handler()\" />\n        }\n        }\n    </mosaik-dialog-actions>\n    }\n    @if (this.footerTemplate; as template) {\n    <mosaik-dialog-footer>\n        <ng-container [ngTemplateOutlet]=\"template\" />\n    </mosaik-dialog-footer>\n    }\n</mosaik-dialog>\n",
			styles: [".cdk-overlay-backdrop.mosaik-cdk-backdrop{--backdrop-background-color: var(--joy-scheme-semi-transparent);--backdrop-blur: 4px;--backdrop-transition-duration: var(--mosaik-duration-short);--backdrop-transition-mode: ease;--backdrop-transition-property: opacity, backdrop-filter;background:var(--backdrop-background-color);-webkit-backdrop-filter:blur(var(--backdrop-blur));backdrop-filter:blur(var(--backdrop-blur));opacity:1;transition-duration:var(--backdrop-transition-duration);transition-timing-function:var(--backdrop-transition-mode);transition-property:var(--backdrop-transition-property)}:root[theme=joy] .cdk-overlay-backdrop.mosaik-cdk-backdrop{--backdrop-background-color: var(--joy-scheme-semi-transparent);--backdrop-blur: 4px;--backdrop-transition-duration: var(--mosaik-duration-short);--backdrop-transition-mode: ease;--backdrop-transition-property: opacity, backdrop-filter}:root[theme=memphis] .cdk-overlay-backdrop.mosaik-cdk-backdrop{--backdrop-background-color: var(--memphis-scheme-semi-transparent);--backdrop-blur: none;--backdrop-transition-duration: var(--memphis-duration-short);--backdrop-transition-mode: ease;--backdrop-transition-property: opacity}:root[theme=cosmopolitan] .cdk-overlay-backdrop.mosaik-cdk-backdrop{--backdrop-background-color: var(--cosmopolitan-scheme-semi-transparent);--backdrop-blur: none;--backdrop-transition-duration: var(--cosmopolitan-duration-short);--backdrop-transition-mode: ease;--backdrop-transition-property: opacity}@media screen and (prefers-reduced-motion:reduce){.cdk-overlay-backdrop.mosaik-cdk-backdrop{transition-duration:.01ms}}.cdk-overlay-pane.mosaik-cdk-overlay-pane{pointer-events:none}.mosaik-cdk-overlay-pane mosaik-dialog::part(backdrop),.mosaik-cdk-overlay-pane mosaik-drawer::part(backdrop),.mosaik-cdk-overlay-pane mosaik-message-box::part(backdrop),.mosaik-cdk-overlay-pane mosaik-sheet::part(backdrop),.mosaik-cdk-overlay-pane mosaik-toast::part(backdrop){opacity:0;pointer-events:none;background:transparent;-webkit-backdrop-filter:none;backdrop-filter:none}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		_portal: [{
			type: ViewChild,
			args: [CdkPortalOutlet, { static: true }]
		}],
		_component: [{
			type: ViewChild,
			args: [DialogComponent, { static: true }]
		}]
	}
});
var PortalCloseAttempt = class {
	_trigger;
	_closePrevented;
	constructor(trigger) {
		this._trigger = trigger;
		this._closePrevented = false;
	}
	get trigger() {
		return this._trigger;
	}
	get closePrevented() {
		return this._closePrevented;
	}
	preventClose() {
		this._closePrevented = true;
	}
};
var PortalRef = class {
	_closedSubject;
	_closeAttemptedSubject;
	_component;
	_overlayRef;
	_id;
	_data;
	_isClosed;
	constructor(id, component, overlayRef, data) {
		this._closedSubject = new Subject();
		this._closeAttemptedSubject = new Subject();
		this._component = component;
		this._overlayRef = overlayRef;
		this._id = id;
		this._data = data;
		this._isClosed = false;
	}
	get id() {
		return this._id;
	}
	get component() {
		return this._component;
	}
	get overlayRef() {
		return this._overlayRef;
	}
	get data() {
		return this._data;
	}
	get closed() {
		return this._closedSubject.asObservable();
	}
	get closeAttempted() {
		return this._closeAttemptedSubject.asObservable();
	}
	close(result) {
		if (this._isClosed) return;
		this._isClosed = true;
		this._closeAttemptedSubject.complete();
		this._closedSubject.next(result);
		this._closedSubject.complete();
	}
	requestClose(trigger, result) {
		if (this._isClosed) return;
		const attempt = new PortalCloseAttempt(trigger);
		this._closeAttemptedSubject.next(attempt);
		if (!attempt.closePrevented) this.close(result);
	}
};
var DialogRef = class extends PortalRef {
	_positionChangedSubject;
	_sizeChangedSubject;
	_dialogElement;
	constructor(id, component, overlayRef, data) {
		super(id, component, overlayRef, data);
		this._positionChangedSubject = new Subject();
		this._sizeChangedSubject = new Subject();
		const dialogElement = overlayRef.hostElement.querySelector("mosaik-dialog");
		if (!dialogElement) throw new Error("DialogElement not found in overlay host element.");
		this._dialogElement = dialogElement;
	}
	get element() {
		return this._dialogElement;
	}
	get positionChanged() {
		return this._positionChangedSubject.asObservable();
	}
	get sizeChanged() {
		return this._sizeChangedSubject.asObservable();
	}
	close(result) {
		this._positionChangedSubject.complete();
		this._sizeChangedSubject.complete();
		super.close(result);
		this.component.close();
	}
	requestAttention(animation) {
		return this.element.requestAttention(animation);
	}
	updatePosition(position) {
		const strategy = this.overlayRef.getConfig().positionStrategy;
		if (position.left || position.right) {
			if (position.left) strategy.left(this.parseNumber(position.left));
			else if (position.right) strategy.right(this.parseNumber(position.right));
		} else strategy.centerHorizontally();
		if (position.top || position.bottom) {
			if (position.top) strategy.top(this.parseNumber(position.top));
			else strategy.bottom(this.parseNumber(position.bottom));
		} else strategy.centerVertically();
		this.overlayRef.updatePosition();
		this._positionChangedSubject.next(position);
		return this;
	}
	updateSize(size) {
		this.overlayRef.updateSize({
			width: size.width,
			height: size.height
		});
		this.overlayRef.updatePosition();
		this._sizeChangedSubject.next(size);
		return this;
	}
	parseNumber(size) {
		if (typeof size === "string") return size;
		else if (typeof size === "number") return `${size}px`;
		return "";
	}
};
var StatelessInjector = class {
	_parentInjector;
	_injectionTokens;
	constructor(parentInjector, injectionTokens) {
		this._parentInjector = parentInjector;
		this._injectionTokens = injectionTokens ? new WeakMap(injectionTokens) : null;
	}
	dispose() {
		this._injectionTokens = null;
	}
	get(token, notFoundValue, options) {
		if (typeof token === "object" && this._injectionTokens?.has(token)) {
			const value = this._injectionTokens.get(token);
			if (value !== void 0) return value;
			return notFoundValue === void 0 ? null : notFoundValue;
		}
		return this._parentInjector.get(token, notFoundValue, options);
	}
};
var OverlayBackdropStackCoordinator = class OverlayBackdropStackCoordinator {
	static _entries = new Array();
	static resolveHasBackdrop(hasBackdrop, options) {
		const backdropStackKey = options?.backdropStackKey;
		if (hasBackdrop !== true || options?.backdropStrategy === "own" || !backdropStackKey) return hasBackdrop;
		return !OverlayBackdropStackCoordinator.hasBackdropInCurrentStack(backdropStackKey);
	}
	static register(overlayRef, hasBackdrop, options) {
		OverlayBackdropStackCoordinator._entries.push({
			overlayRef,
			backdropStackKey: options?.backdropStackKey,
			hasBackdrop: hasBackdrop === true
		});
	}
	static unregister(overlayRef) {
		const index = OverlayBackdropStackCoordinator._entries.findIndex((entry) => entry.overlayRef === overlayRef);
		if (index >= 0) OverlayBackdropStackCoordinator._entries.splice(index, 1);
	}
	static hasBackdropInCurrentStack(backdropStackKey) {
		for (let index = OverlayBackdropStackCoordinator._entries.length - 1; index >= 0; index--) {
			const entry = OverlayBackdropStackCoordinator._entries[index];
			if (entry.backdropStackKey !== backdropStackKey) return false;
			if (entry.hasBackdrop) return true;
		}
		return false;
	}
};
var OverlayLayerCoordinator = class OverlayLayerCoordinator {
	static _states = /* @__PURE__ */ new WeakMap();
	static attach(overlayRef, zIndex) {
		const host = overlayRef.hostElement;
		const document = host.ownerDocument;
		if (zIndex !== void 0) {
			const state = OverlayLayerCoordinator.getOrCreateState(document);
			if (state.entries.has(overlayRef)) {
				OverlayLayerCoordinator.refresh(document);
				return;
			}
			const originalParent = host.parentElement;
			let container = null;
			host.style.zIndex = String(zIndex);
			if (!overlayRef.getConfig().usePopover) {
				container = document.createElement("div");
				container.classList.add("cdk-overlay-container");
				container.style.zIndex = String(zIndex);
				if (originalParent?.parentNode) originalParent.after(container);
				else document.body.append(container);
				if (overlayRef.backdropElement) {
					overlayRef.backdropElement.style.zIndex = String(zIndex - 1);
					container.append(overlayRef.backdropElement);
				}
				container.append(host);
			}
			state.entries.set(overlayRef, {
				overlayRef,
				host,
				zIndex,
				originalParent,
				container
			});
		}
		OverlayLayerCoordinator.refresh(document);
	}
	static detach(overlayRef, document) {
		const state = OverlayLayerCoordinator._states.get(document);
		const entry = state?.entries.get(overlayRef);
		if (!state || !entry) return;
		state.entries.delete(overlayRef);
		if (entry.container) {
			if (entry.host.parentElement === entry.container && entry.originalParent) entry.originalParent.append(entry.host);
			entry.container.remove();
		}
		if (state.entries.size === 0) {
			document.removeEventListener("beforetoggle", state.beforeToggle, true);
			OverlayLayerCoordinator.cancelFrame(document, state);
			OverlayLayerCoordinator._states.delete(document);
		}
	}
	static getOrCreateState(document) {
		let state = OverlayLayerCoordinator._states.get(document);
		if (!state) {
			state = {
				entries: /* @__PURE__ */ new Map(),
				beforeToggle: (event) => OverlayLayerCoordinator.beforeToggle(document, event),
				refreshing: false,
				frame: null
			};
			OverlayLayerCoordinator._states.set(document, state);
			document.addEventListener("beforetoggle", state.beforeToggle, true);
		}
		return state;
	}
	static beforeToggle(document, event) {
		const state = OverlayLayerCoordinator._states.get(document);
		if (!state || state.refreshing || state.frame !== null || !document.defaultView || !("newState" in event) || event.newState !== "open" || Array.from(state.entries.values()).some((entry) => entry.host === event.target)) return;
		state.frame = document.defaultView.requestAnimationFrame(() => {
			state.frame = null;
			if (OverlayLayerCoordinator._states.get(document) === state) OverlayLayerCoordinator.refresh(document);
		});
	}
	static refresh(document) {
		const state = OverlayLayerCoordinator._states.get(document);
		if (!state || state.refreshing) return;
		OverlayLayerCoordinator.cancelFrame(document, state);
		state.refreshing = true;
		const focusedElement = OverlayLayerCoordinator.focusedElement(document);
		try {
			const entries = Array.from(state.entries.values()).sort((left, right) => left.zIndex - right.zIndex);
			for (const entry of entries) if (entry.overlayRef.getConfig().usePopover && entry.overlayRef.hasAttached() && entry.host.isConnected && entry.host.matches(":popover-open")) {
				entry.host.hidePopover();
				entry.host.showPopover();
			}
		} finally {
			state.refreshing = false;
			if (focusedElement?.isConnected && OverlayLayerCoordinator.focusedElement(document) !== focusedElement) focusedElement.focus({ preventScroll: true });
		}
	}
	static focusedElement(document) {
		let element = document.activeElement;
		while (element?.shadowRoot?.activeElement) element = element.shadowRoot.activeElement;
		return element && "focus" in element ? element : null;
	}
	static cancelFrame(document, state) {
		if (state.frame !== null) {
			document.defaultView?.cancelAnimationFrame(state.frame);
			state.frame = null;
		}
	}
};
const MOSAIK_CDK_OVERLAY_PANE_CLASS = "mosaik-cdk-overlay-pane";
const MOSAIK_CDK_BACKDROP_CLASS = "mosaik-cdk-backdrop";
var PortalProvider = class {
	_injector;
	_overlayPositionBuilder;
	_overlay;
	_cache;
	_cacheCountSubject;
	constructor() {
		this._injector = inject(Injector);
		this._overlayPositionBuilder = inject(OverlayPositionBuilder);
		this._overlay = inject(Overlay);
		this._cache = new Array();
		this._cacheCountSubject = new BehaviorSubject(0);
	}
	get count() {
		return this._cacheCountSubject.asObservable();
	}
	get overlayPositionBuilder() {
		return this._overlayPositionBuilder;
	}
	get overlay() {
		return this._overlay;
	}
	get injector() {
		return this._injector;
	}
	get cache() {
		return this._cache;
	}
	createOverlay(config, options) {
		const overlayConfig = {
			...config,
			hasBackdrop: OverlayBackdropStackCoordinator.resolveHasBackdrop(config.hasBackdrop, options),
			positionStrategy: this.createPositionStrategy(),
			scrollStrategy: this.createScrollStrategy(),
			panelClass: withOverlayClass(config.panelClass, MOSAIK_CDK_OVERLAY_PANE_CLASS),
			backdropClass: withOverlayClass(config.backdropClass, MOSAIK_CDK_BACKDROP_CLASS)
		};
		const overlayRef = this._overlay.create(overlayConfig);
		OverlayBackdropStackCoordinator.register(overlayRef, overlayConfig.hasBackdrop, options);
		useBackdropPointerEvents(overlayRef);
		overlayRef.attachments().subscribe(() => {
			useBackdropPointerEvents(overlayRef);
			OverlayLayerCoordinator.attach(overlayRef, options?.zIndex);
		});
		const ownerDocument = overlayRef.hostElement.ownerDocument;
		overlayRef.detachments().subscribe(() => OverlayLayerCoordinator.detach(overlayRef, ownerDocument));
		return overlayRef;
	}
	createPortal(component, overlayRef, config) {
		const portalInjector = new StatelessInjector(this.createPortalInjector(config), [[PORTAL_OVERLAY_REF, overlayRef]]);
		return new ComponentPortal(component, null, portalInjector);
	}
	createComponent(portal, overlayRef, _component, _config) {
		return overlayRef.attach(portal);
	}
	createContent(componentTypeOrTemplateRef, container, ref, config) {
		let componentRefOrEmbeddedViewRef = null;
		if (componentTypeOrTemplateRef instanceof TemplateRef) {
			const portal = new TemplatePortal(componentTypeOrTemplateRef, null, { $implicit: ref }, this.createContentInjector(ref, config));
			componentRefOrEmbeddedViewRef = container.attachTemplatePortal(portal);
		} else {
			const portal = new ComponentPortal(componentTypeOrTemplateRef, null, this.createContentInjector(ref, config));
			componentRefOrEmbeddedViewRef = container.attachComponentPortal(portal);
		}
		return componentRefOrEmbeddedViewRef;
	}
	attach(overlayRef, portal) {
		this._cache.push({
			overlay: overlayRef,
			portal
		});
		OverlayInteractionCoordinator.register(overlayRef);
		this._cacheCountSubject.next(this._cache.length);
	}
	detach(overlayRef) {
		if (overlayRef.hasAttached()) overlayRef.detach();
		OverlayBackdropStackCoordinator.unregister(overlayRef);
		OverlayInteractionCoordinator.unregister(overlayRef);
		const index = this._cache.findIndex((x) => x.overlay === overlayRef);
		if (index >= 0) this._cache.splice(index, 1);
		this._cacheCountSubject.next(this._cache.length);
	}
};
function useBackdropPointerEvents(overlayRef) {
	overlayRef.overlayElement.style.pointerEvents = "none";
}
function withOverlayClass(value, className) {
	if (!value) return className;
	if (Array.isArray(value)) return value.includes(className) ? value : [...value, className];
	return value === className ? value : [value, className];
}
const MOSAIK_OVERLAY_INTERACTION_BOUNDARY_ATTRIBUTE = "data-mosaik-overlay-interaction-boundary";
var OverlayInteractionBoundaryDirective = class OverlayInteractionBoundaryDirective {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: OverlayInteractionBoundaryDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: OverlayInteractionBoundaryDirective,
		isStandalone: true,
		selector: "[mosaikOverlayInteractionBoundary]",
		host: { attributes: { "data-mosaik-overlay-interaction-boundary": "" } },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: OverlayInteractionBoundaryDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[mosaikOverlayInteractionBoundary]",
			host: { "data-mosaik-overlay-interaction-boundary": "" }
		}]
	}]
});
const OUTSIDE_CLOSE_DEDUPLICATION_WINDOW_IN_MS = 50;
function connectOverlayOutsideClose(overlayRef, closed, close) {
	const ownerDocument = overlayRef.overlayElement.ownerDocument;
	let lastOutsideCloseAttemptTimestamp = Number.NEGATIVE_INFINITY;
	merge(overlayRef.backdropClick(), overlayRef.outsidePointerEvents(), fromEvent(ownerDocument, "pointerdown", { capture: true })).pipe(filter((event) => OverlayInteractionCoordinator.isTopMostForInteraction(overlayRef, event)), filter((event) => !isOverlayInteractionEvent(overlayRef, event)), filter((event) => !isOwnedMosaikPortalProjectionEvent(overlayRef, event)), filter((event) => !isExternalOverlayInteractionBoundaryEvent(event)), takeUntil(closed)).subscribe((event) => {
		const timestamp = event.timeStamp || Date.now();
		if (timestamp - lastOutsideCloseAttemptTimestamp < OUTSIDE_CLOSE_DEDUPLICATION_WINDOW_IN_MS) return;
		lastOutsideCloseAttemptTimestamp = timestamp;
		close();
	});
}
function connectOverlayEscapeClose(overlayRef, closed, close) {
	fromEvent(overlayRef.overlayElement.ownerDocument, "keydown", { capture: true }).pipe(filter(isEscapeKeyEvent), filter((event) => OverlayInteractionCoordinator.isTopMostForInteraction(overlayRef, event)), filter(() => !hasOpenPopup(overlayRef)), takeUntil(closed)).subscribe((event) => {
		consumeEscapeKeyEvent(event);
		close();
	});
}
function connectOverlayEscapeBlock(overlayRef, closed) {
	fromEvent(overlayRef.overlayElement.ownerDocument, "keydown", { capture: true }).pipe(filter(isEscapeKeyEvent), filter((event) => OverlayInteractionCoordinator.isTopMostForInteraction(overlayRef, event)), filter(() => !hasOpenPopup(overlayRef)), takeUntil(closed)).subscribe((event) => consumeEscapeKeyEvent(event));
}
function isEscapeKeyEvent(event) {
	return event.key === "Escape" || event.code === "Escape" || event.keyCode === Key.Escape;
}
function hasOpenPopup(overlayRef) {
	return ClickOutsideController.hasObservingHostWithin(overlayRef.overlayElement);
}
function consumeEscapeKeyEvent(event) {
	event.preventDefault();
	event.stopImmediatePropagation();
}
function isOwnedMosaikPortalProjectionEvent(overlayRef, event) {
	return event.composedPath().some((target) => isMosaikPortalProjectionElement(target) && isProjectionOwnedByOverlay(overlayRef, target));
}
function isOverlayInteractionEvent(overlayRef, event) {
	return event.composedPath().some((target) => isNode(target) && isComposedDescendantOf(overlayRef.overlayElement, target));
}
function isExternalOverlayInteractionBoundaryEvent(event) {
	return event.composedPath().some((target) => typeof Element !== "undefined" && target instanceof Element && target.hasAttribute("data-mosaik-overlay-interaction-boundary"));
}
function isNode(target) {
	return typeof Node !== "undefined" && target instanceof Node;
}
function isMosaikPortalProjectionElement(target) {
	return typeof HTMLElement !== "undefined" && target instanceof HTMLElement && target.localName === "mosaik-portal-projection";
}
function isProjectionOwnedByOverlay(overlayRef, projection) {
	const portal = tryGetProjectionPortal(projection);
	return portal !== null && isComposedDescendantOf(overlayRef.overlayElement, portal);
}
function tryGetProjectionPortal(projection) {
	try {
		return typeof HTMLElement !== "undefined" && projection.portal instanceof HTMLElement ? projection.portal : null;
	} catch {
		return null;
	}
}
function isComposedDescendantOf(parent, child) {
	let current = child;
	while (current) {
		if (current === parent) return true;
		if (isShadowRoot(current)) current = current.host;
		else if (current.parentNode) current = current.parentNode;
		else {
			const root = current.getRootNode();
			current = isShadowRoot(root) ? root.host : null;
		}
	}
	return false;
}
function isShadowRoot(node) {
	return typeof ShadowRoot !== "undefined" && node instanceof ShadowRoot;
}
var DialogService = class DialogService extends PortalProvider {
	_behaviors;
	_defaultConfig;
	_portalInjector;
	constructor() {
		super();
		this._behaviors = new Array();
		this._defaultConfig = inject(DIALOG_CONFIG, { optional: true }) ?? {};
		for (const behavior of inject(DIALOG_BEHAVIORS, { optional: true }) ?? []) this.withBehavior(behavior);
	}
	show(componentTypeOrTemplateRef, config) {
		const resolvedConfig = this.createConfig(config);
		if (resolvedConfig) for (const behavior of this._behaviors) behavior.configure(resolvedConfig);
		const overlayRef = this.createOverlay({
			hasBackdrop: resolvedConfig?.hasBackdrop,
			width: resolvedConfig?.size?.width,
			height: resolvedConfig?.size?.height,
			minWidth: resolvedConfig?.minSize?.width,
			minHeight: resolvedConfig?.minSize?.height,
			maxWidth: resolvedConfig?.maxSize?.width,
			maxHeight: resolvedConfig?.maxSize?.height,
			disposeOnNavigation: resolvedConfig?.closeOnNavigation
		}, {
			backdropStackKey: "dialog",
			backdropStrategy: resolvedConfig?.backdropStrategy
		});
		const portal = this.createPortal(DialogPortalComponent, overlayRef, resolvedConfig);
		const componentRef = this.createComponent(portal, overlayRef, DialogPortalComponent, resolvedConfig);
		this._portalInjector = componentRef.injector;
		const dialogRef = new DialogRef(this.createId(), componentRef.instance.dialog, overlayRef, resolvedConfig?.data);
		this.createContent(componentTypeOrTemplateRef, componentRef.instance, dialogRef, resolvedConfig);
		this.prepareComponent(overlayRef, componentRef.instance.dialog, dialogRef, resolvedConfig);
		this.attach(overlayRef, portal);
		componentRef.instance.dialog.open();
		this._behaviors.forEach((x) => x.attach(dialogRef, portal));
		return dialogRef;
	}
	close(ref) {
		this.detach(ref.overlayRef);
	}
	isShown(ref) {
		return this.cache.some((x) => x.overlay === ref.overlayRef && x.portal.isAttached);
	}
	withBehavior(type) {
		const behavior = this.injector.get(type);
		this._behaviors.push(behavior);
		return this;
	}
	createId() {
		return EID.next("mosaik-dialog");
	}
	createPortalInjector(config) {
		return new StatelessInjector(this.injector, [[DIALOG_CONFIG, config]]);
	}
	createContentInjector(ref, config) {
		return new StatelessInjector(this._portalInjector ?? this.injector, [
			[DIALOG_REF, ref],
			[DIALOG_REF_DATA, ref.data],
			[DIALOG_CONFIG, config]
		]);
	}
	createPositionStrategy() {
		return this.overlayPositionBuilder.global().centerVertically().centerHorizontally();
	}
	createScrollStrategy() {
		return this.overlay.scrollStrategies.block();
	}
	createComponent(portal, overlayRef, _component, config) {
		if (config?.singleton) {
			const overlayRefs = this.cache.filter((x) => x.overlay !== overlayRef);
			const detachments = new Array();
			for (const ref of overlayRefs) {
				ref.overlay.detach();
				detachments.push(ref);
			}
			const sub = overlayRef.detachments().subscribe(() => {
				sub.unsubscribe();
				for (const entry of detachments) entry.overlay.attach(entry.portal);
			});
		}
		return super.createComponent(portal, overlayRef, _component, config);
	}
	prepareComponent(overlayRef, component, dialogRef, config) {
		if (config) {
			Object.keys(config).forEach((p) => {
				if (p in component && typeof component.setInput === "function") component.setInput(p, config[p]);
			});
			if (config.clickOutsideToClose) connectOverlayOutsideClose(overlayRef, dialogRef.closed, () => dialogRef.requestClose("outside", Cancel.negative()));
		}
		component.setInput("pressEscapeToClose", false);
		component.setInput("clickOutsideToClose", false);
		if (config?.pressEscapeToClose) connectOverlayEscapeClose(overlayRef, dialogRef.closed, () => dialogRef.requestClose("escape", Cancel.negative()));
		else connectOverlayEscapeBlock(overlayRef, dialogRef.closed);
		const closedSubscription = component.closed.subscribe(() => {
			closedSubscription.unsubscribe();
			dialogRef.close(Cancel.none());
			this.detach(overlayRef);
			this._behaviors.forEach((x) => x.detach(dialogRef));
		});
	}
	createConfig(config) {
		const defaultConfig = this._defaultConfig;
		if (!this.hasConfig(defaultConfig) && !this.hasConfig(config)) return;
		return {
			...defaultConfig,
			...config,
			size: this.mergeSize(defaultConfig.size, config?.size),
			minSize: this.mergeSize(defaultConfig.minSize, config?.minSize),
			maxSize: this.mergeSize(defaultConfig.maxSize, config?.maxSize)
		};
	}
	hasConfig(config) {
		return config !== void 0 && Object.keys(config).length > 0;
	}
	mergeSize(defaultSize, size) {
		if (!defaultSize && !size) return;
		return {
			...defaultSize,
			...size
		};
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DialogService,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DialogService
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DialogService,
	decorators: [{ type: Injectable }],
	ctorParameters: () => []
});
function provideDialogs(...withBehaviors) {
	const behaviorTypes = withBehaviors.map((x) => x.behaviorType).filter((behaviorType) => behaviorType !== void 0);
	return makeEnvironmentProviders([
		{
			provide: DIALOG_BEHAVIORS,
			useValue: behaviorTypes
		},
		{
			provide: DialogService,
			useClass: DialogService
		},
		...withBehaviors.flatMap((x) => x.provide())
	]);
}
function withDialogDefaultBehavior(config) {
	return {
		id: "dialogDefaultBehavior",
		provide: () => config ? [{
			provide: DIALOG_CONFIG,
			useValue: config
		}] : []
	};
}
function withDialogBreakpointBehavior(config) {
	return {
		id: "dialogBreakpointBehavior",
		behaviorType: DialogBreakpointBehavior,
		provide: () => [{
			provide: DIALOG_BREAKPOINT_BEHAVIOR_CONFIG,
			useValue: config
		}, {
			provide: DialogBreakpointBehavior,
			useClass: DialogBreakpointBehavior
		}]
	};
}
function withDialogStackBehavior(config) {
	return {
		id: "dialogStackBehavior",
		behaviorType: DialogStackBehavior,
		provide: () => [{
			provide: DIALOG_STACK_BEHAVIOR_CONFIG,
			useValue: config
		}, {
			provide: DialogStackBehavior,
			useClass: DialogStackBehavior
		}]
	};
}
var DialogActionsDirective = class DialogActionsDirective {
	_slots = inject(DIALOG_SLOTS);
	constructor(template) {
		this._slots.setActions(template);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DialogActionsDirective,
		deps: [{ token: i0.TemplateRef }],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: DialogActionsDirective,
		isStandalone: true,
		selector: "ng-template[mosaikDialogActions]",
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DialogActionsDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "ng-template[mosaikDialogActions]" }]
	}],
	ctorParameters: () => [{ type: i0.TemplateRef }]
});
var DialogContentDirective = class DialogContentDirective {
	_slots = inject(DIALOG_SLOTS);
	constructor(template) {
		this._slots.setContent(template);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DialogContentDirective,
		deps: [{ token: i0.TemplateRef }],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: DialogContentDirective,
		isStandalone: true,
		selector: "ng-template[mosaikDialogContent]",
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DialogContentDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "ng-template[mosaikDialogContent]" }]
	}],
	ctorParameters: () => [{ type: i0.TemplateRef }]
});
var DialogFooterDirective = class DialogFooterDirective {
	_slots = inject(DIALOG_SLOTS);
	constructor(template) {
		this._slots.setFooter(template);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DialogFooterDirective,
		deps: [{ token: i0.TemplateRef }],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: DialogFooterDirective,
		isStandalone: true,
		selector: "ng-template[mosaikDialogFooter]",
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DialogFooterDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "ng-template[mosaikDialogFooter]" }]
	}],
	ctorParameters: () => [{ type: i0.TemplateRef }]
});
var DialogHeaderDirective = class DialogHeaderDirective {
	_slots = inject(DIALOG_SLOTS);
	constructor(template) {
		this._slots.setHeader(template);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DialogHeaderDirective,
		deps: [{ token: i0.TemplateRef }],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: DialogHeaderDirective,
		isStandalone: true,
		selector: "ng-template[mosaikDialogHeader]",
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DialogHeaderDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "ng-template[mosaikDialogHeader]" }]
	}],
	ctorParameters: () => [{ type: i0.TemplateRef }]
});
var DrawerBehavior = class {
	_ref;
	_attached;
	_drawerConfig;
	constructor() {
		this._ref = null;
		this._attached = false;
		this._drawerConfig = null;
	}
	get ref() {
		if (!this._attached) throw new Error("Must be attached before use the element property.");
		return this._ref;
	}
	get config() {
		return this._drawerConfig;
	}
	configure(config) {
		this._drawerConfig = config;
	}
	attach(element, _portal, config) {
		this._ref = element;
		this._attached = true;
	}
	detach(ref) {
		this._attached = false;
	}
};
const DRAWER_BREAKPOINT_BEHAVIOR_CONFIG = new InjectionToken("DRAWER_BREAKPOINT_OBSERVER_BEHAVIOR_CONFIG");
var DrawerBreakpointBehavior = class extends DrawerBehavior {
	_breakpointObserver;
	_breakpointRegistry;
	_config;
	_mediaQueryToAliasMap;
	_subscription;
	constructor(config = inject(DRAWER_BREAKPOINT_BEHAVIOR_CONFIG, { optional: true })) {
		super();
		this._breakpointObserver = inject(BreakpointObserver);
		this._breakpointRegistry = inject(BreakpointRegistry);
		this._config = config;
		this._mediaQueryToAliasMap = /* @__PURE__ */ new Map();
		this._subscription = Subscription.EMPTY;
	}
	attach(drawerRef, _portal) {
		if (this._config?.breakpoints.length) {
			this._mediaQueryToAliasMap.clear();
			const breakpoints = this._config.breakpoints.map((x) => {
				const breakpoint = this._breakpointRegistry.findByAlias(x.breakpoint);
				if (breakpoint?.mediaQuery) this._mediaQueryToAliasMap.set(breakpoint.mediaQuery, x.breakpoint);
				return breakpoint?.mediaQuery;
			}).filter((x) => x !== void 0);
			this._subscription = this._breakpointObserver.observe(breakpoints).subscribe((x) => this.onBreakpoint(x, drawerRef, this.config ?? void 0));
		}
	}
	detach(_ref) {
		this._subscription.unsubscribe();
	}
	onBreakpoint(state, drawerRef, config) {
		if (state.matches) Object.entries(state.breakpoints).forEach(([mediaQuery, match]) => {
			if (match) {
				const alias = this._mediaQueryToAliasMap.get(mediaQuery);
				const breakpointConfig = alias ? this._config?.breakpoints.find((x) => x.breakpoint === alias) ?? null : null;
				drawerRef.updateSize({
					width: breakpointConfig?.size.width,
					height: breakpointConfig?.size.height
				});
				drawerRef.component.setInput("isFullScreen", true);
			}
		});
		else {
			drawerRef.updateSize({
				width: config?.size?.width,
				height: config?.size?.height
			});
			drawerRef.component.setInput("isFullScreen", false);
		}
	}
};
const DRAWER_STACK_BEHAVIOR_CONFIG = new InjectionToken("DRAWER_STACK_BEHAVIOR_CONFIG");
var DrawerStackBehavior = class extends DrawerBehavior {
	_stack;
	_behaviorConfig;
	constructor(config = inject(DRAWER_STACK_BEHAVIOR_CONFIG, { optional: true })) {
		super();
		this._behaviorConfig = {
			...DRAWER_STACK_BEHAVIOR_DEFAULT_CONFIG,
			...config
		};
		this._stack = new Array();
	}
	get stackSize() {
		return this._stack.length;
	}
	get stackConfig() {
		return this._behaviorConfig;
	}
	attach(drawerRef, portal, config) {
		super.attach(drawerRef, portal, config);
		if (this._behaviorConfig.maxStackDepth !== void 0 && this._stack.length >= this._behaviorConfig.maxStackDepth) throw new Error(`Cannot open drawer: maximum stack depth (${this._behaviorConfig.maxStackDepth}) reached.`);
		const originalBaseWidth = CssLength.toString(config?.size?.width) ?? this._behaviorConfig.baseWidth;
		const computedWidth = originalBaseWidth;
		this.growStackForNewDrawer(originalBaseWidth);
		this.applyStackedClasses();
		const stackLevel = this._stack.length;
		this._stack.push({
			ref: drawerRef,
			portal,
			originalBaseWidth,
			computedWidth
		});
		this.applyStackStyles(drawerRef, stackLevel, computedWidth);
		this.applyStackedClasses();
	}
	detach(ref) {
		super.detach(ref);
		if (this._stack.length === 0) return;
		let indexToRemove;
		if (ref) {
			indexToRemove = this._stack.findIndex((entry) => entry.ref.id === ref.id);
			if (indexToRemove === -1) return;
		} else indexToRemove = this._stack.length - 1;
		this._stack.splice(indexToRemove, 1);
		this.recalculateStackWidths();
		this.applyStackedClasses();
	}
	calculateWidth(stackLevel, baseWidthOverride) {
		const baseWidth = baseWidthOverride ?? this._behaviorConfig.baseWidth;
		const reduction = stackLevel * this._behaviorConfig.stackThreshold;
		const match = /^(\d+(?:\.\d+)?)(%.*)$/.exec(baseWidth);
		if (match) {
			const numericValue = parseFloat(match[1]);
			const unit = match[2];
			return `${Math.max(0, numericValue - reduction)}${unit}`;
		}
		return `calc(${baseWidth} - ${reduction}%)`;
	}
	calculateZIndex(stackLevel) {
		return 1e3 + stackLevel * this._behaviorConfig.zIndexIncrement;
	}
	applyStackStyles(drawerRef, stackLevel, computedWidth) {
		drawerRef.element.setAttribute("data-stack-level", String(stackLevel));
		drawerRef.element.setAttribute("data-computed-width", computedWidth);
		drawerRef.element.style.setProperty("--drawer-stack-level", String(stackLevel));
		drawerRef.element.style.setProperty("--drawer-computed-width", computedWidth);
		drawerRef.element.style.setProperty("--drawer-z-index", String(this.calculateZIndex(stackLevel)));
		if (this._behaviorConfig.showStackIndicator && stackLevel > 0) {
			const indicatorOffset = stackLevel * this._behaviorConfig.stackIndicatorOffset;
			drawerRef.element.style.setProperty("--drawer-stack-indicator-offset", `${indicatorOffset}px`);
		}
		requestAnimationFrame(() => {
			drawerRef.component.setInput("width", computedWidth);
		});
	}
	recalculateStackWidths() {
		if (this._stack.length === 0) return;
		let largestBaseWidthPercentage = 0;
		for (const entry of this._stack) {
			const percentage = this.parseWidthToPercentage(entry.originalBaseWidth);
			if (percentage !== null && percentage > largestBaseWidthPercentage) largestBaseWidthPercentage = percentage;
		}
		const threshold = this._behaviorConfig.stackThreshold;
		const stackLength = this._stack.length;
		this._stack.forEach((entry, index) => {
			const entryBasePercentage = this.parseWidthToPercentage(entry.originalBaseWidth);
			let newWidth;
			if (entryBasePercentage !== null) {
				const offsetFromTop = stackLength - 1 - index;
				if (largestBaseWidthPercentage > entryBasePercentage) newWidth = `${largestBaseWidthPercentage + offsetFromTop * threshold}%`;
				else newWidth = `${entryBasePercentage + offsetFromTop * threshold}%`;
			} else newWidth = this.calculateWidth(index, entry.originalBaseWidth);
			entry.computedWidth = newWidth;
			this.applyStackStyles(entry.ref, index, newWidth);
		});
	}
	parseWidthToPercentage(width) {
		const match = /^(\d+(?:\.\d+)?)%$/.exec(width);
		if (match) return parseFloat(match[1]);
		return null;
	}
	growStackForNewDrawer(newDrawerBaseWidth) {
		const newWidthPercentage = this.parseWidthToPercentage(newDrawerBaseWidth);
		if (newWidthPercentage === null) return;
		const threshold = this._behaviorConfig.stackThreshold;
		const stackLength = this._stack.length;
		for (let i = 0; i < stackLength; i++) {
			const entry = this._stack[i];
			const existingWidthPercentage = this.parseWidthToPercentage(entry.originalBaseWidth);
			if (existingWidthPercentage === null) continue;
			const offsetFromTop = stackLength - i;
			const grownWidthStr = `${Math.max(newWidthPercentage, existingWidthPercentage) + offsetFromTop * threshold}%`;
			entry.computedWidth = grownWidthStr;
			this.applyStackStyles(entry.ref, i, grownWidthStr);
		}
	}
	applyStackedClasses() {
		for (let i = 0; i < this._stack.length; i++) {
			const entry = this._stack[i];
			if (i === this._stack.length - 1) entry.ref.element.classList.remove("mosaik-drawer-stacked");
			else entry.ref.element.classList.add("mosaik-drawer-stacked");
		}
	}
};
const DRAWER_CONFIG = new InjectionToken("MOSAIK_DRAWER_CONFIG");
const DRAWER_REF = new InjectionToken("MOSAIK_DRAWER_REF");
const DRAWER_REF_DATA = new InjectionToken("MOSAIK_DRAWER_REF_DATA");
const DRAWER_BEHAVIORS = new InjectionToken("MOSAIK_DRAWER_BEHAVIORS");
const DRAWER_SLOTS = new InjectionToken("MOSAIK_DRAWER_SLOTS");
function provideDrawerSlots() {
	return {
		provide: DRAWER_SLOTS,
		useFactory: () => {
			const header = signal(null, ...ngDevMode ? [{ debugName: "header" }] : /* istanbul ignore next */ []);
			const content = signal(null, ...ngDevMode ? [{ debugName: "content" }] : /* istanbul ignore next */ []);
			const rail = signal(null, ...ngDevMode ? [{ debugName: "rail" }] : /* istanbul ignore next */ []);
			const actions = signal(null, ...ngDevMode ? [{ debugName: "actions" }] : /* istanbul ignore next */ []);
			const footer = signal(null, ...ngDevMode ? [{ debugName: "footer" }] : /* istanbul ignore next */ []);
			return {
				header: header.asReadonly(),
				content: content.asReadonly(),
				rail: rail.asReadonly(),
				actions: actions.asReadonly(),
				footer: footer.asReadonly(),
				setHeader: (t) => header.set(t),
				setContent: (t) => content.set(t),
				setRail: (t) => rail.set(t),
				setActions: (t) => actions.set(t),
				setFooter: (t) => footer.set(t)
			};
		}
	};
}
var DrawerPortalComponent = class DrawerPortalComponent extends PortalComponent {
	_portal;
	_component;
	_config;
	_slots;
	_warnedHeader;
	_warnedActions;
	constructor() {
		super();
		this._config = inject(DRAWER_CONFIG, { optional: true }) ?? void 0;
		this._slots = inject(DRAWER_SLOTS);
		this._warnedHeader = false;
		this._warnedActions = false;
		effect(() => {
			const hasHeaderTemplate = this._slots.header() !== null;
			const hasHeaderConfig = Boolean(this._config?.header) || Boolean(this._config?.subheader);
			if (hasHeaderTemplate && hasHeaderConfig && !this._warnedHeader) {
				console.warn("[DrawerPortalComponent] Header template provided while drawerConfig.header/subheader is set. The template takes precedence.");
				this._warnedHeader = true;
			}
			const hasActionsTemplate = this._slots.actions() !== null;
			const actions = this._config?.actions;
			const hasActionsConfig = Array.isArray(actions) && actions.length > 0;
			if (hasActionsTemplate && hasActionsConfig && !this._warnedActions) {
				console.warn("[DrawerPortalComponent] Actions template provided while drawerConfig.actions is set. The template takes precedence.");
				this._warnedActions = true;
			}
		});
	}
	get drawer() {
		return this._component;
	}
	get drawerConfig() {
		return this._config;
	}
	get portal() {
		return this._portal;
	}
	get headerTemplate() {
		return this._slots.header();
	}
	get actionsTemplate() {
		return this._slots.actions();
	}
	get footerTemplate() {
		return this._slots.footer();
	}
	get contentTemplate() {
		return this._slots.content();
	}
	get railTemplate() {
		return this._slots.rail();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DrawerPortalComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: DrawerPortalComponent,
		isStandalone: true,
		selector: "mosaik-drawer-portal",
		host: { classAttribute: "drawer-portal" },
		providers: [provideDrawerSlots()],
		viewQueries: [{
			propertyName: "_portal",
			first: true,
			predicate: CdkPortalOutlet,
			descendants: true,
			static: true
		}, {
			propertyName: "_component",
			first: true,
			predicate: DrawerComponent,
			descendants: true,
			static: true
		}],
		exportAs: ["mosaikDrawerPortal"],
		usesInheritance: true,
		ngImport: i0,
		template: "<mosaik-drawer [closeable]=\"(this.drawerConfig?.closeable | of | async) ?? false\"\n               [enter]=\"this.drawerConfig?.enter\"\n               [exit]=\"this.drawerConfig?.exit\"\n               [width]=\"this.drawerConfig?.size?.width ?? 'auto'\"\n               [height]=\"this.drawerConfig?.size?.height ?? 'auto'\">\n    @if (this.headerTemplate; as template) {\n    <ng-container [ngTemplateOutlet]=\"template\" />\n    } @else if ((this.drawerConfig?.header | of | async) || (this.drawerConfig?.subheader | of | async) || this.drawerConfig?.closeable) {\n    <mosaik-drawer-header>\n        <mosaik-drawer-header-text [text]=\"(this.drawerConfig?.header | of | async) ?? ''\" />\n        <mosaik-drawer-header-sub-text [text]=\"(this.drawerConfig?.subheader | of | async) ?? ''\" />\n        @if (this.drawerConfig?.closeable) {\n        <mosaik-dismiss slot=\"suffix\"\n                        (click)=\"this.drawer.close()\" />\n        }\n    </mosaik-drawer-header>\n    }\n    <mosaik-drawer-content cdkScrollable>\n        @if (this.contentTemplate; as template) {\n        <ng-container [ngTemplateOutlet]=\"template\" />\n        } @else { }\n        <ng-template cdkPortalOutlet />\n    </mosaik-drawer-content>\n    @if (this.actionsTemplate; as template) {\n    <mosaik-drawer-actions>\n        <ng-container [ngTemplateOutlet]=\"template\" />\n    </mosaik-drawer-actions>\n    } @else if (this.drawerConfig?.actions) {\n    <mosaik-drawer-actions>\n        @for (action of this.drawerConfig.actions; track action.label) {\n        @if ((action?.visible | of | async) ?? true) {\n        <mosaik-button [appearance]=\"action?.kind === 'primary' ? 'solid' : 'plain'\"\n                       [label]=\"(action?.label | of | async) ?? ''\"\n                       [disabled]=\"(action?.disabled | of | async) ?? false\"\n                       [variant]=\"'primary'\"\n                       (click)=\"action?.handler()\" />\n        }\n        }\n    </mosaik-drawer-actions>\n    }\n    @if (this.footerTemplate; as template) {\n    <mosaik-drawer-footer>\n        <ng-container [ngTemplateOutlet]=\"template\" />\n    </mosaik-drawer-footer>\n    }\n    @if (this.railTemplate; as template) {\n    <mosaik-drawer-rail>\n        <ng-container [ngTemplateOutlet]=\"template\" />\n    </mosaik-drawer-rail>\n    }\n</mosaik-drawer>\n",
		styles: [".cdk-overlay-backdrop.mosaik-cdk-backdrop{--backdrop-background-color: var(--joy-scheme-semi-transparent);--backdrop-blur: 4px;--backdrop-transition-duration: var(--mosaik-duration-short);--backdrop-transition-mode: ease;--backdrop-transition-property: opacity, backdrop-filter;background:var(--backdrop-background-color);-webkit-backdrop-filter:blur(var(--backdrop-blur));backdrop-filter:blur(var(--backdrop-blur));opacity:1;transition-duration:var(--backdrop-transition-duration);transition-timing-function:var(--backdrop-transition-mode);transition-property:var(--backdrop-transition-property)}:root[theme=joy] .cdk-overlay-backdrop.mosaik-cdk-backdrop{--backdrop-background-color: var(--joy-scheme-semi-transparent);--backdrop-blur: 4px;--backdrop-transition-duration: var(--mosaik-duration-short);--backdrop-transition-mode: ease;--backdrop-transition-property: opacity, backdrop-filter}:root[theme=memphis] .cdk-overlay-backdrop.mosaik-cdk-backdrop{--backdrop-background-color: var(--memphis-scheme-semi-transparent);--backdrop-blur: none;--backdrop-transition-duration: var(--memphis-duration-short);--backdrop-transition-mode: ease;--backdrop-transition-property: opacity}:root[theme=cosmopolitan] .cdk-overlay-backdrop.mosaik-cdk-backdrop{--backdrop-background-color: var(--cosmopolitan-scheme-semi-transparent);--backdrop-blur: none;--backdrop-transition-duration: var(--cosmopolitan-duration-short);--backdrop-transition-mode: ease;--backdrop-transition-property: opacity}@media screen and (prefers-reduced-motion:reduce){.cdk-overlay-backdrop.mosaik-cdk-backdrop{transition-duration:.01ms}}.cdk-overlay-pane.mosaik-cdk-overlay-pane{pointer-events:none}.mosaik-cdk-overlay-pane mosaik-dialog::part(backdrop),.mosaik-cdk-overlay-pane mosaik-drawer::part(backdrop),.mosaik-cdk-overlay-pane mosaik-message-box::part(backdrop),.mosaik-cdk-overlay-pane mosaik-sheet::part(backdrop),.mosaik-cdk-overlay-pane mosaik-toast::part(backdrop){opacity:0;pointer-events:none;background:transparent;-webkit-backdrop-filter:none;backdrop-filter:none}\n"],
		dependencies: [
			{
				kind: "directive",
				type: NgTemplateOutlet,
				selector: "[ngTemplateOutlet]",
				inputs: [
					"ngTemplateOutletContext",
					"ngTemplateOutlet",
					"ngTemplateOutletInjector"
				]
			},
			{
				kind: "directive",
				type: CdkScrollable,
				selector: "[cdk-scrollable], [cdkScrollable]"
			},
			{
				kind: "directive",
				type: CdkPortalOutlet,
				selector: "[cdkPortalOutlet]",
				inputs: ["cdkPortalOutlet"],
				outputs: ["attached"],
				exportAs: ["cdkPortalOutlet"]
			},
			{
				kind: "component",
				type: DrawerComponent,
				selector: "mosaik-drawer",
				inputs: [
					"isFullScreen",
					"header",
					"subHeader",
					"position",
					"mode",
					"hasShadow",
					"themeName",
					"enter",
					"exit",
					"width",
					"height",
					"elevation",
					"isOpen",
					"hasBackdrop",
					"pressEscapeToClose",
					"clickOutsideToClose",
					"attention",
					"closeable",
					"dir",
					"lang"
				],
				outputs: [
					"closed",
					"opened",
					"closeAttempted",
					"connected",
					"disconnected",
					"changed"
				]
			},
			{
				kind: "component",
				type: DrawerHeaderComponent,
				selector: "mosaik-drawer-header",
				inputs: [
					"text",
					"subText",
					"themeName",
					"formatter",
					"dir",
					"lang"
				],
				outputs: [
					"connected",
					"disconnected",
					"changed"
				]
			},
			{
				kind: "component",
				type: DrawerHeaderTextComponent,
				selector: "mosaik-drawer-header-text",
				inputs: [
					"text",
					"themeName",
					"formatter",
					"dir",
					"lang"
				],
				outputs: [
					"connected",
					"disconnected",
					"changed"
				]
			},
			{
				kind: "component",
				type: DrawerHeaderSubTextComponent,
				selector: "mosaik-drawer-header-sub-text",
				inputs: [
					"text",
					"themeName",
					"formatter",
					"dir",
					"lang"
				],
				outputs: [
					"connected",
					"disconnected",
					"changed"
				]
			},
			{
				kind: "component",
				type: DrawerContentComponent,
				selector: "mosaik-drawer-content",
				inputs: [
					"isOpen",
					"themeName",
					"dir",
					"lang"
				],
				outputs: [
					"connected",
					"disconnected",
					"changed"
				]
			},
			{
				kind: "component",
				type: DrawerActionsComponent,
				selector: "mosaik-drawer-actions",
				inputs: [
					"themeName",
					"dir",
					"lang"
				],
				outputs: [
					"connected",
					"disconnected",
					"changed"
				]
			},
			{
				kind: "component",
				type: DismissComponent,
				selector: "mosaik-dismiss",
				inputs: [
					"themeName",
					"variant",
					"appearance",
					"size",
					"disabled",
					"isFocused",
					"dir",
					"lang"
				],
				outputs: [
					"connected",
					"disconnected",
					"changed"
				]
			},
			{
				kind: "component",
				type: ButtonComponent,
				selector: "mosaik-button",
				inputs: [
					"download",
					"href",
					"rel",
					"target",
					"themeName",
					"reverse",
					"orientation",
					"horizontalContentAlignment",
					"verticalContentAlignment",
					"fit",
					"isBusy",
					"label",
					"icon",
					"iconPosition",
					"iconSize",
					"type",
					"ripple",
					"variant",
					"appearance",
					"size",
					"value",
					"disabled",
					"isFocused",
					"dir",
					"lang"
				],
				outputs: [
					"connected",
					"disconnected",
					"changed"
				]
			},
			{
				kind: "component",
				type: DrawerFooterComponent,
				selector: "mosaik-drawer-footer",
				inputs: [
					"themeName",
					"dir",
					"lang"
				],
				outputs: [
					"connected",
					"disconnected",
					"changed"
				]
			},
			{
				kind: "component",
				type: DrawerRailComponent,
				selector: "mosaik-drawer-rail",
				inputs: [
					"themeName",
					"dir",
					"lang"
				],
				outputs: [
					"connected",
					"disconnected",
					"changed"
				]
			},
			{
				kind: "pipe",
				type: AsyncPipe,
				name: "async"
			},
			{
				kind: "pipe",
				type: OfPipe,
				name: "of"
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush,
		encapsulation: i0.ViewEncapsulation.None
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DrawerPortalComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-drawer-portal",
			exportAs: "mosaikDrawerPortal",
			host: { class: "drawer-portal" },
			changeDetection: ChangeDetectionStrategy.OnPush,
			encapsulation: ViewEncapsulation.None,
			providers: [provideDrawerSlots()],
			imports: [
				AsyncPipe,
				NgTemplateOutlet,
				OfPipe,
				CdkScrollable,
				CdkPortalOutlet,
				DrawerComponent,
				DrawerHeaderComponent,
				DrawerHeaderTextComponent,
				DrawerHeaderSubTextComponent,
				DrawerContentComponent,
				DrawerActionsComponent,
				DismissComponent,
				ButtonComponent,
				DrawerFooterComponent,
				DrawerRailComponent
			],
			template: "<mosaik-drawer [closeable]=\"(this.drawerConfig?.closeable | of | async) ?? false\"\n               [enter]=\"this.drawerConfig?.enter\"\n               [exit]=\"this.drawerConfig?.exit\"\n               [width]=\"this.drawerConfig?.size?.width ?? 'auto'\"\n               [height]=\"this.drawerConfig?.size?.height ?? 'auto'\">\n    @if (this.headerTemplate; as template) {\n    <ng-container [ngTemplateOutlet]=\"template\" />\n    } @else if ((this.drawerConfig?.header | of | async) || (this.drawerConfig?.subheader | of | async) || this.drawerConfig?.closeable) {\n    <mosaik-drawer-header>\n        <mosaik-drawer-header-text [text]=\"(this.drawerConfig?.header | of | async) ?? ''\" />\n        <mosaik-drawer-header-sub-text [text]=\"(this.drawerConfig?.subheader | of | async) ?? ''\" />\n        @if (this.drawerConfig?.closeable) {\n        <mosaik-dismiss slot=\"suffix\"\n                        (click)=\"this.drawer.close()\" />\n        }\n    </mosaik-drawer-header>\n    }\n    <mosaik-drawer-content cdkScrollable>\n        @if (this.contentTemplate; as template) {\n        <ng-container [ngTemplateOutlet]=\"template\" />\n        } @else { }\n        <ng-template cdkPortalOutlet />\n    </mosaik-drawer-content>\n    @if (this.actionsTemplate; as template) {\n    <mosaik-drawer-actions>\n        <ng-container [ngTemplateOutlet]=\"template\" />\n    </mosaik-drawer-actions>\n    } @else if (this.drawerConfig?.actions) {\n    <mosaik-drawer-actions>\n        @for (action of this.drawerConfig.actions; track action.label) {\n        @if ((action?.visible | of | async) ?? true) {\n        <mosaik-button [appearance]=\"action?.kind === 'primary' ? 'solid' : 'plain'\"\n                       [label]=\"(action?.label | of | async) ?? ''\"\n                       [disabled]=\"(action?.disabled | of | async) ?? false\"\n                       [variant]=\"'primary'\"\n                       (click)=\"action?.handler()\" />\n        }\n        }\n    </mosaik-drawer-actions>\n    }\n    @if (this.footerTemplate; as template) {\n    <mosaik-drawer-footer>\n        <ng-container [ngTemplateOutlet]=\"template\" />\n    </mosaik-drawer-footer>\n    }\n    @if (this.railTemplate; as template) {\n    <mosaik-drawer-rail>\n        <ng-container [ngTemplateOutlet]=\"template\" />\n    </mosaik-drawer-rail>\n    }\n</mosaik-drawer>\n",
			styles: [".cdk-overlay-backdrop.mosaik-cdk-backdrop{--backdrop-background-color: var(--joy-scheme-semi-transparent);--backdrop-blur: 4px;--backdrop-transition-duration: var(--mosaik-duration-short);--backdrop-transition-mode: ease;--backdrop-transition-property: opacity, backdrop-filter;background:var(--backdrop-background-color);-webkit-backdrop-filter:blur(var(--backdrop-blur));backdrop-filter:blur(var(--backdrop-blur));opacity:1;transition-duration:var(--backdrop-transition-duration);transition-timing-function:var(--backdrop-transition-mode);transition-property:var(--backdrop-transition-property)}:root[theme=joy] .cdk-overlay-backdrop.mosaik-cdk-backdrop{--backdrop-background-color: var(--joy-scheme-semi-transparent);--backdrop-blur: 4px;--backdrop-transition-duration: var(--mosaik-duration-short);--backdrop-transition-mode: ease;--backdrop-transition-property: opacity, backdrop-filter}:root[theme=memphis] .cdk-overlay-backdrop.mosaik-cdk-backdrop{--backdrop-background-color: var(--memphis-scheme-semi-transparent);--backdrop-blur: none;--backdrop-transition-duration: var(--memphis-duration-short);--backdrop-transition-mode: ease;--backdrop-transition-property: opacity}:root[theme=cosmopolitan] .cdk-overlay-backdrop.mosaik-cdk-backdrop{--backdrop-background-color: var(--cosmopolitan-scheme-semi-transparent);--backdrop-blur: none;--backdrop-transition-duration: var(--cosmopolitan-duration-short);--backdrop-transition-mode: ease;--backdrop-transition-property: opacity}@media screen and (prefers-reduced-motion:reduce){.cdk-overlay-backdrop.mosaik-cdk-backdrop{transition-duration:.01ms}}.cdk-overlay-pane.mosaik-cdk-overlay-pane{pointer-events:none}.mosaik-cdk-overlay-pane mosaik-dialog::part(backdrop),.mosaik-cdk-overlay-pane mosaik-drawer::part(backdrop),.mosaik-cdk-overlay-pane mosaik-message-box::part(backdrop),.mosaik-cdk-overlay-pane mosaik-sheet::part(backdrop),.mosaik-cdk-overlay-pane mosaik-toast::part(backdrop){opacity:0;pointer-events:none;background:transparent;-webkit-backdrop-filter:none;backdrop-filter:none}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		_portal: [{
			type: ViewChild,
			args: [CdkPortalOutlet, { static: true }]
		}],
		_component: [{
			type: ViewChild,
			args: [DrawerComponent, { static: true }]
		}]
	}
});
var DrawerRef = class extends PortalRef {
	_positionChangedSubject;
	_sizeChangedSubject;
	_drawerElement;
	constructor(id, component, overlayRef, data) {
		super(id, component, overlayRef, data);
		this._positionChangedSubject = new Subject();
		this._sizeChangedSubject = new Subject();
		const drawerElement = overlayRef.hostElement.querySelector("mosaik-drawer");
		if (!drawerElement) throw new Error("DrawerElement not found in overlay host element.");
		this._drawerElement = drawerElement;
	}
	get element() {
		return this._drawerElement;
	}
	close(result) {
		this._positionChangedSubject.complete();
		this._sizeChangedSubject.complete();
		super.close(result);
		this.component.close();
	}
	requestAttention(animation) {
		return this.element.requestAttention(animation);
	}
	get positionChanged() {
		return this._positionChangedSubject.asObservable();
	}
	get sizeChanged() {
		return this._sizeChangedSubject.asObservable();
	}
	updatePosition(position) {
		const strategy = this.overlayRef.getConfig().positionStrategy;
		if (position.left || position.right) {
			if (position.left) strategy.left(this.parseNumber(position.left));
			else if (position.right) strategy.right(this.parseNumber(position.right));
		} else strategy.centerHorizontally();
		if (position.top || position.bottom) {
			if (position.top) strategy.top(this.parseNumber(position.top));
			else strategy.bottom(this.parseNumber(position.bottom));
		} else strategy.centerVertically();
		this.overlayRef.updatePosition();
		this._positionChangedSubject.next(position);
		return this;
	}
	updateSize(size) {
		this.overlayRef.updateSize({
			width: size.width,
			height: size.height
		});
		this.overlayRef.updatePosition();
		this._sizeChangedSubject.next(size);
		return this;
	}
	parseNumber(size) {
		if (typeof size === "string") return size;
		else if (typeof size === "number") return `${size}px`;
		return "";
	}
};
var DrawerService = class DrawerService extends PortalProvider {
	_behaviors;
	_defaultConfig;
	_portalInjector;
	constructor() {
		super();
		this._behaviors = new Array();
		this._defaultConfig = inject(DRAWER_CONFIG, { optional: true }) ?? {};
		for (const behavior of inject(DRAWER_BEHAVIORS, { optional: true }) ?? []) this.withBehavior(behavior);
	}
	show(componentTypeOrTemplateRef, config) {
		const resolvedConfig = this.createConfig(config);
		if (resolvedConfig) for (const behavior of this._behaviors) behavior.configure(resolvedConfig);
		const overlayRef = this.createOverlay({
			hasBackdrop: resolvedConfig?.hasBackdrop,
			disposeOnNavigation: resolvedConfig?.closeOnNavigation
		}, {
			backdropStackKey: "drawer",
			backdropStrategy: resolvedConfig?.backdropStrategy
		});
		const portal = this.createPortal(DrawerPortalComponent, overlayRef, resolvedConfig);
		const componentRef = this.createComponent(portal, overlayRef, DrawerPortalComponent, resolvedConfig);
		this._portalInjector = componentRef.injector;
		const drawerRef = new DrawerRef(this.createId(), componentRef.instance.drawer, overlayRef, resolvedConfig?.data);
		this.createContent(componentTypeOrTemplateRef, componentRef.instance, drawerRef, resolvedConfig);
		this.prepareComponent(overlayRef, componentRef.instance.drawer, drawerRef, resolvedConfig);
		this.attach(overlayRef, portal);
		componentRef.instance.drawer.open();
		this._behaviors.forEach((behavior) => behavior.attach(drawerRef, portal, resolvedConfig));
		return drawerRef;
	}
	close(ref) {
		this.detach(ref.overlayRef);
	}
	isShown(ref) {
		return this.cache.some((x) => x.overlay === ref.overlayRef && x.portal.isAttached);
	}
	withBehavior(type) {
		const behavior = this.injector.get(type);
		this._behaviors.push(behavior);
		return this;
	}
	createId() {
		return EID.next("mosaik-drawer");
	}
	createPortalInjector(config) {
		return new StatelessInjector(this.injector, [[DRAWER_CONFIG, config]]);
	}
	createContentInjector(ref, config) {
		return new StatelessInjector(this._portalInjector ?? this.injector, [
			[DRAWER_REF, ref],
			[DRAWER_REF_DATA, ref.data],
			[DRAWER_CONFIG, config]
		]);
	}
	createPositionStrategy() {
		return this.overlayPositionBuilder.global().centerVertically().centerHorizontally();
	}
	createScrollStrategy() {
		return this.overlay.scrollStrategies.block();
	}
	createComponent(portal, overlayRef, _component, config) {
		if (config?.singleton) {
			const overlayRefs = this.cache.filter((x) => x.overlay !== overlayRef);
			const detachments = new Array();
			for (const ref of overlayRefs) {
				ref.overlay.detach();
				detachments.push(ref);
			}
			const sub = overlayRef.detachments().subscribe(() => {
				sub.unsubscribe();
				for (const entry of detachments) entry.overlay.attach(entry.portal);
			});
		}
		return overlayRef.attach(portal);
	}
	prepareComponent(overlayRef, component, drawerRef, config) {
		if (config) {
			Object.keys(config).forEach((p) => {
				if (p in component && typeof component.setInput === "function") component.setInput(p, config[p]);
			});
			if (config.clickOutsideToClose) connectOverlayOutsideClose(overlayRef, drawerRef.closed, () => drawerRef.requestClose("outside", Cancel.negative()));
		}
		component.setInput("pressEscapeToClose", false);
		component.setInput("clickOutsideToClose", false);
		if (config?.pressEscapeToClose) connectOverlayEscapeClose(overlayRef, drawerRef.closed, () => drawerRef.requestClose("escape", Cancel.negative()));
		else connectOverlayEscapeBlock(overlayRef, drawerRef.closed);
		const closedSubscription = component.closed.subscribe(() => {
			closedSubscription.unsubscribe();
			drawerRef.close(Cancel.none());
			this.detach(overlayRef);
			this._behaviors.forEach((x) => x.detach(drawerRef));
		});
	}
	createConfig(config) {
		const defaultConfig = this._defaultConfig;
		if (!this.hasConfig(defaultConfig) && !this.hasConfig(config)) return;
		return {
			...defaultConfig,
			...config,
			size: this.mergeSize(defaultConfig.size, config?.size),
			minSize: this.mergeSize(defaultConfig.minSize, config?.minSize),
			maxSize: this.mergeSize(defaultConfig.maxSize, config?.maxSize)
		};
	}
	hasConfig(config) {
		return config !== void 0 && Object.keys(config).length > 0;
	}
	mergeSize(defaultSize, size) {
		if (!defaultSize && !size) return;
		return {
			...defaultSize,
			...size
		};
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DrawerService,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DrawerService
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DrawerService,
	decorators: [{ type: Injectable }],
	ctorParameters: () => []
});
function provideDrawers(...withFeatures) {
	const behaviorTypes = withFeatures.map((feature) => feature.behaviorType).filter((behaviorType) => behaviorType !== void 0);
	return makeEnvironmentProviders([
		{
			provide: DRAWER_BEHAVIORS,
			useValue: behaviorTypes
		},
		{
			provide: DrawerService,
			useClass: DrawerService
		},
		...withFeatures.flatMap((feature) => feature.provide())
	]);
}
function withDrawerDefaultBehavior(config) {
	return {
		id: "drawerDefaultBehavior",
		provide: () => config ? [{
			provide: DRAWER_CONFIG,
			useValue: config
		}] : []
	};
}
function withDrawerBreakpointBehavior(config) {
	return {
		id: "drawerBreakpointBehavior",
		behaviorType: DrawerBreakpointBehavior,
		provide: () => [{
			provide: DRAWER_BREAKPOINT_BEHAVIOR_CONFIG,
			useValue: config
		}, {
			provide: DrawerBreakpointBehavior,
			useClass: DrawerBreakpointBehavior
		}]
	};
}
function withDrawerStackBehavior(config) {
	return {
		id: "drawerStackBehavior",
		behaviorType: DrawerStackBehavior,
		provide: () => [{
			provide: DRAWER_STACK_BEHAVIOR_CONFIG,
			useValue: config
		}, {
			provide: DrawerStackBehavior,
			useClass: DrawerStackBehavior
		}]
	};
}
var DrawerActionsDirective = class DrawerActionsDirective {
	_slots = inject(DRAWER_SLOTS);
	constructor(template) {
		this._slots.setActions(template);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DrawerActionsDirective,
		deps: [{ token: i0.TemplateRef }],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: DrawerActionsDirective,
		isStandalone: true,
		selector: "ng-template[mosaikDrawerActions]",
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DrawerActionsDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "ng-template[mosaikDrawerActions]" }]
	}],
	ctorParameters: () => [{ type: i0.TemplateRef }]
});
var DrawerContentDirective = class DrawerContentDirective {
	_slots = inject(DRAWER_SLOTS);
	constructor(template) {
		this._slots.setContent(template);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DrawerContentDirective,
		deps: [{ token: i0.TemplateRef }],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: DrawerContentDirective,
		isStandalone: true,
		selector: "ng-template[mosaikDrawerContent]",
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DrawerContentDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "ng-template[mosaikDrawerContent]" }]
	}],
	ctorParameters: () => [{ type: i0.TemplateRef }]
});
var DrawerFooterDirective = class DrawerFooterDirective {
	_slots = inject(DRAWER_SLOTS);
	constructor(template) {
		this._slots.setFooter(template);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DrawerFooterDirective,
		deps: [{ token: i0.TemplateRef }],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: DrawerFooterDirective,
		isStandalone: true,
		selector: "ng-template[mosaikDrawerFooter]",
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DrawerFooterDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "ng-template[mosaikDrawerFooter]" }]
	}],
	ctorParameters: () => [{ type: i0.TemplateRef }]
});
var DrawerHeaderDirective = class DrawerHeaderDirective {
	_slots = inject(DRAWER_SLOTS);
	constructor(template) {
		this._slots.setHeader(template);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DrawerHeaderDirective,
		deps: [{ token: i0.TemplateRef }],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: DrawerHeaderDirective,
		isStandalone: true,
		selector: "ng-template[mosaikDrawerHeader]",
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DrawerHeaderDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "ng-template[mosaikDrawerHeader]" }]
	}],
	ctorParameters: () => [{ type: i0.TemplateRef }]
});
var DrawerRailDirective = class DrawerRailDirective {
	_slots;
	_template;
	constructor() {
		this._slots = inject(DRAWER_SLOTS);
		this._template = inject(TemplateRef);
		this._slots.setRail(this._template);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DrawerRailDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: DrawerRailDirective,
		isStandalone: true,
		selector: "ng-template[mosaikDrawerRail]",
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DrawerRailDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "ng-template[mosaikDrawerRail]" }]
	}],
	ctorParameters: () => []
});
const MESSAGE_BOX_CONFIG = new InjectionToken("MOSAIK_MESSAGE_BOX_CONFIG");
const MESSAGE_BOX_REF = new InjectionToken("MOSAIK_MESSAGE_BOX_REF");
const MESSAGE_BOX_REF_DATA = new InjectionToken("MOSAIK_MESSAGE_BOX_REF_DATA");
const MESSAGE_BOX_BEHAVIORS = new InjectionToken("MOSAIK_MESSAGE_BOX_BEHAVIORS");
var MessageBoxPortalComponent = class MessageBoxPortalComponent extends PortalComponent {
	_portal;
	_component;
	_config;
	constructor() {
		super();
		this._config = inject(MESSAGE_BOX_CONFIG, { optional: true }) ?? void 0;
	}
	get portal() {
		return this._portal;
	}
	get messageBox() {
		return this._component;
	}
	get config() {
		return this._config;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: MessageBoxPortalComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: MessageBoxPortalComponent,
		isStandalone: true,
		selector: "mosaik-message-box-portal",
		host: { classAttribute: "message-box-portal" },
		viewQueries: [{
			propertyName: "_portal",
			first: true,
			predicate: CdkPortalOutlet,
			descendants: true,
			static: true
		}, {
			propertyName: "_component",
			first: true,
			predicate: MessageBoxComponent,
			descendants: true,
			static: true
		}],
		exportAs: ["mosaikMessageBoxPortal"],
		usesInheritance: true,
		ngImport: i0,
		template: "<mosaik-message-box>\n    <ng-template cdkPortalOutlet></ng-template>\n</mosaik-message-box>",
		styles: [":host{width:100vw;height:100vh}\n", ".cdk-overlay-backdrop.mosaik-cdk-backdrop{--backdrop-background-color: var(--joy-scheme-semi-transparent);--backdrop-blur: 4px;--backdrop-transition-duration: var(--mosaik-duration-short);--backdrop-transition-mode: ease;--backdrop-transition-property: opacity, backdrop-filter;background:var(--backdrop-background-color);-webkit-backdrop-filter:blur(var(--backdrop-blur));backdrop-filter:blur(var(--backdrop-blur));opacity:1;transition-duration:var(--backdrop-transition-duration);transition-timing-function:var(--backdrop-transition-mode);transition-property:var(--backdrop-transition-property)}:root[theme=joy] .cdk-overlay-backdrop.mosaik-cdk-backdrop{--backdrop-background-color: var(--joy-scheme-semi-transparent);--backdrop-blur: 4px;--backdrop-transition-duration: var(--mosaik-duration-short);--backdrop-transition-mode: ease;--backdrop-transition-property: opacity, backdrop-filter}:root[theme=memphis] .cdk-overlay-backdrop.mosaik-cdk-backdrop{--backdrop-background-color: var(--memphis-scheme-semi-transparent);--backdrop-blur: none;--backdrop-transition-duration: var(--memphis-duration-short);--backdrop-transition-mode: ease;--backdrop-transition-property: opacity}:root[theme=cosmopolitan] .cdk-overlay-backdrop.mosaik-cdk-backdrop{--backdrop-background-color: var(--cosmopolitan-scheme-semi-transparent);--backdrop-blur: none;--backdrop-transition-duration: var(--cosmopolitan-duration-short);--backdrop-transition-mode: ease;--backdrop-transition-property: opacity}@media screen and (prefers-reduced-motion:reduce){.cdk-overlay-backdrop.mosaik-cdk-backdrop{transition-duration:.01ms}}.cdk-overlay-pane.mosaik-cdk-overlay-pane{pointer-events:none}.mosaik-cdk-overlay-pane mosaik-dialog::part(backdrop),.mosaik-cdk-overlay-pane mosaik-drawer::part(backdrop),.mosaik-cdk-overlay-pane mosaik-message-box::part(backdrop),.mosaik-cdk-overlay-pane mosaik-sheet::part(backdrop),.mosaik-cdk-overlay-pane mosaik-toast::part(backdrop){opacity:0;pointer-events:none;background:transparent;-webkit-backdrop-filter:none;backdrop-filter:none}\n"],
		dependencies: [{
			kind: "directive",
			type: CdkPortalOutlet,
			selector: "[cdkPortalOutlet]",
			inputs: ["cdkPortalOutlet"],
			outputs: ["attached"],
			exportAs: ["cdkPortalOutlet"]
		}, {
			kind: "component",
			type: MessageBoxComponent,
			selector: "mosaik-message-box",
			inputs: [
				"intl",
				"header",
				"subHeader",
				"message",
				"buttons",
				"initialResult",
				"icon",
				"alignment",
				"formatter",
				"variant",
				"isFullScreen",
				"isDraggable",
				"themeName",
				"enter",
				"exit",
				"width",
				"height",
				"elevation",
				"appearance",
				"isOpen",
				"hasBackdrop",
				"pressEscapeToClose",
				"clickOutsideToClose",
				"attention",
				"closeable",
				"dir",
				"lang"
			],
			outputs: [
				"dialogResult",
				"opened",
				"closed",
				"closeAttempted",
				"connected",
				"disconnected",
				"changed"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush,
		encapsulation: i0.ViewEncapsulation.None
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MessageBoxPortalComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-message-box-portal",
			exportAs: "mosaikMessageBoxPortal",
			host: { class: "message-box-portal" },
			changeDetection: ChangeDetectionStrategy.OnPush,
			encapsulation: ViewEncapsulation.None,
			imports: [CdkPortalOutlet, MessageBoxComponent],
			template: "<mosaik-message-box>\n    <ng-template cdkPortalOutlet></ng-template>\n</mosaik-message-box>",
			styles: [":host{width:100vw;height:100vh}\n", ".cdk-overlay-backdrop.mosaik-cdk-backdrop{--backdrop-background-color: var(--joy-scheme-semi-transparent);--backdrop-blur: 4px;--backdrop-transition-duration: var(--mosaik-duration-short);--backdrop-transition-mode: ease;--backdrop-transition-property: opacity, backdrop-filter;background:var(--backdrop-background-color);-webkit-backdrop-filter:blur(var(--backdrop-blur));backdrop-filter:blur(var(--backdrop-blur));opacity:1;transition-duration:var(--backdrop-transition-duration);transition-timing-function:var(--backdrop-transition-mode);transition-property:var(--backdrop-transition-property)}:root[theme=joy] .cdk-overlay-backdrop.mosaik-cdk-backdrop{--backdrop-background-color: var(--joy-scheme-semi-transparent);--backdrop-blur: 4px;--backdrop-transition-duration: var(--mosaik-duration-short);--backdrop-transition-mode: ease;--backdrop-transition-property: opacity, backdrop-filter}:root[theme=memphis] .cdk-overlay-backdrop.mosaik-cdk-backdrop{--backdrop-background-color: var(--memphis-scheme-semi-transparent);--backdrop-blur: none;--backdrop-transition-duration: var(--memphis-duration-short);--backdrop-transition-mode: ease;--backdrop-transition-property: opacity}:root[theme=cosmopolitan] .cdk-overlay-backdrop.mosaik-cdk-backdrop{--backdrop-background-color: var(--cosmopolitan-scheme-semi-transparent);--backdrop-blur: none;--backdrop-transition-duration: var(--cosmopolitan-duration-short);--backdrop-transition-mode: ease;--backdrop-transition-property: opacity}@media screen and (prefers-reduced-motion:reduce){.cdk-overlay-backdrop.mosaik-cdk-backdrop{transition-duration:.01ms}}.cdk-overlay-pane.mosaik-cdk-overlay-pane{pointer-events:none}.mosaik-cdk-overlay-pane mosaik-dialog::part(backdrop),.mosaik-cdk-overlay-pane mosaik-drawer::part(backdrop),.mosaik-cdk-overlay-pane mosaik-message-box::part(backdrop),.mosaik-cdk-overlay-pane mosaik-sheet::part(backdrop),.mosaik-cdk-overlay-pane mosaik-toast::part(backdrop){opacity:0;pointer-events:none;background:transparent;-webkit-backdrop-filter:none;backdrop-filter:none}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		_portal: [{
			type: ViewChild,
			args: [CdkPortalOutlet, { static: true }]
		}],
		_component: [{
			type: ViewChild,
			args: [MessageBoxComponent, { static: true }]
		}]
	}
});
var MessageBoxRef = class extends PortalRef {
	_messageBoxElement;
	constructor(id, component, overlayRef, data) {
		super(id, component, overlayRef, data);
		const messageBoxElement = overlayRef.hostElement.querySelector("mosaik-message-box");
		if (!messageBoxElement) throw new Error("MessageBoxElement not found in overlay host element.");
		this._messageBoxElement = messageBoxElement;
	}
	get element() {
		return this._messageBoxElement;
	}
	requestAttention(animation) {
		return this.element.requestAttention(animation);
	}
};
var MessageBoxService = class MessageBoxService extends PortalProvider {
	_messageBoxBehaviors;
	constructor(config = null, behaviors = null) {
		super();
		this._messageBoxBehaviors = new Array();
		for (const behavior of behaviors ?? []) this.withBehavior(behavior);
	}
	show(config) {
		if (config) for (const behavior of this._messageBoxBehaviors) behavior.configure(config);
		const overlayRef = this.createOverlay({
			hasBackdrop: config?.hasBackdrop ?? true,
			disposeOnNavigation: config?.closeOnNavigation
		}, {
			backdropStackKey: "message-box",
			backdropStrategy: config?.backdropStrategy
		});
		const portal = this.createPortal(MessageBoxPortalComponent, overlayRef, config);
		const componentRef = this.createComponent(portal, overlayRef, MessageBoxPortalComponent, config);
		const messageBoxRef = new MessageBoxRef(this.createId(), componentRef.instance.messageBox, overlayRef, config?.data);
		this.prepareComponent(overlayRef, componentRef.instance.messageBox, messageBoxRef, config);
		this.attach(overlayRef, portal);
		componentRef.instance.messageBox.open();
		this._messageBoxBehaviors.forEach((x) => x.attach(messageBoxRef, portal));
		return messageBoxRef;
	}
	close(ref) {
		this.detach(ref.overlayRef);
	}
	isShown(ref) {
		return this.cache.some((x) => x.overlay === ref.overlayRef && x.portal.isAttached);
	}
	withBehavior(type) {
		const behavior = this.injector.get(type);
		this._messageBoxBehaviors.push(behavior);
		return this;
	}
	createId() {
		return EID.next("mosaik-message-box");
	}
	createPortalInjector(config) {
		return new StatelessInjector(this.injector, [[MESSAGE_BOX_CONFIG, config]]);
	}
	createContentInjector(ref, config) {
		return new StatelessInjector(this.injector, [
			[MESSAGE_BOX_REF, ref],
			[MESSAGE_BOX_REF_DATA, ref.data],
			[MESSAGE_BOX_CONFIG, config]
		]);
	}
	createPositionStrategy() {
		return this.overlayPositionBuilder.global().centerVertically().centerHorizontally();
	}
	createScrollStrategy() {
		return this.overlay.scrollStrategies.block();
	}
	prepareComponent(overlayRef, component, messageBoxRef, config) {
		if (config) {
			Object.keys(config).forEach((p) => {
				if (p === "intl") return;
				if (p in component && typeof component.setInput === "function") component.setInput(p, config[p]);
			});
			if (config.intl) Object.assign(messageBoxRef.element.intl, config.intl);
			if (config.clickOutsideToClose) connectOverlayOutsideClose(overlayRef, messageBoxRef.closed, () => messageBoxRef.requestClose("outside", Cancel.negative()));
		}
		component.setInput("pressEscapeToClose", false);
		component.setInput("clickOutsideToClose", false);
		if (config?.pressEscapeToClose) connectOverlayEscapeClose(overlayRef, messageBoxRef.closed, () => messageBoxRef.requestClose("escape", Cancel.negative()));
		else connectOverlayEscapeBlock(overlayRef, messageBoxRef.closed);
		const dialogResultSubscription = component.dialogResult.subscribe((result) => {
			dialogResultSubscription.unsubscribe();
			const messageBoxResult = result;
			if (messageBoxResult === MessageBoxResult.Yes || messageBoxResult === MessageBoxResult.OK) messageBoxRef.close(Cancel.positive(messageBoxResult));
			else if (messageBoxResult === MessageBoxResult.No || messageBoxResult === MessageBoxResult.Cancel) messageBoxRef.close(Cancel.negative(messageBoxResult));
			else messageBoxRef.close(Cancel.none(messageBoxResult));
		});
		const closedSubscription = component.closed.subscribe(() => {
			closedSubscription.unsubscribe();
			dialogResultSubscription.unsubscribe();
			messageBoxRef.close(Cancel.none());
			this.detach(overlayRef);
			this._messageBoxBehaviors.forEach((x) => x.detach());
			this._messageBoxBehaviors.length = 0;
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: MessageBoxService,
		deps: [{
			token: MESSAGE_BOX_CONFIG,
			optional: true
		}, {
			token: MESSAGE_BOX_BEHAVIORS,
			optional: true
		}],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: MessageBoxService
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MessageBoxService,
	decorators: [{ type: Injectable }],
	ctorParameters: () => [{
		type: void 0,
		decorators: [{ type: Optional }, {
			type: Inject,
			args: [MESSAGE_BOX_CONFIG]
		}]
	}, {
		type: void 0,
		decorators: [{ type: Optional }, {
			type: Inject,
			args: [MESSAGE_BOX_BEHAVIORS]
		}]
	}]
});
var MessageBoxTestIdBehavior = class MessageBoxTestIdBehavior {
	_element;
	configure(config) {}
	attach(ref) {
		this._element = ref.element;
		this._element.setAttribute("test-id", "message-box");
	}
	detach() {
		this._element?.removeAttribute("test-id");
		this._element = void 0;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: MessageBoxTestIdBehavior,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: MessageBoxTestIdBehavior
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MessageBoxTestIdBehavior,
	decorators: [{ type: Injectable }]
});
function provideMessageBoxes(options) {
	return makeEnvironmentProviders([
		MessageBoxService,
		options?.config ? {
			provide: MESSAGE_BOX_CONFIG,
			useValue: options.config
		} : [],
		options?.behaviors ? {
			provide: MESSAGE_BOX_BEHAVIORS,
			useValue: options.behaviors
		} : []
	]);
}
const SHEET_CONFIG = new InjectionToken("MOSAIK_SHEET_CONFIG");
const SHEET_REF = new InjectionToken("MOSAIK_SHEET_REF");
const SHEET_REF_DATA = new InjectionToken("MOSAIK_SHEET_REF_DATA");
const SHEET_BEHAVIORS = new InjectionToken("MOSAIK_SHEET_BEHAVIORS");
const SHEET_BREAKPOINT_BEHAVIOR_CONFIG = new InjectionToken("SHEET_BREAKPOINT_OBSERVER_BEHAVIOR_CONFIG");
var SheetBehavior = class {
	_sheetRef;
	_attached;
	_sheetConfig;
	constructor() {
		this._sheetRef = null;
		this._attached = false;
		this._sheetConfig = null;
	}
	get ref() {
		if (!this._attached || this._sheetRef === null) throw new Error("The sheet behavior must be attached before its ref can be read.");
		return this._sheetRef;
	}
	get config() {
		return this._sheetConfig;
	}
	configure(config) {
		this._sheetConfig = config;
	}
	attach(ref, _portal) {
		this._sheetRef = ref;
		this._attached = true;
	}
	detach(ref) {
		if (ref === void 0 || ref === this._sheetRef) {
			this._sheetRef = null;
			this._attached = false;
		}
	}
};
var SheetBreakpointBehavior = class extends SheetBehavior {
	_breakpointObserver;
	_breakpointRegistry;
	_breakpointConfig;
	_mediaQueryToAliasMap;
	_subscription;
	constructor(config = inject(SHEET_BREAKPOINT_BEHAVIOR_CONFIG, { optional: true })) {
		super();
		this._breakpointObserver = inject(BreakpointObserver);
		this._breakpointRegistry = inject(BreakpointRegistry);
		this._breakpointConfig = config ?? null;
		this._mediaQueryToAliasMap = /* @__PURE__ */ new Map();
		this._subscription = Subscription.EMPTY;
	}
	attach(sheetRef, _portal) {
		super.attach(sheetRef, _portal);
		if (this._breakpointConfig?.breakpoints.length) {
			this._mediaQueryToAliasMap.clear();
			const breakpoints = this._breakpointConfig.breakpoints.map((x) => {
				const breakpoint = this._breakpointRegistry.findByAlias(x.breakpoint);
				if (breakpoint?.mediaQuery) this._mediaQueryToAliasMap.set(breakpoint.mediaQuery, x.breakpoint);
				return breakpoint?.mediaQuery;
			}).filter((x) => x !== void 0);
			this._subscription.unsubscribe();
			this._subscription = this._breakpointObserver.observe(breakpoints).subscribe((x) => this.onBreakpoint(x, sheetRef, this.config ?? void 0));
		}
	}
	detach(_ref) {
		this._subscription.unsubscribe();
		this._subscription = Subscription.EMPTY;
		super.detach(_ref);
	}
	onBreakpoint(state, sheetRef, config) {
		if (state.matches) Object.entries(state.breakpoints).forEach(([mediaQuery, match]) => {
			if (match) {
				const alias = this._mediaQueryToAliasMap.get(mediaQuery);
				const breakpointConfig = alias ? this._breakpointConfig?.breakpoints.find((x) => x.breakpoint === alias) ?? null : null;
				sheetRef.updateSize({
					width: breakpointConfig?.size.width,
					height: breakpointConfig?.size.height
				});
				sheetRef.component.setInput("width", breakpointConfig?.size.width ?? "100%");
				sheetRef.component.setInput("height", breakpointConfig?.size.height ?? "auto");
			}
		});
		else {
			sheetRef.updateSize({
				width: config?.width,
				height: config?.height
			});
			sheetRef.component.setInput("width", config?.width ?? "100%");
			sheetRef.component.setInput("height", config?.height ?? "auto");
		}
	}
};
const SHEET_SLOTS = new InjectionToken("MOSAIK_SHEET_SLOTS");
function provideSheetSlots() {
	return {
		provide: SHEET_SLOTS,
		useFactory: () => {
			const header = signal(null, ...ngDevMode ? [{ debugName: "header" }] : /* istanbul ignore next */ []);
			const content = signal(null, ...ngDevMode ? [{ debugName: "content" }] : /* istanbul ignore next */ []);
			const footer = signal(null, ...ngDevMode ? [{ debugName: "footer" }] : /* istanbul ignore next */ []);
			return {
				header: header.asReadonly(),
				content: content.asReadonly(),
				footer: footer.asReadonly(),
				setHeader: (t) => header.set(t),
				setContent: (t) => content.set(t),
				setFooter: (t) => footer.set(t)
			};
		}
	};
}
var SheetPortalComponent = class SheetPortalComponent extends PortalComponent {
	_portal;
	_component;
	_config;
	_slots;
	_warnedHeader;
	constructor() {
		super();
		this._config = inject(SHEET_CONFIG, { optional: true }) ?? void 0;
		this._slots = inject(SHEET_SLOTS);
		this._warnedHeader = false;
		effect(() => {
			const hasHeaderTemplate = this._slots.header() !== null;
			const hasHeaderConfig = Boolean(this._config?.header) || Boolean(this._config?.subheader);
			if (hasHeaderTemplate && hasHeaderConfig && !this._warnedHeader) {
				console.warn("[SheetPortalComponent] Header template provided while sheetConfig.header/subheader is set. The template takes precedence.");
				this._warnedHeader = true;
			}
		});
	}
	get portal() {
		return this._portal;
	}
	get sheet() {
		return this._component;
	}
	get sheetConfig() {
		return this._config;
	}
	get headerTemplate() {
		return this._slots.header();
	}
	get contentTemplate() {
		return this._slots.content();
	}
	get footerTemplate() {
		return this._slots.footer();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: SheetPortalComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: SheetPortalComponent,
		isStandalone: true,
		selector: "mosaik-sheet-portal",
		host: { classAttribute: "sheet-portal" },
		providers: [provideSheetSlots()],
		viewQueries: [{
			propertyName: "_portal",
			first: true,
			predicate: CdkPortalOutlet,
			descendants: true,
			static: true
		}, {
			propertyName: "_component",
			first: true,
			predicate: SheetComponent,
			descendants: true,
			static: true
		}],
		exportAs: ["mosaikSheetPortal"],
		usesInheritance: true,
		ngImport: i0,
		template: "<mosaik-sheet [closeable]=\"this.sheetConfig?.closeable ?? false\"\n              [width]=\"this.sheetConfig?.width\"\n              [height]=\"this.sheetConfig?.height\"\n              [position]=\"this.sheetConfig?.position\"\n              [snaps]=\"this.sheetConfig?.snaps\"\n              [activeSnapIndex]=\"this.sheetConfig?.activeSnapIndex\"\n              [closeThreshold]=\"this.sheetConfig?.closeThreshold\"\n              [elastic]=\"this.sheetConfig?.elastic\"\n              [inertia]=\"this.sheetConfig?.inertia\"\n              [dragMode]=\"this.sheetConfig?.dragMode\"\n              [hasHandle]=\"this.sheetConfig?.hasHandle\"\n              [hasSnapIndicator]=\"this.sheetConfig?.hasSnapIndicator\"\n              [isModal]=\"this.sheetConfig?.isModal ?? true\">\n    @if (this.headerTemplate; as template) {\n    <ng-container [ngTemplateOutlet]=\"template\" />\n    } @else if ((this.sheetConfig?.header | of | async) || this.sheetConfig?.closeable) {\n    <mosaik-sheet-header>\n        <mosaik-sheet-header-text [text]=\"(this.sheetConfig?.header | of | async) ?? ''\" />\n        <mosaik-sheet-header-sub-text [text]=\"(this.sheetConfig?.subheader | of | async) ?? ''\" />\n    </mosaik-sheet-header>\n    }\n    <mosaik-sheet-content cdkScrollable>\n        @if (this.contentTemplate; as template) {\n        <ng-container [ngTemplateOutlet]=\"template\" />\n        }\n        <ng-template cdkPortalOutlet />\n    </mosaik-sheet-content>\n    @if (this.footerTemplate; as template) {\n    <mosaik-sheet-footer>\n        <ng-container [ngTemplateOutlet]=\"template\" />\n    </mosaik-sheet-footer>\n    }\n</mosaik-sheet>\n",
		styles: [".cdk-overlay-backdrop.mosaik-cdk-backdrop{--backdrop-background-color: var(--joy-scheme-semi-transparent);--backdrop-blur: 4px;--backdrop-transition-duration: var(--mosaik-duration-short);--backdrop-transition-mode: ease;--backdrop-transition-property: opacity, backdrop-filter;background:var(--backdrop-background-color);-webkit-backdrop-filter:blur(var(--backdrop-blur));backdrop-filter:blur(var(--backdrop-blur));opacity:1;transition-duration:var(--backdrop-transition-duration);transition-timing-function:var(--backdrop-transition-mode);transition-property:var(--backdrop-transition-property)}:root[theme=joy] .cdk-overlay-backdrop.mosaik-cdk-backdrop{--backdrop-background-color: var(--joy-scheme-semi-transparent);--backdrop-blur: 4px;--backdrop-transition-duration: var(--mosaik-duration-short);--backdrop-transition-mode: ease;--backdrop-transition-property: opacity, backdrop-filter}:root[theme=memphis] .cdk-overlay-backdrop.mosaik-cdk-backdrop{--backdrop-background-color: var(--memphis-scheme-semi-transparent);--backdrop-blur: none;--backdrop-transition-duration: var(--memphis-duration-short);--backdrop-transition-mode: ease;--backdrop-transition-property: opacity}:root[theme=cosmopolitan] .cdk-overlay-backdrop.mosaik-cdk-backdrop{--backdrop-background-color: var(--cosmopolitan-scheme-semi-transparent);--backdrop-blur: none;--backdrop-transition-duration: var(--cosmopolitan-duration-short);--backdrop-transition-mode: ease;--backdrop-transition-property: opacity}@media screen and (prefers-reduced-motion:reduce){.cdk-overlay-backdrop.mosaik-cdk-backdrop{transition-duration:.01ms}}.cdk-overlay-pane.mosaik-cdk-overlay-pane{pointer-events:none}.mosaik-cdk-overlay-pane mosaik-dialog::part(backdrop),.mosaik-cdk-overlay-pane mosaik-drawer::part(backdrop),.mosaik-cdk-overlay-pane mosaik-message-box::part(backdrop),.mosaik-cdk-overlay-pane mosaik-sheet::part(backdrop),.mosaik-cdk-overlay-pane mosaik-toast::part(backdrop){opacity:0;pointer-events:none;background:transparent;-webkit-backdrop-filter:none;backdrop-filter:none}\n"],
		dependencies: [
			{
				kind: "directive",
				type: NgTemplateOutlet,
				selector: "[ngTemplateOutlet]",
				inputs: [
					"ngTemplateOutletContext",
					"ngTemplateOutlet",
					"ngTemplateOutletInjector"
				]
			},
			{
				kind: "directive",
				type: CdkScrollable,
				selector: "[cdk-scrollable], [cdkScrollable]"
			},
			{
				kind: "directive",
				type: CdkPortalOutlet,
				selector: "[cdkPortalOutlet]",
				inputs: ["cdkPortalOutlet"],
				outputs: ["attached"],
				exportAs: ["cdkPortalOutlet"]
			},
			{
				kind: "component",
				type: SheetComponent,
				selector: "mosaik-sheet",
				inputs: [
					"width",
					"height",
					"position",
					"snaps",
					"activeSnapIndex",
					"closeThreshold",
					"elastic",
					"inertia",
					"dragMode",
					"hasHandle",
					"hasSnapIndicator",
					"isModal",
					"themeName",
					"isOpen",
					"hasBackdrop",
					"pressEscapeToClose",
					"clickOutsideToClose",
					"attention",
					"closeable",
					"dir",
					"lang"
				],
				outputs: [
					"activeSnapChanged",
					"dragStart",
					"dragging",
					"dragEnd",
					"opened",
					"closed",
					"closeAttempted",
					"connected",
					"disconnected",
					"changed"
				]
			},
			{
				kind: "component",
				type: SheetHeaderComponent,
				selector: "mosaik-sheet-header",
				inputs: [
					"text",
					"subText",
					"themeName",
					"formatter",
					"dir",
					"lang"
				],
				outputs: [
					"connected",
					"disconnected",
					"changed"
				]
			},
			{
				kind: "component",
				type: SheetHeaderTextComponent,
				selector: "mosaik-sheet-header-text",
				inputs: [
					"text",
					"themeName",
					"formatter",
					"dir",
					"lang"
				],
				outputs: [
					"connected",
					"disconnected",
					"changed"
				]
			},
			{
				kind: "component",
				type: SheetHeaderSubTextComponent,
				selector: "mosaik-sheet-header-sub-text",
				inputs: [
					"text",
					"themeName",
					"formatter",
					"dir",
					"lang"
				],
				outputs: [
					"connected",
					"disconnected",
					"changed"
				]
			},
			{
				kind: "component",
				type: SheetContentComponent,
				selector: "mosaik-sheet-content",
				inputs: [
					"text",
					"themeName",
					"formatter",
					"dir",
					"lang"
				],
				outputs: [
					"connected",
					"disconnected",
					"changed"
				]
			},
			{
				kind: "component",
				type: SheetFooterComponent,
				selector: "mosaik-sheet-footer",
				inputs: [
					"themeName",
					"dir",
					"lang"
				],
				outputs: [
					"connected",
					"disconnected",
					"changed"
				]
			},
			{
				kind: "pipe",
				type: AsyncPipe,
				name: "async"
			},
			{
				kind: "pipe",
				type: OfPipe,
				name: "of"
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush,
		encapsulation: i0.ViewEncapsulation.None
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: SheetPortalComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-sheet-portal",
			exportAs: "mosaikSheetPortal",
			host: { class: "sheet-portal" },
			changeDetection: ChangeDetectionStrategy.OnPush,
			encapsulation: ViewEncapsulation.None,
			providers: [provideSheetSlots()],
			imports: [
				AsyncPipe,
				NgTemplateOutlet,
				OfPipe,
				CdkScrollable,
				CdkPortalOutlet,
				SheetComponent,
				SheetHeaderComponent,
				SheetHeaderTextComponent,
				SheetHeaderSubTextComponent,
				SheetContentComponent,
				SheetFooterComponent
			],
			template: "<mosaik-sheet [closeable]=\"this.sheetConfig?.closeable ?? false\"\n              [width]=\"this.sheetConfig?.width\"\n              [height]=\"this.sheetConfig?.height\"\n              [position]=\"this.sheetConfig?.position\"\n              [snaps]=\"this.sheetConfig?.snaps\"\n              [activeSnapIndex]=\"this.sheetConfig?.activeSnapIndex\"\n              [closeThreshold]=\"this.sheetConfig?.closeThreshold\"\n              [elastic]=\"this.sheetConfig?.elastic\"\n              [inertia]=\"this.sheetConfig?.inertia\"\n              [dragMode]=\"this.sheetConfig?.dragMode\"\n              [hasHandle]=\"this.sheetConfig?.hasHandle\"\n              [hasSnapIndicator]=\"this.sheetConfig?.hasSnapIndicator\"\n              [isModal]=\"this.sheetConfig?.isModal ?? true\">\n    @if (this.headerTemplate; as template) {\n    <ng-container [ngTemplateOutlet]=\"template\" />\n    } @else if ((this.sheetConfig?.header | of | async) || this.sheetConfig?.closeable) {\n    <mosaik-sheet-header>\n        <mosaik-sheet-header-text [text]=\"(this.sheetConfig?.header | of | async) ?? ''\" />\n        <mosaik-sheet-header-sub-text [text]=\"(this.sheetConfig?.subheader | of | async) ?? ''\" />\n    </mosaik-sheet-header>\n    }\n    <mosaik-sheet-content cdkScrollable>\n        @if (this.contentTemplate; as template) {\n        <ng-container [ngTemplateOutlet]=\"template\" />\n        }\n        <ng-template cdkPortalOutlet />\n    </mosaik-sheet-content>\n    @if (this.footerTemplate; as template) {\n    <mosaik-sheet-footer>\n        <ng-container [ngTemplateOutlet]=\"template\" />\n    </mosaik-sheet-footer>\n    }\n</mosaik-sheet>\n",
			styles: [".cdk-overlay-backdrop.mosaik-cdk-backdrop{--backdrop-background-color: var(--joy-scheme-semi-transparent);--backdrop-blur: 4px;--backdrop-transition-duration: var(--mosaik-duration-short);--backdrop-transition-mode: ease;--backdrop-transition-property: opacity, backdrop-filter;background:var(--backdrop-background-color);-webkit-backdrop-filter:blur(var(--backdrop-blur));backdrop-filter:blur(var(--backdrop-blur));opacity:1;transition-duration:var(--backdrop-transition-duration);transition-timing-function:var(--backdrop-transition-mode);transition-property:var(--backdrop-transition-property)}:root[theme=joy] .cdk-overlay-backdrop.mosaik-cdk-backdrop{--backdrop-background-color: var(--joy-scheme-semi-transparent);--backdrop-blur: 4px;--backdrop-transition-duration: var(--mosaik-duration-short);--backdrop-transition-mode: ease;--backdrop-transition-property: opacity, backdrop-filter}:root[theme=memphis] .cdk-overlay-backdrop.mosaik-cdk-backdrop{--backdrop-background-color: var(--memphis-scheme-semi-transparent);--backdrop-blur: none;--backdrop-transition-duration: var(--memphis-duration-short);--backdrop-transition-mode: ease;--backdrop-transition-property: opacity}:root[theme=cosmopolitan] .cdk-overlay-backdrop.mosaik-cdk-backdrop{--backdrop-background-color: var(--cosmopolitan-scheme-semi-transparent);--backdrop-blur: none;--backdrop-transition-duration: var(--cosmopolitan-duration-short);--backdrop-transition-mode: ease;--backdrop-transition-property: opacity}@media screen and (prefers-reduced-motion:reduce){.cdk-overlay-backdrop.mosaik-cdk-backdrop{transition-duration:.01ms}}.cdk-overlay-pane.mosaik-cdk-overlay-pane{pointer-events:none}.mosaik-cdk-overlay-pane mosaik-dialog::part(backdrop),.mosaik-cdk-overlay-pane mosaik-drawer::part(backdrop),.mosaik-cdk-overlay-pane mosaik-message-box::part(backdrop),.mosaik-cdk-overlay-pane mosaik-sheet::part(backdrop),.mosaik-cdk-overlay-pane mosaik-toast::part(backdrop){opacity:0;pointer-events:none;background:transparent;-webkit-backdrop-filter:none;backdrop-filter:none}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		_portal: [{
			type: ViewChild,
			args: [CdkPortalOutlet, { static: true }]
		}],
		_component: [{
			type: ViewChild,
			args: [SheetComponent, { static: true }]
		}]
	}
});
var SheetRef = class extends PortalRef {
	_positionChangedSubject;
	_sizeChangedSubject;
	_sheetElement;
	constructor(id, component, overlayRef, data) {
		super(id, component, overlayRef, data);
		this._positionChangedSubject = new Subject();
		this._sizeChangedSubject = new Subject();
		const sheetElement = overlayRef.hostElement.querySelector("mosaik-sheet");
		if (!sheetElement) throw new Error("SheetElement not found in overlay host element.");
		this._sheetElement = sheetElement;
	}
	get element() {
		return this._sheetElement;
	}
	close(result) {
		this._positionChangedSubject.complete();
		this._sizeChangedSubject.complete();
		super.close(result);
		this.component.close();
	}
	requestAttention(animation) {
		return this.element.requestAttention(animation);
	}
	get positionChanged() {
		return this._positionChangedSubject.asObservable();
	}
	get sizeChanged() {
		return this._sizeChangedSubject.asObservable();
	}
	updatePosition(position) {
		const strategy = this.overlayRef.getConfig().positionStrategy;
		if (position.left || position.right) {
			if (position.left) strategy.left(this.parseNumber(position.left));
			else if (position.right) strategy.right(this.parseNumber(position.right));
		} else strategy.centerHorizontally();
		if (position.top || position.bottom) {
			if (position.top) strategy.top(this.parseNumber(position.top));
			else strategy.bottom(this.parseNumber(position.bottom));
		} else strategy.centerVertically();
		this.overlayRef.updatePosition();
		this._positionChangedSubject.next(position);
		return this;
	}
	updateSize(size) {
		this.overlayRef.updateSize({
			width: size.width,
			height: size.height
		});
		this.overlayRef.updatePosition();
		this._sizeChangedSubject.next(size);
		return this;
	}
	parseNumber(size) {
		if (typeof size === "string") return size;
		else if (typeof size === "number") return `${size}px`;
		return "";
	}
};
var SheetService = class SheetService extends PortalProvider {
	_behaviors;
	_defaultConfig;
	_portalInjector;
	constructor() {
		super();
		this._behaviors = new Array();
		this._defaultConfig = inject(SHEET_CONFIG, { optional: true }) ?? {};
		for (const behavior of inject(SHEET_BEHAVIORS, { optional: true }) ?? []) this.withBehavior(behavior);
	}
	show(componentTypeOrTemplateRef, config) {
		const resolvedConfig = this.createConfig(config);
		if (resolvedConfig) for (const behavior of this._behaviors) behavior.configure(resolvedConfig);
		const overlayRef = this.createOverlay({
			hasBackdrop: resolvedConfig?.hasBackdrop,
			disposeOnNavigation: resolvedConfig?.closeOnNavigation
		}, {
			backdropStackKey: "sheet",
			backdropStrategy: resolvedConfig?.backdropStrategy
		});
		const portal = this.createPortal(SheetPortalComponent, overlayRef, resolvedConfig);
		const componentRef = this.createComponent(portal, overlayRef, SheetPortalComponent, resolvedConfig);
		this._portalInjector = componentRef.injector;
		const sheetRef = new SheetRef(this.createId(), componentRef.instance.sheet, overlayRef, resolvedConfig?.data);
		this.createContent(componentTypeOrTemplateRef, componentRef.instance, sheetRef, resolvedConfig);
		this.prepareComponent(overlayRef, componentRef.instance.sheet, sheetRef, resolvedConfig);
		this.attach(overlayRef, portal);
		componentRef.instance.sheet.open();
		this._behaviors.forEach((x) => x.attach(sheetRef, portal));
		return sheetRef;
	}
	close(ref) {
		this.detach(ref.overlayRef);
	}
	isShown(ref) {
		return this.cache.some((x) => x.overlay === ref.overlayRef && x.portal.isAttached);
	}
	withBehavior(type) {
		const behavior = this.injector.get(type);
		this._behaviors.push(behavior);
		return this;
	}
	createId() {
		return EID.next("mosaik-sheet");
	}
	createPortalInjector(config) {
		return new StatelessInjector(this.injector, [[SHEET_CONFIG, config]]);
	}
	createContentInjector(ref, config) {
		return new StatelessInjector(this._portalInjector ?? this.injector, [
			[SHEET_REF, ref],
			[SHEET_REF_DATA, ref.data],
			[SHEET_CONFIG, config]
		]);
	}
	createPositionStrategy() {
		return this.overlayPositionBuilder.global().centerHorizontally().bottom("0");
	}
	createScrollStrategy() {
		return this.overlay.scrollStrategies.block();
	}
	prepareComponent(overlayRef, component, sheetRef, config) {
		if (config) {
			Object.keys(config).forEach((p) => {
				if (p in component && typeof component.setInput === "function") component.setInput(p, config[p]);
			});
			if (config.clickOutsideToClose) connectOverlayOutsideClose(overlayRef, sheetRef.closed, () => sheetRef.requestClose("outside", Cancel.negative()));
		}
		component.setInput("pressEscapeToClose", false);
		component.setInput("clickOutsideToClose", false);
		if (config?.pressEscapeToClose) connectOverlayEscapeClose(overlayRef, sheetRef.closed, () => sheetRef.requestClose("escape", Cancel.negative()));
		else connectOverlayEscapeBlock(overlayRef, sheetRef.closed);
		const closedSubscription = component.closed.subscribe(() => {
			closedSubscription.unsubscribe();
			sheetRef.close(Cancel.none());
			this.detach(overlayRef);
			this._behaviors.forEach((x) => x.detach(sheetRef));
		});
	}
	createConfig(config) {
		const defaultConfig = this._defaultConfig;
		if (!this.hasConfig(defaultConfig) && !this.hasConfig(config)) return;
		return {
			...defaultConfig,
			...config
		};
	}
	hasConfig(config) {
		return config !== void 0 && Object.keys(config).length > 0;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: SheetService,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: SheetService
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: SheetService,
	decorators: [{ type: Injectable }],
	ctorParameters: () => []
});
function provideSheets(...withFeatures) {
	const behaviorTypes = withFeatures.map((feature) => feature.behaviorType).filter((behaviorType) => behaviorType !== void 0);
	return makeEnvironmentProviders([
		{
			provide: SHEET_BEHAVIORS,
			useValue: behaviorTypes
		},
		{
			provide: SheetService,
			useClass: SheetService
		},
		...withFeatures.flatMap((feature) => feature.provide())
	]);
}
function withSheetDefaultBehavior(config) {
	return {
		id: "sheetDefaultBehavior",
		provide: () => config ? [{
			provide: SHEET_CONFIG,
			useValue: config
		}] : []
	};
}
function withSheetBreakpointBehavior(config) {
	return {
		id: "sheetBreakpointBehavior",
		behaviorType: SheetBreakpointBehavior,
		provide: () => [{
			provide: SHEET_BREAKPOINT_BEHAVIOR_CONFIG,
			useValue: config
		}, {
			provide: SheetBreakpointBehavior,
			useClass: SheetBreakpointBehavior
		}]
	};
}
var SheetContentDirective = class SheetContentDirective {
	_slots = inject(SHEET_SLOTS);
	constructor(template) {
		this._slots.setContent(template);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: SheetContentDirective,
		deps: [{ token: i0.TemplateRef }],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: SheetContentDirective,
		isStandalone: true,
		selector: "ng-template[mosaikSheetContent]",
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: SheetContentDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "ng-template[mosaikSheetContent]" }]
	}],
	ctorParameters: () => [{ type: i0.TemplateRef }]
});
var SheetFooterDirective = class SheetFooterDirective {
	_slots = inject(SHEET_SLOTS);
	constructor(template) {
		this._slots.setFooter(template);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: SheetFooterDirective,
		deps: [{ token: i0.TemplateRef }],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: SheetFooterDirective,
		isStandalone: true,
		selector: "ng-template[mosaikSheetFooter]",
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: SheetFooterDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "ng-template[mosaikSheetFooter]" }]
	}],
	ctorParameters: () => [{ type: i0.TemplateRef }]
});
var SheetHeaderDirective = class SheetHeaderDirective {
	_slots = inject(SHEET_SLOTS);
	constructor(template) {
		this._slots.setHeader(template);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: SheetHeaderDirective,
		deps: [{ token: i0.TemplateRef }],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: SheetHeaderDirective,
		isStandalone: true,
		selector: "ng-template[mosaikSheetHeader]",
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: SheetHeaderDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "ng-template[mosaikSheetHeader]" }]
	}],
	ctorParameters: () => [{ type: i0.TemplateRef }]
});
const TOAST_STACK_BEHAVIOR_CONFIG = new InjectionToken("MOSAIK_TOAST_STACK_BEHAVIOR_CONFIG");
var ToastStackBehavior = class {
	_stack;
	constructor(config = inject(TOAST_STACK_BEHAVIOR_CONFIG, { optional: true })) {
		this._stack = new ToastStackBehavior$1(config ?? void 0);
	}
	get config() {
		return this._stack.config;
	}
	get stackSize() {
		return this._stack.stackSize;
	}
	configure(_config) {}
	attach(ref, _portal) {
		this._stack.add(this.targetOf(ref));
	}
	detach(ref) {
		if (!ref) {
			this._stack.dispose();
			return;
		}
		this._stack.remove(this.targetOf(ref));
	}
	targetOf(ref) {
		return {
			id: ref.id,
			element: ref.element
		};
	}
};
const TOAST_BREAKPOINT_BEHAVIOR_CONFIG = new InjectionToken("MOSAIK_TOAST_BREAKPOINT_BEHAVIOR_CONFIG");
var ToastBreakpointBehavior = class {
	_breakpointObserver;
	_breakpointRegistry;
	_config;
	_subscriptions;
	constructor(config = inject(TOAST_BREAKPOINT_BEHAVIOR_CONFIG, { optional: true })) {
		this._breakpointObserver = inject(BreakpointObserver);
		this._breakpointRegistry = inject(BreakpointRegistry);
		this._config = config;
		this._subscriptions = /* @__PURE__ */ new Map();
	}
	configure(_config) {}
	attach(ref, _portal) {
		const breakpoints = this.resolveBreakpoints();
		if (breakpoints.length === 0) return;
		this.detach(ref);
		const defaultMaxWidth = ref.element.maxWidth;
		const subscription = this._breakpointObserver.observe(breakpoints.map((breakpoint) => breakpoint.mediaQuery)).subscribe((state) => this.onBreakpoint(state, ref, defaultMaxWidth, breakpoints));
		this._subscriptions.set(ref, subscription);
	}
	detach(ref) {
		if (ref) {
			this._subscriptions.get(ref)?.unsubscribe();
			this._subscriptions.delete(ref);
			return;
		}
		this._subscriptions.forEach((subscription) => subscription.unsubscribe());
		this._subscriptions.clear();
	}
	onBreakpoint(state, ref, defaultMaxWidth, breakpoints) {
		let maxWidth = defaultMaxWidth;
		breakpoints.forEach((breakpoint) => {
			if (state.breakpoints[breakpoint.mediaQuery]) maxWidth = breakpoint.maxWidth;
		});
		ref.element.maxWidth = maxWidth;
	}
	resolveBreakpoints() {
		const result = new Array();
		this._config?.breakpoints.forEach((config) => {
			const breakpoint = this._breakpointRegistry.findByAlias(config.breakpoint);
			if (breakpoint?.mediaQuery) result.push({
				mediaQuery: breakpoint.mediaQuery,
				maxWidth: config.maxWidth
			});
		});
		return result;
	}
};
const TOAST_SLOTS = new InjectionToken("MOSAIK_TOAST_SLOTS");
function provideToastSlots() {
	return {
		provide: TOAST_SLOTS,
		useFactory: () => {
			const actions = signal(null, ...ngDevMode ? [{ debugName: "actions" }] : /* istanbul ignore next */ []);
			return {
				actions: actions.asReadonly(),
				setActions: (t) => actions.set(t)
			};
		}
	};
}
const TOAST_CONFIG = new InjectionToken("MOSAIK_TOAST_CONFIG");
const TOAST_REF = new InjectionToken("MOSAIK_TOAST_REF");
const TOAST_REF_DATA = new InjectionToken("MOSAIK_TOAST_REF_DATA");
const TOAST_BEHAVIORS = new InjectionToken("MOSAIK_TOAST_BEHAVIORS");
var ToastPortalComponent = class ToastPortalComponent extends PortalComponent {
	_portal;
	_component;
	_config;
	_slots;
	_warnedActions = false;
	constructor() {
		super();
		this._config = inject(TOAST_CONFIG, { optional: true }) ?? void 0;
		this._slots = inject(TOAST_SLOTS);
		effect(() => {
			const hasActionsTemplate = this._slots.actions() !== null;
			const actions = this._config?.actions;
			const hasActionsConfig = Array.isArray(actions) && actions.length > 0;
			if (hasActionsTemplate && hasActionsConfig && !this._warnedActions) {
				console.warn("[ToastPortalComponent] Actions template provided while toastConfig.actions is set. The template takes precedence.");
				this._warnedActions = true;
			}
		});
	}
	get managesFocus() {
		return false;
	}
	get portal() {
		return this._portal;
	}
	get toast() {
		return this._component;
	}
	get config() {
		return this._config;
	}
	get actionsTemplate() {
		return this._slots.actions();
	}
	onActionClick(handler) {
		handler?.();
		this._component.close();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ToastPortalComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: ToastPortalComponent,
		isStandalone: true,
		selector: "mosaik-toast-portal",
		host: { classAttribute: "toast-portal" },
		providers: [provideToastSlots()],
		viewQueries: [{
			propertyName: "_portal",
			first: true,
			predicate: CdkPortalOutlet,
			descendants: true,
			static: true
		}, {
			propertyName: "_component",
			first: true,
			predicate: ToastComponent,
			descendants: true,
			static: true
		}],
		exportAs: ["mosaikToastPortal"],
		usesInheritance: true,
		hostDirectives: [{ directive: OverlayInteractionBoundaryDirective }],
		ngImport: i0,
		template: "<mosaik-toast [variant]=\"this.config?.variant ?? 'default'\"\n              [appearance]=\"this.config?.appearance ?? 'default'\"\n              [closeable]=\"this.config?.closeable ?? false\"\n              [enter]=\"this.config?.enter\"\n              [exit]=\"this.config?.exit\"\n              [icon]=\"((this.config?.icon ?? this.config?.iconName) | of | async) ?? undefined\">\n    <ng-template cdkPortalOutlet></ng-template>\n    @if (this.actionsTemplate) {\n    <ng-container [ngTemplateOutlet]=\"this.actionsTemplate\" />\n    } @else if (this.config?.actions) {\n    <mosaik-toast-actions>\n        @for (action of this.config.actions; track action.label) {\n        @if ((action?.visible | of | async) ?? true) {\n        <mosaik-button [appearance]=\"action?.kind === 'primary' ? 'solid' : 'plain'\"\n                       [label]=\"(action?.label | of | async) ?? ''\"\n                       [disabled]=\"(action?.disabled | of | async) ?? false\"\n                       [variant]=\"'primary'\"\n                       (click)=\"onActionClick(action?.handler)\" />\n        }\n        }\n    </mosaik-toast-actions>\n    }\n</mosaik-toast>\n",
		styles: [".cdk-overlay-backdrop.mosaik-cdk-backdrop{--backdrop-background-color: var(--joy-scheme-semi-transparent);--backdrop-blur: 4px;--backdrop-transition-duration: var(--mosaik-duration-short);--backdrop-transition-mode: ease;--backdrop-transition-property: opacity, backdrop-filter;background:var(--backdrop-background-color);-webkit-backdrop-filter:blur(var(--backdrop-blur));backdrop-filter:blur(var(--backdrop-blur));opacity:1;transition-duration:var(--backdrop-transition-duration);transition-timing-function:var(--backdrop-transition-mode);transition-property:var(--backdrop-transition-property)}:root[theme=joy] .cdk-overlay-backdrop.mosaik-cdk-backdrop{--backdrop-background-color: var(--joy-scheme-semi-transparent);--backdrop-blur: 4px;--backdrop-transition-duration: var(--mosaik-duration-short);--backdrop-transition-mode: ease;--backdrop-transition-property: opacity, backdrop-filter}:root[theme=memphis] .cdk-overlay-backdrop.mosaik-cdk-backdrop{--backdrop-background-color: var(--memphis-scheme-semi-transparent);--backdrop-blur: none;--backdrop-transition-duration: var(--memphis-duration-short);--backdrop-transition-mode: ease;--backdrop-transition-property: opacity}:root[theme=cosmopolitan] .cdk-overlay-backdrop.mosaik-cdk-backdrop{--backdrop-background-color: var(--cosmopolitan-scheme-semi-transparent);--backdrop-blur: none;--backdrop-transition-duration: var(--cosmopolitan-duration-short);--backdrop-transition-mode: ease;--backdrop-transition-property: opacity}@media screen and (prefers-reduced-motion:reduce){.cdk-overlay-backdrop.mosaik-cdk-backdrop{transition-duration:.01ms}}.cdk-overlay-pane.mosaik-cdk-overlay-pane{pointer-events:none}.mosaik-cdk-overlay-pane mosaik-dialog::part(backdrop),.mosaik-cdk-overlay-pane mosaik-drawer::part(backdrop),.mosaik-cdk-overlay-pane mosaik-message-box::part(backdrop),.mosaik-cdk-overlay-pane mosaik-sheet::part(backdrop),.mosaik-cdk-overlay-pane mosaik-toast::part(backdrop){opacity:0;pointer-events:none;background:transparent;-webkit-backdrop-filter:none;backdrop-filter:none}\n"],
		dependencies: [
			{
				kind: "directive",
				type: NgTemplateOutlet,
				selector: "[ngTemplateOutlet]",
				inputs: [
					"ngTemplateOutletContext",
					"ngTemplateOutlet",
					"ngTemplateOutletInjector"
				]
			},
			{
				kind: "directive",
				type: CdkPortalOutlet,
				selector: "[cdkPortalOutlet]",
				inputs: ["cdkPortalOutlet"],
				outputs: ["attached"],
				exportAs: ["cdkPortalOutlet"]
			},
			{
				kind: "component",
				type: ToastComponent,
				selector: "mosaik-toast",
				inputs: [
					"header",
					"content",
					"icon",
					"iconSize",
					"maxWidth",
					"timeout",
					"position",
					"showProgress",
					"themeName",
					"enter",
					"exit",
					"variant",
					"appearance",
					"formatter",
					"isBusy",
					"isOpen",
					"hasBackdrop",
					"pressEscapeToClose",
					"clickOutsideToClose",
					"attention",
					"closeable",
					"dir",
					"lang"
				],
				outputs: [
					"opened",
					"closed",
					"closeAttempted",
					"connected",
					"disconnected",
					"changed"
				]
			},
			{
				kind: "component",
				type: ToastActionsComponent,
				selector: "mosaik-toast-actions",
				inputs: [
					"themeName",
					"dir",
					"lang"
				],
				outputs: [
					"connected",
					"disconnected",
					"changed"
				]
			},
			{
				kind: "component",
				type: ButtonComponent,
				selector: "mosaik-button",
				inputs: [
					"download",
					"href",
					"rel",
					"target",
					"themeName",
					"reverse",
					"orientation",
					"horizontalContentAlignment",
					"verticalContentAlignment",
					"fit",
					"isBusy",
					"label",
					"icon",
					"iconPosition",
					"iconSize",
					"type",
					"ripple",
					"variant",
					"appearance",
					"size",
					"value",
					"disabled",
					"isFocused",
					"dir",
					"lang"
				],
				outputs: [
					"connected",
					"disconnected",
					"changed"
				]
			},
			{
				kind: "pipe",
				type: AsyncPipe,
				name: "async"
			},
			{
				kind: "pipe",
				type: OfPipe,
				name: "of"
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush,
		encapsulation: i0.ViewEncapsulation.None
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ToastPortalComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-toast-portal",
			exportAs: "mosaikToastPortal",
			host: { class: "toast-portal" },
			hostDirectives: [OverlayInteractionBoundaryDirective],
			changeDetection: ChangeDetectionStrategy.OnPush,
			encapsulation: ViewEncapsulation.None,
			providers: [provideToastSlots()],
			imports: [
				AsyncPipe,
				NgTemplateOutlet,
				OfPipe,
				CdkPortalOutlet,
				ToastComponent,
				ToastActionsComponent,
				ButtonComponent
			],
			template: "<mosaik-toast [variant]=\"this.config?.variant ?? 'default'\"\n              [appearance]=\"this.config?.appearance ?? 'default'\"\n              [closeable]=\"this.config?.closeable ?? false\"\n              [enter]=\"this.config?.enter\"\n              [exit]=\"this.config?.exit\"\n              [icon]=\"((this.config?.icon ?? this.config?.iconName) | of | async) ?? undefined\">\n    <ng-template cdkPortalOutlet></ng-template>\n    @if (this.actionsTemplate) {\n    <ng-container [ngTemplateOutlet]=\"this.actionsTemplate\" />\n    } @else if (this.config?.actions) {\n    <mosaik-toast-actions>\n        @for (action of this.config.actions; track action.label) {\n        @if ((action?.visible | of | async) ?? true) {\n        <mosaik-button [appearance]=\"action?.kind === 'primary' ? 'solid' : 'plain'\"\n                       [label]=\"(action?.label | of | async) ?? ''\"\n                       [disabled]=\"(action?.disabled | of | async) ?? false\"\n                       [variant]=\"'primary'\"\n                       (click)=\"onActionClick(action?.handler)\" />\n        }\n        }\n    </mosaik-toast-actions>\n    }\n</mosaik-toast>\n",
			styles: [".cdk-overlay-backdrop.mosaik-cdk-backdrop{--backdrop-background-color: var(--joy-scheme-semi-transparent);--backdrop-blur: 4px;--backdrop-transition-duration: var(--mosaik-duration-short);--backdrop-transition-mode: ease;--backdrop-transition-property: opacity, backdrop-filter;background:var(--backdrop-background-color);-webkit-backdrop-filter:blur(var(--backdrop-blur));backdrop-filter:blur(var(--backdrop-blur));opacity:1;transition-duration:var(--backdrop-transition-duration);transition-timing-function:var(--backdrop-transition-mode);transition-property:var(--backdrop-transition-property)}:root[theme=joy] .cdk-overlay-backdrop.mosaik-cdk-backdrop{--backdrop-background-color: var(--joy-scheme-semi-transparent);--backdrop-blur: 4px;--backdrop-transition-duration: var(--mosaik-duration-short);--backdrop-transition-mode: ease;--backdrop-transition-property: opacity, backdrop-filter}:root[theme=memphis] .cdk-overlay-backdrop.mosaik-cdk-backdrop{--backdrop-background-color: var(--memphis-scheme-semi-transparent);--backdrop-blur: none;--backdrop-transition-duration: var(--memphis-duration-short);--backdrop-transition-mode: ease;--backdrop-transition-property: opacity}:root[theme=cosmopolitan] .cdk-overlay-backdrop.mosaik-cdk-backdrop{--backdrop-background-color: var(--cosmopolitan-scheme-semi-transparent);--backdrop-blur: none;--backdrop-transition-duration: var(--cosmopolitan-duration-short);--backdrop-transition-mode: ease;--backdrop-transition-property: opacity}@media screen and (prefers-reduced-motion:reduce){.cdk-overlay-backdrop.mosaik-cdk-backdrop{transition-duration:.01ms}}.cdk-overlay-pane.mosaik-cdk-overlay-pane{pointer-events:none}.mosaik-cdk-overlay-pane mosaik-dialog::part(backdrop),.mosaik-cdk-overlay-pane mosaik-drawer::part(backdrop),.mosaik-cdk-overlay-pane mosaik-message-box::part(backdrop),.mosaik-cdk-overlay-pane mosaik-sheet::part(backdrop),.mosaik-cdk-overlay-pane mosaik-toast::part(backdrop){opacity:0;pointer-events:none;background:transparent;-webkit-backdrop-filter:none;backdrop-filter:none}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		_portal: [{
			type: ViewChild,
			args: [CdkPortalOutlet, { static: true }]
		}],
		_component: [{
			type: ViewChild,
			args: [ToastComponent, { static: true }]
		}]
	}
});
var ToastRef = class extends PortalRef {
	_toastElement;
	constructor(id, component, overlayRef, data) {
		super(id, component, overlayRef, data);
		const toastElement = overlayRef.hostElement.querySelector("mosaik-toast");
		if (!toastElement) throw new Error("ToastElement not found in overlay host element.");
		this._toastElement = toastElement;
	}
	get element() {
		return this._toastElement;
	}
	requestAttention(animation) {
		return this.element.requestAttention(animation);
	}
};
var ToastService = class ToastService extends PortalProvider {
	_toastBehaviors;
	_defaultConfig;
	constructor(config = null, behaviors = null) {
		super();
		this._toastBehaviors = new Array();
		this._defaultConfig = config ?? {};
		for (const behavior of behaviors ?? []) this.withBehavior(behavior);
	}
	show(componentTypeOrTemplateRefOrConfig, config) {
		let componentTypeOrTemplateRef;
		let requestedConfig;
		if (componentTypeOrTemplateRefOrConfig instanceof TemplateRef || typeof componentTypeOrTemplateRefOrConfig === "function") {
			componentTypeOrTemplateRef = componentTypeOrTemplateRefOrConfig;
			requestedConfig = config;
		} else requestedConfig = componentTypeOrTemplateRefOrConfig;
		const resolvedConfig = this.createConfig(requestedConfig);
		if (resolvedConfig) for (const behavior of this._toastBehaviors) behavior.configure(resolvedConfig);
		const overlayRef = this.createOverlay({
			hasBackdrop: resolvedConfig?.hasBackdrop,
			disposeOnNavigation: resolvedConfig?.closeOnNavigation
		}, {
			backdropStackKey: "toast",
			backdropStrategy: resolvedConfig?.backdropStrategy,
			zIndex: LayerManager.nextToast()
		});
		const portal = this.createPortal(ToastPortalComponent, overlayRef, resolvedConfig);
		const componentRef = this.createComponent(portal, overlayRef, ToastPortalComponent, resolvedConfig);
		const toastRef = new ToastRef(resolvedConfig?.id ?? this.createId(), componentRef.instance.toast, overlayRef, resolvedConfig?.data);
		if (componentTypeOrTemplateRef) this.createContent(componentTypeOrTemplateRef, componentRef.instance, toastRef, resolvedConfig);
		this.prepareComponent(overlayRef, componentRef.instance.toast, toastRef, resolvedConfig);
		this.attach(overlayRef, portal);
		componentRef.instance.toast.open();
		this._toastBehaviors.forEach((x) => x.attach(toastRef, portal));
		const detachment = overlayRef.detachments().subscribe(() => {
			detachment.unsubscribe();
			this._toastBehaviors.forEach((x) => x.detach(toastRef));
		});
		return toastRef;
	}
	close(ref) {
		this.detach(ref.overlayRef);
	}
	isShown(ref) {
		return this.cache.some((x) => x.overlay === ref.overlayRef && x.portal.isAttached);
	}
	withBehavior(type) {
		const behavior = this.injector.get(type);
		this._toastBehaviors.push(behavior);
		return this;
	}
	createId() {
		return EID.next("mosaik-toast");
	}
	createPortalInjector(config) {
		return new StatelessInjector(this.injector, [[TOAST_CONFIG, config]]);
	}
	createContentInjector(ref, config) {
		return new StatelessInjector(this.injector, [
			[TOAST_REF, ref],
			[TOAST_REF_DATA, ref.data],
			[TOAST_CONFIG, config]
		]);
	}
	createPositionStrategy() {
		return this.overlayPositionBuilder.global().centerHorizontally().bottom("0");
	}
	createScrollStrategy() {
		return this.overlay.scrollStrategies.noop();
	}
	prepareComponent(overlayRef, component, toastRef, config) {
		if (config) {
			Object.keys(config).forEach((p) => {
				if (p in component && typeof component.setInput === "function") component.setInput(p, config[p]);
			});
			if (config.clickOutsideToClose) connectOverlayOutsideClose(overlayRef, toastRef.closed, () => toastRef.requestClose("outside", Cancel.negative()));
		}
		component.setInput("pressEscapeToClose", false);
		component.setInput("clickOutsideToClose", false);
		if (config?.pressEscapeToClose) connectOverlayEscapeClose(overlayRef, toastRef.closed, () => toastRef.requestClose("escape", Cancel.negative()));
		else connectOverlayEscapeBlock(overlayRef, toastRef.closed);
		const closedSubscription = component.closed.subscribe(() => {
			closedSubscription.unsubscribe();
			toastRef.close(Cancel.none());
			this.detach(overlayRef);
		});
	}
	createConfig(config) {
		const defaultConfig = this._defaultConfig;
		if (Object.keys(defaultConfig).length === 0 && !config) return;
		return {
			...defaultConfig,
			...config
		};
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ToastService,
		deps: [{
			token: TOAST_CONFIG,
			optional: true
		}, {
			token: TOAST_BEHAVIORS,
			optional: true
		}],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ToastService
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ToastService,
	decorators: [{ type: Injectable }],
	ctorParameters: () => [{
		type: void 0,
		decorators: [{ type: Optional }, {
			type: Inject,
			args: [TOAST_CONFIG]
		}]
	}, {
		type: void 0,
		decorators: [{ type: Optional }, {
			type: Inject,
			args: [TOAST_BEHAVIORS]
		}]
	}]
});
function provideToasts(...withFeatures) {
	const behaviorTypes = withFeatures.map((feature) => feature.behaviorType).filter((behaviorType) => behaviorType !== void 0);
	return makeEnvironmentProviders([
		{
			provide: TOAST_BEHAVIORS,
			useValue: behaviorTypes
		},
		{
			provide: ToastService,
			useClass: ToastService
		},
		provideToastSlots(),
		...withFeatures.flatMap((feature) => feature.provide())
	]);
}
function withToastDefaultBehavior(config) {
	return {
		id: "toastDefaultBehavior",
		provide: () => config ? [{
			provide: TOAST_CONFIG,
			useValue: config
		}] : []
	};
}
function withToastBreakpointBehavior(config) {
	return {
		id: "toastBreakpointBehavior",
		behaviorType: ToastBreakpointBehavior,
		provide: () => [{
			provide: TOAST_BREAKPOINT_BEHAVIOR_CONFIG,
			useValue: config
		}, {
			provide: ToastBreakpointBehavior,
			useClass: ToastBreakpointBehavior
		}]
	};
}
function withToastStackBehavior(config) {
	return {
		id: "toastStackBehavior",
		behaviorType: ToastStackBehavior,
		provide: () => [{
			provide: TOAST_STACK_BEHAVIOR_CONFIG,
			useValue: config
		}, {
			provide: ToastStackBehavior,
			useClass: ToastStackBehavior
		}]
	};
}
var ToastActionsDirective = class ToastActionsDirective {
	_slots = inject(TOAST_SLOTS);
	constructor(template) {
		this._slots.setActions(template);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ToastActionsDirective,
		deps: [{ token: i0.TemplateRef }],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: ToastActionsDirective,
		isStandalone: true,
		selector: "ng-template[mosaikToastActions]",
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ToastActionsDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "ng-template[mosaikToastActions]" }]
	}],
	ctorParameters: () => [{ type: i0.TemplateRef }]
});
var TourAnchorDirective = class TourAnchorDirective {
	_element;
	_anchorId = signal("", ...ngDevMode ? [{ debugName: "_anchorId" }] : /* istanbul ignore next */ []);
	_tourId = signal("default", ...ngDevMode ? [{ debugName: "_tourId" }] : /* istanbul ignore next */ []);
	constructor() {
		this._element = inject(ElementRef);
		effect((onCleanup) => {
			const tourId = this._tourId();
			const anchorId = this._anchorId();
			if (!tourId || !anchorId) return;
			const registration = TourAnchorRegistry.instance.register(tourId, anchorId, this._element.nativeElement, { replaceExisting: true });
			onCleanup(() => registration.dispose());
		});
	}
	get anchorId() {
		return this._anchorId();
	}
	set anchorId(value) {
		this._anchorId.set(value);
	}
	get tourId() {
		return this._tourId();
	}
	set tourId(value) {
		this._tourId.set(value);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: TourAnchorDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "16.1.0",
		version: "22.2.3",
		type: TourAnchorDirective,
		isStandalone: true,
		selector: "[mosaikTourAnchor]",
		inputs: {
			anchorId: [
				"mosaikTourAnchor",
				"anchorId",
				(value) => value?.trim() ?? ""
			],
			tourId: [
				"mosaikTourId",
				"tourId",
				(value) => value?.trim() || "default"
			]
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: TourAnchorDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "[mosaikTourAnchor]" }]
	}],
	ctorParameters: () => [],
	propDecorators: {
		anchorId: [{
			type: Input,
			args: [{
				alias: "mosaikTourAnchor",
				transform: (value) => value?.trim() ?? ""
			}]
		}],
		tourId: [{
			type: Input,
			args: [{
				alias: "mosaikTourId",
				transform: (value) => value?.trim() || "default"
			}]
		}]
	}
});
const TOUR_ACCESSOR = new InjectionToken("MOSAIK_TOUR_ACCESSOR");
var TourAccessorDirective = class TourAccessorDirective {
	_accessor = inject(TOUR_ACCESSOR, { self: true });
	anchors = input({}, {
		...ngDevMode ? { debugName: "anchors" } : /* istanbul ignore next */ {},
		alias: "mosaikTourAccessor"
	});
	tourId = input("default", {
		...ngDevMode ? { debugName: "tourId" } : /* istanbul ignore next */ {},
		alias: "mosaikTourId",
		transform: (value) => value?.trim() || "default"
	});
	constructor() {
		effect((onCleanup) => {
			const registrations = new Array();
			const tourId = this.tourId();
			const targets = this._accessor.targets();
			for (const [targetKey, configuredAnchorId] of Object.entries(this.anchors())) {
				const anchorId = configuredAnchorId?.trim() ?? "";
				const target = targets.get(targetKey);
				const element = target?.element() ?? null;
				if (!anchorId || !target || !element) continue;
				const value = target.value?.() ?? null;
				registrations.push(TourAnchorRegistry.instance.register(tourId, anchorId, {
					element,
					click: target.click,
					fill: value ? (nextValue) => {
						value.set(nextValue);
						return true;
					} : void 0
				}));
			}
			onCleanup(() => registrations.forEach((registration) => registration.dispose()));
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: TourAccessorDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: TourAccessorDirective,
		isStandalone: true,
		selector: "[mosaikTourAccessor]",
		inputs: {
			anchors: {
				classPropertyName: "anchors",
				publicName: "mosaikTourAccessor",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			tourId: {
				classPropertyName: "tourId",
				publicName: "mosaikTourId",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: TourAccessorDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "[mosaikTourAccessor]" }]
	}],
	ctorParameters: () => [],
	propDecorators: {
		anchors: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mosaikTourAccessor",
				required: false
			}]
		}],
		tourId: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mosaikTourId",
				required: false
			}]
		}]
	}
});
function createTourAccessorTarget(element, value, click) {
	return {
		element,
		value,
		click
	};
}
const TOUR_DEFINITIONS = new InjectionToken("MOSAIK_TOUR_DEFINITIONS");
const TOUR_BEHAVIORS = new InjectionToken("MOSAIK_TOUR_BEHAVIORS");
var TourService = class TourService {
	_document;
	_injector;
	_sources;
	_behaviors;
	_defaultProps;
	_router;
	_routerEventsSubscription;
	_stepActivator;
	_activeTourId;
	_activeStep;
	_lastFailure;
	_isActive;
	_handleStarted;
	_handleEnded;
	_handleStepChanged;
	_handleFailed;
	_element;
	_isStarting;
	_allowUserInitiatedNavigation;
	_isTourNavigation;
	_contextEffect;
	constructor() {
		this._document = inject(DOCUMENT);
		this._injector = inject(Injector);
		this._sources = inject(TOUR_DEFINITIONS, { optional: true }) ?? [];
		this._behaviors = (inject(TOUR_BEHAVIORS, { optional: true }) ?? []).map((behaviorType) => this._injector.get(behaviorType));
		this._defaultProps = inject(TOUR_DEFAULT_PROPS, { optional: true }) ?? {};
		this._router = inject(Router, { optional: true });
		this._activeTourId = signal(null, ...ngDevMode ? [{ debugName: "_activeTourId" }] : /* istanbul ignore next */ []);
		this._activeStep = signal(null, ...ngDevMode ? [{ debugName: "_activeStep" }] : /* istanbul ignore next */ []);
		this._lastFailure = signal(null, ...ngDevMode ? [{ debugName: "_lastFailure" }] : /* istanbul ignore next */ []);
		this._isActive = computed(() => this._activeTourId() !== null, ...ngDevMode ? [{ debugName: "_isActive" }] : /* istanbul ignore next */ []);
		this._element = null;
		this._isStarting = false;
		this._allowUserInitiatedNavigation = false;
		this._isTourNavigation = false;
		this._contextEffect = null;
		this._stepActivator = { activate: (step) => this.activateStep(step) };
		this._handleStarted = (event) => this.onStarted(event);
		this._handleEnded = (event) => this.onEnded(event);
		this._handleStepChanged = (event) => this.onStepChanged(event);
		this._handleFailed = (event) => this.onFailed(event);
		this._routerEventsSubscription = this._router?.events.subscribe((event) => this.onRouterEvent(event)) ?? null;
		inject(DestroyRef).onDestroy(() => this.destroy());
	}
	get activeTourId() {
		return this._activeTourId.asReadonly();
	}
	get activeStep() {
		return this._activeStep.asReadonly();
	}
	get isActive() {
		return this._isActive;
	}
	get lastFailure() {
		return this._lastFailure.asReadonly();
	}
	getDefinitions() {
		const definitions = this._sources.map((source) => typeof source === "function" ? runInInjectionContext(this._injector, source) : source);
		const identifiers = /* @__PURE__ */ new Set();
		for (const definition of definitions) {
			if (identifiers.has(definition.id)) throw new Error(`Tour definition "${definition.id}" is provided more than once.`);
			identifiers.add(definition.id);
		}
		return definitions;
	}
	hasTour(tourId) {
		return this.getDefinitions().some((definition) => definition.id === tourId);
	}
	async start(tourId, stepId, context) {
		if (this._isStarting) return false;
		this._isStarting = true;
		try {
			return await this.startCore(tourId, stepId, context);
		} finally {
			this._isStarting = false;
		}
	}
	next() {
		return this._element?.next() ?? Promise.resolve(false);
	}
	previous() {
		return this._element?.previous() ?? Promise.resolve(false);
	}
	pauseAutoAdvance() {
		return this._element?.pauseAutoAdvance() ?? false;
	}
	resumeAutoAdvance() {
		return this._element?.resumeAutoAdvance() ?? false;
	}
	showStep(stepId) {
		return this._element?.showStep(stepId) ?? Promise.resolve(false);
	}
	finish() {
		return this._element?.finish() ?? Promise.resolve(false);
	}
	skip() {
		return this._element?.skip() ?? Promise.resolve(false);
	}
	end(reason = "programmatic") {
		return this._element?.end(reason) ?? Promise.resolve(false);
	}
	async startCore(tourId, stepId, context) {
		const definition = this.getDefinitions().find((candidate) => candidate.id === tourId);
		if (!definition) {
			this._lastFailure.set({
				tourId,
				code: "invalid-tour-id",
				message: `Tour definition "${tourId}" is not provided.`,
				step: null
			});
			return false;
		}
		const element = this.getOrCreateElement();
		if (element.isOpen) {
			if (!await element.end("programmatic")) return false;
		}
		this._lastFailure.set(null);
		this.applyDefinition(element, definition);
		this.bindContext(element, context);
		this.mountElement(element, definition, stepId);
		const started = await element.start(stepId);
		if (!started) this.clearContextBinding();
		return started;
	}
	getOrCreateElement() {
		if (this._element) return this._element;
		const element = this._document.createElement(TourElement.is);
		applyDefaults$1(element, this._defaultProps);
		element.addEventListener("tourStarted", this._handleStarted);
		element.addEventListener("tourEnded", this._handleEnded);
		element.addEventListener("tourStepChanged", this._handleStepChanged);
		element.addEventListener("tourFailed", this._handleFailed);
		element.setAttribute(MOSAIK_OVERLAY_INTERACTION_BOUNDARY_ATTRIBUTE, "");
		this._element = element;
		return element;
	}
	applyDefinition(element, definition) {
		element.tourId = definition.id;
		element.behaviors = this._behaviors;
		element.steps = definition.steps;
		element.labels = {
			...this._defaultProps.labels ?? {},
			...definition.labels ?? {}
		};
		element.enter = this.resolveDefault(definition.enter, this._defaultProps.enter, TOUR_DEFAULT_ENTER_ANIMATION);
		element.exit = this.resolveDefault(definition.exit, this._defaultProps.exit, TOUR_DEFAULT_EXIT_ANIMATION);
		element.hasBackdrop = this.resolveDefault(definition.hasBackdrop, this._defaultProps.hasBackdrop, true);
		element.pressEscapeToClose = this.resolveDefault(definition.closeOnEscape, this._defaultProps.pressEscapeToClose, true);
		element.clickOutsideToClose = this.resolveDefault(definition.closeOnOutsideClick, this._defaultProps.clickOutsideToClose, true);
		element.showProgress = this.resolveDefault(definition.showProgress, this._defaultProps.showProgress, true);
		element.showAutoAdvanceControls = this.resolveDefault(definition.showAutoAdvanceControls, this._defaultProps.showAutoAdvanceControls, false);
		element.showFloatingControls = this.resolveDefault(definition.showFloatingControls, this._defaultProps.showFloatingControls, false);
		element.minimumStepDuration = this.resolveDefault(definition.minimumStepDuration, this._defaultProps.minimumStepDuration, 5e3);
		element.maximumStepDuration = this.resolveDefault(definition.maximumStepDuration, this._defaultProps.maximumStepDuration, 6e4);
		element.stepDurationIncrement = this.resolveDefault(definition.stepDurationIncrement, this._defaultProps.stepDurationIncrement, 1e3);
		element.restoreFocus = this.resolveDefault(definition.restoreFocus, this._defaultProps.restoreFocus, true);
		element.blockScroll = this.resolveDefault(definition.blockScroll, this._defaultProps.blockScroll, true);
		element.stepActivator = this._stepActivator;
		this._allowUserInitiatedNavigation = definition.allowUserInitiatedNavigation ?? false;
	}
	resolveDefault(definitionValue, defaultValue, fallback) {
		if (definitionValue !== void 0) return definitionValue;
		if (defaultValue !== void 0) return defaultValue;
		return fallback;
	}
	mountElement(element, definition, stepId) {
		const requestedIndex = stepId === void 0 ? 0 : definition.steps.findIndex((step) => step.id === stepId);
		const initialStep = requestedIndex < 0 ? void 0 : definition.steps.slice(requestedIndex).find((step) => this.isStepContextActive(step, element.context));
		const anchor = initialStep ? TourAnchorRegistry.instance.resolve(definition.id, initialStep.anchorId) : null;
		(this.findPortalScope(anchor ?? this.resolveDeepActiveElement()) ?? this._document.body).append(element);
	}
	isStepContextActive(step, context) {
		const canActivate = step.canActivate;
		if (!canActivate) return true;
		try {
			return canActivate(context) !== false;
		} catch {
			return true;
		}
	}
	bindContext(element, context) {
		this.clearContextBinding(false);
		element.context = context?.();
		if (!context) return;
		this._contextEffect = afterRenderEffect(() => {
			const value = context();
			if (!Object.is(element.context, value)) element.context = value;
		}, {
			...ngDevMode ? { debugName: "_contextEffect" } : /* istanbul ignore next */ {},
			injector: this._injector,
			manualCleanup: true
		});
	}
	clearContextBinding(resetElementContext = true) {
		this._contextEffect?.destroy();
		this._contextEffect = null;
		if (resetElementContext && this._element) this._element.context = void 0;
	}
	findPortalScope(origin) {
		let node = origin;
		while (node) {
			if (node instanceof HTMLElement && node.hasAttribute(MOSAIK_PORTAL_SCOPE_ATTRIBUTE)) return node;
			const root = node.getRootNode();
			node = node.parentNode ?? (root instanceof ShadowRoot ? root.host : null);
		}
		return null;
	}
	resolveDeepActiveElement() {
		let activeElement = this._document.activeElement;
		while (activeElement?.shadowRoot?.activeElement) activeElement = activeElement.shadowRoot.activeElement;
		return activeElement instanceof HTMLElement ? activeElement : null;
	}
	async activateStep(step) {
		const route = step.route?.trim();
		if (!route) return true;
		if (!this._router) return false;
		if (this._router.isActive(route, {
			paths: "exact",
			queryParams: "exact",
			fragment: "ignored",
			matrixParams: "exact"
		})) return true;
		this._isTourNavigation = true;
		try {
			return await this._router.navigateByUrl(route);
		} catch {
			return false;
		} finally {
			this._isTourNavigation = false;
		}
	}
	onRouterEvent(event) {
		if (!(event instanceof NavigationStart) || this._isTourNavigation || this._allowUserInitiatedNavigation || !this._element?.isOpen) return;
		this._element.end("navigation");
	}
	onStarted(event) {
		this._activeTourId.set(event.detail.tourId);
		this._activeStep.set(event.detail.currentStep);
	}
	onEnded(_event) {
		this.clearContextBinding();
		this._activeTourId.set(null);
		this._activeStep.set(null);
		this._allowUserInitiatedNavigation = false;
	}
	onStepChanged(event) {
		this._activeStep.set(event.detail.currentStep);
	}
	onFailed(event) {
		this._lastFailure.set(event.detail);
	}
	destroy() {
		this._routerEventsSubscription?.unsubscribe();
		this.clearContextBinding();
		const element = this._element;
		if (!element) return;
		element.removeEventListener("tourStarted", this._handleStarted);
		element.removeEventListener("tourEnded", this._handleEnded);
		element.removeEventListener("tourStepChanged", this._handleStepChanged);
		element.removeEventListener("tourFailed", this._handleFailed);
		element.stepActivator = null;
		element.remove();
		this._element = null;
		this._activeTourId.set(null);
		this._activeStep.set(null);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: TourService,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: TourService
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: TourService,
	decorators: [{ type: Injectable }],
	ctorParameters: () => []
});
function provideTours(...sources) {
	const definitions = sources.filter((source) => !isTourFeature(source));
	const features = sources.filter(isTourFeature);
	const definitionProviders = definitions.map((definition) => ({
		provide: TOUR_DEFINITIONS,
		useValue: definition,
		multi: true
	}));
	const behaviorProviders = features.flatMap((feature) => feature.behaviorType ? [{
		provide: TOUR_BEHAVIORS,
		useValue: feature.behaviorType,
		multi: true
	}] : []);
	return makeEnvironmentProviders([
		TourService,
		...definitionProviders,
		...behaviorProviders,
		...features.flatMap((feature) => feature.provide())
	]);
}
function withTourDefaultBehavior(config) {
	return {
		id: "tourDefaultBehavior",
		provide: () => {
			if (!config) return [];
			return typeof config === "function" ? [{
				provide: TOUR_DEFAULT_PROPS,
				useFactory: config
			}] : [{
				provide: TOUR_DEFAULT_PROPS,
				useValue: config
			}];
		}
	};
}
function isTourFeature(source) {
	return typeof source === "object" && source !== null && "provide" in source && typeof source.provide === "function";
}
var TourStartDirective = class TourStartDirective {
	_element;
	_tourService;
	_handleHostClick;
	_tourId = signal("", ...ngDevMode ? [{ debugName: "_tourId" }] : /* istanbul ignore next */ []);
	_startAt = signal(void 0, ...ngDevMode ? [{ debugName: "_startAt" }] : /* istanbul ignore next */ []);
	_context = signal(void 0, ...ngDevMode ? [{ debugName: "_context" }] : /* istanbul ignore next */ []);
	constructor() {
		this._element = inject(ElementRef);
		this._tourService = inject(TourService);
		this._handleHostClick = () => this.onClicked();
		this._element.nativeElement.addEventListener("click", this._handleHostClick, { capture: true });
		inject(DestroyRef).onDestroy(() => {
			this._element.nativeElement.removeEventListener("click", this._handleHostClick, { capture: true });
		});
	}
	get tourId() {
		return this._tourId();
	}
	set tourId(value) {
		this._tourId.set(value);
	}
	get startAt() {
		return this._startAt();
	}
	set startAt(value) {
		this._startAt.set(value);
	}
	get context() {
		return this._context();
	}
	set context(value) {
		this._context.set(value ?? void 0);
	}
	onClicked() {
		const tourId = this.tourId;
		if (tourId) {
			const context = this.context;
			if (context) this._tourService.start(tourId, this.startAt, context);
			else this._tourService.start(tourId, this.startAt);
		}
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: TourStartDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "16.1.0",
		version: "22.2.3",
		type: TourStartDirective,
		isStandalone: true,
		selector: "[mosaikTourStart]",
		inputs: {
			tourId: [
				"mosaikTourStart",
				"tourId",
				(value) => value?.trim() ?? ""
			],
			startAt: [
				"mosaikTourStartAt",
				"startAt",
				(value) => value?.trim() || void 0
			],
			context: ["mosaikTourContext", "context"]
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: TourStartDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "[mosaikTourStart]" }]
	}],
	ctorParameters: () => [],
	propDecorators: {
		tourId: [{
			type: Input,
			args: [{
				alias: "mosaikTourStart",
				transform: (value) => value?.trim() ?? ""
			}]
		}],
		startAt: [{
			type: Input,
			args: [{
				alias: "mosaikTourStartAt",
				transform: (value) => value?.trim() || void 0
			}]
		}],
		context: [{
			type: Input,
			args: [{ alias: "mosaikTourContext" }]
		}]
	}
});
function withTourCameraBehavior(config) {
	return {
		id: "tourCameraBehavior",
		behaviorType: TourCameraBehavior,
		provide: () => [{
			provide: TourCameraBehavior,
			useFactory: () => new TourCameraBehavior(config)
		}]
	};
}
var TimeUpdateService = class TimeUpdateService {
	_zone;
	_secondTick;
	_minuteTick;
	_hourTick;
	_midnightTick;
	constructor(zone) {
		this._zone = zone;
		this._secondTick = null;
		this._minuteTick = null;
		this._hourTick = null;
		this._midnightTick = null;
	}
	getSecondTick() {
		this._secondTick ??= this._zone.runOutsideAngular(() => timer(0, 2e3).pipe(map$1(() => Date.now()), share()));
		return this._secondTick;
	}
	getMinuteTick() {
		this._minuteTick ??= this._zone.runOutsideAngular(() => timer(0, 3e4).pipe(map$1(() => Date.now()), share()));
		return this._minuteTick;
	}
	getHourTick() {
		this._hourTick ??= this._zone.runOutsideAngular(() => timer(0, 3e5).pipe(map$1(() => Date.now()), share()));
		return this._hourTick;
	}
	getMidnightTick() {
		this._midnightTick ??= this._zone.runOutsideAngular(() => this.createMidnightObservable());
		return this._midnightTick;
	}
	createMidnightObservable() {
		const now = /* @__PURE__ */ new Date();
		const tomorrow = new Date(now);
		tomorrow.setHours(24, 0, 0, 0);
		const msUntilMidnight = tomorrow.getTime() - now.getTime();
		return timer(msUntilMidnight, 864e5).pipe(startWith(Date.now()), map$1(() => Date.now()), share());
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: TimeUpdateService,
		deps: [{ token: i0.NgZone }],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: TimeUpdateService
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: TimeUpdateService,
	decorators: [{ type: Injectable }],
	ctorParameters: () => [{ type: i0.NgZone }]
});
var DateAgoPipe = class DateAgoPipe {
	_intl;
	_changeDetectorRef;
	_zone;
	_timeUpdateService;
	_intlChangesSubscription;
	_midnightSubscription = null;
	constructor(intl, changeDetectorRef, zone, timeUpdateService) {
		this._intl = intl;
		this._intlChangesSubscription = intl.changes.subscribe(() => changeDetectorRef.markForCheck());
		this._changeDetectorRef = changeDetectorRef;
		this._zone = zone;
		this._timeUpdateService = timeUpdateService;
		this._midnightSubscription = this._timeUpdateService.getMidnightTick().subscribe(() => {
			this._zone.run(() => this._changeDetectorRef.markForCheck());
		});
	}
	transform(value) {
		const inputDate = typeof value === "string" ? new Date(value) : value;
		const now = /* @__PURE__ */ new Date();
		const startOfInputDate = new Date(inputDate.getFullYear(), inputDate.getMonth(), inputDate.getDate());
		const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
		const daysDifference = Math.round((startOfToday.getTime() - startOfInputDate.getTime()) / 864e5);
		if (Number.isNaN(daysDifference)) return "";
		if (daysDifference === 0) return this._intl.todayLabel;
		if (daysDifference === 1) return this._intl.yesterdayLabel;
		if (daysDifference <= 6) return this.format(this._intl.daysAgoLabel, daysDifference);
		if (daysDifference <= 13) return this._intl.lastWeekLabel;
		if (daysDifference <= 27) {
			const weeks = Math.round(daysDifference / 7);
			return this.format(this._intl.weeksAgoLabel, weeks);
		}
		if (daysDifference <= 45) return this._intl.lastMonthLabel;
		if (daysDifference <= 345) {
			const months = Math.round(daysDifference / 30.416);
			return this.format(this._intl.monthsAgoLabel, months);
		}
		if (daysDifference <= 545) return this._intl.lastYearLabel;
		const years = Math.round(daysDifference / 365);
		return this.format(this._intl.yearsAgoLabel, years);
	}
	ngOnDestroy() {
		this._midnightSubscription?.unsubscribe();
		this._intlChangesSubscription.unsubscribe();
	}
	format(self, ...args) {
		const allArgs = new Array();
		args.forEach((x) => {
			if (Array.isArray(x)) x.forEach((y) => {
				allArgs.push(y);
			});
			else allArgs.push(x);
		});
		return self.replace(/{(\d+)}/g, (match, index) => {
			const value = allArgs[index];
			if (value !== void 0) return typeof value === "string" || typeof value === "number" ? String(value) : JSON.stringify(value);
			return match;
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DateAgoPipe,
		deps: [
			{ token: DateAgoPipeIntl },
			{ token: i0.ChangeDetectorRef },
			{ token: i0.NgZone },
			{ token: TimeUpdateService }
		],
		target: i0.ɵɵFactoryTarget.Pipe
	});
	static ɵpipe = i0.ɵɵngDeclarePipe({
		minVersion: "14.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DateAgoPipe,
		isStandalone: true,
		name: "dateAgo",
		pure: false
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DateAgoPipe,
	decorators: [{
		type: Pipe,
		args: [{
			name: "dateAgo",
			pure: false
		}]
	}],
	ctorParameters: () => [
		{ type: DateAgoPipeIntl },
		{ type: i0.ChangeDetectorRef },
		{ type: i0.NgZone },
		{ type: TimeUpdateService }
	]
});
var DateAgoPipeIntl = class DateAgoPipeIntl extends DateAgoIntl {
	_changesSubject;
	constructor() {
		super();
		this._changesSubject = new Subject();
	}
	get changes() {
		return this._changesSubject;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DateAgoPipeIntl,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DateAgoPipeIntl
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DateAgoPipeIntl,
	decorators: [{ type: Injectable }],
	ctorParameters: () => []
});
function provideDateAgoPipe() {
	return {
		provide: DateAgoPipeIntl,
		useFactory: (parent) => parent ?? new DateAgoPipeIntl(),
		deps: [[
			new Optional(),
			new SkipSelf(),
			DateAgoPipeIntl
		]]
	};
}
var FilterByPipe = class FilterByPipe {
	transform(...args) {
		return filterByMemberPath(...args);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FilterByPipe,
		deps: [],
		target: i0.ɵɵFactoryTarget.Pipe
	});
	static ɵpipe = i0.ɵɵngDeclarePipe({
		minVersion: "14.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FilterByPipe,
		isStandalone: true,
		name: "filterBy"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FilterByPipe,
	decorators: [{
		type: Pipe,
		args: [{ name: "filterBy" }]
	}]
});
var FormatPipe = class FormatPipe {
	transform(value, ...args) {
		return this.format(value, ...args);
	}
	format(self, ...args) {
		const allArgs = new Array();
		args.forEach((x) => {
			if (Array.isArray(x)) x.forEach((y) => {
				allArgs.push(y);
			});
			else allArgs.push(x);
		});
		return self.replace(/{(\d+)}/g, (match, index) => {
			if (allArgs[index] !== void 0) return allArgs[index];
			return match;
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FormatPipe,
		deps: [],
		target: i0.ɵɵFactoryTarget.Pipe
	});
	static ɵpipe = i0.ɵɵngDeclarePipe({
		minVersion: "14.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FormatPipe,
		isStandalone: true,
		name: "format"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FormatPipe,
	decorators: [{
		type: Pipe,
		args: [{ name: "format" }]
	}]
});
var OrderByPipe = class OrderByPipe {
	transform(...args) {
		return orderByMemberPath(...args);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: OrderByPipe,
		deps: [],
		target: i0.ɵɵFactoryTarget.Pipe
	});
	static ɵpipe = i0.ɵɵngDeclarePipe({
		minVersion: "14.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: OrderByPipe,
		isStandalone: true,
		name: "orderBy"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: OrderByPipe,
	decorators: [{
		type: Pipe,
		args: [{ name: "orderBy" }]
	}]
});
var TimeAgoPipe = class TimeAgoPipe {
	_intl;
	_changeDetectorRef;
	_zone;
	_timeUpdateService;
	_intlChangesSubscription;
	_tickSubscription = null;
	_currentTickType = null;
	constructor(intl, changeDetectorRef, zone, timeUpdateService) {
		this._intl = intl;
		this._intlChangesSubscription = intl.changes.subscribe(() => changeDetectorRef.markForCheck());
		this._changeDetectorRef = changeDetectorRef;
		this._zone = zone;
		this._timeUpdateService = timeUpdateService;
	}
	transform(value) {
		const time = typeof value === "string" ? new Date(value).getTime() : value.getTime();
		const seconds = Math.round(Math.abs(((/* @__PURE__ */ new Date()).getTime() - time) / 1e3));
		if (Number.isNaN(seconds)) {
			this.unsubscribeFromTicks();
			return "";
		}
		const requiredTickType = this.getRequiredTickType(seconds);
		if (this._currentTickType !== requiredTickType) this.subscribeToTicks(requiredTickType);
		const minutes = Math.round(Math.abs(seconds / 60));
		const hours = Math.round(Math.abs(minutes / 60));
		const days = Math.round(Math.abs(hours / 24));
		const months = Math.round(Math.abs(days / 30.416));
		const years = Math.round(Math.abs(days / 365));
		if (seconds <= 45) return this._intl.fewSecondsLabel;
		if (seconds <= 90) return this._intl.minuteLabel;
		if (minutes <= 45) return this.format(this._intl.minutesLabel, minutes);
		if (minutes <= 90) return this._intl.hourLabel;
		if (hours <= 22) return this.format(this._intl.hoursLabel, hours);
		if (hours <= 36) return this._intl.dayLabel;
		if (days <= 25) return this.format(this._intl.daysLabel, days);
		if (days <= 45) return this._intl.monthLabel;
		if (days <= 345) return this.format(this._intl.monthsLabel, months);
		if (days <= 545) return this._intl.yearLabel;
		return this.format(this._intl.yearsLabel, years);
	}
	ngOnDestroy() {
		this.unsubscribeFromTicks();
		this._intlChangesSubscription.unsubscribe();
	}
	getRequiredTickType(seconds) {
		const min = 60;
		const hr = 3600;
		const day = hr * 24;
		if (seconds < min) return "second";
		if (seconds < hr) return "minute";
		if (seconds < day) return "hour";
		return "hour";
	}
	subscribeToTicks(tickType) {
		this.unsubscribeFromTicks();
		this._currentTickType = tickType;
		const tick$ = tickType === "second" ? this._timeUpdateService.getSecondTick() : tickType === "minute" ? this._timeUpdateService.getMinuteTick() : this._timeUpdateService.getHourTick();
		this._tickSubscription = tick$.subscribe(() => {
			this._zone.run(() => this._changeDetectorRef.markForCheck());
		});
	}
	unsubscribeFromTicks() {
		if (this._tickSubscription) {
			this._tickSubscription.unsubscribe();
			this._tickSubscription = null;
		}
		this._currentTickType = null;
	}
	format(self, ...args) {
		const allArgs = new Array();
		args.forEach((x) => {
			if (Array.isArray(x)) x.forEach((y) => {
				allArgs.push(y);
			});
			else allArgs.push(x);
		});
		return self.replace(/{(\d+)}/g, (match, index) => {
			const value = allArgs[index];
			if (value !== void 0) return typeof value === "string" || typeof value === "number" ? String(value) : JSON.stringify(value);
			return match;
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: TimeAgoPipe,
		deps: [
			{ token: TimeAgoPipeIntl },
			{ token: i0.ChangeDetectorRef },
			{ token: i0.NgZone },
			{ token: TimeUpdateService }
		],
		target: i0.ɵɵFactoryTarget.Pipe
	});
	static ɵpipe = i0.ɵɵngDeclarePipe({
		minVersion: "14.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: TimeAgoPipe,
		isStandalone: true,
		name: "timeAgo",
		pure: false
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: TimeAgoPipe,
	decorators: [{
		type: Pipe,
		args: [{
			name: "timeAgo",
			pure: false
		}]
	}],
	ctorParameters: () => [
		{ type: TimeAgoPipeIntl },
		{ type: i0.ChangeDetectorRef },
		{ type: i0.NgZone },
		{ type: TimeUpdateService }
	]
});
var TimeAgoPipeIntl = class TimeAgoPipeIntl extends TimeAgoIntl {
	_changesSubject;
	constructor() {
		super();
		this._changesSubject = new Subject();
	}
	get changes() {
		return this._changesSubject;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: TimeAgoPipeIntl,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: TimeAgoPipeIntl
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: TimeAgoPipeIntl,
	decorators: [{ type: Injectable }],
	ctorParameters: () => []
});
function provideTimeAgoPipe() {
	return {
		provide: TimeAgoPipeIntl,
		useFactory: (parent) => parent ?? new TimeAgoPipeIntl(),
		deps: [[
			new Optional(),
			new SkipSelf(),
			TimeAgoPipeIntl
		]]
	};
}
function provideTimeUpdates() {
	return makeEnvironmentProviders([
		{
			provide: TimeUpdateService,
			useClass: TimeUpdateService
		},
		{
			provide: TimeAgoPipeIntl,
			useClass: TimeAgoPipeIntl
		},
		{
			provide: TimeAgoPipe,
			useClass: TimeAgoPipe
		},
		{
			provide: DateAgoPipeIntl,
			useClass: DateAgoPipeIntl
		},
		{
			provide: DateAgoPipe,
			useClass: DateAgoPipe
		}
	]);
}
function deepMerge(target, source) {
	if (!source) return structuredClone(target);
	const isObject = (val) => typeof val === "object" && val !== null && !Array.isArray(val);
	const result = { ...target };
	for (const key of Object.keys(source)) {
		const sourceValue = source[key];
		const targetValue = target[key];
		if (isObject(targetValue) && isObject(sourceValue)) result[key] = deepMerge(targetValue, sourceValue);
		else if (sourceValue !== void 0) result[key] = sourceValue;
	}
	return result;
}
const THEME = new InjectionToken("MOSAIK_THEME");
const THEME_MODE = new InjectionToken("MOSAIK_THEME_MODE");
var ThemeService = class {
	_theme;
	_themeMode;
	_themeObserver;
	_themeModeChangedSubscription;
	constructor(theme = inject(THEME), themeMode = inject(THEME_MODE), themeObserver = inject(ThemeObserver), destroyRef = inject(DestroyRef)) {
		this._theme = theme;
		this._themeMode = themeMode;
		this._themeObserver = themeObserver;
		this._themeModeChangedSubscription = null;
		destroyRef.onDestroy(() => {
			this._themeModeChangedSubscription?.dispose();
		});
	}
	get schemes() {
		return Object.keys(this._theme().scheme);
	}
	get palettes() {
		return Object.keys(this._theme().palette);
	}
	initialize() {
		this._themeModeChangedSubscription = this._themeObserver.themeModeChanged.subscribe((mode) => {
			if (mode) {
				this._themeObserver.applyTheme(this._theme().name, mode);
				ThemeService$1.instance.applyTheme(this._theme());
			}
		});
		this._themeObserver.applyTheme(this._theme().name, this._themeMode());
		ThemeService$1.instance.applyTheme(this._theme());
	}
	applyTheme(mode) {
		this._themeObserver.applyTheme(this._theme().name, mode);
		ThemeService$1.instance.applyTheme(this._theme());
	}
};
function provideTheme(config) {
	return makeEnvironmentProviders([
		{
			provide: THEME,
			useValue: signal(deepMerge(config.theme, config.overrides))
		},
		{
			provide: THEME_MODE,
			useValue: signal(config.mode)
		},
		{
			provide: ThemeService,
			useClass: ThemeService
		},
		{
			provide: ThemeGenerator,
			useFactory: () => ThemeGeneratorServiceLocator.current
		},
		{
			provide: ThemeObserver,
			useFactory: () => ThemeObserverServiceLocator.current
		},
		provideEnvironmentInitializer(() => {
			inject(ThemeService).initialize();
		})
	]);
}
function provideTranslationRegistry(config) {
	return makeEnvironmentProviders([{
		provide: TranslateService,
		useFactory: () => {
			const document = inject(DOCUMENT);
			const service = new TranslatorService(config?.defaultLanguageResolver ?? Translator.DEFAULT_LANGUAGE_RESOLVER);
			document.documentElement.lang = service.currentLanguage;
			service.languageChanged.subscribe(() => {
				document.documentElement.lang = service.currentLanguage;
				emit(document, "languageChanged", {
					bubbles: true,
					cancelable: true
				});
			});
			Object.entries(config?.translations ?? {}).forEach(([lang, translations]) => {
				service.addTranslations(lang, translations);
			});
			TranslatorServiceLocator.set(service);
			return new TranslateService(service);
		}
	}]);
}
function provideTranslations(translations) {
	const entries = Object.entries(translations ?? {});
	if (!entries.some(([, value]) => value != null && typeof value.then === "function")) return makeEnvironmentProviders([provideEnvironmentInitializer(() => {
		const translate = inject(TranslateService);
		entries.forEach(([lang, data]) => {
			translate.addTranslations(lang, data);
		});
	})]);
	return makeEnvironmentProviders([provideAppInitializer(async () => {
		const translate = inject(TranslateService);
		(await Promise.all(entries.map(async ([lang, data]) => {
			try {
				return [lang, await data];
			} catch {
				return [lang, {}];
			}
		}))).forEach(([lang, data]) => {
			translate.addTranslations(lang, data);
		});
	})]);
}
var TranslateDirective = class TranslateDirective {
	_vcr;
	_templateRef;
	_cdr;
	_translate;
	_view;
	_scope;
	_languageChangedSubscription;
	constructor() {
		this._vcr = inject(ViewContainerRef);
		this._templateRef = inject(TemplateRef);
		this._cdr = inject(ChangeDetectorRef);
		this._translate = inject(TranslateService);
		this._languageChangedSubscription = null;
		this._view = null;
		this._scope = "";
	}
	get scope() {
		return this._scope;
	}
	set scope(value) {
		this._scope = value;
	}
	ngOnInit() {
		this.invalidate();
		this._languageChangedSubscription = this._translate.languageChanged.subscribe(() => this.onCultureChanged());
	}
	ngOnDestroy() {
		this._languageChangedSubscription?.unsubscribe();
	}
	onCultureChanged() {
		this.invalidate();
		this._cdr.markForCheck();
	}
	invalidate() {
		if (this._view) this._view.context.$implicit = this.getImplicitFn();
		else this._view = this._vcr.createEmbeddedView(this._templateRef, { $implicit: this.getImplicitFn() });
	}
	getImplicitFn() {
		return (key, params) => {
			const scopedKey = this._scope ? `${this._scope}.${key}` : key;
			return this._translate.translate(scopedKey, params);
		};
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: TranslateDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: TranslateDirective,
		isStandalone: true,
		selector: "[mosaikTranslate]",
		inputs: { scope: ["translateScope", "scope"] },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: TranslateDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "[mosaikTranslate]" }]
	}],
	ctorParameters: () => [],
	propDecorators: { scope: [{
		type: Input,
		args: ["translateScope"]
	}] }
});
var TranslatePipe = class TranslatePipe {
	_translate;
	_cdr;
	_lastKey;
	_lastParams;
	_lastScope;
	_lastValue;
	_languageChangedSubscription;
	constructor() {
		this._translate = inject(TranslateService);
		this._cdr = inject(ChangeDetectorRef);
		this._lastKey = null;
		this._lastParams = void 0;
		this._lastScope = void 0;
		this._lastValue = null;
		this._languageChangedSubscription = this._translate.languageChanged.subscribe(() => {
			this._lastValue = null;
			this._cdr.markForCheck();
		});
	}
	transform(key, params, scope) {
		const scopedKey = scope ? `${scope}.${key}` : key;
		if (this._lastKey !== scopedKey || !this.isEqual(this._lastParams, params)) {
			this._lastKey = scopedKey;
			this._lastParams = params;
			this._lastScope = scope;
			this._lastValue = this._translate.translate(scopedKey, params);
		}
		return this._lastValue ?? "";
	}
	ngOnDestroy() {
		this._languageChangedSubscription?.unsubscribe();
	}
	isEqual(obj1, obj2) {
		if (obj1 === obj2) return true;
		if (!obj1 || !obj2) return false;
		return JSON.stringify(obj1) === JSON.stringify(obj2);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: TranslatePipe,
		deps: [],
		target: i0.ɵɵFactoryTarget.Pipe
	});
	static ɵpipe = i0.ɵɵngDeclarePipe({
		minVersion: "14.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: TranslatePipe,
		isStandalone: true,
		name: "translate"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: TranslatePipe,
	decorators: [{
		type: Pipe,
		args: [{
			name: "translate",
			pure: true
		}]
	}],
	ctorParameters: () => []
});
const VIEW_SLOT_CONTEXT = new InjectionToken("ViewSlotContext");
const VIEW_SLOT_REGISTRATIONS = new InjectionToken("ViewSlotRegistrations");
function provideViewSlot(slotId, views) {
	return makeEnvironmentProviders([{
		provide: ViewSlotRegistry,
		useClass: ViewSlotRegistry
	}, {
		provide: VIEW_SLOT_REGISTRATIONS,
		useValue: {
			slotId,
			views
		},
		multi: true
	}]);
}
function provideViewSlotFrom(slotId, provider) {
	return makeEnvironmentProviders([
		{
			provide: ViewSlotRegistry,
			useClass: ViewSlotRegistry
		},
		provider,
		{
			provide: VIEW_SLOT_REGISTRATIONS,
			useFactory: (viewSlotProvider) => ({
				slotId,
				views: viewSlotProvider.getViews()
			}),
			deps: [provider],
			multi: true
		}
	]);
}
var ViewSlotRegistry = class ViewSlotRegistry {
	_injector = inject(Injector);
	_slots = /* @__PURE__ */ new Map();
	getViews(slotId) {
		const state = this._getOrCreateSlotState(slotId);
		return computed(() => {
			const allViews = [...state.staticViews, ...state.dynamicViews()];
			return this._sortAndFilterViews(allViews);
		});
	}
	getActiveViews(slotId, selection) {
		const allViews = this.getViews(slotId);
		return computed(() => {
			const currentSelection = selection();
			return allViews().filter((view) => {
				if (!view.canActivate) return true;
				return view.canActivate(currentSelection);
			});
		});
	}
	hasViews(slotId) {
		const views = this.getViews(slotId);
		return computed(() => views().length > 0);
	}
	hasActiveViews(slotId, selection) {
		const views = this.getActiveViews(slotId, selection);
		return computed(() => views().length > 0);
	}
	register(slotId, view, providerId) {
		const state = this._getOrCreateSlotState(slotId);
		if ([...state.staticViews, ...state.dynamicViews()].some((existingView) => existingView.id === view.id)) throw new Error(`View with ID '${view.id}' is already registered in slot '${slotId}'.`);
		state.setDynamicViews([...state.dynamicViews(), {
			...view,
			providerId: providerId ?? "dynamic"
		}]);
	}
	unregister(slotId, viewId) {
		const state = this._slots.get(slotId);
		if (!state) return false;
		const currentViews = state.dynamicViews();
		if (currentViews.findIndex((view) => view.id === viewId) === -1) return false;
		state.setDynamicViews(currentViews.filter((view) => view.id !== viewId));
		return true;
	}
	getViewById(slotId, viewId) {
		return this.getViews(slotId)().find((view) => view.id === viewId);
	}
	_getOrCreateSlotState(slotId) {
		let state = this._slots.get(slotId);
		if (!state) {
			const dynamicViews = signal([], ...ngDevMode ? [{ debugName: "dynamicViews" }] : /* istanbul ignore next */ []);
			state = {
				staticViews: this._initializeFromRegistrations(slotId),
				dynamicViews: dynamicViews.asReadonly(),
				setDynamicViews: (views) => dynamicViews.set(views)
			};
			this._slots.set(slotId, state);
		}
		return state;
	}
	_initializeFromRegistrations(slotId) {
		const registrations = runInInjectionContext(this._injector, () => inject(VIEW_SLOT_REGISTRATIONS, { optional: true }) ?? []);
		const views = [];
		for (const registration of registrations) {
			if (registration.slotId !== slotId) continue;
			for (const view of registration.views) {
				if (views.some((existingView) => existingView.id === view.id)) {
					console.warn(`Duplicate view ID '${view.id}' in slot '${slotId}'. Skipping.`);
					continue;
				}
				views.push({
					...view,
					providerId: "registration"
				});
			}
		}
		return views;
	}
	_sortAndFilterViews(views) {
		const DEFAULT_ORDER = 100;
		return views.filter((view) => !view.isVisible || view.isVisible()).sort((viewA, viewB) => (viewA.order ?? DEFAULT_ORDER) - (viewB.order ?? DEFAULT_ORDER));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ViewSlotRegistry,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ViewSlotRegistry
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ViewSlotRegistry,
	decorators: [{ type: Injectable }]
});
var ViewSlotOutletComponent = class ViewSlotOutletComponent {
	_registry;
	_parentInjector;
	_selection = signal(null, ...ngDevMode ? [{ debugName: "_selection" }] : /* istanbul ignore next */ []);
	_loadedComponents = signal([], ...ngDevMode ? [{ debugName: "_loadedComponents" }] : /* istanbul ignore next */ []);
	_loadingViewId = signal(null, ...ngDevMode ? [{ debugName: "_loadingViewId" }] : /* istanbul ignore next */ []);
	_viewInjectors = /* @__PURE__ */ new Map();
	slot = input.required(...ngDevMode ? [{ debugName: "slot" }] : /* istanbul ignore next */ []);
	initialViewId = input(...ngDevMode ? [void 0, { debugName: "initialViewId" }] : /* istanbul ignore next */ []);
	constructor(registry = inject(ViewSlotRegistry), parentInjector = inject(Injector)) {
		this._registry = registry;
		this._parentInjector = parentInjector;
		effect(() => {
			const currentViews = this.views();
			for (const view of currentViews) if (!this._isViewLoaded(view.id)) this._loadViewComponent(view.id);
		});
	}
	setSelection(selection) {
		this._selection.set(selection);
	}
	getComponent(viewId) {
		return this._loadedComponents().find((loadedComponent) => loadedComponent.viewId === viewId)?.component ?? null;
	}
	getInjectorForView(viewId) {
		let injector = this._viewInjectors.get(viewId);
		if (!injector) {
			const context = {
				slotId: this.slot(),
				viewId,
				selection: this._selection.asReadonly(),
				isLoading: this.isLoading
			};
			injector = Injector.create({
				parent: this._parentInjector,
				providers: [{
					provide: VIEW_SLOT_CONTEXT,
					useValue: context
				}]
			});
			this._viewInjectors.set(viewId, injector);
		}
		return injector;
	}
	getViewDefinition(viewId) {
		return this.views().find((view) => view.id === viewId);
	}
	resolveBadge(badge) {
		if (badge === void 0) return null;
		if (typeof badge === "function") return badge();
		return badge;
	}
	_isViewLoaded(viewId) {
		return this._loadedComponents().some((loaded) => loaded.viewId === viewId);
	}
	async _loadViewComponent(viewId) {
		const view = this.getViewDefinition(viewId);
		if (!view) return;
		if (view.component) {
			this._addLoadedComponent(viewId, view.component);
			return;
		}
		if (view.loadComponent) {
			this._loadingViewId.set(viewId);
			try {
				const component = await view.loadComponent();
				this._addLoadedComponent(viewId, component);
			} catch (error) {
				console.error(`Failed to load component for view '${viewId}':`, error);
			} finally {
				this._loadingViewId.set(null);
			}
		}
	}
	_addLoadedComponent(viewId, component) {
		const current = this._loadedComponents();
		if (!current.some((loaded) => loaded.viewId === viewId)) this._loadedComponents.set([...current, {
			viewId,
			component
		}]);
	}
	views = computed(() => {
		return this._registry.getActiveViews(this.slot(), this._selection)();
	}, ...ngDevMode ? [{ debugName: "views" }] : /* istanbul ignore next */ []);
	isLoading = computed(() => this._loadingViewId() !== null, ...ngDevMode ? [{ debugName: "isLoading" }] : /* istanbul ignore next */ []);
	loadingViewId = this._loadingViewId.asReadonly();
	hasViews = computed(() => this.views().length > 0, ...ngDevMode ? [{ debugName: "hasViews" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ViewSlotOutletComponent,
		deps: [{ token: ViewSlotRegistry }, { token: i0.Injector }],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: ViewSlotOutletComponent,
		isStandalone: true,
		selector: "mosaik-view-slot-outlet",
		inputs: {
			slot: {
				classPropertyName: "slot",
				publicName: "slot",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			initialViewId: {
				classPropertyName: "initialViewId",
				publicName: "initialViewId",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		ngImport: i0,
		template: `
        @for (view of views(); track view.id) {
            @if (getComponent(view.id); as component) {
                <ng-container *ngComponentOutlet="component; injector: getInjectorForView(view.id)" />
            }
        }
    `,
		isInline: true,
		dependencies: [{
			kind: "directive",
			type: NgComponentOutlet,
			selector: "[ngComponentOutlet]",
			inputs: [
				"ngComponentOutlet",
				"ngComponentOutletInputs",
				"ngComponentOutletInjector",
				"ngComponentOutletEnvironmentInjector",
				"ngComponentOutletContent",
				"ngComponentOutletNgModule"
			],
			exportAs: ["ngComponentOutlet"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ViewSlotOutletComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-view-slot-outlet",
			template: `
        @for (view of views(); track view.id) {
            @if (getComponent(view.id); as component) {
                <ng-container *ngComponentOutlet="component; injector: getInjectorForView(view.id)" />
            }
        }
    `,
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [NgComponentOutlet]
		}]
	}],
	ctorParameters: () => [{ type: ViewSlotRegistry }, { type: i0.Injector }],
	propDecorators: {
		slot: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "slot",
				required: true
			}]
		}],
		initialViewId: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "initialViewId",
				required: false
			}]
		}]
	}
});
var SchedulerEventPopupDirective = class SchedulerEventPopupDirective {
	_template;
	_container;
	_document;
	_view;
	_root;
	constructor(_template = inject(TemplateRef), _container = inject(ViewContainerRef), _document = inject(DOCUMENT$1), host = inject(SchedulerEventComponent), destroyRef = inject(DestroyRef)) {
		this._template = _template;
		this._container = _container;
		this._document = _document;
		const event = host.elementRef.nativeElement;
		const previousTemplate = event.popupTemplate;
		const template = this.createView.bind(this);
		event.popupTemplate = template;
		effect(() => {
			const value = this.value();
			if (this._view) {
				this._view.context.$implicit = value;
				this._view.detectChanges();
			}
		});
		destroyRef.onDestroy(() => {
			if (event.popupTemplate === template) event.popupTemplate = previousTemplate;
			this.destroyView();
		});
	}
	value = input.required({
		...ngDevMode ? { debugName: "value" } : /* istanbul ignore next */ {},
		alias: "mosaikSchedulerEventPopup"
	});
	static ngTemplateContextGuard(_directive, _context) {
		return true;
	}
	createView(event) {
		this.destroyView();
		const view = this._container.createEmbeddedView(this._template, {
			$implicit: this.value(),
			event
		});
		const root = this._document.createElement("div");
		root.setAttribute("data-mosaik-portal-projection-root", "");
		root.style.display = "contents";
		this._view = view;
		this._root = root;
		try {
			view.detectChanges();
			root.append(...view.rootNodes);
		} catch (error) {
			this.destroyView();
			throw error;
		}
		return {
			content: root,
			destroy: () => {
				if (this._view === view) this.destroyView();
			}
		};
	}
	destroyView() {
		const view = this._view;
		const root = this._root;
		this._view = void 0;
		this._root = void 0;
		root?.remove();
		if (view && !view.destroyed) view.destroy();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: SchedulerEventPopupDirective,
		deps: [
			{ token: i0.TemplateRef },
			{ token: i0.ViewContainerRef },
			{ token: DOCUMENT$1 },
			{ token: i1.SchedulerEventComponent },
			{ token: i0.DestroyRef }
		],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: SchedulerEventPopupDirective,
		isStandalone: true,
		selector: "ng-template[mosaikSchedulerEventPopup]",
		inputs: { value: {
			classPropertyName: "value",
			publicName: "mosaikSchedulerEventPopup",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: SchedulerEventPopupDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "ng-template[mosaikSchedulerEventPopup]" }]
	}],
	ctorParameters: () => [
		{ type: i0.TemplateRef },
		{ type: i0.ViewContainerRef },
		{
			type: Document,
			decorators: [{
				type: Inject,
				args: [DOCUMENT$1]
			}]
		},
		{ type: i1.SchedulerEventComponent },
		{ type: i0.DestroyRef }
	],
	propDecorators: { value: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "mosaikSchedulerEventPopup",
			required: true
		}]
	}] }
});
export { AnimateDirective, AnimationRegistry, BreakpointDirective, BreakpointRegistry, BreakpointService, Cancel, CardIsBusyDirective, CellDefDirective, ColumnDefDirective, ComboItemVisualDirective, ComboTriggerDirective, DIALOG_BREAKPOINT_BEHAVIOR_CONFIG, DIALOG_CONFIG, DIALOG_REF, DIALOG_REF_DATA, DIALOG_STACK_BEHAVIOR_CONFIG, DRAWER_BREAKPOINT_BEHAVIOR_CONFIG, DRAWER_CONFIG, DRAWER_REF, DRAWER_REF_DATA, DRAWER_STACK_BEHAVIOR_CONFIG, DataTableColumnEditorToggleDirective, DateAgoPipe, DateAgoPipeIntl, DialogActionsDirective, DialogBreakpointBehavior, DialogContentDirective, DialogFooterDirective, DialogHeaderDirective, DialogPortalComponent, DialogRef, DialogService, DialogStackBehavior, DockDirective, DrawerActionsDirective, DrawerBreakpointBehavior, DrawerContentDirective, DrawerFooterDirective, DrawerHeaderDirective, DrawerPortalComponent, DrawerRailDirective, DrawerRef, DrawerService, DrawerStackBehavior, ErrorGroupDirective, ErrorKindDirective, ExpandableToggleDirective, FORM_STATUS_HOST, FilterByPipe, FlexDirective, FlipToDirective, FooterCellDefDirective, FormFieldDirective, FormFieldStateDirective, FormFieldStatusHostDirective, FormStatusHostDirective, FormatPipe, GlobalDomRef, HeaderCellDefDirective, IconDirective, IconNameDirective, IconPipe, IconRegistry, ItemCellDefDirective, ItemDefDirective, LocaleDirective, MESSAGE_BOX_BEHAVIORS, MESSAGE_BOX_CONFIG, MESSAGE_BOX_REF, MESSAGE_BOX_REF_DATA, MessageBoxPortalComponent, MessageBoxRef, MessageBoxService, MessageBoxTestIdBehavior, NumberBoxCurrencyDirective, NumberBoxDecimalDirective, NumberBoxPercentageDirective, OfPipe, OrderByPipe, OverlayInteractionBoundaryDirective, PROMPT_BOX, PerspectiveDirective, PortalCloseAttempt, PortalProjectionDirective, PromptBoxContentDirective, PromptBoxDirective, PromptBoxToolDirective, ProxyCmp, ReactiveFormValidator, ReactiveValidationSession, RippleDirective, SHEET_BEHAVIORS, SHEET_BREAKPOINT_BEHAVIOR_CONFIG, SHEET_CONFIG, SHEET_REF, SHEET_REF_DATA, ScaleDirective, SchedulerEventPopupDirective, SelectItemVisualDirective, SelectTriggerDirective, SheetBreakpointBehavior, SheetContentDirective, SheetFooterDirective, SheetHeaderDirective, SheetPortalComponent, SheetRef, SheetService, SignalFormValidator, SignalValidationBuilder, SpacerDirective, StepperNextDirective, StepperPrevDirective, TEXT_FORMATTER_DEFAULT_PROPS, THEME, THEME_MODE, TOAST_BEHAVIORS, TOAST_BREAKPOINT_BEHAVIOR_CONFIG, TOAST_CONFIG, TOAST_REF, TOAST_REF_DATA, TOAST_SLOTS, TOAST_STACK_BEHAVIOR_CONFIG, TOUR_ACCESSOR, TOUR_BEHAVIORS, TOUR_DEFINITIONS, TextFormatterDirective, ThemeService, TimeAgoPipe, TimeAgoPipeIntl, TimeUpdateService, ToastActionsDirective, ToastBreakpointBehavior, ToastPortalComponent, ToastRef, ToastService, ToastStackBehavior, TooltipDirective, TourAccessorDirective, TourAnchorDirective, TourService, TourStartDirective, TranslateDirective, TranslatePipe, TranslateService, TypographyDirective, VIEW_SLOT_CONTEXT, Validators, ViewSlotOutletComponent, ViewSlotRegistry, WizardNextDirective, WizardPrevDirective, applyDefaults, blank, createTourAccessorTarget, dateNotAfter, dateNotBefore, defineColumn, defineColumns, defineCustomElement, defineItem, defineItems, emailEndsWithDomain, equalsTo, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod, numeric, phoneNumber, provideAnimate, provideBreakpoints, provideDateAgoPipe, provideDefaultIconSet, provideDialogs, provideDrawers, provideForms, provideGlobalDom, provideIconLoader, provideIconRegistry, provideIconSet, provideIcons, provideMessageBoxes, provideSheets, provideTextFormatter, provideTheme, provideTimeAgoPipe, provideTimeUpdates, provideToastSlots, provideToasts, provideTours, provideTranslationRegistry, provideTranslations, provideViewSlot, provideViewSlotFrom, withDialogBreakpointBehavior, withDialogDefaultBehavior, withDialogStackBehavior, withDrawerBreakpointBehavior, withDrawerDefaultBehavior, withDrawerStackBehavior, withSheetBreakpointBehavior, withSheetDefaultBehavior, withToastBreakpointBehavior, withToastDefaultBehavior, withToastStackBehavior, withTourCameraBehavior, withTourDefaultBehavior };

//# sourceMappingURL=mosaik-elements-angular.mjs.map