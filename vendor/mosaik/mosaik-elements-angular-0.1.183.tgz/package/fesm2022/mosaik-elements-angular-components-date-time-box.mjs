import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, forwardRef, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { NG_VALUE_ACCESSOR } from "@angular/forms";
import { DateTimeBoxElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/date-time-box/DateTimeBoxElement";
import { dateTimeBoxElementValueAccessor } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/date-time-box/accessors/DateTimeBoxElementValueAccessor";
import * as i1 from "@pixel-brewery/mosaik-elements-angular/runtime";
import { FORM_STATUS_HOST, FormFieldStatusHostDirective, FormStatusHostDirective, ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const DATE_TIME_BOX_DEFAULT_PROPS = new InjectionToken("MOSAIK_DATE_TIME_BOX_DEFAULT_PROPS");
const DATE_TIME_BOX_INTL = new InjectionToken("MOSAIK_DATE_TIME_BOX_INTL");
let DateTimeBoxComponent = class DateTimeBoxComponent {
	displayDate = input(...ngDevMode ? [void 0, { debugName: "displayDate" }] : /* istanbul ignore next */ []);
	displayDateStart = input(...ngDevMode ? [void 0, { debugName: "displayDateStart" }] : /* istanbul ignore next */ []);
	displayDateEnd = input(...ngDevMode ? [void 0, { debugName: "displayDateEnd" }] : /* istanbul ignore next */ []);
	intl = input(...ngDevMode ? [void 0, { debugName: "intl" }] : /* istanbul ignore next */ []);
	values = input(...ngDevMode ? [void 0, { debugName: "values" }] : /* istanbul ignore next */ []);
	view = input(...ngDevMode ? [void 0, { debugName: "view" }] : /* istanbul ignore next */ []);
	allowedViews = input(...ngDevMode ? [void 0, { debugName: "allowedViews" }] : /* istanbul ignore next */ []);
	showNavigation = input(...ngDevMode ? [void 0, { debugName: "showNavigation" }] : /* istanbul ignore next */ []);
	blackoutDates = input(...ngDevMode ? [void 0, { debugName: "blackoutDates" }] : /* istanbul ignore next */ []);
	specialDates = input(...ngDevMode ? [void 0, { debugName: "specialDates" }] : /* istanbul ignore next */ []);
	minDate = input(...ngDevMode ? [void 0, { debugName: "minDate" }] : /* istanbul ignore next */ []);
	maxDate = input(...ngDevMode ? [void 0, { debugName: "maxDate" }] : /* istanbul ignore next */ []);
	firstDayOfWeek = input(...ngDevMode ? [void 0, { debugName: "firstDayOfWeek" }] : /* istanbul ignore next */ []);
	isTodayHighlighted = input(...ngDevMode ? [void 0, { debugName: "isTodayHighlighted" }] : /* istanbul ignore next */ []);
	isWeekendHighlighted = input(...ngDevMode ? [void 0, { debugName: "isWeekendHighlighted" }] : /* istanbul ignore next */ []);
	showWeekNumbers = input(...ngDevMode ? [void 0, { debugName: "showWeekNumbers" }] : /* istanbul ignore next */ []);
	markerHandler = input(...ngDevMode ? [void 0, { debugName: "markerHandler" }] : /* istanbul ignore next */ []);
	showAdjacent = input(...ngDevMode ? [void 0, { debugName: "showAdjacent" }] : /* istanbul ignore next */ []);
	readonly = input(...ngDevMode ? [void 0, { debugName: "readonly" }] : /* istanbul ignore next */ []);
	required = input(...ngDevMode ? [void 0, { debugName: "required" }] : /* istanbul ignore next */ []);
	autofocus = input(...ngDevMode ? [void 0, { debugName: "autofocus" }] : /* istanbul ignore next */ []);
	name = input(...ngDevMode ? [void 0, { debugName: "name" }] : /* istanbul ignore next */ []);
	placeholder = input(...ngDevMode ? [void 0, { debugName: "placeholder" }] : /* istanbul ignore next */ []);
	autocomplete = input(...ngDevMode ? [void 0, { debugName: "autocomplete" }] : /* istanbul ignore next */ []);
	format = input(...ngDevMode ? [void 0, { debugName: "format" }] : /* istanbul ignore next */ []);
	timePrecision = input(...ngDevMode ? [void 0, { debugName: "timePrecision" }] : /* istanbul ignore next */ []);
	textAlign = input(...ngDevMode ? [void 0, { debugName: "textAlign" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	size = input(...ngDevMode ? [void 0, { debugName: "size" }] : /* istanbul ignore next */ []);
	isClearable = input(...ngDevMode ? [void 0, { debugName: "isClearable" }] : /* istanbul ignore next */ []);
	locale = input(...ngDevMode ? [void 0, { debugName: "locale" }] : /* istanbul ignore next */ []);
	invalid = input(...ngDevMode ? [void 0, { debugName: "invalid" }] : /* istanbul ignore next */ []);
	value = input(...ngDevMode ? [void 0, { debugName: "value" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	appearance = input(...ngDevMode ? [void 0, { debugName: "appearance" }] : /* istanbul ignore next */ []);
	dropDownPlacement = input(...ngDevMode ? [void 0, { debugName: "dropDownPlacement" }] : /* istanbul ignore next */ []);
	dropDownStrategy = input(...ngDevMode ? [void 0, { debugName: "dropDownStrategy" }] : /* istanbul ignore next */ []);
	dropDownDistance = input(...ngDevMode ? [void 0, { debugName: "dropDownDistance" }] : /* istanbul ignore next */ []);
	dropDownSkidding = input(...ngDevMode ? [void 0, { debugName: "dropDownSkidding" }] : /* istanbul ignore next */ []);
	dropDownStaysOpen = input(...ngDevMode ? [void 0, { debugName: "dropDownStaysOpen" }] : /* istanbul ignore next */ []);
	dropDownMaxHeight = input(...ngDevMode ? [void 0, { debugName: "dropDownMaxHeight" }] : /* istanbul ignore next */ []);
	dropDownHeight = input(...ngDevMode ? [void 0, { debugName: "dropDownHeight" }] : /* istanbul ignore next */ []);
	dropDownWidth = input(...ngDevMode ? [void 0, { debugName: "dropDownWidth" }] : /* istanbul ignore next */ []);
	dropDownMaxWidth = input(...ngDevMode ? [void 0, { debugName: "dropDownMaxWidth" }] : /* istanbul ignore next */ []);
	isDropDownOpen = input(...ngDevMode ? [void 0, { debugName: "isDropDownOpen" }] : /* istanbul ignore next */ []);
	label = input(...ngDevMode ? [void 0, { debugName: "label" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	formatter = input(...ngDevMode ? [void 0, { debugName: "formatter" }] : /* istanbul ignore next */ []);
	parser = input(...ngDevMode ? [void 0, { debugName: "parser" }] : /* istanbul ignore next */ []);
	isFocused = input(...ngDevMode ? [void 0, { debugName: "isFocused" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	cleared = output();
	change = output();
	input = output();
	focus = output();
	blur = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	_accessor;
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._accessor = dateTimeBoxElementValueAccessor(this._elementRef.nativeElement);
		this._elementRef.nativeElement.addController(this._accessor);
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			cleared: this.cleared,
			change: this.change,
			input: this.input,
			focus: this.focus,
			blur: this.blur,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
			this._accessor.releaseCallbacks();
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(DATE_TIME_BOX_DEFAULT_PROPS, { optional: true }) ?? {}, ["intl"]);
		const injectedIntl = inject(DATE_TIME_BOX_INTL, { optional: true });
		if (injectedIntl) {
			Object.assign(this._elementRef.nativeElement.intl, injectedIntl);
			this._elementRef.nativeElement.intl.changes.emit();
		}
	}
	writeValue(obj) {
		this._accessor.writeValue(obj);
	}
	registerOnChange(fn) {
		this._accessor.registerOnChange(fn);
	}
	registerOnTouched(fn) {
		this._accessor.registerOnTouched(fn);
	}
	setDisabledState(isDisabled) {
		this._accessor.setDisabled?.(isDisabled);
	}
	open(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "open", args);
	}
	close(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "close", args);
	}
	apply(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "apply", args);
	}
	cancel(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "cancel", args);
	}
	clear(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "clear", args);
	}
	reset(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "reset", args);
	}
	checkValidity(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "checkValidity", args);
	}
	assignToSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "assignToSlot", args);
	}
	getSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getSlotContent", args);
	}
	hasSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlotContent", args);
	}
	hasSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlot", args);
	}
	onSlotChanges(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onSlotChanges", args);
	}
	toggle(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "toggle", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const displayDateValue = this.displayDate();
			if (displayDateValue !== void 0) this._elementRef.nativeElement.displayDate = displayDateValue;
			const displayDateStartValue = this.displayDateStart();
			if (displayDateStartValue !== void 0) this._elementRef.nativeElement.displayDateStart = displayDateStartValue;
			const displayDateEndValue = this.displayDateEnd();
			if (displayDateEndValue !== void 0) this._elementRef.nativeElement.displayDateEnd = displayDateEndValue;
			const valuesValue = this.values();
			if (valuesValue !== void 0) this._elementRef.nativeElement.values = valuesValue;
			const viewValue = this.view();
			if (viewValue !== void 0) this._elementRef.nativeElement.view = viewValue;
			const allowedViewsValue = this.allowedViews();
			if (allowedViewsValue !== void 0) this._elementRef.nativeElement.allowedViews = allowedViewsValue;
			const showNavigationValue = this.showNavigation();
			if (showNavigationValue !== void 0) this._elementRef.nativeElement.showNavigation = showNavigationValue;
			const blackoutDatesValue = this.blackoutDates();
			if (blackoutDatesValue !== void 0) this._elementRef.nativeElement.blackoutDates = blackoutDatesValue;
			const specialDatesValue = this.specialDates();
			if (specialDatesValue !== void 0) this._elementRef.nativeElement.specialDates = specialDatesValue;
			const minDateValue = this.minDate();
			if (minDateValue !== void 0) this._elementRef.nativeElement.minDate = minDateValue;
			const maxDateValue = this.maxDate();
			if (maxDateValue !== void 0) this._elementRef.nativeElement.maxDate = maxDateValue;
			const firstDayOfWeekValue = this.firstDayOfWeek();
			if (firstDayOfWeekValue !== void 0) this._elementRef.nativeElement.firstDayOfWeek = firstDayOfWeekValue;
			const isTodayHighlightedValue = this.isTodayHighlighted();
			if (isTodayHighlightedValue !== void 0) this._elementRef.nativeElement.isTodayHighlighted = isTodayHighlightedValue;
			const isWeekendHighlightedValue = this.isWeekendHighlighted();
			if (isWeekendHighlightedValue !== void 0) this._elementRef.nativeElement.isWeekendHighlighted = isWeekendHighlightedValue;
			const showWeekNumbersValue = this.showWeekNumbers();
			if (showWeekNumbersValue !== void 0) this._elementRef.nativeElement.showWeekNumbers = showWeekNumbersValue;
			const markerHandlerValue = this.markerHandler();
			if (markerHandlerValue !== void 0) this._elementRef.nativeElement.markerHandler = markerHandlerValue;
			const showAdjacentValue = this.showAdjacent();
			if (showAdjacentValue !== void 0) this._elementRef.nativeElement.showAdjacent = showAdjacentValue;
			const readonlyValue = this.readonly();
			if (readonlyValue !== void 0) this._elementRef.nativeElement.readonly = readonlyValue;
			const requiredValue = this.required();
			if (requiredValue !== void 0) this._elementRef.nativeElement.required = requiredValue;
			const autofocusValue = this.autofocus();
			if (autofocusValue !== void 0) this._elementRef.nativeElement.autofocus = autofocusValue;
			const nameValue = this.name();
			if (nameValue !== void 0) this._elementRef.nativeElement.name = nameValue;
			const placeholderValue = this.placeholder();
			if (placeholderValue !== void 0) this._elementRef.nativeElement.placeholder = placeholderValue;
			const autocompleteValue = this.autocomplete();
			if (autocompleteValue !== void 0) this._elementRef.nativeElement.autocomplete = autocompleteValue;
			const formatValue = this.format();
			if (formatValue !== void 0) this._elementRef.nativeElement.format = formatValue;
			const timePrecisionValue = this.timePrecision();
			if (timePrecisionValue !== void 0) this._elementRef.nativeElement.timePrecision = timePrecisionValue;
			const textAlignValue = this.textAlign();
			if (textAlignValue !== void 0) this._elementRef.nativeElement.textAlign = textAlignValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const sizeValue = this.size();
			if (sizeValue !== void 0) this._elementRef.nativeElement.size = sizeValue;
			const isClearableValue = this.isClearable();
			if (isClearableValue !== void 0) this._elementRef.nativeElement.isClearable = isClearableValue;
			const localeValue = this.locale();
			if (localeValue !== void 0) this._elementRef.nativeElement.locale = localeValue;
			const invalidValue = this.invalid();
			if (invalidValue !== void 0) this._elementRef.nativeElement.invalid = invalidValue;
			const valueValue = this.value();
			if (valueValue !== void 0) this._elementRef.nativeElement.value = valueValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const appearanceValue = this.appearance();
			if (appearanceValue !== void 0) this._elementRef.nativeElement.appearance = appearanceValue;
			const dropDownPlacementValue = this.dropDownPlacement();
			if (dropDownPlacementValue !== void 0) this._elementRef.nativeElement.dropDownPlacement = dropDownPlacementValue;
			const dropDownStrategyValue = this.dropDownStrategy();
			if (dropDownStrategyValue !== void 0) this._elementRef.nativeElement.dropDownStrategy = dropDownStrategyValue;
			const dropDownDistanceValue = this.dropDownDistance();
			if (dropDownDistanceValue !== void 0) this._elementRef.nativeElement.dropDownDistance = dropDownDistanceValue;
			const dropDownSkiddingValue = this.dropDownSkidding();
			if (dropDownSkiddingValue !== void 0) this._elementRef.nativeElement.dropDownSkidding = dropDownSkiddingValue;
			const dropDownStaysOpenValue = this.dropDownStaysOpen();
			if (dropDownStaysOpenValue !== void 0) this._elementRef.nativeElement.dropDownStaysOpen = dropDownStaysOpenValue;
			const dropDownMaxHeightValue = this.dropDownMaxHeight();
			if (dropDownMaxHeightValue !== void 0) this._elementRef.nativeElement.dropDownMaxHeight = dropDownMaxHeightValue;
			const dropDownHeightValue = this.dropDownHeight();
			if (dropDownHeightValue !== void 0) this._elementRef.nativeElement.dropDownHeight = dropDownHeightValue;
			const dropDownWidthValue = this.dropDownWidth();
			if (dropDownWidthValue !== void 0) this._elementRef.nativeElement.dropDownWidth = dropDownWidthValue;
			const dropDownMaxWidthValue = this.dropDownMaxWidth();
			if (dropDownMaxWidthValue !== void 0) this._elementRef.nativeElement.dropDownMaxWidth = dropDownMaxWidthValue;
			const isDropDownOpenValue = this.isDropDownOpen();
			if (isDropDownOpenValue !== void 0) this._elementRef.nativeElement.isDropDownOpen = isDropDownOpenValue;
			const labelValue = this.label();
			if (labelValue !== void 0) this._elementRef.nativeElement.label = labelValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const formatterValue = this.formatter();
			if (formatterValue !== void 0) this._elementRef.nativeElement.formatter = formatterValue;
			const parserValue = this.parser();
			if (parserValue !== void 0) this._elementRef.nativeElement.parser = parserValue;
			const isFocusedValue = this.isFocused();
			if (isFocusedValue !== void 0) this._elementRef.nativeElement.isFocused = isFocusedValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
			const intlValue = this.intl();
			if (intlValue !== void 0) {
				Object.assign(this._elementRef.nativeElement.intl, intlValue);
				this._elementRef.nativeElement.intl.changes.emit();
			}
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DateTimeBoxComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: DateTimeBoxComponent,
		isStandalone: true,
		selector: "mosaik-datetimebox",
		inputs: {
			displayDate: {
				classPropertyName: "displayDate",
				publicName: "displayDate",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			displayDateStart: {
				classPropertyName: "displayDateStart",
				publicName: "displayDateStart",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			displayDateEnd: {
				classPropertyName: "displayDateEnd",
				publicName: "displayDateEnd",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			intl: {
				classPropertyName: "intl",
				publicName: "intl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			values: {
				classPropertyName: "values",
				publicName: "values",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			view: {
				classPropertyName: "view",
				publicName: "view",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			allowedViews: {
				classPropertyName: "allowedViews",
				publicName: "allowedViews",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showNavigation: {
				classPropertyName: "showNavigation",
				publicName: "showNavigation",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			blackoutDates: {
				classPropertyName: "blackoutDates",
				publicName: "blackoutDates",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			specialDates: {
				classPropertyName: "specialDates",
				publicName: "specialDates",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			minDate: {
				classPropertyName: "minDate",
				publicName: "minDate",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			maxDate: {
				classPropertyName: "maxDate",
				publicName: "maxDate",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			firstDayOfWeek: {
				classPropertyName: "firstDayOfWeek",
				publicName: "firstDayOfWeek",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isTodayHighlighted: {
				classPropertyName: "isTodayHighlighted",
				publicName: "isTodayHighlighted",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isWeekendHighlighted: {
				classPropertyName: "isWeekendHighlighted",
				publicName: "isWeekendHighlighted",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showWeekNumbers: {
				classPropertyName: "showWeekNumbers",
				publicName: "showWeekNumbers",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			markerHandler: {
				classPropertyName: "markerHandler",
				publicName: "markerHandler",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showAdjacent: {
				classPropertyName: "showAdjacent",
				publicName: "showAdjacent",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			readonly: {
				classPropertyName: "readonly",
				publicName: "readonly",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			required: {
				classPropertyName: "required",
				publicName: "required",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			autofocus: {
				classPropertyName: "autofocus",
				publicName: "autofocus",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			name: {
				classPropertyName: "name",
				publicName: "name",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			placeholder: {
				classPropertyName: "placeholder",
				publicName: "placeholder",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			autocomplete: {
				classPropertyName: "autocomplete",
				publicName: "autocomplete",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			format: {
				classPropertyName: "format",
				publicName: "format",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			timePrecision: {
				classPropertyName: "timePrecision",
				publicName: "timePrecision",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			textAlign: {
				classPropertyName: "textAlign",
				publicName: "textAlign",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isClearable: {
				classPropertyName: "isClearable",
				publicName: "isClearable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			locale: {
				classPropertyName: "locale",
				publicName: "locale",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			invalid: {
				classPropertyName: "invalid",
				publicName: "invalid",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownPlacement: {
				classPropertyName: "dropDownPlacement",
				publicName: "dropDownPlacement",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownStrategy: {
				classPropertyName: "dropDownStrategy",
				publicName: "dropDownStrategy",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownDistance: {
				classPropertyName: "dropDownDistance",
				publicName: "dropDownDistance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownSkidding: {
				classPropertyName: "dropDownSkidding",
				publicName: "dropDownSkidding",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownStaysOpen: {
				classPropertyName: "dropDownStaysOpen",
				publicName: "dropDownStaysOpen",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownMaxHeight: {
				classPropertyName: "dropDownMaxHeight",
				publicName: "dropDownMaxHeight",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownHeight: {
				classPropertyName: "dropDownHeight",
				publicName: "dropDownHeight",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownWidth: {
				classPropertyName: "dropDownWidth",
				publicName: "dropDownWidth",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownMaxWidth: {
				classPropertyName: "dropDownMaxWidth",
				publicName: "dropDownMaxWidth",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isDropDownOpen: {
				classPropertyName: "isDropDownOpen",
				publicName: "isDropDownOpen",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			formatter: {
				classPropertyName: "formatter",
				publicName: "formatter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			parser: {
				classPropertyName: "parser",
				publicName: "parser",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isFocused: {
				classPropertyName: "isFocused",
				publicName: "isFocused",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			cleared: "cleared",
			change: "change",
			input: "input",
			focus: "focus",
			blur: "blur",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		providers: [{
			provide: NG_VALUE_ACCESSOR,
			useExisting: forwardRef(() => DateTimeBoxComponent),
			multi: true
		}, {
			provide: FORM_STATUS_HOST,
			useExisting: forwardRef(() => DateTimeBoxComponent)
		}],
		hostDirectives: [{ directive: i1.FormStatusHostDirective }, { directive: i1.FormFieldStatusHostDirective }],
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
DateTimeBoxComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-datetimebox", DateTimeBoxElement),
	inputs: [
		"displayDate",
		"displayDateStart",
		"displayDateEnd",
		"intl",
		"values",
		"view",
		"allowedViews",
		"showNavigation",
		"blackoutDates",
		"specialDates",
		"minDate",
		"maxDate",
		"firstDayOfWeek",
		"isTodayHighlighted",
		"isWeekendHighlighted",
		"showWeekNumbers",
		"markerHandler",
		"showAdjacent",
		"readonly",
		"required",
		"autofocus",
		"name",
		"placeholder",
		"autocomplete",
		"format",
		"timePrecision",
		"textAlign",
		"themeName",
		"size",
		"isClearable",
		"locale",
		"invalid",
		"value",
		"variant",
		"appearance",
		"dropDownPlacement",
		"dropDownStrategy",
		"dropDownDistance",
		"dropDownSkidding",
		"dropDownStaysOpen",
		"dropDownMaxHeight",
		"dropDownHeight",
		"dropDownWidth",
		"dropDownMaxWidth",
		"isDropDownOpen",
		"label",
		"disabled",
		"formatter",
		"parser",
		"isFocused",
		"dir",
		"lang"
	],
	methods: ["getSlotAssignments", "getSlotAssignmentsOf"]
}), __metadata("design:paramtypes", [])], DateTimeBoxComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DateTimeBoxComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-datetimebox",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>",
			hostDirectives: [FormStatusHostDirective, FormFieldStatusHostDirective],
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => DateTimeBoxComponent),
				multi: true
			}, {
				provide: FORM_STATUS_HOST,
				useExisting: forwardRef(() => DateTimeBoxComponent)
			}]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		displayDate: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "displayDate",
				required: false
			}]
		}],
		displayDateStart: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "displayDateStart",
				required: false
			}]
		}],
		displayDateEnd: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "displayDateEnd",
				required: false
			}]
		}],
		intl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "intl",
				required: false
			}]
		}],
		values: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "values",
				required: false
			}]
		}],
		view: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "view",
				required: false
			}]
		}],
		allowedViews: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "allowedViews",
				required: false
			}]
		}],
		showNavigation: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showNavigation",
				required: false
			}]
		}],
		blackoutDates: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "blackoutDates",
				required: false
			}]
		}],
		specialDates: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "specialDates",
				required: false
			}]
		}],
		minDate: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "minDate",
				required: false
			}]
		}],
		maxDate: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maxDate",
				required: false
			}]
		}],
		firstDayOfWeek: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "firstDayOfWeek",
				required: false
			}]
		}],
		isTodayHighlighted: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isTodayHighlighted",
				required: false
			}]
		}],
		isWeekendHighlighted: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isWeekendHighlighted",
				required: false
			}]
		}],
		showWeekNumbers: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showWeekNumbers",
				required: false
			}]
		}],
		markerHandler: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "markerHandler",
				required: false
			}]
		}],
		showAdjacent: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showAdjacent",
				required: false
			}]
		}],
		readonly: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "readonly",
				required: false
			}]
		}],
		required: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "required",
				required: false
			}]
		}],
		autofocus: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "autofocus",
				required: false
			}]
		}],
		name: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "name",
				required: false
			}]
		}],
		placeholder: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "placeholder",
				required: false
			}]
		}],
		autocomplete: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "autocomplete",
				required: false
			}]
		}],
		format: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "format",
				required: false
			}]
		}],
		timePrecision: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "timePrecision",
				required: false
			}]
		}],
		textAlign: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "textAlign",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		isClearable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isClearable",
				required: false
			}]
		}],
		locale: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "locale",
				required: false
			}]
		}],
		invalid: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "invalid",
				required: false
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		dropDownPlacement: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownPlacement",
				required: false
			}]
		}],
		dropDownStrategy: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownStrategy",
				required: false
			}]
		}],
		dropDownDistance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownDistance",
				required: false
			}]
		}],
		dropDownSkidding: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownSkidding",
				required: false
			}]
		}],
		dropDownStaysOpen: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownStaysOpen",
				required: false
			}]
		}],
		dropDownMaxHeight: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownMaxHeight",
				required: false
			}]
		}],
		dropDownHeight: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownHeight",
				required: false
			}]
		}],
		dropDownWidth: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownWidth",
				required: false
			}]
		}],
		dropDownMaxWidth: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownMaxWidth",
				required: false
			}]
		}],
		isDropDownOpen: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isDropDownOpen",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		formatter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "formatter",
				required: false
			}]
		}],
		parser: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "parser",
				required: false
			}]
		}],
		isFocused: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isFocused",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		cleared: [{
			type: i0.Output,
			args: ["cleared"]
		}],
		change: [{
			type: i0.Output,
			args: ["change"]
		}],
		input: [{
			type: i0.Output,
			args: ["input"]
		}],
		focus: [{
			type: i0.Output,
			args: ["focus"]
		}],
		blur: [{
			type: i0.Output,
			args: ["blur"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideDateTimeBoxComponent(config, intl) {
	const providers = [];
	if (config) providers.push({
		provide: DATE_TIME_BOX_DEFAULT_PROPS,
		useValue: config
	});
	if (intl) {
		if (typeof intl === "function") providers.push({
			provide: DATE_TIME_BOX_INTL,
			useClass: intl
		});
		else providers.push({
			provide: DATE_TIME_BOX_INTL,
			useValue: intl
		});
	}
	return makeEnvironmentProviders(providers);
}
export { DATE_TIME_BOX_DEFAULT_PROPS, DATE_TIME_BOX_INTL, DateTimeBoxComponent, provideDateTimeBoxComponent };

//# sourceMappingURL=mosaik-elements-angular-components-date-time-box.mjs.map