import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { CommentElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/comment/CommentElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const COMMENT_DEFAULT_PROPS = new InjectionToken("MOSAIK_COMMENT_DEFAULT_PROPS");
let CommentComponent = class CommentComponent {
	author = input(...ngDevMode ? [void 0, { debugName: "author" }] : /* istanbul ignore next */ []);
	at = input(...ngDevMode ? [void 0, { debugName: "at" }] : /* istanbul ignore next */ []);
	content = input(...ngDevMode ? [void 0, { debugName: "content" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	formatter = input(...ngDevMode ? [void 0, { debugName: "formatter" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(COMMENT_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const authorValue = this.author();
			if (authorValue !== void 0) this._elementRef.nativeElement.author = authorValue;
			const atValue = this.at();
			if (atValue !== void 0) this._elementRef.nativeElement.at = atValue;
			const contentValue = this.content();
			if (contentValue !== void 0) this._elementRef.nativeElement.content = contentValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const formatterValue = this.formatter();
			if (formatterValue !== void 0) this._elementRef.nativeElement.formatter = formatterValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: CommentComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: CommentComponent,
		isStandalone: true,
		selector: "mosaik-comment",
		inputs: {
			author: {
				classPropertyName: "author",
				publicName: "author",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			at: {
				classPropertyName: "at",
				publicName: "at",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			content: {
				classPropertyName: "content",
				publicName: "content",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			formatter: {
				classPropertyName: "formatter",
				publicName: "formatter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
CommentComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-comment", CommentElement),
	inputs: [
		"author",
		"at",
		"content",
		"themeName",
		"formatter",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], CommentComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: CommentComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-comment",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		author: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "author",
				required: false
			}]
		}],
		at: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "at",
				required: false
			}]
		}],
		content: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "content",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		formatter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "formatter",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideCommentComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: COMMENT_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { COMMENT_DEFAULT_PROPS, CommentComponent, provideCommentComponent };

//# sourceMappingURL=mosaik-elements-angular-components-comment.mjs.map