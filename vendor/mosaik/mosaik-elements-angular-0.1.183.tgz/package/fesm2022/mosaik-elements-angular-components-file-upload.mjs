import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, forwardRef, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { FilePickerElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/file-upload/FilePickerElement";
import * as i1 from "@pixel-brewery/mosaik-elements-angular/runtime";
import { FORM_STATUS_HOST, FormFieldStatusHostDirective, FormStatusHostDirective, ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { FileUploadItemElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/file-upload/FileUploadItemElement";
import { NG_VALUE_ACCESSOR } from "@angular/forms";
import { FileUploadElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/file-upload/FileUploadElement";
import { fileUploadElementValueAccessor } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/file-upload/accessors/FileUploadElementValueAccessor";
var __decorate$2 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$2 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const FILE_PICKER_DEFAULT_PROPS = new InjectionToken("MOSAIK_FILE_PICKER_DEFAULT_PROPS");
let FilePickerComponent = class FilePickerComponent {
	multiple = input(...ngDevMode ? [void 0, { debugName: "multiple" }] : /* istanbul ignore next */ []);
	accept = input(...ngDevMode ? [void 0, { debugName: "accept" }] : /* istanbul ignore next */ []);
	directory = input(...ngDevMode ? [void 0, { debugName: "directory" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	filesPicked = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			filesPicked: this.filesPicked,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(FILE_PICKER_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	pick(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "pick", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const multipleValue = this.multiple();
			if (multipleValue !== void 0) this._elementRef.nativeElement.multiple = multipleValue;
			const acceptValue = this.accept();
			if (acceptValue !== void 0) this._elementRef.nativeElement.accept = acceptValue;
			const directoryValue = this.directory();
			if (directoryValue !== void 0) this._elementRef.nativeElement.directory = directoryValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FilePickerComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: FilePickerComponent,
		isStandalone: true,
		selector: "mosaik-file-picker",
		inputs: {
			multiple: {
				classPropertyName: "multiple",
				publicName: "multiple",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			accept: {
				classPropertyName: "accept",
				publicName: "accept",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			directory: {
				classPropertyName: "directory",
				publicName: "directory",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			filesPicked: "filesPicked",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
FilePickerComponent = __decorate$2([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-file-picker", FilePickerElement),
	inputs: [
		"multiple",
		"accept",
		"directory",
		"themeName",
		"disabled",
		"dir",
		"lang"
	]
}), __metadata$2("design:paramtypes", [])], FilePickerComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FilePickerComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-file-picker",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		multiple: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "multiple",
				required: false
			}]
		}],
		accept: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "accept",
				required: false
			}]
		}],
		directory: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "directory",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		filesPicked: [{
			type: i0.Output,
			args: ["filesPicked"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideFilePickerComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: FILE_PICKER_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$1 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$1 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const FILE_UPLOAD_ITEM_DEFAULT_PROPS = new InjectionToken("MOSAIK_FILE_UPLOAD_ITEM_DEFAULT_PROPS");
const FILE_UPLOAD_ITEM_INTL = new InjectionToken("MOSAIK_FILE_UPLOAD_ITEM_INTL");
let FileUploadItemComponent = class FileUploadItemComponent {
	intl = input(...ngDevMode ? [void 0, { debugName: "intl" }] : /* istanbul ignore next */ []);
	file = input(...ngDevMode ? [void 0, { debugName: "file" }] : /* istanbul ignore next */ []);
	view = input(...ngDevMode ? [void 0, { debugName: "view" }] : /* istanbul ignore next */ []);
	progressMode = input(...ngDevMode ? [void 0, { debugName: "progressMode" }] : /* istanbul ignore next */ []);
	showPreview = input(...ngDevMode ? [void 0, { debugName: "showPreview" }] : /* istanbul ignore next */ []);
	controlled = input(...ngDevMode ? [void 0, { debugName: "controlled" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(FILE_UPLOAD_ITEM_DEFAULT_PROPS, { optional: true }) ?? {}, ["intl"]);
		const injectedIntl = inject(FILE_UPLOAD_ITEM_INTL, { optional: true });
		if (injectedIntl) {
			Object.assign(this._elementRef.nativeElement.intl, injectedIntl);
			this._elementRef.nativeElement.intl.changes.emit();
		}
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const fileValue = this.file();
			if (fileValue !== void 0) this._elementRef.nativeElement.file = fileValue;
			const viewValue = this.view();
			if (viewValue !== void 0) this._elementRef.nativeElement.view = viewValue;
			const progressModeValue = this.progressMode();
			if (progressModeValue !== void 0) this._elementRef.nativeElement.progressMode = progressModeValue;
			const showPreviewValue = this.showPreview();
			if (showPreviewValue !== void 0) this._elementRef.nativeElement.showPreview = showPreviewValue;
			const controlledValue = this.controlled();
			if (controlledValue !== void 0) this._elementRef.nativeElement.controlled = controlledValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
			const intlValue = this.intl();
			if (intlValue !== void 0) {
				Object.assign(this._elementRef.nativeElement.intl, intlValue);
				this._elementRef.nativeElement.intl.changes.emit();
			}
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FileUploadItemComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: FileUploadItemComponent,
		isStandalone: true,
		selector: "mosaik-file-upload-item",
		inputs: {
			intl: {
				classPropertyName: "intl",
				publicName: "intl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			file: {
				classPropertyName: "file",
				publicName: "file",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			view: {
				classPropertyName: "view",
				publicName: "view",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			progressMode: {
				classPropertyName: "progressMode",
				publicName: "progressMode",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showPreview: {
				classPropertyName: "showPreview",
				publicName: "showPreview",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			controlled: {
				classPropertyName: "controlled",
				publicName: "controlled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
FileUploadItemComponent = __decorate$1([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-file-upload-item", FileUploadItemElement),
	inputs: [
		"intl",
		"file",
		"view",
		"progressMode",
		"showPreview",
		"controlled",
		"themeName",
		"dir",
		"lang"
	]
}), __metadata$1("design:paramtypes", [])], FileUploadItemComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FileUploadItemComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-file-upload-item",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		intl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "intl",
				required: false
			}]
		}],
		file: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "file",
				required: false
			}]
		}],
		view: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "view",
				required: false
			}]
		}],
		progressMode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "progressMode",
				required: false
			}]
		}],
		showPreview: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showPreview",
				required: false
			}]
		}],
		controlled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "controlled",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideFileUploadItemComponent(config, intl) {
	const providers = [];
	if (config) providers.push({
		provide: FILE_UPLOAD_ITEM_DEFAULT_PROPS,
		useValue: config
	});
	if (intl) {
		if (typeof intl === "function") providers.push({
			provide: FILE_UPLOAD_ITEM_INTL,
			useClass: intl
		});
		else providers.push({
			provide: FILE_UPLOAD_ITEM_INTL,
			useValue: intl
		});
	}
	return makeEnvironmentProviders(providers);
}
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const FILE_UPLOAD_DEFAULT_PROPS = new InjectionToken("MOSAIK_FILE_UPLOAD_DEFAULT_PROPS");
const FILE_UPLOAD_INTL = new InjectionToken("MOSAIK_FILE_UPLOAD_INTL");
let FileUploadComponent = class FileUploadComponent {
	intl = input(...ngDevMode ? [void 0, { debugName: "intl" }] : /* istanbul ignore next */ []);
	autoUpload = input(...ngDevMode ? [void 0, { debugName: "autoUpload" }] : /* istanbul ignore next */ []);
	view = input(...ngDevMode ? [void 0, { debugName: "view" }] : /* istanbul ignore next */ []);
	progressMode = input(...ngDevMode ? [void 0, { debugName: "progressMode" }] : /* istanbul ignore next */ []);
	showPreview = input(...ngDevMode ? [void 0, { debugName: "showPreview" }] : /* istanbul ignore next */ []);
	multiple = input(...ngDevMode ? [void 0, { debugName: "multiple" }] : /* istanbul ignore next */ []);
	directory = input(...ngDevMode ? [void 0, { debugName: "directory" }] : /* istanbul ignore next */ []);
	accept = input(...ngDevMode ? [void 0, { debugName: "accept" }] : /* istanbul ignore next */ []);
	strategy = input(...ngDevMode ? [void 0, { debugName: "strategy" }] : /* istanbul ignore next */ []);
	placeholder = input(...ngDevMode ? [void 0, { debugName: "placeholder" }] : /* istanbul ignore next */ []);
	maxSize = input(...ngDevMode ? [void 0, { debugName: "maxSize" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	appearance = input(...ngDevMode ? [void 0, { debugName: "appearance" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	invalid = input(...ngDevMode ? [void 0, { debugName: "invalid" }] : /* istanbul ignore next */ []);
	value = input(...ngDevMode ? [void 0, { debugName: "value" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	fileAdded = output();
	fileRemoved = output();
	fileFailed = output();
	filesChanged = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	_accessor;
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._accessor = fileUploadElementValueAccessor(this._elementRef.nativeElement);
		this._elementRef.nativeElement.addController(this._accessor);
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			fileAdded: this.fileAdded,
			fileRemoved: this.fileRemoved,
			fileFailed: this.fileFailed,
			filesChanged: this.filesChanged,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
			this._accessor.releaseCallbacks();
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(FILE_UPLOAD_DEFAULT_PROPS, { optional: true }) ?? {}, ["intl"]);
		const injectedIntl = inject(FILE_UPLOAD_INTL, { optional: true });
		if (injectedIntl) {
			Object.assign(this._elementRef.nativeElement.intl, injectedIntl);
			this._elementRef.nativeElement.intl.changes.emit();
		}
	}
	writeValue(obj) {
		this._accessor.writeValue(obj);
	}
	registerOnChange(fn) {
		this._accessor.registerOnChange(fn);
	}
	registerOnTouched(fn) {
		this._accessor.registerOnTouched(fn);
	}
	setDisabledState(isDisabled) {
		this._accessor.setDisabled?.(isDisabled);
	}
	add(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "add", args);
	}
	delete(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "delete", args);
	}
	save(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "save", args);
	}
	reset(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "reset", args);
	}
	checkValidity(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "checkValidity", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const autoUploadValue = this.autoUpload();
			if (autoUploadValue !== void 0) this._elementRef.nativeElement.autoUpload = autoUploadValue;
			const viewValue = this.view();
			if (viewValue !== void 0) this._elementRef.nativeElement.view = viewValue;
			const progressModeValue = this.progressMode();
			if (progressModeValue !== void 0) this._elementRef.nativeElement.progressMode = progressModeValue;
			const showPreviewValue = this.showPreview();
			if (showPreviewValue !== void 0) this._elementRef.nativeElement.showPreview = showPreviewValue;
			const multipleValue = this.multiple();
			if (multipleValue !== void 0) this._elementRef.nativeElement.multiple = multipleValue;
			const directoryValue = this.directory();
			if (directoryValue !== void 0) this._elementRef.nativeElement.directory = directoryValue;
			const acceptValue = this.accept();
			if (acceptValue !== void 0) this._elementRef.nativeElement.accept = acceptValue;
			const strategyValue = this.strategy();
			if (strategyValue !== void 0) this._elementRef.nativeElement.strategy = strategyValue;
			const placeholderValue = this.placeholder();
			if (placeholderValue !== void 0) this._elementRef.nativeElement.placeholder = placeholderValue;
			const maxSizeValue = this.maxSize();
			if (maxSizeValue !== void 0) this._elementRef.nativeElement.maxSize = maxSizeValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const appearanceValue = this.appearance();
			if (appearanceValue !== void 0) this._elementRef.nativeElement.appearance = appearanceValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const invalidValue = this.invalid();
			if (invalidValue !== void 0) this._elementRef.nativeElement.invalid = invalidValue;
			const valueValue = this.value();
			if (valueValue !== void 0) this._elementRef.nativeElement.value = valueValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
			const intlValue = this.intl();
			if (intlValue !== void 0) {
				Object.assign(this._elementRef.nativeElement.intl, intlValue);
				this._elementRef.nativeElement.intl.changes.emit();
			}
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FileUploadComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: FileUploadComponent,
		isStandalone: true,
		selector: "mosaik-file-upload",
		inputs: {
			intl: {
				classPropertyName: "intl",
				publicName: "intl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			autoUpload: {
				classPropertyName: "autoUpload",
				publicName: "autoUpload",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			view: {
				classPropertyName: "view",
				publicName: "view",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			progressMode: {
				classPropertyName: "progressMode",
				publicName: "progressMode",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showPreview: {
				classPropertyName: "showPreview",
				publicName: "showPreview",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			multiple: {
				classPropertyName: "multiple",
				publicName: "multiple",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			directory: {
				classPropertyName: "directory",
				publicName: "directory",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			accept: {
				classPropertyName: "accept",
				publicName: "accept",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			strategy: {
				classPropertyName: "strategy",
				publicName: "strategy",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			placeholder: {
				classPropertyName: "placeholder",
				publicName: "placeholder",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			maxSize: {
				classPropertyName: "maxSize",
				publicName: "maxSize",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			invalid: {
				classPropertyName: "invalid",
				publicName: "invalid",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			fileAdded: "fileAdded",
			fileRemoved: "fileRemoved",
			fileFailed: "fileFailed",
			filesChanged: "filesChanged",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		providers: [{
			provide: NG_VALUE_ACCESSOR,
			useExisting: forwardRef(() => FileUploadComponent),
			multi: true
		}, {
			provide: FORM_STATUS_HOST,
			useExisting: forwardRef(() => FileUploadComponent)
		}],
		hostDirectives: [{ directive: i1.FormStatusHostDirective }, { directive: i1.FormFieldStatusHostDirective }],
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
FileUploadComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-file-upload", FileUploadElement),
	inputs: [
		"intl",
		"autoUpload",
		"view",
		"progressMode",
		"showPreview",
		"multiple",
		"directory",
		"accept",
		"strategy",
		"placeholder",
		"maxSize",
		"themeName",
		"disabled",
		"appearance",
		"variant",
		"invalid",
		"value",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], FileUploadComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FileUploadComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-file-upload",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>",
			hostDirectives: [FormStatusHostDirective, FormFieldStatusHostDirective],
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => FileUploadComponent),
				multi: true
			}, {
				provide: FORM_STATUS_HOST,
				useExisting: forwardRef(() => FileUploadComponent)
			}]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		intl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "intl",
				required: false
			}]
		}],
		autoUpload: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "autoUpload",
				required: false
			}]
		}],
		view: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "view",
				required: false
			}]
		}],
		progressMode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "progressMode",
				required: false
			}]
		}],
		showPreview: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showPreview",
				required: false
			}]
		}],
		multiple: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "multiple",
				required: false
			}]
		}],
		directory: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "directory",
				required: false
			}]
		}],
		accept: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "accept",
				required: false
			}]
		}],
		strategy: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "strategy",
				required: false
			}]
		}],
		placeholder: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "placeholder",
				required: false
			}]
		}],
		maxSize: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maxSize",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		invalid: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "invalid",
				required: false
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		fileAdded: [{
			type: i0.Output,
			args: ["fileAdded"]
		}],
		fileRemoved: [{
			type: i0.Output,
			args: ["fileRemoved"]
		}],
		fileFailed: [{
			type: i0.Output,
			args: ["fileFailed"]
		}],
		filesChanged: [{
			type: i0.Output,
			args: ["filesChanged"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideFileUploadComponent(config, intl) {
	const providers = [];
	if (config) providers.push({
		provide: FILE_UPLOAD_DEFAULT_PROPS,
		useValue: config
	});
	if (intl) {
		if (typeof intl === "function") providers.push({
			provide: FILE_UPLOAD_INTL,
			useClass: intl
		});
		else providers.push({
			provide: FILE_UPLOAD_INTL,
			useValue: intl
		});
	}
	return makeEnvironmentProviders(providers);
}
export { FILE_PICKER_DEFAULT_PROPS, FILE_UPLOAD_DEFAULT_PROPS, FILE_UPLOAD_INTL, FILE_UPLOAD_ITEM_DEFAULT_PROPS, FILE_UPLOAD_ITEM_INTL, FilePickerComponent, FileUploadComponent, FileUploadItemComponent, provideFilePickerComponent, provideFileUploadComponent, provideFileUploadItemComponent };

//# sourceMappingURL=mosaik-elements-angular-components-file-upload.mjs.map