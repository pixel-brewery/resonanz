import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { KnobElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/ranges/knob/KnobElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const KNOB_DEFAULT_PROPS = new InjectionToken("MOSAIK_KNOB_DEFAULT_PROPS");
let KnobComponent = class KnobComponent {
	step = input(...ngDevMode ? [void 0, { debugName: "step" }] : /* istanbul ignore next */ []);
	diameter = input(...ngDevMode ? [void 0, { debugName: "diameter" }] : /* istanbul ignore next */ []);
	mode = input(...ngDevMode ? [void 0, { debugName: "mode" }] : /* istanbul ignore next */ []);
	startAngle = input(...ngDevMode ? [void 0, { debugName: "startAngle" }] : /* istanbul ignore next */ []);
	endAngle = input(...ngDevMode ? [void 0, { debugName: "endAngle" }] : /* istanbul ignore next */ []);
	ticks = input(...ngDevMode ? [void 0, { debugName: "ticks" }] : /* istanbul ignore next */ []);
	tickPlacement = input(...ngDevMode ? [void 0, { debugName: "tickPlacement" }] : /* istanbul ignore next */ []);
	tickLength = input(...ngDevMode ? [void 0, { debugName: "tickLength" }] : /* istanbul ignore next */ []);
	tickGap = input(...ngDevMode ? [void 0, { debugName: "tickGap" }] : /* istanbul ignore next */ []);
	pxPerStep = input(...ngDevMode ? [void 0, { debugName: "pxPerStep" }] : /* istanbul ignore next */ []);
	wheel = input(...ngDevMode ? [void 0, { debugName: "wheel" }] : /* istanbul ignore next */ []);
	label = input(...ngDevMode ? [void 0, { debugName: "label" }] : /* istanbul ignore next */ []);
	showValue = input(...ngDevMode ? [void 0, { debugName: "showValue" }] : /* istanbul ignore next */ []);
	valueAccessor = input(...ngDevMode ? [void 0, { debugName: "valueAccessor" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	appearance = input(...ngDevMode ? [void 0, { debugName: "appearance" }] : /* istanbul ignore next */ []);
	isFocused = input(...ngDevMode ? [void 0, { debugName: "isFocused" }] : /* istanbul ignore next */ []);
	invalid = input(...ngDevMode ? [void 0, { debugName: "invalid" }] : /* istanbul ignore next */ []);
	min = input(...ngDevMode ? [void 0, { debugName: "min" }] : /* istanbul ignore next */ []);
	max = input(...ngDevMode ? [void 0, { debugName: "max" }] : /* istanbul ignore next */ []);
	value = input(...ngDevMode ? [void 0, { debugName: "value" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	rangeValueChanged = output();
	input = output();
	change = output();
	changed = output();
	connected = output();
	disconnected = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			rangeValueChanged: this.rangeValueChanged,
			input: this.input,
			change: this.change,
			changed: this.changed,
			connected: this.connected,
			disconnected: this.disconnected
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(KNOB_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	stepDown(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "stepDown", args);
	}
	stepUp(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "stepUp", args);
	}
	checkValidity(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "checkValidity", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const stepValue = this.step();
			if (stepValue !== void 0) this._elementRef.nativeElement.step = stepValue;
			const diameterValue = this.diameter();
			if (diameterValue !== void 0) this._elementRef.nativeElement.diameter = diameterValue;
			const modeValue = this.mode();
			if (modeValue !== void 0) this._elementRef.nativeElement.mode = modeValue;
			const startAngleValue = this.startAngle();
			if (startAngleValue !== void 0) this._elementRef.nativeElement.startAngle = startAngleValue;
			const endAngleValue = this.endAngle();
			if (endAngleValue !== void 0) this._elementRef.nativeElement.endAngle = endAngleValue;
			const tickPlacementValue = this.tickPlacement();
			if (tickPlacementValue !== void 0) this._elementRef.nativeElement.tickPlacement = tickPlacementValue;
			const tickLengthValue = this.tickLength();
			if (tickLengthValue !== void 0) this._elementRef.nativeElement.tickLength = tickLengthValue;
			const tickGapValue = this.tickGap();
			if (tickGapValue !== void 0) this._elementRef.nativeElement.tickGap = tickGapValue;
			const pxPerStepValue = this.pxPerStep();
			if (pxPerStepValue !== void 0) this._elementRef.nativeElement.pxPerStep = pxPerStepValue;
			const wheelValue = this.wheel();
			if (wheelValue !== void 0) this._elementRef.nativeElement.wheel = wheelValue;
			const labelValue = this.label();
			if (labelValue !== void 0) this._elementRef.nativeElement.label = labelValue;
			const showValueValue = this.showValue();
			if (showValueValue !== void 0) this._elementRef.nativeElement.showValue = showValueValue;
			const valueAccessorValue = this.valueAccessor();
			if (valueAccessorValue !== void 0) this._elementRef.nativeElement.valueAccessor = valueAccessorValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const appearanceValue = this.appearance();
			if (appearanceValue !== void 0) this._elementRef.nativeElement.appearance = appearanceValue;
			const isFocusedValue = this.isFocused();
			if (isFocusedValue !== void 0) this._elementRef.nativeElement.isFocused = isFocusedValue;
			const invalidValue = this.invalid();
			if (invalidValue !== void 0) this._elementRef.nativeElement.invalid = invalidValue;
			const minValue = this.min();
			if (minValue !== void 0) this._elementRef.nativeElement.min = minValue;
			const maxValue = this.max();
			if (maxValue !== void 0) this._elementRef.nativeElement.max = maxValue;
			const valueValue = this.value();
			if (valueValue !== void 0) this._elementRef.nativeElement.value = valueValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: KnobComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: KnobComponent,
		isStandalone: true,
		selector: "mosaik-knob",
		inputs: {
			step: {
				classPropertyName: "step",
				publicName: "step",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			diameter: {
				classPropertyName: "diameter",
				publicName: "diameter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			mode: {
				classPropertyName: "mode",
				publicName: "mode",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			startAngle: {
				classPropertyName: "startAngle",
				publicName: "startAngle",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			endAngle: {
				classPropertyName: "endAngle",
				publicName: "endAngle",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			ticks: {
				classPropertyName: "ticks",
				publicName: "ticks",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			tickPlacement: {
				classPropertyName: "tickPlacement",
				publicName: "tickPlacement",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			tickLength: {
				classPropertyName: "tickLength",
				publicName: "tickLength",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			tickGap: {
				classPropertyName: "tickGap",
				publicName: "tickGap",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			pxPerStep: {
				classPropertyName: "pxPerStep",
				publicName: "pxPerStep",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			wheel: {
				classPropertyName: "wheel",
				publicName: "wheel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showValue: {
				classPropertyName: "showValue",
				publicName: "showValue",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			valueAccessor: {
				classPropertyName: "valueAccessor",
				publicName: "valueAccessor",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isFocused: {
				classPropertyName: "isFocused",
				publicName: "isFocused",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			invalid: {
				classPropertyName: "invalid",
				publicName: "invalid",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			min: {
				classPropertyName: "min",
				publicName: "min",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			max: {
				classPropertyName: "max",
				publicName: "max",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			rangeValueChanged: "rangeValueChanged",
			input: "input",
			change: "change",
			changed: "changed",
			connected: "connected",
			disconnected: "disconnected"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
KnobComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-knob", KnobElement),
	inputs: [
		"step",
		"diameter",
		"mode",
		"startAngle",
		"endAngle",
		"ticks",
		"tickPlacement",
		"tickLength",
		"tickGap",
		"pxPerStep",
		"wheel",
		"label",
		"showValue",
		"valueAccessor",
		"themeName",
		"disabled",
		"variant",
		"appearance",
		"isFocused",
		"invalid",
		"min",
		"max",
		"value",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], KnobComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: KnobComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-knob",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		step: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "step",
				required: false
			}]
		}],
		diameter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "diameter",
				required: false
			}]
		}],
		mode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mode",
				required: false
			}]
		}],
		startAngle: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "startAngle",
				required: false
			}]
		}],
		endAngle: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "endAngle",
				required: false
			}]
		}],
		ticks: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "ticks",
				required: false
			}]
		}],
		tickPlacement: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tickPlacement",
				required: false
			}]
		}],
		tickLength: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tickLength",
				required: false
			}]
		}],
		tickGap: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tickGap",
				required: false
			}]
		}],
		pxPerStep: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "pxPerStep",
				required: false
			}]
		}],
		wheel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "wheel",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		showValue: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showValue",
				required: false
			}]
		}],
		valueAccessor: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "valueAccessor",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		isFocused: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isFocused",
				required: false
			}]
		}],
		invalid: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "invalid",
				required: false
			}]
		}],
		min: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "min",
				required: false
			}]
		}],
		max: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "max",
				required: false
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		rangeValueChanged: [{
			type: i0.Output,
			args: ["rangeValueChanged"]
		}],
		input: [{
			type: i0.Output,
			args: ["input"]
		}],
		change: [{
			type: i0.Output,
			args: ["change"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}]
	}
});
function provideKnobComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: KNOB_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { KNOB_DEFAULT_PROPS, KnobComponent, provideKnobComponent };

//# sourceMappingURL=mosaik-elements-angular-components-knob.mjs.map