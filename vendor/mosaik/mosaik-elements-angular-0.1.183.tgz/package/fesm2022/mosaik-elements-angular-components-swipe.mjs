import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { SwipeElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/swipe/SwipeElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const SWIPE_DEFAULT_PROPS = new InjectionToken("MOSAIK_SWIPE_DEFAULT_PROPS");
let SwipeComponent = class SwipeComponent {
	panEndTriggeringThreshold = input(...ngDevMode ? [void 0, { debugName: "panEndTriggeringThreshold" }] : /* istanbul ignore next */ []);
	panLeftDisabled = input(...ngDevMode ? [void 0, { debugName: "panLeftDisabled" }] : /* istanbul ignore next */ []);
	panRightDisabled = input(...ngDevMode ? [void 0, { debugName: "panRightDisabled" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	swipeLeft = output();
	swipeRight = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			swipeLeft: this.swipeLeft,
			swipeRight: this.swipeRight,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(SWIPE_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	panLeft(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "panLeft", args);
	}
	panRight(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "panRight", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const panEndTriggeringThresholdValue = this.panEndTriggeringThreshold();
			if (panEndTriggeringThresholdValue !== void 0) this._elementRef.nativeElement.panEndTriggeringThreshold = panEndTriggeringThresholdValue;
			const panLeftDisabledValue = this.panLeftDisabled();
			if (panLeftDisabledValue !== void 0) this._elementRef.nativeElement.panLeftDisabled = panLeftDisabledValue;
			const panRightDisabledValue = this.panRightDisabled();
			if (panRightDisabledValue !== void 0) this._elementRef.nativeElement.panRightDisabled = panRightDisabledValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: SwipeComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: SwipeComponent,
		isStandalone: true,
		selector: "mosaik-swipe",
		inputs: {
			panEndTriggeringThreshold: {
				classPropertyName: "panEndTriggeringThreshold",
				publicName: "panEndTriggeringThreshold",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			panLeftDisabled: {
				classPropertyName: "panLeftDisabled",
				publicName: "panLeftDisabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			panRightDisabled: {
				classPropertyName: "panRightDisabled",
				publicName: "panRightDisabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			swipeLeft: "swipeLeft",
			swipeRight: "swipeRight",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
SwipeComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-swipe", SwipeElement),
	inputs: [
		"panEndTriggeringThreshold",
		"panLeftDisabled",
		"panRightDisabled",
		"themeName",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], SwipeComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: SwipeComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-swipe",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		panEndTriggeringThreshold: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "panEndTriggeringThreshold",
				required: false
			}]
		}],
		panLeftDisabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "panLeftDisabled",
				required: false
			}]
		}],
		panRightDisabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "panRightDisabled",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		swipeLeft: [{
			type: i0.Output,
			args: ["swipeLeft"]
		}],
		swipeRight: [{
			type: i0.Output,
			args: ["swipeRight"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideSwipeComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: SWIPE_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { SWIPE_DEFAULT_PROPS, SwipeComponent, provideSwipeComponent };

//# sourceMappingURL=mosaik-elements-angular-components-swipe.mjs.map