import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { UpDownSpinnerElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/up-down-spinner/UpDownSpinnerElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const UP_DOWN_SPINNER_DEFAULT_PROPS = new InjectionToken("MOSAIK_UP_DOWN_SPINNER_DEFAULT_PROPS");
const UP_DOWN_SPINNER_INTL = new InjectionToken("MOSAIK_UP_DOWN_SPINNER_INTL");
let UpDownSpinnerComponent = class UpDownSpinnerComponent {
	increaseIcon = input(...ngDevMode ? [void 0, { debugName: "increaseIcon" }] : /* istanbul ignore next */ []);
	decreaseIcon = input(...ngDevMode ? [void 0, { debugName: "decreaseIcon" }] : /* istanbul ignore next */ []);
	intl = input(...ngDevMode ? [void 0, { debugName: "intl" }] : /* istanbul ignore next */ []);
	delay = input(...ngDevMode ? [void 0, { debugName: "delay" }] : /* istanbul ignore next */ []);
	interval = input(...ngDevMode ? [void 0, { debugName: "interval" }] : /* istanbul ignore next */ []);
	position = input(...ngDevMode ? [void 0, { debugName: "position" }] : /* istanbul ignore next */ []);
	increaseDisabled = input(...ngDevMode ? [void 0, { debugName: "increaseDisabled" }] : /* istanbul ignore next */ []);
	decreaseDisabled = input(...ngDevMode ? [void 0, { debugName: "decreaseDisabled" }] : /* istanbul ignore next */ []);
	focusable = input(...ngDevMode ? [void 0, { debugName: "focusable" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	size = input(...ngDevMode ? [void 0, { debugName: "size" }] : /* istanbul ignore next */ []);
	appearance = input(...ngDevMode ? [void 0, { debugName: "appearance" }] : /* istanbul ignore next */ []);
	orientation = input(...ngDevMode ? [void 0, { debugName: "orientation" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	spinned = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			spinned: this.spinned,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(UP_DOWN_SPINNER_DEFAULT_PROPS, { optional: true }) ?? {}, ["intl"]);
		const injectedIntl = inject(UP_DOWN_SPINNER_INTL, { optional: true });
		if (injectedIntl) {
			Object.assign(this._elementRef.nativeElement.intl, injectedIntl);
			this._elementRef.nativeElement.intl.changes.emit();
		}
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const increaseIconValue = this.increaseIcon();
			if (increaseIconValue !== void 0) this._elementRef.nativeElement.increaseIcon = increaseIconValue;
			const decreaseIconValue = this.decreaseIcon();
			if (decreaseIconValue !== void 0) this._elementRef.nativeElement.decreaseIcon = decreaseIconValue;
			const delayValue = this.delay();
			if (delayValue !== void 0) this._elementRef.nativeElement.delay = delayValue;
			const intervalValue = this.interval();
			if (intervalValue !== void 0) this._elementRef.nativeElement.interval = intervalValue;
			const positionValue = this.position();
			if (positionValue !== void 0) this._elementRef.nativeElement.position = positionValue;
			const increaseDisabledValue = this.increaseDisabled();
			if (increaseDisabledValue !== void 0) this._elementRef.nativeElement.increaseDisabled = increaseDisabledValue;
			const decreaseDisabledValue = this.decreaseDisabled();
			if (decreaseDisabledValue !== void 0) this._elementRef.nativeElement.decreaseDisabled = decreaseDisabledValue;
			const focusableValue = this.focusable();
			if (focusableValue !== void 0) this._elementRef.nativeElement.focusable = focusableValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const sizeValue = this.size();
			if (sizeValue !== void 0) this._elementRef.nativeElement.size = sizeValue;
			const appearanceValue = this.appearance();
			if (appearanceValue !== void 0) this._elementRef.nativeElement.appearance = appearanceValue;
			const orientationValue = this.orientation();
			if (orientationValue !== void 0) this._elementRef.nativeElement.orientation = orientationValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
			const intlValue = this.intl();
			if (intlValue !== void 0) {
				Object.assign(this._elementRef.nativeElement.intl, intlValue);
				this._elementRef.nativeElement.intl.changes.emit();
			}
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: UpDownSpinnerComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: UpDownSpinnerComponent,
		isStandalone: true,
		selector: "mosaik-updown-spinner",
		inputs: {
			increaseIcon: {
				classPropertyName: "increaseIcon",
				publicName: "increaseIcon",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			decreaseIcon: {
				classPropertyName: "decreaseIcon",
				publicName: "decreaseIcon",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			intl: {
				classPropertyName: "intl",
				publicName: "intl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			delay: {
				classPropertyName: "delay",
				publicName: "delay",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			interval: {
				classPropertyName: "interval",
				publicName: "interval",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			position: {
				classPropertyName: "position",
				publicName: "position",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			increaseDisabled: {
				classPropertyName: "increaseDisabled",
				publicName: "increaseDisabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			decreaseDisabled: {
				classPropertyName: "decreaseDisabled",
				publicName: "decreaseDisabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			focusable: {
				classPropertyName: "focusable",
				publicName: "focusable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			orientation: {
				classPropertyName: "orientation",
				publicName: "orientation",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			spinned: "spinned",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
UpDownSpinnerComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-updown-spinner", UpDownSpinnerElement),
	inputs: [
		"increaseIcon",
		"decreaseIcon",
		"intl",
		"delay",
		"interval",
		"position",
		"increaseDisabled",
		"decreaseDisabled",
		"focusable",
		"themeName",
		"variant",
		"size",
		"appearance",
		"orientation",
		"disabled",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], UpDownSpinnerComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: UpDownSpinnerComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-updown-spinner",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		increaseIcon: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "increaseIcon",
				required: false
			}]
		}],
		decreaseIcon: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "decreaseIcon",
				required: false
			}]
		}],
		intl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "intl",
				required: false
			}]
		}],
		delay: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "delay",
				required: false
			}]
		}],
		interval: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "interval",
				required: false
			}]
		}],
		position: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "position",
				required: false
			}]
		}],
		increaseDisabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "increaseDisabled",
				required: false
			}]
		}],
		decreaseDisabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "decreaseDisabled",
				required: false
			}]
		}],
		focusable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "focusable",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		orientation: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "orientation",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		spinned: [{
			type: i0.Output,
			args: ["spinned"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideUpDownSpinnerComponent(config, intl) {
	const providers = [];
	if (config) providers.push({
		provide: UP_DOWN_SPINNER_DEFAULT_PROPS,
		useValue: config
	});
	if (intl) {
		if (typeof intl === "function") providers.push({
			provide: UP_DOWN_SPINNER_INTL,
			useClass: intl
		});
		else providers.push({
			provide: UP_DOWN_SPINNER_INTL,
			useValue: intl
		});
	}
	return makeEnvironmentProviders(providers);
}
export { UP_DOWN_SPINNER_DEFAULT_PROPS, UP_DOWN_SPINNER_INTL, UpDownSpinnerComponent, provideUpDownSpinnerComponent };

//# sourceMappingURL=mosaik-elements-angular-components-up-down-spinner.mjs.map