import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { FlowControlsElement, FlowEdgeElement, FlowElement, FlowMinimapElement, FlowNodeElement } from "@pixel-brewery/mosaik-elements-foundation/components/flow";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate$4 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$4 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const FLOW_CONTROLS_DEFAULT_PROPS = new InjectionToken("MOSAIK_FLOW_CONTROLS_DEFAULT_PROPS");
let FlowControlsComponent = class FlowControlsComponent {
	showZoom = input(...ngDevMode ? [void 0, { debugName: "showZoom" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(FLOW_CONTROLS_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const showZoomValue = this.showZoom();
			if (showZoomValue !== void 0) this._elementRef.nativeElement.showZoom = showZoomValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FlowControlsComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: FlowControlsComponent,
		isStandalone: true,
		selector: "mosaik-flow-controls",
		inputs: {
			showZoom: {
				classPropertyName: "showZoom",
				publicName: "showZoom",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
FlowControlsComponent = __decorate$4([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-flow-controls", FlowControlsElement),
	inputs: [
		"showZoom",
		"themeName",
		"dir",
		"lang"
	]
}), __metadata$4("design:paramtypes", [])], FlowControlsComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FlowControlsComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-flow-controls",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		showZoom: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showZoom",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideFlowControlsComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: FLOW_CONTROLS_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$3 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$3 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const FLOW_EDGE_DEFAULT_PROPS = new InjectionToken("MOSAIK_FLOW_EDGE_DEFAULT_PROPS");
let FlowEdgeComponent = class FlowEdgeComponent {
	edgeKey = input(...ngDevMode ? [void 0, { debugName: "edgeKey" }] : /* istanbul ignore next */ []);
	source = input(...ngDevMode ? [void 0, { debugName: "source" }] : /* istanbul ignore next */ []);
	target = input(...ngDevMode ? [void 0, { debugName: "target" }] : /* istanbul ignore next */ []);
	sourceSide = input(...ngDevMode ? [void 0, { debugName: "sourceSide" }] : /* istanbul ignore next */ []);
	sourcePort = input(...ngDevMode ? [void 0, { debugName: "sourcePort" }] : /* istanbul ignore next */ []);
	showPorts = input(...ngDevMode ? [void 0, { debugName: "showPorts" }] : /* istanbul ignore next */ []);
	targetSide = input(...ngDevMode ? [void 0, { debugName: "targetSide" }] : /* istanbul ignore next */ []);
	routing = input(...ngDevMode ? [void 0, { debugName: "routing" }] : /* istanbul ignore next */ []);
	markerEnd = input(...ngDevMode ? [void 0, { debugName: "markerEnd" }] : /* istanbul ignore next */ []);
	offset = input(...ngDevMode ? [void 0, { debugName: "offset" }] : /* istanbul ignore next */ []);
	cornerRadius = input(...ngDevMode ? [void 0, { debugName: "cornerRadius" }] : /* istanbul ignore next */ []);
	labelPosition = input(...ngDevMode ? [void 0, { debugName: "labelPosition" }] : /* istanbul ignore next */ []);
	waypoints = input(...ngDevMode ? [void 0, { debugName: "waypoints" }] : /* istanbul ignore next */ []);
	pathBuilder = input(...ngDevMode ? [void 0, { debugName: "pathBuilder" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	label = input(...ngDevMode ? [void 0, { debugName: "label" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(FLOW_EDGE_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	focus(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "focus", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const edgeKeyValue = this.edgeKey();
			if (edgeKeyValue !== void 0) this._elementRef.nativeElement.edgeKey = edgeKeyValue;
			const sourceValue = this.source();
			if (sourceValue !== void 0) this._elementRef.nativeElement.source = sourceValue;
			const targetValue = this.target();
			if (targetValue !== void 0) this._elementRef.nativeElement.target = targetValue;
			const sourceSideValue = this.sourceSide();
			if (sourceSideValue !== void 0) this._elementRef.nativeElement.sourceSide = sourceSideValue;
			const sourcePortValue = this.sourcePort();
			if (sourcePortValue !== void 0) this._elementRef.nativeElement.sourcePort = sourcePortValue;
			const showPortsValue = this.showPorts();
			if (showPortsValue !== void 0) this._elementRef.nativeElement.showPorts = showPortsValue;
			const targetSideValue = this.targetSide();
			if (targetSideValue !== void 0) this._elementRef.nativeElement.targetSide = targetSideValue;
			const routingValue = this.routing();
			if (routingValue !== void 0) this._elementRef.nativeElement.routing = routingValue;
			const markerEndValue = this.markerEnd();
			if (markerEndValue !== void 0) this._elementRef.nativeElement.markerEnd = markerEndValue;
			const offsetValue = this.offset();
			if (offsetValue !== void 0) this._elementRef.nativeElement.offset = offsetValue;
			const cornerRadiusValue = this.cornerRadius();
			if (cornerRadiusValue !== void 0) this._elementRef.nativeElement.cornerRadius = cornerRadiusValue;
			const labelPositionValue = this.labelPosition();
			if (labelPositionValue !== void 0) this._elementRef.nativeElement.labelPosition = labelPositionValue;
			const waypointsValue = this.waypoints();
			if (waypointsValue !== void 0) this._elementRef.nativeElement.waypoints = waypointsValue;
			const pathBuilderValue = this.pathBuilder();
			if (pathBuilderValue !== void 0) this._elementRef.nativeElement.pathBuilder = pathBuilderValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const labelValue = this.label();
			if (labelValue !== void 0) this._elementRef.nativeElement.label = labelValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FlowEdgeComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: FlowEdgeComponent,
		isStandalone: true,
		selector: "mosaik-flow-edge",
		inputs: {
			edgeKey: {
				classPropertyName: "edgeKey",
				publicName: "edgeKey",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			source: {
				classPropertyName: "source",
				publicName: "source",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			target: {
				classPropertyName: "target",
				publicName: "target",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			sourceSide: {
				classPropertyName: "sourceSide",
				publicName: "sourceSide",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			sourcePort: {
				classPropertyName: "sourcePort",
				publicName: "sourcePort",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showPorts: {
				classPropertyName: "showPorts",
				publicName: "showPorts",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			targetSide: {
				classPropertyName: "targetSide",
				publicName: "targetSide",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			routing: {
				classPropertyName: "routing",
				publicName: "routing",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			markerEnd: {
				classPropertyName: "markerEnd",
				publicName: "markerEnd",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			offset: {
				classPropertyName: "offset",
				publicName: "offset",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			cornerRadius: {
				classPropertyName: "cornerRadius",
				publicName: "cornerRadius",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			labelPosition: {
				classPropertyName: "labelPosition",
				publicName: "labelPosition",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			waypoints: {
				classPropertyName: "waypoints",
				publicName: "waypoints",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			pathBuilder: {
				classPropertyName: "pathBuilder",
				publicName: "pathBuilder",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
FlowEdgeComponent = __decorate$3([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-flow-edge", FlowEdgeElement),
	inputs: [
		"edgeKey",
		"source",
		"target",
		"sourceSide",
		"sourcePort",
		"showPorts",
		"targetSide",
		"routing",
		"markerEnd",
		"offset",
		"cornerRadius",
		"labelPosition",
		"waypoints",
		"pathBuilder",
		"themeName",
		"label",
		"dir",
		"lang"
	]
}), __metadata$3("design:paramtypes", [])], FlowEdgeComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FlowEdgeComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-flow-edge",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		edgeKey: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "edgeKey",
				required: false
			}]
		}],
		source: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "source",
				required: false
			}]
		}],
		target: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "target",
				required: false
			}]
		}],
		sourceSide: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "sourceSide",
				required: false
			}]
		}],
		sourcePort: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "sourcePort",
				required: false
			}]
		}],
		showPorts: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showPorts",
				required: false
			}]
		}],
		targetSide: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "targetSide",
				required: false
			}]
		}],
		routing: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "routing",
				required: false
			}]
		}],
		markerEnd: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "markerEnd",
				required: false
			}]
		}],
		offset: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "offset",
				required: false
			}]
		}],
		cornerRadius: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "cornerRadius",
				required: false
			}]
		}],
		labelPosition: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "labelPosition",
				required: false
			}]
		}],
		waypoints: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "waypoints",
				required: false
			}]
		}],
		pathBuilder: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "pathBuilder",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideFlowEdgeComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: FLOW_EDGE_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$2 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$2 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const FLOW_MINIMAP_DEFAULT_PROPS = new InjectionToken("MOSAIK_FLOW_MINIMAP_DEFAULT_PROPS");
let FlowMinimapComponent = class FlowMinimapComponent {
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	label = input(...ngDevMode ? [void 0, { debugName: "label" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(FLOW_MINIMAP_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const labelValue = this.label();
			if (labelValue !== void 0) this._elementRef.nativeElement.label = labelValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FlowMinimapComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: FlowMinimapComponent,
		isStandalone: true,
		selector: "mosaik-flow-minimap",
		inputs: {
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
FlowMinimapComponent = __decorate$2([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-flow-minimap", FlowMinimapElement),
	inputs: [
		"themeName",
		"label",
		"dir",
		"lang"
	]
}), __metadata$2("design:paramtypes", [])], FlowMinimapComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FlowMinimapComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-flow-minimap",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideFlowMinimapComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: FLOW_MINIMAP_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$1 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$1 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const FLOW_NODE_DEFAULT_PROPS = new InjectionToken("MOSAIK_FLOW_NODE_DEFAULT_PROPS");
let FlowNodeComponent = class FlowNodeComponent {
	nodeKey = input(...ngDevMode ? [void 0, { debugName: "nodeKey" }] : /* istanbul ignore next */ []);
	x = input(...ngDevMode ? [void 0, { debugName: "x" }] : /* istanbul ignore next */ []);
	y = input(...ngDevMode ? [void 0, { debugName: "y" }] : /* istanbul ignore next */ []);
	shape = input(...ngDevMode ? [void 0, { debugName: "shape" }] : /* istanbul ignore next */ []);
	layoutGroup = input(...ngDevMode ? [void 0, { debugName: "layoutGroup" }] : /* istanbul ignore next */ []);
	reflowIgnore = input(...ngDevMode ? [void 0, { debugName: "reflowIgnore" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	label = input(...ngDevMode ? [void 0, { debugName: "label" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(FLOW_NODE_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	focus(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "focus", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const nodeKeyValue = this.nodeKey();
			if (nodeKeyValue !== void 0) this._elementRef.nativeElement.nodeKey = nodeKeyValue;
			const xValue = this.x();
			if (xValue !== void 0) this._elementRef.nativeElement.x = xValue;
			const yValue = this.y();
			if (yValue !== void 0) this._elementRef.nativeElement.y = yValue;
			const shapeValue = this.shape();
			if (shapeValue !== void 0) this._elementRef.nativeElement.shape = shapeValue;
			const layoutGroupValue = this.layoutGroup();
			if (layoutGroupValue !== void 0) this._elementRef.nativeElement.layoutGroup = layoutGroupValue;
			const reflowIgnoreValue = this.reflowIgnore();
			if (reflowIgnoreValue !== void 0) this._elementRef.nativeElement.reflowIgnore = reflowIgnoreValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const labelValue = this.label();
			if (labelValue !== void 0) this._elementRef.nativeElement.label = labelValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FlowNodeComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: FlowNodeComponent,
		isStandalone: true,
		selector: "mosaik-flow-node",
		inputs: {
			nodeKey: {
				classPropertyName: "nodeKey",
				publicName: "nodeKey",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			x: {
				classPropertyName: "x",
				publicName: "x",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			y: {
				classPropertyName: "y",
				publicName: "y",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			shape: {
				classPropertyName: "shape",
				publicName: "shape",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			layoutGroup: {
				classPropertyName: "layoutGroup",
				publicName: "layoutGroup",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			reflowIgnore: {
				classPropertyName: "reflowIgnore",
				publicName: "reflowIgnore",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
FlowNodeComponent = __decorate$1([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-flow-node", FlowNodeElement),
	inputs: [
		"nodeKey",
		"x",
		"y",
		"shape",
		"layoutGroup",
		"reflowIgnore",
		"themeName",
		"variant",
		"label",
		"dir",
		"lang"
	]
}), __metadata$1("design:paramtypes", [])], FlowNodeComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FlowNodeComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-flow-node",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		nodeKey: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "nodeKey",
				required: false
			}]
		}],
		x: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "x",
				required: false
			}]
		}],
		y: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "y",
				required: false
			}]
		}],
		shape: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "shape",
				required: false
			}]
		}],
		layoutGroup: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "layoutGroup",
				required: false
			}]
		}],
		reflowIgnore: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "reflowIgnore",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideFlowNodeComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: FLOW_NODE_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const FLOW_DEFAULT_PROPS = new InjectionToken("MOSAIK_FLOW_DEFAULT_PROPS");
const FLOW_INTL = new InjectionToken("MOSAIK_FLOW_INTL");
let FlowComponent = class FlowComponent {
	intl = input(...ngDevMode ? [void 0, { debugName: "intl" }] : /* istanbul ignore next */ []);
	layout = input(...ngDevMode ? [void 0, { debugName: "layout" }] : /* istanbul ignore next */ []);
	layoutEngine = input(...ngDevMode ? [void 0, { debugName: "layoutEngine" }] : /* istanbul ignore next */ []);
	layoutOptions = input(...ngDevMode ? [void 0, { debugName: "layoutOptions" }] : /* istanbul ignore next */ []);
	reflowEngine = input(...ngDevMode ? [void 0, { debugName: "reflowEngine" }] : /* istanbul ignore next */ []);
	direction = input(...ngDevMode ? [void 0, { debugName: "direction" }] : /* istanbul ignore next */ []);
	edgeRouting = input(...ngDevMode ? [void 0, { debugName: "edgeRouting" }] : /* istanbul ignore next */ []);
	edgeMarkerEnd = input(...ngDevMode ? [void 0, { debugName: "edgeMarkerEnd" }] : /* istanbul ignore next */ []);
	selectionMode = input(...ngDevMode ? [void 0, { debugName: "selectionMode" }] : /* istanbul ignore next */ []);
	selectedKey = input(...ngDevMode ? [void 0, { debugName: "selectedKey" }] : /* istanbul ignore next */ []);
	highlightMode = input(...ngDevMode ? [void 0, { debugName: "highlightMode" }] : /* istanbul ignore next */ []);
	grid = input(...ngDevMode ? [void 0, { debugName: "grid" }] : /* istanbul ignore next */ []);
	controlsPosition = input(...ngDevMode ? [void 0, { debugName: "controlsPosition" }] : /* istanbul ignore next */ []);
	minimapPosition = input(...ngDevMode ? [void 0, { debugName: "minimapPosition" }] : /* istanbul ignore next */ []);
	fitOnLoad = input(...ngDevMode ? [void 0, { debugName: "fitOnLoad" }] : /* istanbul ignore next */ []);
	fitPadding = input(...ngDevMode ? [void 0, { debugName: "fitPadding" }] : /* istanbul ignore next */ []);
	fitMinZoom = input(...ngDevMode ? [void 0, { debugName: "fitMinZoom" }] : /* istanbul ignore next */ []);
	zoom = input(...ngDevMode ? [void 0, { debugName: "zoom" }] : /* istanbul ignore next */ []);
	minZoom = input(...ngDevMode ? [void 0, { debugName: "minZoom" }] : /* istanbul ignore next */ []);
	maxZoom = input(...ngDevMode ? [void 0, { debugName: "maxZoom" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	label = input(...ngDevMode ? [void 0, { debugName: "label" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	flowSelectionChanged = output();
	flowViewportChanged = output();
	flowLayoutCompleted = output();
	flowPositionsChanged = output();
	flowError = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			flowSelectionChanged: this.flowSelectionChanged,
			flowViewportChanged: this.flowViewportChanged,
			flowLayoutCompleted: this.flowLayoutCompleted,
			flowPositionsChanged: this.flowPositionsChanged,
			flowError: this.flowError,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(FLOW_DEFAULT_PROPS, { optional: true }) ?? {}, ["intl"]);
		const injectedIntl = inject(FLOW_INTL, { optional: true });
		if (injectedIntl) {
			Object.assign(this._elementRef.nativeElement.intl, injectedIntl);
			this._elementRef.nativeElement.intl.changes.emit();
		}
	}
	relayout(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "relayout", args);
	}
	applyLayout(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "applyLayout", args);
	}
	select(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "select", args);
	}
	clearSelection(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "clearSelection", args);
	}
	fitToView(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "fitToView", args);
	}
	zoomIn(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "zoomIn", args);
	}
	zoomOut(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "zoomOut", args);
	}
	setZoom(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "setZoom", args);
	}
	setViewport(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "setViewport", args);
	}
	panBy(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "panBy", args);
	}
	centerOn(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "centerOn", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const layoutValue = this.layout();
			if (layoutValue !== void 0) this._elementRef.nativeElement.layout = layoutValue;
			const layoutEngineValue = this.layoutEngine();
			if (layoutEngineValue !== void 0) this._elementRef.nativeElement.layoutEngine = layoutEngineValue;
			const layoutOptionsValue = this.layoutOptions();
			if (layoutOptionsValue !== void 0) this._elementRef.nativeElement.layoutOptions = layoutOptionsValue;
			const reflowEngineValue = this.reflowEngine();
			if (reflowEngineValue !== void 0) this._elementRef.nativeElement.reflowEngine = reflowEngineValue;
			const directionValue = this.direction();
			if (directionValue !== void 0) this._elementRef.nativeElement.direction = directionValue;
			const edgeRoutingValue = this.edgeRouting();
			if (edgeRoutingValue !== void 0) this._elementRef.nativeElement.edgeRouting = edgeRoutingValue;
			const edgeMarkerEndValue = this.edgeMarkerEnd();
			if (edgeMarkerEndValue !== void 0) this._elementRef.nativeElement.edgeMarkerEnd = edgeMarkerEndValue;
			const selectionModeValue = this.selectionMode();
			if (selectionModeValue !== void 0) this._elementRef.nativeElement.selectionMode = selectionModeValue;
			const selectedKeyValue = this.selectedKey();
			if (selectedKeyValue !== void 0) this._elementRef.nativeElement.selectedKey = selectedKeyValue;
			const highlightModeValue = this.highlightMode();
			if (highlightModeValue !== void 0) this._elementRef.nativeElement.highlightMode = highlightModeValue;
			const gridValue = this.grid();
			if (gridValue !== void 0) this._elementRef.nativeElement.grid = gridValue;
			const controlsPositionValue = this.controlsPosition();
			if (controlsPositionValue !== void 0) this._elementRef.nativeElement.controlsPosition = controlsPositionValue;
			const minimapPositionValue = this.minimapPosition();
			if (minimapPositionValue !== void 0) this._elementRef.nativeElement.minimapPosition = minimapPositionValue;
			const fitOnLoadValue = this.fitOnLoad();
			if (fitOnLoadValue !== void 0) this._elementRef.nativeElement.fitOnLoad = fitOnLoadValue;
			const fitPaddingValue = this.fitPadding();
			if (fitPaddingValue !== void 0) this._elementRef.nativeElement.fitPadding = fitPaddingValue;
			const fitMinZoomValue = this.fitMinZoom();
			if (fitMinZoomValue !== void 0) this._elementRef.nativeElement.fitMinZoom = fitMinZoomValue;
			const zoomValue = this.zoom();
			if (zoomValue !== void 0) this._elementRef.nativeElement.zoom = zoomValue;
			const minZoomValue = this.minZoom();
			if (minZoomValue !== void 0) this._elementRef.nativeElement.minZoom = minZoomValue;
			const maxZoomValue = this.maxZoom();
			if (maxZoomValue !== void 0) this._elementRef.nativeElement.maxZoom = maxZoomValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const labelValue = this.label();
			if (labelValue !== void 0) this._elementRef.nativeElement.label = labelValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
			const intlValue = this.intl();
			if (intlValue !== void 0) {
				Object.assign(this._elementRef.nativeElement.intl, intlValue);
				this._elementRef.nativeElement.intl.changes.emit();
			}
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FlowComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: FlowComponent,
		isStandalone: true,
		selector: "mosaik-flow",
		inputs: {
			intl: {
				classPropertyName: "intl",
				publicName: "intl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			layout: {
				classPropertyName: "layout",
				publicName: "layout",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			layoutEngine: {
				classPropertyName: "layoutEngine",
				publicName: "layoutEngine",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			layoutOptions: {
				classPropertyName: "layoutOptions",
				publicName: "layoutOptions",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			reflowEngine: {
				classPropertyName: "reflowEngine",
				publicName: "reflowEngine",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			direction: {
				classPropertyName: "direction",
				publicName: "direction",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			edgeRouting: {
				classPropertyName: "edgeRouting",
				publicName: "edgeRouting",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			edgeMarkerEnd: {
				classPropertyName: "edgeMarkerEnd",
				publicName: "edgeMarkerEnd",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			selectionMode: {
				classPropertyName: "selectionMode",
				publicName: "selectionMode",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			selectedKey: {
				classPropertyName: "selectedKey",
				publicName: "selectedKey",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			highlightMode: {
				classPropertyName: "highlightMode",
				publicName: "highlightMode",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			grid: {
				classPropertyName: "grid",
				publicName: "grid",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			controlsPosition: {
				classPropertyName: "controlsPosition",
				publicName: "controlsPosition",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			minimapPosition: {
				classPropertyName: "minimapPosition",
				publicName: "minimapPosition",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			fitOnLoad: {
				classPropertyName: "fitOnLoad",
				publicName: "fitOnLoad",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			fitPadding: {
				classPropertyName: "fitPadding",
				publicName: "fitPadding",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			fitMinZoom: {
				classPropertyName: "fitMinZoom",
				publicName: "fitMinZoom",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			zoom: {
				classPropertyName: "zoom",
				publicName: "zoom",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			minZoom: {
				classPropertyName: "minZoom",
				publicName: "minZoom",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			maxZoom: {
				classPropertyName: "maxZoom",
				publicName: "maxZoom",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			flowSelectionChanged: "flowSelectionChanged",
			flowViewportChanged: "flowViewportChanged",
			flowLayoutCompleted: "flowLayoutCompleted",
			flowPositionsChanged: "flowPositionsChanged",
			flowError: "flowError",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
FlowComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-flow", FlowElement),
	inputs: [
		"intl",
		"layout",
		"layoutEngine",
		"layoutOptions",
		"reflowEngine",
		"direction",
		"edgeRouting",
		"edgeMarkerEnd",
		"selectionMode",
		"selectedKey",
		"highlightMode",
		"grid",
		"controlsPosition",
		"minimapPosition",
		"fitOnLoad",
		"fitPadding",
		"fitMinZoom",
		"zoom",
		"minZoom",
		"maxZoom",
		"themeName",
		"label",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], FlowComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FlowComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-flow",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		intl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "intl",
				required: false
			}]
		}],
		layout: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "layout",
				required: false
			}]
		}],
		layoutEngine: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "layoutEngine",
				required: false
			}]
		}],
		layoutOptions: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "layoutOptions",
				required: false
			}]
		}],
		reflowEngine: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "reflowEngine",
				required: false
			}]
		}],
		direction: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "direction",
				required: false
			}]
		}],
		edgeRouting: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "edgeRouting",
				required: false
			}]
		}],
		edgeMarkerEnd: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "edgeMarkerEnd",
				required: false
			}]
		}],
		selectionMode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "selectionMode",
				required: false
			}]
		}],
		selectedKey: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "selectedKey",
				required: false
			}]
		}],
		highlightMode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "highlightMode",
				required: false
			}]
		}],
		grid: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "grid",
				required: false
			}]
		}],
		controlsPosition: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "controlsPosition",
				required: false
			}]
		}],
		minimapPosition: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "minimapPosition",
				required: false
			}]
		}],
		fitOnLoad: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "fitOnLoad",
				required: false
			}]
		}],
		fitPadding: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "fitPadding",
				required: false
			}]
		}],
		fitMinZoom: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "fitMinZoom",
				required: false
			}]
		}],
		zoom: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "zoom",
				required: false
			}]
		}],
		minZoom: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "minZoom",
				required: false
			}]
		}],
		maxZoom: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maxZoom",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		flowSelectionChanged: [{
			type: i0.Output,
			args: ["flowSelectionChanged"]
		}],
		flowViewportChanged: [{
			type: i0.Output,
			args: ["flowViewportChanged"]
		}],
		flowLayoutCompleted: [{
			type: i0.Output,
			args: ["flowLayoutCompleted"]
		}],
		flowPositionsChanged: [{
			type: i0.Output,
			args: ["flowPositionsChanged"]
		}],
		flowError: [{
			type: i0.Output,
			args: ["flowError"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideFlowComponent(config, intl) {
	const providers = [];
	if (config) providers.push({
		provide: FLOW_DEFAULT_PROPS,
		useValue: config
	});
	if (intl) {
		if (typeof intl === "function") providers.push({
			provide: FLOW_INTL,
			useClass: intl
		});
		else providers.push({
			provide: FLOW_INTL,
			useValue: intl
		});
	}
	return makeEnvironmentProviders(providers);
}
const FLOW_FEATURE_DEFAULTS = new InjectionToken("MOSAIK_FLOW_FEATURE_DEFAULTS");
function provideFlows(...features) {
	return makeEnvironmentProviders([...features.flatMap((feature) => feature.provide()), {
		provide: FLOW_DEFAULT_PROPS,
		useFactory: () => Object.assign({}, ...inject(FLOW_FEATURE_DEFAULTS, { optional: true }) ?? [])
	}]);
}
function withFlowDefaultBehavior(defaults) {
	return {
		id: "flowDefaultBehavior",
		provide: () => [{
			provide: FLOW_FEATURE_DEFAULTS,
			multi: true,
			useFactory: () => ({ ...defaults })
		}]
	};
}
function withFlowLayoutBehavior(createEngine, config = {}) {
	return {
		id: "flowLayoutBehavior",
		provide: () => [{
			provide: FLOW_FEATURE_DEFAULTS,
			multi: true,
			useFactory: () => ({
				layoutEngine: createEngine(),
				layout: config.mode ?? "auto",
				layoutOptions: { ...config.options }
			})
		}]
	};
}
function withFlowReflowOnResize(createEngine) {
	return {
		id: "flowReflowOnResize",
		provide: () => [{
			provide: FLOW_FEATURE_DEFAULTS,
			multi: true,
			useFactory: () => ({ reflowEngine: createEngine() })
		}]
	};
}
export { FLOW_CONTROLS_DEFAULT_PROPS, FLOW_DEFAULT_PROPS, FLOW_EDGE_DEFAULT_PROPS, FLOW_INTL, FLOW_MINIMAP_DEFAULT_PROPS, FLOW_NODE_DEFAULT_PROPS, FlowComponent, FlowControlsComponent, FlowEdgeComponent, FlowMinimapComponent, FlowNodeComponent, provideFlowComponent, provideFlowControlsComponent, provideFlowEdgeComponent, provideFlowMinimapComponent, provideFlowNodeComponent, provideFlows, withFlowDefaultBehavior, withFlowLayoutBehavior, withFlowReflowOnResize };

//# sourceMappingURL=mosaik-elements-angular-components-flow.mjs.map