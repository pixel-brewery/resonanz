import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { CameraElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/camera/CameraElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const CAMERA_DEFAULT_PROPS = new InjectionToken("MOSAIK_CAMERA_DEFAULT_PROPS");
let CameraComponent = class CameraComponent {
	src = input(...ngDevMode ? [void 0, { debugName: "src" }] : /* istanbul ignore next */ []);
	autoPlay = input(...ngDevMode ? [void 0, { debugName: "autoPlay" }] : /* istanbul ignore next */ []);
	poster = input(...ngDevMode ? [void 0, { debugName: "poster" }] : /* istanbul ignore next */ []);
	autoFullScreen = input(...ngDevMode ? [void 0, { debugName: "autoFullScreen" }] : /* istanbul ignore next */ []);
	type = input(...ngDevMode ? [void 0, { debugName: "type" }] : /* istanbul ignore next */ []);
	recorderFormat = input(...ngDevMode ? [void 0, { debugName: "recorderFormat" }] : /* istanbul ignore next */ []);
	captureFormat = input(...ngDevMode ? [void 0, { debugName: "captureFormat" }] : /* istanbul ignore next */ []);
	frame = input(...ngDevMode ? [void 0, { debugName: "frame" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	width = input(...ngDevMode ? [void 0, { debugName: "width" }] : /* istanbul ignore next */ []);
	height = input(...ngDevMode ? [void 0, { debugName: "height" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	captured = output();
	recorded = output();
	error = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			captured: this.captured,
			recorded: this.recorded,
			error: this.error,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(CAMERA_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	record(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "record", args);
	}
	capture(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "capture", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const srcValue = this.src();
			if (srcValue !== void 0) this._elementRef.nativeElement.src = srcValue;
			const autoPlayValue = this.autoPlay();
			if (autoPlayValue !== void 0) this._elementRef.nativeElement.autoPlay = autoPlayValue;
			const posterValue = this.poster();
			if (posterValue !== void 0) this._elementRef.nativeElement.poster = posterValue;
			const autoFullScreenValue = this.autoFullScreen();
			if (autoFullScreenValue !== void 0) this._elementRef.nativeElement.autoFullScreen = autoFullScreenValue;
			const typeValue = this.type();
			if (typeValue !== void 0) this._elementRef.nativeElement.type = typeValue;
			const recorderFormatValue = this.recorderFormat();
			if (recorderFormatValue !== void 0) this._elementRef.nativeElement.recorderFormat = recorderFormatValue;
			const captureFormatValue = this.captureFormat();
			if (captureFormatValue !== void 0) this._elementRef.nativeElement.captureFormat = captureFormatValue;
			const frameValue = this.frame();
			if (frameValue !== void 0) this._elementRef.nativeElement.frame = frameValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const widthValue = this.width();
			if (widthValue !== void 0) this._elementRef.nativeElement.width = widthValue;
			const heightValue = this.height();
			if (heightValue !== void 0) this._elementRef.nativeElement.height = heightValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: CameraComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: CameraComponent,
		isStandalone: true,
		selector: "mosaik-camera",
		inputs: {
			src: {
				classPropertyName: "src",
				publicName: "src",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			autoPlay: {
				classPropertyName: "autoPlay",
				publicName: "autoPlay",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			poster: {
				classPropertyName: "poster",
				publicName: "poster",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			autoFullScreen: {
				classPropertyName: "autoFullScreen",
				publicName: "autoFullScreen",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			type: {
				classPropertyName: "type",
				publicName: "type",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			recorderFormat: {
				classPropertyName: "recorderFormat",
				publicName: "recorderFormat",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			captureFormat: {
				classPropertyName: "captureFormat",
				publicName: "captureFormat",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			frame: {
				classPropertyName: "frame",
				publicName: "frame",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			width: {
				classPropertyName: "width",
				publicName: "width",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			height: {
				classPropertyName: "height",
				publicName: "height",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			captured: "captured",
			recorded: "recorded",
			error: "error",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
CameraComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-camera", CameraElement),
	inputs: [
		"src",
		"autoPlay",
		"poster",
		"autoFullScreen",
		"type",
		"recorderFormat",
		"captureFormat",
		"frame",
		"themeName",
		"disabled",
		"width",
		"height",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], CameraComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: CameraComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-camera",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		src: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "src",
				required: false
			}]
		}],
		autoPlay: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "autoPlay",
				required: false
			}]
		}],
		poster: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "poster",
				required: false
			}]
		}],
		autoFullScreen: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "autoFullScreen",
				required: false
			}]
		}],
		type: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "type",
				required: false
			}]
		}],
		recorderFormat: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "recorderFormat",
				required: false
			}]
		}],
		captureFormat: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "captureFormat",
				required: false
			}]
		}],
		frame: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "frame",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		width: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "width",
				required: false
			}]
		}],
		height: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "height",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		captured: [{
			type: i0.Output,
			args: ["captured"]
		}],
		recorded: [{
			type: i0.Output,
			args: ["recorded"]
		}],
		error: [{
			type: i0.Output,
			args: ["error"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideCameraComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: CAMERA_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { CAMERA_DEFAULT_PROPS, CameraComponent, provideCameraComponent };

//# sourceMappingURL=mosaik-elements-angular-components-camera.mjs.map