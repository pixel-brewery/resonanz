import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, forwardRef, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { AttachmentChatToolElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/chat/tools/AttachmentChatToolElement";
import * as i1 from "@pixel-brewery/mosaik-elements-angular/runtime";
import { FORM_STATUS_HOST, FormFieldStatusHostDirective, FormStatusHostDirective, ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { ChatHeaderElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/chat/ChatHeaderElement";
import { ChatMarkerElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/chat/ChatMarkerElement";
import { ChatMessageAvatarElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/chat/ChatMessageAvatarElement";
import { ChatMessageDividerElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/chat/ChatMessageDividerElement";
import { ChatMessageReactionElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/chat/ChatMessageReactionElement";
import { ChatMessageElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/chat/ChatMessageElement";
import { ChatPromptBoxAttachmentListElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/chat/ChatPromptBoxAttachmentListElement";
import { ChatPromptBoxQueueElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/chat/ChatPromptBoxQueueElement";
import { NG_VALUE_ACCESSOR } from "@angular/forms";
import { ChatPromptBoxElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/chat/ChatPromptBoxElement";
import { chatPromptBoxElementValueAccessor } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/chat/accessors/ChatPromptBoxElementValueAccessor";
import { ChatElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/chat/ChatElement";
import { MentionTextElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/chat/MentionTextElement";
import { MentionElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/chat/MentionElement";
import { ReactionChatToolElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/chat/tools/ReactionChatToolElement";
import { VoiceRecorderChatToolElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/chat/tools/VoiceRecorderChatToolElement";
var __decorate$14 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$14 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const ATTACHMENT_CHAT_TOOL_DEFAULT_PROPS = new InjectionToken("MOSAIK_ATTACHMENT_CHAT_TOOL_DEFAULT_PROPS");
const ATTACHMENT_CHAT_TOOL_INTL = new InjectionToken("MOSAIK_ATTACHMENT_CHAT_TOOL_INTL");
let AttachmentChatToolComponent = class AttachmentChatToolComponent {
	multiple = input(...ngDevMode ? [void 0, { debugName: "multiple" }] : /* istanbul ignore next */ []);
	accept = input(...ngDevMode ? [void 0, { debugName: "accept" }] : /* istanbul ignore next */ []);
	directory = input(...ngDevMode ? [void 0, { debugName: "directory" }] : /* istanbul ignore next */ []);
	intl = input(...ngDevMode ? [void 0, { debugName: "intl" }] : /* istanbul ignore next */ []);
	maxFiles = input(...ngDevMode ? [void 0, { debugName: "maxFiles" }] : /* istanbul ignore next */ []);
	maxFileSize = input(...ngDevMode ? [void 0, { debugName: "maxFileSize" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dock = input(...ngDevMode ? [void 0, { debugName: "dock" }] : /* istanbul ignore next */ []);
	disabledWhen = input(...ngDevMode ? [void 0, { debugName: "disabledWhen" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	attachmentReject = output();
	filesPicked = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			attachmentReject: this.attachmentReject,
			filesPicked: this.filesPicked,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(ATTACHMENT_CHAT_TOOL_DEFAULT_PROPS, { optional: true }) ?? {}, ["intl"]);
		const injectedIntl = inject(ATTACHMENT_CHAT_TOOL_INTL, { optional: true });
		if (injectedIntl) {
			Object.assign(this._elementRef.nativeElement.intl, injectedIntl);
			this._elementRef.nativeElement.intl.changes.emit();
		}
	}
	execute(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "execute", args);
	}
	attach(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "attach", args);
	}
	detach(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "detach", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const multipleValue = this.multiple();
			if (multipleValue !== void 0) this._elementRef.nativeElement.multiple = multipleValue;
			const acceptValue = this.accept();
			if (acceptValue !== void 0) this._elementRef.nativeElement.accept = acceptValue;
			const directoryValue = this.directory();
			if (directoryValue !== void 0) this._elementRef.nativeElement.directory = directoryValue;
			const maxFilesValue = this.maxFiles();
			if (maxFilesValue !== void 0) this._elementRef.nativeElement.maxFiles = maxFilesValue;
			const maxFileSizeValue = this.maxFileSize();
			if (maxFileSizeValue !== void 0) this._elementRef.nativeElement.maxFileSize = maxFileSizeValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dockValue = this.dock();
			if (dockValue !== void 0) this._elementRef.nativeElement.dock = dockValue;
			const disabledWhenValue = this.disabledWhen();
			if (disabledWhenValue !== void 0) this._elementRef.nativeElement.disabledWhen = disabledWhenValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
			const intlValue = this.intl();
			if (intlValue !== void 0) {
				Object.assign(this._elementRef.nativeElement.intl, intlValue);
				this._elementRef.nativeElement.intl.changes.emit();
			}
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: AttachmentChatToolComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: AttachmentChatToolComponent,
		isStandalone: true,
		selector: "mosaik-attachment-chat-tool",
		inputs: {
			multiple: {
				classPropertyName: "multiple",
				publicName: "multiple",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			accept: {
				classPropertyName: "accept",
				publicName: "accept",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			directory: {
				classPropertyName: "directory",
				publicName: "directory",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			intl: {
				classPropertyName: "intl",
				publicName: "intl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			maxFiles: {
				classPropertyName: "maxFiles",
				publicName: "maxFiles",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			maxFileSize: {
				classPropertyName: "maxFileSize",
				publicName: "maxFileSize",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dock: {
				classPropertyName: "dock",
				publicName: "dock",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabledWhen: {
				classPropertyName: "disabledWhen",
				publicName: "disabledWhen",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			attachmentReject: "attachmentReject",
			filesPicked: "filesPicked",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
AttachmentChatToolComponent = __decorate$14([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-attachment-chat-tool", AttachmentChatToolElement),
	inputs: [
		"multiple",
		"accept",
		"directory",
		"intl",
		"maxFiles",
		"maxFileSize",
		"themeName",
		"dock",
		"disabledWhen",
		"disabled",
		"dir",
		"lang"
	]
}), __metadata$14("design:paramtypes", [])], AttachmentChatToolComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: AttachmentChatToolComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-attachment-chat-tool",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		multiple: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "multiple",
				required: false
			}]
		}],
		accept: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "accept",
				required: false
			}]
		}],
		directory: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "directory",
				required: false
			}]
		}],
		intl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "intl",
				required: false
			}]
		}],
		maxFiles: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maxFiles",
				required: false
			}]
		}],
		maxFileSize: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maxFileSize",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dock: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dock",
				required: false
			}]
		}],
		disabledWhen: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabledWhen",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		attachmentReject: [{
			type: i0.Output,
			args: ["attachmentReject"]
		}],
		filesPicked: [{
			type: i0.Output,
			args: ["filesPicked"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideAttachmentChatToolComponent(config, intl) {
	const providers = [];
	if (config) providers.push({
		provide: ATTACHMENT_CHAT_TOOL_DEFAULT_PROPS,
		useValue: config
	});
	if (intl) {
		if (typeof intl === "function") providers.push({
			provide: ATTACHMENT_CHAT_TOOL_INTL,
			useClass: intl
		});
		else providers.push({
			provide: ATTACHMENT_CHAT_TOOL_INTL,
			useValue: intl
		});
	}
	return makeEnvironmentProviders(providers);
}
var __decorate$13 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$13 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const CHAT_HEADER_DEFAULT_PROPS = new InjectionToken("MOSAIK_CHAT_HEADER_DEFAULT_PROPS");
let ChatHeaderComponent = class ChatHeaderComponent {
	title = input(...ngDevMode ? [void 0, { debugName: "title" }] : /* istanbul ignore next */ []);
	subTitle = input(...ngDevMode ? [void 0, { debugName: "subTitle" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	formatter = input(...ngDevMode ? [void 0, { debugName: "formatter" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(CHAT_HEADER_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const titleValue = this.title();
			if (titleValue !== void 0) this._elementRef.nativeElement.title = titleValue;
			const subTitleValue = this.subTitle();
			if (subTitleValue !== void 0) this._elementRef.nativeElement.subTitle = subTitleValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const formatterValue = this.formatter();
			if (formatterValue !== void 0) this._elementRef.nativeElement.formatter = formatterValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ChatHeaderComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: ChatHeaderComponent,
		isStandalone: true,
		selector: "mosaik-chat-header",
		inputs: {
			title: {
				classPropertyName: "title",
				publicName: "title",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			subTitle: {
				classPropertyName: "subTitle",
				publicName: "subTitle",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			formatter: {
				classPropertyName: "formatter",
				publicName: "formatter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
ChatHeaderComponent = __decorate$13([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-chat-header", ChatHeaderElement),
	inputs: [
		"title",
		"subTitle",
		"themeName",
		"formatter",
		"dir",
		"lang"
	]
}), __metadata$13("design:paramtypes", [])], ChatHeaderComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ChatHeaderComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-chat-header",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		title: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "title",
				required: false
			}]
		}],
		subTitle: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "subTitle",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		formatter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "formatter",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideChatHeaderComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: CHAT_HEADER_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$12 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$12 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const CHAT_MARKER_DEFAULT_PROPS = new InjectionToken("MOSAIK_CHAT_MARKER_DEFAULT_PROPS");
let ChatMarkerComponent = class ChatMarkerComponent {
	text = input(...ngDevMode ? [void 0, { debugName: "text" }] : /* istanbul ignore next */ []);
	icon = input(...ngDevMode ? [void 0, { debugName: "icon" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	orientation = input(...ngDevMode ? [void 0, { debugName: "orientation" }] : /* istanbul ignore next */ []);
	horizontalContentAlignment = input(...ngDevMode ? [void 0, { debugName: "horizontalContentAlignment" }] : /* istanbul ignore next */ []);
	verticalContentAlignment = input(...ngDevMode ? [void 0, { debugName: "verticalContentAlignment" }] : /* istanbul ignore next */ []);
	isSticky = input(...ngDevMode ? [void 0, { debugName: "isSticky" }] : /* istanbul ignore next */ []);
	formatter = input(...ngDevMode ? [void 0, { debugName: "formatter" }] : /* istanbul ignore next */ []);
	appearance = input(...ngDevMode ? [void 0, { debugName: "appearance" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(CHAT_MARKER_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const textValue = this.text();
			if (textValue !== void 0) this._elementRef.nativeElement.text = textValue;
			const iconValue = this.icon();
			if (iconValue !== void 0) this._elementRef.nativeElement.icon = iconValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const orientationValue = this.orientation();
			if (orientationValue !== void 0) this._elementRef.nativeElement.orientation = orientationValue;
			const horizontalContentAlignmentValue = this.horizontalContentAlignment();
			if (horizontalContentAlignmentValue !== void 0) this._elementRef.nativeElement.horizontalContentAlignment = horizontalContentAlignmentValue;
			const verticalContentAlignmentValue = this.verticalContentAlignment();
			if (verticalContentAlignmentValue !== void 0) this._elementRef.nativeElement.verticalContentAlignment = verticalContentAlignmentValue;
			const isStickyValue = this.isSticky();
			if (isStickyValue !== void 0) this._elementRef.nativeElement.isSticky = isStickyValue;
			const formatterValue = this.formatter();
			if (formatterValue !== void 0) this._elementRef.nativeElement.formatter = formatterValue;
			const appearanceValue = this.appearance();
			if (appearanceValue !== void 0) this._elementRef.nativeElement.appearance = appearanceValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ChatMarkerComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: ChatMarkerComponent,
		isStandalone: true,
		selector: "mosaik-chat-marker",
		inputs: {
			text: {
				classPropertyName: "text",
				publicName: "text",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			icon: {
				classPropertyName: "icon",
				publicName: "icon",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			orientation: {
				classPropertyName: "orientation",
				publicName: "orientation",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			horizontalContentAlignment: {
				classPropertyName: "horizontalContentAlignment",
				publicName: "horizontalContentAlignment",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			verticalContentAlignment: {
				classPropertyName: "verticalContentAlignment",
				publicName: "verticalContentAlignment",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isSticky: {
				classPropertyName: "isSticky",
				publicName: "isSticky",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			formatter: {
				classPropertyName: "formatter",
				publicName: "formatter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
ChatMarkerComponent = __decorate$12([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-chat-marker", ChatMarkerElement),
	inputs: [
		"text",
		"icon",
		"themeName",
		"variant",
		"orientation",
		"horizontalContentAlignment",
		"verticalContentAlignment",
		"isSticky",
		"formatter",
		"appearance",
		"dir",
		"lang"
	]
}), __metadata$12("design:paramtypes", [])], ChatMarkerComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ChatMarkerComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-chat-marker",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		text: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "text",
				required: false
			}]
		}],
		icon: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "icon",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		orientation: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "orientation",
				required: false
			}]
		}],
		horizontalContentAlignment: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "horizontalContentAlignment",
				required: false
			}]
		}],
		verticalContentAlignment: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "verticalContentAlignment",
				required: false
			}]
		}],
		isSticky: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isSticky",
				required: false
			}]
		}],
		formatter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "formatter",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideChatMarkerComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: CHAT_MARKER_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$11 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$11 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const CHAT_MESSAGE_AVATAR_DEFAULT_PROPS = new InjectionToken("MOSAIK_CHAT_MESSAGE_AVATAR_DEFAULT_PROPS");
let ChatMessageAvatarComponent = class ChatMessageAvatarComponent {
	text = input(...ngDevMode ? [void 0, { debugName: "text" }] : /* istanbul ignore next */ []);
	icon = input(...ngDevMode ? [void 0, { debugName: "icon" }] : /* istanbul ignore next */ []);
	src = input(...ngDevMode ? [void 0, { debugName: "src" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	appearance = input(...ngDevMode ? [void 0, { debugName: "appearance" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(CHAT_MESSAGE_AVATAR_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const textValue = this.text();
			if (textValue !== void 0) this._elementRef.nativeElement.text = textValue;
			const iconValue = this.icon();
			if (iconValue !== void 0) this._elementRef.nativeElement.icon = iconValue;
			const srcValue = this.src();
			if (srcValue !== void 0) this._elementRef.nativeElement.src = srcValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const appearanceValue = this.appearance();
			if (appearanceValue !== void 0) this._elementRef.nativeElement.appearance = appearanceValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ChatMessageAvatarComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: ChatMessageAvatarComponent,
		isStandalone: true,
		selector: "mosaik-chat-message-avatar",
		inputs: {
			text: {
				classPropertyName: "text",
				publicName: "text",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			icon: {
				classPropertyName: "icon",
				publicName: "icon",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			src: {
				classPropertyName: "src",
				publicName: "src",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
ChatMessageAvatarComponent = __decorate$11([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-chat-message-avatar", ChatMessageAvatarElement),
	inputs: [
		"text",
		"icon",
		"src",
		"themeName",
		"appearance",
		"variant",
		"disabled",
		"dir",
		"lang"
	]
}), __metadata$11("design:paramtypes", [])], ChatMessageAvatarComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ChatMessageAvatarComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-chat-message-avatar",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		text: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "text",
				required: false
			}]
		}],
		icon: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "icon",
				required: false
			}]
		}],
		src: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "src",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideChatMessageAvatarComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: CHAT_MESSAGE_AVATAR_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$10 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$10 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const CHAT_MESSAGE_DIVIDER_DEFAULT_PROPS = new InjectionToken("MOSAIK_CHAT_MESSAGE_DIVIDER_DEFAULT_PROPS");
let ChatMessageDividerComponent = class ChatMessageDividerComponent {
	text = input(...ngDevMode ? [void 0, { debugName: "text" }] : /* istanbul ignore next */ []);
	thickness = input(...ngDevMode ? [void 0, { debugName: "thickness" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	isSticky = input(...ngDevMode ? [void 0, { debugName: "isSticky" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(CHAT_MESSAGE_DIVIDER_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const textValue = this.text();
			if (textValue !== void 0) this._elementRef.nativeElement.text = textValue;
			const thicknessValue = this.thickness();
			if (thicknessValue !== void 0) this._elementRef.nativeElement.thickness = thicknessValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const isStickyValue = this.isSticky();
			if (isStickyValue !== void 0) this._elementRef.nativeElement.isSticky = isStickyValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ChatMessageDividerComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: ChatMessageDividerComponent,
		isStandalone: true,
		selector: "mosaik-chat-message-divider",
		inputs: {
			text: {
				classPropertyName: "text",
				publicName: "text",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			thickness: {
				classPropertyName: "thickness",
				publicName: "thickness",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isSticky: {
				classPropertyName: "isSticky",
				publicName: "isSticky",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
ChatMessageDividerComponent = __decorate$10([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-chat-message-divider", ChatMessageDividerElement),
	inputs: [
		"text",
		"thickness",
		"themeName",
		"isSticky",
		"dir",
		"lang"
	]
}), __metadata$10("design:paramtypes", [])], ChatMessageDividerComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ChatMessageDividerComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-chat-message-divider",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		text: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "text",
				required: false
			}]
		}],
		thickness: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "thickness",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		isSticky: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isSticky",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideChatMessageDividerComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: CHAT_MESSAGE_DIVIDER_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$9 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$9 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const CHAT_MESSAGE_REACTION_DEFAULT_PROPS = new InjectionToken("MOSAIK_CHAT_MESSAGE_REACTION_DEFAULT_PROPS");
let ChatMessageReactionComponent = class ChatMessageReactionComponent {
	emoji = input(...ngDevMode ? [void 0, { debugName: "emoji" }] : /* istanbul ignore next */ []);
	count = input(...ngDevMode ? [void 0, { debugName: "count" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(CHAT_MESSAGE_REACTION_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const emojiValue = this.emoji();
			if (emojiValue !== void 0) this._elementRef.nativeElement.emoji = emojiValue;
			const countValue = this.count();
			if (countValue !== void 0) this._elementRef.nativeElement.count = countValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ChatMessageReactionComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: ChatMessageReactionComponent,
		isStandalone: true,
		selector: "mosaik-chat-message-reaction",
		inputs: {
			emoji: {
				classPropertyName: "emoji",
				publicName: "emoji",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			count: {
				classPropertyName: "count",
				publicName: "count",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
ChatMessageReactionComponent = __decorate$9([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-chat-message-reaction", ChatMessageReactionElement),
	inputs: [
		"emoji",
		"count",
		"themeName",
		"disabled",
		"dir",
		"lang"
	]
}), __metadata$9("design:paramtypes", [])], ChatMessageReactionComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ChatMessageReactionComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-chat-message-reaction",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		emoji: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "emoji",
				required: false
			}]
		}],
		count: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "count",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideChatMessageReactionComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: CHAT_MESSAGE_REACTION_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$8 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$8 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const CHAT_MESSAGE_DEFAULT_PROPS = new InjectionToken("MOSAIK_CHAT_MESSAGE_DEFAULT_PROPS");
let ChatMessageComponent = class ChatMessageComponent {
	attachments = input(...ngDevMode ? [void 0, { debugName: "attachments" }] : /* istanbul ignore next */ []);
	author = input(...ngDevMode ? [void 0, { debugName: "author" }] : /* istanbul ignore next */ []);
	text = input(...ngDevMode ? [void 0, { debugName: "text" }] : /* istanbul ignore next */ []);
	at = input(...ngDevMode ? [void 0, { debugName: "at" }] : /* istanbul ignore next */ []);
	reply = input(...ngDevMode ? [void 0, { debugName: "reply" }] : /* istanbul ignore next */ []);
	mentions = input(...ngDevMode ? [void 0, { debugName: "mentions" }] : /* istanbul ignore next */ []);
	mentionCardProvider = input(...ngDevMode ? [void 0, { debugName: "mentionCardProvider" }] : /* istanbul ignore next */ []);
	isMentionInteractive = input(...ngDevMode ? [void 0, { debugName: "isMentionInteractive" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	appearance = input(...ngDevMode ? [void 0, { debugName: "appearance" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	formatter = input(...ngDevMode ? [void 0, { debugName: "formatter" }] : /* istanbul ignore next */ []);
	isBusy = input(...ngDevMode ? [void 0, { debugName: "isBusy" }] : /* istanbul ignore next */ []);
	value = input(...ngDevMode ? [void 0, { debugName: "value" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	mentionInvoked = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			mentionInvoked: this.mentionInvoked,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(CHAT_MESSAGE_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	assignToSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "assignToSlot", args);
	}
	getSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getSlotContent", args);
	}
	hasSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlotContent", args);
	}
	hasSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlot", args);
	}
	onSlotChanges(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onSlotChanges", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const attachmentsValue = this.attachments();
			if (attachmentsValue !== void 0) this._elementRef.nativeElement.attachments = attachmentsValue;
			const authorValue = this.author();
			if (authorValue !== void 0) this._elementRef.nativeElement.author = authorValue;
			const textValue = this.text();
			if (textValue !== void 0) this._elementRef.nativeElement.text = textValue;
			const atValue = this.at();
			if (atValue !== void 0) this._elementRef.nativeElement.at = atValue;
			const replyValue = this.reply();
			if (replyValue !== void 0) this._elementRef.nativeElement.reply = replyValue;
			const mentionsValue = this.mentions();
			if (mentionsValue !== void 0) this._elementRef.nativeElement.mentions = mentionsValue;
			const mentionCardProviderValue = this.mentionCardProvider();
			if (mentionCardProviderValue !== void 0) this._elementRef.nativeElement.mentionCardProvider = mentionCardProviderValue;
			const isMentionInteractiveValue = this.isMentionInteractive();
			if (isMentionInteractiveValue !== void 0) this._elementRef.nativeElement.isMentionInteractive = isMentionInteractiveValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const appearanceValue = this.appearance();
			if (appearanceValue !== void 0) this._elementRef.nativeElement.appearance = appearanceValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const formatterValue = this.formatter();
			if (formatterValue !== void 0) this._elementRef.nativeElement.formatter = formatterValue;
			const isBusyValue = this.isBusy();
			if (isBusyValue !== void 0) this._elementRef.nativeElement.isBusy = isBusyValue;
			const valueValue = this.value();
			if (valueValue !== void 0) this._elementRef.nativeElement.value = valueValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ChatMessageComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: ChatMessageComponent,
		isStandalone: true,
		selector: "mosaik-chat-message",
		inputs: {
			attachments: {
				classPropertyName: "attachments",
				publicName: "attachments",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			author: {
				classPropertyName: "author",
				publicName: "author",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			text: {
				classPropertyName: "text",
				publicName: "text",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			at: {
				classPropertyName: "at",
				publicName: "at",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			reply: {
				classPropertyName: "reply",
				publicName: "reply",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			mentions: {
				classPropertyName: "mentions",
				publicName: "mentions",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			mentionCardProvider: {
				classPropertyName: "mentionCardProvider",
				publicName: "mentionCardProvider",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isMentionInteractive: {
				classPropertyName: "isMentionInteractive",
				publicName: "isMentionInteractive",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			formatter: {
				classPropertyName: "formatter",
				publicName: "formatter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isBusy: {
				classPropertyName: "isBusy",
				publicName: "isBusy",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			mentionInvoked: "mentionInvoked",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
ChatMessageComponent = __decorate$8([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-chat-message", ChatMessageElement),
	inputs: [
		"attachments",
		"author",
		"text",
		"at",
		"reply",
		"mentions",
		"mentionCardProvider",
		"isMentionInteractive",
		"themeName",
		"variant",
		"appearance",
		"disabled",
		"formatter",
		"isBusy",
		"value",
		"dir",
		"lang"
	],
	methods: ["getSlotAssignments", "getSlotAssignmentsOf"]
}), __metadata$8("design:paramtypes", [])], ChatMessageComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ChatMessageComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-chat-message",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		attachments: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "attachments",
				required: false
			}]
		}],
		author: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "author",
				required: false
			}]
		}],
		text: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "text",
				required: false
			}]
		}],
		at: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "at",
				required: false
			}]
		}],
		reply: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "reply",
				required: false
			}]
		}],
		mentions: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mentions",
				required: false
			}]
		}],
		mentionCardProvider: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mentionCardProvider",
				required: false
			}]
		}],
		isMentionInteractive: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isMentionInteractive",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		formatter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "formatter",
				required: false
			}]
		}],
		isBusy: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isBusy",
				required: false
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		mentionInvoked: [{
			type: i0.Output,
			args: ["mentionInvoked"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideChatMessageComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: CHAT_MESSAGE_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$7 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$7 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const CHAT_PROMPT_BOX_ATTACHMENT_LIST_DEFAULT_PROPS = new InjectionToken("MOSAIK_CHAT_PROMPT_BOX_ATTACHMENT_LIST_DEFAULT_PROPS");
let ChatPromptBoxAttachmentListComponent = class ChatPromptBoxAttachmentListComponent {
	entries = input(...ngDevMode ? [void 0, { debugName: "entries" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	appearance = input(...ngDevMode ? [void 0, { debugName: "appearance" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	attachmentRemove = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			attachmentRemove: this.attachmentRemove,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(CHAT_PROMPT_BOX_ATTACHMENT_LIST_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	assignToSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "assignToSlot", args);
	}
	getSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getSlotContent", args);
	}
	hasSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlotContent", args);
	}
	hasSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlot", args);
	}
	onSlotChanges(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onSlotChanges", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const entriesValue = this.entries();
			if (entriesValue !== void 0) this._elementRef.nativeElement.entries = entriesValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const appearanceValue = this.appearance();
			if (appearanceValue !== void 0) this._elementRef.nativeElement.appearance = appearanceValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ChatPromptBoxAttachmentListComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: ChatPromptBoxAttachmentListComponent,
		isStandalone: true,
		selector: "mosaik-chat-prompt-box-attachment-list",
		inputs: {
			entries: {
				classPropertyName: "entries",
				publicName: "entries",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			attachmentRemove: "attachmentRemove",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
ChatPromptBoxAttachmentListComponent = __decorate$7([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-chat-prompt-box-attachment-list", ChatPromptBoxAttachmentListElement),
	inputs: [
		"entries",
		"themeName",
		"variant",
		"appearance",
		"disabled",
		"dir",
		"lang"
	],
	methods: ["getSlotAssignments", "getSlotAssignmentsOf"]
}), __metadata$7("design:paramtypes", [])], ChatPromptBoxAttachmentListComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ChatPromptBoxAttachmentListComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-chat-prompt-box-attachment-list",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		entries: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "entries",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		attachmentRemove: [{
			type: i0.Output,
			args: ["attachmentRemove"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideChatPromptBoxAttachmentListComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: CHAT_PROMPT_BOX_ATTACHMENT_LIST_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$6 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$6 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const CHAT_PROMPT_BOX_QUEUE_DEFAULT_PROPS = new InjectionToken("MOSAIK_CHAT_PROMPT_BOX_QUEUE_DEFAULT_PROPS");
const CHAT_PROMPT_BOX_QUEUE_INTL = new InjectionToken("MOSAIK_CHAT_PROMPT_BOX_QUEUE_INTL");
let ChatPromptBoxQueueComponent = class ChatPromptBoxQueueComponent {
	intl = input(...ngDevMode ? [void 0, { debugName: "intl" }] : /* istanbul ignore next */ []);
	entries = input(...ngDevMode ? [void 0, { debugName: "entries" }] : /* istanbul ignore next */ []);
	reorderable = input(...ngDevMode ? [void 0, { debugName: "reorderable" }] : /* istanbul ignore next */ []);
	steerable = input(...ngDevMode ? [void 0, { debugName: "steerable" }] : /* istanbul ignore next */ []);
	editable = input(...ngDevMode ? [void 0, { debugName: "editable" }] : /* istanbul ignore next */ []);
	pausable = input(...ngDevMode ? [void 0, { debugName: "pausable" }] : /* istanbul ignore next */ []);
	actions = input(...ngDevMode ? [void 0, { debugName: "actions" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	appearance = input(...ngDevMode ? [void 0, { debugName: "appearance" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(CHAT_PROMPT_BOX_QUEUE_DEFAULT_PROPS, { optional: true }) ?? {}, ["intl"]);
		const injectedIntl = inject(CHAT_PROMPT_BOX_QUEUE_INTL, { optional: true });
		if (injectedIntl) {
			Object.assign(this._elementRef.nativeElement.intl, injectedIntl);
			this._elementRef.nativeElement.intl.changes.emit();
		}
	}
	assignToSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "assignToSlot", args);
	}
	getSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getSlotContent", args);
	}
	hasSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlotContent", args);
	}
	hasSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlot", args);
	}
	onSlotChanges(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onSlotChanges", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const entriesValue = this.entries();
			if (entriesValue !== void 0) this._elementRef.nativeElement.entries = entriesValue;
			const reorderableValue = this.reorderable();
			if (reorderableValue !== void 0) this._elementRef.nativeElement.reorderable = reorderableValue;
			const steerableValue = this.steerable();
			if (steerableValue !== void 0) this._elementRef.nativeElement.steerable = steerableValue;
			const editableValue = this.editable();
			if (editableValue !== void 0) this._elementRef.nativeElement.editable = editableValue;
			const pausableValue = this.pausable();
			if (pausableValue !== void 0) this._elementRef.nativeElement.pausable = pausableValue;
			const actionsValue = this.actions();
			if (actionsValue !== void 0) this._elementRef.nativeElement.actions = actionsValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const appearanceValue = this.appearance();
			if (appearanceValue !== void 0) this._elementRef.nativeElement.appearance = appearanceValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
			const intlValue = this.intl();
			if (intlValue !== void 0) {
				Object.assign(this._elementRef.nativeElement.intl, intlValue);
				this._elementRef.nativeElement.intl.changes.emit();
			}
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ChatPromptBoxQueueComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: ChatPromptBoxQueueComponent,
		isStandalone: true,
		selector: "mosaik-chat-prompt-box-queue",
		inputs: {
			intl: {
				classPropertyName: "intl",
				publicName: "intl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			entries: {
				classPropertyName: "entries",
				publicName: "entries",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			reorderable: {
				classPropertyName: "reorderable",
				publicName: "reorderable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			steerable: {
				classPropertyName: "steerable",
				publicName: "steerable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			editable: {
				classPropertyName: "editable",
				publicName: "editable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			pausable: {
				classPropertyName: "pausable",
				publicName: "pausable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			actions: {
				classPropertyName: "actions",
				publicName: "actions",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
ChatPromptBoxQueueComponent = __decorate$6([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-chat-prompt-box-queue", ChatPromptBoxQueueElement),
	inputs: [
		"intl",
		"entries",
		"reorderable",
		"steerable",
		"editable",
		"pausable",
		"actions",
		"themeName",
		"variant",
		"appearance",
		"disabled",
		"dir",
		"lang"
	],
	methods: ["getSlotAssignments", "getSlotAssignmentsOf"]
}), __metadata$6("design:paramtypes", [])], ChatPromptBoxQueueComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ChatPromptBoxQueueComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-chat-prompt-box-queue",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		intl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "intl",
				required: false
			}]
		}],
		entries: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "entries",
				required: false
			}]
		}],
		reorderable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "reorderable",
				required: false
			}]
		}],
		steerable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "steerable",
				required: false
			}]
		}],
		editable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "editable",
				required: false
			}]
		}],
		pausable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "pausable",
				required: false
			}]
		}],
		actions: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "actions",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideChatPromptBoxQueueComponent(config, intl) {
	const providers = [];
	if (config) providers.push({
		provide: CHAT_PROMPT_BOX_QUEUE_DEFAULT_PROPS,
		useValue: config
	});
	if (intl) {
		if (typeof intl === "function") providers.push({
			provide: CHAT_PROMPT_BOX_QUEUE_INTL,
			useClass: intl
		});
		else providers.push({
			provide: CHAT_PROMPT_BOX_QUEUE_INTL,
			useValue: intl
		});
	}
	return makeEnvironmentProviders(providers);
}
var __decorate$5 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$5 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const CHAT_PROMPT_BOX_DEFAULT_PROPS = new InjectionToken("MOSAIK_CHAT_PROMPT_BOX_DEFAULT_PROPS");
const CHAT_PROMPT_BOX_INTL = new InjectionToken("MOSAIK_CHAT_PROMPT_BOX_INTL");
let ChatPromptBoxComponent = class ChatPromptBoxComponent {
	intl = input(...ngDevMode ? [void 0, { debugName: "intl" }] : /* istanbul ignore next */ []);
	value = input(...ngDevMode ? [void 0, { debugName: "value" }] : /* istanbul ignore next */ []);
	mentionDocument = input(...ngDevMode ? [void 0, { debugName: "mentionDocument" }] : /* istanbul ignore next */ []);
	suggestions = input(...ngDevMode ? [void 0, { debugName: "suggestions" }] : /* istanbul ignore next */ []);
	entries = input(...ngDevMode ? [void 0, { debugName: "entries" }] : /* istanbul ignore next */ []);
	queue = input(...ngDevMode ? [void 0, { debugName: "queue" }] : /* istanbul ignore next */ []);
	queueOnBusy = input(...ngDevMode ? [void 0, { debugName: "queueOnBusy" }] : /* istanbul ignore next */ []);
	queuePaused = input(...ngDevMode ? [void 0, { debugName: "queuePaused" }] : /* istanbul ignore next */ []);
	tools = input(...ngDevMode ? [void 0, { debugName: "tools" }] : /* istanbul ignore next */ []);
	placeholder = input(...ngDevMode ? [void 0, { debugName: "placeholder" }] : /* istanbul ignore next */ []);
	minRows = input(...ngDevMode ? [void 0, { debugName: "minRows" }] : /* istanbul ignore next */ []);
	maxRows = input(...ngDevMode ? [void 0, { debugName: "maxRows" }] : /* istanbul ignore next */ []);
	showSubmitButton = input(...ngDevMode ? [void 0, { debugName: "showSubmitButton" }] : /* istanbul ignore next */ []);
	submitOnEnter = input(...ngDevMode ? [void 0, { debugName: "submitOnEnter" }] : /* istanbul ignore next */ []);
	readonly = input(...ngDevMode ? [void 0, { debugName: "readonly" }] : /* istanbul ignore next */ []);
	required = input(...ngDevMode ? [void 0, { debugName: "required" }] : /* istanbul ignore next */ []);
	autofocus = input(...ngDevMode ? [void 0, { debugName: "autofocus" }] : /* istanbul ignore next */ []);
	name = input(...ngDevMode ? [void 0, { debugName: "name" }] : /* istanbul ignore next */ []);
	minlength = input(...ngDevMode ? [void 0, { debugName: "minlength" }] : /* istanbul ignore next */ []);
	maxlength = input(...ngDevMode ? [void 0, { debugName: "maxlength" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	appearance = input(...ngDevMode ? [void 0, { debugName: "appearance" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	isBusy = input(...ngDevMode ? [void 0, { debugName: "isBusy" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	formatter = input(...ngDevMode ? [void 0, { debugName: "formatter" }] : /* istanbul ignore next */ []);
	parser = input(...ngDevMode ? [void 0, { debugName: "parser" }] : /* istanbul ignore next */ []);
	isFocused = input(...ngDevMode ? [void 0, { debugName: "isFocused" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	entriesChanged = output();
	promptQueued = output();
	promptSubmitted = output();
	queueChanged = output();
	stopRequested = output();
	steerRequested = output();
	queuePausedChanged = output();
	queueActionInvoked = output();
	suggestionSelected = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	_accessor;
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._accessor = chatPromptBoxElementValueAccessor(this._elementRef.nativeElement);
		this._elementRef.nativeElement.addController(this._accessor);
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			entriesChanged: this.entriesChanged,
			promptQueued: this.promptQueued,
			promptSubmitted: this.promptSubmitted,
			queueChanged: this.queueChanged,
			stopRequested: this.stopRequested,
			steerRequested: this.steerRequested,
			queuePausedChanged: this.queuePausedChanged,
			queueActionInvoked: this.queueActionInvoked,
			suggestionSelected: this.suggestionSelected,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
			this._accessor.releaseCallbacks();
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(CHAT_PROMPT_BOX_DEFAULT_PROPS, { optional: true }) ?? {}, ["intl"]);
		const injectedIntl = inject(CHAT_PROMPT_BOX_INTL, { optional: true });
		if (injectedIntl) {
			Object.assign(this._elementRef.nativeElement.intl, injectedIntl);
			this._elementRef.nativeElement.intl.changes.emit();
		}
	}
	writeValue(obj) {
		this._accessor.writeValue(obj);
	}
	registerOnChange(fn) {
		this._accessor.registerOnChange(fn);
	}
	registerOnTouched(fn) {
		this._accessor.registerOnTouched(fn);
	}
	setDisabledState(isDisabled) {
		this._accessor.setDisabled?.(isDisabled);
	}
	registerTool(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "registerTool", args);
	}
	unregisterTool(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "unregisterTool", args);
	}
	addEntry(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "addEntry", args);
	}
	updateEntry(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "updateEntry", args);
	}
	removeEntry(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "removeEntry", args);
	}
	clearEntries(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "clearEntries", args);
	}
	enqueue(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "enqueue", args);
	}
	dequeue(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "dequeue", args);
	}
	peekQueue(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "peekQueue", args);
	}
	removeQueued(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "removeQueued", args);
	}
	moveQueued(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "moveQueued", args);
	}
	clearQueue(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "clearQueue", args);
	}
	steerQueued(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "steerQueued", args);
	}
	editQueued(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "editQueued", args);
	}
	invokeQueuedAction(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "invokeQueuedAction", args);
	}
	clear(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "clear", args);
	}
	reset(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "reset", args);
	}
	checkValidity(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "checkValidity", args);
	}
	submit(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "submit", args);
	}
	stop(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "stop", args);
	}
	focus(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "focus", args);
	}
	blur(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "blur", args);
	}
	onSlotChanges(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onSlotChanges", args);
	}
	assignToSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "assignToSlot", args);
	}
	getSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getSlotContent", args);
	}
	hasSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlotContent", args);
	}
	hasSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlot", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const valueValue = this.value();
			if (valueValue !== void 0) this._elementRef.nativeElement.value = valueValue;
			const mentionDocumentValue = this.mentionDocument();
			if (mentionDocumentValue !== void 0) this._elementRef.nativeElement.mentionDocument = mentionDocumentValue;
			const suggestionsValue = this.suggestions();
			if (suggestionsValue !== void 0) this._elementRef.nativeElement.suggestions = suggestionsValue;
			const entriesValue = this.entries();
			if (entriesValue !== void 0) this._elementRef.nativeElement.entries = entriesValue;
			const queueValue = this.queue();
			if (queueValue !== void 0) this._elementRef.nativeElement.queue = queueValue;
			const queueOnBusyValue = this.queueOnBusy();
			if (queueOnBusyValue !== void 0) this._elementRef.nativeElement.queueOnBusy = queueOnBusyValue;
			const queuePausedValue = this.queuePaused();
			if (queuePausedValue !== void 0) this._elementRef.nativeElement.queuePaused = queuePausedValue;
			const toolsValue = this.tools();
			if (toolsValue !== void 0) this._elementRef.nativeElement.tools = toolsValue;
			const placeholderValue = this.placeholder();
			if (placeholderValue !== void 0) this._elementRef.nativeElement.placeholder = placeholderValue;
			const minRowsValue = this.minRows();
			if (minRowsValue !== void 0) this._elementRef.nativeElement.minRows = minRowsValue;
			const maxRowsValue = this.maxRows();
			if (maxRowsValue !== void 0) this._elementRef.nativeElement.maxRows = maxRowsValue;
			const showSubmitButtonValue = this.showSubmitButton();
			if (showSubmitButtonValue !== void 0) this._elementRef.nativeElement.showSubmitButton = showSubmitButtonValue;
			const submitOnEnterValue = this.submitOnEnter();
			if (submitOnEnterValue !== void 0) this._elementRef.nativeElement.submitOnEnter = submitOnEnterValue;
			const readonlyValue = this.readonly();
			if (readonlyValue !== void 0) this._elementRef.nativeElement.readonly = readonlyValue;
			const requiredValue = this.required();
			if (requiredValue !== void 0) this._elementRef.nativeElement.required = requiredValue;
			const autofocusValue = this.autofocus();
			if (autofocusValue !== void 0) this._elementRef.nativeElement.autofocus = autofocusValue;
			const nameValue = this.name();
			if (nameValue !== void 0) this._elementRef.nativeElement.name = nameValue;
			const minlengthValue = this.minlength();
			if (minlengthValue !== void 0) this._elementRef.nativeElement.minlength = minlengthValue;
			const maxlengthValue = this.maxlength();
			if (maxlengthValue !== void 0) this._elementRef.nativeElement.maxlength = maxlengthValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const appearanceValue = this.appearance();
			if (appearanceValue !== void 0) this._elementRef.nativeElement.appearance = appearanceValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const isBusyValue = this.isBusy();
			if (isBusyValue !== void 0) this._elementRef.nativeElement.isBusy = isBusyValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const formatterValue = this.formatter();
			if (formatterValue !== void 0) this._elementRef.nativeElement.formatter = formatterValue;
			const parserValue = this.parser();
			if (parserValue !== void 0) this._elementRef.nativeElement.parser = parserValue;
			const isFocusedValue = this.isFocused();
			if (isFocusedValue !== void 0) this._elementRef.nativeElement.isFocused = isFocusedValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
			const intlValue = this.intl();
			if (intlValue !== void 0) {
				Object.assign(this._elementRef.nativeElement.intl, intlValue);
				this._elementRef.nativeElement.intl.changes.emit();
			}
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ChatPromptBoxComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: ChatPromptBoxComponent,
		isStandalone: true,
		selector: "mosaik-chat-prompt-box",
		inputs: {
			intl: {
				classPropertyName: "intl",
				publicName: "intl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			mentionDocument: {
				classPropertyName: "mentionDocument",
				publicName: "mentionDocument",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			suggestions: {
				classPropertyName: "suggestions",
				publicName: "suggestions",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			entries: {
				classPropertyName: "entries",
				publicName: "entries",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			queue: {
				classPropertyName: "queue",
				publicName: "queue",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			queueOnBusy: {
				classPropertyName: "queueOnBusy",
				publicName: "queueOnBusy",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			queuePaused: {
				classPropertyName: "queuePaused",
				publicName: "queuePaused",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			tools: {
				classPropertyName: "tools",
				publicName: "tools",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			placeholder: {
				classPropertyName: "placeholder",
				publicName: "placeholder",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			minRows: {
				classPropertyName: "minRows",
				publicName: "minRows",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			maxRows: {
				classPropertyName: "maxRows",
				publicName: "maxRows",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showSubmitButton: {
				classPropertyName: "showSubmitButton",
				publicName: "showSubmitButton",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			submitOnEnter: {
				classPropertyName: "submitOnEnter",
				publicName: "submitOnEnter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			readonly: {
				classPropertyName: "readonly",
				publicName: "readonly",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			required: {
				classPropertyName: "required",
				publicName: "required",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			autofocus: {
				classPropertyName: "autofocus",
				publicName: "autofocus",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			name: {
				classPropertyName: "name",
				publicName: "name",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			minlength: {
				classPropertyName: "minlength",
				publicName: "minlength",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			maxlength: {
				classPropertyName: "maxlength",
				publicName: "maxlength",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isBusy: {
				classPropertyName: "isBusy",
				publicName: "isBusy",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			formatter: {
				classPropertyName: "formatter",
				publicName: "formatter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			parser: {
				classPropertyName: "parser",
				publicName: "parser",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isFocused: {
				classPropertyName: "isFocused",
				publicName: "isFocused",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			entriesChanged: "entriesChanged",
			promptQueued: "promptQueued",
			promptSubmitted: "promptSubmitted",
			queueChanged: "queueChanged",
			stopRequested: "stopRequested",
			steerRequested: "steerRequested",
			queuePausedChanged: "queuePausedChanged",
			queueActionInvoked: "queueActionInvoked",
			suggestionSelected: "suggestionSelected",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		providers: [{
			provide: NG_VALUE_ACCESSOR,
			useExisting: forwardRef(() => ChatPromptBoxComponent),
			multi: true
		}, {
			provide: FORM_STATUS_HOST,
			useExisting: forwardRef(() => ChatPromptBoxComponent)
		}],
		hostDirectives: [{ directive: i1.FormStatusHostDirective }, { directive: i1.FormFieldStatusHostDirective }],
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
ChatPromptBoxComponent = __decorate$5([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-chat-prompt-box", ChatPromptBoxElement),
	inputs: [
		"intl",
		"value",
		"mentionDocument",
		"suggestions",
		"entries",
		"queue",
		"queueOnBusy",
		"queuePaused",
		"tools",
		"placeholder",
		"minRows",
		"maxRows",
		"showSubmitButton",
		"submitOnEnter",
		"readonly",
		"required",
		"autofocus",
		"name",
		"minlength",
		"maxlength",
		"themeName",
		"appearance",
		"variant",
		"isBusy",
		"disabled",
		"formatter",
		"parser",
		"isFocused",
		"dir",
		"lang"
	],
	methods: ["getSlotAssignments", "getSlotAssignmentsOf"]
}), __metadata$5("design:paramtypes", [])], ChatPromptBoxComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ChatPromptBoxComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-chat-prompt-box",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>",
			hostDirectives: [FormStatusHostDirective, FormFieldStatusHostDirective],
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => ChatPromptBoxComponent),
				multi: true
			}, {
				provide: FORM_STATUS_HOST,
				useExisting: forwardRef(() => ChatPromptBoxComponent)
			}]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		intl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "intl",
				required: false
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		mentionDocument: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mentionDocument",
				required: false
			}]
		}],
		suggestions: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "suggestions",
				required: false
			}]
		}],
		entries: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "entries",
				required: false
			}]
		}],
		queue: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "queue",
				required: false
			}]
		}],
		queueOnBusy: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "queueOnBusy",
				required: false
			}]
		}],
		queuePaused: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "queuePaused",
				required: false
			}]
		}],
		tools: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tools",
				required: false
			}]
		}],
		placeholder: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "placeholder",
				required: false
			}]
		}],
		minRows: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "minRows",
				required: false
			}]
		}],
		maxRows: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maxRows",
				required: false
			}]
		}],
		showSubmitButton: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showSubmitButton",
				required: false
			}]
		}],
		submitOnEnter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "submitOnEnter",
				required: false
			}]
		}],
		readonly: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "readonly",
				required: false
			}]
		}],
		required: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "required",
				required: false
			}]
		}],
		autofocus: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "autofocus",
				required: false
			}]
		}],
		name: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "name",
				required: false
			}]
		}],
		minlength: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "minlength",
				required: false
			}]
		}],
		maxlength: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maxlength",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		isBusy: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isBusy",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		formatter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "formatter",
				required: false
			}]
		}],
		parser: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "parser",
				required: false
			}]
		}],
		isFocused: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isFocused",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		entriesChanged: [{
			type: i0.Output,
			args: ["entriesChanged"]
		}],
		promptQueued: [{
			type: i0.Output,
			args: ["promptQueued"]
		}],
		promptSubmitted: [{
			type: i0.Output,
			args: ["promptSubmitted"]
		}],
		queueChanged: [{
			type: i0.Output,
			args: ["queueChanged"]
		}],
		stopRequested: [{
			type: i0.Output,
			args: ["stopRequested"]
		}],
		steerRequested: [{
			type: i0.Output,
			args: ["steerRequested"]
		}],
		queuePausedChanged: [{
			type: i0.Output,
			args: ["queuePausedChanged"]
		}],
		queueActionInvoked: [{
			type: i0.Output,
			args: ["queueActionInvoked"]
		}],
		suggestionSelected: [{
			type: i0.Output,
			args: ["suggestionSelected"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideChatPromptBoxComponent(config, intl) {
	const providers = [];
	if (config) providers.push({
		provide: CHAT_PROMPT_BOX_DEFAULT_PROPS,
		useValue: config
	});
	if (intl) {
		if (typeof intl === "function") providers.push({
			provide: CHAT_PROMPT_BOX_INTL,
			useClass: intl
		});
		else providers.push({
			provide: CHAT_PROMPT_BOX_INTL,
			useValue: intl
		});
	}
	return makeEnvironmentProviders(providers);
}
var __decorate$4 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$4 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const CHAT_DEFAULT_PROPS = new InjectionToken("MOSAIK_CHAT_DEFAULT_PROPS");
const CHAT_INTL = new InjectionToken("MOSAIK_CHAT_INTL");
let ChatComponent = class ChatComponent {
	intl = input(...ngDevMode ? [void 0, { debugName: "intl" }] : /* istanbul ignore next */ []);
	scrollToEnd = input(...ngDevMode ? [void 0, { debugName: "scrollToEnd" }] : /* istanbul ignore next */ []);
	scrollToEndThreshold = input(...ngDevMode ? [void 0, { debugName: "scrollToEndThreshold" }] : /* istanbul ignore next */ []);
	begin = input(...ngDevMode ? [void 0, { debugName: "begin" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	width = input(...ngDevMode ? [void 0, { debugName: "width" }] : /* istanbul ignore next */ []);
	height = input(...ngDevMode ? [void 0, { debugName: "height" }] : /* istanbul ignore next */ []);
	appearance = input(...ngDevMode ? [void 0, { debugName: "appearance" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(CHAT_DEFAULT_PROPS, { optional: true }) ?? {}, ["intl"]);
		const injectedIntl = inject(CHAT_INTL, { optional: true });
		if (injectedIntl) {
			Object.assign(this._elementRef.nativeElement.intl, injectedIntl);
			this._elementRef.nativeElement.intl.changes.emit();
		}
	}
	onSlotChanges(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onSlotChanges", args);
	}
	assignToSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "assignToSlot", args);
	}
	getSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getSlotContent", args);
	}
	hasSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlotContent", args);
	}
	hasSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlot", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const scrollToEndValue = this.scrollToEnd();
			if (scrollToEndValue !== void 0) this._elementRef.nativeElement.scrollToEnd = scrollToEndValue;
			const scrollToEndThresholdValue = this.scrollToEndThreshold();
			if (scrollToEndThresholdValue !== void 0) this._elementRef.nativeElement.scrollToEndThreshold = scrollToEndThresholdValue;
			const beginValue = this.begin();
			if (beginValue !== void 0) this._elementRef.nativeElement.begin = beginValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const widthValue = this.width();
			if (widthValue !== void 0) this._elementRef.nativeElement.width = widthValue;
			const heightValue = this.height();
			if (heightValue !== void 0) this._elementRef.nativeElement.height = heightValue;
			const appearanceValue = this.appearance();
			if (appearanceValue !== void 0) this._elementRef.nativeElement.appearance = appearanceValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
			const intlValue = this.intl();
			if (intlValue !== void 0) {
				Object.assign(this._elementRef.nativeElement.intl, intlValue);
				this._elementRef.nativeElement.intl.changes.emit();
			}
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ChatComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: ChatComponent,
		isStandalone: true,
		selector: "mosaik-chat",
		inputs: {
			intl: {
				classPropertyName: "intl",
				publicName: "intl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			scrollToEnd: {
				classPropertyName: "scrollToEnd",
				publicName: "scrollToEnd",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			scrollToEndThreshold: {
				classPropertyName: "scrollToEndThreshold",
				publicName: "scrollToEndThreshold",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			begin: {
				classPropertyName: "begin",
				publicName: "begin",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			width: {
				classPropertyName: "width",
				publicName: "width",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			height: {
				classPropertyName: "height",
				publicName: "height",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
ChatComponent = __decorate$4([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-chat", ChatElement),
	inputs: [
		"intl",
		"scrollToEnd",
		"scrollToEndThreshold",
		"begin",
		"themeName",
		"width",
		"height",
		"appearance",
		"variant",
		"dir",
		"lang"
	],
	methods: ["getSlotAssignments", "getSlotAssignmentsOf"]
}), __metadata$4("design:paramtypes", [])], ChatComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ChatComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-chat",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		intl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "intl",
				required: false
			}]
		}],
		scrollToEnd: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "scrollToEnd",
				required: false
			}]
		}],
		scrollToEndThreshold: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "scrollToEndThreshold",
				required: false
			}]
		}],
		begin: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "begin",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		width: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "width",
				required: false
			}]
		}],
		height: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "height",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideChatComponent(config, intl) {
	const providers = [];
	if (config) providers.push({
		provide: CHAT_DEFAULT_PROPS,
		useValue: config
	});
	if (intl) {
		if (typeof intl === "function") providers.push({
			provide: CHAT_INTL,
			useClass: intl
		});
		else providers.push({
			provide: CHAT_INTL,
			useValue: intl
		});
	}
	return makeEnvironmentProviders(providers);
}
var __decorate$3 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$3 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const MENTION_TEXT_DEFAULT_PROPS = new InjectionToken("MOSAIK_MENTION_TEXT_DEFAULT_PROPS");
let MentionTextComponent = class MentionTextComponent {
	document = input(...ngDevMode ? [void 0, { debugName: "document" }] : /* istanbul ignore next */ []);
	isInteractive = input(...ngDevMode ? [void 0, { debugName: "isInteractive" }] : /* istanbul ignore next */ []);
	cardProvider = input(...ngDevMode ? [void 0, { debugName: "cardProvider" }] : /* istanbul ignore next */ []);
	formatter = input(...ngDevMode ? [void 0, { debugName: "formatter" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	mentionInvoked = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			mentionInvoked: this.mentionInvoked,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(MENTION_TEXT_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const documentValue = this.document();
			if (documentValue !== void 0) this._elementRef.nativeElement.document = documentValue;
			const isInteractiveValue = this.isInteractive();
			if (isInteractiveValue !== void 0) this._elementRef.nativeElement.isInteractive = isInteractiveValue;
			const cardProviderValue = this.cardProvider();
			if (cardProviderValue !== void 0) this._elementRef.nativeElement.cardProvider = cardProviderValue;
			const formatterValue = this.formatter();
			if (formatterValue !== void 0) this._elementRef.nativeElement.formatter = formatterValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: MentionTextComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: MentionTextComponent,
		isStandalone: true,
		selector: "mosaik-mention-text",
		inputs: {
			document: {
				classPropertyName: "document",
				publicName: "document",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isInteractive: {
				classPropertyName: "isInteractive",
				publicName: "isInteractive",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			cardProvider: {
				classPropertyName: "cardProvider",
				publicName: "cardProvider",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			formatter: {
				classPropertyName: "formatter",
				publicName: "formatter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			mentionInvoked: "mentionInvoked",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
MentionTextComponent = __decorate$3([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-mention-text", MentionTextElement),
	inputs: [
		"document",
		"isInteractive",
		"cardProvider",
		"formatter",
		"dir",
		"lang"
	]
}), __metadata$3("design:paramtypes", [])], MentionTextComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MentionTextComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-mention-text",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		document: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "document",
				required: false
			}]
		}],
		isInteractive: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isInteractive",
				required: false
			}]
		}],
		cardProvider: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "cardProvider",
				required: false
			}]
		}],
		formatter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "formatter",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		mentionInvoked: [{
			type: i0.Output,
			args: ["mentionInvoked"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideMentionTextComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: MENTION_TEXT_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$2 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$2 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const MENTION_DEFAULT_PROPS = new InjectionToken("MOSAIK_MENTION_DEFAULT_PROPS");
let MentionComponent = class MentionComponent {
	label = input(...ngDevMode ? [void 0, { debugName: "label" }] : /* istanbul ignore next */ []);
	referenceId = input(...ngDevMode ? [void 0, { debugName: "referenceId" }] : /* istanbul ignore next */ []);
	trigger = input(...ngDevMode ? [void 0, { debugName: "trigger" }] : /* istanbul ignore next */ []);
	tone = input(...ngDevMode ? [void 0, { debugName: "tone" }] : /* istanbul ignore next */ []);
	kind = input(...ngDevMode ? [void 0, { debugName: "kind" }] : /* istanbul ignore next */ []);
	isInteractive = input(...ngDevMode ? [void 0, { debugName: "isInteractive" }] : /* istanbul ignore next */ []);
	cardProvider = input(...ngDevMode ? [void 0, { debugName: "cardProvider" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	mentionInvoked = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			mentionInvoked: this.mentionInvoked,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(MENTION_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const labelValue = this.label();
			if (labelValue !== void 0) this._elementRef.nativeElement.label = labelValue;
			const referenceIdValue = this.referenceId();
			if (referenceIdValue !== void 0) this._elementRef.nativeElement.referenceId = referenceIdValue;
			const triggerValue = this.trigger();
			if (triggerValue !== void 0) this._elementRef.nativeElement.trigger = triggerValue;
			const toneValue = this.tone();
			if (toneValue !== void 0) this._elementRef.nativeElement.tone = toneValue;
			const isInteractiveValue = this.isInteractive();
			if (isInteractiveValue !== void 0) this._elementRef.nativeElement.isInteractive = isInteractiveValue;
			const cardProviderValue = this.cardProvider();
			if (cardProviderValue !== void 0) this._elementRef.nativeElement.cardProvider = cardProviderValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: MentionComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: MentionComponent,
		isStandalone: true,
		selector: "mosaik-mention",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			referenceId: {
				classPropertyName: "referenceId",
				publicName: "referenceId",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			trigger: {
				classPropertyName: "trigger",
				publicName: "trigger",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			tone: {
				classPropertyName: "tone",
				publicName: "tone",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			kind: {
				classPropertyName: "kind",
				publicName: "kind",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isInteractive: {
				classPropertyName: "isInteractive",
				publicName: "isInteractive",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			cardProvider: {
				classPropertyName: "cardProvider",
				publicName: "cardProvider",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			mentionInvoked: "mentionInvoked",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
MentionComponent = __decorate$2([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-mention", MentionElement),
	inputs: [
		"label",
		"referenceId",
		"trigger",
		"tone",
		"kind",
		"isInteractive",
		"cardProvider",
		"themeName",
		"dir",
		"lang"
	]
}), __metadata$2("design:paramtypes", [])], MentionComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MentionComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-mention",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		referenceId: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "referenceId",
				required: false
			}]
		}],
		trigger: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "trigger",
				required: false
			}]
		}],
		tone: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tone",
				required: false
			}]
		}],
		kind: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "kind",
				required: false
			}]
		}],
		isInteractive: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isInteractive",
				required: false
			}]
		}],
		cardProvider: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "cardProvider",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		mentionInvoked: [{
			type: i0.Output,
			args: ["mentionInvoked"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideMentionComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: MENTION_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$1 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$1 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const REACTION_CHAT_TOOL_DEFAULT_PROPS = new InjectionToken("MOSAIK_REACTION_CHAT_TOOL_DEFAULT_PROPS");
let ReactionChatToolComponent = class ReactionChatToolComponent {
	reactions = input(...ngDevMode ? [void 0, { debugName: "reactions" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dock = input(...ngDevMode ? [void 0, { debugName: "dock" }] : /* istanbul ignore next */ []);
	disabledWhen = input(...ngDevMode ? [void 0, { debugName: "disabledWhen" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(REACTION_CHAT_TOOL_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	execute(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "execute", args);
	}
	attach(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "attach", args);
	}
	detach(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "detach", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const reactionsValue = this.reactions();
			if (reactionsValue !== void 0) this._elementRef.nativeElement.reactions = reactionsValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dockValue = this.dock();
			if (dockValue !== void 0) this._elementRef.nativeElement.dock = dockValue;
			const disabledWhenValue = this.disabledWhen();
			if (disabledWhenValue !== void 0) this._elementRef.nativeElement.disabledWhen = disabledWhenValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ReactionChatToolComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: ReactionChatToolComponent,
		isStandalone: true,
		selector: "mosaik-reaction-chat-tool",
		inputs: {
			reactions: {
				classPropertyName: "reactions",
				publicName: "reactions",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dock: {
				classPropertyName: "dock",
				publicName: "dock",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabledWhen: {
				classPropertyName: "disabledWhen",
				publicName: "disabledWhen",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
ReactionChatToolComponent = __decorate$1([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-reaction-chat-tool", ReactionChatToolElement),
	inputs: [
		"reactions",
		"themeName",
		"dock",
		"disabledWhen",
		"disabled",
		"dir",
		"lang"
	]
}), __metadata$1("design:paramtypes", [])], ReactionChatToolComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ReactionChatToolComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-reaction-chat-tool",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		reactions: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "reactions",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dock: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dock",
				required: false
			}]
		}],
		disabledWhen: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabledWhen",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideReactionChatToolComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: REACTION_CHAT_TOOL_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const VOICE_RECORDER_CHAT_TOOL_DEFAULT_PROPS = new InjectionToken("MOSAIK_VOICE_RECORDER_CHAT_TOOL_DEFAULT_PROPS");
const VOICE_RECORDER_CHAT_TOOL_INTL = new InjectionToken("MOSAIK_VOICE_RECORDER_CHAT_TOOL_INTL");
let VoiceRecorderChatToolComponent = class VoiceRecorderChatToolComponent {
	intl = input(...ngDevMode ? [void 0, { debugName: "intl" }] : /* istanbul ignore next */ []);
	state = input(...ngDevMode ? [void 0, { debugName: "state" }] : /* istanbul ignore next */ []);
	elapsedTime = input(...ngDevMode ? [void 0, { debugName: "elapsedTime" }] : /* istanbul ignore next */ []);
	maxDurationTime = input(...ngDevMode ? [void 0, { debugName: "maxDurationTime" }] : /* istanbul ignore next */ []);
	objectUrl = input(...ngDevMode ? [void 0, { debugName: "objectUrl" }] : /* istanbul ignore next */ []);
	canPause = input(...ngDevMode ? [void 0, { debugName: "canPause" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dock = input(...ngDevMode ? [void 0, { debugName: "dock" }] : /* istanbul ignore next */ []);
	disabledWhen = input(...ngDevMode ? [void 0, { debugName: "disabledWhen" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	recorderCancel = output();
	recorderPause = output();
	recorderResume = output();
	recorderStart = output();
	recorderStop = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			recorderCancel: this.recorderCancel,
			recorderPause: this.recorderPause,
			recorderResume: this.recorderResume,
			recorderStart: this.recorderStart,
			recorderStop: this.recorderStop,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(VOICE_RECORDER_CHAT_TOOL_DEFAULT_PROPS, { optional: true }) ?? {}, ["intl"]);
		const injectedIntl = inject(VOICE_RECORDER_CHAT_TOOL_INTL, { optional: true });
		if (injectedIntl) {
			Object.assign(this._elementRef.nativeElement.intl, injectedIntl);
			this._elementRef.nativeElement.intl.changes.emit();
		}
	}
	execute(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "execute", args);
	}
	attach(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "attach", args);
	}
	detach(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "detach", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const stateValue = this.state();
			if (stateValue !== void 0) this._elementRef.nativeElement.state = stateValue;
			const elapsedTimeValue = this.elapsedTime();
			if (elapsedTimeValue !== void 0) this._elementRef.nativeElement.elapsedTime = elapsedTimeValue;
			const maxDurationTimeValue = this.maxDurationTime();
			if (maxDurationTimeValue !== void 0) this._elementRef.nativeElement.maxDurationTime = maxDurationTimeValue;
			const objectUrlValue = this.objectUrl();
			if (objectUrlValue !== void 0) this._elementRef.nativeElement.objectUrl = objectUrlValue;
			const canPauseValue = this.canPause();
			if (canPauseValue !== void 0) this._elementRef.nativeElement.canPause = canPauseValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dockValue = this.dock();
			if (dockValue !== void 0) this._elementRef.nativeElement.dock = dockValue;
			const disabledWhenValue = this.disabledWhen();
			if (disabledWhenValue !== void 0) this._elementRef.nativeElement.disabledWhen = disabledWhenValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
			const intlValue = this.intl();
			if (intlValue !== void 0) {
				Object.assign(this._elementRef.nativeElement.intl, intlValue);
				this._elementRef.nativeElement.intl.changes.emit();
			}
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: VoiceRecorderChatToolComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: VoiceRecorderChatToolComponent,
		isStandalone: true,
		selector: "mosaik-voice-recorder-chat-tool",
		inputs: {
			intl: {
				classPropertyName: "intl",
				publicName: "intl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			state: {
				classPropertyName: "state",
				publicName: "state",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			elapsedTime: {
				classPropertyName: "elapsedTime",
				publicName: "elapsedTime",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			maxDurationTime: {
				classPropertyName: "maxDurationTime",
				publicName: "maxDurationTime",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			objectUrl: {
				classPropertyName: "objectUrl",
				publicName: "objectUrl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			canPause: {
				classPropertyName: "canPause",
				publicName: "canPause",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dock: {
				classPropertyName: "dock",
				publicName: "dock",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabledWhen: {
				classPropertyName: "disabledWhen",
				publicName: "disabledWhen",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			recorderCancel: "recorderCancel",
			recorderPause: "recorderPause",
			recorderResume: "recorderResume",
			recorderStart: "recorderStart",
			recorderStop: "recorderStop",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
VoiceRecorderChatToolComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-voice-recorder-chat-tool", VoiceRecorderChatToolElement),
	inputs: [
		"intl",
		"state",
		"elapsedTime",
		"maxDurationTime",
		"objectUrl",
		"canPause",
		"themeName",
		"dock",
		"disabledWhen",
		"disabled",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], VoiceRecorderChatToolComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: VoiceRecorderChatToolComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-voice-recorder-chat-tool",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		intl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "intl",
				required: false
			}]
		}],
		state: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "state",
				required: false
			}]
		}],
		elapsedTime: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "elapsedTime",
				required: false
			}]
		}],
		maxDurationTime: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maxDurationTime",
				required: false
			}]
		}],
		objectUrl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "objectUrl",
				required: false
			}]
		}],
		canPause: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "canPause",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dock: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dock",
				required: false
			}]
		}],
		disabledWhen: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabledWhen",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		recorderCancel: [{
			type: i0.Output,
			args: ["recorderCancel"]
		}],
		recorderPause: [{
			type: i0.Output,
			args: ["recorderPause"]
		}],
		recorderResume: [{
			type: i0.Output,
			args: ["recorderResume"]
		}],
		recorderStart: [{
			type: i0.Output,
			args: ["recorderStart"]
		}],
		recorderStop: [{
			type: i0.Output,
			args: ["recorderStop"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideVoiceRecorderChatToolComponent(config, intl) {
	const providers = [];
	if (config) providers.push({
		provide: VOICE_RECORDER_CHAT_TOOL_DEFAULT_PROPS,
		useValue: config
	});
	if (intl) {
		if (typeof intl === "function") providers.push({
			provide: VOICE_RECORDER_CHAT_TOOL_INTL,
			useClass: intl
		});
		else providers.push({
			provide: VOICE_RECORDER_CHAT_TOOL_INTL,
			useValue: intl
		});
	}
	return makeEnvironmentProviders(providers);
}
export { ATTACHMENT_CHAT_TOOL_DEFAULT_PROPS, ATTACHMENT_CHAT_TOOL_INTL, AttachmentChatToolComponent, CHAT_DEFAULT_PROPS, CHAT_HEADER_DEFAULT_PROPS, CHAT_INTL, CHAT_MARKER_DEFAULT_PROPS, CHAT_MESSAGE_AVATAR_DEFAULT_PROPS, CHAT_MESSAGE_DEFAULT_PROPS, CHAT_MESSAGE_DIVIDER_DEFAULT_PROPS, CHAT_MESSAGE_REACTION_DEFAULT_PROPS, CHAT_PROMPT_BOX_ATTACHMENT_LIST_DEFAULT_PROPS, CHAT_PROMPT_BOX_DEFAULT_PROPS, CHAT_PROMPT_BOX_INTL, CHAT_PROMPT_BOX_QUEUE_DEFAULT_PROPS, CHAT_PROMPT_BOX_QUEUE_INTL, ChatComponent, ChatHeaderComponent, ChatMarkerComponent, ChatMessageAvatarComponent, ChatMessageComponent, ChatMessageDividerComponent, ChatMessageReactionComponent, ChatPromptBoxAttachmentListComponent, ChatPromptBoxComponent, ChatPromptBoxQueueComponent, MENTION_DEFAULT_PROPS, MENTION_TEXT_DEFAULT_PROPS, MentionComponent, MentionTextComponent, REACTION_CHAT_TOOL_DEFAULT_PROPS, ReactionChatToolComponent, VOICE_RECORDER_CHAT_TOOL_DEFAULT_PROPS, VOICE_RECORDER_CHAT_TOOL_INTL, VoiceRecorderChatToolComponent, provideAttachmentChatToolComponent, provideChatComponent, provideChatHeaderComponent, provideChatMarkerComponent, provideChatMessageAvatarComponent, provideChatMessageComponent, provideChatMessageDividerComponent, provideChatMessageReactionComponent, provideChatPromptBoxAttachmentListComponent, provideChatPromptBoxComponent, provideChatPromptBoxQueueComponent, provideMentionComponent, provideMentionTextComponent, provideReactionChatToolComponent, provideVoiceRecorderChatToolComponent };

//# sourceMappingURL=mosaik-elements-angular-components-chat.mjs.map