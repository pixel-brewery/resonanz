import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, forwardRef, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { NG_VALUE_ACCESSOR } from "@angular/forms";
import { ScrubSliderElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/ranges/scrub-slider/ScrubSliderElement";
import { scrubSliderElementValueAccessor } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/ranges/scrub-slider/accessors/ScrubSliderElementValueAccessor";
import * as i1 from "@pixel-brewery/mosaik-elements-angular/runtime";
import { FORM_STATUS_HOST, FormFieldStatusHostDirective, FormStatusHostDirective, ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const SCRUB_SLIDER_DEFAULT_PROPS = new InjectionToken("MOSAIK_SCRUB_SLIDER_DEFAULT_PROPS");
let ScrubSliderComponent = class ScrubSliderComponent {
	step = input(...ngDevMode ? [void 0, { debugName: "step" }] : /* istanbul ignore next */ []);
	track = input(...ngDevMode ? [void 0, { debugName: "track" }] : /* istanbul ignore next */ []);
	ticks = input(...ngDevMode ? [void 0, { debugName: "ticks" }] : /* istanbul ignore next */ []);
	tickPlacement = input(...ngDevMode ? [void 0, { debugName: "tickPlacement" }] : /* istanbul ignore next */ []);
	showTickLabels = input(...ngDevMode ? [void 0, { debugName: "showTickLabels" }] : /* istanbul ignore next */ []);
	tickLabelAccessor = input(...ngDevMode ? [void 0, { debugName: "tickLabelAccessor" }] : /* istanbul ignore next */ []);
	tooltipPlacement = input(...ngDevMode ? [void 0, { debugName: "tooltipPlacement" }] : /* istanbul ignore next */ []);
	tooltipAccessor = input(...ngDevMode ? [void 0, { debugName: "tooltipAccessor" }] : /* istanbul ignore next */ []);
	pxPerStep = input(...ngDevMode ? [void 0, { debugName: "pxPerStep" }] : /* istanbul ignore next */ []);
	accelerate = input(...ngDevMode ? [void 0, { debugName: "accelerate" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	orientation = input(...ngDevMode ? [void 0, { debugName: "orientation" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	appearance = input(...ngDevMode ? [void 0, { debugName: "appearance" }] : /* istanbul ignore next */ []);
	isFocused = input(...ngDevMode ? [void 0, { debugName: "isFocused" }] : /* istanbul ignore next */ []);
	invalid = input(...ngDevMode ? [void 0, { debugName: "invalid" }] : /* istanbul ignore next */ []);
	min = input(...ngDevMode ? [void 0, { debugName: "min" }] : /* istanbul ignore next */ []);
	max = input(...ngDevMode ? [void 0, { debugName: "max" }] : /* istanbul ignore next */ []);
	value = input(...ngDevMode ? [void 0, { debugName: "value" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	input = output();
	change = output();
	rangeValueChanged = output();
	changed = output();
	connected = output();
	disconnected = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	_accessor;
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._accessor = scrubSliderElementValueAccessor(this._elementRef.nativeElement);
		this._elementRef.nativeElement.addController(this._accessor);
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			input: this.input,
			change: this.change,
			rangeValueChanged: this.rangeValueChanged,
			changed: this.changed,
			connected: this.connected,
			disconnected: this.disconnected
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
			this._accessor.releaseCallbacks();
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(SCRUB_SLIDER_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	writeValue(obj) {
		this._accessor.writeValue(obj);
	}
	registerOnChange(fn) {
		this._accessor.registerOnChange(fn);
	}
	registerOnTouched(fn) {
		this._accessor.registerOnTouched(fn);
	}
	setDisabledState(isDisabled) {
		this._accessor.setDisabled?.(isDisabled);
	}
	checkValidity(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "checkValidity", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const stepValue = this.step();
			if (stepValue !== void 0) this._elementRef.nativeElement.step = stepValue;
			const trackValue = this.track();
			if (trackValue !== void 0) this._elementRef.nativeElement.track = trackValue;
			const tickPlacementValue = this.tickPlacement();
			if (tickPlacementValue !== void 0) this._elementRef.nativeElement.tickPlacement = tickPlacementValue;
			const showTickLabelsValue = this.showTickLabels();
			if (showTickLabelsValue !== void 0) this._elementRef.nativeElement.showTickLabels = showTickLabelsValue;
			const tickLabelAccessorValue = this.tickLabelAccessor();
			if (tickLabelAccessorValue !== void 0) this._elementRef.nativeElement.tickLabelAccessor = tickLabelAccessorValue;
			const tooltipPlacementValue = this.tooltipPlacement();
			if (tooltipPlacementValue !== void 0) this._elementRef.nativeElement.tooltipPlacement = tooltipPlacementValue;
			const tooltipAccessorValue = this.tooltipAccessor();
			if (tooltipAccessorValue !== void 0) this._elementRef.nativeElement.tooltipAccessor = tooltipAccessorValue;
			const pxPerStepValue = this.pxPerStep();
			if (pxPerStepValue !== void 0) this._elementRef.nativeElement.pxPerStep = pxPerStepValue;
			const accelerateValue = this.accelerate();
			if (accelerateValue !== void 0) this._elementRef.nativeElement.accelerate = accelerateValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const orientationValue = this.orientation();
			if (orientationValue !== void 0) this._elementRef.nativeElement.orientation = orientationValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const appearanceValue = this.appearance();
			if (appearanceValue !== void 0) this._elementRef.nativeElement.appearance = appearanceValue;
			const isFocusedValue = this.isFocused();
			if (isFocusedValue !== void 0) this._elementRef.nativeElement.isFocused = isFocusedValue;
			const invalidValue = this.invalid();
			if (invalidValue !== void 0) this._elementRef.nativeElement.invalid = invalidValue;
			const minValue = this.min();
			if (minValue !== void 0) this._elementRef.nativeElement.min = minValue;
			const maxValue = this.max();
			if (maxValue !== void 0) this._elementRef.nativeElement.max = maxValue;
			const valueValue = this.value();
			if (valueValue !== void 0) this._elementRef.nativeElement.value = valueValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ScrubSliderComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: ScrubSliderComponent,
		isStandalone: true,
		selector: "mosaik-scrub-slider",
		inputs: {
			step: {
				classPropertyName: "step",
				publicName: "step",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			track: {
				classPropertyName: "track",
				publicName: "track",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			ticks: {
				classPropertyName: "ticks",
				publicName: "ticks",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			tickPlacement: {
				classPropertyName: "tickPlacement",
				publicName: "tickPlacement",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showTickLabels: {
				classPropertyName: "showTickLabels",
				publicName: "showTickLabels",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			tickLabelAccessor: {
				classPropertyName: "tickLabelAccessor",
				publicName: "tickLabelAccessor",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			tooltipPlacement: {
				classPropertyName: "tooltipPlacement",
				publicName: "tooltipPlacement",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			tooltipAccessor: {
				classPropertyName: "tooltipAccessor",
				publicName: "tooltipAccessor",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			pxPerStep: {
				classPropertyName: "pxPerStep",
				publicName: "pxPerStep",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			accelerate: {
				classPropertyName: "accelerate",
				publicName: "accelerate",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			orientation: {
				classPropertyName: "orientation",
				publicName: "orientation",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isFocused: {
				classPropertyName: "isFocused",
				publicName: "isFocused",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			invalid: {
				classPropertyName: "invalid",
				publicName: "invalid",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			min: {
				classPropertyName: "min",
				publicName: "min",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			max: {
				classPropertyName: "max",
				publicName: "max",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			input: "input",
			change: "change",
			rangeValueChanged: "rangeValueChanged",
			changed: "changed",
			connected: "connected",
			disconnected: "disconnected"
		},
		providers: [{
			provide: NG_VALUE_ACCESSOR,
			useExisting: forwardRef(() => ScrubSliderComponent),
			multi: true
		}, {
			provide: FORM_STATUS_HOST,
			useExisting: forwardRef(() => ScrubSliderComponent)
		}],
		hostDirectives: [{ directive: i1.FormStatusHostDirective }, { directive: i1.FormFieldStatusHostDirective }],
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
ScrubSliderComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-scrub-slider", ScrubSliderElement),
	inputs: [
		"step",
		"track",
		"ticks",
		"tickPlacement",
		"showTickLabels",
		"tickLabelAccessor",
		"tooltipPlacement",
		"tooltipAccessor",
		"pxPerStep",
		"accelerate",
		"themeName",
		"orientation",
		"disabled",
		"variant",
		"appearance",
		"isFocused",
		"invalid",
		"min",
		"max",
		"value",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], ScrubSliderComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ScrubSliderComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-scrub-slider",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>",
			hostDirectives: [FormStatusHostDirective, FormFieldStatusHostDirective],
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => ScrubSliderComponent),
				multi: true
			}, {
				provide: FORM_STATUS_HOST,
				useExisting: forwardRef(() => ScrubSliderComponent)
			}]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		step: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "step",
				required: false
			}]
		}],
		track: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "track",
				required: false
			}]
		}],
		ticks: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "ticks",
				required: false
			}]
		}],
		tickPlacement: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tickPlacement",
				required: false
			}]
		}],
		showTickLabels: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showTickLabels",
				required: false
			}]
		}],
		tickLabelAccessor: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tickLabelAccessor",
				required: false
			}]
		}],
		tooltipPlacement: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tooltipPlacement",
				required: false
			}]
		}],
		tooltipAccessor: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tooltipAccessor",
				required: false
			}]
		}],
		pxPerStep: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "pxPerStep",
				required: false
			}]
		}],
		accelerate: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "accelerate",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		orientation: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "orientation",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		isFocused: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isFocused",
				required: false
			}]
		}],
		invalid: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "invalid",
				required: false
			}]
		}],
		min: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "min",
				required: false
			}]
		}],
		max: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "max",
				required: false
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		input: [{
			type: i0.Output,
			args: ["input"]
		}],
		change: [{
			type: i0.Output,
			args: ["change"]
		}],
		rangeValueChanged: [{
			type: i0.Output,
			args: ["rangeValueChanged"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}]
	}
});
function provideScrubSliderComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: SCRUB_SLIDER_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { SCRUB_SLIDER_DEFAULT_PROPS, ScrubSliderComponent, provideScrubSliderComponent };

//# sourceMappingURL=mosaik-elements-angular-components-scrub-slider.mjs.map