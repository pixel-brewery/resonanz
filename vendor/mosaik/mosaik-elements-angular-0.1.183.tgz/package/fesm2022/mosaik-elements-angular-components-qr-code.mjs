import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { QRCodeElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/qr-code/QRCodeElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const QRCODE_DEFAULT_PROPS = new InjectionToken("MOSAIK_QRCODE_DEFAULT_PROPS");
let QRCodeComponent = class QRCodeComponent {
	text = input(...ngDevMode ? [void 0, { debugName: "text" }] : /* istanbul ignore next */ []);
	radius = input(...ngDevMode ? [void 0, { debugName: "radius" }] : /* istanbul ignore next */ []);
	dimension = input(...ngDevMode ? [void 0, { debugName: "dimension" }] : /* istanbul ignore next */ []);
	errorCorrection = input(...ngDevMode ? [void 0, { debugName: "errorCorrection" }] : /* istanbul ignore next */ []);
	backgroundColor = input(...ngDevMode ? [void 0, { debugName: "backgroundColor" }] : /* istanbul ignore next */ []);
	foregroundColor = input(...ngDevMode ? [void 0, { debugName: "foregroundColor" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(QRCODE_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	toDataURL(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "toDataURL", args);
	}
	toBlob(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "toBlob", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const textValue = this.text();
			if (textValue !== void 0) this._elementRef.nativeElement.text = textValue;
			const radiusValue = this.radius();
			if (radiusValue !== void 0) this._elementRef.nativeElement.radius = radiusValue;
			const dimensionValue = this.dimension();
			if (dimensionValue !== void 0) this._elementRef.nativeElement.dimension = dimensionValue;
			const errorCorrectionValue = this.errorCorrection();
			if (errorCorrectionValue !== void 0) this._elementRef.nativeElement.errorCorrection = errorCorrectionValue;
			const backgroundColorValue = this.backgroundColor();
			if (backgroundColorValue !== void 0) this._elementRef.nativeElement.backgroundColor = backgroundColorValue;
			const foregroundColorValue = this.foregroundColor();
			if (foregroundColorValue !== void 0) this._elementRef.nativeElement.foregroundColor = foregroundColorValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: QRCodeComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: QRCodeComponent,
		isStandalone: true,
		selector: "mosaik-qrcode",
		inputs: {
			text: {
				classPropertyName: "text",
				publicName: "text",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			radius: {
				classPropertyName: "radius",
				publicName: "radius",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dimension: {
				classPropertyName: "dimension",
				publicName: "dimension",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			errorCorrection: {
				classPropertyName: "errorCorrection",
				publicName: "errorCorrection",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			backgroundColor: {
				classPropertyName: "backgroundColor",
				publicName: "backgroundColor",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			foregroundColor: {
				classPropertyName: "foregroundColor",
				publicName: "foregroundColor",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
QRCodeComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-qrcode", QRCodeElement),
	inputs: [
		"text",
		"radius",
		"dimension",
		"errorCorrection",
		"backgroundColor",
		"foregroundColor",
		"themeName",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], QRCodeComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: QRCodeComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-qrcode",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		text: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "text",
				required: false
			}]
		}],
		radius: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "radius",
				required: false
			}]
		}],
		dimension: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dimension",
				required: false
			}]
		}],
		errorCorrection: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "errorCorrection",
				required: false
			}]
		}],
		backgroundColor: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "backgroundColor",
				required: false
			}]
		}],
		foregroundColor: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "foregroundColor",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideQRCodeComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: QRCODE_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { QRCODE_DEFAULT_PROPS, QRCodeComponent, provideQRCodeComponent };

//# sourceMappingURL=mosaik-elements-angular-components-qr-code.mjs.map