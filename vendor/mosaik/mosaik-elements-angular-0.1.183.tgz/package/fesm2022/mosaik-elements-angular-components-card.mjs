import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { CardActionsElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/grouping/card/CardActionsElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { CardContentElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/grouping/card/CardContentElement";
import { CardFooterElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/grouping/card/CardFooterElement";
import { CardHeaderElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/grouping/card/CardHeaderElement";
import { CardSubTitleElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/grouping/card/CardSubTitleElement";
import { CardTitleElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/grouping/card/CardTitleElement";
import { CardElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/grouping/card/CardElement";
var __decorate$6 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$6 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const CARD_ACTIONS_DEFAULT_PROPS = new InjectionToken("MOSAIK_CARD_ACTIONS_DEFAULT_PROPS");
let CardActionsComponent = class CardActionsComponent {
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(CARD_ACTIONS_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	assignToSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "assignToSlot", args);
	}
	getSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getSlotContent", args);
	}
	hasSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlotContent", args);
	}
	hasSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlot", args);
	}
	onSlotChanges(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onSlotChanges", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: CardActionsComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: CardActionsComponent,
		isStandalone: true,
		selector: "mosaik-card-actions",
		inputs: {
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
CardActionsComponent = __decorate$6([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-card-actions", CardActionsElement),
	inputs: [
		"themeName",
		"dir",
		"lang"
	],
	methods: ["getSlotAssignments", "getSlotAssignmentsOf"]
}), __metadata$6("design:paramtypes", [])], CardActionsComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: CardActionsComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-card-actions",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideCardActionsComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: CARD_ACTIONS_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$5 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$5 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const CARD_CONTENT_DEFAULT_PROPS = new InjectionToken("MOSAIK_CARD_CONTENT_DEFAULT_PROPS");
let CardContentComponent = class CardContentComponent {
	text = input(...ngDevMode ? [void 0, { debugName: "text" }] : /* istanbul ignore next */ []);
	formatter = input(...ngDevMode ? [void 0, { debugName: "formatter" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	contentChanged = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			contentChanged: this.contentChanged,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(CARD_CONTENT_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	onSlotChanges(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onSlotChanges", args);
	}
	assignToSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "assignToSlot", args);
	}
	getSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getSlotContent", args);
	}
	hasSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlotContent", args);
	}
	hasSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlot", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const textValue = this.text();
			if (textValue !== void 0) this._elementRef.nativeElement.text = textValue;
			const formatterValue = this.formatter();
			if (formatterValue !== void 0) this._elementRef.nativeElement.formatter = formatterValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: CardContentComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: CardContentComponent,
		isStandalone: true,
		selector: "mosaik-card-content",
		inputs: {
			text: {
				classPropertyName: "text",
				publicName: "text",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			formatter: {
				classPropertyName: "formatter",
				publicName: "formatter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			contentChanged: "contentChanged",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
CardContentComponent = __decorate$5([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-card-content", CardContentElement),
	inputs: [
		"text",
		"formatter",
		"themeName",
		"dir",
		"lang"
	],
	methods: ["getSlotAssignments", "getSlotAssignmentsOf"]
}), __metadata$5("design:paramtypes", [])], CardContentComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: CardContentComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-card-content",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		text: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "text",
				required: false
			}]
		}],
		formatter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "formatter",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		contentChanged: [{
			type: i0.Output,
			args: ["contentChanged"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideCardContentComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: CARD_CONTENT_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$4 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$4 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const CARD_FOOTER_DEFAULT_PROPS = new InjectionToken("MOSAIK_CARD_FOOTER_DEFAULT_PROPS");
let CardFooterComponent = class CardFooterComponent {
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(CARD_FOOTER_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	assignToSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "assignToSlot", args);
	}
	getSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getSlotContent", args);
	}
	hasSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlotContent", args);
	}
	hasSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlot", args);
	}
	onSlotChanges(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onSlotChanges", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: CardFooterComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: CardFooterComponent,
		isStandalone: true,
		selector: "mosaik-card-footer",
		inputs: {
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
CardFooterComponent = __decorate$4([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-card-footer", CardFooterElement),
	inputs: [
		"themeName",
		"dir",
		"lang"
	],
	methods: ["getSlotAssignments", "getSlotAssignmentsOf"]
}), __metadata$4("design:paramtypes", [])], CardFooterComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: CardFooterComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-card-footer",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideCardFooterComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: CARD_FOOTER_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$3 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$3 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const CARD_HEADER_DEFAULT_PROPS = new InjectionToken("MOSAIK_CARD_HEADER_DEFAULT_PROPS");
let CardHeaderComponent = class CardHeaderComponent {
	text = input(...ngDevMode ? [void 0, { debugName: "text" }] : /* istanbul ignore next */ []);
	subText = input(...ngDevMode ? [void 0, { debugName: "subText" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	formatter = input(...ngDevMode ? [void 0, { debugName: "formatter" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(CARD_HEADER_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	assignToSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "assignToSlot", args);
	}
	getSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getSlotContent", args);
	}
	hasSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlotContent", args);
	}
	hasSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlot", args);
	}
	onSlotChanges(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onSlotChanges", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const textValue = this.text();
			if (textValue !== void 0) this._elementRef.nativeElement.text = textValue;
			const subTextValue = this.subText();
			if (subTextValue !== void 0) this._elementRef.nativeElement.subText = subTextValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const formatterValue = this.formatter();
			if (formatterValue !== void 0) this._elementRef.nativeElement.formatter = formatterValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: CardHeaderComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: CardHeaderComponent,
		isStandalone: true,
		selector: "mosaik-card-header",
		inputs: {
			text: {
				classPropertyName: "text",
				publicName: "text",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			subText: {
				classPropertyName: "subText",
				publicName: "subText",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			formatter: {
				classPropertyName: "formatter",
				publicName: "formatter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
CardHeaderComponent = __decorate$3([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-card-header", CardHeaderElement),
	inputs: [
		"text",
		"subText",
		"themeName",
		"formatter",
		"dir",
		"lang"
	],
	methods: ["getSlotAssignments", "getSlotAssignmentsOf"]
}), __metadata$3("design:paramtypes", [])], CardHeaderComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: CardHeaderComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-card-header",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		text: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "text",
				required: false
			}]
		}],
		subText: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "subText",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		formatter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "formatter",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideCardHeaderComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: CARD_HEADER_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$2 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$2 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const CARD_SUB_TITLE_DEFAULT_PROPS = new InjectionToken("MOSAIK_CARD_SUB_TITLE_DEFAULT_PROPS");
let CardSubTitleComponent = class CardSubTitleComponent {
	text = input(...ngDevMode ? [void 0, { debugName: "text" }] : /* istanbul ignore next */ []);
	formatter = input(...ngDevMode ? [void 0, { debugName: "formatter" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	contentChanged = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			contentChanged: this.contentChanged,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(CARD_SUB_TITLE_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	onSlotChanges(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onSlotChanges", args);
	}
	assignToSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "assignToSlot", args);
	}
	getSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getSlotContent", args);
	}
	hasSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlotContent", args);
	}
	hasSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlot", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const textValue = this.text();
			if (textValue !== void 0) this._elementRef.nativeElement.text = textValue;
			const formatterValue = this.formatter();
			if (formatterValue !== void 0) this._elementRef.nativeElement.formatter = formatterValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: CardSubTitleComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: CardSubTitleComponent,
		isStandalone: true,
		selector: "mosaik-card-sub-title",
		inputs: {
			text: {
				classPropertyName: "text",
				publicName: "text",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			formatter: {
				classPropertyName: "formatter",
				publicName: "formatter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			contentChanged: "contentChanged",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
CardSubTitleComponent = __decorate$2([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-card-sub-title", CardSubTitleElement),
	inputs: [
		"text",
		"formatter",
		"themeName",
		"dir",
		"lang"
	],
	methods: ["getSlotAssignments", "getSlotAssignmentsOf"]
}), __metadata$2("design:paramtypes", [])], CardSubTitleComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: CardSubTitleComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-card-sub-title",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		text: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "text",
				required: false
			}]
		}],
		formatter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "formatter",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		contentChanged: [{
			type: i0.Output,
			args: ["contentChanged"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideCardSubTitleComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: CARD_SUB_TITLE_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$1 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$1 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const CARD_TITLE_DEFAULT_PROPS = new InjectionToken("MOSAIK_CARD_TITLE_DEFAULT_PROPS");
let CardTitleComponent = class CardTitleComponent {
	text = input(...ngDevMode ? [void 0, { debugName: "text" }] : /* istanbul ignore next */ []);
	formatter = input(...ngDevMode ? [void 0, { debugName: "formatter" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	contentChanged = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			contentChanged: this.contentChanged,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(CARD_TITLE_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	onSlotChanges(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onSlotChanges", args);
	}
	assignToSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "assignToSlot", args);
	}
	getSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getSlotContent", args);
	}
	hasSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlotContent", args);
	}
	hasSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlot", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const textValue = this.text();
			if (textValue !== void 0) this._elementRef.nativeElement.text = textValue;
			const formatterValue = this.formatter();
			if (formatterValue !== void 0) this._elementRef.nativeElement.formatter = formatterValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: CardTitleComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: CardTitleComponent,
		isStandalone: true,
		selector: "mosaik-card-title",
		inputs: {
			text: {
				classPropertyName: "text",
				publicName: "text",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			formatter: {
				classPropertyName: "formatter",
				publicName: "formatter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			contentChanged: "contentChanged",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
CardTitleComponent = __decorate$1([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-card-title", CardTitleElement),
	inputs: [
		"text",
		"formatter",
		"themeName",
		"dir",
		"lang"
	],
	methods: ["getSlotAssignments", "getSlotAssignmentsOf"]
}), __metadata$1("design:paramtypes", [])], CardTitleComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: CardTitleComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-card-title",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		text: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "text",
				required: false
			}]
		}],
		formatter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "formatter",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		contentChanged: [{
			type: i0.Output,
			args: ["contentChanged"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideCardTitleComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: CARD_TITLE_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const CARD_DEFAULT_PROPS = new InjectionToken("MOSAIK_CARD_DEFAULT_PROPS");
let CardComponent = class CardComponent {
	header = input(...ngDevMode ? [void 0, { debugName: "header" }] : /* istanbul ignore next */ []);
	subHeader = input(...ngDevMode ? [void 0, { debugName: "subHeader" }] : /* istanbul ignore next */ []);
	content = input(...ngDevMode ? [void 0, { debugName: "content" }] : /* istanbul ignore next */ []);
	inlineMedia = input(...ngDevMode ? [void 0, { debugName: "inlineMedia" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	elevation = input(...ngDevMode ? [void 0, { debugName: "elevation" }] : /* istanbul ignore next */ []);
	appearance = input(...ngDevMode ? [void 0, { debugName: "appearance" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	inset = input(...ngDevMode ? [void 0, { debugName: "inset" }] : /* istanbul ignore next */ []);
	fit = input(...ngDevMode ? [void 0, { debugName: "fit" }] : /* istanbul ignore next */ []);
	orientation = input(...ngDevMode ? [void 0, { debugName: "orientation" }] : /* istanbul ignore next */ []);
	formatter = input(...ngDevMode ? [void 0, { debugName: "formatter" }] : /* istanbul ignore next */ []);
	isSelected = input(...ngDevMode ? [void 0, { debugName: "isSelected" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	selected = output();
	deselected = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			selected: this.selected,
			deselected: this.deselected,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(CARD_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	select(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "select", args);
	}
	deselect(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "deselect", args);
	}
	assignToSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "assignToSlot", args);
	}
	getSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getSlotContent", args);
	}
	hasSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlotContent", args);
	}
	hasSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlot", args);
	}
	onSlotChanges(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onSlotChanges", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const headerValue = this.header();
			if (headerValue !== void 0) this._elementRef.nativeElement.header = headerValue;
			const subHeaderValue = this.subHeader();
			if (subHeaderValue !== void 0) this._elementRef.nativeElement.subHeader = subHeaderValue;
			const contentValue = this.content();
			if (contentValue !== void 0) this._elementRef.nativeElement.content = contentValue;
			const inlineMediaValue = this.inlineMedia();
			if (inlineMediaValue !== void 0) this._elementRef.nativeElement.inlineMedia = inlineMediaValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const elevationValue = this.elevation();
			if (elevationValue !== void 0) this._elementRef.nativeElement.elevation = elevationValue;
			const appearanceValue = this.appearance();
			if (appearanceValue !== void 0) this._elementRef.nativeElement.appearance = appearanceValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const insetValue = this.inset();
			if (insetValue !== void 0) this._elementRef.nativeElement.inset = insetValue;
			const fitValue = this.fit();
			if (fitValue !== void 0) this._elementRef.nativeElement.fit = fitValue;
			const orientationValue = this.orientation();
			if (orientationValue !== void 0) this._elementRef.nativeElement.orientation = orientationValue;
			const formatterValue = this.formatter();
			if (formatterValue !== void 0) this._elementRef.nativeElement.formatter = formatterValue;
			const isSelectedValue = this.isSelected();
			if (isSelectedValue !== void 0) this._elementRef.nativeElement.isSelected = isSelectedValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: CardComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: CardComponent,
		isStandalone: true,
		selector: "mosaik-card",
		inputs: {
			header: {
				classPropertyName: "header",
				publicName: "header",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			subHeader: {
				classPropertyName: "subHeader",
				publicName: "subHeader",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			content: {
				classPropertyName: "content",
				publicName: "content",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			inlineMedia: {
				classPropertyName: "inlineMedia",
				publicName: "inlineMedia",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			elevation: {
				classPropertyName: "elevation",
				publicName: "elevation",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			inset: {
				classPropertyName: "inset",
				publicName: "inset",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			fit: {
				classPropertyName: "fit",
				publicName: "fit",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			orientation: {
				classPropertyName: "orientation",
				publicName: "orientation",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			formatter: {
				classPropertyName: "formatter",
				publicName: "formatter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isSelected: {
				classPropertyName: "isSelected",
				publicName: "isSelected",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			selected: "selected",
			deselected: "deselected",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
CardComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-card", CardElement),
	inputs: [
		"header",
		"subHeader",
		"content",
		"inlineMedia",
		"themeName",
		"elevation",
		"appearance",
		"variant",
		"inset",
		"fit",
		"orientation",
		"formatter",
		"isSelected",
		"disabled",
		"dir",
		"lang"
	],
	methods: ["getSlotAssignments", "getSlotAssignmentsOf"]
}), __metadata("design:paramtypes", [])], CardComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: CardComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-card",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		header: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "header",
				required: false
			}]
		}],
		subHeader: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "subHeader",
				required: false
			}]
		}],
		content: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "content",
				required: false
			}]
		}],
		inlineMedia: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "inlineMedia",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		elevation: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "elevation",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		inset: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "inset",
				required: false
			}]
		}],
		fit: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "fit",
				required: false
			}]
		}],
		orientation: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "orientation",
				required: false
			}]
		}],
		formatter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "formatter",
				required: false
			}]
		}],
		isSelected: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isSelected",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		selected: [{
			type: i0.Output,
			args: ["selected"]
		}],
		deselected: [{
			type: i0.Output,
			args: ["deselected"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideCardComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: CARD_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { CARD_ACTIONS_DEFAULT_PROPS, CARD_CONTENT_DEFAULT_PROPS, CARD_DEFAULT_PROPS, CARD_FOOTER_DEFAULT_PROPS, CARD_HEADER_DEFAULT_PROPS, CARD_SUB_TITLE_DEFAULT_PROPS, CARD_TITLE_DEFAULT_PROPS, CardActionsComponent, CardComponent, CardContentComponent, CardFooterComponent, CardHeaderComponent, CardSubTitleComponent, CardTitleComponent, provideCardActionsComponent, provideCardComponent, provideCardContentComponent, provideCardFooterComponent, provideCardHeaderComponent, provideCardSubTitleComponent, provideCardTitleComponent };

//# sourceMappingURL=mosaik-elements-angular-components-card.mjs.map