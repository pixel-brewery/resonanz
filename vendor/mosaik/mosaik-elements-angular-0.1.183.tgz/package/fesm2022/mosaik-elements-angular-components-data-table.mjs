import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, forwardRef, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { NG_VALUE_ACCESSOR } from "@angular/forms";
import { DataTableElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/data-table/DataTableElement";
import { dataTableElementValueAccessor } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/data-table/accessors/DataTableElementValueAccessor";
import * as i1 from "@pixel-brewery/mosaik-elements-angular/runtime";
import { FORM_STATUS_HOST, FormFieldStatusHostDirective, FormStatusHostDirective, ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const DATA_TABLE_DEFAULT_PROPS = new InjectionToken("MOSAIK_DATA_TABLE_DEFAULT_PROPS");
const DATA_TABLE_INTL = new InjectionToken("MOSAIK_DATA_TABLE_INTL");
let DataTableComponent = class DataTableComponent {
	intl = input(...ngDevMode ? [void 0, { debugName: "intl" }] : /* istanbul ignore next */ []);
	alternating = input(...ngDevMode ? [void 0, { debugName: "alternating" }] : /* istanbul ignore next */ []);
	autoGenerateColumns = input(...ngDevMode ? [void 0, { debugName: "autoGenerateColumns" }] : /* istanbul ignore next */ []);
	columnDefinitions = input(...ngDevMode ? [void 0, { debugName: "columnDefinitions" }] : /* istanbul ignore next */ []);
	caption = input(...ngDevMode ? [void 0, { debugName: "caption" }] : /* istanbul ignore next */ []);
	selectionType = input(...ngDevMode ? [void 0, { debugName: "selectionType" }] : /* istanbul ignore next */ []);
	selectionMode = input(...ngDevMode ? [void 0, { debugName: "selectionMode" }] : /* istanbul ignore next */ []);
	resizable = input(...ngDevMode ? [void 0, { debugName: "resizable" }] : /* istanbul ignore next */ []);
	selectionColumn = input(...ngDevMode ? [void 0, { debugName: "selectionColumn" }] : /* istanbul ignore next */ []);
	rowClickSelects = input(...ngDevMode ? [void 0, { debugName: "rowClickSelects" }] : /* istanbul ignore next */ []);
	sortable = input(...ngDevMode ? [void 0, { debugName: "sortable" }] : /* istanbul ignore next */ []);
	pinable = input(...ngDevMode ? [void 0, { debugName: "pinable" }] : /* istanbul ignore next */ []);
	hideable = input(...ngDevMode ? [void 0, { debugName: "hideable" }] : /* istanbul ignore next */ []);
	autoSizeable = input(...ngDevMode ? [void 0, { debugName: "autoSizeable" }] : /* istanbul ignore next */ []);
	columnChoosable = input(...ngDevMode ? [void 0, { debugName: "columnChoosable" }] : /* istanbul ignore next */ []);
	reorderable = input(...ngDevMode ? [void 0, { debugName: "reorderable" }] : /* istanbul ignore next */ []);
	sortMode = input(...ngDevMode ? [void 0, { debugName: "sortMode" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	appearance = input(...ngDevMode ? [void 0, { debugName: "appearance" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	source = input(...ngDevMode ? [void 0, { debugName: "source" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	tableSelectionChanged = output();
	dataTableEditorOpened = output();
	dataTableEditorClosed = output();
	dataTableSortChanged = output();
	changed = output();
	connected = output();
	disconnected = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	_accessor;
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._accessor = dataTableElementValueAccessor(this._elementRef.nativeElement);
		this._elementRef.nativeElement.addController(this._accessor);
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			tableSelectionChanged: this.tableSelectionChanged,
			dataTableEditorOpened: this.dataTableEditorOpened,
			dataTableEditorClosed: this.dataTableEditorClosed,
			dataTableSortChanged: this.dataTableSortChanged,
			changed: this.changed,
			connected: this.connected,
			disconnected: this.disconnected
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
			this._accessor.releaseCallbacks();
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(DATA_TABLE_DEFAULT_PROPS, { optional: true }) ?? {}, ["intl"]);
		const injectedIntl = inject(DATA_TABLE_INTL, { optional: true });
		if (injectedIntl) {
			Object.assign(this._elementRef.nativeElement.intl, injectedIntl);
			this._elementRef.nativeElement.intl.changes.emit();
		}
	}
	writeValue(obj) {
		this._accessor.writeValue(obj);
	}
	registerOnChange(fn) {
		this._accessor.registerOnChange(fn);
	}
	registerOnTouched(fn) {
		this._accessor.registerOnTouched(fn);
	}
	setDisabledState(isDisabled) {
		this._accessor.setDisabled?.(isDisabled);
	}
	selectAll(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "selectAll", args);
	}
	clearSelection(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "clearSelection", args);
	}
	openEditor(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "openEditor", args);
	}
	closeEditor(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "closeEditor", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const alternatingValue = this.alternating();
			if (alternatingValue !== void 0) this._elementRef.nativeElement.alternating = alternatingValue;
			const autoGenerateColumnsValue = this.autoGenerateColumns();
			if (autoGenerateColumnsValue !== void 0) this._elementRef.nativeElement.autoGenerateColumns = autoGenerateColumnsValue;
			const columnDefinitionsValue = this.columnDefinitions();
			if (columnDefinitionsValue !== void 0) this._elementRef.nativeElement.columnDefinitions = columnDefinitionsValue;
			const captionValue = this.caption();
			if (captionValue !== void 0) this._elementRef.nativeElement.caption = captionValue;
			const selectionTypeValue = this.selectionType();
			if (selectionTypeValue !== void 0) this._elementRef.nativeElement.selectionType = selectionTypeValue;
			const selectionModeValue = this.selectionMode();
			if (selectionModeValue !== void 0) this._elementRef.nativeElement.selectionMode = selectionModeValue;
			const resizableValue = this.resizable();
			if (resizableValue !== void 0) this._elementRef.nativeElement.resizable = resizableValue;
			const selectionColumnValue = this.selectionColumn();
			if (selectionColumnValue !== void 0) this._elementRef.nativeElement.selectionColumn = selectionColumnValue;
			const rowClickSelectsValue = this.rowClickSelects();
			if (rowClickSelectsValue !== void 0) this._elementRef.nativeElement.rowClickSelects = rowClickSelectsValue;
			const sortableValue = this.sortable();
			if (sortableValue !== void 0) this._elementRef.nativeElement.sortable = sortableValue;
			const pinableValue = this.pinable();
			if (pinableValue !== void 0) this._elementRef.nativeElement.pinable = pinableValue;
			const hideableValue = this.hideable();
			if (hideableValue !== void 0) this._elementRef.nativeElement.hideable = hideableValue;
			const autoSizeableValue = this.autoSizeable();
			if (autoSizeableValue !== void 0) this._elementRef.nativeElement.autoSizeable = autoSizeableValue;
			const columnChoosableValue = this.columnChoosable();
			if (columnChoosableValue !== void 0) this._elementRef.nativeElement.columnChoosable = columnChoosableValue;
			const reorderableValue = this.reorderable();
			if (reorderableValue !== void 0) this._elementRef.nativeElement.reorderable = reorderableValue;
			const sortModeValue = this.sortMode();
			if (sortModeValue !== void 0) this._elementRef.nativeElement.sortMode = sortModeValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const appearanceValue = this.appearance();
			if (appearanceValue !== void 0) this._elementRef.nativeElement.appearance = appearanceValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const sourceValue = this.source();
			if (sourceValue !== void 0) this._elementRef.nativeElement.source = sourceValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
			const intlValue = this.intl();
			if (intlValue !== void 0) {
				Object.assign(this._elementRef.nativeElement.intl, intlValue);
				this._elementRef.nativeElement.intl.changes.emit();
			}
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DataTableComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: DataTableComponent,
		isStandalone: true,
		selector: "mosaik-data-table",
		inputs: {
			intl: {
				classPropertyName: "intl",
				publicName: "intl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			alternating: {
				classPropertyName: "alternating",
				publicName: "alternating",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			autoGenerateColumns: {
				classPropertyName: "autoGenerateColumns",
				publicName: "autoGenerateColumns",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			columnDefinitions: {
				classPropertyName: "columnDefinitions",
				publicName: "columnDefinitions",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			caption: {
				classPropertyName: "caption",
				publicName: "caption",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			selectionType: {
				classPropertyName: "selectionType",
				publicName: "selectionType",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			selectionMode: {
				classPropertyName: "selectionMode",
				publicName: "selectionMode",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			resizable: {
				classPropertyName: "resizable",
				publicName: "resizable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			selectionColumn: {
				classPropertyName: "selectionColumn",
				publicName: "selectionColumn",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			rowClickSelects: {
				classPropertyName: "rowClickSelects",
				publicName: "rowClickSelects",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			sortable: {
				classPropertyName: "sortable",
				publicName: "sortable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			pinable: {
				classPropertyName: "pinable",
				publicName: "pinable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			hideable: {
				classPropertyName: "hideable",
				publicName: "hideable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			autoSizeable: {
				classPropertyName: "autoSizeable",
				publicName: "autoSizeable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			columnChoosable: {
				classPropertyName: "columnChoosable",
				publicName: "columnChoosable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			reorderable: {
				classPropertyName: "reorderable",
				publicName: "reorderable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			sortMode: {
				classPropertyName: "sortMode",
				publicName: "sortMode",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			source: {
				classPropertyName: "source",
				publicName: "source",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			tableSelectionChanged: "tableSelectionChanged",
			dataTableEditorOpened: "dataTableEditorOpened",
			dataTableEditorClosed: "dataTableEditorClosed",
			dataTableSortChanged: "dataTableSortChanged",
			changed: "changed",
			connected: "connected",
			disconnected: "disconnected"
		},
		providers: [{
			provide: NG_VALUE_ACCESSOR,
			useExisting: forwardRef(() => DataTableComponent),
			multi: true
		}, {
			provide: FORM_STATUS_HOST,
			useExisting: forwardRef(() => DataTableComponent)
		}],
		hostDirectives: [{ directive: i1.FormStatusHostDirective }, { directive: i1.FormFieldStatusHostDirective }],
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
DataTableComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-data-table", DataTableElement),
	inputs: [
		"intl",
		"alternating",
		"autoGenerateColumns",
		"columnDefinitions",
		"caption",
		"selectionType",
		"selectionMode",
		"resizable",
		"selectionColumn",
		"rowClickSelects",
		"sortable",
		"pinable",
		"hideable",
		"autoSizeable",
		"columnChoosable",
		"reorderable",
		"sortMode",
		"themeName",
		"appearance",
		"disabled",
		"source",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], DataTableComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DataTableComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-data-table",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>",
			hostDirectives: [FormStatusHostDirective, FormFieldStatusHostDirective],
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => DataTableComponent),
				multi: true
			}, {
				provide: FORM_STATUS_HOST,
				useExisting: forwardRef(() => DataTableComponent)
			}]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		intl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "intl",
				required: false
			}]
		}],
		alternating: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "alternating",
				required: false
			}]
		}],
		autoGenerateColumns: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "autoGenerateColumns",
				required: false
			}]
		}],
		columnDefinitions: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "columnDefinitions",
				required: false
			}]
		}],
		caption: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "caption",
				required: false
			}]
		}],
		selectionType: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "selectionType",
				required: false
			}]
		}],
		selectionMode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "selectionMode",
				required: false
			}]
		}],
		resizable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "resizable",
				required: false
			}]
		}],
		selectionColumn: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "selectionColumn",
				required: false
			}]
		}],
		rowClickSelects: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "rowClickSelects",
				required: false
			}]
		}],
		sortable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "sortable",
				required: false
			}]
		}],
		pinable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "pinable",
				required: false
			}]
		}],
		hideable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hideable",
				required: false
			}]
		}],
		autoSizeable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "autoSizeable",
				required: false
			}]
		}],
		columnChoosable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "columnChoosable",
				required: false
			}]
		}],
		reorderable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "reorderable",
				required: false
			}]
		}],
		sortMode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "sortMode",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		source: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "source",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		tableSelectionChanged: [{
			type: i0.Output,
			args: ["tableSelectionChanged"]
		}],
		dataTableEditorOpened: [{
			type: i0.Output,
			args: ["dataTableEditorOpened"]
		}],
		dataTableEditorClosed: [{
			type: i0.Output,
			args: ["dataTableEditorClosed"]
		}],
		dataTableSortChanged: [{
			type: i0.Output,
			args: ["dataTableSortChanged"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}]
	}
});
function provideDataTableComponent(config, intl) {
	const providers = [];
	if (config) providers.push({
		provide: DATA_TABLE_DEFAULT_PROPS,
		useValue: config
	});
	if (intl) {
		if (typeof intl === "function") providers.push({
			provide: DATA_TABLE_INTL,
			useClass: intl
		});
		else providers.push({
			provide: DATA_TABLE_INTL,
			useValue: intl
		});
	}
	return makeEnvironmentProviders(providers);
}
export { DATA_TABLE_DEFAULT_PROPS, DATA_TABLE_INTL, DataTableComponent, provideDataTableComponent };

//# sourceMappingURL=mosaik-elements-angular-components-data-table.mjs.map