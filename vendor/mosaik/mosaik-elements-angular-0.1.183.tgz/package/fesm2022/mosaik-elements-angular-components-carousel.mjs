import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { CarouselItemElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/carousel/CarouselItemElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { CarouselElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/carousel/CarouselElement";
var __decorate$1 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$1 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const CAROUSEL_ITEM_DEFAULT_PROPS = new InjectionToken("MOSAIK_CAROUSEL_ITEM_DEFAULT_PROPS");
let CarouselItemComponent = class CarouselItemComponent {
	timeout = input(...ngDevMode ? [void 0, { debugName: "timeout" }] : /* istanbul ignore next */ []);
	isDismissed = input(...ngDevMode ? [void 0, { debugName: "isDismissed" }] : /* istanbul ignore next */ []);
	isActive = input(...ngDevMode ? [void 0, { debugName: "isActive" }] : /* istanbul ignore next */ []);
	dismissDirection = input(...ngDevMode ? [void 0, { debugName: "dismissDirection" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	isSelected = input(...ngDevMode ? [void 0, { debugName: "isSelected" }] : /* istanbul ignore next */ []);
	value = input(...ngDevMode ? [void 0, { debugName: "value" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	selected = output();
	deselected = output();
	changed = output();
	connected = output();
	disconnected = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			selected: this.selected,
			deselected: this.deselected,
			changed: this.changed,
			connected: this.connected,
			disconnected: this.disconnected
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(CAROUSEL_ITEM_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	select(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "select", args);
	}
	deselect(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "deselect", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const timeoutValue = this.timeout();
			if (timeoutValue !== void 0) this._elementRef.nativeElement.timeout = timeoutValue;
			const isDismissedValue = this.isDismissed();
			if (isDismissedValue !== void 0) this._elementRef.nativeElement.isDismissed = isDismissedValue;
			const isActiveValue = this.isActive();
			if (isActiveValue !== void 0) this._elementRef.nativeElement.isActive = isActiveValue;
			const dismissDirectionValue = this.dismissDirection();
			if (dismissDirectionValue !== void 0) this._elementRef.nativeElement.dismissDirection = dismissDirectionValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const isSelectedValue = this.isSelected();
			if (isSelectedValue !== void 0) this._elementRef.nativeElement.isSelected = isSelectedValue;
			const valueValue = this.value();
			if (valueValue !== void 0) this._elementRef.nativeElement.value = valueValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: CarouselItemComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: CarouselItemComponent,
		isStandalone: true,
		selector: "mosaik-carousel-item",
		inputs: {
			timeout: {
				classPropertyName: "timeout",
				publicName: "timeout",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isDismissed: {
				classPropertyName: "isDismissed",
				publicName: "isDismissed",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isActive: {
				classPropertyName: "isActive",
				publicName: "isActive",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dismissDirection: {
				classPropertyName: "dismissDirection",
				publicName: "dismissDirection",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isSelected: {
				classPropertyName: "isSelected",
				publicName: "isSelected",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			selected: "selected",
			deselected: "deselected",
			changed: "changed",
			connected: "connected",
			disconnected: "disconnected"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
CarouselItemComponent = __decorate$1([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-carousel-item", CarouselItemElement),
	inputs: [
		"timeout",
		"isDismissed",
		"isActive",
		"dismissDirection",
		"themeName",
		"disabled",
		"isSelected",
		"value",
		"dir",
		"lang"
	]
}), __metadata$1("design:paramtypes", [])], CarouselItemComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: CarouselItemComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-carousel-item",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		timeout: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "timeout",
				required: false
			}]
		}],
		isDismissed: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isDismissed",
				required: false
			}]
		}],
		isActive: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isActive",
				required: false
			}]
		}],
		dismissDirection: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dismissDirection",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		isSelected: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isSelected",
				required: false
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		selected: [{
			type: i0.Output,
			args: ["selected"]
		}],
		deselected: [{
			type: i0.Output,
			args: ["deselected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}]
	}
});
function provideCarouselItemComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: CAROUSEL_ITEM_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const CAROUSEL_DEFAULT_PROPS = new InjectionToken("MOSAIK_CAROUSEL_DEFAULT_PROPS");
let CarouselComponent = class CarouselComponent {
	intl = input(...ngDevMode ? [void 0, { debugName: "intl" }] : /* istanbul ignore next */ []);
	autoplay = input(...ngDevMode ? [void 0, { debugName: "autoplay" }] : /* istanbul ignore next */ []);
	timeout = input(...ngDevMode ? [void 0, { debugName: "timeout" }] : /* istanbul ignore next */ []);
	showNavigation = input(...ngDevMode ? [void 0, { debugName: "showNavigation" }] : /* istanbul ignore next */ []);
	showIndicator = input(...ngDevMode ? [void 0, { debugName: "showIndicator" }] : /* istanbul ignore next */ []);
	indicatorMode = input(...ngDevMode ? [void 0, { debugName: "indicatorMode" }] : /* istanbul ignore next */ []);
	slideAlignment = input(...ngDevMode ? [void 0, { debugName: "slideAlignment" }] : /* istanbul ignore next */ []);
	loop = input(...ngDevMode ? [void 0, { debugName: "loop" }] : /* istanbul ignore next */ []);
	navigationPosition = input(...ngDevMode ? [void 0, { debugName: "navigationPosition" }] : /* istanbul ignore next */ []);
	displayMode = input(...ngDevMode ? [void 0, { debugName: "displayMode" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	appearance = input(...ngDevMode ? [void 0, { debugName: "appearance" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	selectionChanged = output();
	itemsChanged = output();
	changed = output();
	connected = output();
	disconnected = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			selectionChanged: this.selectionChanged,
			itemsChanged: this.itemsChanged,
			changed: this.changed,
			connected: this.connected,
			disconnected: this.disconnected
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(CAROUSEL_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	start(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "start", args);
	}
	stop(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "stop", args);
	}
	pause(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "pause", args);
	}
	resume(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "resume", args);
	}
	select(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "select", args);
	}
	selectNext(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "selectNext", args);
	}
	selectPrevious(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "selectPrevious", args);
	}
	selectFirst(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "selectFirst", args);
	}
	selectLast(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "selectLast", args);
	}
	deselect(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "deselect", args);
	}
	resetSelection(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "resetSelection", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const autoplayValue = this.autoplay();
			if (autoplayValue !== void 0) this._elementRef.nativeElement.autoplay = autoplayValue;
			const timeoutValue = this.timeout();
			if (timeoutValue !== void 0) this._elementRef.nativeElement.timeout = timeoutValue;
			const showNavigationValue = this.showNavigation();
			if (showNavigationValue !== void 0) this._elementRef.nativeElement.showNavigation = showNavigationValue;
			const showIndicatorValue = this.showIndicator();
			if (showIndicatorValue !== void 0) this._elementRef.nativeElement.showIndicator = showIndicatorValue;
			const indicatorModeValue = this.indicatorMode();
			if (indicatorModeValue !== void 0) this._elementRef.nativeElement.indicatorMode = indicatorModeValue;
			const slideAlignmentValue = this.slideAlignment();
			if (slideAlignmentValue !== void 0) this._elementRef.nativeElement.slideAlignment = slideAlignmentValue;
			const loopValue = this.loop();
			if (loopValue !== void 0) this._elementRef.nativeElement.loop = loopValue;
			const navigationPositionValue = this.navigationPosition();
			if (navigationPositionValue !== void 0) this._elementRef.nativeElement.navigationPosition = navigationPositionValue;
			const displayModeValue = this.displayMode();
			if (displayModeValue !== void 0) this._elementRef.nativeElement.displayMode = displayModeValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const appearanceValue = this.appearance();
			if (appearanceValue !== void 0) this._elementRef.nativeElement.appearance = appearanceValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: CarouselComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: CarouselComponent,
		isStandalone: true,
		selector: "mosaik-carousel",
		inputs: {
			intl: {
				classPropertyName: "intl",
				publicName: "intl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			autoplay: {
				classPropertyName: "autoplay",
				publicName: "autoplay",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			timeout: {
				classPropertyName: "timeout",
				publicName: "timeout",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showNavigation: {
				classPropertyName: "showNavigation",
				publicName: "showNavigation",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showIndicator: {
				classPropertyName: "showIndicator",
				publicName: "showIndicator",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			indicatorMode: {
				classPropertyName: "indicatorMode",
				publicName: "indicatorMode",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			slideAlignment: {
				classPropertyName: "slideAlignment",
				publicName: "slideAlignment",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			loop: {
				classPropertyName: "loop",
				publicName: "loop",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			navigationPosition: {
				classPropertyName: "navigationPosition",
				publicName: "navigationPosition",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			displayMode: {
				classPropertyName: "displayMode",
				publicName: "displayMode",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			selectionChanged: "selectionChanged",
			itemsChanged: "itemsChanged",
			changed: "changed",
			connected: "connected",
			disconnected: "disconnected"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
CarouselComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-carousel", CarouselElement),
	inputs: [
		"intl",
		"autoplay",
		"timeout",
		"showNavigation",
		"showIndicator",
		"indicatorMode",
		"slideAlignment",
		"loop",
		"navigationPosition",
		"displayMode",
		"themeName",
		"disabled",
		"appearance",
		"variant",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], CarouselComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: CarouselComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-carousel",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		intl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "intl",
				required: false
			}]
		}],
		autoplay: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "autoplay",
				required: false
			}]
		}],
		timeout: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "timeout",
				required: false
			}]
		}],
		showNavigation: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showNavigation",
				required: false
			}]
		}],
		showIndicator: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showIndicator",
				required: false
			}]
		}],
		indicatorMode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "indicatorMode",
				required: false
			}]
		}],
		slideAlignment: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "slideAlignment",
				required: false
			}]
		}],
		loop: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "loop",
				required: false
			}]
		}],
		navigationPosition: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "navigationPosition",
				required: false
			}]
		}],
		displayMode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "displayMode",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		selectionChanged: [{
			type: i0.Output,
			args: ["selectionChanged"]
		}],
		itemsChanged: [{
			type: i0.Output,
			args: ["itemsChanged"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}]
	}
});
function provideCarouselComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: CAROUSEL_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { CAROUSEL_DEFAULT_PROPS, CAROUSEL_ITEM_DEFAULT_PROPS, CarouselComponent, CarouselItemComponent, provideCarouselComponent, provideCarouselItemComponent };

//# sourceMappingURL=mosaik-elements-angular-components-carousel.mjs.map