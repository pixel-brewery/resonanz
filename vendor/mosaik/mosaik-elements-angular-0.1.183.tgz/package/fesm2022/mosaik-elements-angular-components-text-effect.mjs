import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { TextEffectElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/illustrations/text-effect/TextEffectElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const TEXT_EFFECT_DEFAULT_PROPS = new InjectionToken("MOSAIK_TEXT_EFFECT_DEFAULT_PROPS");
let TextEffectComponent = class TextEffectComponent {
	effect = input(...ngDevMode ? [void 0, { debugName: "effect" }] : /* istanbul ignore next */ []);
	text = input(...ngDevMode ? [void 0, { debugName: "text" }] : /* istanbul ignore next */ []);
	words = input(...ngDevMode ? [void 0, { debugName: "words" }] : /* istanbul ignore next */ []);
	interval = input(...ngDevMode ? [void 0, { debugName: "interval" }] : /* istanbul ignore next */ []);
	label = input(...ngDevMode ? [void 0, { debugName: "label" }] : /* istanbul ignore next */ []);
	mediaSource = input(...ngDevMode ? [void 0, { debugName: "mediaSource" }] : /* istanbul ignore next */ []);
	mediaKind = input(...ngDevMode ? [void 0, { debugName: "mediaKind" }] : /* istanbul ignore next */ []);
	poster = input(...ngDevMode ? [void 0, { debugName: "poster" }] : /* istanbul ignore next */ []);
	reverse = input(...ngDevMode ? [void 0, { debugName: "reverse" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(TEXT_EFFECT_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const effectValue = this.effect();
			if (effectValue !== void 0) this._elementRef.nativeElement.effect = effectValue;
			const textValue = this.text();
			if (textValue !== void 0) this._elementRef.nativeElement.text = textValue;
			const wordsValue = this.words();
			if (wordsValue !== void 0) this._elementRef.nativeElement.words = wordsValue;
			const intervalValue = this.interval();
			if (intervalValue !== void 0) this._elementRef.nativeElement.interval = intervalValue;
			const labelValue = this.label();
			if (labelValue !== void 0) this._elementRef.nativeElement.label = labelValue;
			const mediaSourceValue = this.mediaSource();
			if (mediaSourceValue !== void 0) this._elementRef.nativeElement.mediaSource = mediaSourceValue;
			const mediaKindValue = this.mediaKind();
			if (mediaKindValue !== void 0) this._elementRef.nativeElement.mediaKind = mediaKindValue;
			const posterValue = this.poster();
			if (posterValue !== void 0) this._elementRef.nativeElement.poster = posterValue;
			const reverseValue = this.reverse();
			if (reverseValue !== void 0) this._elementRef.nativeElement.reverse = reverseValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: TextEffectComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: TextEffectComponent,
		isStandalone: true,
		selector: "mosaik-text-effect",
		inputs: {
			effect: {
				classPropertyName: "effect",
				publicName: "effect",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			text: {
				classPropertyName: "text",
				publicName: "text",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			words: {
				classPropertyName: "words",
				publicName: "words",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			interval: {
				classPropertyName: "interval",
				publicName: "interval",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			mediaSource: {
				classPropertyName: "mediaSource",
				publicName: "mediaSource",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			mediaKind: {
				classPropertyName: "mediaKind",
				publicName: "mediaKind",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			poster: {
				classPropertyName: "poster",
				publicName: "poster",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			reverse: {
				classPropertyName: "reverse",
				publicName: "reverse",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
TextEffectComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-text-effect", TextEffectElement),
	inputs: [
		"effect",
		"text",
		"words",
		"interval",
		"label",
		"mediaSource",
		"mediaKind",
		"poster",
		"reverse",
		"themeName",
		"variant",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], TextEffectComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: TextEffectComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-text-effect",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		effect: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "effect",
				required: false
			}]
		}],
		text: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "text",
				required: false
			}]
		}],
		words: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "words",
				required: false
			}]
		}],
		interval: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "interval",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		mediaSource: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mediaSource",
				required: false
			}]
		}],
		mediaKind: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mediaKind",
				required: false
			}]
		}],
		poster: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "poster",
				required: false
			}]
		}],
		reverse: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "reverse",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideTextEffectComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: TEXT_EFFECT_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { TEXT_EFFECT_DEFAULT_PROPS, TextEffectComponent, provideTextEffectComponent };

//# sourceMappingURL=mosaik-elements-angular-components-text-effect.mjs.map