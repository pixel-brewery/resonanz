import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { NumberCounterElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/number/NumberCounterElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { NumberElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/number/NumberElement";
var __decorate$1 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$1 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const NUMBER_COUNTER_DEFAULT_PROPS = new InjectionToken("MOSAIK_NUMBER_COUNTER_DEFAULT_PROPS");
let NumberCounterComponent = class NumberCounterComponent {
	from = input(...ngDevMode ? [void 0, { debugName: "from" }] : /* istanbul ignore next */ []);
	to = input(...ngDevMode ? [void 0, { debugName: "to" }] : /* istanbul ignore next */ []);
	duration = input(...ngDevMode ? [void 0, { debugName: "duration" }] : /* istanbul ignore next */ []);
	readonly = input(...ngDevMode ? [void 0, { debugName: "readonly" }] : /* istanbul ignore next */ []);
	alignment = input(...ngDevMode ? [void 0, { debugName: "alignment" }] : /* istanbul ignore next */ []);
	decimals = input(...ngDevMode ? [void 0, { debugName: "decimals" }] : /* istanbul ignore next */ []);
	grouping = input(...ngDevMode ? [void 0, { debugName: "grouping" }] : /* istanbul ignore next */ []);
	locale = input(...ngDevMode ? [void 0, { debugName: "locale" }] : /* istanbul ignore next */ []);
	prefixText = input(...ngDevMode ? [void 0, { debugName: "prefixText" }] : /* istanbul ignore next */ []);
	suffixText = input(...ngDevMode ? [void 0, { debugName: "suffixText" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(NUMBER_COUNTER_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	format(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "format", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const fromValue = this.from();
			if (fromValue !== void 0) this._elementRef.nativeElement.from = fromValue;
			const toValue = this.to();
			if (toValue !== void 0) this._elementRef.nativeElement.to = toValue;
			const durationValue = this.duration();
			if (durationValue !== void 0) this._elementRef.nativeElement.duration = durationValue;
			const readonlyValue = this.readonly();
			if (readonlyValue !== void 0) this._elementRef.nativeElement.readonly = readonlyValue;
			const alignmentValue = this.alignment();
			if (alignmentValue !== void 0) this._elementRef.nativeElement.alignment = alignmentValue;
			const decimalsValue = this.decimals();
			if (decimalsValue !== void 0) this._elementRef.nativeElement.decimals = decimalsValue;
			const groupingValue = this.grouping();
			if (groupingValue !== void 0) this._elementRef.nativeElement.grouping = groupingValue;
			const localeValue = this.locale();
			if (localeValue !== void 0) this._elementRef.nativeElement.locale = localeValue;
			const prefixTextValue = this.prefixText();
			if (prefixTextValue !== void 0) this._elementRef.nativeElement.prefixText = prefixTextValue;
			const suffixTextValue = this.suffixText();
			if (suffixTextValue !== void 0) this._elementRef.nativeElement.suffixText = suffixTextValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NumberCounterComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: NumberCounterComponent,
		isStandalone: true,
		selector: "mosaik-number-counter",
		inputs: {
			from: {
				classPropertyName: "from",
				publicName: "from",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			to: {
				classPropertyName: "to",
				publicName: "to",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			duration: {
				classPropertyName: "duration",
				publicName: "duration",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			readonly: {
				classPropertyName: "readonly",
				publicName: "readonly",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			alignment: {
				classPropertyName: "alignment",
				publicName: "alignment",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			decimals: {
				classPropertyName: "decimals",
				publicName: "decimals",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			grouping: {
				classPropertyName: "grouping",
				publicName: "grouping",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			locale: {
				classPropertyName: "locale",
				publicName: "locale",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			prefixText: {
				classPropertyName: "prefixText",
				publicName: "prefixText",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			suffixText: {
				classPropertyName: "suffixText",
				publicName: "suffixText",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
NumberCounterComponent = __decorate$1([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-number-counter", NumberCounterElement),
	inputs: [
		"from",
		"to",
		"duration",
		"readonly",
		"alignment",
		"decimals",
		"grouping",
		"locale",
		"prefixText",
		"suffixText",
		"themeName",
		"variant",
		"disabled",
		"dir",
		"lang"
	]
}), __metadata$1("design:paramtypes", [])], NumberCounterComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NumberCounterComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-number-counter",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		from: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "from",
				required: false
			}]
		}],
		to: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "to",
				required: false
			}]
		}],
		duration: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "duration",
				required: false
			}]
		}],
		readonly: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "readonly",
				required: false
			}]
		}],
		alignment: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "alignment",
				required: false
			}]
		}],
		decimals: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "decimals",
				required: false
			}]
		}],
		grouping: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "grouping",
				required: false
			}]
		}],
		locale: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "locale",
				required: false
			}]
		}],
		prefixText: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "prefixText",
				required: false
			}]
		}],
		suffixText: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "suffixText",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideNumberCounterComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: NUMBER_COUNTER_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const NUMBER_DEFAULT_PROPS = new InjectionToken("MOSAIK_NUMBER_DEFAULT_PROPS");
let NumberComponent = class NumberComponent {
	number = input(...ngDevMode ? [void 0, { debugName: "number" }] : /* istanbul ignore next */ []);
	readonly = input(...ngDevMode ? [void 0, { debugName: "readonly" }] : /* istanbul ignore next */ []);
	alignment = input(...ngDevMode ? [void 0, { debugName: "alignment" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(NUMBER_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const numberValue = this.number();
			if (numberValue !== void 0) this._elementRef.nativeElement.number = numberValue;
			const readonlyValue = this.readonly();
			if (readonlyValue !== void 0) this._elementRef.nativeElement.readonly = readonlyValue;
			const alignmentValue = this.alignment();
			if (alignmentValue !== void 0) this._elementRef.nativeElement.alignment = alignmentValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NumberComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: NumberComponent,
		isStandalone: true,
		selector: "mosaik-number",
		inputs: {
			number: {
				classPropertyName: "number",
				publicName: "number",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			readonly: {
				classPropertyName: "readonly",
				publicName: "readonly",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			alignment: {
				classPropertyName: "alignment",
				publicName: "alignment",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
NumberComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-number", NumberElement),
	inputs: [
		"number",
		"readonly",
		"alignment",
		"themeName",
		"variant",
		"disabled",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], NumberComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NumberComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-number",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		number: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "number",
				required: false
			}]
		}],
		readonly: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "readonly",
				required: false
			}]
		}],
		alignment: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "alignment",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideNumberComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: NUMBER_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { NUMBER_COUNTER_DEFAULT_PROPS, NUMBER_DEFAULT_PROPS, NumberComponent, NumberCounterComponent, provideNumberComponent, provideNumberCounterComponent };

//# sourceMappingURL=mosaik-elements-angular-components-number.mjs.map