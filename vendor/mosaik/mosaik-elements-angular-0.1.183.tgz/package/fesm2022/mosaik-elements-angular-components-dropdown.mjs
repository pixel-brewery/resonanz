import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { DropdownAnchorElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/dropdown/DropdownAnchorElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { DropdownPanelElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/dropdown/DropdownPanelElement";
import { DropdownElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/dropdown/DropdownElement";
var __decorate$2 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$2 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const DROPDOWN_ANCHOR_DEFAULT_PROPS = new InjectionToken("MOSAIK_DROPDOWN_ANCHOR_DEFAULT_PROPS");
let DropdownAnchorComponent = class DropdownAnchorComponent {
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(DROPDOWN_ANCHOR_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DropdownAnchorComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: DropdownAnchorComponent,
		isStandalone: true,
		selector: "mosaik-dropdown-anchor",
		inputs: {
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
DropdownAnchorComponent = __decorate$2([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-dropdown-anchor", DropdownAnchorElement),
	inputs: [
		"themeName",
		"dir",
		"lang"
	]
}), __metadata$2("design:paramtypes", [])], DropdownAnchorComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DropdownAnchorComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-dropdown-anchor",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideDropdownAnchorComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: DROPDOWN_ANCHOR_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$1 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$1 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const DROPDOWN_PANEL_DEFAULT_PROPS = new InjectionToken("MOSAIK_DROPDOWN_PANEL_DEFAULT_PROPS");
let DropdownPanelComponent = class DropdownPanelComponent {
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(DROPDOWN_PANEL_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DropdownPanelComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: DropdownPanelComponent,
		isStandalone: true,
		selector: "mosaik-dropdown-panel",
		inputs: {
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
DropdownPanelComponent = __decorate$1([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-dropdown-panel", DropdownPanelElement),
	inputs: [
		"themeName",
		"dir",
		"lang"
	]
}), __metadata$1("design:paramtypes", [])], DropdownPanelComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DropdownPanelComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-dropdown-panel",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideDropdownPanelComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: DROPDOWN_PANEL_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const DROPDOWN_DEFAULT_PROPS = new InjectionToken("MOSAIK_DROPDOWN_DEFAULT_PROPS");
let DropdownComponent = class DropdownComponent {
	placement = input(...ngDevMode ? [void 0, { debugName: "placement" }] : /* istanbul ignore next */ []);
	strategy = input(...ngDevMode ? [void 0, { debugName: "strategy" }] : /* istanbul ignore next */ []);
	offset = input(...ngDevMode ? [void 0, { debugName: "offset" }] : /* istanbul ignore next */ []);
	skidding = input(...ngDevMode ? [void 0, { debugName: "skidding" }] : /* istanbul ignore next */ []);
	open = input(...ngDevMode ? [void 0, { debugName: "open" }] : /* istanbul ignore next */ []);
	trigger = input(...ngDevMode ? [void 0, { debugName: "trigger" }] : /* istanbul ignore next */ []);
	closeOnOutsideClick = input(...ngDevMode ? [void 0, { debugName: "closeOnOutsideClick" }] : /* istanbul ignore next */ []);
	closeOnEscape = input(...ngDevMode ? [void 0, { debugName: "closeOnEscape" }] : /* istanbul ignore next */ []);
	closeOnSelect = input(...ngDevMode ? [void 0, { debugName: "closeOnSelect" }] : /* istanbul ignore next */ []);
	restoreFocus = input(...ngDevMode ? [void 0, { debugName: "restoreFocus" }] : /* istanbul ignore next */ []);
	hasPopup = input(...ngDevMode ? [void 0, { debugName: "hasPopup" }] : /* istanbul ignore next */ []);
	matchAnchorWidth = input(...ngDevMode ? [void 0, { debugName: "matchAnchorWidth" }] : /* istanbul ignore next */ []);
	maxHeight = input(...ngDevMode ? [void 0, { debugName: "maxHeight" }] : /* istanbul ignore next */ []);
	height = input(...ngDevMode ? [void 0, { debugName: "height" }] : /* istanbul ignore next */ []);
	width = input(...ngDevMode ? [void 0, { debugName: "width" }] : /* istanbul ignore next */ []);
	maxWidth = input(...ngDevMode ? [void 0, { debugName: "maxWidth" }] : /* istanbul ignore next */ []);
	dropDownPlacement = input(...ngDevMode ? [void 0, { debugName: "dropDownPlacement" }] : /* istanbul ignore next */ []);
	dropDownStrategy = input(...ngDevMode ? [void 0, { debugName: "dropDownStrategy" }] : /* istanbul ignore next */ []);
	dropDownDistance = input(...ngDevMode ? [void 0, { debugName: "dropDownDistance" }] : /* istanbul ignore next */ []);
	dropDownSkidding = input(...ngDevMode ? [void 0, { debugName: "dropDownSkidding" }] : /* istanbul ignore next */ []);
	dropDownStaysOpen = input(...ngDevMode ? [void 0, { debugName: "dropDownStaysOpen" }] : /* istanbul ignore next */ []);
	dropDownMaxHeight = input(...ngDevMode ? [void 0, { debugName: "dropDownMaxHeight" }] : /* istanbul ignore next */ []);
	dropDownHeight = input(...ngDevMode ? [void 0, { debugName: "dropDownHeight" }] : /* istanbul ignore next */ []);
	dropDownMaxWidth = input(...ngDevMode ? [void 0, { debugName: "dropDownMaxWidth" }] : /* istanbul ignore next */ []);
	dropDownWidth = input(...ngDevMode ? [void 0, { debugName: "dropDownWidth" }] : /* istanbul ignore next */ []);
	isDropDownOpen = input(...ngDevMode ? [void 0, { debugName: "isDropDownOpen" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	enter = input(...ngDevMode ? [void 0, { debugName: "enter" }] : /* istanbul ignore next */ []);
	exit = input(...ngDevMode ? [void 0, { debugName: "exit" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	openChanged = output();
	slotchange = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			openChanged: this.openChanged,
			slotchange: this.slotchange,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(DROPDOWN_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	openDropdown(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "openDropdown", args);
	}
	closeDropdown(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "closeDropdown", args);
	}
	toggleDropdown(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "toggleDropdown", args);
	}
	updatePosition(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "updatePosition", args);
	}
	play(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "play", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const placementValue = this.placement();
			if (placementValue !== void 0) this._elementRef.nativeElement.placement = placementValue;
			const strategyValue = this.strategy();
			if (strategyValue !== void 0) this._elementRef.nativeElement.strategy = strategyValue;
			const offsetValue = this.offset();
			if (offsetValue !== void 0) this._elementRef.nativeElement.offset = offsetValue;
			const skiddingValue = this.skidding();
			if (skiddingValue !== void 0) this._elementRef.nativeElement.skidding = skiddingValue;
			const openValue = this.open();
			if (openValue !== void 0) this._elementRef.nativeElement.open = openValue;
			const triggerValue = this.trigger();
			if (triggerValue !== void 0) this._elementRef.nativeElement.trigger = triggerValue;
			const closeOnOutsideClickValue = this.closeOnOutsideClick();
			if (closeOnOutsideClickValue !== void 0) this._elementRef.nativeElement.closeOnOutsideClick = closeOnOutsideClickValue;
			const closeOnEscapeValue = this.closeOnEscape();
			if (closeOnEscapeValue !== void 0) this._elementRef.nativeElement.closeOnEscape = closeOnEscapeValue;
			const closeOnSelectValue = this.closeOnSelect();
			if (closeOnSelectValue !== void 0) this._elementRef.nativeElement.closeOnSelect = closeOnSelectValue;
			const restoreFocusValue = this.restoreFocus();
			if (restoreFocusValue !== void 0) this._elementRef.nativeElement.restoreFocus = restoreFocusValue;
			const hasPopupValue = this.hasPopup();
			if (hasPopupValue !== void 0) this._elementRef.nativeElement.hasPopup = hasPopupValue;
			const matchAnchorWidthValue = this.matchAnchorWidth();
			if (matchAnchorWidthValue !== void 0) this._elementRef.nativeElement.matchAnchorWidth = matchAnchorWidthValue;
			const maxHeightValue = this.maxHeight();
			if (maxHeightValue !== void 0) this._elementRef.nativeElement.maxHeight = maxHeightValue;
			const heightValue = this.height();
			if (heightValue !== void 0) this._elementRef.nativeElement.height = heightValue;
			const widthValue = this.width();
			if (widthValue !== void 0) this._elementRef.nativeElement.width = widthValue;
			const maxWidthValue = this.maxWidth();
			if (maxWidthValue !== void 0) this._elementRef.nativeElement.maxWidth = maxWidthValue;
			const dropDownPlacementValue = this.dropDownPlacement();
			if (dropDownPlacementValue !== void 0) this._elementRef.nativeElement.dropDownPlacement = dropDownPlacementValue;
			const dropDownStrategyValue = this.dropDownStrategy();
			if (dropDownStrategyValue !== void 0) this._elementRef.nativeElement.dropDownStrategy = dropDownStrategyValue;
			const dropDownDistanceValue = this.dropDownDistance();
			if (dropDownDistanceValue !== void 0) this._elementRef.nativeElement.dropDownDistance = dropDownDistanceValue;
			const dropDownSkiddingValue = this.dropDownSkidding();
			if (dropDownSkiddingValue !== void 0) this._elementRef.nativeElement.dropDownSkidding = dropDownSkiddingValue;
			const dropDownStaysOpenValue = this.dropDownStaysOpen();
			if (dropDownStaysOpenValue !== void 0) this._elementRef.nativeElement.dropDownStaysOpen = dropDownStaysOpenValue;
			const dropDownMaxHeightValue = this.dropDownMaxHeight();
			if (dropDownMaxHeightValue !== void 0) this._elementRef.nativeElement.dropDownMaxHeight = dropDownMaxHeightValue;
			const dropDownHeightValue = this.dropDownHeight();
			if (dropDownHeightValue !== void 0) this._elementRef.nativeElement.dropDownHeight = dropDownHeightValue;
			const dropDownMaxWidthValue = this.dropDownMaxWidth();
			if (dropDownMaxWidthValue !== void 0) this._elementRef.nativeElement.dropDownMaxWidth = dropDownMaxWidthValue;
			const dropDownWidthValue = this.dropDownWidth();
			if (dropDownWidthValue !== void 0) this._elementRef.nativeElement.dropDownWidth = dropDownWidthValue;
			const isDropDownOpenValue = this.isDropDownOpen();
			if (isDropDownOpenValue !== void 0) this._elementRef.nativeElement.isDropDownOpen = isDropDownOpenValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const enterValue = this.enter();
			if (enterValue !== void 0) this._elementRef.nativeElement.enter = enterValue;
			const exitValue = this.exit();
			if (exitValue !== void 0) this._elementRef.nativeElement.exit = exitValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DropdownComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: DropdownComponent,
		isStandalone: true,
		selector: "mosaik-dropdown",
		inputs: {
			placement: {
				classPropertyName: "placement",
				publicName: "placement",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			strategy: {
				classPropertyName: "strategy",
				publicName: "strategy",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			offset: {
				classPropertyName: "offset",
				publicName: "offset",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			skidding: {
				classPropertyName: "skidding",
				publicName: "skidding",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			open: {
				classPropertyName: "open",
				publicName: "open",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			trigger: {
				classPropertyName: "trigger",
				publicName: "trigger",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			closeOnOutsideClick: {
				classPropertyName: "closeOnOutsideClick",
				publicName: "closeOnOutsideClick",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			closeOnEscape: {
				classPropertyName: "closeOnEscape",
				publicName: "closeOnEscape",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			closeOnSelect: {
				classPropertyName: "closeOnSelect",
				publicName: "closeOnSelect",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			restoreFocus: {
				classPropertyName: "restoreFocus",
				publicName: "restoreFocus",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			hasPopup: {
				classPropertyName: "hasPopup",
				publicName: "hasPopup",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			matchAnchorWidth: {
				classPropertyName: "matchAnchorWidth",
				publicName: "matchAnchorWidth",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			maxHeight: {
				classPropertyName: "maxHeight",
				publicName: "maxHeight",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			height: {
				classPropertyName: "height",
				publicName: "height",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			width: {
				classPropertyName: "width",
				publicName: "width",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			maxWidth: {
				classPropertyName: "maxWidth",
				publicName: "maxWidth",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownPlacement: {
				classPropertyName: "dropDownPlacement",
				publicName: "dropDownPlacement",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownStrategy: {
				classPropertyName: "dropDownStrategy",
				publicName: "dropDownStrategy",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownDistance: {
				classPropertyName: "dropDownDistance",
				publicName: "dropDownDistance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownSkidding: {
				classPropertyName: "dropDownSkidding",
				publicName: "dropDownSkidding",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownStaysOpen: {
				classPropertyName: "dropDownStaysOpen",
				publicName: "dropDownStaysOpen",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownMaxHeight: {
				classPropertyName: "dropDownMaxHeight",
				publicName: "dropDownMaxHeight",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownHeight: {
				classPropertyName: "dropDownHeight",
				publicName: "dropDownHeight",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownMaxWidth: {
				classPropertyName: "dropDownMaxWidth",
				publicName: "dropDownMaxWidth",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownWidth: {
				classPropertyName: "dropDownWidth",
				publicName: "dropDownWidth",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isDropDownOpen: {
				classPropertyName: "isDropDownOpen",
				publicName: "isDropDownOpen",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			enter: {
				classPropertyName: "enter",
				publicName: "enter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			exit: {
				classPropertyName: "exit",
				publicName: "exit",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			openChanged: "openChanged",
			slotchange: "slotchange",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
DropdownComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-dropdown", DropdownElement),
	inputs: [
		"placement",
		"strategy",
		"offset",
		"skidding",
		"open",
		"trigger",
		"closeOnOutsideClick",
		"closeOnEscape",
		"closeOnSelect",
		"restoreFocus",
		"hasPopup",
		"matchAnchorWidth",
		"maxHeight",
		"height",
		"width",
		"maxWidth",
		"dropDownPlacement",
		"dropDownStrategy",
		"dropDownDistance",
		"dropDownSkidding",
		"dropDownStaysOpen",
		"dropDownMaxHeight",
		"dropDownHeight",
		"dropDownMaxWidth",
		"dropDownWidth",
		"isDropDownOpen",
		"themeName",
		"enter",
		"exit",
		"disabled",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], DropdownComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DropdownComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-dropdown",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		placement: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "placement",
				required: false
			}]
		}],
		strategy: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "strategy",
				required: false
			}]
		}],
		offset: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "offset",
				required: false
			}]
		}],
		skidding: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "skidding",
				required: false
			}]
		}],
		open: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "open",
				required: false
			}]
		}],
		trigger: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "trigger",
				required: false
			}]
		}],
		closeOnOutsideClick: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "closeOnOutsideClick",
				required: false
			}]
		}],
		closeOnEscape: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "closeOnEscape",
				required: false
			}]
		}],
		closeOnSelect: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "closeOnSelect",
				required: false
			}]
		}],
		restoreFocus: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "restoreFocus",
				required: false
			}]
		}],
		hasPopup: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hasPopup",
				required: false
			}]
		}],
		matchAnchorWidth: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "matchAnchorWidth",
				required: false
			}]
		}],
		maxHeight: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maxHeight",
				required: false
			}]
		}],
		height: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "height",
				required: false
			}]
		}],
		width: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "width",
				required: false
			}]
		}],
		maxWidth: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maxWidth",
				required: false
			}]
		}],
		dropDownPlacement: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownPlacement",
				required: false
			}]
		}],
		dropDownStrategy: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownStrategy",
				required: false
			}]
		}],
		dropDownDistance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownDistance",
				required: false
			}]
		}],
		dropDownSkidding: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownSkidding",
				required: false
			}]
		}],
		dropDownStaysOpen: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownStaysOpen",
				required: false
			}]
		}],
		dropDownMaxHeight: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownMaxHeight",
				required: false
			}]
		}],
		dropDownHeight: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownHeight",
				required: false
			}]
		}],
		dropDownMaxWidth: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownMaxWidth",
				required: false
			}]
		}],
		dropDownWidth: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownWidth",
				required: false
			}]
		}],
		isDropDownOpen: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isDropDownOpen",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		enter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "enter",
				required: false
			}]
		}],
		exit: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "exit",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		openChanged: [{
			type: i0.Output,
			args: ["openChanged"]
		}],
		slotchange: [{
			type: i0.Output,
			args: ["slotchange"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideDropdownComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: DROPDOWN_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { DROPDOWN_ANCHOR_DEFAULT_PROPS, DROPDOWN_DEFAULT_PROPS, DROPDOWN_PANEL_DEFAULT_PROPS, DropdownAnchorComponent, DropdownComponent, DropdownPanelComponent, provideDropdownAnchorComponent, provideDropdownComponent, provideDropdownPanelComponent };

//# sourceMappingURL=mosaik-elements-angular-components-dropdown.mjs.map