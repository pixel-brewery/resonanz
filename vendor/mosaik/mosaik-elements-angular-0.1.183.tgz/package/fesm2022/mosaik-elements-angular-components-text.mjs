import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { TextElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/text/TextElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const TEXT_DEFAULT_PROPS = new InjectionToken("MOSAIK_TEXT_DEFAULT_PROPS");
let TextComponent = class TextComponent {
	text = input(...ngDevMode ? [void 0, { debugName: "text" }] : /* istanbul ignore next */ []);
	truncate = input(...ngDevMode ? [void 0, { debugName: "truncate" }] : /* istanbul ignore next */ []);
	wrap = input(...ngDevMode ? [void 0, { debugName: "wrap" }] : /* istanbul ignore next */ []);
	maxLength = input(...ngDevMode ? [void 0, { debugName: "maxLength" }] : /* istanbul ignore next */ []);
	maxLines = input(...ngDevMode ? [void 0, { debugName: "maxLines" }] : /* istanbul ignore next */ []);
	readonly = input(...ngDevMode ? [void 0, { debugName: "readonly" }] : /* istanbul ignore next */ []);
	alignment = input(...ngDevMode ? [void 0, { debugName: "alignment" }] : /* istanbul ignore next */ []);
	marker = input(...ngDevMode ? [void 0, { debugName: "marker" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	formatter = input(...ngDevMode ? [void 0, { debugName: "formatter" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(TEXT_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	mark(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "mark", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const textValue = this.text();
			if (textValue !== void 0) this._elementRef.nativeElement.text = textValue;
			const truncateValue = this.truncate();
			if (truncateValue !== void 0) this._elementRef.nativeElement.truncate = truncateValue;
			const wrapValue = this.wrap();
			if (wrapValue !== void 0) this._elementRef.nativeElement.wrap = wrapValue;
			const maxLengthValue = this.maxLength();
			if (maxLengthValue !== void 0) this._elementRef.nativeElement.maxLength = maxLengthValue;
			const maxLinesValue = this.maxLines();
			if (maxLinesValue !== void 0) this._elementRef.nativeElement.maxLines = maxLinesValue;
			const readonlyValue = this.readonly();
			if (readonlyValue !== void 0) this._elementRef.nativeElement.readonly = readonlyValue;
			const alignmentValue = this.alignment();
			if (alignmentValue !== void 0) this._elementRef.nativeElement.alignment = alignmentValue;
			const markerValue = this.marker();
			if (markerValue !== void 0) this._elementRef.nativeElement.marker = markerValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const formatterValue = this.formatter();
			if (formatterValue !== void 0) this._elementRef.nativeElement.formatter = formatterValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: TextComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: TextComponent,
		isStandalone: true,
		selector: "mosaik-text",
		inputs: {
			text: {
				classPropertyName: "text",
				publicName: "text",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			truncate: {
				classPropertyName: "truncate",
				publicName: "truncate",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			wrap: {
				classPropertyName: "wrap",
				publicName: "wrap",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			maxLength: {
				classPropertyName: "maxLength",
				publicName: "maxLength",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			maxLines: {
				classPropertyName: "maxLines",
				publicName: "maxLines",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			readonly: {
				classPropertyName: "readonly",
				publicName: "readonly",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			alignment: {
				classPropertyName: "alignment",
				publicName: "alignment",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			marker: {
				classPropertyName: "marker",
				publicName: "marker",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			formatter: {
				classPropertyName: "formatter",
				publicName: "formatter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
TextComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-text", TextElement),
	inputs: [
		"text",
		"truncate",
		"wrap",
		"maxLength",
		"maxLines",
		"readonly",
		"alignment",
		"marker",
		"themeName",
		"variant",
		"disabled",
		"formatter",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], TextComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: TextComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-text",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		text: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "text",
				required: false
			}]
		}],
		truncate: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "truncate",
				required: false
			}]
		}],
		wrap: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "wrap",
				required: false
			}]
		}],
		maxLength: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maxLength",
				required: false
			}]
		}],
		maxLines: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maxLines",
				required: false
			}]
		}],
		readonly: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "readonly",
				required: false
			}]
		}],
		alignment: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "alignment",
				required: false
			}]
		}],
		marker: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "marker",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		formatter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "formatter",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideTextComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: TEXT_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { TEXT_DEFAULT_PROPS, TextComponent, provideTextComponent };

//# sourceMappingURL=mosaik-elements-angular-components-text.mjs.map