import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { DesignerCanvasElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/designer/canvas/DesignerCanvasElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { DesignerConnectorElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/designer/connector/DesignerConnectorElement";
import { DesignerContentElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/designer/content/DesignerContentElement";
import { DesignerFrameElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/designer/frame/DesignerFrameElement";
import { DesignerElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/designer/DesignerElement";
var __decorate$4 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$4 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const DESIGNER_CANVAS_DEFAULT_PROPS = new InjectionToken("MOSAIK_DESIGNER_CANVAS_DEFAULT_PROPS");
let DesignerCanvasComponent = class DesignerCanvasComponent {
	arrangement = input(...ngDevMode ? [void 0, { debugName: "arrangement" }] : /* istanbul ignore next */ []);
	zoom = input(...ngDevMode ? [void 0, { debugName: "zoom" }] : /* istanbul ignore next */ []);
	minZoom = input(...ngDevMode ? [void 0, { debugName: "minZoom" }] : /* istanbul ignore next */ []);
	maxZoom = input(...ngDevMode ? [void 0, { debugName: "maxZoom" }] : /* istanbul ignore next */ []);
	interactionMode = input(...ngDevMode ? [void 0, { debugName: "interactionMode" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	zoomChanged = output();
	viewportChanged = output();
	viewportSettled = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			zoomChanged: this.zoomChanged,
			viewportChanged: this.viewportChanged,
			viewportSettled: this.viewportSettled,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(DESIGNER_CANVAS_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	zoomIn(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "zoomIn", args);
	}
	zoomOut(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "zoomOut", args);
	}
	setZoom(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "setZoom", args);
	}
	resetZoom(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "resetZoom", args);
	}
	fitToFrame(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "fitToFrame", args);
	}
	fitToContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "fitToContent", args);
	}
	zoomToRect(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "zoomToRect", args);
	}
	setViewport(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "setViewport", args);
	}
	zoomAt(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "zoomAt", args);
	}
	screenToWorld(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "screenToWorld", args);
	}
	worldToScreen(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "worldToScreen", args);
	}
	panBy(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "panBy", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const arrangementValue = this.arrangement();
			if (arrangementValue !== void 0) this._elementRef.nativeElement.arrangement = arrangementValue;
			const zoomValue = this.zoom();
			if (zoomValue !== void 0) this._elementRef.nativeElement.zoom = zoomValue;
			const minZoomValue = this.minZoom();
			if (minZoomValue !== void 0) this._elementRef.nativeElement.minZoom = minZoomValue;
			const maxZoomValue = this.maxZoom();
			if (maxZoomValue !== void 0) this._elementRef.nativeElement.maxZoom = maxZoomValue;
			const interactionModeValue = this.interactionMode();
			if (interactionModeValue !== void 0) this._elementRef.nativeElement.interactionMode = interactionModeValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DesignerCanvasComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: DesignerCanvasComponent,
		isStandalone: true,
		selector: "mosaik-designer-canvas",
		inputs: {
			arrangement: {
				classPropertyName: "arrangement",
				publicName: "arrangement",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			zoom: {
				classPropertyName: "zoom",
				publicName: "zoom",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			minZoom: {
				classPropertyName: "minZoom",
				publicName: "minZoom",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			maxZoom: {
				classPropertyName: "maxZoom",
				publicName: "maxZoom",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			interactionMode: {
				classPropertyName: "interactionMode",
				publicName: "interactionMode",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			zoomChanged: "zoomChanged",
			viewportChanged: "viewportChanged",
			viewportSettled: "viewportSettled",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
DesignerCanvasComponent = __decorate$4([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-designer-canvas", DesignerCanvasElement),
	inputs: [
		"arrangement",
		"zoom",
		"minZoom",
		"maxZoom",
		"interactionMode",
		"themeName",
		"dir",
		"lang"
	]
}), __metadata$4("design:paramtypes", [])], DesignerCanvasComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DesignerCanvasComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-designer-canvas",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		arrangement: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "arrangement",
				required: false
			}]
		}],
		zoom: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "zoom",
				required: false
			}]
		}],
		minZoom: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "minZoom",
				required: false
			}]
		}],
		maxZoom: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maxZoom",
				required: false
			}]
		}],
		interactionMode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "interactionMode",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		zoomChanged: [{
			type: i0.Output,
			args: ["zoomChanged"]
		}],
		viewportChanged: [{
			type: i0.Output,
			args: ["viewportChanged"]
		}],
		viewportSettled: [{
			type: i0.Output,
			args: ["viewportSettled"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideDesignerCanvasComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: DESIGNER_CANVAS_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$3 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$3 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const DESIGNER_CONNECTOR_DEFAULT_PROPS = new InjectionToken("MOSAIK_DESIGNER_CONNECTOR_DEFAULT_PROPS");
let DesignerConnectorComponent = class DesignerConnectorComponent {
	from = input(...ngDevMode ? [void 0, { debugName: "from" }] : /* istanbul ignore next */ []);
	to = input(...ngDevMode ? [void 0, { debugName: "to" }] : /* istanbul ignore next */ []);
	routing = input(...ngDevMode ? [void 0, { debugName: "routing" }] : /* istanbul ignore next */ []);
	arrow = input(...ngDevMode ? [void 0, { debugName: "arrow" }] : /* istanbul ignore next */ []);
	label = input(...ngDevMode ? [void 0, { debugName: "label" }] : /* istanbul ignore next */ []);
	selected = input(...ngDevMode ? [void 0, { debugName: "selected" }] : /* istanbul ignore next */ []);
	inverseZoom = input(...ngDevMode ? [void 0, { debugName: "inverseZoom" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(DESIGNER_CONNECTOR_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const fromValue = this.from();
			if (fromValue !== void 0) this._elementRef.nativeElement.from = fromValue;
			const toValue = this.to();
			if (toValue !== void 0) this._elementRef.nativeElement.to = toValue;
			const routingValue = this.routing();
			if (routingValue !== void 0) this._elementRef.nativeElement.routing = routingValue;
			const arrowValue = this.arrow();
			if (arrowValue !== void 0) this._elementRef.nativeElement.arrow = arrowValue;
			const labelValue = this.label();
			if (labelValue !== void 0) this._elementRef.nativeElement.label = labelValue;
			const selectedValue = this.selected();
			if (selectedValue !== void 0) this._elementRef.nativeElement.selected = selectedValue;
			const inverseZoomValue = this.inverseZoom();
			if (inverseZoomValue !== void 0) this._elementRef.nativeElement.inverseZoom = inverseZoomValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DesignerConnectorComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: DesignerConnectorComponent,
		isStandalone: true,
		selector: "mosaik-designer-connector",
		inputs: {
			from: {
				classPropertyName: "from",
				publicName: "from",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			to: {
				classPropertyName: "to",
				publicName: "to",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			routing: {
				classPropertyName: "routing",
				publicName: "routing",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			arrow: {
				classPropertyName: "arrow",
				publicName: "arrow",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			selected: {
				classPropertyName: "selected",
				publicName: "selected",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			inverseZoom: {
				classPropertyName: "inverseZoom",
				publicName: "inverseZoom",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
DesignerConnectorComponent = __decorate$3([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-designer-connector", DesignerConnectorElement),
	inputs: [
		"from",
		"to",
		"routing",
		"arrow",
		"label",
		"selected",
		"inverseZoom",
		"themeName",
		"dir",
		"lang"
	]
}), __metadata$3("design:paramtypes", [])], DesignerConnectorComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DesignerConnectorComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-designer-connector",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		from: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "from",
				required: false
			}]
		}],
		to: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "to",
				required: false
			}]
		}],
		routing: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "routing",
				required: false
			}]
		}],
		arrow: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "arrow",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		selected: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "selected",
				required: false
			}]
		}],
		inverseZoom: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "inverseZoom",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideDesignerConnectorComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: DESIGNER_CONNECTOR_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$2 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$2 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const DESIGNER_CONTENT_DEFAULT_PROPS = new InjectionToken("MOSAIK_DESIGNER_CONTENT_DEFAULT_PROPS");
let DesignerContentComponent = class DesignerContentComponent {
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(DESIGNER_CONTENT_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DesignerContentComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: DesignerContentComponent,
		isStandalone: true,
		selector: "mosaik-designer-content",
		inputs: {
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
DesignerContentComponent = __decorate$2([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-designer-content", DesignerContentElement),
	inputs: [
		"themeName",
		"dir",
		"lang"
	]
}), __metadata$2("design:paramtypes", [])], DesignerContentComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DesignerContentComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-designer-content",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideDesignerContentComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: DESIGNER_CONTENT_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$1 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$1 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const DESIGNER_FRAME_DEFAULT_PROPS = new InjectionToken("MOSAIK_DESIGNER_FRAME_DEFAULT_PROPS");
let DesignerFrameComponent = class DesignerFrameComponent {
	bounds = input(...ngDevMode ? [void 0, { debugName: "bounds" }] : /* istanbul ignore next */ []);
	showBounds = input(...ngDevMode ? [void 0, { debugName: "showBounds" }] : /* istanbul ignore next */ []);
	fold = input(...ngDevMode ? [void 0, { debugName: "fold" }] : /* istanbul ignore next */ []);
	foldOffset = input(...ngDevMode ? [void 0, { debugName: "foldOffset" }] : /* istanbul ignore next */ []);
	x = input(...ngDevMode ? [void 0, { debugName: "x" }] : /* istanbul ignore next */ []);
	y = input(...ngDevMode ? [void 0, { debugName: "y" }] : /* istanbul ignore next */ []);
	label = input(...ngDevMode ? [void 0, { debugName: "label" }] : /* istanbul ignore next */ []);
	selected = input(...ngDevMode ? [void 0, { debugName: "selected" }] : /* istanbul ignore next */ []);
	focused = input(...ngDevMode ? [void 0, { debugName: "focused" }] : /* istanbul ignore next */ []);
	inverseZoom = input(...ngDevMode ? [void 0, { debugName: "inverseZoom" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(DESIGNER_FRAME_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const boundsValue = this.bounds();
			if (boundsValue !== void 0) this._elementRef.nativeElement.bounds = boundsValue;
			const showBoundsValue = this.showBounds();
			if (showBoundsValue !== void 0) this._elementRef.nativeElement.showBounds = showBoundsValue;
			const foldValue = this.fold();
			if (foldValue !== void 0) this._elementRef.nativeElement.fold = foldValue;
			const foldOffsetValue = this.foldOffset();
			if (foldOffsetValue !== void 0) this._elementRef.nativeElement.foldOffset = foldOffsetValue;
			const xValue = this.x();
			if (xValue !== void 0) this._elementRef.nativeElement.x = xValue;
			const yValue = this.y();
			if (yValue !== void 0) this._elementRef.nativeElement.y = yValue;
			const labelValue = this.label();
			if (labelValue !== void 0) this._elementRef.nativeElement.label = labelValue;
			const selectedValue = this.selected();
			if (selectedValue !== void 0) this._elementRef.nativeElement.selected = selectedValue;
			const focusedValue = this.focused();
			if (focusedValue !== void 0) this._elementRef.nativeElement.focused = focusedValue;
			const inverseZoomValue = this.inverseZoom();
			if (inverseZoomValue !== void 0) this._elementRef.nativeElement.inverseZoom = inverseZoomValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DesignerFrameComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: DesignerFrameComponent,
		isStandalone: true,
		selector: "mosaik-designer-frame",
		inputs: {
			bounds: {
				classPropertyName: "bounds",
				publicName: "bounds",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showBounds: {
				classPropertyName: "showBounds",
				publicName: "showBounds",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			fold: {
				classPropertyName: "fold",
				publicName: "fold",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			foldOffset: {
				classPropertyName: "foldOffset",
				publicName: "foldOffset",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			x: {
				classPropertyName: "x",
				publicName: "x",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			y: {
				classPropertyName: "y",
				publicName: "y",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			selected: {
				classPropertyName: "selected",
				publicName: "selected",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			focused: {
				classPropertyName: "focused",
				publicName: "focused",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			inverseZoom: {
				classPropertyName: "inverseZoom",
				publicName: "inverseZoom",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
DesignerFrameComponent = __decorate$1([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-designer-frame", DesignerFrameElement),
	inputs: [
		"bounds",
		"showBounds",
		"fold",
		"foldOffset",
		"x",
		"y",
		"label",
		"selected",
		"focused",
		"inverseZoom",
		"themeName",
		"dir",
		"lang"
	]
}), __metadata$1("design:paramtypes", [])], DesignerFrameComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DesignerFrameComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-designer-frame",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		bounds: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "bounds",
				required: false
			}]
		}],
		showBounds: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showBounds",
				required: false
			}]
		}],
		fold: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "fold",
				required: false
			}]
		}],
		foldOffset: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "foldOffset",
				required: false
			}]
		}],
		x: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "x",
				required: false
			}]
		}],
		y: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "y",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		selected: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "selected",
				required: false
			}]
		}],
		focused: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "focused",
				required: false
			}]
		}],
		inverseZoom: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "inverseZoom",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideDesignerFrameComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: DESIGNER_FRAME_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const DESIGNER_DEFAULT_PROPS = new InjectionToken("MOSAIK_DESIGNER_DEFAULT_PROPS");
let DesignerComponent = class DesignerComponent {
	defaultLayers = input(...ngDevMode ? [void 0, { debugName: "defaultLayers" }] : /* istanbul ignore next */ []);
	layers = input(...ngDevMode ? [void 0, { debugName: "layers" }] : /* istanbul ignore next */ []);
	frameSize = input(...ngDevMode ? [void 0, { debugName: "frameSize" }] : /* istanbul ignore next */ []);
	mode = input(...ngDevMode ? [void 0, { debugName: "mode" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	layersChanged = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			layersChanged: this.layersChanged,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(DESIGNER_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	updateLayers(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "updateLayers", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const defaultLayersValue = this.defaultLayers();
			if (defaultLayersValue !== void 0) this._elementRef.nativeElement.defaultLayers = defaultLayersValue;
			const layersValue = this.layers();
			if (layersValue !== void 0) this._elementRef.nativeElement.layers = layersValue;
			const frameSizeValue = this.frameSize();
			if (frameSizeValue !== void 0) this._elementRef.nativeElement.frameSize = frameSizeValue;
			const modeValue = this.mode();
			if (modeValue !== void 0) this._elementRef.nativeElement.mode = modeValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DesignerComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: DesignerComponent,
		isStandalone: true,
		selector: "mosaik-designer",
		inputs: {
			defaultLayers: {
				classPropertyName: "defaultLayers",
				publicName: "defaultLayers",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			layers: {
				classPropertyName: "layers",
				publicName: "layers",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			frameSize: {
				classPropertyName: "frameSize",
				publicName: "frameSize",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			mode: {
				classPropertyName: "mode",
				publicName: "mode",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			layersChanged: "layersChanged",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
DesignerComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-designer", DesignerElement),
	inputs: [
		"defaultLayers",
		"layers",
		"frameSize",
		"mode",
		"themeName",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], DesignerComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DesignerComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-designer",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		defaultLayers: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "defaultLayers",
				required: false
			}]
		}],
		layers: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "layers",
				required: false
			}]
		}],
		frameSize: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "frameSize",
				required: false
			}]
		}],
		mode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mode",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		layersChanged: [{
			type: i0.Output,
			args: ["layersChanged"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideDesignerComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: DESIGNER_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { DESIGNER_CANVAS_DEFAULT_PROPS, DESIGNER_CONNECTOR_DEFAULT_PROPS, DESIGNER_CONTENT_DEFAULT_PROPS, DESIGNER_DEFAULT_PROPS, DESIGNER_FRAME_DEFAULT_PROPS, DesignerCanvasComponent, DesignerComponent, DesignerConnectorComponent, DesignerContentComponent, DesignerFrameComponent, provideDesignerCanvasComponent, provideDesignerComponent, provideDesignerConnectorComponent, provideDesignerContentComponent, provideDesignerFrameComponent };

//# sourceMappingURL=mosaik-elements-angular-components-designer.mjs.map