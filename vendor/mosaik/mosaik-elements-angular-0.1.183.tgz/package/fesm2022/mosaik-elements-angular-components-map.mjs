import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { MapElement } from "@pixel-brewery/mosaik-elements-foundation/components/map";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const MAP_DEFAULT_PROPS = new InjectionToken("MOSAIK_MAP_DEFAULT_PROPS");
const MAP_INTL = new InjectionToken("MOSAIK_MAP_INTL");
let MapComponent = class MapComponent {
	intl = input(...ngDevMode ? [void 0, { debugName: "intl" }] : /* istanbul ignore next */ []);
	latitude = input(...ngDevMode ? [void 0, { debugName: "latitude" }] : /* istanbul ignore next */ []);
	longitude = input(...ngDevMode ? [void 0, { debugName: "longitude" }] : /* istanbul ignore next */ []);
	zoom = input(...ngDevMode ? [void 0, { debugName: "zoom" }] : /* istanbul ignore next */ []);
	mode = input(...ngDevMode ? [void 0, { debugName: "mode" }] : /* istanbul ignore next */ []);
	provider = input(...ngDevMode ? [void 0, { debugName: "provider" }] : /* istanbul ignore next */ []);
	label = input(...ngDevMode ? [void 0, { debugName: "label" }] : /* istanbul ignore next */ []);
	markers = input(...ngDevMode ? [void 0, { debugName: "markers" }] : /* istanbul ignore next */ []);
	routes = input(...ngDevMode ? [void 0, { debugName: "routes" }] : /* istanbul ignore next */ []);
	cluster = input(...ngDevMode ? [void 0, { debugName: "cluster" }] : /* istanbul ignore next */ []);
	showControls = input(...ngDevMode ? [void 0, { debugName: "showControls" }] : /* istanbul ignore next */ []);
	mapStyle = input(...ngDevMode ? [void 0, { debugName: "mapStyle" }] : /* istanbul ignore next */ []);
	vectorSource = input(...ngDevMode ? [void 0, { debugName: "vectorSource" }] : /* istanbul ignore next */ []);
	workerUrl = input(...ngDevMode ? [void 0, { debugName: "workerUrl" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	width = input(...ngDevMode ? [void 0, { debugName: "width" }] : /* istanbul ignore next */ []);
	height = input(...ngDevMode ? [void 0, { debugName: "height" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	mapReady = output();
	mapMarkerSelected = output();
	mapCameraChanged = output();
	mapError = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			mapReady: this.mapReady,
			mapMarkerSelected: this.mapMarkerSelected,
			mapCameraChanged: this.mapCameraChanged,
			mapError: this.mapError,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(MAP_DEFAULT_PROPS, { optional: true }) ?? {}, ["intl"]);
		const injectedIntl = inject(MAP_INTL, { optional: true });
		if (injectedIntl) {
			Object.assign(this._elementRef.nativeElement.intl, injectedIntl);
			this._elementRef.nativeElement.intl.changes.emit();
		}
	}
	fitBounds(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "fitBounds", args);
	}
	retry(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "retry", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const latitudeValue = this.latitude();
			if (latitudeValue !== void 0) this._elementRef.nativeElement.latitude = latitudeValue;
			const longitudeValue = this.longitude();
			if (longitudeValue !== void 0) this._elementRef.nativeElement.longitude = longitudeValue;
			const zoomValue = this.zoom();
			if (zoomValue !== void 0) this._elementRef.nativeElement.zoom = zoomValue;
			const modeValue = this.mode();
			if (modeValue !== void 0) this._elementRef.nativeElement.mode = modeValue;
			const providerValue = this.provider();
			if (providerValue !== void 0) this._elementRef.nativeElement.provider = providerValue;
			const labelValue = this.label();
			if (labelValue !== void 0) this._elementRef.nativeElement.label = labelValue;
			const markersValue = this.markers();
			if (markersValue !== void 0) this._elementRef.nativeElement.markers = markersValue;
			const routesValue = this.routes();
			if (routesValue !== void 0) this._elementRef.nativeElement.routes = routesValue;
			const clusterValue = this.cluster();
			if (clusterValue !== void 0) this._elementRef.nativeElement.cluster = clusterValue;
			const showControlsValue = this.showControls();
			if (showControlsValue !== void 0) this._elementRef.nativeElement.showControls = showControlsValue;
			const mapStyleValue = this.mapStyle();
			if (mapStyleValue !== void 0) this._elementRef.nativeElement.mapStyle = mapStyleValue;
			const vectorSourceValue = this.vectorSource();
			if (vectorSourceValue !== void 0) this._elementRef.nativeElement.vectorSource = vectorSourceValue;
			const workerUrlValue = this.workerUrl();
			if (workerUrlValue !== void 0) this._elementRef.nativeElement.workerUrl = workerUrlValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const widthValue = this.width();
			if (widthValue !== void 0) this._elementRef.nativeElement.width = widthValue;
			const heightValue = this.height();
			if (heightValue !== void 0) this._elementRef.nativeElement.height = heightValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
			const intlValue = this.intl();
			if (intlValue !== void 0) {
				Object.assign(this._elementRef.nativeElement.intl, intlValue);
				this._elementRef.nativeElement.intl.changes.emit();
			}
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: MapComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: MapComponent,
		isStandalone: true,
		selector: "mosaik-map",
		inputs: {
			intl: {
				classPropertyName: "intl",
				publicName: "intl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			latitude: {
				classPropertyName: "latitude",
				publicName: "latitude",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			longitude: {
				classPropertyName: "longitude",
				publicName: "longitude",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			zoom: {
				classPropertyName: "zoom",
				publicName: "zoom",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			mode: {
				classPropertyName: "mode",
				publicName: "mode",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			provider: {
				classPropertyName: "provider",
				publicName: "provider",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			markers: {
				classPropertyName: "markers",
				publicName: "markers",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			routes: {
				classPropertyName: "routes",
				publicName: "routes",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			cluster: {
				classPropertyName: "cluster",
				publicName: "cluster",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showControls: {
				classPropertyName: "showControls",
				publicName: "showControls",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			mapStyle: {
				classPropertyName: "mapStyle",
				publicName: "mapStyle",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			vectorSource: {
				classPropertyName: "vectorSource",
				publicName: "vectorSource",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			workerUrl: {
				classPropertyName: "workerUrl",
				publicName: "workerUrl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			width: {
				classPropertyName: "width",
				publicName: "width",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			height: {
				classPropertyName: "height",
				publicName: "height",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			mapReady: "mapReady",
			mapMarkerSelected: "mapMarkerSelected",
			mapCameraChanged: "mapCameraChanged",
			mapError: "mapError",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
MapComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-map", MapElement),
	inputs: [
		"intl",
		"latitude",
		"longitude",
		"zoom",
		"mode",
		"provider",
		"label",
		"markers",
		"routes",
		"cluster",
		"showControls",
		"mapStyle",
		"vectorSource",
		"workerUrl",
		"themeName",
		"width",
		"height",
		"disabled",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], MapComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MapComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-map",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		intl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "intl",
				required: false
			}]
		}],
		latitude: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "latitude",
				required: false
			}]
		}],
		longitude: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "longitude",
				required: false
			}]
		}],
		zoom: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "zoom",
				required: false
			}]
		}],
		mode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mode",
				required: false
			}]
		}],
		provider: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "provider",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		markers: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "markers",
				required: false
			}]
		}],
		routes: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "routes",
				required: false
			}]
		}],
		cluster: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "cluster",
				required: false
			}]
		}],
		showControls: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showControls",
				required: false
			}]
		}],
		mapStyle: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mapStyle",
				required: false
			}]
		}],
		vectorSource: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "vectorSource",
				required: false
			}]
		}],
		workerUrl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "workerUrl",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		width: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "width",
				required: false
			}]
		}],
		height: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "height",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		mapReady: [{
			type: i0.Output,
			args: ["mapReady"]
		}],
		mapMarkerSelected: [{
			type: i0.Output,
			args: ["mapMarkerSelected"]
		}],
		mapCameraChanged: [{
			type: i0.Output,
			args: ["mapCameraChanged"]
		}],
		mapError: [{
			type: i0.Output,
			args: ["mapError"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideMapComponent(config, intl) {
	const providers = [];
	if (config) providers.push({
		provide: MAP_DEFAULT_PROPS,
		useValue: config
	});
	if (intl) {
		if (typeof intl === "function") providers.push({
			provide: MAP_INTL,
			useClass: intl
		});
		else providers.push({
			provide: MAP_INTL,
			useValue: intl
		});
	}
	return makeEnvironmentProviders(providers);
}
export { MAP_DEFAULT_PROPS, MAP_INTL, MapComponent, provideMapComponent };

//# sourceMappingURL=mosaik-elements-angular-components-map.mjs.map