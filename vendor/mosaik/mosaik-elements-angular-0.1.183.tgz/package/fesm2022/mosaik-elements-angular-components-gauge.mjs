import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, forwardRef, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { GaugeArcElement, GaugeControlElement, GaugeDotElement, GaugeElement, GaugeHubElement, GaugeInsetElement, GaugeMarksElement, GaugeNeedleElement, GaugeStackElement, GaugeTextElement, GaugeTickLabelsElement, GaugeTicksElement, GaugeTooltipElement, GaugeTrackElement, GaugeValueElement, GaugeZonesElement, gaugeControlElementValueAccessor } from "@pixel-brewery/mosaik-elements-foundation/components/gauge";
import * as i1 from "@pixel-brewery/mosaik-elements-angular/runtime";
import { FORM_STATUS_HOST, FormFieldStatusHostDirective, FormStatusHostDirective, ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { NG_VALUE_ACCESSOR } from "@angular/forms";
var __decorate$15 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$15 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const GAUGE_ARC_DEFAULT_PROPS = new InjectionToken("MOSAIK_GAUGE_ARC_DEFAULT_PROPS");
let GaugeArcComponent = class GaugeArcComponent {
	zones = input(...ngDevMode ? [void 0, { debugName: "zones" }] : /* istanbul ignore next */ []);
	width = input(...ngDevMode ? [void 0, { debugName: "width" }] : /* istanbul ignore next */ []);
	cap = input(...ngDevMode ? [void 0, { debugName: "cap" }] : /* istanbul ignore next */ []);
	from = input(...ngDevMode ? [void 0, { debugName: "from" }] : /* istanbul ignore next */ []);
	to = input(...ngDevMode ? [void 0, { debugName: "to" }] : /* istanbul ignore next */ []);
	reverse = input(...ngDevMode ? [void 0, { debugName: "reverse" }] : /* istanbul ignore next */ []);
	wrap = input(...ngDevMode ? [void 0, { debugName: "wrap" }] : /* istanbul ignore next */ []);
	color = input(...ngDevMode ? [void 0, { debugName: "color" }] : /* istanbul ignore next */ []);
	opacity = input(...ngDevMode ? [void 0, { debugName: "opacity" }] : /* istanbul ignore next */ []);
	offset = input(...ngDevMode ? [void 0, { debugName: "offset" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(GAUGE_ARC_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	renderGauge(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "renderGauge", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const zonesValue = this.zones();
			if (zonesValue !== void 0) this._elementRef.nativeElement.zones = zonesValue;
			const widthValue = this.width();
			if (widthValue !== void 0) this._elementRef.nativeElement.width = widthValue;
			const capValue = this.cap();
			if (capValue !== void 0) this._elementRef.nativeElement.cap = capValue;
			const fromValue = this.from();
			if (fromValue !== void 0) this._elementRef.nativeElement.from = fromValue;
			const toValue = this.to();
			if (toValue !== void 0) this._elementRef.nativeElement.to = toValue;
			const reverseValue = this.reverse();
			if (reverseValue !== void 0) this._elementRef.nativeElement.reverse = reverseValue;
			const wrapValue = this.wrap();
			if (wrapValue !== void 0) this._elementRef.nativeElement.wrap = wrapValue;
			const colorValue = this.color();
			if (colorValue !== void 0) this._elementRef.nativeElement.color = colorValue;
			const opacityValue = this.opacity();
			if (opacityValue !== void 0) this._elementRef.nativeElement.opacity = opacityValue;
			const offsetValue = this.offset();
			if (offsetValue !== void 0) this._elementRef.nativeElement.offset = offsetValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: GaugeArcComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: GaugeArcComponent,
		isStandalone: true,
		selector: "mosaik-gauge-arc",
		inputs: {
			zones: {
				classPropertyName: "zones",
				publicName: "zones",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			width: {
				classPropertyName: "width",
				publicName: "width",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			cap: {
				classPropertyName: "cap",
				publicName: "cap",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			from: {
				classPropertyName: "from",
				publicName: "from",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			to: {
				classPropertyName: "to",
				publicName: "to",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			reverse: {
				classPropertyName: "reverse",
				publicName: "reverse",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			wrap: {
				classPropertyName: "wrap",
				publicName: "wrap",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			color: {
				classPropertyName: "color",
				publicName: "color",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			opacity: {
				classPropertyName: "opacity",
				publicName: "opacity",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			offset: {
				classPropertyName: "offset",
				publicName: "offset",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
GaugeArcComponent = __decorate$15([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-gauge-arc", GaugeArcElement),
	inputs: [
		"zones",
		"width",
		"cap",
		"from",
		"to",
		"reverse",
		"wrap",
		"color",
		"opacity",
		"offset",
		"themeName",
		"dir",
		"lang"
	]
}), __metadata$15("design:paramtypes", [])], GaugeArcComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: GaugeArcComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-gauge-arc",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		zones: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "zones",
				required: false
			}]
		}],
		width: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "width",
				required: false
			}]
		}],
		cap: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "cap",
				required: false
			}]
		}],
		from: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "from",
				required: false
			}]
		}],
		to: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "to",
				required: false
			}]
		}],
		reverse: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "reverse",
				required: false
			}]
		}],
		wrap: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "wrap",
				required: false
			}]
		}],
		color: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "color",
				required: false
			}]
		}],
		opacity: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "opacity",
				required: false
			}]
		}],
		offset: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "offset",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideGaugeArcComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: GAUGE_ARC_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$14 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$14 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const GAUGE_CONTROL_DEFAULT_PROPS = new InjectionToken("MOSAIK_GAUGE_CONTROL_DEFAULT_PROPS");
let GaugeControlComponent = class GaugeControlComponent {
	value = input(...ngDevMode ? [void 0, { debugName: "value" }] : /* istanbul ignore next */ []);
	min = input(...ngDevMode ? [void 0, { debugName: "min" }] : /* istanbul ignore next */ []);
	max = input(...ngDevMode ? [void 0, { debugName: "max" }] : /* istanbul ignore next */ []);
	step = input(...ngDevMode ? [void 0, { debugName: "step" }] : /* istanbul ignore next */ []);
	startAngle = input(...ngDevMode ? [void 0, { debugName: "startAngle" }] : /* istanbul ignore next */ []);
	endAngle = input(...ngDevMode ? [void 0, { debugName: "endAngle" }] : /* istanbul ignore next */ []);
	label = input(...ngDevMode ? [void 0, { debugName: "label" }] : /* istanbul ignore next */ []);
	valueText = input(...ngDevMode ? [void 0, { debugName: "valueText" }] : /* istanbul ignore next */ []);
	knob = input(...ngDevMode ? [void 0, { debugName: "knob" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	isFocused = input(...ngDevMode ? [void 0, { debugName: "isFocused" }] : /* istanbul ignore next */ []);
	name = input(...ngDevMode ? [void 0, { debugName: "name" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	form = input(...ngDevMode ? [void 0, { debugName: "form" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	rangeValueChanged = output();
	gaugePressed = output();
	input = output();
	change = output();
	connected = output();
	disconnected = output();
	changed = output();
	invalid = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	_accessor;
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._accessor = gaugeControlElementValueAccessor(this._elementRef.nativeElement);
		this._elementRef.nativeElement.addController(this._accessor);
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			rangeValueChanged: this.rangeValueChanged,
			gaugePressed: this.gaugePressed,
			input: this.input,
			change: this.change,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed,
			invalid: this.invalid
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
			this._accessor.releaseCallbacks();
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(GAUGE_CONTROL_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	writeValue(obj) {
		this._accessor.writeValue(obj);
	}
	registerOnChange(fn) {
		this._accessor.registerOnChange(fn);
	}
	registerOnTouched(fn) {
		this._accessor.registerOnTouched(fn);
	}
	setDisabledState(isDisabled) {
		this._accessor.setDisabled?.(isDisabled);
	}
	getFormValue(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getFormValue", args);
	}
	checkValidity(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "checkValidity", args);
	}
	reportValidity(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "reportValidity", args);
	}
	getFormState(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getFormState", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const valueValue = this.value();
			if (valueValue !== void 0) this._elementRef.nativeElement.value = valueValue;
			const minValue = this.min();
			if (minValue !== void 0) this._elementRef.nativeElement.min = minValue;
			const maxValue = this.max();
			if (maxValue !== void 0) this._elementRef.nativeElement.max = maxValue;
			const stepValue = this.step();
			if (stepValue !== void 0) this._elementRef.nativeElement.step = stepValue;
			const startAngleValue = this.startAngle();
			if (startAngleValue !== void 0) this._elementRef.nativeElement.startAngle = startAngleValue;
			const endAngleValue = this.endAngle();
			if (endAngleValue !== void 0) this._elementRef.nativeElement.endAngle = endAngleValue;
			const labelValue = this.label();
			if (labelValue !== void 0) this._elementRef.nativeElement.label = labelValue;
			const valueTextValue = this.valueText();
			if (valueTextValue !== void 0) this._elementRef.nativeElement.valueText = valueTextValue;
			const knobValue = this.knob();
			if (knobValue !== void 0) this._elementRef.nativeElement.knob = knobValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const isFocusedValue = this.isFocused();
			if (isFocusedValue !== void 0) this._elementRef.nativeElement.isFocused = isFocusedValue;
			const nameValue = this.name();
			if (nameValue !== void 0) this._elementRef.nativeElement.name = nameValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const formValue = this.form();
			if (formValue !== void 0) this._elementRef.nativeElement.form = formValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: GaugeControlComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: GaugeControlComponent,
		isStandalone: true,
		selector: "mosaik-gauge-control",
		inputs: {
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			min: {
				classPropertyName: "min",
				publicName: "min",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			max: {
				classPropertyName: "max",
				publicName: "max",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			step: {
				classPropertyName: "step",
				publicName: "step",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			startAngle: {
				classPropertyName: "startAngle",
				publicName: "startAngle",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			endAngle: {
				classPropertyName: "endAngle",
				publicName: "endAngle",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			valueText: {
				classPropertyName: "valueText",
				publicName: "valueText",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			knob: {
				classPropertyName: "knob",
				publicName: "knob",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isFocused: {
				classPropertyName: "isFocused",
				publicName: "isFocused",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			name: {
				classPropertyName: "name",
				publicName: "name",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			form: {
				classPropertyName: "form",
				publicName: "form",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			rangeValueChanged: "rangeValueChanged",
			gaugePressed: "gaugePressed",
			input: "input",
			change: "change",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed",
			invalid: "invalid"
		},
		providers: [{
			provide: NG_VALUE_ACCESSOR,
			useExisting: forwardRef(() => GaugeControlComponent),
			multi: true
		}, {
			provide: FORM_STATUS_HOST,
			useExisting: forwardRef(() => GaugeControlComponent)
		}],
		hostDirectives: [{ directive: i1.FormStatusHostDirective }, { directive: i1.FormFieldStatusHostDirective }],
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
GaugeControlComponent = __decorate$14([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-gauge-control", GaugeControlElement),
	inputs: [
		"value",
		"min",
		"max",
		"step",
		"startAngle",
		"endAngle",
		"label",
		"valueText",
		"knob",
		"themeName",
		"isFocused",
		"name",
		"disabled",
		"form",
		"dir",
		"lang"
	]
}), __metadata$14("design:paramtypes", [])], GaugeControlComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: GaugeControlComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-gauge-control",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>",
			hostDirectives: [FormStatusHostDirective, FormFieldStatusHostDirective],
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => GaugeControlComponent),
				multi: true
			}, {
				provide: FORM_STATUS_HOST,
				useExisting: forwardRef(() => GaugeControlComponent)
			}]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		min: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "min",
				required: false
			}]
		}],
		max: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "max",
				required: false
			}]
		}],
		step: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "step",
				required: false
			}]
		}],
		startAngle: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "startAngle",
				required: false
			}]
		}],
		endAngle: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "endAngle",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		valueText: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "valueText",
				required: false
			}]
		}],
		knob: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "knob",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		isFocused: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isFocused",
				required: false
			}]
		}],
		name: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "name",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		form: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "form",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		rangeValueChanged: [{
			type: i0.Output,
			args: ["rangeValueChanged"]
		}],
		gaugePressed: [{
			type: i0.Output,
			args: ["gaugePressed"]
		}],
		input: [{
			type: i0.Output,
			args: ["input"]
		}],
		change: [{
			type: i0.Output,
			args: ["change"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}],
		invalid: [{
			type: i0.Output,
			args: ["invalid"]
		}]
	}
});
function provideGaugeControlComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: GAUGE_CONTROL_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$13 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$13 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const GAUGE_DOT_DEFAULT_PROPS = new InjectionToken("MOSAIK_GAUGE_DOT_DEFAULT_PROPS");
let GaugeDotComponent = class GaugeDotComponent {
	radius = input(...ngDevMode ? [void 0, { debugName: "radius" }] : /* istanbul ignore next */ []);
	turns = input(...ngDevMode ? [void 0, { debugName: "turns" }] : /* istanbul ignore next */ []);
	halo = input(...ngDevMode ? [void 0, { debugName: "halo" }] : /* istanbul ignore next */ []);
	haloColor = input(...ngDevMode ? [void 0, { debugName: "haloColor" }] : /* istanbul ignore next */ []);
	color = input(...ngDevMode ? [void 0, { debugName: "color" }] : /* istanbul ignore next */ []);
	opacity = input(...ngDevMode ? [void 0, { debugName: "opacity" }] : /* istanbul ignore next */ []);
	offset = input(...ngDevMode ? [void 0, { debugName: "offset" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(GAUGE_DOT_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	renderGauge(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "renderGauge", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const radiusValue = this.radius();
			if (radiusValue !== void 0) this._elementRef.nativeElement.radius = radiusValue;
			const turnsValue = this.turns();
			if (turnsValue !== void 0) this._elementRef.nativeElement.turns = turnsValue;
			const haloValue = this.halo();
			if (haloValue !== void 0) this._elementRef.nativeElement.halo = haloValue;
			const haloColorValue = this.haloColor();
			if (haloColorValue !== void 0) this._elementRef.nativeElement.haloColor = haloColorValue;
			const colorValue = this.color();
			if (colorValue !== void 0) this._elementRef.nativeElement.color = colorValue;
			const opacityValue = this.opacity();
			if (opacityValue !== void 0) this._elementRef.nativeElement.opacity = opacityValue;
			const offsetValue = this.offset();
			if (offsetValue !== void 0) this._elementRef.nativeElement.offset = offsetValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: GaugeDotComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: GaugeDotComponent,
		isStandalone: true,
		selector: "mosaik-gauge-dot",
		inputs: {
			radius: {
				classPropertyName: "radius",
				publicName: "radius",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			turns: {
				classPropertyName: "turns",
				publicName: "turns",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			halo: {
				classPropertyName: "halo",
				publicName: "halo",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			haloColor: {
				classPropertyName: "haloColor",
				publicName: "haloColor",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			color: {
				classPropertyName: "color",
				publicName: "color",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			opacity: {
				classPropertyName: "opacity",
				publicName: "opacity",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			offset: {
				classPropertyName: "offset",
				publicName: "offset",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
GaugeDotComponent = __decorate$13([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-gauge-dot", GaugeDotElement),
	inputs: [
		"radius",
		"turns",
		"halo",
		"haloColor",
		"color",
		"opacity",
		"offset",
		"themeName",
		"dir",
		"lang"
	]
}), __metadata$13("design:paramtypes", [])], GaugeDotComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: GaugeDotComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-gauge-dot",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		radius: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "radius",
				required: false
			}]
		}],
		turns: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "turns",
				required: false
			}]
		}],
		halo: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "halo",
				required: false
			}]
		}],
		haloColor: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "haloColor",
				required: false
			}]
		}],
		color: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "color",
				required: false
			}]
		}],
		opacity: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "opacity",
				required: false
			}]
		}],
		offset: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "offset",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideGaugeDotComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: GAUGE_DOT_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$12 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$12 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const GAUGE_HUB_DEFAULT_PROPS = new InjectionToken("MOSAIK_GAUGE_HUB_DEFAULT_PROPS");
let GaugeHubComponent = class GaugeHubComponent {
	radius = input(...ngDevMode ? [void 0, { debugName: "radius" }] : /* istanbul ignore next */ []);
	color = input(...ngDevMode ? [void 0, { debugName: "color" }] : /* istanbul ignore next */ []);
	opacity = input(...ngDevMode ? [void 0, { debugName: "opacity" }] : /* istanbul ignore next */ []);
	offset = input(...ngDevMode ? [void 0, { debugName: "offset" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(GAUGE_HUB_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	renderGauge(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "renderGauge", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const radiusValue = this.radius();
			if (radiusValue !== void 0) this._elementRef.nativeElement.radius = radiusValue;
			const colorValue = this.color();
			if (colorValue !== void 0) this._elementRef.nativeElement.color = colorValue;
			const opacityValue = this.opacity();
			if (opacityValue !== void 0) this._elementRef.nativeElement.opacity = opacityValue;
			const offsetValue = this.offset();
			if (offsetValue !== void 0) this._elementRef.nativeElement.offset = offsetValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: GaugeHubComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: GaugeHubComponent,
		isStandalone: true,
		selector: "mosaik-gauge-hub",
		inputs: {
			radius: {
				classPropertyName: "radius",
				publicName: "radius",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			color: {
				classPropertyName: "color",
				publicName: "color",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			opacity: {
				classPropertyName: "opacity",
				publicName: "opacity",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			offset: {
				classPropertyName: "offset",
				publicName: "offset",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
GaugeHubComponent = __decorate$12([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-gauge-hub", GaugeHubElement),
	inputs: [
		"radius",
		"color",
		"opacity",
		"offset",
		"themeName",
		"dir",
		"lang"
	]
}), __metadata$12("design:paramtypes", [])], GaugeHubComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: GaugeHubComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-gauge-hub",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		radius: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "radius",
				required: false
			}]
		}],
		color: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "color",
				required: false
			}]
		}],
		opacity: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "opacity",
				required: false
			}]
		}],
		offset: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "offset",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideGaugeHubComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: GAUGE_HUB_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$11 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$11 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const GAUGE_INSET_DEFAULT_PROPS = new InjectionToken("MOSAIK_GAUGE_INSET_DEFAULT_PROPS");
let GaugeInsetComponent = class GaugeInsetComponent {
	x = input(...ngDevMode ? [void 0, { debugName: "x" }] : /* istanbul ignore next */ []);
	y = input(...ngDevMode ? [void 0, { debugName: "y" }] : /* istanbul ignore next */ []);
	scale = input(...ngDevMode ? [void 0, { debugName: "scale" }] : /* istanbul ignore next */ []);
	transition = input(...ngDevMode ? [void 0, { debugName: "transition" }] : /* istanbul ignore next */ []);
	startAngle = input(...ngDevMode ? [void 0, { debugName: "startAngle" }] : /* istanbul ignore next */ []);
	endAngle = input(...ngDevMode ? [void 0, { debugName: "endAngle" }] : /* istanbul ignore next */ []);
	radius = input(...ngDevMode ? [void 0, { debugName: "radius" }] : /* istanbul ignore next */ []);
	rotate = input(...ngDevMode ? [void 0, { debugName: "rotate" }] : /* istanbul ignore next */ []);
	wrap = input(...ngDevMode ? [void 0, { debugName: "wrap" }] : /* istanbul ignore next */ []);
	initialValue = input(...ngDevMode ? [void 0, { debugName: "initialValue" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	label = input(...ngDevMode ? [void 0, { debugName: "label" }] : /* istanbul ignore next */ []);
	min = input(...ngDevMode ? [void 0, { debugName: "min" }] : /* istanbul ignore next */ []);
	max = input(...ngDevMode ? [void 0, { debugName: "max" }] : /* istanbul ignore next */ []);
	value = input(...ngDevMode ? [void 0, { debugName: "value" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	rangeValueChanged = output();
	changed = output();
	connected = output();
	disconnected = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			rangeValueChanged: this.rangeValueChanged,
			changed: this.changed,
			connected: this.connected,
			disconnected: this.disconnected
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(GAUGE_INSET_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	renderGauge(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "renderGauge", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const xValue = this.x();
			if (xValue !== void 0) this._elementRef.nativeElement.x = xValue;
			const yValue = this.y();
			if (yValue !== void 0) this._elementRef.nativeElement.y = yValue;
			const scaleValue = this.scale();
			if (scaleValue !== void 0) this._elementRef.nativeElement.scale = scaleValue;
			const transitionValue = this.transition();
			if (transitionValue !== void 0) this._elementRef.nativeElement.transition = transitionValue;
			const startAngleValue = this.startAngle();
			if (startAngleValue !== void 0) this._elementRef.nativeElement.startAngle = startAngleValue;
			const endAngleValue = this.endAngle();
			if (endAngleValue !== void 0) this._elementRef.nativeElement.endAngle = endAngleValue;
			const radiusValue = this.radius();
			if (radiusValue !== void 0) this._elementRef.nativeElement.radius = radiusValue;
			const rotateValue = this.rotate();
			if (rotateValue !== void 0) this._elementRef.nativeElement.rotate = rotateValue;
			const wrapValue = this.wrap();
			if (wrapValue !== void 0) this._elementRef.nativeElement.wrap = wrapValue;
			const initialValueValue = this.initialValue();
			if (initialValueValue !== void 0) this._elementRef.nativeElement.initialValue = initialValueValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const labelValue = this.label();
			if (labelValue !== void 0) this._elementRef.nativeElement.label = labelValue;
			const minValue = this.min();
			if (minValue !== void 0) this._elementRef.nativeElement.min = minValue;
			const maxValue = this.max();
			if (maxValue !== void 0) this._elementRef.nativeElement.max = maxValue;
			const valueValue = this.value();
			if (valueValue !== void 0) this._elementRef.nativeElement.value = valueValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: GaugeInsetComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: GaugeInsetComponent,
		isStandalone: true,
		selector: "mosaik-gauge-inset",
		inputs: {
			x: {
				classPropertyName: "x",
				publicName: "x",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			y: {
				classPropertyName: "y",
				publicName: "y",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			scale: {
				classPropertyName: "scale",
				publicName: "scale",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			transition: {
				classPropertyName: "transition",
				publicName: "transition",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			startAngle: {
				classPropertyName: "startAngle",
				publicName: "startAngle",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			endAngle: {
				classPropertyName: "endAngle",
				publicName: "endAngle",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			radius: {
				classPropertyName: "radius",
				publicName: "radius",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			rotate: {
				classPropertyName: "rotate",
				publicName: "rotate",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			wrap: {
				classPropertyName: "wrap",
				publicName: "wrap",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			initialValue: {
				classPropertyName: "initialValue",
				publicName: "initialValue",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			min: {
				classPropertyName: "min",
				publicName: "min",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			max: {
				classPropertyName: "max",
				publicName: "max",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			rangeValueChanged: "rangeValueChanged",
			changed: "changed",
			connected: "connected",
			disconnected: "disconnected"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
GaugeInsetComponent = __decorate$11([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-gauge-inset", GaugeInsetElement),
	inputs: [
		"x",
		"y",
		"scale",
		"transition",
		"startAngle",
		"endAngle",
		"radius",
		"rotate",
		"wrap",
		"initialValue",
		"themeName",
		"label",
		"min",
		"max",
		"value",
		"dir",
		"lang"
	]
}), __metadata$11("design:paramtypes", [])], GaugeInsetComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: GaugeInsetComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-gauge-inset",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		x: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "x",
				required: false
			}]
		}],
		y: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "y",
				required: false
			}]
		}],
		scale: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "scale",
				required: false
			}]
		}],
		transition: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "transition",
				required: false
			}]
		}],
		startAngle: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "startAngle",
				required: false
			}]
		}],
		endAngle: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "endAngle",
				required: false
			}]
		}],
		radius: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "radius",
				required: false
			}]
		}],
		rotate: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "rotate",
				required: false
			}]
		}],
		wrap: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "wrap",
				required: false
			}]
		}],
		initialValue: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "initialValue",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		min: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "min",
				required: false
			}]
		}],
		max: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "max",
				required: false
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		rangeValueChanged: [{
			type: i0.Output,
			args: ["rangeValueChanged"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}]
	}
});
function provideGaugeInsetComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: GAUGE_INSET_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$10 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$10 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const GAUGE_MARKS_DEFAULT_PROPS = new InjectionToken("MOSAIK_GAUGE_MARKS_DEFAULT_PROPS");
let GaugeMarksComponent = class GaugeMarksComponent {
	width = input(...ngDevMode ? [void 0, { debugName: "width" }] : /* istanbul ignore next */ []);
	cap = input(...ngDevMode ? [void 0, { debugName: "cap" }] : /* istanbul ignore next */ []);
	length = input(...ngDevMode ? [void 0, { debugName: "length" }] : /* istanbul ignore next */ []);
	count = input(...ngDevMode ? [void 0, { debugName: "count" }] : /* istanbul ignore next */ []);
	values = input(...ngDevMode ? [void 0, { debugName: "values" }] : /* istanbul ignore next */ []);
	color = input(...ngDevMode ? [void 0, { debugName: "color" }] : /* istanbul ignore next */ []);
	opacity = input(...ngDevMode ? [void 0, { debugName: "opacity" }] : /* istanbul ignore next */ []);
	offset = input(...ngDevMode ? [void 0, { debugName: "offset" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(GAUGE_MARKS_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	renderGauge(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "renderGauge", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const widthValue = this.width();
			if (widthValue !== void 0) this._elementRef.nativeElement.width = widthValue;
			const capValue = this.cap();
			if (capValue !== void 0) this._elementRef.nativeElement.cap = capValue;
			const countValue = this.count();
			if (countValue !== void 0) this._elementRef.nativeElement.count = countValue;
			const valuesValue = this.values();
			if (valuesValue !== void 0) this._elementRef.nativeElement.values = valuesValue;
			const colorValue = this.color();
			if (colorValue !== void 0) this._elementRef.nativeElement.color = colorValue;
			const opacityValue = this.opacity();
			if (opacityValue !== void 0) this._elementRef.nativeElement.opacity = opacityValue;
			const offsetValue = this.offset();
			if (offsetValue !== void 0) this._elementRef.nativeElement.offset = offsetValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: GaugeMarksComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: GaugeMarksComponent,
		isStandalone: true,
		selector: "mosaik-gauge-marks",
		inputs: {
			width: {
				classPropertyName: "width",
				publicName: "width",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			cap: {
				classPropertyName: "cap",
				publicName: "cap",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			length: {
				classPropertyName: "length",
				publicName: "length",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			count: {
				classPropertyName: "count",
				publicName: "count",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			values: {
				classPropertyName: "values",
				publicName: "values",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			color: {
				classPropertyName: "color",
				publicName: "color",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			opacity: {
				classPropertyName: "opacity",
				publicName: "opacity",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			offset: {
				classPropertyName: "offset",
				publicName: "offset",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
GaugeMarksComponent = __decorate$10([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-gauge-marks", GaugeMarksElement),
	inputs: [
		"width",
		"cap",
		"length",
		"count",
		"values",
		"color",
		"opacity",
		"offset",
		"themeName",
		"dir",
		"lang"
	]
}), __metadata$10("design:paramtypes", [])], GaugeMarksComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: GaugeMarksComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-gauge-marks",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		width: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "width",
				required: false
			}]
		}],
		cap: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "cap",
				required: false
			}]
		}],
		length: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "length",
				required: false
			}]
		}],
		count: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "count",
				required: false
			}]
		}],
		values: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "values",
				required: false
			}]
		}],
		color: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "color",
				required: false
			}]
		}],
		opacity: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "opacity",
				required: false
			}]
		}],
		offset: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "offset",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideGaugeMarksComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: GAUGE_MARKS_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$9 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$9 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const GAUGE_NEEDLE_DEFAULT_PROPS = new InjectionToken("MOSAIK_GAUGE_NEEDLE_DEFAULT_PROPS");
let GaugeNeedleComponent = class GaugeNeedleComponent {
	needleStyle = input(...ngDevMode ? [void 0, { debugName: "needleStyle" }] : /* istanbul ignore next */ []);
	length = input(...ngDevMode ? [void 0, { debugName: "length" }] : /* istanbul ignore next */ []);
	width = input(...ngDevMode ? [void 0, { debugName: "width" }] : /* istanbul ignore next */ []);
	tail = input(...ngDevMode ? [void 0, { debugName: "tail" }] : /* istanbul ignore next */ []);
	tailColor = input(...ngDevMode ? [void 0, { debugName: "tailColor" }] : /* istanbul ignore next */ []);
	tailDot = input(...ngDevMode ? [void 0, { debugName: "tailDot" }] : /* istanbul ignore next */ []);
	turns = input(...ngDevMode ? [void 0, { debugName: "turns" }] : /* istanbul ignore next */ []);
	gap = input(...ngDevMode ? [void 0, { debugName: "gap" }] : /* istanbul ignore next */ []);
	color = input(...ngDevMode ? [void 0, { debugName: "color" }] : /* istanbul ignore next */ []);
	opacity = input(...ngDevMode ? [void 0, { debugName: "opacity" }] : /* istanbul ignore next */ []);
	offset = input(...ngDevMode ? [void 0, { debugName: "offset" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(GAUGE_NEEDLE_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	renderGauge(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "renderGauge", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const needleStyleValue = this.needleStyle();
			if (needleStyleValue !== void 0) this._elementRef.nativeElement.needleStyle = needleStyleValue;
			const widthValue = this.width();
			if (widthValue !== void 0) this._elementRef.nativeElement.width = widthValue;
			const tailValue = this.tail();
			if (tailValue !== void 0) this._elementRef.nativeElement.tail = tailValue;
			const tailColorValue = this.tailColor();
			if (tailColorValue !== void 0) this._elementRef.nativeElement.tailColor = tailColorValue;
			const tailDotValue = this.tailDot();
			if (tailDotValue !== void 0) this._elementRef.nativeElement.tailDot = tailDotValue;
			const turnsValue = this.turns();
			if (turnsValue !== void 0) this._elementRef.nativeElement.turns = turnsValue;
			const gapValue = this.gap();
			if (gapValue !== void 0) this._elementRef.nativeElement.gap = gapValue;
			const colorValue = this.color();
			if (colorValue !== void 0) this._elementRef.nativeElement.color = colorValue;
			const opacityValue = this.opacity();
			if (opacityValue !== void 0) this._elementRef.nativeElement.opacity = opacityValue;
			const offsetValue = this.offset();
			if (offsetValue !== void 0) this._elementRef.nativeElement.offset = offsetValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: GaugeNeedleComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: GaugeNeedleComponent,
		isStandalone: true,
		selector: "mosaik-gauge-needle",
		inputs: {
			needleStyle: {
				classPropertyName: "needleStyle",
				publicName: "needleStyle",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			length: {
				classPropertyName: "length",
				publicName: "length",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			width: {
				classPropertyName: "width",
				publicName: "width",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			tail: {
				classPropertyName: "tail",
				publicName: "tail",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			tailColor: {
				classPropertyName: "tailColor",
				publicName: "tailColor",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			tailDot: {
				classPropertyName: "tailDot",
				publicName: "tailDot",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			turns: {
				classPropertyName: "turns",
				publicName: "turns",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			gap: {
				classPropertyName: "gap",
				publicName: "gap",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			color: {
				classPropertyName: "color",
				publicName: "color",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			opacity: {
				classPropertyName: "opacity",
				publicName: "opacity",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			offset: {
				classPropertyName: "offset",
				publicName: "offset",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
GaugeNeedleComponent = __decorate$9([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-gauge-needle", GaugeNeedleElement),
	inputs: [
		"needleStyle",
		"length",
		"width",
		"tail",
		"tailColor",
		"tailDot",
		"turns",
		"gap",
		"color",
		"opacity",
		"offset",
		"themeName",
		"dir",
		"lang"
	]
}), __metadata$9("design:paramtypes", [])], GaugeNeedleComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: GaugeNeedleComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-gauge-needle",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		needleStyle: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "needleStyle",
				required: false
			}]
		}],
		length: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "length",
				required: false
			}]
		}],
		width: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "width",
				required: false
			}]
		}],
		tail: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tail",
				required: false
			}]
		}],
		tailColor: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tailColor",
				required: false
			}]
		}],
		tailDot: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tailDot",
				required: false
			}]
		}],
		turns: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "turns",
				required: false
			}]
		}],
		gap: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "gap",
				required: false
			}]
		}],
		color: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "color",
				required: false
			}]
		}],
		opacity: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "opacity",
				required: false
			}]
		}],
		offset: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "offset",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideGaugeNeedleComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: GAUGE_NEEDLE_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$8 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$8 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const GAUGE_STACK_DEFAULT_PROPS = new InjectionToken("MOSAIK_GAUGE_STACK_DEFAULT_PROPS");
let GaugeStackComponent = class GaugeStackComponent {
	width = input(...ngDevMode ? [void 0, { debugName: "width" }] : /* istanbul ignore next */ []);
	cap = input(...ngDevMode ? [void 0, { debugName: "cap" }] : /* istanbul ignore next */ []);
	from = input(...ngDevMode ? [void 0, { debugName: "from" }] : /* istanbul ignore next */ []);
	parts = input(...ngDevMode ? [void 0, { debugName: "parts" }] : /* istanbul ignore next */ []);
	color = input(...ngDevMode ? [void 0, { debugName: "color" }] : /* istanbul ignore next */ []);
	opacity = input(...ngDevMode ? [void 0, { debugName: "opacity" }] : /* istanbul ignore next */ []);
	offset = input(...ngDevMode ? [void 0, { debugName: "offset" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(GAUGE_STACK_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	renderGauge(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "renderGauge", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const widthValue = this.width();
			if (widthValue !== void 0) this._elementRef.nativeElement.width = widthValue;
			const capValue = this.cap();
			if (capValue !== void 0) this._elementRef.nativeElement.cap = capValue;
			const fromValue = this.from();
			if (fromValue !== void 0) this._elementRef.nativeElement.from = fromValue;
			const partsValue = this.parts();
			if (partsValue !== void 0) this._elementRef.nativeElement.parts = partsValue;
			const colorValue = this.color();
			if (colorValue !== void 0) this._elementRef.nativeElement.color = colorValue;
			const opacityValue = this.opacity();
			if (opacityValue !== void 0) this._elementRef.nativeElement.opacity = opacityValue;
			const offsetValue = this.offset();
			if (offsetValue !== void 0) this._elementRef.nativeElement.offset = offsetValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: GaugeStackComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: GaugeStackComponent,
		isStandalone: true,
		selector: "mosaik-gauge-stack",
		inputs: {
			width: {
				classPropertyName: "width",
				publicName: "width",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			cap: {
				classPropertyName: "cap",
				publicName: "cap",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			from: {
				classPropertyName: "from",
				publicName: "from",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			parts: {
				classPropertyName: "parts",
				publicName: "parts",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			color: {
				classPropertyName: "color",
				publicName: "color",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			opacity: {
				classPropertyName: "opacity",
				publicName: "opacity",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			offset: {
				classPropertyName: "offset",
				publicName: "offset",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
GaugeStackComponent = __decorate$8([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-gauge-stack", GaugeStackElement),
	inputs: [
		"width",
		"cap",
		"from",
		"parts",
		"color",
		"opacity",
		"offset",
		"themeName",
		"dir",
		"lang"
	]
}), __metadata$8("design:paramtypes", [])], GaugeStackComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: GaugeStackComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-gauge-stack",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		width: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "width",
				required: false
			}]
		}],
		cap: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "cap",
				required: false
			}]
		}],
		from: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "from",
				required: false
			}]
		}],
		parts: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "parts",
				required: false
			}]
		}],
		color: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "color",
				required: false
			}]
		}],
		opacity: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "opacity",
				required: false
			}]
		}],
		offset: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "offset",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideGaugeStackComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: GAUGE_STACK_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$7 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$7 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const GAUGE_TEXT_DEFAULT_PROPS = new InjectionToken("MOSAIK_GAUGE_TEXT_DEFAULT_PROPS");
let GaugeTextComponent = class GaugeTextComponent {
	x = input(...ngDevMode ? [void 0, { debugName: "x" }] : /* istanbul ignore next */ []);
	y = input(...ngDevMode ? [void 0, { debugName: "y" }] : /* istanbul ignore next */ []);
	fontSize = input(...ngDevMode ? [void 0, { debugName: "fontSize" }] : /* istanbul ignore next */ []);
	font = input(...ngDevMode ? [void 0, { debugName: "font" }] : /* istanbul ignore next */ []);
	weight = input(...ngDevMode ? [void 0, { debugName: "weight" }] : /* istanbul ignore next */ []);
	anchor = input(...ngDevMode ? [void 0, { debugName: "anchor" }] : /* istanbul ignore next */ []);
	text = input(...ngDevMode ? [void 0, { debugName: "text" }] : /* istanbul ignore next */ []);
	color = input(...ngDevMode ? [void 0, { debugName: "color" }] : /* istanbul ignore next */ []);
	opacity = input(...ngDevMode ? [void 0, { debugName: "opacity" }] : /* istanbul ignore next */ []);
	offset = input(...ngDevMode ? [void 0, { debugName: "offset" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(GAUGE_TEXT_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	renderGauge(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "renderGauge", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const xValue = this.x();
			if (xValue !== void 0) this._elementRef.nativeElement.x = xValue;
			const yValue = this.y();
			if (yValue !== void 0) this._elementRef.nativeElement.y = yValue;
			const fontSizeValue = this.fontSize();
			if (fontSizeValue !== void 0) this._elementRef.nativeElement.fontSize = fontSizeValue;
			const fontValue = this.font();
			if (fontValue !== void 0) this._elementRef.nativeElement.font = fontValue;
			const weightValue = this.weight();
			if (weightValue !== void 0) this._elementRef.nativeElement.weight = weightValue;
			const anchorValue = this.anchor();
			if (anchorValue !== void 0) this._elementRef.nativeElement.anchor = anchorValue;
			const textValue = this.text();
			if (textValue !== void 0) this._elementRef.nativeElement.text = textValue;
			const colorValue = this.color();
			if (colorValue !== void 0) this._elementRef.nativeElement.color = colorValue;
			const opacityValue = this.opacity();
			if (opacityValue !== void 0) this._elementRef.nativeElement.opacity = opacityValue;
			const offsetValue = this.offset();
			if (offsetValue !== void 0) this._elementRef.nativeElement.offset = offsetValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: GaugeTextComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: GaugeTextComponent,
		isStandalone: true,
		selector: "mosaik-gauge-text",
		inputs: {
			x: {
				classPropertyName: "x",
				publicName: "x",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			y: {
				classPropertyName: "y",
				publicName: "y",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			fontSize: {
				classPropertyName: "fontSize",
				publicName: "fontSize",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			font: {
				classPropertyName: "font",
				publicName: "font",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			weight: {
				classPropertyName: "weight",
				publicName: "weight",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			anchor: {
				classPropertyName: "anchor",
				publicName: "anchor",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			text: {
				classPropertyName: "text",
				publicName: "text",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			color: {
				classPropertyName: "color",
				publicName: "color",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			opacity: {
				classPropertyName: "opacity",
				publicName: "opacity",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			offset: {
				classPropertyName: "offset",
				publicName: "offset",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
GaugeTextComponent = __decorate$7([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-gauge-text", GaugeTextElement),
	inputs: [
		"x",
		"y",
		"fontSize",
		"font",
		"weight",
		"anchor",
		"text",
		"color",
		"opacity",
		"offset",
		"themeName",
		"dir",
		"lang"
	]
}), __metadata$7("design:paramtypes", [])], GaugeTextComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: GaugeTextComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-gauge-text",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		x: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "x",
				required: false
			}]
		}],
		y: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "y",
				required: false
			}]
		}],
		fontSize: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "fontSize",
				required: false
			}]
		}],
		font: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "font",
				required: false
			}]
		}],
		weight: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "weight",
				required: false
			}]
		}],
		anchor: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "anchor",
				required: false
			}]
		}],
		text: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "text",
				required: false
			}]
		}],
		color: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "color",
				required: false
			}]
		}],
		opacity: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "opacity",
				required: false
			}]
		}],
		offset: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "offset",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideGaugeTextComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: GAUGE_TEXT_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$6 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$6 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const GAUGE_TICK_LABELS_DEFAULT_PROPS = new InjectionToken("MOSAIK_GAUGE_TICK_LABELS_DEFAULT_PROPS");
let GaugeTickLabelsComponent = class GaugeTickLabelsComponent {
	count = input(...ngDevMode ? [void 0, { debugName: "count" }] : /* istanbul ignore next */ []);
	fontSize = input(...ngDevMode ? [void 0, { debugName: "fontSize" }] : /* istanbul ignore next */ []);
	font = input(...ngDevMode ? [void 0, { debugName: "font" }] : /* istanbul ignore next */ []);
	weight = input(...ngDevMode ? [void 0, { debugName: "weight" }] : /* istanbul ignore next */ []);
	decimals = input(...ngDevMode ? [void 0, { debugName: "decimals" }] : /* istanbul ignore next */ []);
	format = input(...ngDevMode ? [void 0, { debugName: "format" }] : /* istanbul ignore next */ []);
	formatter = input(...ngDevMode ? [void 0, { debugName: "formatter" }] : /* istanbul ignore next */ []);
	color = input(...ngDevMode ? [void 0, { debugName: "color" }] : /* istanbul ignore next */ []);
	opacity = input(...ngDevMode ? [void 0, { debugName: "opacity" }] : /* istanbul ignore next */ []);
	offset = input(...ngDevMode ? [void 0, { debugName: "offset" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(GAUGE_TICK_LABELS_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	renderGauge(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "renderGauge", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const countValue = this.count();
			if (countValue !== void 0) this._elementRef.nativeElement.count = countValue;
			const fontSizeValue = this.fontSize();
			if (fontSizeValue !== void 0) this._elementRef.nativeElement.fontSize = fontSizeValue;
			const fontValue = this.font();
			if (fontValue !== void 0) this._elementRef.nativeElement.font = fontValue;
			const weightValue = this.weight();
			if (weightValue !== void 0) this._elementRef.nativeElement.weight = weightValue;
			const decimalsValue = this.decimals();
			if (decimalsValue !== void 0) this._elementRef.nativeElement.decimals = decimalsValue;
			const formatValue = this.format();
			if (formatValue !== void 0) this._elementRef.nativeElement.format = formatValue;
			const formatterValue = this.formatter();
			if (formatterValue !== void 0) this._elementRef.nativeElement.formatter = formatterValue;
			const colorValue = this.color();
			if (colorValue !== void 0) this._elementRef.nativeElement.color = colorValue;
			const opacityValue = this.opacity();
			if (opacityValue !== void 0) this._elementRef.nativeElement.opacity = opacityValue;
			const offsetValue = this.offset();
			if (offsetValue !== void 0) this._elementRef.nativeElement.offset = offsetValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: GaugeTickLabelsComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: GaugeTickLabelsComponent,
		isStandalone: true,
		selector: "mosaik-gauge-tick-labels",
		inputs: {
			count: {
				classPropertyName: "count",
				publicName: "count",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			fontSize: {
				classPropertyName: "fontSize",
				publicName: "fontSize",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			font: {
				classPropertyName: "font",
				publicName: "font",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			weight: {
				classPropertyName: "weight",
				publicName: "weight",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			decimals: {
				classPropertyName: "decimals",
				publicName: "decimals",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			format: {
				classPropertyName: "format",
				publicName: "format",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			formatter: {
				classPropertyName: "formatter",
				publicName: "formatter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			color: {
				classPropertyName: "color",
				publicName: "color",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			opacity: {
				classPropertyName: "opacity",
				publicName: "opacity",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			offset: {
				classPropertyName: "offset",
				publicName: "offset",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
GaugeTickLabelsComponent = __decorate$6([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-gauge-tick-labels", GaugeTickLabelsElement),
	inputs: [
		"count",
		"fontSize",
		"font",
		"weight",
		"decimals",
		"format",
		"formatter",
		"color",
		"opacity",
		"offset",
		"themeName",
		"dir",
		"lang"
	]
}), __metadata$6("design:paramtypes", [])], GaugeTickLabelsComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: GaugeTickLabelsComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-gauge-tick-labels",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		count: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "count",
				required: false
			}]
		}],
		fontSize: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "fontSize",
				required: false
			}]
		}],
		font: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "font",
				required: false
			}]
		}],
		weight: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "weight",
				required: false
			}]
		}],
		decimals: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "decimals",
				required: false
			}]
		}],
		format: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "format",
				required: false
			}]
		}],
		formatter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "formatter",
				required: false
			}]
		}],
		color: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "color",
				required: false
			}]
		}],
		opacity: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "opacity",
				required: false
			}]
		}],
		offset: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "offset",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideGaugeTickLabelsComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: GAUGE_TICK_LABELS_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$5 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$5 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const GAUGE_TICKS_DEFAULT_PROPS = new InjectionToken("MOSAIK_GAUGE_TICKS_DEFAULT_PROPS");
let GaugeTicksComponent = class GaugeTicksComponent {
	width = input(...ngDevMode ? [void 0, { debugName: "width" }] : /* istanbul ignore next */ []);
	cap = input(...ngDevMode ? [void 0, { debugName: "cap" }] : /* istanbul ignore next */ []);
	length = input(...ngDevMode ? [void 0, { debugName: "length" }] : /* istanbul ignore next */ []);
	count = input(...ngDevMode ? [void 0, { debugName: "count" }] : /* istanbul ignore next */ []);
	color = input(...ngDevMode ? [void 0, { debugName: "color" }] : /* istanbul ignore next */ []);
	opacity = input(...ngDevMode ? [void 0, { debugName: "opacity" }] : /* istanbul ignore next */ []);
	offset = input(...ngDevMode ? [void 0, { debugName: "offset" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(GAUGE_TICKS_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	renderGauge(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "renderGauge", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const widthValue = this.width();
			if (widthValue !== void 0) this._elementRef.nativeElement.width = widthValue;
			const capValue = this.cap();
			if (capValue !== void 0) this._elementRef.nativeElement.cap = capValue;
			const countValue = this.count();
			if (countValue !== void 0) this._elementRef.nativeElement.count = countValue;
			const colorValue = this.color();
			if (colorValue !== void 0) this._elementRef.nativeElement.color = colorValue;
			const opacityValue = this.opacity();
			if (opacityValue !== void 0) this._elementRef.nativeElement.opacity = opacityValue;
			const offsetValue = this.offset();
			if (offsetValue !== void 0) this._elementRef.nativeElement.offset = offsetValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: GaugeTicksComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: GaugeTicksComponent,
		isStandalone: true,
		selector: "mosaik-gauge-ticks",
		inputs: {
			width: {
				classPropertyName: "width",
				publicName: "width",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			cap: {
				classPropertyName: "cap",
				publicName: "cap",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			length: {
				classPropertyName: "length",
				publicName: "length",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			count: {
				classPropertyName: "count",
				publicName: "count",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			color: {
				classPropertyName: "color",
				publicName: "color",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			opacity: {
				classPropertyName: "opacity",
				publicName: "opacity",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			offset: {
				classPropertyName: "offset",
				publicName: "offset",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
GaugeTicksComponent = __decorate$5([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-gauge-ticks", GaugeTicksElement),
	inputs: [
		"width",
		"cap",
		"length",
		"count",
		"color",
		"opacity",
		"offset",
		"themeName",
		"dir",
		"lang"
	]
}), __metadata$5("design:paramtypes", [])], GaugeTicksComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: GaugeTicksComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-gauge-ticks",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		width: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "width",
				required: false
			}]
		}],
		cap: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "cap",
				required: false
			}]
		}],
		length: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "length",
				required: false
			}]
		}],
		count: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "count",
				required: false
			}]
		}],
		color: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "color",
				required: false
			}]
		}],
		opacity: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "opacity",
				required: false
			}]
		}],
		offset: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "offset",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideGaugeTicksComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: GAUGE_TICKS_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$4 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$4 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const GAUGE_TOOLTIP_DEFAULT_PROPS = new InjectionToken("MOSAIK_GAUGE_TOOLTIP_DEFAULT_PROPS");
let GaugeTooltipComponent = class GaugeTooltipComponent {
	isOpen = input(...ngDevMode ? [void 0, { debugName: "isOpen" }] : /* istanbul ignore next */ []);
	position = input(...ngDevMode ? [void 0, { debugName: "position" }] : /* istanbul ignore next */ []);
	side = input(...ngDevMode ? [void 0, { debugName: "side" }] : /* istanbul ignore next */ []);
	at = input(...ngDevMode ? [void 0, { debugName: "at" }] : /* istanbul ignore next */ []);
	gap = input(...ngDevMode ? [void 0, { debugName: "gap" }] : /* istanbul ignore next */ []);
	avoidCollisions = input(...ngDevMode ? [void 0, { debugName: "avoidCollisions" }] : /* istanbul ignore next */ []);
	collisionPadding = input(...ngDevMode ? [void 0, { debugName: "collisionPadding" }] : /* istanbul ignore next */ []);
	label = input(...ngDevMode ? [void 0, { debugName: "label" }] : /* istanbul ignore next */ []);
	unit = input(...ngDevMode ? [void 0, { debugName: "unit" }] : /* istanbul ignore next */ []);
	decimals = input(...ngDevMode ? [void 0, { debugName: "decimals" }] : /* istanbul ignore next */ []);
	format = input(...ngDevMode ? [void 0, { debugName: "format" }] : /* istanbul ignore next */ []);
	formatter = input(...ngDevMode ? [void 0, { debugName: "formatter" }] : /* istanbul ignore next */ []);
	contentRenderer = input(...ngDevMode ? [void 0, { debugName: "contentRenderer" }] : /* istanbul ignore next */ []);
	color = input(...ngDevMode ? [void 0, { debugName: "color" }] : /* istanbul ignore next */ []);
	opacity = input(...ngDevMode ? [void 0, { debugName: "opacity" }] : /* istanbul ignore next */ []);
	offset = input(...ngDevMode ? [void 0, { debugName: "offset" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(GAUGE_TOOLTIP_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	renderGauge(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "renderGauge", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const isOpenValue = this.isOpen();
			if (isOpenValue !== void 0) this._elementRef.nativeElement.isOpen = isOpenValue;
			const positionValue = this.position();
			if (positionValue !== void 0) this._elementRef.nativeElement.position = positionValue;
			const sideValue = this.side();
			if (sideValue !== void 0) this._elementRef.nativeElement.side = sideValue;
			const atValue = this.at();
			if (atValue !== void 0) this._elementRef.nativeElement.at = atValue;
			const gapValue = this.gap();
			if (gapValue !== void 0) this._elementRef.nativeElement.gap = gapValue;
			const avoidCollisionsValue = this.avoidCollisions();
			if (avoidCollisionsValue !== void 0) this._elementRef.nativeElement.avoidCollisions = avoidCollisionsValue;
			const collisionPaddingValue = this.collisionPadding();
			if (collisionPaddingValue !== void 0) this._elementRef.nativeElement.collisionPadding = collisionPaddingValue;
			const labelValue = this.label();
			if (labelValue !== void 0) this._elementRef.nativeElement.label = labelValue;
			const unitValue = this.unit();
			if (unitValue !== void 0) this._elementRef.nativeElement.unit = unitValue;
			const decimalsValue = this.decimals();
			if (decimalsValue !== void 0) this._elementRef.nativeElement.decimals = decimalsValue;
			const formatValue = this.format();
			if (formatValue !== void 0) this._elementRef.nativeElement.format = formatValue;
			const formatterValue = this.formatter();
			if (formatterValue !== void 0) this._elementRef.nativeElement.formatter = formatterValue;
			const contentRendererValue = this.contentRenderer();
			if (contentRendererValue !== void 0) this._elementRef.nativeElement.contentRenderer = contentRendererValue;
			const colorValue = this.color();
			if (colorValue !== void 0) this._elementRef.nativeElement.color = colorValue;
			const opacityValue = this.opacity();
			if (opacityValue !== void 0) this._elementRef.nativeElement.opacity = opacityValue;
			const offsetValue = this.offset();
			if (offsetValue !== void 0) this._elementRef.nativeElement.offset = offsetValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: GaugeTooltipComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: GaugeTooltipComponent,
		isStandalone: true,
		selector: "mosaik-gauge-tooltip",
		inputs: {
			isOpen: {
				classPropertyName: "isOpen",
				publicName: "isOpen",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			position: {
				classPropertyName: "position",
				publicName: "position",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			side: {
				classPropertyName: "side",
				publicName: "side",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			at: {
				classPropertyName: "at",
				publicName: "at",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			gap: {
				classPropertyName: "gap",
				publicName: "gap",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			avoidCollisions: {
				classPropertyName: "avoidCollisions",
				publicName: "avoidCollisions",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			collisionPadding: {
				classPropertyName: "collisionPadding",
				publicName: "collisionPadding",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			unit: {
				classPropertyName: "unit",
				publicName: "unit",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			decimals: {
				classPropertyName: "decimals",
				publicName: "decimals",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			format: {
				classPropertyName: "format",
				publicName: "format",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			formatter: {
				classPropertyName: "formatter",
				publicName: "formatter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			contentRenderer: {
				classPropertyName: "contentRenderer",
				publicName: "contentRenderer",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			color: {
				classPropertyName: "color",
				publicName: "color",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			opacity: {
				classPropertyName: "opacity",
				publicName: "opacity",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			offset: {
				classPropertyName: "offset",
				publicName: "offset",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
GaugeTooltipComponent = __decorate$4([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-gauge-tooltip", GaugeTooltipElement),
	inputs: [
		"isOpen",
		"position",
		"side",
		"at",
		"gap",
		"avoidCollisions",
		"collisionPadding",
		"label",
		"unit",
		"decimals",
		"format",
		"formatter",
		"contentRenderer",
		"color",
		"opacity",
		"offset",
		"themeName",
		"dir",
		"lang"
	]
}), __metadata$4("design:paramtypes", [])], GaugeTooltipComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: GaugeTooltipComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-gauge-tooltip",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		isOpen: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isOpen",
				required: false
			}]
		}],
		position: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "position",
				required: false
			}]
		}],
		side: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "side",
				required: false
			}]
		}],
		at: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "at",
				required: false
			}]
		}],
		gap: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "gap",
				required: false
			}]
		}],
		avoidCollisions: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "avoidCollisions",
				required: false
			}]
		}],
		collisionPadding: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "collisionPadding",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		unit: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "unit",
				required: false
			}]
		}],
		decimals: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "decimals",
				required: false
			}]
		}],
		format: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "format",
				required: false
			}]
		}],
		formatter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "formatter",
				required: false
			}]
		}],
		contentRenderer: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "contentRenderer",
				required: false
			}]
		}],
		color: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "color",
				required: false
			}]
		}],
		opacity: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "opacity",
				required: false
			}]
		}],
		offset: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "offset",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideGaugeTooltipComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: GAUGE_TOOLTIP_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$3 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$3 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const GAUGE_TRACK_DEFAULT_PROPS = new InjectionToken("MOSAIK_GAUGE_TRACK_DEFAULT_PROPS");
let GaugeTrackComponent = class GaugeTrackComponent {
	width = input(...ngDevMode ? [void 0, { debugName: "width" }] : /* istanbul ignore next */ []);
	cap = input(...ngDevMode ? [void 0, { debugName: "cap" }] : /* istanbul ignore next */ []);
	color = input(...ngDevMode ? [void 0, { debugName: "color" }] : /* istanbul ignore next */ []);
	opacity = input(...ngDevMode ? [void 0, { debugName: "opacity" }] : /* istanbul ignore next */ []);
	offset = input(...ngDevMode ? [void 0, { debugName: "offset" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(GAUGE_TRACK_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	renderGauge(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "renderGauge", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const widthValue = this.width();
			if (widthValue !== void 0) this._elementRef.nativeElement.width = widthValue;
			const capValue = this.cap();
			if (capValue !== void 0) this._elementRef.nativeElement.cap = capValue;
			const colorValue = this.color();
			if (colorValue !== void 0) this._elementRef.nativeElement.color = colorValue;
			const opacityValue = this.opacity();
			if (opacityValue !== void 0) this._elementRef.nativeElement.opacity = opacityValue;
			const offsetValue = this.offset();
			if (offsetValue !== void 0) this._elementRef.nativeElement.offset = offsetValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: GaugeTrackComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: GaugeTrackComponent,
		isStandalone: true,
		selector: "mosaik-gauge-track",
		inputs: {
			width: {
				classPropertyName: "width",
				publicName: "width",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			cap: {
				classPropertyName: "cap",
				publicName: "cap",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			color: {
				classPropertyName: "color",
				publicName: "color",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			opacity: {
				classPropertyName: "opacity",
				publicName: "opacity",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			offset: {
				classPropertyName: "offset",
				publicName: "offset",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
GaugeTrackComponent = __decorate$3([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-gauge-track", GaugeTrackElement),
	inputs: [
		"width",
		"cap",
		"color",
		"opacity",
		"offset",
		"themeName",
		"dir",
		"lang"
	]
}), __metadata$3("design:paramtypes", [])], GaugeTrackComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: GaugeTrackComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-gauge-track",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		width: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "width",
				required: false
			}]
		}],
		cap: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "cap",
				required: false
			}]
		}],
		color: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "color",
				required: false
			}]
		}],
		opacity: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "opacity",
				required: false
			}]
		}],
		offset: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "offset",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideGaugeTrackComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: GAUGE_TRACK_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$2 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$2 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const GAUGE_VALUE_DEFAULT_PROPS = new InjectionToken("MOSAIK_GAUGE_VALUE_DEFAULT_PROPS");
let GaugeValueComponent = class GaugeValueComponent {
	x = input(...ngDevMode ? [void 0, { debugName: "x" }] : /* istanbul ignore next */ []);
	y = input(...ngDevMode ? [void 0, { debugName: "y" }] : /* istanbul ignore next */ []);
	fontSize = input(...ngDevMode ? [void 0, { debugName: "fontSize" }] : /* istanbul ignore next */ []);
	font = input(...ngDevMode ? [void 0, { debugName: "font" }] : /* istanbul ignore next */ []);
	weight = input(...ngDevMode ? [void 0, { debugName: "weight" }] : /* istanbul ignore next */ []);
	anchor = input(...ngDevMode ? [void 0, { debugName: "anchor" }] : /* istanbul ignore next */ []);
	decimals = input(...ngDevMode ? [void 0, { debugName: "decimals" }] : /* istanbul ignore next */ []);
	format = input(...ngDevMode ? [void 0, { debugName: "format" }] : /* istanbul ignore next */ []);
	unit = input(...ngDevMode ? [void 0, { debugName: "unit" }] : /* istanbul ignore next */ []);
	formatter = input(...ngDevMode ? [void 0, { debugName: "formatter" }] : /* istanbul ignore next */ []);
	color = input(...ngDevMode ? [void 0, { debugName: "color" }] : /* istanbul ignore next */ []);
	opacity = input(...ngDevMode ? [void 0, { debugName: "opacity" }] : /* istanbul ignore next */ []);
	offset = input(...ngDevMode ? [void 0, { debugName: "offset" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(GAUGE_VALUE_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	renderGauge(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "renderGauge", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const xValue = this.x();
			if (xValue !== void 0) this._elementRef.nativeElement.x = xValue;
			const yValue = this.y();
			if (yValue !== void 0) this._elementRef.nativeElement.y = yValue;
			const fontSizeValue = this.fontSize();
			if (fontSizeValue !== void 0) this._elementRef.nativeElement.fontSize = fontSizeValue;
			const fontValue = this.font();
			if (fontValue !== void 0) this._elementRef.nativeElement.font = fontValue;
			const weightValue = this.weight();
			if (weightValue !== void 0) this._elementRef.nativeElement.weight = weightValue;
			const anchorValue = this.anchor();
			if (anchorValue !== void 0) this._elementRef.nativeElement.anchor = anchorValue;
			const decimalsValue = this.decimals();
			if (decimalsValue !== void 0) this._elementRef.nativeElement.decimals = decimalsValue;
			const formatValue = this.format();
			if (formatValue !== void 0) this._elementRef.nativeElement.format = formatValue;
			const unitValue = this.unit();
			if (unitValue !== void 0) this._elementRef.nativeElement.unit = unitValue;
			const formatterValue = this.formatter();
			if (formatterValue !== void 0) this._elementRef.nativeElement.formatter = formatterValue;
			const colorValue = this.color();
			if (colorValue !== void 0) this._elementRef.nativeElement.color = colorValue;
			const opacityValue = this.opacity();
			if (opacityValue !== void 0) this._elementRef.nativeElement.opacity = opacityValue;
			const offsetValue = this.offset();
			if (offsetValue !== void 0) this._elementRef.nativeElement.offset = offsetValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: GaugeValueComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: GaugeValueComponent,
		isStandalone: true,
		selector: "mosaik-gauge-value",
		inputs: {
			x: {
				classPropertyName: "x",
				publicName: "x",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			y: {
				classPropertyName: "y",
				publicName: "y",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			fontSize: {
				classPropertyName: "fontSize",
				publicName: "fontSize",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			font: {
				classPropertyName: "font",
				publicName: "font",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			weight: {
				classPropertyName: "weight",
				publicName: "weight",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			anchor: {
				classPropertyName: "anchor",
				publicName: "anchor",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			decimals: {
				classPropertyName: "decimals",
				publicName: "decimals",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			format: {
				classPropertyName: "format",
				publicName: "format",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			unit: {
				classPropertyName: "unit",
				publicName: "unit",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			formatter: {
				classPropertyName: "formatter",
				publicName: "formatter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			color: {
				classPropertyName: "color",
				publicName: "color",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			opacity: {
				classPropertyName: "opacity",
				publicName: "opacity",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			offset: {
				classPropertyName: "offset",
				publicName: "offset",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
GaugeValueComponent = __decorate$2([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-gauge-value", GaugeValueElement),
	inputs: [
		"x",
		"y",
		"fontSize",
		"font",
		"weight",
		"anchor",
		"decimals",
		"format",
		"unit",
		"formatter",
		"color",
		"opacity",
		"offset",
		"themeName",
		"dir",
		"lang"
	]
}), __metadata$2("design:paramtypes", [])], GaugeValueComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: GaugeValueComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-gauge-value",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		x: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "x",
				required: false
			}]
		}],
		y: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "y",
				required: false
			}]
		}],
		fontSize: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "fontSize",
				required: false
			}]
		}],
		font: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "font",
				required: false
			}]
		}],
		weight: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "weight",
				required: false
			}]
		}],
		anchor: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "anchor",
				required: false
			}]
		}],
		decimals: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "decimals",
				required: false
			}]
		}],
		format: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "format",
				required: false
			}]
		}],
		unit: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "unit",
				required: false
			}]
		}],
		formatter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "formatter",
				required: false
			}]
		}],
		color: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "color",
				required: false
			}]
		}],
		opacity: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "opacity",
				required: false
			}]
		}],
		offset: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "offset",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideGaugeValueComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: GAUGE_VALUE_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$1 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$1 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const GAUGE_ZONES_DEFAULT_PROPS = new InjectionToken("MOSAIK_GAUGE_ZONES_DEFAULT_PROPS");
let GaugeZonesComponent = class GaugeZonesComponent {
	width = input(...ngDevMode ? [void 0, { debugName: "width" }] : /* istanbul ignore next */ []);
	cap = input(...ngDevMode ? [void 0, { debugName: "cap" }] : /* istanbul ignore next */ []);
	endCap = input(...ngDevMode ? [void 0, { debugName: "endCap" }] : /* istanbul ignore next */ []);
	gap = input(...ngDevMode ? [void 0, { debugName: "gap" }] : /* istanbul ignore next */ []);
	zones = input(...ngDevMode ? [void 0, { debugName: "zones" }] : /* istanbul ignore next */ []);
	color = input(...ngDevMode ? [void 0, { debugName: "color" }] : /* istanbul ignore next */ []);
	opacity = input(...ngDevMode ? [void 0, { debugName: "opacity" }] : /* istanbul ignore next */ []);
	offset = input(...ngDevMode ? [void 0, { debugName: "offset" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(GAUGE_ZONES_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	renderGauge(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "renderGauge", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const widthValue = this.width();
			if (widthValue !== void 0) this._elementRef.nativeElement.width = widthValue;
			const capValue = this.cap();
			if (capValue !== void 0) this._elementRef.nativeElement.cap = capValue;
			const endCapValue = this.endCap();
			if (endCapValue !== void 0) this._elementRef.nativeElement.endCap = endCapValue;
			const gapValue = this.gap();
			if (gapValue !== void 0) this._elementRef.nativeElement.gap = gapValue;
			const zonesValue = this.zones();
			if (zonesValue !== void 0) this._elementRef.nativeElement.zones = zonesValue;
			const colorValue = this.color();
			if (colorValue !== void 0) this._elementRef.nativeElement.color = colorValue;
			const opacityValue = this.opacity();
			if (opacityValue !== void 0) this._elementRef.nativeElement.opacity = opacityValue;
			const offsetValue = this.offset();
			if (offsetValue !== void 0) this._elementRef.nativeElement.offset = offsetValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: GaugeZonesComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: GaugeZonesComponent,
		isStandalone: true,
		selector: "mosaik-gauge-zones",
		inputs: {
			width: {
				classPropertyName: "width",
				publicName: "width",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			cap: {
				classPropertyName: "cap",
				publicName: "cap",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			endCap: {
				classPropertyName: "endCap",
				publicName: "endCap",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			gap: {
				classPropertyName: "gap",
				publicName: "gap",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			zones: {
				classPropertyName: "zones",
				publicName: "zones",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			color: {
				classPropertyName: "color",
				publicName: "color",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			opacity: {
				classPropertyName: "opacity",
				publicName: "opacity",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			offset: {
				classPropertyName: "offset",
				publicName: "offset",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
GaugeZonesComponent = __decorate$1([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-gauge-zones", GaugeZonesElement),
	inputs: [
		"width",
		"cap",
		"endCap",
		"gap",
		"zones",
		"color",
		"opacity",
		"offset",
		"themeName",
		"dir",
		"lang"
	]
}), __metadata$1("design:paramtypes", [])], GaugeZonesComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: GaugeZonesComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-gauge-zones",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		width: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "width",
				required: false
			}]
		}],
		cap: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "cap",
				required: false
			}]
		}],
		endCap: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "endCap",
				required: false
			}]
		}],
		gap: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "gap",
				required: false
			}]
		}],
		zones: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "zones",
				required: false
			}]
		}],
		color: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "color",
				required: false
			}]
		}],
		opacity: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "opacity",
				required: false
			}]
		}],
		offset: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "offset",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideGaugeZonesComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: GAUGE_ZONES_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const GAUGE_DEFAULT_PROPS = new InjectionToken("MOSAIK_GAUGE_DEFAULT_PROPS");
let GaugeComponent = class GaugeComponent {
	padding = input(...ngDevMode ? [void 0, { debugName: "padding" }] : /* istanbul ignore next */ []);
	fit = input(...ngDevMode ? [void 0, { debugName: "fit" }] : /* istanbul ignore next */ []);
	transition = input(...ngDevMode ? [void 0, { debugName: "transition" }] : /* istanbul ignore next */ []);
	startAngle = input(...ngDevMode ? [void 0, { debugName: "startAngle" }] : /* istanbul ignore next */ []);
	endAngle = input(...ngDevMode ? [void 0, { debugName: "endAngle" }] : /* istanbul ignore next */ []);
	radius = input(...ngDevMode ? [void 0, { debugName: "radius" }] : /* istanbul ignore next */ []);
	rotate = input(...ngDevMode ? [void 0, { debugName: "rotate" }] : /* istanbul ignore next */ []);
	wrap = input(...ngDevMode ? [void 0, { debugName: "wrap" }] : /* istanbul ignore next */ []);
	initialValue = input(...ngDevMode ? [void 0, { debugName: "initialValue" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	label = input(...ngDevMode ? [void 0, { debugName: "label" }] : /* istanbul ignore next */ []);
	min = input(...ngDevMode ? [void 0, { debugName: "min" }] : /* istanbul ignore next */ []);
	max = input(...ngDevMode ? [void 0, { debugName: "max" }] : /* istanbul ignore next */ []);
	value = input(...ngDevMode ? [void 0, { debugName: "value" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	rangeValueChanged = output();
	changed = output();
	connected = output();
	disconnected = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			rangeValueChanged: this.rangeValueChanged,
			changed: this.changed,
			connected: this.connected,
			disconnected: this.disconnected
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(GAUGE_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	renderGauge(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "renderGauge", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const paddingValue = this.padding();
			if (paddingValue !== void 0) this._elementRef.nativeElement.padding = paddingValue;
			const fitValue = this.fit();
			if (fitValue !== void 0) this._elementRef.nativeElement.fit = fitValue;
			const transitionValue = this.transition();
			if (transitionValue !== void 0) this._elementRef.nativeElement.transition = transitionValue;
			const startAngleValue = this.startAngle();
			if (startAngleValue !== void 0) this._elementRef.nativeElement.startAngle = startAngleValue;
			const endAngleValue = this.endAngle();
			if (endAngleValue !== void 0) this._elementRef.nativeElement.endAngle = endAngleValue;
			const radiusValue = this.radius();
			if (radiusValue !== void 0) this._elementRef.nativeElement.radius = radiusValue;
			const rotateValue = this.rotate();
			if (rotateValue !== void 0) this._elementRef.nativeElement.rotate = rotateValue;
			const wrapValue = this.wrap();
			if (wrapValue !== void 0) this._elementRef.nativeElement.wrap = wrapValue;
			const initialValueValue = this.initialValue();
			if (initialValueValue !== void 0) this._elementRef.nativeElement.initialValue = initialValueValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const labelValue = this.label();
			if (labelValue !== void 0) this._elementRef.nativeElement.label = labelValue;
			const minValue = this.min();
			if (minValue !== void 0) this._elementRef.nativeElement.min = minValue;
			const maxValue = this.max();
			if (maxValue !== void 0) this._elementRef.nativeElement.max = maxValue;
			const valueValue = this.value();
			if (valueValue !== void 0) this._elementRef.nativeElement.value = valueValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: GaugeComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: GaugeComponent,
		isStandalone: true,
		selector: "mosaik-gauge",
		inputs: {
			padding: {
				classPropertyName: "padding",
				publicName: "padding",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			fit: {
				classPropertyName: "fit",
				publicName: "fit",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			transition: {
				classPropertyName: "transition",
				publicName: "transition",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			startAngle: {
				classPropertyName: "startAngle",
				publicName: "startAngle",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			endAngle: {
				classPropertyName: "endAngle",
				publicName: "endAngle",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			radius: {
				classPropertyName: "radius",
				publicName: "radius",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			rotate: {
				classPropertyName: "rotate",
				publicName: "rotate",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			wrap: {
				classPropertyName: "wrap",
				publicName: "wrap",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			initialValue: {
				classPropertyName: "initialValue",
				publicName: "initialValue",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			min: {
				classPropertyName: "min",
				publicName: "min",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			max: {
				classPropertyName: "max",
				publicName: "max",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			rangeValueChanged: "rangeValueChanged",
			changed: "changed",
			connected: "connected",
			disconnected: "disconnected"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
GaugeComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-gauge", GaugeElement),
	inputs: [
		"padding",
		"fit",
		"transition",
		"startAngle",
		"endAngle",
		"radius",
		"rotate",
		"wrap",
		"initialValue",
		"themeName",
		"label",
		"min",
		"max",
		"value",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], GaugeComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: GaugeComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-gauge",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		padding: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "padding",
				required: false
			}]
		}],
		fit: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "fit",
				required: false
			}]
		}],
		transition: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "transition",
				required: false
			}]
		}],
		startAngle: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "startAngle",
				required: false
			}]
		}],
		endAngle: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "endAngle",
				required: false
			}]
		}],
		radius: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "radius",
				required: false
			}]
		}],
		rotate: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "rotate",
				required: false
			}]
		}],
		wrap: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "wrap",
				required: false
			}]
		}],
		initialValue: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "initialValue",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		min: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "min",
				required: false
			}]
		}],
		max: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "max",
				required: false
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		rangeValueChanged: [{
			type: i0.Output,
			args: ["rangeValueChanged"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}]
	}
});
function provideGaugeComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: GAUGE_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { GAUGE_ARC_DEFAULT_PROPS, GAUGE_CONTROL_DEFAULT_PROPS, GAUGE_DEFAULT_PROPS, GAUGE_DOT_DEFAULT_PROPS, GAUGE_HUB_DEFAULT_PROPS, GAUGE_INSET_DEFAULT_PROPS, GAUGE_MARKS_DEFAULT_PROPS, GAUGE_NEEDLE_DEFAULT_PROPS, GAUGE_STACK_DEFAULT_PROPS, GAUGE_TEXT_DEFAULT_PROPS, GAUGE_TICKS_DEFAULT_PROPS, GAUGE_TICK_LABELS_DEFAULT_PROPS, GAUGE_TOOLTIP_DEFAULT_PROPS, GAUGE_TRACK_DEFAULT_PROPS, GAUGE_VALUE_DEFAULT_PROPS, GAUGE_ZONES_DEFAULT_PROPS, GaugeArcComponent, GaugeComponent, GaugeControlComponent, GaugeDotComponent, GaugeHubComponent, GaugeInsetComponent, GaugeMarksComponent, GaugeNeedleComponent, GaugeStackComponent, GaugeTextComponent, GaugeTickLabelsComponent, GaugeTicksComponent, GaugeTooltipComponent, GaugeTrackComponent, GaugeValueComponent, GaugeZonesComponent, provideGaugeArcComponent, provideGaugeComponent, provideGaugeControlComponent, provideGaugeDotComponent, provideGaugeHubComponent, provideGaugeInsetComponent, provideGaugeMarksComponent, provideGaugeNeedleComponent, provideGaugeStackComponent, provideGaugeTextComponent, provideGaugeTickLabelsComponent, provideGaugeTicksComponent, provideGaugeTooltipComponent, provideGaugeTrackComponent, provideGaugeValueComponent, provideGaugeZonesComponent };

//# sourceMappingURL=mosaik-elements-angular-components-gauge.mjs.map