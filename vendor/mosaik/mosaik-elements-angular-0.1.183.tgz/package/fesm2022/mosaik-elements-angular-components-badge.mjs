import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { BadgeElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/badge/BadgeElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const BADGE_DEFAULT_PROPS = new InjectionToken("MOSAIK_BADGE_DEFAULT_PROPS");
let BadgeComponent = class BadgeComponent {
	icon = input(...ngDevMode ? [void 0, { debugName: "icon" }] : /* istanbul ignore next */ []);
	overlap = input(...ngDevMode ? [void 0, { debugName: "overlap" }] : /* istanbul ignore next */ []);
	attached = input(...ngDevMode ? [void 0, { debugName: "attached" }] : /* istanbul ignore next */ []);
	position = input(...ngDevMode ? [void 0, { debugName: "position" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	appearance = input(...ngDevMode ? [void 0, { debugName: "appearance" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	size = input(...ngDevMode ? [void 0, { debugName: "size" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	label = input(...ngDevMode ? [void 0, { debugName: "label" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(BADGE_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const iconValue = this.icon();
			if (iconValue !== void 0) this._elementRef.nativeElement.icon = iconValue;
			const overlapValue = this.overlap();
			if (overlapValue !== void 0) this._elementRef.nativeElement.overlap = overlapValue;
			const positionValue = this.position();
			if (positionValue !== void 0) this._elementRef.nativeElement.position = positionValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const appearanceValue = this.appearance();
			if (appearanceValue !== void 0) this._elementRef.nativeElement.appearance = appearanceValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const sizeValue = this.size();
			if (sizeValue !== void 0) this._elementRef.nativeElement.size = sizeValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const labelValue = this.label();
			if (labelValue !== void 0) this._elementRef.nativeElement.label = labelValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: BadgeComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: BadgeComponent,
		isStandalone: true,
		selector: "mosaik-badge",
		inputs: {
			icon: {
				classPropertyName: "icon",
				publicName: "icon",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			overlap: {
				classPropertyName: "overlap",
				publicName: "overlap",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			attached: {
				classPropertyName: "attached",
				publicName: "attached",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			position: {
				classPropertyName: "position",
				publicName: "position",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
BadgeComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-badge", BadgeElement),
	inputs: [
		"icon",
		"overlap",
		"attached",
		"position",
		"themeName",
		"appearance",
		"variant",
		"size",
		"disabled",
		"label",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], BadgeComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: BadgeComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-badge",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		icon: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "icon",
				required: false
			}]
		}],
		overlap: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "overlap",
				required: false
			}]
		}],
		attached: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "attached",
				required: false
			}]
		}],
		position: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "position",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideBadgeComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: BADGE_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { BADGE_DEFAULT_PROPS, BadgeComponent, provideBadgeComponent };

//# sourceMappingURL=mosaik-elements-angular-components-badge.mjs.map