import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { TileManagerTileElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/tile-manager/TileManagerTileElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { TileManagerElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/tile-manager/TileManagerElement";
var __decorate$1 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$1 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const TILE_MANAGER_TILE_DEFAULT_PROPS = new InjectionToken("MOSAIK_TILE_MANAGER_TILE_DEFAULT_PROPS");
let TileManagerTileComponent = class TileManagerTileComponent {
	intl = input(...ngDevMode ? [void 0, { debugName: "intl" }] : /* istanbul ignore next */ []);
	colSpan = input(...ngDevMode ? [void 0, { debugName: "colSpan" }] : /* istanbul ignore next */ []);
	rowSpan = input(...ngDevMode ? [void 0, { debugName: "rowSpan" }] : /* istanbul ignore next */ []);
	colStart = input(...ngDevMode ? [void 0, { debugName: "colStart" }] : /* istanbul ignore next */ []);
	rowStart = input(...ngDevMode ? [void 0, { debugName: "rowStart" }] : /* istanbul ignore next */ []);
	position = input(...ngDevMode ? [void 0, { debugName: "position" }] : /* istanbul ignore next */ []);
	maximized = input(...ngDevMode ? [void 0, { debugName: "maximized" }] : /* istanbul ignore next */ []);
	disableResize = input(...ngDevMode ? [void 0, { debugName: "disableResize" }] : /* istanbul ignore next */ []);
	disableFullscreen = input(...ngDevMode ? [void 0, { debugName: "disableFullscreen" }] : /* istanbul ignore next */ []);
	disableMaximize = input(...ngDevMode ? [void 0, { debugName: "disableMaximize" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	tileFullscreen = output();
	tileMaximize = output();
	tileDragStart = output();
	tileDragEnd = output();
	tileDragCancel = output();
	tileResizeStart = output();
	tileResizeEnd = output();
	tileResizeCancel = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			tileFullscreen: this.tileFullscreen,
			tileMaximize: this.tileMaximize,
			tileDragStart: this.tileDragStart,
			tileDragEnd: this.tileDragEnd,
			tileDragCancel: this.tileDragCancel,
			tileResizeStart: this.tileResizeStart,
			tileResizeEnd: this.tileResizeEnd,
			tileResizeCancel: this.tileResizeCancel,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(TILE_MANAGER_TILE_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setDragState(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "setDragState", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const colSpanValue = this.colSpan();
			if (colSpanValue !== void 0) this._elementRef.nativeElement.colSpan = colSpanValue;
			const rowSpanValue = this.rowSpan();
			if (rowSpanValue !== void 0) this._elementRef.nativeElement.rowSpan = rowSpanValue;
			const colStartValue = this.colStart();
			if (colStartValue !== void 0) this._elementRef.nativeElement.colStart = colStartValue;
			const rowStartValue = this.rowStart();
			if (rowStartValue !== void 0) this._elementRef.nativeElement.rowStart = rowStartValue;
			const positionValue = this.position();
			if (positionValue !== void 0) this._elementRef.nativeElement.position = positionValue;
			const maximizedValue = this.maximized();
			if (maximizedValue !== void 0) this._elementRef.nativeElement.maximized = maximizedValue;
			const disableResizeValue = this.disableResize();
			if (disableResizeValue !== void 0) this._elementRef.nativeElement.disableResize = disableResizeValue;
			const disableFullscreenValue = this.disableFullscreen();
			if (disableFullscreenValue !== void 0) this._elementRef.nativeElement.disableFullscreen = disableFullscreenValue;
			const disableMaximizeValue = this.disableMaximize();
			if (disableMaximizeValue !== void 0) this._elementRef.nativeElement.disableMaximize = disableMaximizeValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: TileManagerTileComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: TileManagerTileComponent,
		isStandalone: true,
		selector: "mosaik-tile-manager-tile",
		inputs: {
			intl: {
				classPropertyName: "intl",
				publicName: "intl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			colSpan: {
				classPropertyName: "colSpan",
				publicName: "colSpan",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			rowSpan: {
				classPropertyName: "rowSpan",
				publicName: "rowSpan",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			colStart: {
				classPropertyName: "colStart",
				publicName: "colStart",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			rowStart: {
				classPropertyName: "rowStart",
				publicName: "rowStart",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			position: {
				classPropertyName: "position",
				publicName: "position",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			maximized: {
				classPropertyName: "maximized",
				publicName: "maximized",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disableResize: {
				classPropertyName: "disableResize",
				publicName: "disableResize",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disableFullscreen: {
				classPropertyName: "disableFullscreen",
				publicName: "disableFullscreen",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disableMaximize: {
				classPropertyName: "disableMaximize",
				publicName: "disableMaximize",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			tileFullscreen: "tileFullscreen",
			tileMaximize: "tileMaximize",
			tileDragStart: "tileDragStart",
			tileDragEnd: "tileDragEnd",
			tileDragCancel: "tileDragCancel",
			tileResizeStart: "tileResizeStart",
			tileResizeEnd: "tileResizeEnd",
			tileResizeCancel: "tileResizeCancel",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
TileManagerTileComponent = __decorate$1([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-tile-manager-tile", TileManagerTileElement),
	inputs: [
		"intl",
		"colSpan",
		"rowSpan",
		"colStart",
		"rowStart",
		"position",
		"maximized",
		"disableResize",
		"disableFullscreen",
		"disableMaximize",
		"themeName",
		"dir",
		"lang"
	]
}), __metadata$1("design:paramtypes", [])], TileManagerTileComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: TileManagerTileComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-tile-manager-tile",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		intl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "intl",
				required: false
			}]
		}],
		colSpan: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "colSpan",
				required: false
			}]
		}],
		rowSpan: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "rowSpan",
				required: false
			}]
		}],
		colStart: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "colStart",
				required: false
			}]
		}],
		rowStart: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "rowStart",
				required: false
			}]
		}],
		position: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "position",
				required: false
			}]
		}],
		maximized: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maximized",
				required: false
			}]
		}],
		disableResize: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disableResize",
				required: false
			}]
		}],
		disableFullscreen: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disableFullscreen",
				required: false
			}]
		}],
		disableMaximize: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disableMaximize",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		tileFullscreen: [{
			type: i0.Output,
			args: ["tileFullscreen"]
		}],
		tileMaximize: [{
			type: i0.Output,
			args: ["tileMaximize"]
		}],
		tileDragStart: [{
			type: i0.Output,
			args: ["tileDragStart"]
		}],
		tileDragEnd: [{
			type: i0.Output,
			args: ["tileDragEnd"]
		}],
		tileDragCancel: [{
			type: i0.Output,
			args: ["tileDragCancel"]
		}],
		tileResizeStart: [{
			type: i0.Output,
			args: ["tileResizeStart"]
		}],
		tileResizeEnd: [{
			type: i0.Output,
			args: ["tileResizeEnd"]
		}],
		tileResizeCancel: [{
			type: i0.Output,
			args: ["tileResizeCancel"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideTileManagerTileComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: TILE_MANAGER_TILE_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const TILE_MANAGER_DEFAULT_PROPS = new InjectionToken("MOSAIK_TILE_MANAGER_DEFAULT_PROPS");
let TileManagerComponent = class TileManagerComponent {
	intl = input(...ngDevMode ? [void 0, { debugName: "intl" }] : /* istanbul ignore next */ []);
	resizeMode = input(...ngDevMode ? [void 0, { debugName: "resizeMode" }] : /* istanbul ignore next */ []);
	dragMode = input(...ngDevMode ? [void 0, { debugName: "dragMode" }] : /* istanbul ignore next */ []);
	columnCount = input(...ngDevMode ? [void 0, { debugName: "columnCount" }] : /* istanbul ignore next */ []);
	minColumnWidth = input(...ngDevMode ? [void 0, { debugName: "minColumnWidth" }] : /* istanbul ignore next */ []);
	minRowHeight = input(...ngDevMode ? [void 0, { debugName: "minRowHeight" }] : /* istanbul ignore next */ []);
	gap = input(...ngDevMode ? [void 0, { debugName: "gap" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	layoutChanged = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			layoutChanged: this.layoutChanged,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(TILE_MANAGER_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	saveLayout(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "saveLayout", args);
	}
	saveLayoutAsJSON(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "saveLayoutAsJSON", args);
	}
	loadLayout(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "loadLayout", args);
	}
	loadLayoutFromJSON(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "loadLayoutFromJSON", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const dragModeValue = this.dragMode();
			if (dragModeValue !== void 0) this._elementRef.nativeElement.dragMode = dragModeValue;
			const columnCountValue = this.columnCount();
			if (columnCountValue !== void 0) this._elementRef.nativeElement.columnCount = columnCountValue;
			const minColumnWidthValue = this.minColumnWidth();
			if (minColumnWidthValue !== void 0) this._elementRef.nativeElement.minColumnWidth = minColumnWidthValue;
			const minRowHeightValue = this.minRowHeight();
			if (minRowHeightValue !== void 0) this._elementRef.nativeElement.minRowHeight = minRowHeightValue;
			const gapValue = this.gap();
			if (gapValue !== void 0) this._elementRef.nativeElement.gap = gapValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: TileManagerComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: TileManagerComponent,
		isStandalone: true,
		selector: "mosaik-tile-manager",
		inputs: {
			intl: {
				classPropertyName: "intl",
				publicName: "intl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			resizeMode: {
				classPropertyName: "resizeMode",
				publicName: "resizeMode",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dragMode: {
				classPropertyName: "dragMode",
				publicName: "dragMode",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			columnCount: {
				classPropertyName: "columnCount",
				publicName: "columnCount",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			minColumnWidth: {
				classPropertyName: "minColumnWidth",
				publicName: "minColumnWidth",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			minRowHeight: {
				classPropertyName: "minRowHeight",
				publicName: "minRowHeight",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			gap: {
				classPropertyName: "gap",
				publicName: "gap",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			layoutChanged: "layoutChanged",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
TileManagerComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-tile-manager", TileManagerElement),
	inputs: [
		"intl",
		"resizeMode",
		"dragMode",
		"columnCount",
		"minColumnWidth",
		"minRowHeight",
		"gap",
		"themeName",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], TileManagerComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: TileManagerComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-tile-manager",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		intl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "intl",
				required: false
			}]
		}],
		resizeMode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "resizeMode",
				required: false
			}]
		}],
		dragMode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dragMode",
				required: false
			}]
		}],
		columnCount: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "columnCount",
				required: false
			}]
		}],
		minColumnWidth: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "minColumnWidth",
				required: false
			}]
		}],
		minRowHeight: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "minRowHeight",
				required: false
			}]
		}],
		gap: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "gap",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		layoutChanged: [{
			type: i0.Output,
			args: ["layoutChanged"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideTileManagerComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: TILE_MANAGER_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { TILE_MANAGER_DEFAULT_PROPS, TILE_MANAGER_TILE_DEFAULT_PROPS, TileManagerComponent, TileManagerTileComponent, provideTileManagerComponent, provideTileManagerTileComponent };

//# sourceMappingURL=mosaik-elements-angular-components-tile-manager.mjs.map