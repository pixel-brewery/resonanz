import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { PulseElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/illustrations/pulse/PulseElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const PULSE_DEFAULT_PROPS = new InjectionToken("MOSAIK_PULSE_DEFAULT_PROPS");
let PulseComponent = class PulseComponent {
	count = input(...ngDevMode ? [void 0, { debugName: "count" }] : /* istanbul ignore next */ []);
	duration = input(...ngDevMode ? [void 0, { debugName: "duration" }] : /* istanbul ignore next */ []);
	dashed = input(...ngDevMode ? [void 0, { debugName: "dashed" }] : /* istanbul ignore next */ []);
	filled = input(...ngDevMode ? [void 0, { debugName: "filled" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(PULSE_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const countValue = this.count();
			if (countValue !== void 0) this._elementRef.nativeElement.count = countValue;
			const durationValue = this.duration();
			if (durationValue !== void 0) this._elementRef.nativeElement.duration = durationValue;
			const dashedValue = this.dashed();
			if (dashedValue !== void 0) this._elementRef.nativeElement.dashed = dashedValue;
			const filledValue = this.filled();
			if (filledValue !== void 0) this._elementRef.nativeElement.filled = filledValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: PulseComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: PulseComponent,
		isStandalone: true,
		selector: "mosaik-pulse",
		inputs: {
			count: {
				classPropertyName: "count",
				publicName: "count",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			duration: {
				classPropertyName: "duration",
				publicName: "duration",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dashed: {
				classPropertyName: "dashed",
				publicName: "dashed",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			filled: {
				classPropertyName: "filled",
				publicName: "filled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
PulseComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-pulse", PulseElement),
	inputs: [
		"count",
		"duration",
		"dashed",
		"filled",
		"themeName",
		"variant",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], PulseComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: PulseComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-pulse",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		count: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "count",
				required: false
			}]
		}],
		duration: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "duration",
				required: false
			}]
		}],
		dashed: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dashed",
				required: false
			}]
		}],
		filled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "filled",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function providePulseComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: PULSE_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { PULSE_DEFAULT_PROPS, PulseComponent, providePulseComponent };

//# sourceMappingURL=mosaik-elements-angular-components-pulse.mjs.map