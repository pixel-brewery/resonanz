import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { IllustrationElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/illustrations/illustration/IllustrationElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const ILLUSTRATION_DEFAULT_PROPS = new InjectionToken("MOSAIK_ILLUSTRATION_DEFAULT_PROPS");
let IllustrationComponent = class IllustrationComponent {
	ratio = input(...ngDevMode ? [void 0, { debugName: "ratio" }] : /* istanbul ignore next */ []);
	background = input(...ngDevMode ? [void 0, { debugName: "background" }] : /* istanbul ignore next */ []);
	frameless = input(...ngDevMode ? [void 0, { debugName: "frameless" }] : /* istanbul ignore next */ []);
	isometric = input(...ngDevMode ? [void 0, { debugName: "isometric" }] : /* istanbul ignore next */ []);
	motion = input(...ngDevMode ? [void 0, { debugName: "motion" }] : /* istanbul ignore next */ []);
	paused = input(...ngDevMode ? [void 0, { debugName: "paused" }] : /* istanbul ignore next */ []);
	label = input(...ngDevMode ? [void 0, { debugName: "label" }] : /* istanbul ignore next */ []);
	description = input(...ngDevMode ? [void 0, { debugName: "description" }] : /* istanbul ignore next */ []);
	interactive = input(...ngDevMode ? [void 0, { debugName: "interactive" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(ILLUSTRATION_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	onSlotChanges(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onSlotChanges", args);
	}
	assignToSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "assignToSlot", args);
	}
	getSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getSlotContent", args);
	}
	hasSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlotContent", args);
	}
	hasSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlot", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const ratioValue = this.ratio();
			if (ratioValue !== void 0) this._elementRef.nativeElement.ratio = ratioValue;
			const backgroundValue = this.background();
			if (backgroundValue !== void 0) this._elementRef.nativeElement.background = backgroundValue;
			const framelessValue = this.frameless();
			if (framelessValue !== void 0) this._elementRef.nativeElement.frameless = framelessValue;
			const isometricValue = this.isometric();
			if (isometricValue !== void 0) this._elementRef.nativeElement.isometric = isometricValue;
			const motionValue = this.motion();
			if (motionValue !== void 0) this._elementRef.nativeElement.motion = motionValue;
			const pausedValue = this.paused();
			if (pausedValue !== void 0) this._elementRef.nativeElement.paused = pausedValue;
			const labelValue = this.label();
			if (labelValue !== void 0) this._elementRef.nativeElement.label = labelValue;
			const descriptionValue = this.description();
			if (descriptionValue !== void 0) this._elementRef.nativeElement.description = descriptionValue;
			const interactiveValue = this.interactive();
			if (interactiveValue !== void 0) this._elementRef.nativeElement.interactive = interactiveValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: IllustrationComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: IllustrationComponent,
		isStandalone: true,
		selector: "mosaik-illustration",
		inputs: {
			ratio: {
				classPropertyName: "ratio",
				publicName: "ratio",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			background: {
				classPropertyName: "background",
				publicName: "background",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			frameless: {
				classPropertyName: "frameless",
				publicName: "frameless",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isometric: {
				classPropertyName: "isometric",
				publicName: "isometric",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			motion: {
				classPropertyName: "motion",
				publicName: "motion",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			paused: {
				classPropertyName: "paused",
				publicName: "paused",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			description: {
				classPropertyName: "description",
				publicName: "description",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			interactive: {
				classPropertyName: "interactive",
				publicName: "interactive",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
IllustrationComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-illustration", IllustrationElement),
	inputs: [
		"ratio",
		"background",
		"frameless",
		"isometric",
		"motion",
		"paused",
		"label",
		"description",
		"interactive",
		"themeName",
		"dir",
		"lang"
	],
	methods: ["getSlotAssignments", "getSlotAssignmentsOf"]
}), __metadata("design:paramtypes", [])], IllustrationComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: IllustrationComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-illustration",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		ratio: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "ratio",
				required: false
			}]
		}],
		background: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "background",
				required: false
			}]
		}],
		frameless: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "frameless",
				required: false
			}]
		}],
		isometric: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isometric",
				required: false
			}]
		}],
		motion: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "motion",
				required: false
			}]
		}],
		paused: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "paused",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		description: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "description",
				required: false
			}]
		}],
		interactive: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "interactive",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideIllustrationComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: ILLUSTRATION_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { ILLUSTRATION_DEFAULT_PROPS, IllustrationComponent, provideIllustrationComponent };

//# sourceMappingURL=mosaik-elements-angular-components-illustration.mjs.map