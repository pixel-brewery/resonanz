import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, forwardRef, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { NG_VALUE_ACCESSOR } from "@angular/forms";
import { CodeEditorElement, codeEditorElementValueAccessor } from "@pixel-brewery/mosaik-elements-foundation/components/code-editor";
import * as i1 from "@pixel-brewery/mosaik-elements-angular/runtime";
import { FORM_STATUS_HOST, FormFieldStatusHostDirective, FormStatusHostDirective, ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const CODE_EDITOR_DEFAULT_PROPS = new InjectionToken("MOSAIK_CODE_EDITOR_DEFAULT_PROPS");
const CODE_EDITOR_INTL = new InjectionToken("MOSAIK_CODE_EDITOR_INTL");
let CodeEditorComponent = class CodeEditorComponent {
	text = input(...ngDevMode ? [void 0, { debugName: "text" }] : /* istanbul ignore next */ []);
	value = input(...ngDevMode ? [void 0, { debugName: "value" }] : /* istanbul ignore next */ []);
	language = input(...ngDevMode ? [void 0, { debugName: "language" }] : /* istanbul ignore next */ []);
	readonly = input(...ngDevMode ? [void 0, { debugName: "readonly" }] : /* istanbul ignore next */ []);
	required = input(...ngDevMode ? [void 0, { debugName: "required" }] : /* istanbul ignore next */ []);
	invalid = input(...ngDevMode ? [void 0, { debugName: "invalid" }] : /* istanbul ignore next */ []);
	name = input(...ngDevMode ? [void 0, { debugName: "name" }] : /* istanbul ignore next */ []);
	placeholder = input(...ngDevMode ? [void 0, { debugName: "placeholder" }] : /* istanbul ignore next */ []);
	lineNumbers = input(...ngDevMode ? [void 0, { debugName: "lineNumbers" }] : /* istanbul ignore next */ []);
	lineWrapping = input(...ngDevMode ? [void 0, { debugName: "lineWrapping" }] : /* istanbul ignore next */ []);
	foldGutter = input(...ngDevMode ? [void 0, { debugName: "foldGutter" }] : /* istanbul ignore next */ []);
	highlightActiveLine = input(...ngDevMode ? [void 0, { debugName: "highlightActiveLine" }] : /* istanbul ignore next */ []);
	highlightWhitespace = input(...ngDevMode ? [void 0, { debugName: "highlightWhitespace" }] : /* istanbul ignore next */ []);
	closeBrackets = input(...ngDevMode ? [void 0, { debugName: "closeBrackets" }] : /* istanbul ignore next */ []);
	autocompletion = input(...ngDevMode ? [void 0, { debugName: "autocompletion" }] : /* istanbul ignore next */ []);
	indentWithTab = input(...ngDevMode ? [void 0, { debugName: "indentWithTab" }] : /* istanbul ignore next */ []);
	tabSize = input(...ngDevMode ? [void 0, { debugName: "tabSize" }] : /* istanbul ignore next */ []);
	indentWithTabs = input(...ngDevMode ? [void 0, { debugName: "indentWithTabs" }] : /* istanbul ignore next */ []);
	minLines = input(...ngDevMode ? [void 0, { debugName: "minLines" }] : /* istanbul ignore next */ []);
	maxLines = input(...ngDevMode ? [void 0, { debugName: "maxLines" }] : /* istanbul ignore next */ []);
	toolbar = input(...ngDevMode ? [void 0, { debugName: "toolbar" }] : /* istanbul ignore next */ []);
	statusBar = input(...ngDevMode ? [void 0, { debugName: "statusBar" }] : /* istanbul ignore next */ []);
	copyable = input(...ngDevMode ? [void 0, { debugName: "copyable" }] : /* istanbul ignore next */ []);
	maximized = input(...ngDevMode ? [void 0, { debugName: "maximized" }] : /* istanbul ignore next */ []);
	preview = input(...ngDevMode ? [void 0, { debugName: "preview" }] : /* istanbul ignore next */ []);
	autoFormat = input(...ngDevMode ? [void 0, { debugName: "autoFormat" }] : /* istanbul ignore next */ []);
	tooltipPosition = input(...ngDevMode ? [void 0, { debugName: "tooltipPosition" }] : /* istanbul ignore next */ []);
	completions = input(...ngDevMode ? [void 0, { debugName: "completions" }] : /* istanbul ignore next */ []);
	diagnostics = input(...ngDevMode ? [void 0, { debugName: "diagnostics" }] : /* istanbul ignore next */ []);
	linter = input(...ngDevMode ? [void 0, { debugName: "linter" }] : /* istanbul ignore next */ []);
	formatter = input(...ngDevMode ? [void 0, { debugName: "formatter" }] : /* istanbul ignore next */ []);
	previewRenderer = input(...ngDevMode ? [void 0, { debugName: "previewRenderer" }] : /* istanbul ignore next */ []);
	copyHandler = input(...ngDevMode ? [void 0, { debugName: "copyHandler" }] : /* istanbul ignore next */ []);
	extensions = input(...ngDevMode ? [void 0, { debugName: "extensions" }] : /* istanbul ignore next */ []);
	intl = input(...ngDevMode ? [void 0, { debugName: "intl" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	appearance = input(...ngDevMode ? [void 0, { debugName: "appearance" }] : /* istanbul ignore next */ []);
	label = input(...ngDevMode ? [void 0, { debugName: "label" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	locale = input(...ngDevMode ? [void 0, { debugName: "locale" }] : /* istanbul ignore next */ []);
	isFocused = input(...ngDevMode ? [void 0, { debugName: "isFocused" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	input = output();
	change = output();
	selectionChanged = output();
	copied = output();
	formatted = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	_accessor;
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._accessor = codeEditorElementValueAccessor(this._elementRef.nativeElement);
		this._elementRef.nativeElement.addController(this._accessor);
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			input: this.input,
			change: this.change,
			selectionChanged: this.selectionChanged,
			copied: this.copied,
			formatted: this.formatted,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
			this._accessor.releaseCallbacks();
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(CODE_EDITOR_DEFAULT_PROPS, { optional: true }) ?? {}, ["intl"]);
		const injectedIntl = inject(CODE_EDITOR_INTL, { optional: true });
		if (injectedIntl) {
			Object.assign(this._elementRef.nativeElement.intl, injectedIntl);
			this._elementRef.nativeElement.intl.changes.emit();
		}
	}
	writeValue(obj) {
		this._accessor.writeValue(obj);
	}
	registerOnChange(fn) {
		this._accessor.registerOnChange(fn);
	}
	registerOnTouched(fn) {
		this._accessor.registerOnTouched(fn);
	}
	setDisabledState(isDisabled) {
		this._accessor.setDisabled?.(isDisabled);
	}
	focus(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "focus", args);
	}
	blur(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "blur", args);
	}
	select(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "select", args);
	}
	goToLine(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "goToLine", args);
	}
	insertText(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "insertText", args);
	}
	undo(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "undo", args);
	}
	redo(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "redo", args);
	}
	foldAll(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "foldAll", args);
	}
	unfoldAll(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "unfoldAll", args);
	}
	lint(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "lint", args);
	}
	format(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "format", args);
	}
	copy(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "copy", args);
	}
	openSearch(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "openSearch", args);
	}
	closeSearch(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "closeSearch", args);
	}
	toggleSearch(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "toggleSearch", args);
	}
	findNext(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "findNext", args);
	}
	findPrevious(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "findPrevious", args);
	}
	selectAllMatches(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "selectAllMatches", args);
	}
	replaceNext(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "replaceNext", args);
	}
	replaceAll(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "replaceAll", args);
	}
	toggleLineWrapping(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "toggleLineWrapping", args);
	}
	toggleMaximized(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "toggleMaximized", args);
	}
	togglePreview(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "togglePreview", args);
	}
	whenReady(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "whenReady", args);
	}
	checkValidity(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "checkValidity", args);
	}
	reset(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "reset", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const textValue = this.text();
			if (textValue !== void 0) this._elementRef.nativeElement.text = textValue;
			const valueValue = this.value();
			if (valueValue !== void 0) this._elementRef.nativeElement.value = valueValue;
			const languageValue = this.language();
			if (languageValue !== void 0) this._elementRef.nativeElement.language = languageValue;
			const readonlyValue = this.readonly();
			if (readonlyValue !== void 0) this._elementRef.nativeElement.readonly = readonlyValue;
			const requiredValue = this.required();
			if (requiredValue !== void 0) this._elementRef.nativeElement.required = requiredValue;
			const invalidValue = this.invalid();
			if (invalidValue !== void 0) this._elementRef.nativeElement.invalid = invalidValue;
			const nameValue = this.name();
			if (nameValue !== void 0) this._elementRef.nativeElement.name = nameValue;
			const placeholderValue = this.placeholder();
			if (placeholderValue !== void 0) this._elementRef.nativeElement.placeholder = placeholderValue;
			const lineNumbersValue = this.lineNumbers();
			if (lineNumbersValue !== void 0) this._elementRef.nativeElement.lineNumbers = lineNumbersValue;
			const lineWrappingValue = this.lineWrapping();
			if (lineWrappingValue !== void 0) this._elementRef.nativeElement.lineWrapping = lineWrappingValue;
			const foldGutterValue = this.foldGutter();
			if (foldGutterValue !== void 0) this._elementRef.nativeElement.foldGutter = foldGutterValue;
			const highlightActiveLineValue = this.highlightActiveLine();
			if (highlightActiveLineValue !== void 0) this._elementRef.nativeElement.highlightActiveLine = highlightActiveLineValue;
			const highlightWhitespaceValue = this.highlightWhitespace();
			if (highlightWhitespaceValue !== void 0) this._elementRef.nativeElement.highlightWhitespace = highlightWhitespaceValue;
			const closeBracketsValue = this.closeBrackets();
			if (closeBracketsValue !== void 0) this._elementRef.nativeElement.closeBrackets = closeBracketsValue;
			const autocompletionValue = this.autocompletion();
			if (autocompletionValue !== void 0) this._elementRef.nativeElement.autocompletion = autocompletionValue;
			const indentWithTabValue = this.indentWithTab();
			if (indentWithTabValue !== void 0) this._elementRef.nativeElement.indentWithTab = indentWithTabValue;
			const tabSizeValue = this.tabSize();
			if (tabSizeValue !== void 0) this._elementRef.nativeElement.tabSize = tabSizeValue;
			const indentWithTabsValue = this.indentWithTabs();
			if (indentWithTabsValue !== void 0) this._elementRef.nativeElement.indentWithTabs = indentWithTabsValue;
			const minLinesValue = this.minLines();
			if (minLinesValue !== void 0) this._elementRef.nativeElement.minLines = minLinesValue;
			const maxLinesValue = this.maxLines();
			if (maxLinesValue !== void 0) this._elementRef.nativeElement.maxLines = maxLinesValue;
			const toolbarValue = this.toolbar();
			if (toolbarValue !== void 0) this._elementRef.nativeElement.toolbar = toolbarValue;
			const statusBarValue = this.statusBar();
			if (statusBarValue !== void 0) this._elementRef.nativeElement.statusBar = statusBarValue;
			const copyableValue = this.copyable();
			if (copyableValue !== void 0) this._elementRef.nativeElement.copyable = copyableValue;
			const maximizedValue = this.maximized();
			if (maximizedValue !== void 0) this._elementRef.nativeElement.maximized = maximizedValue;
			const previewValue = this.preview();
			if (previewValue !== void 0) this._elementRef.nativeElement.preview = previewValue;
			const autoFormatValue = this.autoFormat();
			if (autoFormatValue !== void 0) this._elementRef.nativeElement.autoFormat = autoFormatValue;
			const tooltipPositionValue = this.tooltipPosition();
			if (tooltipPositionValue !== void 0) this._elementRef.nativeElement.tooltipPosition = tooltipPositionValue;
			const completionsValue = this.completions();
			if (completionsValue !== void 0) this._elementRef.nativeElement.completions = completionsValue;
			const diagnosticsValue = this.diagnostics();
			if (diagnosticsValue !== void 0) this._elementRef.nativeElement.diagnostics = diagnosticsValue;
			const linterValue = this.linter();
			if (linterValue !== void 0) this._elementRef.nativeElement.linter = linterValue;
			const formatterValue = this.formatter();
			if (formatterValue !== void 0) this._elementRef.nativeElement.formatter = formatterValue;
			const previewRendererValue = this.previewRenderer();
			if (previewRendererValue !== void 0) this._elementRef.nativeElement.previewRenderer = previewRendererValue;
			const copyHandlerValue = this.copyHandler();
			if (copyHandlerValue !== void 0) this._elementRef.nativeElement.copyHandler = copyHandlerValue;
			const extensionsValue = this.extensions();
			if (extensionsValue !== void 0) this._elementRef.nativeElement.extensions = extensionsValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const appearanceValue = this.appearance();
			if (appearanceValue !== void 0) this._elementRef.nativeElement.appearance = appearanceValue;
			const labelValue = this.label();
			if (labelValue !== void 0) this._elementRef.nativeElement.label = labelValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const localeValue = this.locale();
			if (localeValue !== void 0) this._elementRef.nativeElement.locale = localeValue;
			const isFocusedValue = this.isFocused();
			if (isFocusedValue !== void 0) this._elementRef.nativeElement.isFocused = isFocusedValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
			const intlValue = this.intl();
			if (intlValue !== void 0) {
				Object.assign(this._elementRef.nativeElement.intl, intlValue);
				this._elementRef.nativeElement.intl.changes.emit();
			}
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: CodeEditorComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: CodeEditorComponent,
		isStandalone: true,
		selector: "mosaik-code-editor",
		inputs: {
			text: {
				classPropertyName: "text",
				publicName: "text",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			language: {
				classPropertyName: "language",
				publicName: "language",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			readonly: {
				classPropertyName: "readonly",
				publicName: "readonly",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			required: {
				classPropertyName: "required",
				publicName: "required",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			invalid: {
				classPropertyName: "invalid",
				publicName: "invalid",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			name: {
				classPropertyName: "name",
				publicName: "name",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			placeholder: {
				classPropertyName: "placeholder",
				publicName: "placeholder",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lineNumbers: {
				classPropertyName: "lineNumbers",
				publicName: "lineNumbers",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lineWrapping: {
				classPropertyName: "lineWrapping",
				publicName: "lineWrapping",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			foldGutter: {
				classPropertyName: "foldGutter",
				publicName: "foldGutter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			highlightActiveLine: {
				classPropertyName: "highlightActiveLine",
				publicName: "highlightActiveLine",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			highlightWhitespace: {
				classPropertyName: "highlightWhitespace",
				publicName: "highlightWhitespace",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			closeBrackets: {
				classPropertyName: "closeBrackets",
				publicName: "closeBrackets",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			autocompletion: {
				classPropertyName: "autocompletion",
				publicName: "autocompletion",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			indentWithTab: {
				classPropertyName: "indentWithTab",
				publicName: "indentWithTab",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			tabSize: {
				classPropertyName: "tabSize",
				publicName: "tabSize",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			indentWithTabs: {
				classPropertyName: "indentWithTabs",
				publicName: "indentWithTabs",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			minLines: {
				classPropertyName: "minLines",
				publicName: "minLines",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			maxLines: {
				classPropertyName: "maxLines",
				publicName: "maxLines",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			toolbar: {
				classPropertyName: "toolbar",
				publicName: "toolbar",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			statusBar: {
				classPropertyName: "statusBar",
				publicName: "statusBar",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			copyable: {
				classPropertyName: "copyable",
				publicName: "copyable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			maximized: {
				classPropertyName: "maximized",
				publicName: "maximized",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			preview: {
				classPropertyName: "preview",
				publicName: "preview",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			autoFormat: {
				classPropertyName: "autoFormat",
				publicName: "autoFormat",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			tooltipPosition: {
				classPropertyName: "tooltipPosition",
				publicName: "tooltipPosition",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			completions: {
				classPropertyName: "completions",
				publicName: "completions",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			diagnostics: {
				classPropertyName: "diagnostics",
				publicName: "diagnostics",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			linter: {
				classPropertyName: "linter",
				publicName: "linter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			formatter: {
				classPropertyName: "formatter",
				publicName: "formatter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			previewRenderer: {
				classPropertyName: "previewRenderer",
				publicName: "previewRenderer",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			copyHandler: {
				classPropertyName: "copyHandler",
				publicName: "copyHandler",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			extensions: {
				classPropertyName: "extensions",
				publicName: "extensions",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			intl: {
				classPropertyName: "intl",
				publicName: "intl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			locale: {
				classPropertyName: "locale",
				publicName: "locale",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isFocused: {
				classPropertyName: "isFocused",
				publicName: "isFocused",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			input: "input",
			change: "change",
			selectionChanged: "selectionChanged",
			copied: "copied",
			formatted: "formatted",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		providers: [{
			provide: NG_VALUE_ACCESSOR,
			useExisting: forwardRef(() => CodeEditorComponent),
			multi: true
		}, {
			provide: FORM_STATUS_HOST,
			useExisting: forwardRef(() => CodeEditorComponent)
		}],
		hostDirectives: [{ directive: i1.FormStatusHostDirective }, { directive: i1.FormFieldStatusHostDirective }],
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
CodeEditorComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-code-editor", CodeEditorElement),
	inputs: [
		"text",
		"value",
		"language",
		"readonly",
		"required",
		"invalid",
		"name",
		"placeholder",
		"lineNumbers",
		"lineWrapping",
		"foldGutter",
		"highlightActiveLine",
		"highlightWhitespace",
		"closeBrackets",
		"autocompletion",
		"indentWithTab",
		"tabSize",
		"indentWithTabs",
		"minLines",
		"maxLines",
		"toolbar",
		"statusBar",
		"copyable",
		"maximized",
		"preview",
		"autoFormat",
		"tooltipPosition",
		"completions",
		"diagnostics",
		"linter",
		"formatter",
		"previewRenderer",
		"copyHandler",
		"extensions",
		"intl",
		"themeName",
		"appearance",
		"label",
		"disabled",
		"locale",
		"isFocused",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], CodeEditorComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: CodeEditorComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-code-editor",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>",
			hostDirectives: [FormStatusHostDirective, FormFieldStatusHostDirective],
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => CodeEditorComponent),
				multi: true
			}, {
				provide: FORM_STATUS_HOST,
				useExisting: forwardRef(() => CodeEditorComponent)
			}]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		text: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "text",
				required: false
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		language: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "language",
				required: false
			}]
		}],
		readonly: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "readonly",
				required: false
			}]
		}],
		required: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "required",
				required: false
			}]
		}],
		invalid: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "invalid",
				required: false
			}]
		}],
		name: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "name",
				required: false
			}]
		}],
		placeholder: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "placeholder",
				required: false
			}]
		}],
		lineNumbers: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lineNumbers",
				required: false
			}]
		}],
		lineWrapping: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lineWrapping",
				required: false
			}]
		}],
		foldGutter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "foldGutter",
				required: false
			}]
		}],
		highlightActiveLine: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "highlightActiveLine",
				required: false
			}]
		}],
		highlightWhitespace: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "highlightWhitespace",
				required: false
			}]
		}],
		closeBrackets: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "closeBrackets",
				required: false
			}]
		}],
		autocompletion: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "autocompletion",
				required: false
			}]
		}],
		indentWithTab: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "indentWithTab",
				required: false
			}]
		}],
		tabSize: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tabSize",
				required: false
			}]
		}],
		indentWithTabs: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "indentWithTabs",
				required: false
			}]
		}],
		minLines: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "minLines",
				required: false
			}]
		}],
		maxLines: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maxLines",
				required: false
			}]
		}],
		toolbar: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "toolbar",
				required: false
			}]
		}],
		statusBar: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "statusBar",
				required: false
			}]
		}],
		copyable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "copyable",
				required: false
			}]
		}],
		maximized: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maximized",
				required: false
			}]
		}],
		preview: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "preview",
				required: false
			}]
		}],
		autoFormat: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "autoFormat",
				required: false
			}]
		}],
		tooltipPosition: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tooltipPosition",
				required: false
			}]
		}],
		completions: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "completions",
				required: false
			}]
		}],
		diagnostics: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "diagnostics",
				required: false
			}]
		}],
		linter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "linter",
				required: false
			}]
		}],
		formatter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "formatter",
				required: false
			}]
		}],
		previewRenderer: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "previewRenderer",
				required: false
			}]
		}],
		copyHandler: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "copyHandler",
				required: false
			}]
		}],
		extensions: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "extensions",
				required: false
			}]
		}],
		intl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "intl",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		locale: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "locale",
				required: false
			}]
		}],
		isFocused: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isFocused",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		input: [{
			type: i0.Output,
			args: ["input"]
		}],
		change: [{
			type: i0.Output,
			args: ["change"]
		}],
		selectionChanged: [{
			type: i0.Output,
			args: ["selectionChanged"]
		}],
		copied: [{
			type: i0.Output,
			args: ["copied"]
		}],
		formatted: [{
			type: i0.Output,
			args: ["formatted"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideCodeEditorComponent(config, intl) {
	const providers = [];
	if (config) providers.push({
		provide: CODE_EDITOR_DEFAULT_PROPS,
		useValue: config
	});
	if (intl) {
		if (typeof intl === "function") providers.push({
			provide: CODE_EDITOR_INTL,
			useClass: intl
		});
		else providers.push({
			provide: CODE_EDITOR_INTL,
			useValue: intl
		});
	}
	return makeEnvironmentProviders(providers);
}
export { CODE_EDITOR_DEFAULT_PROPS, CODE_EDITOR_INTL, CodeEditorComponent, provideCodeEditorComponent };

//# sourceMappingURL=mosaik-elements-angular-components-code-editor.mjs.map