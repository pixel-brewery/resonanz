import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { TickBarElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/tick-bar/TickBarElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const TICK_BAR_DEFAULT_PROPS = new InjectionToken("MOSAIK_TICK_BAR_DEFAULT_PROPS");
let TickBarComponent = class TickBarComponent {
	min = input(...ngDevMode ? [void 0, { debugName: "min" }] : /* istanbul ignore next */ []);
	max = input(...ngDevMode ? [void 0, { debugName: "max" }] : /* istanbul ignore next */ []);
	interval = input(...ngDevMode ? [void 0, { debugName: "interval" }] : /* istanbul ignore next */ []);
	showLabels = input(...ngDevMode ? [void 0, { debugName: "showLabels" }] : /* istanbul ignore next */ []);
	labelAccessor = input(...ngDevMode ? [void 0, { debugName: "labelAccessor" }] : /* istanbul ignore next */ []);
	labelPosition = input(...ngDevMode ? [void 0, { debugName: "labelPosition" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	orientation = input(...ngDevMode ? [void 0, { debugName: "orientation" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(TICK_BAR_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const minValue = this.min();
			if (minValue !== void 0) this._elementRef.nativeElement.min = minValue;
			const maxValue = this.max();
			if (maxValue !== void 0) this._elementRef.nativeElement.max = maxValue;
			const intervalValue = this.interval();
			if (intervalValue !== void 0) this._elementRef.nativeElement.interval = intervalValue;
			const showLabelsValue = this.showLabels();
			if (showLabelsValue !== void 0) this._elementRef.nativeElement.showLabels = showLabelsValue;
			const labelAccessorValue = this.labelAccessor();
			if (labelAccessorValue !== void 0) this._elementRef.nativeElement.labelAccessor = labelAccessorValue;
			const labelPositionValue = this.labelPosition();
			if (labelPositionValue !== void 0) this._elementRef.nativeElement.labelPosition = labelPositionValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const orientationValue = this.orientation();
			if (orientationValue !== void 0) this._elementRef.nativeElement.orientation = orientationValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: TickBarComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: TickBarComponent,
		isStandalone: true,
		selector: "mosaik-tick-bar",
		inputs: {
			min: {
				classPropertyName: "min",
				publicName: "min",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			max: {
				classPropertyName: "max",
				publicName: "max",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			interval: {
				classPropertyName: "interval",
				publicName: "interval",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showLabels: {
				classPropertyName: "showLabels",
				publicName: "showLabels",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			labelAccessor: {
				classPropertyName: "labelAccessor",
				publicName: "labelAccessor",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			labelPosition: {
				classPropertyName: "labelPosition",
				publicName: "labelPosition",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			orientation: {
				classPropertyName: "orientation",
				publicName: "orientation",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
TickBarComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-tick-bar", TickBarElement),
	inputs: [
		"min",
		"max",
		"interval",
		"showLabels",
		"labelAccessor",
		"labelPosition",
		"themeName",
		"disabled",
		"orientation",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], TickBarComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: TickBarComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-tick-bar",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		min: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "min",
				required: false
			}]
		}],
		max: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "max",
				required: false
			}]
		}],
		interval: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "interval",
				required: false
			}]
		}],
		showLabels: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showLabels",
				required: false
			}]
		}],
		labelAccessor: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "labelAccessor",
				required: false
			}]
		}],
		labelPosition: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "labelPosition",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		orientation: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "orientation",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideTickBarComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: TICK_BAR_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { TICK_BAR_DEFAULT_PROPS, TickBarComponent, provideTickBarComponent };

//# sourceMappingURL=mosaik-elements-angular-components-tick-bar.mjs.map