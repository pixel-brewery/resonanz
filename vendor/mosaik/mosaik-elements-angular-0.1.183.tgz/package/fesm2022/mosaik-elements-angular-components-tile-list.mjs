import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { TileListItemElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/tile-list/TileListItemElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { TileListElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/tile-list/TileListElement";
var __decorate$1 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$1 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const TILE_LIST_ITEM_DEFAULT_PROPS = new InjectionToken("MOSAIK_TILE_LIST_ITEM_DEFAULT_PROPS");
let TileListItemComponent = class TileListItemComponent {
	col = input(...ngDevMode ? [void 0, { debugName: "col" }] : /* istanbul ignore next */ []);
	colSpan = input(...ngDevMode ? [void 0, { debugName: "colSpan" }] : /* istanbul ignore next */ []);
	order = input(...ngDevMode ? [void 0, { debugName: "order" }] : /* istanbul ignore next */ []);
	reorderable = input(...ngDevMode ? [void 0, { debugName: "reorderable" }] : /* istanbul ignore next */ []);
	resizable = input(...ngDevMode ? [void 0, { debugName: "resizable" }] : /* istanbul ignore next */ []);
	row = input(...ngDevMode ? [void 0, { debugName: "row" }] : /* istanbul ignore next */ []);
	rowSpan = input(...ngDevMode ? [void 0, { debugName: "rowSpan" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(TILE_LIST_ITEM_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const colValue = this.col();
			if (colValue !== void 0) this._elementRef.nativeElement.col = colValue;
			const colSpanValue = this.colSpan();
			if (colSpanValue !== void 0) this._elementRef.nativeElement.colSpan = colSpanValue;
			const orderValue = this.order();
			if (orderValue !== void 0) this._elementRef.nativeElement.order = orderValue;
			const reorderableValue = this.reorderable();
			if (reorderableValue !== void 0) this._elementRef.nativeElement.reorderable = reorderableValue;
			const resizableValue = this.resizable();
			if (resizableValue !== void 0) this._elementRef.nativeElement.resizable = resizableValue;
			const rowValue = this.row();
			if (rowValue !== void 0) this._elementRef.nativeElement.row = rowValue;
			const rowSpanValue = this.rowSpan();
			if (rowSpanValue !== void 0) this._elementRef.nativeElement.rowSpan = rowSpanValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: TileListItemComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: TileListItemComponent,
		isStandalone: true,
		selector: "mosaik-tile-list-item",
		inputs: {
			col: {
				classPropertyName: "col",
				publicName: "col",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			colSpan: {
				classPropertyName: "colSpan",
				publicName: "colSpan",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			order: {
				classPropertyName: "order",
				publicName: "order",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			reorderable: {
				classPropertyName: "reorderable",
				publicName: "reorderable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			resizable: {
				classPropertyName: "resizable",
				publicName: "resizable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			row: {
				classPropertyName: "row",
				publicName: "row",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			rowSpan: {
				classPropertyName: "rowSpan",
				publicName: "rowSpan",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
TileListItemComponent = __decorate$1([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-tile-list-item", TileListItemElement),
	inputs: [
		"col",
		"colSpan",
		"order",
		"reorderable",
		"resizable",
		"row",
		"rowSpan",
		"themeName",
		"dir",
		"lang"
	]
}), __metadata$1("design:paramtypes", [])], TileListItemComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: TileListItemComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-tile-list-item",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		col: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "col",
				required: false
			}]
		}],
		colSpan: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "colSpan",
				required: false
			}]
		}],
		order: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "order",
				required: false
			}]
		}],
		reorderable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "reorderable",
				required: false
			}]
		}],
		resizable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "resizable",
				required: false
			}]
		}],
		row: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "row",
				required: false
			}]
		}],
		rowSpan: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "rowSpan",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideTileListItemComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: TILE_LIST_ITEM_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const TILE_LIST_DEFAULT_PROPS = new InjectionToken("MOSAIK_TILE_LIST_DEFAULT_PROPS");
let TileListComponent = class TileListComponent {
	cols = input(...ngDevMode ? [void 0, { debugName: "cols" }] : /* istanbul ignore next */ []);
	rowHeight = input(...ngDevMode ? [void 0, { debugName: "rowHeight" }] : /* istanbul ignore next */ []);
	gutterSize = input(...ngDevMode ? [void 0, { debugName: "gutterSize" }] : /* istanbul ignore next */ []);
	autoFlow = input(...ngDevMode ? [void 0, { debugName: "autoFlow" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(TILE_LIST_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const colsValue = this.cols();
			if (colsValue !== void 0) this._elementRef.nativeElement.cols = colsValue;
			const rowHeightValue = this.rowHeight();
			if (rowHeightValue !== void 0) this._elementRef.nativeElement.rowHeight = rowHeightValue;
			const gutterSizeValue = this.gutterSize();
			if (gutterSizeValue !== void 0) this._elementRef.nativeElement.gutterSize = gutterSizeValue;
			const autoFlowValue = this.autoFlow();
			if (autoFlowValue !== void 0) this._elementRef.nativeElement.autoFlow = autoFlowValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: TileListComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: TileListComponent,
		isStandalone: true,
		selector: "mosaik-tile-list",
		inputs: {
			cols: {
				classPropertyName: "cols",
				publicName: "cols",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			rowHeight: {
				classPropertyName: "rowHeight",
				publicName: "rowHeight",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			gutterSize: {
				classPropertyName: "gutterSize",
				publicName: "gutterSize",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			autoFlow: {
				classPropertyName: "autoFlow",
				publicName: "autoFlow",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
TileListComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-tile-list", TileListElement),
	inputs: [
		"cols",
		"rowHeight",
		"gutterSize",
		"autoFlow",
		"themeName",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], TileListComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: TileListComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-tile-list",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		cols: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "cols",
				required: false
			}]
		}],
		rowHeight: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "rowHeight",
				required: false
			}]
		}],
		gutterSize: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "gutterSize",
				required: false
			}]
		}],
		autoFlow: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "autoFlow",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideTileListComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: TILE_LIST_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { TILE_LIST_DEFAULT_PROPS, TILE_LIST_ITEM_DEFAULT_PROPS, TileListComponent, TileListItemComponent, provideTileListComponent, provideTileListItemComponent };

//# sourceMappingURL=mosaik-elements-angular-components-tile-list.mjs.map