import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { SchedulerEventElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/scheduler/SchedulerEventElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { SchedulerElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/scheduler/SchedulerElement";
var __decorate$1 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$1 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const SCHEDULER_EVENT_DEFAULT_PROPS = new InjectionToken("MOSAIK_SCHEDULER_EVENT_DEFAULT_PROPS");
let SchedulerEventComponent = class SchedulerEventComponent {
	eventKey = input(...ngDevMode ? [void 0, { debugName: "eventKey" }] : /* istanbul ignore next */ []);
	allDay = input(...ngDevMode ? [void 0, { debugName: "allDay" }] : /* istanbul ignore next */ []);
	draggable = input(...ngDevMode ? [void 0, { debugName: "draggable" }] : /* istanbul ignore next */ []);
	resizable = input(...ngDevMode ? [void 0, { debugName: "resizable" }] : /* istanbul ignore next */ []);
	resizeEdges = input(...ngDevMode ? [void 0, { debugName: "resizeEdges" }] : /* istanbul ignore next */ []);
	pinned = input(...ngDevMode ? [void 0, { debugName: "pinned" }] : /* istanbul ignore next */ []);
	status = input(...ngDevMode ? [void 0, { debugName: "status" }] : /* istanbul ignore next */ []);
	popupTemplate = input(...ngDevMode ? [void 0, { debugName: "popupTemplate" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	ripple = input(...ngDevMode ? [void 0, { debugName: "ripple" }] : /* istanbul ignore next */ []);
	isFocused = input(...ngDevMode ? [void 0, { debugName: "isFocused" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	value = input(...ngDevMode ? [void 0, { debugName: "value" }] : /* istanbul ignore next */ []);
	appearance = input(...ngDevMode ? [void 0, { debugName: "appearance" }] : /* istanbul ignore next */ []);
	start = input(...ngDevMode ? [void 0, { debugName: "start" }] : /* istanbul ignore next */ []);
	end = input(...ngDevMode ? [void 0, { debugName: "end" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	schedulerEventChange = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			schedulerEventChange: this.schedulerEventChange,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(SCHEDULER_EVENT_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	assignToSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "assignToSlot", args);
	}
	getSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getSlotContent", args);
	}
	hasSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlotContent", args);
	}
	hasSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlot", args);
	}
	onSlotChanges(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onSlotChanges", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const eventKeyValue = this.eventKey();
			if (eventKeyValue !== void 0) this._elementRef.nativeElement.eventKey = eventKeyValue;
			const allDayValue = this.allDay();
			if (allDayValue !== void 0) this._elementRef.nativeElement.allDay = allDayValue;
			const draggableValue = this.draggable();
			if (draggableValue !== void 0) this._elementRef.nativeElement.draggable = draggableValue;
			const resizableValue = this.resizable();
			if (resizableValue !== void 0) this._elementRef.nativeElement.resizable = resizableValue;
			const resizeEdgesValue = this.resizeEdges();
			if (resizeEdgesValue !== void 0) this._elementRef.nativeElement.resizeEdges = resizeEdgesValue;
			const pinnedValue = this.pinned();
			if (pinnedValue !== void 0) this._elementRef.nativeElement.pinned = pinnedValue;
			const statusValue = this.status();
			if (statusValue !== void 0) this._elementRef.nativeElement.status = statusValue;
			const popupTemplateValue = this.popupTemplate();
			if (popupTemplateValue !== void 0) this._elementRef.nativeElement.popupTemplate = popupTemplateValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const rippleValue = this.ripple();
			if (rippleValue !== void 0) this._elementRef.nativeElement.ripple = rippleValue;
			const isFocusedValue = this.isFocused();
			if (isFocusedValue !== void 0) this._elementRef.nativeElement.isFocused = isFocusedValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const valueValue = this.value();
			if (valueValue !== void 0) this._elementRef.nativeElement.value = valueValue;
			const appearanceValue = this.appearance();
			if (appearanceValue !== void 0) this._elementRef.nativeElement.appearance = appearanceValue;
			const startValue = this.start();
			if (startValue !== void 0) this._elementRef.nativeElement.start = startValue;
			const endValue = this.end();
			if (endValue !== void 0) this._elementRef.nativeElement.end = endValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: SchedulerEventComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: SchedulerEventComponent,
		isStandalone: true,
		selector: "mosaik-scheduler-event",
		inputs: {
			eventKey: {
				classPropertyName: "eventKey",
				publicName: "eventKey",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			allDay: {
				classPropertyName: "allDay",
				publicName: "allDay",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			draggable: {
				classPropertyName: "draggable",
				publicName: "draggable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			resizable: {
				classPropertyName: "resizable",
				publicName: "resizable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			resizeEdges: {
				classPropertyName: "resizeEdges",
				publicName: "resizeEdges",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			pinned: {
				classPropertyName: "pinned",
				publicName: "pinned",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			status: {
				classPropertyName: "status",
				publicName: "status",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			popupTemplate: {
				classPropertyName: "popupTemplate",
				publicName: "popupTemplate",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			ripple: {
				classPropertyName: "ripple",
				publicName: "ripple",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isFocused: {
				classPropertyName: "isFocused",
				publicName: "isFocused",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			start: {
				classPropertyName: "start",
				publicName: "start",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			end: {
				classPropertyName: "end",
				publicName: "end",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			schedulerEventChange: "schedulerEventChange",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
SchedulerEventComponent = __decorate$1([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-scheduler-event", SchedulerEventElement),
	inputs: [
		"eventKey",
		"allDay",
		"draggable",
		"resizable",
		"resizeEdges",
		"pinned",
		"status",
		"popupTemplate",
		"themeName",
		"ripple",
		"isFocused",
		"disabled",
		"variant",
		"value",
		"appearance",
		"start",
		"end",
		"dir",
		"lang"
	],
	methods: ["getSlotAssignments", "getSlotAssignmentsOf"]
}), __metadata$1("design:paramtypes", [])], SchedulerEventComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: SchedulerEventComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-scheduler-event",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		eventKey: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "eventKey",
				required: false
			}]
		}],
		allDay: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "allDay",
				required: false
			}]
		}],
		draggable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "draggable",
				required: false
			}]
		}],
		resizable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "resizable",
				required: false
			}]
		}],
		resizeEdges: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "resizeEdges",
				required: false
			}]
		}],
		pinned: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "pinned",
				required: false
			}]
		}],
		status: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "status",
				required: false
			}]
		}],
		popupTemplate: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "popupTemplate",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		ripple: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "ripple",
				required: false
			}]
		}],
		isFocused: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isFocused",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		start: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "start",
				required: false
			}]
		}],
		end: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "end",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		schedulerEventChange: [{
			type: i0.Output,
			args: ["schedulerEventChange"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideSchedulerEventComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: SCHEDULER_EVENT_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const SCHEDULER_DEFAULT_PROPS = new InjectionToken("MOSAIK_SCHEDULER_DEFAULT_PROPS");
const SCHEDULER_INTL = new InjectionToken("MOSAIK_SCHEDULER_INTL");
let SchedulerComponent = class SchedulerComponent {
	intl = input(...ngDevMode ? [void 0, { debugName: "intl" }] : /* istanbul ignore next */ []);
	view = input(...ngDevMode ? [void 0, { debugName: "view" }] : /* istanbul ignore next */ []);
	startDate = input(...ngDevMode ? [void 0, { debugName: "startDate" }] : /* istanbul ignore next */ []);
	days = input(...ngDevMode ? [void 0, { debugName: "days" }] : /* istanbul ignore next */ []);
	timelineScale = input(...ngDevMode ? [void 0, { debugName: "timelineScale" }] : /* istanbul ignore next */ []);
	timelineSlotWidth = input(...ngDevMode ? [void 0, { debugName: "timelineSlotWidth" }] : /* istanbul ignore next */ []);
	hourStart = input(...ngDevMode ? [void 0, { debugName: "hourStart" }] : /* istanbul ignore next */ []);
	hourEnd = input(...ngDevMode ? [void 0, { debugName: "hourEnd" }] : /* istanbul ignore next */ []);
	stepMinutes = input(...ngDevMode ? [void 0, { debugName: "stepMinutes" }] : /* istanbul ignore next */ []);
	eventLayout = input(...ngDevMode ? [void 0, { debugName: "eventLayout" }] : /* istanbul ignore next */ []);
	gestureEnabled = input(...ngDevMode ? [void 0, { debugName: "gestureEnabled" }] : /* istanbul ignore next */ []);
	dragdrop = input(...ngDevMode ? [void 0, { debugName: "dragdrop" }] : /* istanbul ignore next */ []);
	dragPreviewMode = input(...ngDevMode ? [void 0, { debugName: "dragPreviewMode" }] : /* istanbul ignore next */ []);
	resizable = input(...ngDevMode ? [void 0, { debugName: "resizable" }] : /* istanbul ignore next */ []);
	mutationMode = input(...ngDevMode ? [void 0, { debugName: "mutationMode" }] : /* istanbul ignore next */ []);
	snapMinutes = input(...ngDevMode ? [void 0, { debugName: "snapMinutes" }] : /* istanbul ignore next */ []);
	eventAllow = input(...ngDevMode ? [void 0, { debugName: "eventAllow" }] : /* istanbul ignore next */ []);
	rangeSelection = input(...ngDevMode ? [void 0, { debugName: "rangeSelection" }] : /* istanbul ignore next */ []);
	selectAllow = input(...ngDevMode ? [void 0, { debugName: "selectAllow" }] : /* istanbul ignore next */ []);
	workingHours = input(...ngDevMode ? [void 0, { debugName: "workingHours" }] : /* istanbul ignore next */ []);
	blockedRanges = input(...ngDevMode ? [void 0, { debugName: "blockedRanges" }] : /* istanbul ignore next */ []);
	allowOverlap = input(...ngDevMode ? [void 0, { debugName: "allowOverlap" }] : /* istanbul ignore next */ []);
	timezone = input(...ngDevMode ? [void 0, { debugName: "timezone" }] : /* istanbul ignore next */ []);
	blackoutDates = input(...ngDevMode ? [void 0, { debugName: "blackoutDates" }] : /* istanbul ignore next */ []);
	specialDates = input(...ngDevMode ? [void 0, { debugName: "specialDates" }] : /* istanbul ignore next */ []);
	firstDayOfWeek = input(...ngDevMode ? [void 0, { debugName: "firstDayOfWeek" }] : /* istanbul ignore next */ []);
	isTodayHighlighted = input(...ngDevMode ? [void 0, { debugName: "isTodayHighlighted" }] : /* istanbul ignore next */ []);
	isWeekendHighlighted = input(...ngDevMode ? [void 0, { debugName: "isWeekendHighlighted" }] : /* istanbul ignore next */ []);
	allDayVisibility = input(...ngDevMode ? [void 0, { debugName: "allDayVisibility" }] : /* istanbul ignore next */ []);
	showWeekNumbers = input(...ngDevMode ? [void 0, { debugName: "showWeekNumbers" }] : /* istanbul ignore next */ []);
	showAdjacent = input(...ngDevMode ? [void 0, { debugName: "showAdjacent" }] : /* istanbul ignore next */ []);
	maxEventsPerDay = input(...ngDevMode ? [void 0, { debugName: "maxEventsPerDay" }] : /* istanbul ignore next */ []);
	daysAhead = input(...ngDevMode ? [void 0, { debugName: "daysAhead" }] : /* istanbul ignore next */ []);
	weekdayFormat = input(...ngDevMode ? [void 0, { debugName: "weekdayFormat" }] : /* istanbul ignore next */ []);
	dayFormat = input(...ngDevMode ? [void 0, { debugName: "dayFormat" }] : /* istanbul ignore next */ []);
	timeFormat = input(...ngDevMode ? [void 0, { debugName: "timeFormat" }] : /* istanbul ignore next */ []);
	monthDayFormat = input(...ngDevMode ? [void 0, { debugName: "monthDayFormat" }] : /* istanbul ignore next */ []);
	showTools = input(...ngDevMode ? [void 0, { debugName: "showTools" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	appearance = input(...ngDevMode ? [void 0, { debugName: "appearance" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	locale = input(...ngDevMode ? [void 0, { debugName: "locale" }] : /* istanbul ignore next */ []);
	size = input(...ngDevMode ? [void 0, { debugName: "size" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	schedulerBeforeEventActivate = output();
	schedulerEventActivate = output();
	schedulerBeforeSelectRange = output();
	schedulerSelectRange = output();
	schedulerRangeChange = output();
	schedulerBeforeEventMove = output();
	schedulerEventMove = output();
	schedulerBeforeEventResize = output();
	schedulerEventResize = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			schedulerBeforeEventActivate: this.schedulerBeforeEventActivate,
			schedulerEventActivate: this.schedulerEventActivate,
			schedulerBeforeSelectRange: this.schedulerBeforeSelectRange,
			schedulerSelectRange: this.schedulerSelectRange,
			schedulerRangeChange: this.schedulerRangeChange,
			schedulerBeforeEventMove: this.schedulerBeforeEventMove,
			schedulerEventMove: this.schedulerEventMove,
			schedulerBeforeEventResize: this.schedulerBeforeEventResize,
			schedulerEventResize: this.schedulerEventResize,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(SCHEDULER_DEFAULT_PROPS, { optional: true }) ?? {}, ["intl"]);
		const injectedIntl = inject(SCHEDULER_INTL, { optional: true });
		if (injectedIntl) {
			Object.assign(this._elementRef.nativeElement.intl, injectedIntl);
			this._elementRef.nativeElement.intl.changes.emit();
		}
	}
	isBlackoutDate(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "isBlackoutDate", args);
	}
	isSpecialDate(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "isSpecialDate", args);
	}
	isWeekend(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "isWeekend", args);
	}
	isToday(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "isToday", args);
	}
	now(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "now", args);
	}
	getEventsForDay(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getEventsForDay", args);
	}
	getAllDayEventsForDay(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getAllDayEventsForDay", args);
	}
	getAllDayEvents(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getAllDayEvents", args);
	}
	activateEvent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "activateEvent", args);
	}
	navigateToDate(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "navigateToDate", args);
	}
	navigateToday(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "navigateToday", args);
	}
	navigatePrevious(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "navigatePrevious", args);
	}
	navigateNext(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "navigateNext", args);
	}
	assignToSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "assignToSlot", args);
	}
	getSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getSlotContent", args);
	}
	hasSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlotContent", args);
	}
	hasSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlot", args);
	}
	onSlotChanges(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onSlotChanges", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const viewValue = this.view();
			if (viewValue !== void 0) this._elementRef.nativeElement.view = viewValue;
			const startDateValue = this.startDate();
			if (startDateValue !== void 0) this._elementRef.nativeElement.startDate = startDateValue;
			const daysValue = this.days();
			if (daysValue !== void 0) this._elementRef.nativeElement.days = daysValue;
			const timelineScaleValue = this.timelineScale();
			if (timelineScaleValue !== void 0) this._elementRef.nativeElement.timelineScale = timelineScaleValue;
			const timelineSlotWidthValue = this.timelineSlotWidth();
			if (timelineSlotWidthValue !== void 0) this._elementRef.nativeElement.timelineSlotWidth = timelineSlotWidthValue;
			const hourStartValue = this.hourStart();
			if (hourStartValue !== void 0) this._elementRef.nativeElement.hourStart = hourStartValue;
			const hourEndValue = this.hourEnd();
			if (hourEndValue !== void 0) this._elementRef.nativeElement.hourEnd = hourEndValue;
			const stepMinutesValue = this.stepMinutes();
			if (stepMinutesValue !== void 0) this._elementRef.nativeElement.stepMinutes = stepMinutesValue;
			const eventLayoutValue = this.eventLayout();
			if (eventLayoutValue !== void 0) this._elementRef.nativeElement.eventLayout = eventLayoutValue;
			const gestureEnabledValue = this.gestureEnabled();
			if (gestureEnabledValue !== void 0) this._elementRef.nativeElement.gestureEnabled = gestureEnabledValue;
			const dragdropValue = this.dragdrop();
			if (dragdropValue !== void 0) this._elementRef.nativeElement.dragdrop = dragdropValue;
			const dragPreviewModeValue = this.dragPreviewMode();
			if (dragPreviewModeValue !== void 0) this._elementRef.nativeElement.dragPreviewMode = dragPreviewModeValue;
			const resizableValue = this.resizable();
			if (resizableValue !== void 0) this._elementRef.nativeElement.resizable = resizableValue;
			const mutationModeValue = this.mutationMode();
			if (mutationModeValue !== void 0) this._elementRef.nativeElement.mutationMode = mutationModeValue;
			const snapMinutesValue = this.snapMinutes();
			if (snapMinutesValue !== void 0) this._elementRef.nativeElement.snapMinutes = snapMinutesValue;
			const eventAllowValue = this.eventAllow();
			if (eventAllowValue !== void 0) this._elementRef.nativeElement.eventAllow = eventAllowValue;
			const rangeSelectionValue = this.rangeSelection();
			if (rangeSelectionValue !== void 0) this._elementRef.nativeElement.rangeSelection = rangeSelectionValue;
			const selectAllowValue = this.selectAllow();
			if (selectAllowValue !== void 0) this._elementRef.nativeElement.selectAllow = selectAllowValue;
			const workingHoursValue = this.workingHours();
			if (workingHoursValue !== void 0) this._elementRef.nativeElement.workingHours = workingHoursValue;
			const blockedRangesValue = this.blockedRanges();
			if (blockedRangesValue !== void 0) this._elementRef.nativeElement.blockedRanges = blockedRangesValue;
			const allowOverlapValue = this.allowOverlap();
			if (allowOverlapValue !== void 0) this._elementRef.nativeElement.allowOverlap = allowOverlapValue;
			const timezoneValue = this.timezone();
			if (timezoneValue !== void 0) this._elementRef.nativeElement.timezone = timezoneValue;
			const blackoutDatesValue = this.blackoutDates();
			if (blackoutDatesValue !== void 0) this._elementRef.nativeElement.blackoutDates = blackoutDatesValue;
			const specialDatesValue = this.specialDates();
			if (specialDatesValue !== void 0) this._elementRef.nativeElement.specialDates = specialDatesValue;
			const firstDayOfWeekValue = this.firstDayOfWeek();
			if (firstDayOfWeekValue !== void 0) this._elementRef.nativeElement.firstDayOfWeek = firstDayOfWeekValue;
			const isTodayHighlightedValue = this.isTodayHighlighted();
			if (isTodayHighlightedValue !== void 0) this._elementRef.nativeElement.isTodayHighlighted = isTodayHighlightedValue;
			const isWeekendHighlightedValue = this.isWeekendHighlighted();
			if (isWeekendHighlightedValue !== void 0) this._elementRef.nativeElement.isWeekendHighlighted = isWeekendHighlightedValue;
			const allDayVisibilityValue = this.allDayVisibility();
			if (allDayVisibilityValue !== void 0) this._elementRef.nativeElement.allDayVisibility = allDayVisibilityValue;
			const showWeekNumbersValue = this.showWeekNumbers();
			if (showWeekNumbersValue !== void 0) this._elementRef.nativeElement.showWeekNumbers = showWeekNumbersValue;
			const showAdjacentValue = this.showAdjacent();
			if (showAdjacentValue !== void 0) this._elementRef.nativeElement.showAdjacent = showAdjacentValue;
			const maxEventsPerDayValue = this.maxEventsPerDay();
			if (maxEventsPerDayValue !== void 0) this._elementRef.nativeElement.maxEventsPerDay = maxEventsPerDayValue;
			const daysAheadValue = this.daysAhead();
			if (daysAheadValue !== void 0) this._elementRef.nativeElement.daysAhead = daysAheadValue;
			const weekdayFormatValue = this.weekdayFormat();
			if (weekdayFormatValue !== void 0) this._elementRef.nativeElement.weekdayFormat = weekdayFormatValue;
			const dayFormatValue = this.dayFormat();
			if (dayFormatValue !== void 0) this._elementRef.nativeElement.dayFormat = dayFormatValue;
			const timeFormatValue = this.timeFormat();
			if (timeFormatValue !== void 0) this._elementRef.nativeElement.timeFormat = timeFormatValue;
			const monthDayFormatValue = this.monthDayFormat();
			if (monthDayFormatValue !== void 0) this._elementRef.nativeElement.monthDayFormat = monthDayFormatValue;
			const showToolsValue = this.showTools();
			if (showToolsValue !== void 0) this._elementRef.nativeElement.showTools = showToolsValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const appearanceValue = this.appearance();
			if (appearanceValue !== void 0) this._elementRef.nativeElement.appearance = appearanceValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const localeValue = this.locale();
			if (localeValue !== void 0) this._elementRef.nativeElement.locale = localeValue;
			const sizeValue = this.size();
			if (sizeValue !== void 0) this._elementRef.nativeElement.size = sizeValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
			const intlValue = this.intl();
			if (intlValue !== void 0) {
				Object.assign(this._elementRef.nativeElement.intl, intlValue);
				this._elementRef.nativeElement.intl.changes.emit();
			}
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: SchedulerComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: SchedulerComponent,
		isStandalone: true,
		selector: "mosaik-scheduler",
		inputs: {
			intl: {
				classPropertyName: "intl",
				publicName: "intl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			view: {
				classPropertyName: "view",
				publicName: "view",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			startDate: {
				classPropertyName: "startDate",
				publicName: "startDate",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			days: {
				classPropertyName: "days",
				publicName: "days",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			timelineScale: {
				classPropertyName: "timelineScale",
				publicName: "timelineScale",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			timelineSlotWidth: {
				classPropertyName: "timelineSlotWidth",
				publicName: "timelineSlotWidth",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			hourStart: {
				classPropertyName: "hourStart",
				publicName: "hourStart",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			hourEnd: {
				classPropertyName: "hourEnd",
				publicName: "hourEnd",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			stepMinutes: {
				classPropertyName: "stepMinutes",
				publicName: "stepMinutes",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			eventLayout: {
				classPropertyName: "eventLayout",
				publicName: "eventLayout",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			gestureEnabled: {
				classPropertyName: "gestureEnabled",
				publicName: "gestureEnabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dragdrop: {
				classPropertyName: "dragdrop",
				publicName: "dragdrop",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dragPreviewMode: {
				classPropertyName: "dragPreviewMode",
				publicName: "dragPreviewMode",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			resizable: {
				classPropertyName: "resizable",
				publicName: "resizable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			mutationMode: {
				classPropertyName: "mutationMode",
				publicName: "mutationMode",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			snapMinutes: {
				classPropertyName: "snapMinutes",
				publicName: "snapMinutes",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			eventAllow: {
				classPropertyName: "eventAllow",
				publicName: "eventAllow",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			rangeSelection: {
				classPropertyName: "rangeSelection",
				publicName: "rangeSelection",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			selectAllow: {
				classPropertyName: "selectAllow",
				publicName: "selectAllow",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			workingHours: {
				classPropertyName: "workingHours",
				publicName: "workingHours",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			blockedRanges: {
				classPropertyName: "blockedRanges",
				publicName: "blockedRanges",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			allowOverlap: {
				classPropertyName: "allowOverlap",
				publicName: "allowOverlap",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			timezone: {
				classPropertyName: "timezone",
				publicName: "timezone",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			blackoutDates: {
				classPropertyName: "blackoutDates",
				publicName: "blackoutDates",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			specialDates: {
				classPropertyName: "specialDates",
				publicName: "specialDates",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			firstDayOfWeek: {
				classPropertyName: "firstDayOfWeek",
				publicName: "firstDayOfWeek",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isTodayHighlighted: {
				classPropertyName: "isTodayHighlighted",
				publicName: "isTodayHighlighted",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isWeekendHighlighted: {
				classPropertyName: "isWeekendHighlighted",
				publicName: "isWeekendHighlighted",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			allDayVisibility: {
				classPropertyName: "allDayVisibility",
				publicName: "allDayVisibility",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showWeekNumbers: {
				classPropertyName: "showWeekNumbers",
				publicName: "showWeekNumbers",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showAdjacent: {
				classPropertyName: "showAdjacent",
				publicName: "showAdjacent",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			maxEventsPerDay: {
				classPropertyName: "maxEventsPerDay",
				publicName: "maxEventsPerDay",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			daysAhead: {
				classPropertyName: "daysAhead",
				publicName: "daysAhead",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			weekdayFormat: {
				classPropertyName: "weekdayFormat",
				publicName: "weekdayFormat",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dayFormat: {
				classPropertyName: "dayFormat",
				publicName: "dayFormat",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			timeFormat: {
				classPropertyName: "timeFormat",
				publicName: "timeFormat",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			monthDayFormat: {
				classPropertyName: "monthDayFormat",
				publicName: "monthDayFormat",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showTools: {
				classPropertyName: "showTools",
				publicName: "showTools",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			locale: {
				classPropertyName: "locale",
				publicName: "locale",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			schedulerBeforeEventActivate: "schedulerBeforeEventActivate",
			schedulerEventActivate: "schedulerEventActivate",
			schedulerBeforeSelectRange: "schedulerBeforeSelectRange",
			schedulerSelectRange: "schedulerSelectRange",
			schedulerRangeChange: "schedulerRangeChange",
			schedulerBeforeEventMove: "schedulerBeforeEventMove",
			schedulerEventMove: "schedulerEventMove",
			schedulerBeforeEventResize: "schedulerBeforeEventResize",
			schedulerEventResize: "schedulerEventResize",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
SchedulerComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-scheduler", SchedulerElement),
	inputs: [
		"intl",
		"view",
		"startDate",
		"days",
		"timelineScale",
		"timelineSlotWidth",
		"hourStart",
		"hourEnd",
		"stepMinutes",
		"eventLayout",
		"gestureEnabled",
		"dragdrop",
		"dragPreviewMode",
		"resizable",
		"mutationMode",
		"snapMinutes",
		"eventAllow",
		"rangeSelection",
		"selectAllow",
		"workingHours",
		"blockedRanges",
		"allowOverlap",
		"timezone",
		"blackoutDates",
		"specialDates",
		"firstDayOfWeek",
		"isTodayHighlighted",
		"isWeekendHighlighted",
		"allDayVisibility",
		"showWeekNumbers",
		"showAdjacent",
		"maxEventsPerDay",
		"daysAhead",
		"weekdayFormat",
		"dayFormat",
		"timeFormat",
		"monthDayFormat",
		"showTools",
		"themeName",
		"appearance",
		"variant",
		"locale",
		"size",
		"disabled",
		"dir",
		"lang"
	],
	methods: ["getSlotAssignments", "getSlotAssignmentsOf"]
}), __metadata("design:paramtypes", [])], SchedulerComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: SchedulerComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-scheduler",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		intl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "intl",
				required: false
			}]
		}],
		view: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "view",
				required: false
			}]
		}],
		startDate: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "startDate",
				required: false
			}]
		}],
		days: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "days",
				required: false
			}]
		}],
		timelineScale: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "timelineScale",
				required: false
			}]
		}],
		timelineSlotWidth: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "timelineSlotWidth",
				required: false
			}]
		}],
		hourStart: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hourStart",
				required: false
			}]
		}],
		hourEnd: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hourEnd",
				required: false
			}]
		}],
		stepMinutes: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "stepMinutes",
				required: false
			}]
		}],
		eventLayout: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "eventLayout",
				required: false
			}]
		}],
		gestureEnabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "gestureEnabled",
				required: false
			}]
		}],
		dragdrop: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dragdrop",
				required: false
			}]
		}],
		dragPreviewMode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dragPreviewMode",
				required: false
			}]
		}],
		resizable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "resizable",
				required: false
			}]
		}],
		mutationMode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mutationMode",
				required: false
			}]
		}],
		snapMinutes: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "snapMinutes",
				required: false
			}]
		}],
		eventAllow: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "eventAllow",
				required: false
			}]
		}],
		rangeSelection: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "rangeSelection",
				required: false
			}]
		}],
		selectAllow: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "selectAllow",
				required: false
			}]
		}],
		workingHours: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "workingHours",
				required: false
			}]
		}],
		blockedRanges: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "blockedRanges",
				required: false
			}]
		}],
		allowOverlap: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "allowOverlap",
				required: false
			}]
		}],
		timezone: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "timezone",
				required: false
			}]
		}],
		blackoutDates: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "blackoutDates",
				required: false
			}]
		}],
		specialDates: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "specialDates",
				required: false
			}]
		}],
		firstDayOfWeek: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "firstDayOfWeek",
				required: false
			}]
		}],
		isTodayHighlighted: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isTodayHighlighted",
				required: false
			}]
		}],
		isWeekendHighlighted: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isWeekendHighlighted",
				required: false
			}]
		}],
		allDayVisibility: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "allDayVisibility",
				required: false
			}]
		}],
		showWeekNumbers: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showWeekNumbers",
				required: false
			}]
		}],
		showAdjacent: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showAdjacent",
				required: false
			}]
		}],
		maxEventsPerDay: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maxEventsPerDay",
				required: false
			}]
		}],
		daysAhead: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "daysAhead",
				required: false
			}]
		}],
		weekdayFormat: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "weekdayFormat",
				required: false
			}]
		}],
		dayFormat: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dayFormat",
				required: false
			}]
		}],
		timeFormat: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "timeFormat",
				required: false
			}]
		}],
		monthDayFormat: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "monthDayFormat",
				required: false
			}]
		}],
		showTools: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showTools",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		locale: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "locale",
				required: false
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		schedulerBeforeEventActivate: [{
			type: i0.Output,
			args: ["schedulerBeforeEventActivate"]
		}],
		schedulerEventActivate: [{
			type: i0.Output,
			args: ["schedulerEventActivate"]
		}],
		schedulerBeforeSelectRange: [{
			type: i0.Output,
			args: ["schedulerBeforeSelectRange"]
		}],
		schedulerSelectRange: [{
			type: i0.Output,
			args: ["schedulerSelectRange"]
		}],
		schedulerRangeChange: [{
			type: i0.Output,
			args: ["schedulerRangeChange"]
		}],
		schedulerBeforeEventMove: [{
			type: i0.Output,
			args: ["schedulerBeforeEventMove"]
		}],
		schedulerEventMove: [{
			type: i0.Output,
			args: ["schedulerEventMove"]
		}],
		schedulerBeforeEventResize: [{
			type: i0.Output,
			args: ["schedulerBeforeEventResize"]
		}],
		schedulerEventResize: [{
			type: i0.Output,
			args: ["schedulerEventResize"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideSchedulerComponent(config, intl) {
	const providers = [];
	if (config) providers.push({
		provide: SCHEDULER_DEFAULT_PROPS,
		useValue: config
	});
	if (intl) {
		if (typeof intl === "function") providers.push({
			provide: SCHEDULER_INTL,
			useClass: intl
		});
		else providers.push({
			provide: SCHEDULER_INTL,
			useValue: intl
		});
	}
	return makeEnvironmentProviders(providers);
}
export { SCHEDULER_DEFAULT_PROPS, SCHEDULER_EVENT_DEFAULT_PROPS, SCHEDULER_INTL, SchedulerComponent, SchedulerEventComponent, provideSchedulerComponent, provideSchedulerEventComponent };

//# sourceMappingURL=mosaik-elements-angular-components-scheduler.mjs.map