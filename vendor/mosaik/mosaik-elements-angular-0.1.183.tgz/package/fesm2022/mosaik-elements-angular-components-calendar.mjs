import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, forwardRef, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { CalendarHeaderElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/calendar/CalendarHeaderElement";
import * as i1 from "@pixel-brewery/mosaik-elements-angular/runtime";
import { FORM_STATUS_HOST, FormFieldStatusHostDirective, FormStatusHostDirective, ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { CalendarItemElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/calendar/CalendarItemElement";
import { CalendarSubHeaderElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/calendar/CalendarSubHeaderElement";
import { NG_VALUE_ACCESSOR } from "@angular/forms";
import { CalendarElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/calendar/CalendarElement";
import { calendarElementValueAccessor } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/calendar/accessors/CalendarElementValueAccessor";
var __decorate$3 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$3 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const CALENDAR_HEADER_DEFAULT_PROPS = new InjectionToken("MOSAIK_CALENDAR_HEADER_DEFAULT_PROPS");
let CalendarHeaderComponent = class CalendarHeaderComponent {
	text = input(...ngDevMode ? [void 0, { debugName: "text" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(CALENDAR_HEADER_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const textValue = this.text();
			if (textValue !== void 0) this._elementRef.nativeElement.text = textValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: CalendarHeaderComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: CalendarHeaderComponent,
		isStandalone: true,
		selector: "mosaik-calendar-header",
		inputs: {
			text: {
				classPropertyName: "text",
				publicName: "text",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
CalendarHeaderComponent = __decorate$3([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-calendar-header", CalendarHeaderElement),
	inputs: [
		"text",
		"themeName",
		"disabled",
		"dir",
		"lang"
	]
}), __metadata$3("design:paramtypes", [])], CalendarHeaderComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: CalendarHeaderComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-calendar-header",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		text: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "text",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideCalendarHeaderComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: CALENDAR_HEADER_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$2 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$2 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const CALENDAR_ITEM_DEFAULT_PROPS = new InjectionToken("MOSAIK_CALENDAR_ITEM_DEFAULT_PROPS");
let CalendarItemComponent = class CalendarItemComponent {
	isSelected = input(...ngDevMode ? [void 0, { debugName: "isSelected" }] : /* istanbul ignore next */ []);
	isBlackout = input(...ngDevMode ? [void 0, { debugName: "isBlackout" }] : /* istanbul ignore next */ []);
	isSpecial = input(...ngDevMode ? [void 0, { debugName: "isSpecial" }] : /* istanbul ignore next */ []);
	isToday = input(...ngDevMode ? [void 0, { debugName: "isToday" }] : /* istanbul ignore next */ []);
	isWeekend = input(...ngDevMode ? [void 0, { debugName: "isWeekend" }] : /* istanbul ignore next */ []);
	isAdjacent = input(...ngDevMode ? [void 0, { debugName: "isAdjacent" }] : /* istanbul ignore next */ []);
	markers = input(...ngDevMode ? [void 0, { debugName: "markers" }] : /* istanbul ignore next */ []);
	isRangeStart = input(...ngDevMode ? [void 0, { debugName: "isRangeStart" }] : /* istanbul ignore next */ []);
	isRangeMiddle = input(...ngDevMode ? [void 0, { debugName: "isRangeMiddle" }] : /* istanbul ignore next */ []);
	isRangeEnd = input(...ngDevMode ? [void 0, { debugName: "isRangeEnd" }] : /* istanbul ignore next */ []);
	isRangePreview = input(...ngDevMode ? [void 0, { debugName: "isRangePreview" }] : /* istanbul ignore next */ []);
	text = input(...ngDevMode ? [void 0, { debugName: "text" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	ripple = input(...ngDevMode ? [void 0, { debugName: "ripple" }] : /* istanbul ignore next */ []);
	appearance = input(...ngDevMode ? [void 0, { debugName: "appearance" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	value = input(...ngDevMode ? [void 0, { debugName: "value" }] : /* istanbul ignore next */ []);
	isFocused = input(...ngDevMode ? [void 0, { debugName: "isFocused" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	click = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			click: this.click,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(CALENDAR_ITEM_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const isSelectedValue = this.isSelected();
			if (isSelectedValue !== void 0) this._elementRef.nativeElement.isSelected = isSelectedValue;
			const isBlackoutValue = this.isBlackout();
			if (isBlackoutValue !== void 0) this._elementRef.nativeElement.isBlackout = isBlackoutValue;
			const isSpecialValue = this.isSpecial();
			if (isSpecialValue !== void 0) this._elementRef.nativeElement.isSpecial = isSpecialValue;
			const isTodayValue = this.isToday();
			if (isTodayValue !== void 0) this._elementRef.nativeElement.isToday = isTodayValue;
			const isWeekendValue = this.isWeekend();
			if (isWeekendValue !== void 0) this._elementRef.nativeElement.isWeekend = isWeekendValue;
			const isAdjacentValue = this.isAdjacent();
			if (isAdjacentValue !== void 0) this._elementRef.nativeElement.isAdjacent = isAdjacentValue;
			const markersValue = this.markers();
			if (markersValue !== void 0) this._elementRef.nativeElement.markers = markersValue;
			const isRangeStartValue = this.isRangeStart();
			if (isRangeStartValue !== void 0) this._elementRef.nativeElement.isRangeStart = isRangeStartValue;
			const isRangeMiddleValue = this.isRangeMiddle();
			if (isRangeMiddleValue !== void 0) this._elementRef.nativeElement.isRangeMiddle = isRangeMiddleValue;
			const isRangeEndValue = this.isRangeEnd();
			if (isRangeEndValue !== void 0) this._elementRef.nativeElement.isRangeEnd = isRangeEndValue;
			const isRangePreviewValue = this.isRangePreview();
			if (isRangePreviewValue !== void 0) this._elementRef.nativeElement.isRangePreview = isRangePreviewValue;
			const textValue = this.text();
			if (textValue !== void 0) this._elementRef.nativeElement.text = textValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const rippleValue = this.ripple();
			if (rippleValue !== void 0) this._elementRef.nativeElement.ripple = rippleValue;
			const appearanceValue = this.appearance();
			if (appearanceValue !== void 0) this._elementRef.nativeElement.appearance = appearanceValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const valueValue = this.value();
			if (valueValue !== void 0) this._elementRef.nativeElement.value = valueValue;
			const isFocusedValue = this.isFocused();
			if (isFocusedValue !== void 0) this._elementRef.nativeElement.isFocused = isFocusedValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: CalendarItemComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: CalendarItemComponent,
		isStandalone: true,
		selector: "mosaik-calendar-item",
		inputs: {
			isSelected: {
				classPropertyName: "isSelected",
				publicName: "isSelected",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isBlackout: {
				classPropertyName: "isBlackout",
				publicName: "isBlackout",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isSpecial: {
				classPropertyName: "isSpecial",
				publicName: "isSpecial",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isToday: {
				classPropertyName: "isToday",
				publicName: "isToday",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isWeekend: {
				classPropertyName: "isWeekend",
				publicName: "isWeekend",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isAdjacent: {
				classPropertyName: "isAdjacent",
				publicName: "isAdjacent",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			markers: {
				classPropertyName: "markers",
				publicName: "markers",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isRangeStart: {
				classPropertyName: "isRangeStart",
				publicName: "isRangeStart",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isRangeMiddle: {
				classPropertyName: "isRangeMiddle",
				publicName: "isRangeMiddle",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isRangeEnd: {
				classPropertyName: "isRangeEnd",
				publicName: "isRangeEnd",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isRangePreview: {
				classPropertyName: "isRangePreview",
				publicName: "isRangePreview",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			text: {
				classPropertyName: "text",
				publicName: "text",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			ripple: {
				classPropertyName: "ripple",
				publicName: "ripple",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isFocused: {
				classPropertyName: "isFocused",
				publicName: "isFocused",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			click: "click",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
CalendarItemComponent = __decorate$2([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-calendar-item", CalendarItemElement),
	inputs: [
		"isSelected",
		"isBlackout",
		"isSpecial",
		"isToday",
		"isWeekend",
		"isAdjacent",
		"markers",
		"isRangeStart",
		"isRangeMiddle",
		"isRangeEnd",
		"isRangePreview",
		"text",
		"themeName",
		"ripple",
		"appearance",
		"variant",
		"disabled",
		"value",
		"isFocused",
		"dir",
		"lang"
	]
}), __metadata$2("design:paramtypes", [])], CalendarItemComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: CalendarItemComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-calendar-item",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		isSelected: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isSelected",
				required: false
			}]
		}],
		isBlackout: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isBlackout",
				required: false
			}]
		}],
		isSpecial: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isSpecial",
				required: false
			}]
		}],
		isToday: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isToday",
				required: false
			}]
		}],
		isWeekend: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isWeekend",
				required: false
			}]
		}],
		isAdjacent: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isAdjacent",
				required: false
			}]
		}],
		markers: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "markers",
				required: false
			}]
		}],
		isRangeStart: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isRangeStart",
				required: false
			}]
		}],
		isRangeMiddle: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isRangeMiddle",
				required: false
			}]
		}],
		isRangeEnd: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isRangeEnd",
				required: false
			}]
		}],
		isRangePreview: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isRangePreview",
				required: false
			}]
		}],
		text: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "text",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		ripple: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "ripple",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		isFocused: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isFocused",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		click: [{
			type: i0.Output,
			args: ["click"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideCalendarItemComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: CALENDAR_ITEM_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$1 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$1 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const CALENDAR_SUB_HEADER_DEFAULT_PROPS = new InjectionToken("MOSAIK_CALENDAR_SUB_HEADER_DEFAULT_PROPS");
let CalendarSubHeaderComponent = class CalendarSubHeaderComponent {
	text = input(...ngDevMode ? [void 0, { debugName: "text" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(CALENDAR_SUB_HEADER_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const textValue = this.text();
			if (textValue !== void 0) this._elementRef.nativeElement.text = textValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: CalendarSubHeaderComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: CalendarSubHeaderComponent,
		isStandalone: true,
		selector: "mosaik-calendar-sub-header",
		inputs: {
			text: {
				classPropertyName: "text",
				publicName: "text",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
CalendarSubHeaderComponent = __decorate$1([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-calendar-sub-header", CalendarSubHeaderElement),
	inputs: [
		"text",
		"themeName",
		"disabled",
		"dir",
		"lang"
	]
}), __metadata$1("design:paramtypes", [])], CalendarSubHeaderComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: CalendarSubHeaderComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-calendar-sub-header",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		text: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "text",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideCalendarSubHeaderComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: CALENDAR_SUB_HEADER_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const CALENDAR_DEFAULT_PROPS = new InjectionToken("MOSAIK_CALENDAR_DEFAULT_PROPS");
const CALENDAR_INTL = new InjectionToken("MOSAIK_CALENDAR_INTL");
let CalendarComponent = class CalendarComponent {
	sheets = input(...ngDevMode ? [void 0, { debugName: "sheets" }] : /* istanbul ignore next */ []);
	intl = input(...ngDevMode ? [void 0, { debugName: "intl" }] : /* istanbul ignore next */ []);
	displayDate = input(...ngDevMode ? [void 0, { debugName: "displayDate" }] : /* istanbul ignore next */ []);
	displayDateStart = input(...ngDevMode ? [void 0, { debugName: "displayDateStart" }] : /* istanbul ignore next */ []);
	displayDateEnd = input(...ngDevMode ? [void 0, { debugName: "displayDateEnd" }] : /* istanbul ignore next */ []);
	values = input(...ngDevMode ? [void 0, { debugName: "values" }] : /* istanbul ignore next */ []);
	view = input(...ngDevMode ? [void 0, { debugName: "view" }] : /* istanbul ignore next */ []);
	selectionMode = input(...ngDevMode ? [void 0, { debugName: "selectionMode" }] : /* istanbul ignore next */ []);
	blackoutDates = input(...ngDevMode ? [void 0, { debugName: "blackoutDates" }] : /* istanbul ignore next */ []);
	specialDates = input(...ngDevMode ? [void 0, { debugName: "specialDates" }] : /* istanbul ignore next */ []);
	minDate = input(...ngDevMode ? [void 0, { debugName: "minDate" }] : /* istanbul ignore next */ []);
	maxDate = input(...ngDevMode ? [void 0, { debugName: "maxDate" }] : /* istanbul ignore next */ []);
	firstDayOfWeek = input(...ngDevMode ? [void 0, { debugName: "firstDayOfWeek" }] : /* istanbul ignore next */ []);
	isTodayHighlighted = input(...ngDevMode ? [void 0, { debugName: "isTodayHighlighted" }] : /* istanbul ignore next */ []);
	isWeekendHighlighted = input(...ngDevMode ? [void 0, { debugName: "isWeekendHighlighted" }] : /* istanbul ignore next */ []);
	showWeekNumbers = input(...ngDevMode ? [void 0, { debugName: "showWeekNumbers" }] : /* istanbul ignore next */ []);
	showAdjacent = input(...ngDevMode ? [void 0, { debugName: "showAdjacent" }] : /* istanbul ignore next */ []);
	markerHandler = input(...ngDevMode ? [void 0, { debugName: "markerHandler" }] : /* istanbul ignore next */ []);
	allowedViews = input(...ngDevMode ? [void 0, { debugName: "allowedViews" }] : /* istanbul ignore next */ []);
	showNavigation = input(...ngDevMode ? [void 0, { debugName: "showNavigation" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	locale = input(...ngDevMode ? [void 0, { debugName: "locale" }] : /* istanbul ignore next */ []);
	appearance = input(...ngDevMode ? [void 0, { debugName: "appearance" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	invalid = input(...ngDevMode ? [void 0, { debugName: "invalid" }] : /* istanbul ignore next */ []);
	value = input(...ngDevMode ? [void 0, { debugName: "value" }] : /* istanbul ignore next */ []);
	orientation = input(...ngDevMode ? [void 0, { debugName: "orientation" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	fit = input(...ngDevMode ? [void 0, { debugName: "fit" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	dateChanged = output();
	displayChanged = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	_accessor;
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._accessor = calendarElementValueAccessor(this._elementRef.nativeElement);
		this._elementRef.nativeElement.addController(this._accessor);
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			dateChanged: this.dateChanged,
			displayChanged: this.displayChanged,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
			this._accessor.releaseCallbacks();
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(CALENDAR_DEFAULT_PROPS, { optional: true }) ?? {}, ["intl"]);
		const injectedIntl = inject(CALENDAR_INTL, { optional: true });
		if (injectedIntl) {
			Object.assign(this._elementRef.nativeElement.intl, injectedIntl);
			this._elementRef.nativeElement.intl.changes.emit();
		}
	}
	writeValue(obj) {
		this._accessor.writeValue(obj);
	}
	registerOnChange(fn) {
		this._accessor.registerOnChange(fn);
	}
	registerOnTouched(fn) {
		this._accessor.registerOnTouched(fn);
	}
	setDisabledState(isDisabled) {
		this._accessor.setDisabled?.(isDisabled);
	}
	reset(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "reset", args);
	}
	checkValidity(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "checkValidity", args);
	}
	navigatePrevious(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "navigatePrevious", args);
	}
	navigateNext(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "navigateNext", args);
	}
	navigateToday(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "navigateToday", args);
	}
	assignToSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "assignToSlot", args);
	}
	getSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getSlotContent", args);
	}
	hasSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlotContent", args);
	}
	hasSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlot", args);
	}
	onSlotChanges(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onSlotChanges", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const sheetsValue = this.sheets();
			if (sheetsValue !== void 0) this._elementRef.nativeElement.sheets = sheetsValue;
			const displayDateValue = this.displayDate();
			if (displayDateValue !== void 0) this._elementRef.nativeElement.displayDate = displayDateValue;
			const displayDateStartValue = this.displayDateStart();
			if (displayDateStartValue !== void 0) this._elementRef.nativeElement.displayDateStart = displayDateStartValue;
			const displayDateEndValue = this.displayDateEnd();
			if (displayDateEndValue !== void 0) this._elementRef.nativeElement.displayDateEnd = displayDateEndValue;
			const valuesValue = this.values();
			if (valuesValue !== void 0) this._elementRef.nativeElement.values = valuesValue;
			const viewValue = this.view();
			if (viewValue !== void 0) this._elementRef.nativeElement.view = viewValue;
			const selectionModeValue = this.selectionMode();
			if (selectionModeValue !== void 0) this._elementRef.nativeElement.selectionMode = selectionModeValue;
			const blackoutDatesValue = this.blackoutDates();
			if (blackoutDatesValue !== void 0) this._elementRef.nativeElement.blackoutDates = blackoutDatesValue;
			const specialDatesValue = this.specialDates();
			if (specialDatesValue !== void 0) this._elementRef.nativeElement.specialDates = specialDatesValue;
			const minDateValue = this.minDate();
			if (minDateValue !== void 0) this._elementRef.nativeElement.minDate = minDateValue;
			const maxDateValue = this.maxDate();
			if (maxDateValue !== void 0) this._elementRef.nativeElement.maxDate = maxDateValue;
			const firstDayOfWeekValue = this.firstDayOfWeek();
			if (firstDayOfWeekValue !== void 0) this._elementRef.nativeElement.firstDayOfWeek = firstDayOfWeekValue;
			const isTodayHighlightedValue = this.isTodayHighlighted();
			if (isTodayHighlightedValue !== void 0) this._elementRef.nativeElement.isTodayHighlighted = isTodayHighlightedValue;
			const isWeekendHighlightedValue = this.isWeekendHighlighted();
			if (isWeekendHighlightedValue !== void 0) this._elementRef.nativeElement.isWeekendHighlighted = isWeekendHighlightedValue;
			const showWeekNumbersValue = this.showWeekNumbers();
			if (showWeekNumbersValue !== void 0) this._elementRef.nativeElement.showWeekNumbers = showWeekNumbersValue;
			const showAdjacentValue = this.showAdjacent();
			if (showAdjacentValue !== void 0) this._elementRef.nativeElement.showAdjacent = showAdjacentValue;
			const markerHandlerValue = this.markerHandler();
			if (markerHandlerValue !== void 0) this._elementRef.nativeElement.markerHandler = markerHandlerValue;
			const allowedViewsValue = this.allowedViews();
			if (allowedViewsValue !== void 0) this._elementRef.nativeElement.allowedViews = allowedViewsValue;
			const showNavigationValue = this.showNavigation();
			if (showNavigationValue !== void 0) this._elementRef.nativeElement.showNavigation = showNavigationValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const localeValue = this.locale();
			if (localeValue !== void 0) this._elementRef.nativeElement.locale = localeValue;
			const appearanceValue = this.appearance();
			if (appearanceValue !== void 0) this._elementRef.nativeElement.appearance = appearanceValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const invalidValue = this.invalid();
			if (invalidValue !== void 0) this._elementRef.nativeElement.invalid = invalidValue;
			const valueValue = this.value();
			if (valueValue !== void 0) this._elementRef.nativeElement.value = valueValue;
			const orientationValue = this.orientation();
			if (orientationValue !== void 0) this._elementRef.nativeElement.orientation = orientationValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const fitValue = this.fit();
			if (fitValue !== void 0) this._elementRef.nativeElement.fit = fitValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
			const intlValue = this.intl();
			if (intlValue !== void 0) {
				Object.assign(this._elementRef.nativeElement.intl, intlValue);
				this._elementRef.nativeElement.intl.changes.emit();
			}
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: CalendarComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: CalendarComponent,
		isStandalone: true,
		selector: "mosaik-calendar",
		inputs: {
			sheets: {
				classPropertyName: "sheets",
				publicName: "sheets",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			intl: {
				classPropertyName: "intl",
				publicName: "intl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			displayDate: {
				classPropertyName: "displayDate",
				publicName: "displayDate",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			displayDateStart: {
				classPropertyName: "displayDateStart",
				publicName: "displayDateStart",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			displayDateEnd: {
				classPropertyName: "displayDateEnd",
				publicName: "displayDateEnd",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			values: {
				classPropertyName: "values",
				publicName: "values",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			view: {
				classPropertyName: "view",
				publicName: "view",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			selectionMode: {
				classPropertyName: "selectionMode",
				publicName: "selectionMode",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			blackoutDates: {
				classPropertyName: "blackoutDates",
				publicName: "blackoutDates",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			specialDates: {
				classPropertyName: "specialDates",
				publicName: "specialDates",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			minDate: {
				classPropertyName: "minDate",
				publicName: "minDate",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			maxDate: {
				classPropertyName: "maxDate",
				publicName: "maxDate",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			firstDayOfWeek: {
				classPropertyName: "firstDayOfWeek",
				publicName: "firstDayOfWeek",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isTodayHighlighted: {
				classPropertyName: "isTodayHighlighted",
				publicName: "isTodayHighlighted",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isWeekendHighlighted: {
				classPropertyName: "isWeekendHighlighted",
				publicName: "isWeekendHighlighted",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showWeekNumbers: {
				classPropertyName: "showWeekNumbers",
				publicName: "showWeekNumbers",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showAdjacent: {
				classPropertyName: "showAdjacent",
				publicName: "showAdjacent",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			markerHandler: {
				classPropertyName: "markerHandler",
				publicName: "markerHandler",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			allowedViews: {
				classPropertyName: "allowedViews",
				publicName: "allowedViews",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showNavigation: {
				classPropertyName: "showNavigation",
				publicName: "showNavigation",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			locale: {
				classPropertyName: "locale",
				publicName: "locale",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			invalid: {
				classPropertyName: "invalid",
				publicName: "invalid",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			orientation: {
				classPropertyName: "orientation",
				publicName: "orientation",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			fit: {
				classPropertyName: "fit",
				publicName: "fit",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			dateChanged: "dateChanged",
			displayChanged: "displayChanged",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		providers: [{
			provide: NG_VALUE_ACCESSOR,
			useExisting: forwardRef(() => CalendarComponent),
			multi: true
		}, {
			provide: FORM_STATUS_HOST,
			useExisting: forwardRef(() => CalendarComponent)
		}],
		hostDirectives: [{ directive: i1.FormStatusHostDirective }, { directive: i1.FormFieldStatusHostDirective }],
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
CalendarComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-calendar", CalendarElement),
	inputs: [
		"sheets",
		"intl",
		"displayDate",
		"displayDateStart",
		"displayDateEnd",
		"values",
		"view",
		"selectionMode",
		"blackoutDates",
		"specialDates",
		"minDate",
		"maxDate",
		"firstDayOfWeek",
		"isTodayHighlighted",
		"isWeekendHighlighted",
		"showWeekNumbers",
		"showAdjacent",
		"markerHandler",
		"allowedViews",
		"showNavigation",
		"themeName",
		"locale",
		"appearance",
		"disabled",
		"invalid",
		"value",
		"orientation",
		"variant",
		"fit",
		"dir",
		"lang"
	],
	methods: ["getSlotAssignments", "getSlotAssignmentsOf"]
}), __metadata("design:paramtypes", [])], CalendarComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: CalendarComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-calendar",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>",
			hostDirectives: [FormStatusHostDirective, FormFieldStatusHostDirective],
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => CalendarComponent),
				multi: true
			}, {
				provide: FORM_STATUS_HOST,
				useExisting: forwardRef(() => CalendarComponent)
			}]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		sheets: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "sheets",
				required: false
			}]
		}],
		intl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "intl",
				required: false
			}]
		}],
		displayDate: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "displayDate",
				required: false
			}]
		}],
		displayDateStart: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "displayDateStart",
				required: false
			}]
		}],
		displayDateEnd: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "displayDateEnd",
				required: false
			}]
		}],
		values: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "values",
				required: false
			}]
		}],
		view: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "view",
				required: false
			}]
		}],
		selectionMode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "selectionMode",
				required: false
			}]
		}],
		blackoutDates: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "blackoutDates",
				required: false
			}]
		}],
		specialDates: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "specialDates",
				required: false
			}]
		}],
		minDate: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "minDate",
				required: false
			}]
		}],
		maxDate: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maxDate",
				required: false
			}]
		}],
		firstDayOfWeek: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "firstDayOfWeek",
				required: false
			}]
		}],
		isTodayHighlighted: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isTodayHighlighted",
				required: false
			}]
		}],
		isWeekendHighlighted: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isWeekendHighlighted",
				required: false
			}]
		}],
		showWeekNumbers: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showWeekNumbers",
				required: false
			}]
		}],
		showAdjacent: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showAdjacent",
				required: false
			}]
		}],
		markerHandler: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "markerHandler",
				required: false
			}]
		}],
		allowedViews: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "allowedViews",
				required: false
			}]
		}],
		showNavigation: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showNavigation",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		locale: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "locale",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		invalid: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "invalid",
				required: false
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		orientation: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "orientation",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		fit: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "fit",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		dateChanged: [{
			type: i0.Output,
			args: ["dateChanged"]
		}],
		displayChanged: [{
			type: i0.Output,
			args: ["displayChanged"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideCalendarComponent(config, intl) {
	const providers = [];
	if (config) providers.push({
		provide: CALENDAR_DEFAULT_PROPS,
		useValue: config
	});
	if (intl) {
		if (typeof intl === "function") providers.push({
			provide: CALENDAR_INTL,
			useClass: intl
		});
		else providers.push({
			provide: CALENDAR_INTL,
			useValue: intl
		});
	}
	return makeEnvironmentProviders(providers);
}
export { CALENDAR_DEFAULT_PROPS, CALENDAR_HEADER_DEFAULT_PROPS, CALENDAR_INTL, CALENDAR_ITEM_DEFAULT_PROPS, CALENDAR_SUB_HEADER_DEFAULT_PROPS, CalendarComponent, CalendarHeaderComponent, CalendarItemComponent, CalendarSubHeaderComponent, provideCalendarComponent, provideCalendarHeaderComponent, provideCalendarItemComponent, provideCalendarSubHeaderComponent };

//# sourceMappingURL=mosaik-elements-angular-components-calendar.mjs.map