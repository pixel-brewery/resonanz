import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { ChartElement, ChartToolboxElement } from "@pixel-brewery/mosaik-elements-foundation/components/chart";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate$1 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$1 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const CHART_TOOLBOX_DEFAULT_PROPS = new InjectionToken("MOSAIK_CHART_TOOLBOX_DEFAULT_PROPS");
let ChartToolboxComponent = class ChartToolboxComponent {
	chart = input(...ngDevMode ? [void 0, { debugName: "chart" }] : /* istanbul ignore next */ []);
	tools = input(...ngDevMode ? [void 0, { debugName: "tools" }] : /* istanbul ignore next */ []);
	intl = input(...ngDevMode ? [void 0, { debugName: "intl" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(CHART_TOOLBOX_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const chartValue = this.chart();
			if (chartValue !== void 0) this._elementRef.nativeElement.chart = chartValue;
			const toolsValue = this.tools();
			if (toolsValue !== void 0) this._elementRef.nativeElement.tools = toolsValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ChartToolboxComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: ChartToolboxComponent,
		isStandalone: true,
		selector: "mosaik-chart-toolbox",
		inputs: {
			chart: {
				classPropertyName: "chart",
				publicName: "chart",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			tools: {
				classPropertyName: "tools",
				publicName: "tools",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			intl: {
				classPropertyName: "intl",
				publicName: "intl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
ChartToolboxComponent = __decorate$1([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-chart-toolbox", ChartToolboxElement),
	inputs: [
		"chart",
		"tools",
		"intl",
		"themeName",
		"dir",
		"lang"
	]
}), __metadata$1("design:paramtypes", [])], ChartToolboxComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ChartToolboxComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-chart-toolbox",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		chart: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "chart",
				required: false
			}]
		}],
		tools: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tools",
				required: false
			}]
		}],
		intl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "intl",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideChartToolboxComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: CHART_TOOLBOX_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const CHART_DEFAULT_PROPS = new InjectionToken("MOSAIK_CHART_DEFAULT_PROPS");
let ChartComponent = class ChartComponent {
	chart = input(...ngDevMode ? [void 0, { debugName: "chart" }] : /* istanbul ignore next */ []);
	showToolbox = input(...ngDevMode ? [void 0, { debugName: "showToolbox" }] : /* istanbul ignore next */ []);
	toolboxTools = input(...ngDevMode ? [void 0, { debugName: "toolboxTools" }] : /* istanbul ignore next */ []);
	annotations = input(...ngDevMode ? [void 0, { debugName: "annotations" }] : /* istanbul ignore next */ []);
	colors = input(...ngDevMode ? [void 0, { debugName: "colors" }] : /* istanbul ignore next */ []);
	dataLabels = input(...ngDevMode ? [void 0, { debugName: "dataLabels" }] : /* istanbul ignore next */ []);
	series = input(...ngDevMode ? [void 0, { debugName: "series" }] : /* istanbul ignore next */ []);
	stroke = input(...ngDevMode ? [void 0, { debugName: "stroke" }] : /* istanbul ignore next */ []);
	labels = input(...ngDevMode ? [void 0, { debugName: "labels" }] : /* istanbul ignore next */ []);
	legend = input(...ngDevMode ? [void 0, { debugName: "legend" }] : /* istanbul ignore next */ []);
	markers = input(...ngDevMode ? [void 0, { debugName: "markers" }] : /* istanbul ignore next */ []);
	noData = input(...ngDevMode ? [void 0, { debugName: "noData" }] : /* istanbul ignore next */ []);
	fill = input(...ngDevMode ? [void 0, { debugName: "fill" }] : /* istanbul ignore next */ []);
	tooltip = input(...ngDevMode ? [void 0, { debugName: "tooltip" }] : /* istanbul ignore next */ []);
	plotOptions = input(...ngDevMode ? [void 0, { debugName: "plotOptions" }] : /* istanbul ignore next */ []);
	responsive = input(...ngDevMode ? [void 0, { debugName: "responsive" }] : /* istanbul ignore next */ []);
	xAxis = input(...ngDevMode ? [void 0, { debugName: "xAxis" }] : /* istanbul ignore next */ []);
	yAxis = input(...ngDevMode ? [void 0, { debugName: "yAxis" }] : /* istanbul ignore next */ []);
	grid = input(...ngDevMode ? [void 0, { debugName: "grid" }] : /* istanbul ignore next */ []);
	states = input(...ngDevMode ? [void 0, { debugName: "states" }] : /* istanbul ignore next */ []);
	theme = input(...ngDevMode ? [void 0, { debugName: "theme" }] : /* istanbul ignore next */ []);
	display = input(...ngDevMode ? [void 0, { debugName: "display" }] : /* istanbul ignore next */ []);
	stacked = input(...ngDevMode ? [void 0, { debugName: "stacked" }] : /* istanbul ignore next */ []);
	stackType = input(...ngDevMode ? [void 0, { debugName: "stackType" }] : /* istanbul ignore next */ []);
	isYAxisVisible = input(...ngDevMode ? [void 0, { debugName: "isYAxisVisible" }] : /* istanbul ignore next */ []);
	isXAxisVisible = input(...ngDevMode ? [void 0, { debugName: "isXAxisVisible" }] : /* istanbul ignore next */ []);
	isLegendVisible = input(...ngDevMode ? [void 0, { debugName: "isLegendVisible" }] : /* istanbul ignore next */ []);
	legendPosition = input(...ngDevMode ? [void 0, { debugName: "legendPosition" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	header = input(...ngDevMode ? [void 0, { debugName: "header" }] : /* istanbul ignore next */ []);
	subHeader = input(...ngDevMode ? [void 0, { debugName: "subHeader" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	fit = input(...ngDevMode ? [void 0, { debugName: "fit" }] : /* istanbul ignore next */ []);
	width = input(...ngDevMode ? [void 0, { debugName: "width" }] : /* istanbul ignore next */ []);
	height = input(...ngDevMode ? [void 0, { debugName: "height" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	chartReady = output();
	chartToolChanged = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			chartReady: this.chartReady,
			chartToolChanged: this.chartToolChanged,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(CHART_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	isToolVisible(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "isToolVisible", args);
	}
	command(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "command", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const chartValue = this.chart();
			if (chartValue !== void 0) this._elementRef.nativeElement.chart = chartValue;
			const showToolboxValue = this.showToolbox();
			if (showToolboxValue !== void 0) this._elementRef.nativeElement.showToolbox = showToolboxValue;
			const toolboxToolsValue = this.toolboxTools();
			if (toolboxToolsValue !== void 0) this._elementRef.nativeElement.toolboxTools = toolboxToolsValue;
			const annotationsValue = this.annotations();
			if (annotationsValue !== void 0) this._elementRef.nativeElement.annotations = annotationsValue;
			const colorsValue = this.colors();
			if (colorsValue !== void 0) this._elementRef.nativeElement.colors = colorsValue;
			const dataLabelsValue = this.dataLabels();
			if (dataLabelsValue !== void 0) this._elementRef.nativeElement.dataLabels = dataLabelsValue;
			const seriesValue = this.series();
			if (seriesValue !== void 0) this._elementRef.nativeElement.series = seriesValue;
			const strokeValue = this.stroke();
			if (strokeValue !== void 0) this._elementRef.nativeElement.stroke = strokeValue;
			const legendValue = this.legend();
			if (legendValue !== void 0) this._elementRef.nativeElement.legend = legendValue;
			const markersValue = this.markers();
			if (markersValue !== void 0) this._elementRef.nativeElement.markers = markersValue;
			const noDataValue = this.noData();
			if (noDataValue !== void 0) this._elementRef.nativeElement.noData = noDataValue;
			const fillValue = this.fill();
			if (fillValue !== void 0) this._elementRef.nativeElement.fill = fillValue;
			const tooltipValue = this.tooltip();
			if (tooltipValue !== void 0) this._elementRef.nativeElement.tooltip = tooltipValue;
			const plotOptionsValue = this.plotOptions();
			if (plotOptionsValue !== void 0) this._elementRef.nativeElement.plotOptions = plotOptionsValue;
			const responsiveValue = this.responsive();
			if (responsiveValue !== void 0) this._elementRef.nativeElement.responsive = responsiveValue;
			const xAxisValue = this.xAxis();
			if (xAxisValue !== void 0) this._elementRef.nativeElement.xAxis = xAxisValue;
			const yAxisValue = this.yAxis();
			if (yAxisValue !== void 0) this._elementRef.nativeElement.yAxis = yAxisValue;
			const gridValue = this.grid();
			if (gridValue !== void 0) this._elementRef.nativeElement.grid = gridValue;
			const statesValue = this.states();
			if (statesValue !== void 0) this._elementRef.nativeElement.states = statesValue;
			const themeValue = this.theme();
			if (themeValue !== void 0) this._elementRef.nativeElement.theme = themeValue;
			const displayValue = this.display();
			if (displayValue !== void 0) this._elementRef.nativeElement.display = displayValue;
			const stackedValue = this.stacked();
			if (stackedValue !== void 0) this._elementRef.nativeElement.stacked = stackedValue;
			const stackTypeValue = this.stackType();
			if (stackTypeValue !== void 0) this._elementRef.nativeElement.stackType = stackTypeValue;
			const isYAxisVisibleValue = this.isYAxisVisible();
			if (isYAxisVisibleValue !== void 0) this._elementRef.nativeElement.isYAxisVisible = isYAxisVisibleValue;
			const isXAxisVisibleValue = this.isXAxisVisible();
			if (isXAxisVisibleValue !== void 0) this._elementRef.nativeElement.isXAxisVisible = isXAxisVisibleValue;
			const isLegendVisibleValue = this.isLegendVisible();
			if (isLegendVisibleValue !== void 0) this._elementRef.nativeElement.isLegendVisible = isLegendVisibleValue;
			const legendPositionValue = this.legendPosition();
			if (legendPositionValue !== void 0) this._elementRef.nativeElement.legendPosition = legendPositionValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const headerValue = this.header();
			if (headerValue !== void 0) this._elementRef.nativeElement.header = headerValue;
			const subHeaderValue = this.subHeader();
			if (subHeaderValue !== void 0) this._elementRef.nativeElement.subHeader = subHeaderValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const fitValue = this.fit();
			if (fitValue !== void 0) this._elementRef.nativeElement.fit = fitValue;
			const widthValue = this.width();
			if (widthValue !== void 0) this._elementRef.nativeElement.width = widthValue;
			const heightValue = this.height();
			if (heightValue !== void 0) this._elementRef.nativeElement.height = heightValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ChartComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: ChartComponent,
		isStandalone: true,
		selector: "mosaik-chart",
		inputs: {
			chart: {
				classPropertyName: "chart",
				publicName: "chart",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showToolbox: {
				classPropertyName: "showToolbox",
				publicName: "showToolbox",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			toolboxTools: {
				classPropertyName: "toolboxTools",
				publicName: "toolboxTools",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			annotations: {
				classPropertyName: "annotations",
				publicName: "annotations",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			colors: {
				classPropertyName: "colors",
				publicName: "colors",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dataLabels: {
				classPropertyName: "dataLabels",
				publicName: "dataLabels",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			series: {
				classPropertyName: "series",
				publicName: "series",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			stroke: {
				classPropertyName: "stroke",
				publicName: "stroke",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			labels: {
				classPropertyName: "labels",
				publicName: "labels",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			legend: {
				classPropertyName: "legend",
				publicName: "legend",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			markers: {
				classPropertyName: "markers",
				publicName: "markers",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			noData: {
				classPropertyName: "noData",
				publicName: "noData",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			fill: {
				classPropertyName: "fill",
				publicName: "fill",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			tooltip: {
				classPropertyName: "tooltip",
				publicName: "tooltip",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			plotOptions: {
				classPropertyName: "plotOptions",
				publicName: "plotOptions",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			responsive: {
				classPropertyName: "responsive",
				publicName: "responsive",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			xAxis: {
				classPropertyName: "xAxis",
				publicName: "xAxis",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			yAxis: {
				classPropertyName: "yAxis",
				publicName: "yAxis",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			grid: {
				classPropertyName: "grid",
				publicName: "grid",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			states: {
				classPropertyName: "states",
				publicName: "states",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			theme: {
				classPropertyName: "theme",
				publicName: "theme",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			display: {
				classPropertyName: "display",
				publicName: "display",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			stacked: {
				classPropertyName: "stacked",
				publicName: "stacked",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			stackType: {
				classPropertyName: "stackType",
				publicName: "stackType",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isYAxisVisible: {
				classPropertyName: "isYAxisVisible",
				publicName: "isYAxisVisible",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isXAxisVisible: {
				classPropertyName: "isXAxisVisible",
				publicName: "isXAxisVisible",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isLegendVisible: {
				classPropertyName: "isLegendVisible",
				publicName: "isLegendVisible",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			legendPosition: {
				classPropertyName: "legendPosition",
				publicName: "legendPosition",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			header: {
				classPropertyName: "header",
				publicName: "header",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			subHeader: {
				classPropertyName: "subHeader",
				publicName: "subHeader",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			fit: {
				classPropertyName: "fit",
				publicName: "fit",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			width: {
				classPropertyName: "width",
				publicName: "width",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			height: {
				classPropertyName: "height",
				publicName: "height",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			chartReady: "chartReady",
			chartToolChanged: "chartToolChanged",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
ChartComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-chart", ChartElement),
	inputs: [
		"chart",
		"showToolbox",
		"toolboxTools",
		"annotations",
		"colors",
		"dataLabels",
		"series",
		"stroke",
		"labels",
		"legend",
		"markers",
		"noData",
		"fill",
		"tooltip",
		"plotOptions",
		"responsive",
		"xAxis",
		"yAxis",
		"grid",
		"states",
		"theme",
		"display",
		"stacked",
		"stackType",
		"isYAxisVisible",
		"isXAxisVisible",
		"isLegendVisible",
		"legendPosition",
		"themeName",
		"header",
		"subHeader",
		"variant",
		"fit",
		"width",
		"height",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], ChartComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ChartComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-chart",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		chart: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "chart",
				required: false
			}]
		}],
		showToolbox: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showToolbox",
				required: false
			}]
		}],
		toolboxTools: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "toolboxTools",
				required: false
			}]
		}],
		annotations: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "annotations",
				required: false
			}]
		}],
		colors: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "colors",
				required: false
			}]
		}],
		dataLabels: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dataLabels",
				required: false
			}]
		}],
		series: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "series",
				required: false
			}]
		}],
		stroke: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "stroke",
				required: false
			}]
		}],
		labels: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "labels",
				required: false
			}]
		}],
		legend: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "legend",
				required: false
			}]
		}],
		markers: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "markers",
				required: false
			}]
		}],
		noData: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "noData",
				required: false
			}]
		}],
		fill: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "fill",
				required: false
			}]
		}],
		tooltip: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tooltip",
				required: false
			}]
		}],
		plotOptions: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "plotOptions",
				required: false
			}]
		}],
		responsive: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "responsive",
				required: false
			}]
		}],
		xAxis: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "xAxis",
				required: false
			}]
		}],
		yAxis: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "yAxis",
				required: false
			}]
		}],
		grid: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "grid",
				required: false
			}]
		}],
		states: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "states",
				required: false
			}]
		}],
		theme: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "theme",
				required: false
			}]
		}],
		display: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "display",
				required: false
			}]
		}],
		stacked: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "stacked",
				required: false
			}]
		}],
		stackType: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "stackType",
				required: false
			}]
		}],
		isYAxisVisible: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isYAxisVisible",
				required: false
			}]
		}],
		isXAxisVisible: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isXAxisVisible",
				required: false
			}]
		}],
		isLegendVisible: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isLegendVisible",
				required: false
			}]
		}],
		legendPosition: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "legendPosition",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		header: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "header",
				required: false
			}]
		}],
		subHeader: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "subHeader",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		fit: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "fit",
				required: false
			}]
		}],
		width: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "width",
				required: false
			}]
		}],
		height: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "height",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		chartReady: [{
			type: i0.Output,
			args: ["chartReady"]
		}],
		chartToolChanged: [{
			type: i0.Output,
			args: ["chartToolChanged"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideChartComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: CHART_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { CHART_DEFAULT_PROPS, CHART_TOOLBOX_DEFAULT_PROPS, ChartComponent, ChartToolboxComponent, provideChartComponent, provideChartToolboxComponent };

//# sourceMappingURL=mosaik-elements-angular-components-chart.mjs.map