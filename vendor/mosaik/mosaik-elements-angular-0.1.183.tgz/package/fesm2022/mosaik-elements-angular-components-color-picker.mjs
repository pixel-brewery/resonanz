import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { ColorPickerElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/color-picker/ColorPickerElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const COLOR_PICKER_DEFAULT_PROPS = new InjectionToken("MOSAIK_COLOR_PICKER_DEFAULT_PROPS");
const COLOR_PICKER_INTL = new InjectionToken("MOSAIK_COLOR_PICKER_INTL");
let ColorPickerComponent = class ColorPickerComponent {
	intl = input(...ngDevMode ? [void 0, { debugName: "intl" }] : /* istanbul ignore next */ []);
	format = input(...ngDevMode ? [void 0, { debugName: "format" }] : /* istanbul ignore next */ []);
	showAlpha = input(...ngDevMode ? [void 0, { debugName: "showAlpha" }] : /* istanbul ignore next */ []);
	showInputs = input(...ngDevMode ? [void 0, { debugName: "showInputs" }] : /* istanbul ignore next */ []);
	showPalette = input(...ngDevMode ? [void 0, { debugName: "showPalette" }] : /* istanbul ignore next */ []);
	showEyeDropper = input(...ngDevMode ? [void 0, { debugName: "showEyeDropper" }] : /* istanbul ignore next */ []);
	showSwatch = input(...ngDevMode ? [void 0, { debugName: "showSwatch" }] : /* istanbul ignore next */ []);
	palettes = input(...ngDevMode ? [void 0, { debugName: "palettes" }] : /* istanbul ignore next */ []);
	selectedPalette = input(...ngDevMode ? [void 0, { debugName: "selectedPalette" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dropDownPlacement = input(...ngDevMode ? [void 0, { debugName: "dropDownPlacement" }] : /* istanbul ignore next */ []);
	dropDownStrategy = input(...ngDevMode ? [void 0, { debugName: "dropDownStrategy" }] : /* istanbul ignore next */ []);
	dropDownDistance = input(...ngDevMode ? [void 0, { debugName: "dropDownDistance" }] : /* istanbul ignore next */ []);
	dropDownSkidding = input(...ngDevMode ? [void 0, { debugName: "dropDownSkidding" }] : /* istanbul ignore next */ []);
	dropDownStaysOpen = input(...ngDevMode ? [void 0, { debugName: "dropDownStaysOpen" }] : /* istanbul ignore next */ []);
	dropDownMaxHeight = input(...ngDevMode ? [void 0, { debugName: "dropDownMaxHeight" }] : /* istanbul ignore next */ []);
	dropDownHeight = input(...ngDevMode ? [void 0, { debugName: "dropDownHeight" }] : /* istanbul ignore next */ []);
	dropDownWidth = input(...ngDevMode ? [void 0, { debugName: "dropDownWidth" }] : /* istanbul ignore next */ []);
	dropDownMaxWidth = input(...ngDevMode ? [void 0, { debugName: "dropDownMaxWidth" }] : /* istanbul ignore next */ []);
	isDropDownOpen = input(...ngDevMode ? [void 0, { debugName: "isDropDownOpen" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	value = input(...ngDevMode ? [void 0, { debugName: "value" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	colorChanged = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			colorChanged: this.colorChanged,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(COLOR_PICKER_DEFAULT_PROPS, { optional: true }) ?? {}, ["intl"]);
		const injectedIntl = inject(COLOR_PICKER_INTL, { optional: true });
		if (injectedIntl) {
			Object.assign(this._elementRef.nativeElement.intl, injectedIntl);
			this._elementRef.nativeElement.intl.changes.emit();
		}
	}
	open(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "open", args);
	}
	close(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "close", args);
	}
	toggle(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "toggle", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const formatValue = this.format();
			if (formatValue !== void 0) this._elementRef.nativeElement.format = formatValue;
			const showAlphaValue = this.showAlpha();
			if (showAlphaValue !== void 0) this._elementRef.nativeElement.showAlpha = showAlphaValue;
			const showInputsValue = this.showInputs();
			if (showInputsValue !== void 0) this._elementRef.nativeElement.showInputs = showInputsValue;
			const showPaletteValue = this.showPalette();
			if (showPaletteValue !== void 0) this._elementRef.nativeElement.showPalette = showPaletteValue;
			const showEyeDropperValue = this.showEyeDropper();
			if (showEyeDropperValue !== void 0) this._elementRef.nativeElement.showEyeDropper = showEyeDropperValue;
			const showSwatchValue = this.showSwatch();
			if (showSwatchValue !== void 0) this._elementRef.nativeElement.showSwatch = showSwatchValue;
			const palettesValue = this.palettes();
			if (palettesValue !== void 0) this._elementRef.nativeElement.palettes = palettesValue;
			const selectedPaletteValue = this.selectedPalette();
			if (selectedPaletteValue !== void 0) this._elementRef.nativeElement.selectedPalette = selectedPaletteValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dropDownPlacementValue = this.dropDownPlacement();
			if (dropDownPlacementValue !== void 0) this._elementRef.nativeElement.dropDownPlacement = dropDownPlacementValue;
			const dropDownStrategyValue = this.dropDownStrategy();
			if (dropDownStrategyValue !== void 0) this._elementRef.nativeElement.dropDownStrategy = dropDownStrategyValue;
			const dropDownDistanceValue = this.dropDownDistance();
			if (dropDownDistanceValue !== void 0) this._elementRef.nativeElement.dropDownDistance = dropDownDistanceValue;
			const dropDownSkiddingValue = this.dropDownSkidding();
			if (dropDownSkiddingValue !== void 0) this._elementRef.nativeElement.dropDownSkidding = dropDownSkiddingValue;
			const dropDownStaysOpenValue = this.dropDownStaysOpen();
			if (dropDownStaysOpenValue !== void 0) this._elementRef.nativeElement.dropDownStaysOpen = dropDownStaysOpenValue;
			const dropDownMaxHeightValue = this.dropDownMaxHeight();
			if (dropDownMaxHeightValue !== void 0) this._elementRef.nativeElement.dropDownMaxHeight = dropDownMaxHeightValue;
			const dropDownHeightValue = this.dropDownHeight();
			if (dropDownHeightValue !== void 0) this._elementRef.nativeElement.dropDownHeight = dropDownHeightValue;
			const dropDownWidthValue = this.dropDownWidth();
			if (dropDownWidthValue !== void 0) this._elementRef.nativeElement.dropDownWidth = dropDownWidthValue;
			const dropDownMaxWidthValue = this.dropDownMaxWidth();
			if (dropDownMaxWidthValue !== void 0) this._elementRef.nativeElement.dropDownMaxWidth = dropDownMaxWidthValue;
			const isDropDownOpenValue = this.isDropDownOpen();
			if (isDropDownOpenValue !== void 0) this._elementRef.nativeElement.isDropDownOpen = isDropDownOpenValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const valueValue = this.value();
			if (valueValue !== void 0) this._elementRef.nativeElement.value = valueValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
			const intlValue = this.intl();
			if (intlValue !== void 0) {
				Object.assign(this._elementRef.nativeElement.intl, intlValue);
				this._elementRef.nativeElement.intl.changes.emit();
			}
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ColorPickerComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: ColorPickerComponent,
		isStandalone: true,
		selector: "mosaik-color-picker",
		inputs: {
			intl: {
				classPropertyName: "intl",
				publicName: "intl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			format: {
				classPropertyName: "format",
				publicName: "format",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showAlpha: {
				classPropertyName: "showAlpha",
				publicName: "showAlpha",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showInputs: {
				classPropertyName: "showInputs",
				publicName: "showInputs",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showPalette: {
				classPropertyName: "showPalette",
				publicName: "showPalette",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showEyeDropper: {
				classPropertyName: "showEyeDropper",
				publicName: "showEyeDropper",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showSwatch: {
				classPropertyName: "showSwatch",
				publicName: "showSwatch",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			palettes: {
				classPropertyName: "palettes",
				publicName: "palettes",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			selectedPalette: {
				classPropertyName: "selectedPalette",
				publicName: "selectedPalette",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownPlacement: {
				classPropertyName: "dropDownPlacement",
				publicName: "dropDownPlacement",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownStrategy: {
				classPropertyName: "dropDownStrategy",
				publicName: "dropDownStrategy",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownDistance: {
				classPropertyName: "dropDownDistance",
				publicName: "dropDownDistance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownSkidding: {
				classPropertyName: "dropDownSkidding",
				publicName: "dropDownSkidding",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownStaysOpen: {
				classPropertyName: "dropDownStaysOpen",
				publicName: "dropDownStaysOpen",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownMaxHeight: {
				classPropertyName: "dropDownMaxHeight",
				publicName: "dropDownMaxHeight",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownHeight: {
				classPropertyName: "dropDownHeight",
				publicName: "dropDownHeight",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownWidth: {
				classPropertyName: "dropDownWidth",
				publicName: "dropDownWidth",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownMaxWidth: {
				classPropertyName: "dropDownMaxWidth",
				publicName: "dropDownMaxWidth",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isDropDownOpen: {
				classPropertyName: "isDropDownOpen",
				publicName: "isDropDownOpen",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			colorChanged: "colorChanged",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
ColorPickerComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-color-picker", ColorPickerElement),
	inputs: [
		"intl",
		"format",
		"showAlpha",
		"showInputs",
		"showPalette",
		"showEyeDropper",
		"showSwatch",
		"palettes",
		"selectedPalette",
		"themeName",
		"dropDownPlacement",
		"dropDownStrategy",
		"dropDownDistance",
		"dropDownSkidding",
		"dropDownStaysOpen",
		"dropDownMaxHeight",
		"dropDownHeight",
		"dropDownWidth",
		"dropDownMaxWidth",
		"isDropDownOpen",
		"disabled",
		"value",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], ColorPickerComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ColorPickerComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-color-picker",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		intl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "intl",
				required: false
			}]
		}],
		format: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "format",
				required: false
			}]
		}],
		showAlpha: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showAlpha",
				required: false
			}]
		}],
		showInputs: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showInputs",
				required: false
			}]
		}],
		showPalette: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showPalette",
				required: false
			}]
		}],
		showEyeDropper: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showEyeDropper",
				required: false
			}]
		}],
		showSwatch: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showSwatch",
				required: false
			}]
		}],
		palettes: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "palettes",
				required: false
			}]
		}],
		selectedPalette: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "selectedPalette",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dropDownPlacement: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownPlacement",
				required: false
			}]
		}],
		dropDownStrategy: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownStrategy",
				required: false
			}]
		}],
		dropDownDistance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownDistance",
				required: false
			}]
		}],
		dropDownSkidding: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownSkidding",
				required: false
			}]
		}],
		dropDownStaysOpen: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownStaysOpen",
				required: false
			}]
		}],
		dropDownMaxHeight: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownMaxHeight",
				required: false
			}]
		}],
		dropDownHeight: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownHeight",
				required: false
			}]
		}],
		dropDownWidth: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownWidth",
				required: false
			}]
		}],
		dropDownMaxWidth: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownMaxWidth",
				required: false
			}]
		}],
		isDropDownOpen: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isDropDownOpen",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		colorChanged: [{
			type: i0.Output,
			args: ["colorChanged"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideColorPickerComponent(config, intl) {
	const providers = [];
	if (config) providers.push({
		provide: COLOR_PICKER_DEFAULT_PROPS,
		useValue: config
	});
	if (intl) {
		if (typeof intl === "function") providers.push({
			provide: COLOR_PICKER_INTL,
			useClass: intl
		});
		else providers.push({
			provide: COLOR_PICKER_INTL,
			useValue: intl
		});
	}
	return makeEnvironmentProviders(providers);
}
export { COLOR_PICKER_DEFAULT_PROPS, COLOR_PICKER_INTL, ColorPickerComponent, provideColorPickerComponent };

//# sourceMappingURL=mosaik-elements-angular-components-color-picker.mjs.map