import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, forwardRef, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { SelectItemGroupElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/select/SelectItemGroupElement";
import * as i1 from "@pixel-brewery/mosaik-elements-angular/runtime";
import { FORM_STATUS_HOST, FormFieldStatusHostDirective, FormStatusHostDirective, ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { SelectItemVisualElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/select/SelectItemVisualElement";
import { SelectItemElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/select/SelectItemElement";
import { NG_VALUE_ACCESSOR } from "@angular/forms";
import { SelectElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/select/SelectElement";
import { selectElementValueAccessor } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/select/accessors/SelectElementValueAccessor";
var __decorate$3 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$3 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const SELECT_ITEM_GROUP_DEFAULT_PROPS = new InjectionToken("MOSAIK_SELECT_ITEM_GROUP_DEFAULT_PROPS");
let SelectItemGroupComponent = class SelectItemGroupComponent {
	header = input(...ngDevMode ? [void 0, { debugName: "header" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(SELECT_ITEM_GROUP_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const headerValue = this.header();
			if (headerValue !== void 0) this._elementRef.nativeElement.header = headerValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: SelectItemGroupComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: SelectItemGroupComponent,
		isStandalone: true,
		selector: "mosaik-select-item-group",
		inputs: {
			header: {
				classPropertyName: "header",
				publicName: "header",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
SelectItemGroupComponent = __decorate$3([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-select-item-group", SelectItemGroupElement),
	inputs: [
		"header",
		"themeName",
		"dir",
		"lang"
	]
}), __metadata$3("design:paramtypes", [])], SelectItemGroupComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: SelectItemGroupComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-select-item-group",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		header: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "header",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideSelectItemGroupComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: SELECT_ITEM_GROUP_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$2 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$2 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const SELECT_ITEM_VISUAL_DEFAULT_PROPS = new InjectionToken("MOSAIK_SELECT_ITEM_VISUAL_DEFAULT_PROPS");
let SelectItemVisualComponent = class SelectItemVisualComponent {
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(SELECT_ITEM_VISUAL_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	assignToSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "assignToSlot", args);
	}
	getSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getSlotContent", args);
	}
	hasSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlotContent", args);
	}
	hasSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlot", args);
	}
	onSlotChanges(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onSlotChanges", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: SelectItemVisualComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: SelectItemVisualComponent,
		isStandalone: true,
		selector: "mosaik-select-item-visual",
		inputs: {
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
SelectItemVisualComponent = __decorate$2([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-select-item-visual", SelectItemVisualElement),
	inputs: [
		"themeName",
		"dir",
		"lang"
	],
	methods: ["getSlotAssignments", "getSlotAssignmentsOf"]
}), __metadata$2("design:paramtypes", [])], SelectItemVisualComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: SelectItemVisualComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-select-item-visual",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideSelectItemVisualComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: SELECT_ITEM_VISUAL_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate$1 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$1 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const SELECT_ITEM_DEFAULT_PROPS = new InjectionToken("MOSAIK_SELECT_ITEM_DEFAULT_PROPS");
let SelectItemComponent = class SelectItemComponent {
	icon = input(...ngDevMode ? [void 0, { debugName: "icon" }] : /* istanbul ignore next */ []);
	isActive = input(...ngDevMode ? [void 0, { debugName: "isActive" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	ripple = input(...ngDevMode ? [void 0, { debugName: "ripple" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	isFocused = input(...ngDevMode ? [void 0, { debugName: "isFocused" }] : /* istanbul ignore next */ []);
	label = input(...ngDevMode ? [void 0, { debugName: "label" }] : /* istanbul ignore next */ []);
	isSelected = input(...ngDevMode ? [void 0, { debugName: "isSelected" }] : /* istanbul ignore next */ []);
	value = input(...ngDevMode ? [void 0, { debugName: "value" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	selected = output();
	deselected = output();
	changed = output();
	connected = output();
	disconnected = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			selected: this.selected,
			deselected: this.deselected,
			changed: this.changed,
			connected: this.connected,
			disconnected: this.disconnected
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(SELECT_ITEM_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	select(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "select", args);
	}
	deselect(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "deselect", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const iconValue = this.icon();
			if (iconValue !== void 0) this._elementRef.nativeElement.icon = iconValue;
			const isActiveValue = this.isActive();
			if (isActiveValue !== void 0) this._elementRef.nativeElement.isActive = isActiveValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const rippleValue = this.ripple();
			if (rippleValue !== void 0) this._elementRef.nativeElement.ripple = rippleValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const isFocusedValue = this.isFocused();
			if (isFocusedValue !== void 0) this._elementRef.nativeElement.isFocused = isFocusedValue;
			const labelValue = this.label();
			if (labelValue !== void 0) this._elementRef.nativeElement.label = labelValue;
			const isSelectedValue = this.isSelected();
			if (isSelectedValue !== void 0) this._elementRef.nativeElement.isSelected = isSelectedValue;
			const valueValue = this.value();
			if (valueValue !== void 0) this._elementRef.nativeElement.value = valueValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: SelectItemComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: SelectItemComponent,
		isStandalone: true,
		selector: "mosaik-select-item",
		inputs: {
			icon: {
				classPropertyName: "icon",
				publicName: "icon",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isActive: {
				classPropertyName: "isActive",
				publicName: "isActive",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			ripple: {
				classPropertyName: "ripple",
				publicName: "ripple",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isFocused: {
				classPropertyName: "isFocused",
				publicName: "isFocused",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isSelected: {
				classPropertyName: "isSelected",
				publicName: "isSelected",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			selected: "selected",
			deselected: "deselected",
			changed: "changed",
			connected: "connected",
			disconnected: "disconnected"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
SelectItemComponent = __decorate$1([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-select-item", SelectItemElement),
	inputs: [
		"icon",
		"isActive",
		"themeName",
		"ripple",
		"disabled",
		"variant",
		"isFocused",
		"label",
		"isSelected",
		"value",
		"dir",
		"lang"
	]
}), __metadata$1("design:paramtypes", [])], SelectItemComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: SelectItemComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-select-item",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		icon: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "icon",
				required: false
			}]
		}],
		isActive: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isActive",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		ripple: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "ripple",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		isFocused: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isFocused",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		isSelected: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isSelected",
				required: false
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		selected: [{
			type: i0.Output,
			args: ["selected"]
		}],
		deselected: [{
			type: i0.Output,
			args: ["deselected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}]
	}
});
function provideSelectItemComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: SELECT_ITEM_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const SELECT_DEFAULT_PROPS = new InjectionToken("MOSAIK_SELECT_DEFAULT_PROPS");
const SELECT_INTL = new InjectionToken("MOSAIK_SELECT_INTL");
let SelectComponent = class SelectComponent {
	intl = input(...ngDevMode ? [void 0, { debugName: "intl" }] : /* istanbul ignore next */ []);
	isEditable = input(...ngDevMode ? [void 0, { debugName: "isEditable" }] : /* istanbul ignore next */ []);
	isReadOnly = input(...ngDevMode ? [void 0, { debugName: "isReadOnly" }] : /* istanbul ignore next */ []);
	placeholder = input(...ngDevMode ? [void 0, { debugName: "placeholder" }] : /* istanbul ignore next */ []);
	required = input(...ngDevMode ? [void 0, { debugName: "required" }] : /* istanbul ignore next */ []);
	textAlign = input(...ngDevMode ? [void 0, { debugName: "textAlign" }] : /* istanbul ignore next */ []);
	showScrollButtons = input(...ngDevMode ? [void 0, { debugName: "showScrollButtons" }] : /* istanbul ignore next */ []);
	showScrollbar = input(...ngDevMode ? [void 0, { debugName: "showScrollbar" }] : /* istanbul ignore next */ []);
	dropDownPlacement = input(...ngDevMode ? [void 0, { debugName: "dropDownPlacement" }] : /* istanbul ignore next */ []);
	dropDownStrategy = input(...ngDevMode ? [void 0, { debugName: "dropDownStrategy" }] : /* istanbul ignore next */ []);
	dropDownDistance = input(...ngDevMode ? [void 0, { debugName: "dropDownDistance" }] : /* istanbul ignore next */ []);
	dropDownSkidding = input(...ngDevMode ? [void 0, { debugName: "dropDownSkidding" }] : /* istanbul ignore next */ []);
	dropDownStaysOpen = input(...ngDevMode ? [void 0, { debugName: "dropDownStaysOpen" }] : /* istanbul ignore next */ []);
	dropDownMaxHeight = input(...ngDevMode ? [void 0, { debugName: "dropDownMaxHeight" }] : /* istanbul ignore next */ []);
	dropDownHeight = input(...ngDevMode ? [void 0, { debugName: "dropDownHeight" }] : /* istanbul ignore next */ []);
	dropDownWidth = input(...ngDevMode ? [void 0, { debugName: "dropDownWidth" }] : /* istanbul ignore next */ []);
	dropDownMaxWidth = input(...ngDevMode ? [void 0, { debugName: "dropDownMaxWidth" }] : /* istanbul ignore next */ []);
	isDropDownOpen = input(...ngDevMode ? [void 0, { debugName: "isDropDownOpen" }] : /* istanbul ignore next */ []);
	appearance = input(...ngDevMode ? [void 0, { debugName: "appearance" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	size = input(...ngDevMode ? [void 0, { debugName: "size" }] : /* istanbul ignore next */ []);
	label = input(...ngDevMode ? [void 0, { debugName: "label" }] : /* istanbul ignore next */ []);
	isClearable = input(...ngDevMode ? [void 0, { debugName: "isClearable" }] : /* istanbul ignore next */ []);
	invalid = input(...ngDevMode ? [void 0, { debugName: "invalid" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	value = input(...ngDevMode ? [void 0, { debugName: "value" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	showFilter = input(...ngDevMode ? [void 0, { debugName: "showFilter" }] : /* istanbul ignore next */ []);
	filterMemberPath = input(...ngDevMode ? [void 0, { debugName: "filterMemberPath" }] : /* istanbul ignore next */ []);
	filter = input(...ngDevMode ? [void 0, { debugName: "filter" }] : /* istanbul ignore next */ []);
	filterPlaceholder = input(...ngDevMode ? [void 0, { debugName: "filterPlaceholder" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	cleared = output();
	selectionChanged = output();
	itemsChanged = output();
	changed = output();
	connected = output();
	disconnected = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	_accessor;
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._accessor = selectElementValueAccessor(this._elementRef.nativeElement);
		this._elementRef.nativeElement.addController(this._accessor);
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			cleared: this.cleared,
			selectionChanged: this.selectionChanged,
			itemsChanged: this.itemsChanged,
			changed: this.changed,
			connected: this.connected,
			disconnected: this.disconnected
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
			this._accessor.releaseCallbacks();
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(SELECT_DEFAULT_PROPS, { optional: true }) ?? {}, ["intl"]);
		const injectedIntl = inject(SELECT_INTL, { optional: true });
		if (injectedIntl) {
			Object.assign(this._elementRef.nativeElement.intl, injectedIntl);
			this._elementRef.nativeElement.intl.changes.emit();
		}
	}
	writeValue(obj) {
		this._accessor.writeValue(obj);
	}
	registerOnChange(fn) {
		this._accessor.registerOnChange(fn);
	}
	registerOnTouched(fn) {
		this._accessor.registerOnTouched(fn);
	}
	setDisabledState(isDisabled) {
		this._accessor.setDisabled?.(isDisabled);
	}
	reset(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "reset", args);
	}
	checkValidity(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "checkValidity", args);
	}
	clear(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "clear", args);
	}
	onSlotChanges(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "onSlotChanges", args);
	}
	getScrollableElement(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getScrollableElement", args);
	}
	assignToSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "assignToSlot", args);
	}
	getSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "getSlotContent", args);
	}
	hasSlotContent(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlotContent", args);
	}
	hasSlot(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hasSlot", args);
	}
	open(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "open", args);
	}
	close(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "close", args);
	}
	toggle(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "toggle", args);
	}
	select(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "select", args);
	}
	deselect(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "deselect", args);
	}
	resetSelection(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "resetSelection", args);
	}
	selectNext(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "selectNext", args);
	}
	selectPrevious(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "selectPrevious", args);
	}
	selectFirst(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "selectFirst", args);
	}
	selectLast(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "selectLast", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const isEditableValue = this.isEditable();
			if (isEditableValue !== void 0) this._elementRef.nativeElement.isEditable = isEditableValue;
			const isReadOnlyValue = this.isReadOnly();
			if (isReadOnlyValue !== void 0) this._elementRef.nativeElement.isReadOnly = isReadOnlyValue;
			const placeholderValue = this.placeholder();
			if (placeholderValue !== void 0) this._elementRef.nativeElement.placeholder = placeholderValue;
			const requiredValue = this.required();
			if (requiredValue !== void 0) this._elementRef.nativeElement.required = requiredValue;
			const textAlignValue = this.textAlign();
			if (textAlignValue !== void 0) this._elementRef.nativeElement.textAlign = textAlignValue;
			const showScrollButtonsValue = this.showScrollButtons();
			if (showScrollButtonsValue !== void 0) this._elementRef.nativeElement.showScrollButtons = showScrollButtonsValue;
			const showScrollbarValue = this.showScrollbar();
			if (showScrollbarValue !== void 0) this._elementRef.nativeElement.showScrollbar = showScrollbarValue;
			const dropDownPlacementValue = this.dropDownPlacement();
			if (dropDownPlacementValue !== void 0) this._elementRef.nativeElement.dropDownPlacement = dropDownPlacementValue;
			const dropDownStrategyValue = this.dropDownStrategy();
			if (dropDownStrategyValue !== void 0) this._elementRef.nativeElement.dropDownStrategy = dropDownStrategyValue;
			const dropDownDistanceValue = this.dropDownDistance();
			if (dropDownDistanceValue !== void 0) this._elementRef.nativeElement.dropDownDistance = dropDownDistanceValue;
			const dropDownSkiddingValue = this.dropDownSkidding();
			if (dropDownSkiddingValue !== void 0) this._elementRef.nativeElement.dropDownSkidding = dropDownSkiddingValue;
			const dropDownStaysOpenValue = this.dropDownStaysOpen();
			if (dropDownStaysOpenValue !== void 0) this._elementRef.nativeElement.dropDownStaysOpen = dropDownStaysOpenValue;
			const dropDownMaxHeightValue = this.dropDownMaxHeight();
			if (dropDownMaxHeightValue !== void 0) this._elementRef.nativeElement.dropDownMaxHeight = dropDownMaxHeightValue;
			const dropDownHeightValue = this.dropDownHeight();
			if (dropDownHeightValue !== void 0) this._elementRef.nativeElement.dropDownHeight = dropDownHeightValue;
			const dropDownWidthValue = this.dropDownWidth();
			if (dropDownWidthValue !== void 0) this._elementRef.nativeElement.dropDownWidth = dropDownWidthValue;
			const dropDownMaxWidthValue = this.dropDownMaxWidth();
			if (dropDownMaxWidthValue !== void 0) this._elementRef.nativeElement.dropDownMaxWidth = dropDownMaxWidthValue;
			const isDropDownOpenValue = this.isDropDownOpen();
			if (isDropDownOpenValue !== void 0) this._elementRef.nativeElement.isDropDownOpen = isDropDownOpenValue;
			const appearanceValue = this.appearance();
			if (appearanceValue !== void 0) this._elementRef.nativeElement.appearance = appearanceValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const sizeValue = this.size();
			if (sizeValue !== void 0) this._elementRef.nativeElement.size = sizeValue;
			const labelValue = this.label();
			if (labelValue !== void 0) this._elementRef.nativeElement.label = labelValue;
			const isClearableValue = this.isClearable();
			if (isClearableValue !== void 0) this._elementRef.nativeElement.isClearable = isClearableValue;
			const invalidValue = this.invalid();
			if (invalidValue !== void 0) this._elementRef.nativeElement.invalid = invalidValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const valueValue = this.value();
			if (valueValue !== void 0) this._elementRef.nativeElement.value = valueValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const showFilterValue = this.showFilter();
			if (showFilterValue !== void 0) this._elementRef.nativeElement.showFilter = showFilterValue;
			const filterMemberPathValue = this.filterMemberPath();
			if (filterMemberPathValue !== void 0) this._elementRef.nativeElement.filterMemberPath = filterMemberPathValue;
			const filterValue = this.filter();
			if (filterValue !== void 0) this._elementRef.nativeElement.filter = filterValue;
			const filterPlaceholderValue = this.filterPlaceholder();
			if (filterPlaceholderValue !== void 0) this._elementRef.nativeElement.filterPlaceholder = filterPlaceholderValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
			const intlValue = this.intl();
			if (intlValue !== void 0) {
				Object.assign(this._elementRef.nativeElement.intl, intlValue);
				this._elementRef.nativeElement.intl.changes.emit();
			}
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: SelectComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: SelectComponent,
		isStandalone: true,
		selector: "mosaik-select",
		inputs: {
			intl: {
				classPropertyName: "intl",
				publicName: "intl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isEditable: {
				classPropertyName: "isEditable",
				publicName: "isEditable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isReadOnly: {
				classPropertyName: "isReadOnly",
				publicName: "isReadOnly",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			placeholder: {
				classPropertyName: "placeholder",
				publicName: "placeholder",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			required: {
				classPropertyName: "required",
				publicName: "required",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			textAlign: {
				classPropertyName: "textAlign",
				publicName: "textAlign",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showScrollButtons: {
				classPropertyName: "showScrollButtons",
				publicName: "showScrollButtons",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showScrollbar: {
				classPropertyName: "showScrollbar",
				publicName: "showScrollbar",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownPlacement: {
				classPropertyName: "dropDownPlacement",
				publicName: "dropDownPlacement",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownStrategy: {
				classPropertyName: "dropDownStrategy",
				publicName: "dropDownStrategy",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownDistance: {
				classPropertyName: "dropDownDistance",
				publicName: "dropDownDistance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownSkidding: {
				classPropertyName: "dropDownSkidding",
				publicName: "dropDownSkidding",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownStaysOpen: {
				classPropertyName: "dropDownStaysOpen",
				publicName: "dropDownStaysOpen",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownMaxHeight: {
				classPropertyName: "dropDownMaxHeight",
				publicName: "dropDownMaxHeight",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownHeight: {
				classPropertyName: "dropDownHeight",
				publicName: "dropDownHeight",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownWidth: {
				classPropertyName: "dropDownWidth",
				publicName: "dropDownWidth",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropDownMaxWidth: {
				classPropertyName: "dropDownMaxWidth",
				publicName: "dropDownMaxWidth",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isDropDownOpen: {
				classPropertyName: "isDropDownOpen",
				publicName: "isDropDownOpen",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isClearable: {
				classPropertyName: "isClearable",
				publicName: "isClearable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			invalid: {
				classPropertyName: "invalid",
				publicName: "invalid",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showFilter: {
				classPropertyName: "showFilter",
				publicName: "showFilter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			filterMemberPath: {
				classPropertyName: "filterMemberPath",
				publicName: "filterMemberPath",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			filter: {
				classPropertyName: "filter",
				publicName: "filter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			filterPlaceholder: {
				classPropertyName: "filterPlaceholder",
				publicName: "filterPlaceholder",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			cleared: "cleared",
			selectionChanged: "selectionChanged",
			itemsChanged: "itemsChanged",
			changed: "changed",
			connected: "connected",
			disconnected: "disconnected"
		},
		providers: [{
			provide: NG_VALUE_ACCESSOR,
			useExisting: forwardRef(() => SelectComponent),
			multi: true
		}, {
			provide: FORM_STATUS_HOST,
			useExisting: forwardRef(() => SelectComponent)
		}],
		hostDirectives: [{ directive: i1.FormStatusHostDirective }, { directive: i1.FormFieldStatusHostDirective }],
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
SelectComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-select", SelectElement),
	inputs: [
		"intl",
		"isEditable",
		"isReadOnly",
		"placeholder",
		"required",
		"textAlign",
		"showScrollButtons",
		"showScrollbar",
		"dropDownPlacement",
		"dropDownStrategy",
		"dropDownDistance",
		"dropDownSkidding",
		"dropDownStaysOpen",
		"dropDownMaxHeight",
		"dropDownHeight",
		"dropDownWidth",
		"dropDownMaxWidth",
		"isDropDownOpen",
		"appearance",
		"variant",
		"size",
		"label",
		"isClearable",
		"invalid",
		"disabled",
		"value",
		"themeName",
		"showFilter",
		"filterMemberPath",
		"filter",
		"filterPlaceholder",
		"dir",
		"lang"
	],
	methods: ["getSlotAssignments", "getSlotAssignmentsOf"]
}), __metadata("design:paramtypes", [])], SelectComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: SelectComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-select",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>",
			hostDirectives: [FormStatusHostDirective, FormFieldStatusHostDirective],
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => SelectComponent),
				multi: true
			}, {
				provide: FORM_STATUS_HOST,
				useExisting: forwardRef(() => SelectComponent)
			}]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		intl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "intl",
				required: false
			}]
		}],
		isEditable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isEditable",
				required: false
			}]
		}],
		isReadOnly: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isReadOnly",
				required: false
			}]
		}],
		placeholder: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "placeholder",
				required: false
			}]
		}],
		required: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "required",
				required: false
			}]
		}],
		textAlign: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "textAlign",
				required: false
			}]
		}],
		showScrollButtons: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showScrollButtons",
				required: false
			}]
		}],
		showScrollbar: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showScrollbar",
				required: false
			}]
		}],
		dropDownPlacement: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownPlacement",
				required: false
			}]
		}],
		dropDownStrategy: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownStrategy",
				required: false
			}]
		}],
		dropDownDistance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownDistance",
				required: false
			}]
		}],
		dropDownSkidding: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownSkidding",
				required: false
			}]
		}],
		dropDownStaysOpen: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownStaysOpen",
				required: false
			}]
		}],
		dropDownMaxHeight: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownMaxHeight",
				required: false
			}]
		}],
		dropDownHeight: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownHeight",
				required: false
			}]
		}],
		dropDownWidth: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownWidth",
				required: false
			}]
		}],
		dropDownMaxWidth: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropDownMaxWidth",
				required: false
			}]
		}],
		isDropDownOpen: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isDropDownOpen",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		isClearable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isClearable",
				required: false
			}]
		}],
		invalid: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "invalid",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		showFilter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showFilter",
				required: false
			}]
		}],
		filterMemberPath: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "filterMemberPath",
				required: false
			}]
		}],
		filter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "filter",
				required: false
			}]
		}],
		filterPlaceholder: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "filterPlaceholder",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		cleared: [{
			type: i0.Output,
			args: ["cleared"]
		}],
		selectionChanged: [{
			type: i0.Output,
			args: ["selectionChanged"]
		}],
		itemsChanged: [{
			type: i0.Output,
			args: ["itemsChanged"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}]
	}
});
function provideSelectComponent(config, intl) {
	const providers = [];
	if (config) providers.push({
		provide: SELECT_DEFAULT_PROPS,
		useValue: config
	});
	if (intl) {
		if (typeof intl === "function") providers.push({
			provide: SELECT_INTL,
			useClass: intl
		});
		else providers.push({
			provide: SELECT_INTL,
			useValue: intl
		});
	}
	return makeEnvironmentProviders(providers);
}
export { SELECT_DEFAULT_PROPS, SELECT_INTL, SELECT_ITEM_DEFAULT_PROPS, SELECT_ITEM_GROUP_DEFAULT_PROPS, SELECT_ITEM_VISUAL_DEFAULT_PROPS, SelectComponent, SelectItemComponent, SelectItemGroupComponent, SelectItemVisualComponent, provideSelectComponent, provideSelectItemComponent, provideSelectItemGroupComponent, provideSelectItemVisualComponent };

//# sourceMappingURL=mosaik-elements-angular-components-select.mjs.map