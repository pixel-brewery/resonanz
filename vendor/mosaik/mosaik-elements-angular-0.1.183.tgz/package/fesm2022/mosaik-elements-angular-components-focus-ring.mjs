import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { FocusRingElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/focus-ring/FocusRingElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const FOCUS_RING_DEFAULT_PROPS = new InjectionToken("MOSAIK_FOCUS_RING_DEFAULT_PROPS");
let FocusRingComponent = class FocusRingComponent {
	visible = input(...ngDevMode ? [void 0, { debugName: "visible" }] : /* istanbul ignore next */ []);
	inward = input(...ngDevMode ? [void 0, { debugName: "inward" }] : /* istanbul ignore next */ []);
	controlled = input(...ngDevMode ? [void 0, { debugName: "controlled" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	for = input(...ngDevMode ? [void 0, { debugName: "for" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(FOCUS_RING_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	attach(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "attach", args);
	}
	detach(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "detach", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const visibleValue = this.visible();
			if (visibleValue !== void 0) this._elementRef.nativeElement.visible = visibleValue;
			const inwardValue = this.inward();
			if (inwardValue !== void 0) this._elementRef.nativeElement.inward = inwardValue;
			const controlledValue = this.controlled();
			if (controlledValue !== void 0) this._elementRef.nativeElement.controlled = controlledValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const forValue = this.for();
			if (forValue !== void 0) this._elementRef.nativeElement.for = forValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FocusRingComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: FocusRingComponent,
		isStandalone: true,
		selector: "mosaik-focus-ring",
		inputs: {
			visible: {
				classPropertyName: "visible",
				publicName: "visible",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			inward: {
				classPropertyName: "inward",
				publicName: "inward",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			controlled: {
				classPropertyName: "controlled",
				publicName: "controlled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			for: {
				classPropertyName: "for",
				publicName: "for",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
FocusRingComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-focus-ring", FocusRingElement),
	inputs: [
		"visible",
		"inward",
		"controlled",
		"themeName",
		"for",
		"variant",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], FocusRingComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FocusRingComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-focus-ring",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		visible: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "visible",
				required: false
			}]
		}],
		inward: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "inward",
				required: false
			}]
		}],
		controlled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "controlled",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		for: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "for",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideFocusRingComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: FOCUS_RING_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { FOCUS_RING_DEFAULT_PROPS, FocusRingComponent, provideFocusRingComponent };

//# sourceMappingURL=mosaik-elements-angular-components-focus-ring.mjs.map