import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { DisclosureElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/grouping/disclosure/DisclosureElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const DISCLOSURE_DEFAULT_PROPS = new InjectionToken("MOSAIK_DISCLOSURE_DEFAULT_PROPS");
let DisclosureComponent = class DisclosureComponent {
	summary = input(...ngDevMode ? [void 0, { debugName: "summary" }] : /* istanbul ignore next */ []);
	isExpanded = input(...ngDevMode ? [void 0, { debugName: "isExpanded" }] : /* istanbul ignore next */ []);
	caretVisible = input(...ngDevMode ? [void 0, { debugName: "caretVisible" }] : /* istanbul ignore next */ []);
	caretPosition = input(...ngDevMode ? [void 0, { debugName: "caretPosition" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(DISCLOSURE_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	show(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "show", args);
	}
	hide(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "hide", args);
	}
	toggle(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "toggle", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const summaryValue = this.summary();
			if (summaryValue !== void 0) this._elementRef.nativeElement.summary = summaryValue;
			const isExpandedValue = this.isExpanded();
			if (isExpandedValue !== void 0) this._elementRef.nativeElement.isExpanded = isExpandedValue;
			const caretVisibleValue = this.caretVisible();
			if (caretVisibleValue !== void 0) this._elementRef.nativeElement.caretVisible = caretVisibleValue;
			const caretPositionValue = this.caretPosition();
			if (caretPositionValue !== void 0) this._elementRef.nativeElement.caretPosition = caretPositionValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DisclosureComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: DisclosureComponent,
		isStandalone: true,
		selector: "mosaik-disclosure",
		inputs: {
			summary: {
				classPropertyName: "summary",
				publicName: "summary",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isExpanded: {
				classPropertyName: "isExpanded",
				publicName: "isExpanded",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			caretVisible: {
				classPropertyName: "caretVisible",
				publicName: "caretVisible",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			caretPosition: {
				classPropertyName: "caretPosition",
				publicName: "caretPosition",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
DisclosureComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-disclosure", DisclosureElement),
	inputs: [
		"summary",
		"isExpanded",
		"caretVisible",
		"caretPosition",
		"themeName",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], DisclosureComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DisclosureComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-disclosure",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		summary: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "summary",
				required: false
			}]
		}],
		isExpanded: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isExpanded",
				required: false
			}]
		}],
		caretVisible: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "caretVisible",
				required: false
			}]
		}],
		caretPosition: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "caretPosition",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideDisclosureComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: DISCLOSURE_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { DISCLOSURE_DEFAULT_PROPS, DisclosureComponent, provideDisclosureComponent };

//# sourceMappingURL=mosaik-elements-angular-components-disclosure.mjs.map