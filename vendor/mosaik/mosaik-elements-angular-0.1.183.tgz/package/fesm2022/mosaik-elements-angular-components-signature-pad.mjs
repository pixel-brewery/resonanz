import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, forwardRef, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { NG_VALUE_ACCESSOR } from "@angular/forms";
import { SignaturePadElement, signaturePadElementValueAccessor } from "@pixel-brewery/mosaik-elements-foundation/components/signature-pad";
import * as i1 from "@pixel-brewery/mosaik-elements-angular/runtime";
import { FORM_STATUS_HOST, FormFieldStatusHostDirective, FormStatusHostDirective, ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const SIGNATURE_PAD_DEFAULT_PROPS = new InjectionToken("MOSAIK_SIGNATURE_PAD_DEFAULT_PROPS");
const SIGNATURE_PAD_INTL = new InjectionToken("MOSAIK_SIGNATURE_PAD_INTL");
let SignaturePadComponent = class SignaturePadComponent {
	width = input(...ngDevMode ? [void 0, { debugName: "width" }] : /* istanbul ignore next */ []);
	height = input(...ngDevMode ? [void 0, { debugName: "height" }] : /* istanbul ignore next */ []);
	placeholder = input(...ngDevMode ? [void 0, { debugName: "placeholder" }] : /* istanbul ignore next */ []);
	minDistance = input(...ngDevMode ? [void 0, { debugName: "minDistance" }] : /* istanbul ignore next */ []);
	throttle = input(...ngDevMode ? [void 0, { debugName: "throttle" }] : /* istanbul ignore next */ []);
	dotSize = input(...ngDevMode ? [void 0, { debugName: "dotSize" }] : /* istanbul ignore next */ []);
	minWidth = input(...ngDevMode ? [void 0, { debugName: "minWidth" }] : /* istanbul ignore next */ []);
	maxWidth = input(...ngDevMode ? [void 0, { debugName: "maxWidth" }] : /* istanbul ignore next */ []);
	velocityFilterWeight = input(...ngDevMode ? [void 0, { debugName: "velocityFilterWeight" }] : /* istanbul ignore next */ []);
	backgroundColor = input(...ngDevMode ? [void 0, { debugName: "backgroundColor" }] : /* istanbul ignore next */ []);
	penColor = input(...ngDevMode ? [void 0, { debugName: "penColor" }] : /* istanbul ignore next */ []);
	required = input(...ngDevMode ? [void 0, { debugName: "required" }] : /* istanbul ignore next */ []);
	intl = input(...ngDevMode ? [void 0, { debugName: "intl" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	isClearable = input(...ngDevMode ? [void 0, { debugName: "isClearable" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	isFocused = input(...ngDevMode ? [void 0, { debugName: "isFocused" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	invalid = input(...ngDevMode ? [void 0, { debugName: "invalid" }] : /* istanbul ignore next */ []);
	value = input(...ngDevMode ? [void 0, { debugName: "value" }] : /* istanbul ignore next */ []);
	label = input(...ngDevMode ? [void 0, { debugName: "label" }] : /* istanbul ignore next */ []);
	appearance = input(...ngDevMode ? [void 0, { debugName: "appearance" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	cleared = output();
	signStarted = output();
	signEnded = output();
	signStrokeBeforeUpdate = output();
	signStrokeAfterUpdate = output();
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	_accessor;
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._accessor = signaturePadElementValueAccessor(this._elementRef.nativeElement);
		this._elementRef.nativeElement.addController(this._accessor);
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			cleared: this.cleared,
			signStarted: this.signStarted,
			signEnded: this.signEnded,
			signStrokeBeforeUpdate: this.signStrokeBeforeUpdate,
			signStrokeAfterUpdate: this.signStrokeAfterUpdate,
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
			this._accessor.releaseCallbacks();
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(SIGNATURE_PAD_DEFAULT_PROPS, { optional: true }) ?? {}, ["intl"]);
		const injectedIntl = inject(SIGNATURE_PAD_INTL, { optional: true });
		if (injectedIntl) {
			Object.assign(this._elementRef.nativeElement.intl, injectedIntl);
			this._elementRef.nativeElement.intl.changes.emit();
		}
	}
	writeValue(obj) {
		this._accessor.writeValue(obj);
	}
	registerOnChange(fn) {
		this._accessor.registerOnChange(fn);
	}
	registerOnTouched(fn) {
		this._accessor.registerOnTouched(fn);
	}
	setDisabledState(isDisabled) {
		this._accessor.setDisabled?.(isDisabled);
	}
	checkValidity(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "checkValidity", args);
	}
	reset(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "reset", args);
	}
	toData(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "toData", args);
	}
	toDataURL(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "toDataURL", args);
	}
	toBlob(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "toBlob", args);
	}
	fromData(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "fromData", args);
	}
	fromDataURL(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "fromDataURL", args);
	}
	clear(...args) {
		return invokeElementMethod(this._elementRef.nativeElement, "clear", args);
	}
	invoke(method, ...args) {
		return invokeProxyMethod(this._elementRef.nativeElement, method, ...args);
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const widthValue = this.width();
			if (widthValue !== void 0) this._elementRef.nativeElement.width = widthValue;
			const heightValue = this.height();
			if (heightValue !== void 0) this._elementRef.nativeElement.height = heightValue;
			const placeholderValue = this.placeholder();
			if (placeholderValue !== void 0) this._elementRef.nativeElement.placeholder = placeholderValue;
			const minDistanceValue = this.minDistance();
			if (minDistanceValue !== void 0) this._elementRef.nativeElement.minDistance = minDistanceValue;
			const throttleValue = this.throttle();
			if (throttleValue !== void 0) this._elementRef.nativeElement.throttle = throttleValue;
			const dotSizeValue = this.dotSize();
			if (dotSizeValue !== void 0) this._elementRef.nativeElement.dotSize = dotSizeValue;
			const minWidthValue = this.minWidth();
			if (minWidthValue !== void 0) this._elementRef.nativeElement.minWidth = minWidthValue;
			const maxWidthValue = this.maxWidth();
			if (maxWidthValue !== void 0) this._elementRef.nativeElement.maxWidth = maxWidthValue;
			const velocityFilterWeightValue = this.velocityFilterWeight();
			if (velocityFilterWeightValue !== void 0) this._elementRef.nativeElement.velocityFilterWeight = velocityFilterWeightValue;
			const backgroundColorValue = this.backgroundColor();
			if (backgroundColorValue !== void 0) this._elementRef.nativeElement.backgroundColor = backgroundColorValue;
			const penColorValue = this.penColor();
			if (penColorValue !== void 0) this._elementRef.nativeElement.penColor = penColorValue;
			const requiredValue = this.required();
			if (requiredValue !== void 0) this._elementRef.nativeElement.required = requiredValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const isClearableValue = this.isClearable();
			if (isClearableValue !== void 0) this._elementRef.nativeElement.isClearable = isClearableValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const isFocusedValue = this.isFocused();
			if (isFocusedValue !== void 0) this._elementRef.nativeElement.isFocused = isFocusedValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const invalidValue = this.invalid();
			if (invalidValue !== void 0) this._elementRef.nativeElement.invalid = invalidValue;
			const valueValue = this.value();
			if (valueValue !== void 0) this._elementRef.nativeElement.value = valueValue;
			const labelValue = this.label();
			if (labelValue !== void 0) this._elementRef.nativeElement.label = labelValue;
			const appearanceValue = this.appearance();
			if (appearanceValue !== void 0) this._elementRef.nativeElement.appearance = appearanceValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
			const intlValue = this.intl();
			if (intlValue !== void 0) {
				Object.assign(this._elementRef.nativeElement.intl, intlValue);
				this._elementRef.nativeElement.intl.changes.emit();
			}
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: SignaturePadComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: SignaturePadComponent,
		isStandalone: true,
		selector: "mosaik-signaturepad",
		inputs: {
			width: {
				classPropertyName: "width",
				publicName: "width",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			height: {
				classPropertyName: "height",
				publicName: "height",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			placeholder: {
				classPropertyName: "placeholder",
				publicName: "placeholder",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			minDistance: {
				classPropertyName: "minDistance",
				publicName: "minDistance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			throttle: {
				classPropertyName: "throttle",
				publicName: "throttle",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dotSize: {
				classPropertyName: "dotSize",
				publicName: "dotSize",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			minWidth: {
				classPropertyName: "minWidth",
				publicName: "minWidth",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			maxWidth: {
				classPropertyName: "maxWidth",
				publicName: "maxWidth",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			velocityFilterWeight: {
				classPropertyName: "velocityFilterWeight",
				publicName: "velocityFilterWeight",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			backgroundColor: {
				classPropertyName: "backgroundColor",
				publicName: "backgroundColor",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			penColor: {
				classPropertyName: "penColor",
				publicName: "penColor",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			required: {
				classPropertyName: "required",
				publicName: "required",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			intl: {
				classPropertyName: "intl",
				publicName: "intl",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isClearable: {
				classPropertyName: "isClearable",
				publicName: "isClearable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isFocused: {
				classPropertyName: "isFocused",
				publicName: "isFocused",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			invalid: {
				classPropertyName: "invalid",
				publicName: "invalid",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			cleared: "cleared",
			signStarted: "signStarted",
			signEnded: "signEnded",
			signStrokeBeforeUpdate: "signStrokeBeforeUpdate",
			signStrokeAfterUpdate: "signStrokeAfterUpdate",
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		providers: [{
			provide: NG_VALUE_ACCESSOR,
			useExisting: forwardRef(() => SignaturePadComponent),
			multi: true
		}, {
			provide: FORM_STATUS_HOST,
			useExisting: forwardRef(() => SignaturePadComponent)
		}],
		hostDirectives: [{ directive: i1.FormStatusHostDirective }, { directive: i1.FormFieldStatusHostDirective }],
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
SignaturePadComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-signaturepad", SignaturePadElement),
	inputs: [
		"width",
		"height",
		"placeholder",
		"minDistance",
		"throttle",
		"dotSize",
		"minWidth",
		"maxWidth",
		"velocityFilterWeight",
		"backgroundColor",
		"penColor",
		"required",
		"intl",
		"themeName",
		"isClearable",
		"disabled",
		"isFocused",
		"variant",
		"invalid",
		"value",
		"label",
		"appearance",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], SignaturePadComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: SignaturePadComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-signaturepad",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>",
			hostDirectives: [FormStatusHostDirective, FormFieldStatusHostDirective],
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => SignaturePadComponent),
				multi: true
			}, {
				provide: FORM_STATUS_HOST,
				useExisting: forwardRef(() => SignaturePadComponent)
			}]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		width: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "width",
				required: false
			}]
		}],
		height: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "height",
				required: false
			}]
		}],
		placeholder: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "placeholder",
				required: false
			}]
		}],
		minDistance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "minDistance",
				required: false
			}]
		}],
		throttle: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "throttle",
				required: false
			}]
		}],
		dotSize: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dotSize",
				required: false
			}]
		}],
		minWidth: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "minWidth",
				required: false
			}]
		}],
		maxWidth: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maxWidth",
				required: false
			}]
		}],
		velocityFilterWeight: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "velocityFilterWeight",
				required: false
			}]
		}],
		backgroundColor: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "backgroundColor",
				required: false
			}]
		}],
		penColor: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "penColor",
				required: false
			}]
		}],
		required: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "required",
				required: false
			}]
		}],
		intl: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "intl",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		isClearable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isClearable",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		isFocused: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isFocused",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		invalid: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "invalid",
				required: false
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		cleared: [{
			type: i0.Output,
			args: ["cleared"]
		}],
		signStarted: [{
			type: i0.Output,
			args: ["signStarted"]
		}],
		signEnded: [{
			type: i0.Output,
			args: ["signEnded"]
		}],
		signStrokeBeforeUpdate: [{
			type: i0.Output,
			args: ["signStrokeBeforeUpdate"]
		}],
		signStrokeAfterUpdate: [{
			type: i0.Output,
			args: ["signStrokeAfterUpdate"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideSignaturePadComponent(config, intl) {
	const providers = [];
	if (config) providers.push({
		provide: SIGNATURE_PAD_DEFAULT_PROPS,
		useValue: config
	});
	if (intl) {
		if (typeof intl === "function") providers.push({
			provide: SIGNATURE_PAD_INTL,
			useClass: intl
		});
		else providers.push({
			provide: SIGNATURE_PAD_INTL,
			useValue: intl
		});
	}
	return makeEnvironmentProviders(providers);
}
export { SIGNATURE_PAD_DEFAULT_PROPS, SIGNATURE_PAD_INTL, SignaturePadComponent, provideSignaturePadComponent };

//# sourceMappingURL=mosaik-elements-angular-components-signature-pad.mjs.map