import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { SpacerElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/spacer/SpacerElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const SPACER_DEFAULT_PROPS = new InjectionToken("MOSAIK_SPACER_DEFAULT_PROPS");
let SpacerComponent = class SpacerComponent {
	multiplier = input(...ngDevMode ? [void 0, { debugName: "multiplier" }] : /* istanbul ignore next */ []);
	multiplierValidator = input(...ngDevMode ? [void 0, { debugName: "multiplierValidator" }] : /* istanbul ignore next */ []);
	size = input(...ngDevMode ? [void 0, { debugName: "size" }] : /* istanbul ignore next */ []);
	thickness = input(...ngDevMode ? [void 0, { debugName: "thickness" }] : /* istanbul ignore next */ []);
	invert = input(...ngDevMode ? [void 0, { debugName: "invert" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(SPACER_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const multiplierValue = this.multiplier();
			if (multiplierValue !== void 0) this._elementRef.nativeElement.multiplier = multiplierValue;
			const multiplierValidatorValue = this.multiplierValidator();
			if (multiplierValidatorValue !== void 0) this._elementRef.nativeElement.multiplierValidator = multiplierValidatorValue;
			const sizeValue = this.size();
			if (sizeValue !== void 0) this._elementRef.nativeElement.size = sizeValue;
			const thicknessValue = this.thickness();
			if (thicknessValue !== void 0) this._elementRef.nativeElement.thickness = thicknessValue;
			const invertValue = this.invert();
			if (invertValue !== void 0) this._elementRef.nativeElement.invert = invertValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: SpacerComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: SpacerComponent,
		isStandalone: true,
		selector: "mosaik-spacer",
		inputs: {
			multiplier: {
				classPropertyName: "multiplier",
				publicName: "multiplier",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			multiplierValidator: {
				classPropertyName: "multiplierValidator",
				publicName: "multiplierValidator",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			thickness: {
				classPropertyName: "thickness",
				publicName: "thickness",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			invert: {
				classPropertyName: "invert",
				publicName: "invert",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
SpacerComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-spacer", SpacerElement),
	inputs: [
		"multiplier",
		"multiplierValidator",
		"size",
		"thickness",
		"invert",
		"themeName",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], SpacerComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: SpacerComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-spacer",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		multiplier: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "multiplier",
				required: false
			}]
		}],
		multiplierValidator: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "multiplierValidator",
				required: false
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		thickness: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "thickness",
				required: false
			}]
		}],
		invert: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "invert",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideSpacerComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: SPACER_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { SPACER_DEFAULT_PROPS, SpacerComponent, provideSpacerComponent };

//# sourceMappingURL=mosaik-elements-angular-components-spacer.mjs.map