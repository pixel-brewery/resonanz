import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { MeterBarElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/ranges/meter-bar/MeterBarElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs } from "@pixel-brewery/mosaik-elements-angular/runtime";
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const METER_BAR_DEFAULT_PROPS = new InjectionToken("MOSAIK_METER_BAR_DEFAULT_PROPS");
let MeterBarComponent = class MeterBarComponent {
	thickness = input(...ngDevMode ? [void 0, { debugName: "thickness" }] : /* istanbul ignore next */ []);
	high = input(...ngDevMode ? [void 0, { debugName: "high" }] : /* istanbul ignore next */ []);
	low = input(...ngDevMode ? [void 0, { debugName: "low" }] : /* istanbul ignore next */ []);
	optimum = input(...ngDevMode ? [void 0, { debugName: "optimum" }] : /* istanbul ignore next */ []);
	scale = input(...ngDevMode ? [void 0, { debugName: "scale" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	orientation = input(...ngDevMode ? [void 0, { debugName: "orientation" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	label = input(...ngDevMode ? [void 0, { debugName: "label" }] : /* istanbul ignore next */ []);
	min = input(...ngDevMode ? [void 0, { debugName: "min" }] : /* istanbul ignore next */ []);
	max = input(...ngDevMode ? [void 0, { debugName: "max" }] : /* istanbul ignore next */ []);
	value = input(...ngDevMode ? [void 0, { debugName: "value" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	rangeValueChanged = output();
	changed = output();
	connected = output();
	disconnected = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			rangeValueChanged: this.rangeValueChanged,
			changed: this.changed,
			connected: this.connected,
			disconnected: this.disconnected
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(METER_BAR_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const thicknessValue = this.thickness();
			if (thicknessValue !== void 0) this._elementRef.nativeElement.thickness = thicknessValue;
			const highValue = this.high();
			if (highValue !== void 0) this._elementRef.nativeElement.high = highValue;
			const lowValue = this.low();
			if (lowValue !== void 0) this._elementRef.nativeElement.low = lowValue;
			const optimumValue = this.optimum();
			if (optimumValue !== void 0) this._elementRef.nativeElement.optimum = optimumValue;
			const scaleValue = this.scale();
			if (scaleValue !== void 0) this._elementRef.nativeElement.scale = scaleValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const orientationValue = this.orientation();
			if (orientationValue !== void 0) this._elementRef.nativeElement.orientation = orientationValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const labelValue = this.label();
			if (labelValue !== void 0) this._elementRef.nativeElement.label = labelValue;
			const minValue = this.min();
			if (minValue !== void 0) this._elementRef.nativeElement.min = minValue;
			const maxValue = this.max();
			if (maxValue !== void 0) this._elementRef.nativeElement.max = maxValue;
			const valueValue = this.value();
			if (valueValue !== void 0) this._elementRef.nativeElement.value = valueValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: MeterBarComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: MeterBarComponent,
		isStandalone: true,
		selector: "mosaik-meter-bar",
		inputs: {
			thickness: {
				classPropertyName: "thickness",
				publicName: "thickness",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			high: {
				classPropertyName: "high",
				publicName: "high",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			low: {
				classPropertyName: "low",
				publicName: "low",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			optimum: {
				classPropertyName: "optimum",
				publicName: "optimum",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			scale: {
				classPropertyName: "scale",
				publicName: "scale",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			orientation: {
				classPropertyName: "orientation",
				publicName: "orientation",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			min: {
				classPropertyName: "min",
				publicName: "min",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			max: {
				classPropertyName: "max",
				publicName: "max",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			rangeValueChanged: "rangeValueChanged",
			changed: "changed",
			connected: "connected",
			disconnected: "disconnected"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
MeterBarComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-meter-bar", MeterBarElement),
	inputs: [
		"thickness",
		"high",
		"low",
		"optimum",
		"scale",
		"themeName",
		"variant",
		"orientation",
		"disabled",
		"label",
		"min",
		"max",
		"value",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], MeterBarComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MeterBarComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-meter-bar",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		thickness: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "thickness",
				required: false
			}]
		}],
		high: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "high",
				required: false
			}]
		}],
		low: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "low",
				required: false
			}]
		}],
		optimum: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "optimum",
				required: false
			}]
		}],
		scale: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "scale",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		orientation: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "orientation",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		min: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "min",
				required: false
			}]
		}],
		max: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "max",
				required: false
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		rangeValueChanged: [{
			type: i0.Output,
			args: ["rangeValueChanged"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}]
	}
});
function provideMeterBarComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: METER_BAR_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { METER_BAR_DEFAULT_PROPS, MeterBarComponent, provideMeterBarComponent };

//# sourceMappingURL=mosaik-elements-angular-components-meter-bar.mjs.map