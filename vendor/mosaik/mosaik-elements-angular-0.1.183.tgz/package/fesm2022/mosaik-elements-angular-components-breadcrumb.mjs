import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, ElementRef, InjectionToken, effect, inject, input, makeEnvironmentProviders, output } from "@angular/core";
import { BreadcrumbItemElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/grouping/breadcrumb/BreadcrumbItemElement";
import { ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { BreadcrumbElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/grouping/breadcrumb/BreadcrumbElement";
var __decorate$1 = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata$1 = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const BREADCRUMB_ITEM_DEFAULT_PROPS = new InjectionToken("MOSAIK_BREADCRUMB_ITEM_DEFAULT_PROPS");
let BreadcrumbItemComponent = class BreadcrumbItemComponent {
	hasSeparator = input(...ngDevMode ? [void 0, { debugName: "hasSeparator" }] : /* istanbul ignore next */ []);
	isActive = input(...ngDevMode ? [void 0, { debugName: "isActive" }] : /* istanbul ignore next */ []);
	underline = input(...ngDevMode ? [void 0, { debugName: "underline" }] : /* istanbul ignore next */ []);
	download = input(...ngDevMode ? [void 0, { debugName: "download" }] : /* istanbul ignore next */ []);
	href = input(...ngDevMode ? [void 0, { debugName: "href" }] : /* istanbul ignore next */ []);
	rel = input(...ngDevMode ? [void 0, { debugName: "rel" }] : /* istanbul ignore next */ []);
	target = input(...ngDevMode ? [void 0, { debugName: "target" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	disabled = input(...ngDevMode ? [void 0, { debugName: "disabled" }] : /* istanbul ignore next */ []);
	label = input(...ngDevMode ? [void 0, { debugName: "label" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(BREADCRUMB_ITEM_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const hasSeparatorValue = this.hasSeparator();
			if (hasSeparatorValue !== void 0) this._elementRef.nativeElement.hasSeparator = hasSeparatorValue;
			const isActiveValue = this.isActive();
			if (isActiveValue !== void 0) this._elementRef.nativeElement.isActive = isActiveValue;
			const underlineValue = this.underline();
			if (underlineValue !== void 0) this._elementRef.nativeElement.underline = underlineValue;
			const downloadValue = this.download();
			if (downloadValue !== void 0) this._elementRef.nativeElement.download = downloadValue;
			const hrefValue = this.href();
			if (hrefValue !== void 0) this._elementRef.nativeElement.href = hrefValue;
			const relValue = this.rel();
			if (relValue !== void 0) this._elementRef.nativeElement.rel = relValue;
			const targetValue = this.target();
			if (targetValue !== void 0) this._elementRef.nativeElement.target = targetValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const variantValue = this.variant();
			if (variantValue !== void 0) this._elementRef.nativeElement.variant = variantValue;
			const disabledValue = this.disabled();
			if (disabledValue !== void 0) this._elementRef.nativeElement.disabled = disabledValue;
			const labelValue = this.label();
			if (labelValue !== void 0) this._elementRef.nativeElement.label = labelValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: BreadcrumbItemComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: BreadcrumbItemComponent,
		isStandalone: true,
		selector: "mosaik-breadcrumb-item",
		inputs: {
			hasSeparator: {
				classPropertyName: "hasSeparator",
				publicName: "hasSeparator",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isActive: {
				classPropertyName: "isActive",
				publicName: "isActive",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			underline: {
				classPropertyName: "underline",
				publicName: "underline",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			download: {
				classPropertyName: "download",
				publicName: "download",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			href: {
				classPropertyName: "href",
				publicName: "href",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			rel: {
				classPropertyName: "rel",
				publicName: "rel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			target: {
				classPropertyName: "target",
				publicName: "target",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
BreadcrumbItemComponent = __decorate$1([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-breadcrumb-item", BreadcrumbItemElement),
	inputs: [
		"hasSeparator",
		"isActive",
		"underline",
		"download",
		"href",
		"rel",
		"target",
		"themeName",
		"variant",
		"disabled",
		"label",
		"dir",
		"lang"
	]
}), __metadata$1("design:paramtypes", [])], BreadcrumbItemComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: BreadcrumbItemComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-breadcrumb-item",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		hasSeparator: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hasSeparator",
				required: false
			}]
		}],
		isActive: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isActive",
				required: false
			}]
		}],
		underline: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "underline",
				required: false
			}]
		}],
		download: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "download",
				required: false
			}]
		}],
		href: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "href",
				required: false
			}]
		}],
		rel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "rel",
				required: false
			}]
		}],
		target: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "target",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideBreadcrumbItemComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: BREADCRUMB_ITEM_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
	var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
	if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
	else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
	return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = this && this.__metadata || function(k, v) {
	if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const BREADCRUMB_DEFAULT_PROPS = new InjectionToken("MOSAIK_BREADCRUMB_DEFAULT_PROPS");
let BreadcrumbComponent = class BreadcrumbComponent {
	wrap = input(...ngDevMode ? [void 0, { debugName: "wrap" }] : /* istanbul ignore next */ []);
	themeName = input(...ngDevMode ? [void 0, { debugName: "themeName" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	lang = input(...ngDevMode ? [void 0, { debugName: "lang" }] : /* istanbul ignore next */ []);
	connected = output();
	disconnected = output();
	changed = output();
	_elementRef = inject(ElementRef);
	_destroyRef = inject(DestroyRef);
	_outputSubscriptions = [];
	constructor() {
		inject(ChangeDetectorRef).detach();
		this._outputSubscriptions.push(...forwardProxyOutputs(this._elementRef.nativeElement, {
			connected: this.connected,
			disconnected: this.disconnected,
			changed: this.changed
		}));
		this._destroyRef.onDestroy(() => {
			this._outputSubscriptions.forEach((subscription) => subscription.dispose());
			this._outputSubscriptions.length = 0;
		});
		this.initInputSyncEffect();
		applyDefaults(this._elementRef.nativeElement, inject(BREADCRUMB_DEFAULT_PROPS, { optional: true }) ?? {});
	}
	setInput(property, value) {
		this._elementRef.nativeElement[property] = value;
	}
	initInputSyncEffect() {
		effect(() => {
			const wrapValue = this.wrap();
			if (wrapValue !== void 0) this._elementRef.nativeElement.wrap = wrapValue;
			const themeNameValue = this.themeName();
			if (themeNameValue !== void 0) this._elementRef.nativeElement.themeName = themeNameValue;
			const dirValue = this.dir();
			if (dirValue !== void 0) this._elementRef.nativeElement.dir = dirValue;
			const langValue = this.lang();
			if (langValue !== void 0) this._elementRef.nativeElement.lang = langValue;
		});
	}
	get elementRef() {
		return this._elementRef;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: BreadcrumbComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: BreadcrumbComponent,
		isStandalone: true,
		selector: "mosaik-breadcrumb",
		inputs: {
			wrap: {
				classPropertyName: "wrap",
				publicName: "wrap",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			themeName: {
				classPropertyName: "themeName",
				publicName: "themeName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dir: {
				classPropertyName: "dir",
				publicName: "dir",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lang: {
				classPropertyName: "lang",
				publicName: "lang",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			connected: "connected",
			disconnected: "disconnected",
			changed: "changed"
		},
		ngImport: i0,
		template: "<ng-content></ng-content>",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
BreadcrumbComponent = __decorate([ProxyCmp({
	defineCustomElementFn: () => defineCustomElement("mosaik-breadcrumb", BreadcrumbElement),
	inputs: [
		"wrap",
		"themeName",
		"dir",
		"lang"
	]
}), __metadata("design:paramtypes", [])], BreadcrumbComponent);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: BreadcrumbComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mosaik-breadcrumb",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content></ng-content>"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		wrap: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "wrap",
				required: false
			}]
		}],
		themeName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "themeName",
				required: false
			}]
		}],
		dir: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		lang: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lang",
				required: false
			}]
		}],
		connected: [{
			type: i0.Output,
			args: ["connected"]
		}],
		disconnected: [{
			type: i0.Output,
			args: ["disconnected"]
		}],
		changed: [{
			type: i0.Output,
			args: ["changed"]
		}]
	}
});
function provideBreadcrumbComponent(config) {
	const providers = [];
	if (config) providers.push({
		provide: BREADCRUMB_DEFAULT_PROPS,
		useValue: config
	});
	return makeEnvironmentProviders(providers);
}
export { BREADCRUMB_DEFAULT_PROPS, BREADCRUMB_ITEM_DEFAULT_PROPS, BreadcrumbComponent, BreadcrumbItemComponent, provideBreadcrumbComponent, provideBreadcrumbItemComponent };

//# sourceMappingURL=mosaik-elements-angular-components-breadcrumb.mjs.map