# 📦 @pixel-brewery/mosaik-elements-angular

| Package Status                                                                                                                                          | Source                                                             |
| ------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------ |
| [![GitHub Packages](https://img.shields.io/github/v/release/RueDeRennes/mosaik?label=GitHub%20Packages&logo=github)](https://github.com/orgs/pixel-brewery/packages/npm/package/mosaik-elements-angular) | [libs/mosaik-elements-angular](../../libs/mosaik-elements-angular) |

> Angular bindings for the Mosaik web components.
> Use Mosaik design system components in Angular projects with full type safety and integration.

---

## 📁 Project Structure

Part of the monorepo [`mosaik`](https://github.com/RueDeRennes/mosaik)
Package path: `libs/mosaik-elements-angular`
Version: see [GitHub Packages](https://github.com/orgs/pixel-brewery/packages/npm/package/mosaik-elements-angular)
License: MIT

---

## 📦 Installation

```bash
yarn add @pixel-brewery/mosaik-elements-angular
# or
npm install @pixel-brewery/mosaik-elements-angular
```

---

## 🔧 Usage

```typescript
import { ButtonComponent } from "@pixel-brewery/mosaik-elements-angular";
```

### Outputs

Every component has an output for each event of its element, named like the event. A binding such as
`(pressed)="onPressed($event)"` runs once per event and receives the event's `detail`; events of descendants
and plain DOM events reach it as the DOM delivers them.

Angular binds such a name twice - as DOM listener of the element and as subscriber of the output. The
components forward the events with `forwardProxyOutputs()`, which keeps the DOM listener of a binding from
handling an event the output delivered to it already. That relies on two Angular internals;
`src/utils/Proxy.contract.spec.ts` checks them against the installed Angular version, so an Angular upgrade
that changes them fails the tests.

### Calling methods

Every component declares the public methods of its element, with the parameters and the
return type the element declares for them:

```typescript
private readonly _dialog = viewChild.required(DialogComponent);

public async open(): Promise<void> {
    await this._dialog().open();
}
```

The signatures are reflected from the element class (`Parameters<DialogElement['open']>`), so
they follow the element. Generic methods such as `getSlotAssignmentsOf` keep their type
parameters. A method that shares its name with an output of the component, like `focus` on
`NumberBoxComponent`, is called on `elementRef.nativeElement`.

`invoke('open')` still works, but is deprecated in favor of the typed methods.

### Charts (separate entry)

```typescript
import { ChartComponent, ChartToolboxComponent } from '@pixel-brewery/mosaik-elements-angular/components/chart';
```

Install the optional `apexcharts` peer (`yarn add apexcharts`) when using charts.
The main entry excludes charts, the toolbox and ApexCharts. Move existing chart imports
from the main package to `components/chart`. The Foundation entry also exports chart
props, display/legend/stack options, interaction types, events and localization.

## Signature Pad (separate entry)

Import the signature pad explicitly when collecting handwritten signatures:

```typescript
import { SignaturePadComponent } from '@pixel-brewery/mosaik-elements-angular/components/signature-pad';
```

Install the optional `signature_pad` peer (`yarn add signature_pad`) when using this component.
The main package entry excludes the signature pad and its signing library. Existing imports of this
component from the main entry must move to `components/signature-pad`. The Foundation entry also
exports its value accessor, props and signing event types.

### Code editor (secondary entry point)

`mosaik-code-editor` - the CodeMirror 6 editor of the foundation - is **not** part of the main entry, so an
application that never imports it never bundles CodeMirror. Import it from the `components/code-editor` secondary entry point:

```typescript
import { CodeEditorComponent, provideCodeEditorComponent } from '@pixel-brewery/mosaik-elements-angular/components/code-editor';
```

`CodeEditorComponent` is a standalone component with a `ControlValueAccessor`, so it takes part in reactive and
template-driven forms like the other inputs (validation state included):

```typescript
@Component({
    imports: [CodeEditorComponent, ReactiveFormsModule],
    template: `<mosaik-code-editor [formControl]="script" language="typescript" [toolbar]="true" [statusBar]="true" />`
})
export class ScriptEditorComponent {
    protected readonly script = new FormControl('', { nonNullable: true, validators: Validators.required });
}
```

`provideCodeEditorComponent(defaults, intl)` provides default properties (`CODE_EDITOR_DEFAULT_PROPS`) and labels
(`CODE_EDITOR_INTL`, a partial `CodeEditorElementIntl` or a class that resolves them) for every editor below it:

```typescript
providers: [provideCodeEditorComponent({ lineWrapping: true, tooltipPosition: 'fixed' }, { copyLabel: 'Copy code' })]
```

Languages, completions, linting and formatting come from the foundation entry of the editor, e.g.
`createPlaceholderCompletions`, `createPrettierFormatter` and `CodeEditorLanguages` from
`@pixel-brewery/mosaik-elements-foundation/components/code-editor`. The CodeMirror packages and `prettier` are optional peer
dependencies (of this package and of the foundation): install them when you use the editor. Grammars and Prettier
load on demand, but a bundler resolves them when it builds the application, so install all of them:

```bash
yarn add @codemirror/autocomplete @codemirror/commands @codemirror/language @codemirror/lint @codemirror/search \
    @codemirror/state @codemirror/view @lezer/highlight @codemirror/lang-angular @codemirror/lang-css \
    @codemirror/lang-html @codemirror/lang-javascript @codemirror/lang-json @codemirror/lang-sass \
    @codemirror/lang-vue @codemirror/lang-xml @codemirror/lang-yaml @replit/codemirror-lang-svelte prettier
```

The wrapper generator (`_manifest:ng`, option `subpaths`) writes such secondary entry points into a folder of their
own beside `src/` (`components/code-editor/`, with its `ng-package.json`); the main entry exports the runtime of the generated
components (`ProxyCmp`, `applyDefaults`, ...) for them.

### Component entry points

Every other component has a secondary entry point of its own in the same folder, `components/<name>` (e.g.
`@pixel-brewery/mosaik-elements-angular/components/button`, `components/error-state`; option `componentEntryRoot`).
ng-packagr bundles each entry point into one module, so these entry points are what keep an application to the
components (and Foundation elements) it imports. The main entry re-exports all of them; importing from it keeps working.

```ts
import { ButtonComponent } from '@pixel-brewery/mosaik-elements-angular/components/button';
```

### Scheduler event preview templates

Import `SchedulerEventPopupDirective` alongside `SchedulerEventComponent` to
replace the hover preview with an Angular template. Bind the data explicitly so
Angular infers the type of `let-item`; `let-event="event"` exposes the native event.

```html
<mosaik-scheduler-event [value]="appointment">
  <ng-template [mosaikSchedulerEventPopup]="appointment" let-item let-event="event">
    <mosaik-card>
      <mosaik-card-header [text]="item.title" />
      <mosaik-card-content>
        @for (member of item.members; track member.id) {
          <mosaik-persona [primaryText]="member.name" />
        }
      </mosaik-card-content>
    </mosaik-card>
  </ng-template>
</mosaik-scheduler-event>
```

The application controls the content, hierarchy and layout. Mosaik retains the
existing hover trigger, placement, flipping and portal. This is a hover preview;
adding a template does not change it into an interactive menu.

The directive creates an `EmbeddedViewRef` only when the popup opens. Bindings
and repeated children stay live while open, including replacement of the bound
data. All template root nodes are contained in one stable projection root;
Angular owns changes below that root. Closing, replacing or removing the preview
releases the view, so reopening renders current data without retaining detached
components or subscriptions.

Foundation exposes the programmatic `popupTemplate(event)` factory. It returns
`{ content: HTMLElement, destroy(): void }`; the popup projects that exact node,
without cloning, and calls cleanup on close, replacement or disconnect. The
factory takes precedence over the static `popup` slot. Without a factory, the
existing static slot and default title/time preview retain their behavior.

Scheduler previews are bounded by the visible view body below the day headers
and all-day strip. All-day previews use the same large viewport as timed events.
Scrolling or resizing repositions the existing portal; oversized content scrolls
inside its constrained preview. For other popup consumers, the optional native
`PopupElement.boundary` input applies the same placement, two-axis shifting and
size constraint. Its default is `null`, preserving existing popup behavior.

### Toast priority

Toasts opened through `ToastService.show` occupy the reserved toast layer. They remain
above drawers, dialogs, message boxes, sheets and their backdrops, regardless of which
overlay opens first. No application-level CDK container or pane override is required.
With CDK's native popover rendering, opening another overlay promotes existing toast
hosts in their original order in the browser's top layer. Native overlays opened outside
the Mosaik services are observed through `beforetoggle` and followed by one coalesced
animation-frame callback, after the native opening operation and before the next paint.
The current focused control is preserved, and the toast portal and timeout lifecycle stay
attached. With `usePopover: false`, the complete CDK host and its optional backdrop occupy
a dedicated sibling overlay container, above ordinary Foundation portals as well as CDK
overlays. Detaching the toast removes that container; the last toast also releases native
event observation and any pending callback.

Newer toasts appear above older toasts; `withToastStackBehavior` continues to control
their positions, depth and expansion.

A click inside a toast does not dismiss a drawer behind it. Toasts remain non-modal
status messages and do not acquire focus or disable the active dialog or drawer focus
trap. Existing Escape and outside-click arbitration retains the opening order, so the
visual toast layer does not take keyboard control away from a later modal overlay.

### Escape in overlays

Escape closes only the topmost drawer, dialog, message box or sheet. While a popup of its
content is open, such as the list of a combo or select, a date picker or a popup menu, that
popup takes Escape first and closes only itself: the overlay neither closes nor emits a
close attempt, and the control keeps its value. The next Escape reaches the overlay again.

### Guided tours

Provide complete tour definitions at the owning Angular feature boundary. Definition
factories are resolved lazily in Angular's injection context, so translated text and
other injectable configuration can remain feature-owned.

```typescript
import { inject } from "@angular/core";
import { Variant } from "@pixel-brewery/mosaik-elements-foundation";
import {
  provideTours,
  TranslateService,
} from "@pixel-brewery/mosaik-elements-angular";

export const newsletterProviders = [
  provideTours(() => {
    const translate = inject(TranslateService);

    return {
      id: "newsletter-editor",
      showAutoAdvanceControls: true,
      labels: {
        next: translate.translate("tour.next"),
        previous: translate.translate("tour.previous"),
        finish: translate.translate("tour.finish"),
        skip: translate.translate("tour.skip"),
        progress: translate.translate("tour.progress"),
        pause: translate.translate("tour.pause"),
        resume: translate.translate("tour.resume"),
      },
      steps: [
        {
          id: "subject",
          anchorId: "subject",
          route: "/newsletters/new",
          title: translate.translate("tour.subject.title"),
          content: translate.translate("tour.subject.content"),
          variant: Variant.Info,
          formatter: "richtext",
          duration: 5_000,
          interactionMode: "anchor",
          anchorWaitTimeout: 2_500,
          scrollBehavior: "smooth",
          scrollBlock: "center",
          scrollTimeout: 2_000,
        },
      ],
    };
  }),
];
```

Mark existing UI without introducing wrapper elements, and place the start directive
on any clickable host. The start listener runs in the capture phase so it also works
with command controls that intentionally stop click propagation.

```html
<mosaik-form-field mosaikTourAnchor="subject" mosaikTourId="newsletter-editor">
  <!-- Existing field -->
</mosaik-form-field>

<button mosaikTourStart="newsletter-editor">Start tour</button>
```

`TourService` additionally exposes `start`, `showStep`, `next`, `previous`,
`pauseAutoAdvance`, `resumeAutoAdvance`, `finish`, `skip`, and `end` for orchestrated
flows, plus signals for the active tour, active step, and latest failure. Steps support placement, optional or asynchronously rendered
anchors, controlled scrolling, per-step label overrides, a semantic `variant`, and an optional `duration`
in milliseconds. A positive duration advances automatically after the fully positioned
step has been shown; the last timed step finishes the tour. Untimed steps remain manual.
Set `showAutoAdvanceControls` on the complete definition to expose one compact,
accessible Play/Pause action on timed guide cards. A user pause survives manual
previous/next navigation; resuming continues from the currently visible step.
Configured exit and enter animations also bracket every successful step change: the
current card exits completely before the next card is positioned and enters.

Set a step's `variant` to `primary`, `secondary`, `tertiary`, `info`, `warning`,
`danger`, `success`, `neutral`, or `highlight` to color the complete guide card.
The card always uses that theme palette's 500 shade with the same contrast
foreground mapping as a solid Mosaik chip. `mosaik-tour-step` deliberately exposes
`Variantable` only; it has no appearance axis.

Set `formatter: 'richtext'` to render structured help through Mosaik's conversational
rich-text formatter. It supports `*bold*`, `_italic_`, `++underline++`,
`+++double underline+++`, `~strikethrough~`, lists, quotations, code, colors, and links.
Use emphasis selectively for field names, choices, consequences, and warnings instead
of formatting complete paragraphs. `interactionMode: 'anchor'` keeps the highlighted control operable even with
a backdrop; pointer, input, or change interaction on a timed step pauses automatic
progress when its controls are enabled.

Angular route changes are declarative per step. When `route` differs from the active
URL, the current card first completes its exit animation, `TourService` navigates with
Angular Router, and the native tour then waits up to `anchorWaitTimeout` for the target
view to register its anchor. Only after that does it scroll, position, and play the new
card's enter animation. A failed navigation emits `step-activation-failed`; a missing
required anchor emits `anchor-missing`. User-initiated navigation ends an active tour
with reason `navigation` by default. Set `allowUserInitiatedNavigation: true` on the
definition only when the application deliberately keeps the tour valid across such a
navigation.

Scrolling runs only when the complete anchor is outside the viewport or one of its
clipping scroll containers. A nested anchor first moves only its nearest owning scroll
container; the viewport is touched with `nearest` alignment only when that result is
still off-screen. `scrollBehavior: 'smooth'` observes only the scroll target currently
being moved, confirms an idle period after its `scroll` or `scrollend` notification,
and remains bounded by `scrollTimeout`. The Angular service mounts the guide in the
initial anchor's portal scope, keeping guide focus inside an enclosing overlay focus
trap and preventing focus recapture from undoing the completed scroll. When a later
step resolves an anchor inside another portal scope, for example a drawer or dialog
that a step action opened, the guide moves into that scope before the step renders,
re-attaches its behaviors there, and continues without ending: it stays above the new
overlay and inside its focus trap, and it moves back when a later anchor lives in the
original scope again. The enter animation therefore never races or reverses the
moving page.
Reduced-motion preferences automatically replace smooth scrolling with immediate
scrolling. Use `scrollBlock`, `scrollInline`, or `disableScrollToAnchor` for per-step
control.

Steps can perform declarative `click` and `fill` actions through `enterActions` or
`advanceActions`. Use a click action for an actual command such as adding a dynamic
row. Use a fill action for text boxes, selects, combos, or any other value control;
the control kind does not require a separate action type. `skipIfAnchorExists` makes
an action conditional and is re-evaluated when users navigate backwards and forwards.

Reusable Angular components expose dynamic controls through the signal-only
`ITourAccessor` contract. The component provides `TOUR_ACCESSOR` and a signal map of
stable target keys. A target contains a signal for its current element, optionally a
signal resolving the real writable model signal, and optionally a component-owned
click capability. It never receives feature tour ids, anchor names, or tour directives.
The owning feature maps those keys declaratively on the component host:

```html
<feature-compound
  [mosaikTourAccessor]="{
        add: tourAnchors.contactAdd,
        activeItem: tourAnchors.contactValue
    }"
  [mosaikTourId]="tourId"
/>
```

`TourAccessorDirective` reacts when a dynamic target appears, disappears, or is
replaced. Fill actions call `WritableSignal.set()` on the component's real Signal
Forms value. There are no `registerOnChange`, `writeValue`, synthetic input events,
or callback-based ControlValueAccessor bridges in this API.

### Build Steps

1. Run `nx run mosaik-elements-angular:build:manifest` to generate the manifest files from 'mosaik-elements' library.
2. Run `nx run mosaik-elements-angular:build:manifest:ng` to generate all Angular components.
3. Run `nx run mosaik-elements-angular:build` to build the library.

---

## ⚙️ Features

- Angular wrappers for all Mosaik web components
- TypeScript types and Angular modules
- Automatic manifest and proxy generation

---

## 🛠 Recommendations

- Use with the main `mosaik-elements` package for full design system support.
- Integrate into Angular CLI or Nx workspace.

---

## 📦 Publishing

```bash
yarn nx run mosaik-elements-angular:publish
```

---

## 📄 License

MIT © Pixel Brewery

---
