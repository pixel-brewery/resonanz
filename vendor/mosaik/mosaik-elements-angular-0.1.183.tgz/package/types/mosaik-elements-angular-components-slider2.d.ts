import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { Slider2ThumbElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/ranges/slider2/Slider2ThumbElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { Slider2Element } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/ranges/slider2/Slider2Element";
/**
 * @public
 *
 * Injection token for the default properties of the Slider2ThumbComponent.
 * Use this token to provide default properties for the Slider2ThumbComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const SLIDER2THUMB_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/ranges/slider2/ISlider2ThumbElementProps").ISlider2ThumbElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class Slider2ThumbComponent {
  /**
   * Signal input for the `step` property.
   *
   * @public
   */
  readonly step: InputSignal<Slider2ThumbElement['step'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<Slider2ThumbElement['themeName'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<Slider2ThumbElement['disabled'] | undefined>;
  /**
   * Signal input for the `isFocused` property.
   *
   * @public
   */
  readonly isFocused: InputSignal<Slider2ThumbElement['isFocused'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<Slider2ThumbElement['variant'] | undefined>;
  /**
   * Signal input for the `min` property.
   *
   * @public
   */
  readonly min: InputSignal<Slider2ThumbElement['min'] | undefined>;
  /**
   * Signal input for the `max` property.
   *
   * @public
   */
  readonly max: InputSignal<Slider2ThumbElement['max'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<Slider2ThumbElement['value'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<Slider2ThumbElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<Slider2ThumbElement['lang'] | undefined>;
  /**
   * Output signal for the `rangeValueChanged` event.
   *
   * @public
   */
  readonly rangeValueChanged: OutputEmitterRef<ElementEventDetail<Slider2ThumbElement, 'rangeValueChanged'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<Slider2ThumbElement, 'changed'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<Slider2ThumbElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<Slider2ThumbElement, 'disconnected'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof Slider2ThumbElement>(property: TProperty, value: Slider2ThumbElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<Slider2ThumbElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<Slider2ThumbComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<Slider2ThumbComponent, "mosaik-slider2-thumb", never, {
    "step": {
      "alias": "step";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "isFocused": {
      "alias": "isFocused";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "min": {
      "alias": "min";
      "required": false;
      "isSignal": true;
    };
    "max": {
      "alias": "max";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "rangeValueChanged": "rangeValueChanged";
    "changed": "changed";
    "connected": "connected";
    "disconnected": "disconnected";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on Slider2ThumbComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type Slider2ThumbMethodNames = never;
/**
 * Declares the methods interface for Slider2ThumbComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type Slider2ThumbComponentMethods = MethodMap<Slider2ThumbMethodNames>;
/**
 * @public
 */
export declare function provideSlider2ThumbComponent(config?: Partial<Slider2ThumbElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the Slider2Component.
 * Use this token to provide default properties for the Slider2Component.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const SLIDER2_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/ranges/slider2/ISlider2ElementProps").ISlider2ElementProps>>;
/**
 * @public
 *
 * @slot thumb - Slot for one or more Slider2Thumb elements representing draggable handles
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class Slider2Component {
  /**
   * Signal input for the `thickness` property.
   *
   * @public
   */
  readonly thickness: InputSignal<Slider2Element['thickness'] | undefined>;
  /**
   * Signal input for the `step` property.
   *
   * @public
   */
  readonly step: InputSignal<Slider2Element['step'] | undefined>;
  /**
   * Signal input for the `gap` property.
   *
   * @public
   */
  readonly gap: InputSignal<Slider2Element['gap'] | undefined>;
  /**
   * Signal input for the `showValueIndicator` property.
   *
   * @public
   */
  readonly showValueIndicator: InputSignal<Slider2Element['showValueIndicator'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<Slider2Element['themeName'] | undefined>;
  /**
   * Signal input for the `orientation` property.
   *
   * @public
   */
  readonly orientation: InputSignal<Slider2Element['orientation'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<Slider2Element['disabled'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<Slider2Element['variant'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<Slider2Element['appearance'] | undefined>;
  /**
   * Signal input for the `min` property.
   *
   * @public
   */
  readonly min: InputSignal<Slider2Element['min'] | undefined>;
  /**
   * Signal input for the `max` property.
   *
   * @public
   */
  readonly max: InputSignal<Slider2Element['max'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<Slider2Element['value'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<Slider2Element['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<Slider2Element['lang'] | undefined>;
  /**
   * Output signal for the `rangeValueChanged` event.
   *
   * @public
   */
  readonly rangeValueChanged: OutputEmitterRef<ElementEventDetail<Slider2Element, 'rangeValueChanged'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<Slider2Element, 'changed'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<Slider2Element, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<Slider2Element, 'disconnected'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: Slider2Element['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: Slider2Element['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Called when the slot changes.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<Slider2Element['onSlotChanges']>): ReturnType<Slider2Element['onSlotChanges']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   * @param args - The arguments of `assignToSlot`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * - `node` - The nodes to assign to the slot.
   */
  assignToSlot(...args: Parameters<Slider2Element['assignToSlot']>): ReturnType<Slider2Element['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   * This method extracts text content recursively, including from Shadow DOMs
   * and Custom Elements with known text properties (like `mosaik-text`).
   *
   * @public
   * @param args - The arguments of `getSlotContent`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<Slider2Element['getSlotContent']>): ReturnType<Slider2Element['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @param args - The arguments of `hasSlotContent`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<Slider2Element['hasSlotContent']>): ReturnType<Slider2Element['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @param args - The arguments of `hasSlot`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<Slider2Element['hasSlot']>): ReturnType<Slider2Element['hasSlot']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `onSlotChanges()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends Slider2MethodNames>(method: TMethod, ...args: Parameters<Slider2ComponentMethods[TMethod]>): ReturnType<Slider2ComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof Slider2Element>(property: TProperty, value: Slider2Element[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<Slider2Element>;
  static ɵfac: i0.ɵɵFactoryDeclaration<Slider2Component, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<Slider2Component, "mosaik-slider2", never, {
    "thickness": {
      "alias": "thickness";
      "required": false;
      "isSignal": true;
    };
    "step": {
      "alias": "step";
      "required": false;
      "isSignal": true;
    };
    "gap": {
      "alias": "gap";
      "required": false;
      "isSignal": true;
    };
    "showValueIndicator": {
      "alias": "showValueIndicator";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "orientation": {
      "alias": "orientation";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "min": {
      "alias": "min";
      "required": false;
      "isSignal": true;
    };
    "max": {
      "alias": "max";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "rangeValueChanged": "rangeValueChanged";
    "changed": "changed";
    "connected": "connected";
    "disconnected": "disconnected";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on Slider2Component.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type Slider2MethodNames = 'onSlotChanges' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot';
/**
 * Declares the methods interface for Slider2Component.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type Slider2ComponentMethods = MethodMap<Slider2MethodNames>;
/**
 * @public
 */
export declare function provideSlider2Component(config?: Partial<Slider2Element.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-slider2.d.ts.map