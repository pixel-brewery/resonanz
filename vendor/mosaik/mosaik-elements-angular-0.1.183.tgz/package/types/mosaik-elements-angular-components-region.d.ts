import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { RegionViewElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/grouping/region/RegionViewElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { RegionElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/grouping/region/RegionElement";
/**
 * @public
 *
 * Injection token for the default properties of the RegionViewComponent.
 * Use this token to provide default properties for the RegionViewComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const REGION_VIEW_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/grouping/region/IRegionViewElementProps2").IRegionViewElementProps>>;
/**
 * @public
 *
 * @slot  - The content to be rendered when this view becomes active in its parent region
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class RegionViewComponent {
  /**
   * Signal input for the `name` property.
   *
   * @public
   */
  readonly name: InputSignal<RegionViewElement['name'] | undefined>;
  /**
   * Signal input for the `default` property.
   *
   * @public
   */
  readonly default: InputSignal<RegionViewElement['default'] | undefined>;
  /**
   * Signal input for the `active` property.
   *
   * @public
   */
  readonly active: InputSignal<RegionViewElement['active'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<RegionViewElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<RegionViewElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<RegionViewElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<RegionViewElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<RegionViewElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<RegionViewElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof RegionViewElement>(property: TProperty, value: RegionViewElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<RegionViewElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<RegionViewComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<RegionViewComponent, "mosaik-region-view", never, {
    "name": {
      "alias": "name";
      "required": false;
      "isSignal": true;
    };
    "default": {
      "alias": "default";
      "required": false;
      "isSignal": true;
    };
    "active": {
      "alias": "active";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on RegionViewComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type RegionViewMethodNames = never;
/**
 * Declares the methods interface for RegionViewComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type RegionViewComponentMethods = MethodMap<RegionViewMethodNames>;
/**
 * @public
 */
export declare function provideRegionViewComponent(config?: Partial<RegionViewElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the RegionComponent.
 * Use this token to provide default properties for the RegionComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const REGION_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/grouping/region/IRegionElementProps").IRegionElementProps>>;
/**
 * @public
 *
 * @slot  - Contains mosaik-region-view definitions to be managed by the region
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class RegionComponent {
  /**
   * Signal input for the `active` property.
   *
   * @public
   */
  readonly active: InputSignal<RegionElement['active'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<RegionElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<RegionElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<RegionElement['lang'] | undefined>;
  /**
   * Output signal for the `activeChanged` event.
   *
   * @public
   */
  readonly activeChanged: OutputEmitterRef<ElementEventDetail<RegionElement, 'activeChanged'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<RegionElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<RegionElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<RegionElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Activates a view by name.
   *
   * @public
   * @param args - The arguments of `activate`:
   * - `name` - The name of the view to activate
   */
  activate(...args: Parameters<RegionElement['activate']>): ReturnType<RegionElement['activate']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `activate()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends RegionMethodNames>(method: TMethod, ...args: Parameters<RegionComponentMethods[TMethod]>): ReturnType<RegionComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof RegionElement>(property: TProperty, value: RegionElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<RegionElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<RegionComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<RegionComponent, "mosaik-region", never, {
    "active": {
      "alias": "active";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "activeChanged": "activeChanged";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on RegionComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type RegionMethodNames = 'activate';
/**
 * Declares the methods interface for RegionComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type RegionComponentMethods = MethodMap<RegionMethodNames>;
/**
 * @public
 */
export declare function provideRegionComponent(config?: Partial<RegionElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-region.d.ts.map