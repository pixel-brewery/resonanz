import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { BusyStateElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/states/busy/BusyStateElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the BusyStateComponent.
 * Use this token to provide default properties for the BusyStateComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const BUSY_STATE_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/states/busy/IBusyStateElementProps").IBusyStateElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot.
 * @slot actions - Action buttons or controls available during loading (e.g., cancel operation, dismiss)
 * @slot header - The header slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class BusyStateComponent {
  /**
   * Signal input for the `icon` property.
   *
   * @public
   */
  readonly icon: InputSignal<BusyStateElement['icon'] | undefined>;
  /**
   * Signal input for the `header` property.
   *
   * @public
   */
  readonly header: InputSignal<BusyStateElement['header'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<BusyStateElement['themeName'] | undefined>;
  /**
   * Signal input for the `content` property.
   *
   * @public
   */
  readonly content: InputSignal<BusyStateElement['content'] | undefined>;
  /**
   * Signal input for the `formatter` property.
   *
   * @public
   */
  readonly formatter: InputSignal<BusyStateElement['formatter'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<BusyStateElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<BusyStateElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<BusyStateElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<BusyStateElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<BusyStateElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: BusyStateElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: BusyStateElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<BusyStateElement['assignToSlot']>): ReturnType<BusyStateElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<BusyStateElement['getSlotContent']>): ReturnType<BusyStateElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<BusyStateElement['hasSlotContent']>): ReturnType<BusyStateElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<BusyStateElement['hasSlot']>): ReturnType<BusyStateElement['hasSlot']>;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<BusyStateElement['onSlotChanges']>): ReturnType<BusyStateElement['onSlotChanges']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `assignToSlot()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends BusyStateMethodNames>(method: TMethod, ...args: Parameters<BusyStateComponentMethods[TMethod]>): ReturnType<BusyStateComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof BusyStateElement>(property: TProperty, value: BusyStateElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<BusyStateElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<BusyStateComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<BusyStateComponent, "mosaik-busy-state", never, {
    "icon": {
      "alias": "icon";
      "required": false;
      "isSignal": true;
    };
    "header": {
      "alias": "header";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "content": {
      "alias": "content";
      "required": false;
      "isSignal": true;
    };
    "formatter": {
      "alias": "formatter";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on BusyStateComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type BusyStateMethodNames = 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges';
/**
 * Declares the methods interface for BusyStateComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type BusyStateComponentMethods = MethodMap<BusyStateMethodNames>;
/**
 * @public
 */
export declare function provideBusyStateComponent(config?: Partial<BusyStateElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-busy.d.ts.map