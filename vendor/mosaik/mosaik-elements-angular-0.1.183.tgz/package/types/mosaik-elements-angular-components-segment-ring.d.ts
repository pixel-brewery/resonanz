import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { SegmentRingItemElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/ranges/segment-ring/SegmentRingItemElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { SegmentRingElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/ranges/segment-ring/SegmentRingElement";
/**
 * @public
 *
 * Injection token for the default properties of the SegmentRingItemComponent.
 * Use this token to provide default properties for the SegmentRingItemComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const SEGMENT_RING_ITEM_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/ranges/segment-ring/ISegmentRingItemElementProps").ISegmentRingItemElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class SegmentRingItemComponent {
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<SegmentRingItemElement['value'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<SegmentRingItemElement['variant'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<SegmentRingItemElement['label'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<SegmentRingItemElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<SegmentRingItemElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<SegmentRingItemElement, 'connected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<SegmentRingItemElement, 'changed'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<SegmentRingItemElement, 'disconnected'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof SegmentRingItemElement>(property: TProperty, value: SegmentRingItemElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<SegmentRingItemElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SegmentRingItemComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SegmentRingItemComponent, "mosaik-segment-ring-item", never, {
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "changed": "changed";
    "disconnected": "disconnected";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on SegmentRingItemComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SegmentRingItemMethodNames = never;
/**
 * Declares the methods interface for SegmentRingItemComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SegmentRingItemComponentMethods = MethodMap<SegmentRingItemMethodNames>;
/**
 * @public
 */
export declare function provideSegmentRingItemComponent(config?: Partial<SegmentRingItemElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the SegmentRingComponent.
 * Use this token to provide default properties for the SegmentRingComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const SEGMENT_RING_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/ranges/segment-ring/ISegmentRingElementProps").ISegmentRingElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot for segment items (mosaik-segment-ring-item elements)
 * @slot hint - Secondary text content area for additional information or status
 * @slot label - Text label content area for the ring description
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class SegmentRingComponent {
  /**
   * Signal input for the `thickness` property.
   *
   * @public
   */
  readonly thickness: InputSignal<SegmentRingElement['thickness'] | undefined>;
  /**
   * Signal input for the `radius` property.
   *
   * @public
   */
  readonly radius: InputSignal<SegmentRingElement['radius'] | undefined>;
  /**
   * Signal input for the `segmentGap` property.
   *
   * @public
   */
  readonly segmentGap: InputSignal<SegmentRingElement['segmentGap'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<SegmentRingElement['themeName'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<SegmentRingElement['variant'] | undefined>;
  /**
   * Signal input for the `orientation` property.
   *
   * @public
   */
  readonly orientation: InputSignal<SegmentRingElement['orientation'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<SegmentRingElement['disabled'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<SegmentRingElement['label'] | undefined>;
  /**
   * Signal input for the `min` property.
   *
   * @public
   */
  readonly min: InputSignal<SegmentRingElement['min'] | undefined>;
  /**
   * Signal input for the `max` property.
   *
   * @public
   */
  readonly max: InputSignal<SegmentRingElement['max'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<SegmentRingElement['value'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<SegmentRingElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<SegmentRingElement['lang'] | undefined>;
  /**
   * Output signal for the `rangeValueChanged` event.
   *
   * @public
   */
  readonly rangeValueChanged: OutputEmitterRef<ElementEventDetail<SegmentRingElement, 'rangeValueChanged'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<SegmentRingElement, 'changed'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<SegmentRingElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<SegmentRingElement, 'disconnected'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: SegmentRingElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: SegmentRingElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Called when the slot changes.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<SegmentRingElement['onSlotChanges']>): ReturnType<SegmentRingElement['onSlotChanges']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   * @param args - The arguments of `assignToSlot`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * - `node` - The nodes to assign to the slot.
   */
  assignToSlot(...args: Parameters<SegmentRingElement['assignToSlot']>): ReturnType<SegmentRingElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   * This method extracts text content recursively, including from Shadow DOMs
   * and Custom Elements with known text properties (like `mosaik-text`).
   *
   * @public
   * @param args - The arguments of `getSlotContent`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<SegmentRingElement['getSlotContent']>): ReturnType<SegmentRingElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @param args - The arguments of `hasSlotContent`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<SegmentRingElement['hasSlotContent']>): ReturnType<SegmentRingElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @param args - The arguments of `hasSlot`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<SegmentRingElement['hasSlot']>): ReturnType<SegmentRingElement['hasSlot']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `onSlotChanges()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends SegmentRingMethodNames>(method: TMethod, ...args: Parameters<SegmentRingComponentMethods[TMethod]>): ReturnType<SegmentRingComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof SegmentRingElement>(property: TProperty, value: SegmentRingElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<SegmentRingElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SegmentRingComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SegmentRingComponent, "mosaik-segment-ring", never, {
    "thickness": {
      "alias": "thickness";
      "required": false;
      "isSignal": true;
    };
    "radius": {
      "alias": "radius";
      "required": false;
      "isSignal": true;
    };
    "segmentGap": {
      "alias": "segmentGap";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "orientation": {
      "alias": "orientation";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "min": {
      "alias": "min";
      "required": false;
      "isSignal": true;
    };
    "max": {
      "alias": "max";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "rangeValueChanged": "rangeValueChanged";
    "changed": "changed";
    "connected": "connected";
    "disconnected": "disconnected";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on SegmentRingComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SegmentRingMethodNames = 'onSlotChanges' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot';
/**
 * Declares the methods interface for SegmentRingComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SegmentRingComponentMethods = MethodMap<SegmentRingMethodNames>;
/**
 * @public
 */
export declare function provideSegmentRingComponent(config?: Partial<SegmentRingElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-segment-ring.d.ts.map