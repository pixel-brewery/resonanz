import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { ChoiceGroupHeaderElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/choice/ChoiceGroupHeaderElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import * as i1 from "@pixel-brewery/mosaik-elements-angular/runtime";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { ControlValueAccessor } from "@angular/forms";
import { ChoiceGroupElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/choice/ChoiceGroupElement";
import { ChoiceElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/choice/ChoiceElement";
/**
 * @public
 *
 * Injection token for the default properties of the ChoiceGroupHeaderComponent.
 * Use this token to provide default properties for the ChoiceGroupHeaderComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const CHOICE_GROUP_HEADER_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/inputs/choice/IChoiceGroupHeaderElementProps").IChoiceGroupHeaderElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot for header content (text, icons, or custom markup)
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ChoiceGroupHeaderComponent {
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ChoiceGroupHeaderElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ChoiceGroupHeaderElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ChoiceGroupHeaderElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ChoiceGroupHeaderElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ChoiceGroupHeaderElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ChoiceGroupHeaderElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ChoiceGroupHeaderElement>(property: TProperty, value: ChoiceGroupHeaderElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ChoiceGroupHeaderElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ChoiceGroupHeaderComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ChoiceGroupHeaderComponent, "mosaik-choice-group-header", never, {
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on ChoiceGroupHeaderComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ChoiceGroupHeaderMethodNames = never;
/**
 * Declares the methods interface for ChoiceGroupHeaderComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ChoiceGroupHeaderComponentMethods = MethodMap<ChoiceGroupHeaderMethodNames>;
/**
 * @public
 */
export declare function provideChoiceGroupHeaderComponent(config?: Partial<ChoiceGroupHeaderElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the ChoiceGroupComponent.
 * Use this token to provide default properties for the ChoiceGroupComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const CHOICE_GROUP_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/inputs/choice/IChoiceGroupElementProps").IChoiceGroupElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot.
 * @slot error - The error slot.
 * @slot header - The header slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ChoiceGroupComponent implements ControlValueAccessor {
  /**
   * Signal input for the `name` property.
   *
   * @public
   */
  readonly name: InputSignal<ChoiceGroupElement['name'] | undefined>;
  /**
   * Signal input for the `required` property.
   *
   * @public
   */
  readonly required: InputSignal<ChoiceGroupElement['required'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ChoiceGroupElement['themeName'] | undefined>;
  /**
   * Signal input for the `orientation` property.
   *
   * @public
   */
  readonly orientation: InputSignal<ChoiceGroupElement['orientation'] | undefined>;
  /**
   * Signal input for the `invalid` property.
   *
   * @public
   */
  readonly invalid: InputSignal<ChoiceGroupElement['invalid'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<ChoiceGroupElement['value'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<ChoiceGroupElement['disabled'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<ChoiceGroupElement['appearance'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<ChoiceGroupElement['variant'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ChoiceGroupElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ChoiceGroupElement['lang'] | undefined>;
  /**
   * Output signal for the `choiceChanged` event.
   *
   * @public
   */
  readonly choiceChanged: OutputEmitterRef<ElementEventDetail<ChoiceGroupElement, 'choiceChanged'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ChoiceGroupElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ChoiceGroupElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ChoiceGroupElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: ChoiceGroupElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: ChoiceGroupElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  private readonly _accessor;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Applies a value supplied by Angular forms to the native control.
   *
   * @public
   */
  writeValue(obj: unknown): void;
  /**
   * Registers the callback notified when the native control value changes.
   *
   * @public
   */
  registerOnChange(fn: unknown): void;
  /**
   * Registers the callback notified when the native control is touched.
   *
   * @public
   */
  registerOnTouched(fn: unknown): void;
  /**
   * Applies the disabled state supplied by Angular forms.
   *
   * @public
   */
  setDisabledState?(isDisabled: boolean): void;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<ChoiceGroupElement['onSlotChanges']>): ReturnType<ChoiceGroupElement['onSlotChanges']>;
  /**
   * Returns whether a form will validate when it is submitted, without having to submit it.
   *
   * @public
   */
  checkValidity(...args: Parameters<ChoiceGroupElement['checkValidity']>): ReturnType<ChoiceGroupElement['checkValidity']>;
  /**
   * Resets the element to its initial state.
   *
   * @public
   */
  reset(...args: Parameters<ChoiceGroupElement['reset']>): ReturnType<ChoiceGroupElement['reset']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<ChoiceGroupElement['assignToSlot']>): ReturnType<ChoiceGroupElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<ChoiceGroupElement['getSlotContent']>): ReturnType<ChoiceGroupElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<ChoiceGroupElement['hasSlotContent']>): ReturnType<ChoiceGroupElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<ChoiceGroupElement['hasSlot']>): ReturnType<ChoiceGroupElement['hasSlot']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `onSlotChanges()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends ChoiceGroupMethodNames>(method: TMethod, ...args: Parameters<ChoiceGroupComponentMethods[TMethod]>): ReturnType<ChoiceGroupComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ChoiceGroupElement>(property: TProperty, value: ChoiceGroupElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ChoiceGroupElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ChoiceGroupComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ChoiceGroupComponent, "mosaik-choice-group", never, {
    "name": {
      "alias": "name";
      "required": false;
      "isSignal": true;
    };
    "required": {
      "alias": "required";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "orientation": {
      "alias": "orientation";
      "required": false;
      "isSignal": true;
    };
    "invalid": {
      "alias": "invalid";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "choiceChanged": "choiceChanged";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, [{
    directive: typeof i1.FormStatusHostDirective;
    inputs: {};
    outputs: {};
  }, {
    directive: typeof i1.FormFieldStatusHostDirective;
    inputs: {};
    outputs: {};
  }]>;
}
/**
 * Declares the methods available on ChoiceGroupComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ChoiceGroupMethodNames = 'onSlotChanges' | 'checkValidity' | 'reset' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot';
/**
 * Declares the methods interface for ChoiceGroupComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ChoiceGroupComponentMethods = MethodMap<ChoiceGroupMethodNames>;
/**
 * @public
 */
export declare function provideChoiceGroupComponent(config?: Partial<ChoiceGroupElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the ChoiceComponent.
 * Use this token to provide default properties for the ChoiceComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const CHOICE_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/inputs/choice/IChoiceElementProps").IChoiceElementProps>>;
/**
 * @public
 *
 * @slot additional - The additional slot.
 * @slot checkmark - The checkmark slot.
 * @slot label - The label slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ChoiceComponent implements ControlValueAccessor {
  /**
   * Signal input for the `name` property.
   *
   * @public
   */
  readonly name: InputSignal<ChoiceElement['name'] | undefined>;
  /**
   * Signal input for the `additional` property.
   *
   * @public
   */
  readonly additional: InputSignal<ChoiceElement['additional'] | undefined>;
  /**
   * Signal input for the `required` property.
   *
   * @public
   */
  readonly required: InputSignal<ChoiceElement['required'] | undefined>;
  /**
   * Signal input for the `icon` property.
   *
   * @public
   */
  readonly icon: InputSignal<ChoiceElement['icon'] | undefined>;
  /**
   * Signal input for the `iconPosition` property.
   *
   * @public
   */
  readonly iconPosition: InputSignal<ChoiceElement['iconPosition'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ChoiceElement['themeName'] | undefined>;
  /**
   * Signal input for the `ripple` property.
   *
   * @public
   */
  readonly ripple: InputSignal<ChoiceElement['ripple'] | undefined>;
  /**
   * Signal input for the `invalid` property.
   *
   * @public
   */
  readonly invalid: InputSignal<ChoiceElement['invalid'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<ChoiceElement['disabled'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<ChoiceElement['appearance'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<ChoiceElement['variant'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<ChoiceElement['label'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<ChoiceElement['value'] | undefined>;
  /**
   * Signal input for the `formatter` property.
   *
   * @public
   */
  readonly formatter: InputSignal<ChoiceElement['formatter'] | undefined>;
  /**
   * Signal input for the `isChecked` property.
   *
   * @public
   */
  readonly isChecked: InputSignal<ChoiceElement['isChecked'] | undefined>;
  /**
   * Signal input for the `isThreeState` property.
   *
   * @public
   */
  readonly isThreeState: InputSignal<ChoiceElement['isThreeState'] | undefined>;
  /**
   * Signal input for the `isFocused` property.
   *
   * @public
   */
  readonly isFocused: InputSignal<ChoiceElement['isFocused'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ChoiceElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ChoiceElement['lang'] | undefined>;
  /**
   * Output signal for the `checked` event.
   *
   * @public
   */
  readonly checked: OutputEmitterRef<ElementEventDetail<ChoiceElement, 'checked'>>;
  /**
   * Output signal for the `unchecked` event.
   *
   * @public
   */
  readonly unchecked: OutputEmitterRef<ElementEventDetail<ChoiceElement, 'unchecked'>>;
  /**
   * Output signal for the `indeterminate` event.
   *
   * @public
   */
  readonly indeterminate: OutputEmitterRef<ElementEventDetail<ChoiceElement, 'indeterminate'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ChoiceElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ChoiceElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ChoiceElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  private readonly _accessor;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Applies a value supplied by Angular forms to the native control.
   *
   * @public
   */
  writeValue(obj: unknown): void;
  /**
   * Registers the callback notified when the native control value changes.
   *
   * @public
   */
  registerOnChange(fn: unknown): void;
  /**
   * Registers the callback notified when the native control is touched.
   *
   * @public
   */
  registerOnTouched(fn: unknown): void;
  /**
   * Applies the disabled state supplied by Angular forms.
   *
   * @public
   */
  setDisabledState?(isDisabled: boolean): void;
  /**
   * Resets the value, all kinds of validation and errors.
   *
   * @public
   */
  reset(...args: Parameters<ChoiceElement['reset']>): ReturnType<ChoiceElement['reset']>;
  /**
   * Checks the validity of the element and returns `true` if it is valid; otherwise, `false`.
   *
   * @public
   */
  checkValidity(...args: Parameters<ChoiceElement['checkValidity']>): ReturnType<ChoiceElement['checkValidity']>;
  /**
   * Calls `check` on the `mosaik-choice` element.
   *
   * @public
   */
  check(...args: Parameters<ChoiceElement['check']>): ReturnType<ChoiceElement['check']>;
  /**
   * Calls `uncheck` on the `mosaik-choice` element.
   *
   * @public
   */
  uncheck(...args: Parameters<ChoiceElement['uncheck']>): ReturnType<ChoiceElement['uncheck']>;
  /**
   * Calls `toggle` on the `mosaik-choice` element.
   *
   * @public
   */
  toggle(...args: Parameters<ChoiceElement['toggle']>): ReturnType<ChoiceElement['toggle']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `reset()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends ChoiceMethodNames>(method: TMethod, ...args: Parameters<ChoiceComponentMethods[TMethod]>): ReturnType<ChoiceComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ChoiceElement>(property: TProperty, value: ChoiceElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ChoiceElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ChoiceComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ChoiceComponent, "mosaik-choice", never, {
    "name": {
      "alias": "name";
      "required": false;
      "isSignal": true;
    };
    "additional": {
      "alias": "additional";
      "required": false;
      "isSignal": true;
    };
    "required": {
      "alias": "required";
      "required": false;
      "isSignal": true;
    };
    "icon": {
      "alias": "icon";
      "required": false;
      "isSignal": true;
    };
    "iconPosition": {
      "alias": "iconPosition";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "ripple": {
      "alias": "ripple";
      "required": false;
      "isSignal": true;
    };
    "invalid": {
      "alias": "invalid";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "formatter": {
      "alias": "formatter";
      "required": false;
      "isSignal": true;
    };
    "isChecked": {
      "alias": "isChecked";
      "required": false;
      "isSignal": true;
    };
    "isThreeState": {
      "alias": "isThreeState";
      "required": false;
      "isSignal": true;
    };
    "isFocused": {
      "alias": "isFocused";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "checked": "checked";
    "unchecked": "unchecked";
    "indeterminate": "indeterminate";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, [{
    directive: typeof i1.FormStatusHostDirective;
    inputs: {};
    outputs: {};
  }, {
    directive: typeof i1.FormFieldStatusHostDirective;
    inputs: {};
    outputs: {};
  }]>;
}
/**
 * Declares the methods available on ChoiceComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ChoiceMethodNames = 'reset' | 'checkValidity' | 'check' | 'uncheck' | 'toggle';
/**
 * Declares the methods interface for ChoiceComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ChoiceComponentMethods = MethodMap<ChoiceMethodNames>;
/**
 * @public
 */
export declare function provideChoiceComponent(config?: Partial<ChoiceElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-choice.d.ts.map