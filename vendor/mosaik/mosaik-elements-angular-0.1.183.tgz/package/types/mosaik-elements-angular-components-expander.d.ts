import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { ExpanderGroupElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/grouping/expander/ExpanderGroupElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { ExpanderHeaderElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/grouping/expander/ExpanderHeaderElement";
import { ExpanderSubHeaderElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/grouping/expander/ExpanderSubHeaderElement";
import { ExpanderElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/grouping/expander/ExpanderElement";
/**
 * @public
 *
 * Injection token for the default properties of the ExpanderGroupComponent.
 * Use this token to provide default properties for the ExpanderGroupComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const EXPANDER_GROUP_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/grouping/expander/IExpanderGroupElementProps").IExpanderGroupElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot for placing expander items.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ExpanderGroupComponent {
  /**
   * Signal input for the `mode` property.
   *
   * @public
   */
  readonly mode: InputSignal<ExpanderGroupElement['mode'] | undefined>;
  /**
   * Signal input for the `direction` property.
   *
   * @public
   */
  readonly direction: InputSignal<ExpanderGroupElement['direction'] | undefined>;
  /**
   * Signal input for the `stacking` property.
   *
   * @public
   */
  readonly stacking: InputSignal<ExpanderGroupElement['stacking'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ExpanderGroupElement['themeName'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<ExpanderGroupElement['disabled'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<ExpanderGroupElement['variant'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<ExpanderGroupElement['appearance'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ExpanderGroupElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ExpanderGroupElement['lang'] | undefined>;
  /**
   * Output signal for the `toggled` event.
   *
   * @public
   */
  readonly toggled: OutputEmitterRef<ElementEventDetail<ExpanderGroupElement, 'toggled'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ExpanderGroupElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ExpanderGroupElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ExpanderGroupElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: ExpanderGroupElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: ExpanderGroupElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Calls `collapse` on the `mosaik-expander-group` element.
   *
   * @public
   */
  collapse(...args: Parameters<ExpanderGroupElement['collapse']>): ReturnType<ExpanderGroupElement['collapse']>;
  /**
   * Calls `expand` on the `mosaik-expander-group` element.
   *
   * @public
   */
  expand(...args: Parameters<ExpanderGroupElement['expand']>): ReturnType<ExpanderGroupElement['expand']>;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<ExpanderGroupElement['onSlotChanges']>): ReturnType<ExpanderGroupElement['onSlotChanges']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<ExpanderGroupElement['assignToSlot']>): ReturnType<ExpanderGroupElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<ExpanderGroupElement['getSlotContent']>): ReturnType<ExpanderGroupElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<ExpanderGroupElement['hasSlotContent']>): ReturnType<ExpanderGroupElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<ExpanderGroupElement['hasSlot']>): ReturnType<ExpanderGroupElement['hasSlot']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `collapse()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends ExpanderGroupMethodNames>(method: TMethod, ...args: Parameters<ExpanderGroupComponentMethods[TMethod]>): ReturnType<ExpanderGroupComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ExpanderGroupElement>(property: TProperty, value: ExpanderGroupElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ExpanderGroupElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ExpanderGroupComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ExpanderGroupComponent, "mosaik-expander-group", never, {
    "mode": {
      "alias": "mode";
      "required": false;
      "isSignal": true;
    };
    "direction": {
      "alias": "direction";
      "required": false;
      "isSignal": true;
    };
    "stacking": {
      "alias": "stacking";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "toggled": "toggled";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on ExpanderGroupComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ExpanderGroupMethodNames = 'collapse' | 'expand' | 'onSlotChanges' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot';
/**
 * Declares the methods interface for ExpanderGroupComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ExpanderGroupComponentMethods = MethodMap<ExpanderGroupMethodNames>;
/**
 * @public
 */
export declare function provideExpanderGroupComponent(config?: Partial<ExpanderGroupElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the ExpanderHeaderComponent.
 * Use this token to provide default properties for the ExpanderHeaderComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const EXPANDER_HEADER_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/grouping/expander/IExpanderHeaderElementProps").IExpanderHeaderElementProps>>;
/**
 * @public
 *
 * @slot text - The slot for placing header content.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ExpanderHeaderComponent {
  /**
   * Signal input for the `text` property.
   *
   * @public
   */
  readonly text: InputSignal<ExpanderHeaderElement['text'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ExpanderHeaderElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ExpanderHeaderElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ExpanderHeaderElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ExpanderHeaderElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ExpanderHeaderElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ExpanderHeaderElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ExpanderHeaderElement>(property: TProperty, value: ExpanderHeaderElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ExpanderHeaderElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ExpanderHeaderComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ExpanderHeaderComponent, "mosaik-expander-header", never, {
    "text": {
      "alias": "text";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on ExpanderHeaderComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ExpanderHeaderMethodNames = never;
/**
 * Declares the methods interface for ExpanderHeaderComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ExpanderHeaderComponentMethods = MethodMap<ExpanderHeaderMethodNames>;
/**
 * @public
 */
export declare function provideExpanderHeaderComponent(config?: Partial<ExpanderHeaderElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the ExpanderSubHeaderComponent.
 * Use this token to provide default properties for the ExpanderSubHeaderComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const EXPANDER_SUB_HEADER_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/grouping/expander/IExpanderSubHeaderElementProps").IExpanderSubHeaderElementProps>>;
/**
 * @public
 *
 * @slot text - The slot for placing sub-header content.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ExpanderSubHeaderComponent {
  /**
   * Signal input for the `text` property.
   *
   * @public
   */
  readonly text: InputSignal<ExpanderSubHeaderElement['text'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ExpanderSubHeaderElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ExpanderSubHeaderElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ExpanderSubHeaderElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ExpanderSubHeaderElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ExpanderSubHeaderElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ExpanderSubHeaderElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ExpanderSubHeaderElement>(property: TProperty, value: ExpanderSubHeaderElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ExpanderSubHeaderElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ExpanderSubHeaderComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ExpanderSubHeaderComponent, "mosaik-expander-sub-header", never, {
    "text": {
      "alias": "text";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on ExpanderSubHeaderComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ExpanderSubHeaderMethodNames = never;
/**
 * Declares the methods interface for ExpanderSubHeaderComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ExpanderSubHeaderComponentMethods = MethodMap<ExpanderSubHeaderMethodNames>;
/**
 * @public
 */
export declare function provideExpanderSubHeaderComponent(config?: Partial<ExpanderSubHeaderElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the ExpanderComponent.
 * Use this token to provide default properties for the ExpanderComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const EXPANDER_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/grouping/expander/IExpanderElementProps").IExpanderElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot for placing main content inside the expander.
 * @slot header - The header slot.
 * @slot actions - The slot for placing action elements in the expander header.
 * @slot icon - The slot for placing an icon in the expander.
 * @slot subHeader - The slot for placing sub-header content.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ExpanderComponent {
  /**
   * Signal input for the `header` property.
   *
   * @public
   */
  readonly header: InputSignal<ExpanderElement['header'] | undefined>;
  /**
   * Signal input for the `subHeader` property.
   *
   * @public
   */
  readonly subHeader: InputSignal<ExpanderElement['subHeader'] | undefined>;
  /**
   * Signal input for the `icon` property.
   *
   * @public
   */
  readonly icon: InputSignal<ExpanderElement['icon'] | undefined>;
  /**
   * Signal input for the `caretPosition` property.
   *
   * @public
   */
  readonly caretPosition: InputSignal<ExpanderElement['caretPosition'] | undefined>;
  /**
   * Signal input for the `caretVisible` property.
   *
   * @public
   */
  readonly caretVisible: InputSignal<ExpanderElement['caretVisible'] | undefined>;
  /**
   * Signal input for the `direction` property.
   *
   * @public
   */
  readonly direction: InputSignal<ExpanderElement['direction'] | undefined>;
  /**
   * Signal input for the `isExpanded` property.
   *
   * @public
   */
  readonly isExpanded: InputSignal<ExpanderElement['isExpanded'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ExpanderElement['themeName'] | undefined>;
  /**
   * Signal input for the `ripple` property.
   *
   * @public
   */
  readonly ripple: InputSignal<ExpanderElement['ripple'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<ExpanderElement['disabled'] | undefined>;
  /**
   * Signal input for the `enter` property.
   *
   * @public
   */
  readonly enter: InputSignal<ExpanderElement['enter'] | undefined>;
  /**
   * Signal input for the `exit` property.
   *
   * @public
   */
  readonly exit: InputSignal<ExpanderElement['exit'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<ExpanderElement['variant'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<ExpanderElement['appearance'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ExpanderElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ExpanderElement['lang'] | undefined>;
  /**
   * Output signal for the `expanded` event.
   *
   * @public
   */
  readonly expanded: OutputEmitterRef<ElementEventDetail<ExpanderElement, 'expanded'>>;
  /**
   * Output signal for the `collapsed` event.
   *
   * @public
   */
  readonly collapsed: OutputEmitterRef<ElementEventDetail<ExpanderElement, 'collapsed'>>;
  /**
   * Output signal for the `toggled` event.
   *
   * @public
   */
  readonly toggled: OutputEmitterRef<ElementEventDetail<ExpanderElement, 'toggled'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ExpanderElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ExpanderElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ExpanderElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Calls `toggle` on the `mosaik-expander` element.
   *
   * @public
   */
  toggle(...args: Parameters<ExpanderElement['toggle']>): ReturnType<ExpanderElement['toggle']>;
  /**
   * Calls `expand` on the `mosaik-expander` element.
   *
   * @public
   */
  expand(...args: Parameters<ExpanderElement['expand']>): ReturnType<ExpanderElement['expand']>;
  /**
   * Calls `collapse` on the `mosaik-expander` element.
   *
   * @public
   */
  collapse(...args: Parameters<ExpanderElement['collapse']>): ReturnType<ExpanderElement['collapse']>;
  /**
   * Executes the animation.
   *
   * @public
   */
  play(...args: Parameters<ExpanderElement['play']>): ReturnType<ExpanderElement['play']>;
  /**
   * A lifecycle hook that is invoked when the element is added to the DOM.
   *
   * @public
   */
  onEnterAnimation(...args: Parameters<NonNullable<ExpanderElement['onEnterAnimation']>>): ReturnType<NonNullable<ExpanderElement['onEnterAnimation']>> | undefined;
  /**
   * A lifecycle hook that is invoked when the element is removed from the DOM.
   *
   * @public
   */
  onExitAnimation(...args: Parameters<NonNullable<ExpanderElement['onExitAnimation']>>): ReturnType<NonNullable<ExpanderElement['onExitAnimation']>> | undefined;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `toggle()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends ExpanderMethodNames>(method: TMethod, ...args: Parameters<ExpanderComponentMethods[TMethod]>): ReturnType<ExpanderComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ExpanderElement>(property: TProperty, value: ExpanderElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ExpanderElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ExpanderComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ExpanderComponent, "mosaik-expander", never, {
    "header": {
      "alias": "header";
      "required": false;
      "isSignal": true;
    };
    "subHeader": {
      "alias": "subHeader";
      "required": false;
      "isSignal": true;
    };
    "icon": {
      "alias": "icon";
      "required": false;
      "isSignal": true;
    };
    "caretPosition": {
      "alias": "caretPosition";
      "required": false;
      "isSignal": true;
    };
    "caretVisible": {
      "alias": "caretVisible";
      "required": false;
      "isSignal": true;
    };
    "direction": {
      "alias": "direction";
      "required": false;
      "isSignal": true;
    };
    "isExpanded": {
      "alias": "isExpanded";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "ripple": {
      "alias": "ripple";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "enter": {
      "alias": "enter";
      "required": false;
      "isSignal": true;
    };
    "exit": {
      "alias": "exit";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "expanded": "expanded";
    "collapsed": "collapsed";
    "toggled": "toggled";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on ExpanderComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ExpanderMethodNames = 'toggle' | 'expand' | 'collapse' | 'play' | 'onEnterAnimation' | 'onExitAnimation';
/**
 * Declares the methods interface for ExpanderComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ExpanderComponentMethods = MethodMap<ExpanderMethodNames>;
/**
 * @public
 */
export declare function provideExpanderComponent(config?: Partial<ExpanderElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-expander.d.ts.map