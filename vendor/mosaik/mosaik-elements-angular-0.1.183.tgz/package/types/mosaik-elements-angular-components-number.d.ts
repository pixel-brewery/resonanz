import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { NumberCounterElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/number/NumberCounterElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { NumberElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/number/NumberElement";
/**
 * @public
 *
 * Injection token for the default properties of the NumberCounterComponent.
 * Use this token to provide default properties for the NumberCounterComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const NUMBER_COUNTER_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/primitives/number/INumberCounterElementProps").INumberCounterElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class NumberCounterComponent {
  /**
   * Signal input for the `from` property.
   *
   * @public
   */
  readonly from: InputSignal<NumberCounterElement['from'] | undefined>;
  /**
   * Signal input for the `to` property.
   *
   * @public
   */
  readonly to: InputSignal<NumberCounterElement['to'] | undefined>;
  /**
   * Signal input for the `duration` property.
   *
   * @public
   */
  readonly duration: InputSignal<NumberCounterElement['duration'] | undefined>;
  /**
   * Signal input for the `readonly` property.
   *
   * @public
   */
  readonly readonly: InputSignal<NumberCounterElement['readonly'] | undefined>;
  /**
   * Signal input for the `alignment` property.
   *
   * @public
   */
  readonly alignment: InputSignal<NumberCounterElement['alignment'] | undefined>;
  /**
   * Signal input for the `decimals` property.
   *
   * @public
   */
  readonly decimals: InputSignal<NumberCounterElement['decimals'] | undefined>;
  /**
   * Signal input for the `grouping` property.
   *
   * @public
   */
  readonly grouping: InputSignal<NumberCounterElement['grouping'] | undefined>;
  /**
   * Signal input for the `locale` property.
   *
   * @public
   */
  readonly locale: InputSignal<NumberCounterElement['locale'] | undefined>;
  /**
   * Signal input for the `prefixText` property.
   *
   * @public
   */
  readonly prefixText: InputSignal<NumberCounterElement['prefixText'] | undefined>;
  /**
   * Signal input for the `suffixText` property.
   *
   * @public
   */
  readonly suffixText: InputSignal<NumberCounterElement['suffixText'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<NumberCounterElement['themeName'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<NumberCounterElement['variant'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<NumberCounterElement['disabled'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<NumberCounterElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<NumberCounterElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<NumberCounterElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<NumberCounterElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<NumberCounterElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Formats a value with `Intl.NumberFormat`: the fraction digits of `decimals`, the grouping of `grouping` and the
   * language of `locale` (else the element's `lang`, the document language or the browser default).
   *
   * @public
   */
  format(...args: Parameters<NumberCounterElement['format']>): ReturnType<NumberCounterElement['format']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `format()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends NumberCounterMethodNames>(method: TMethod, ...args: Parameters<NumberCounterComponentMethods[TMethod]>): ReturnType<NumberCounterComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof NumberCounterElement>(property: TProperty, value: NumberCounterElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<NumberCounterElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<NumberCounterComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NumberCounterComponent, "mosaik-number-counter", never, {
    "from": {
      "alias": "from";
      "required": false;
      "isSignal": true;
    };
    "to": {
      "alias": "to";
      "required": false;
      "isSignal": true;
    };
    "duration": {
      "alias": "duration";
      "required": false;
      "isSignal": true;
    };
    "readonly": {
      "alias": "readonly";
      "required": false;
      "isSignal": true;
    };
    "alignment": {
      "alias": "alignment";
      "required": false;
      "isSignal": true;
    };
    "decimals": {
      "alias": "decimals";
      "required": false;
      "isSignal": true;
    };
    "grouping": {
      "alias": "grouping";
      "required": false;
      "isSignal": true;
    };
    "locale": {
      "alias": "locale";
      "required": false;
      "isSignal": true;
    };
    "prefixText": {
      "alias": "prefixText";
      "required": false;
      "isSignal": true;
    };
    "suffixText": {
      "alias": "suffixText";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on NumberCounterComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type NumberCounterMethodNames = 'format';
/**
 * Declares the methods interface for NumberCounterComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type NumberCounterComponentMethods = MethodMap<NumberCounterMethodNames>;
/**
 * @public
 */
export declare function provideNumberCounterComponent(config?: Partial<NumberCounterElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the NumberComponent.
 * Use this token to provide default properties for the NumberComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const NUMBER_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/primitives/number/INumberElementProps").INumberElementProps>>;
/**
 * @public
 *
 * @slot number - The number slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class NumberComponent {
  /**
   * Signal input for the `number` property.
   *
   * @public
   */
  readonly number: InputSignal<NumberElement['number'] | undefined>;
  /**
   * Signal input for the `readonly` property.
   *
   * @public
   */
  readonly readonly: InputSignal<NumberElement['readonly'] | undefined>;
  /**
   * Signal input for the `alignment` property.
   *
   * @public
   */
  readonly alignment: InputSignal<NumberElement['alignment'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<NumberElement['themeName'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<NumberElement['variant'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<NumberElement['disabled'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<NumberElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<NumberElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<NumberElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<NumberElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<NumberElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof NumberElement>(property: TProperty, value: NumberElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<NumberElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<NumberComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NumberComponent, "mosaik-number", never, {
    "number": {
      "alias": "number";
      "required": false;
      "isSignal": true;
    };
    "readonly": {
      "alias": "readonly";
      "required": false;
      "isSignal": true;
    };
    "alignment": {
      "alias": "alignment";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on NumberComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type NumberMethodNames = never;
/**
 * Declares the methods interface for NumberComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type NumberComponentMethods = MethodMap<NumberMethodNames>;
/**
 * @public
 */
export declare function provideNumberComponent(config?: Partial<NumberElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-number.d.ts.map