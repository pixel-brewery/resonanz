import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef, Type } from "@angular/core";
import { CookiesConsentElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/misc/cookie-consent/CookiesConsentElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the CookiesConsentComponent.
 * Use this token to provide default properties for the CookiesConsentComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const COOKIES_CONSENT_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/misc/cookie-consent/ICookiesConsentElementProps").ICookiesConsentElementProps>>;
/**
 * @public
 *
 * Injection token for the intl configuration of the CookiesConsentComponent.
 * Provide a partial intl object or an injectable class that resolves translations.
 * This allows third-party applications to override the default intl labels
 * globally, per route, or per component via Angular's dependency injection.
 *
 * Merge order: Foundation defaults → DI intl → [intl] input binding.
 */
export declare const COOKIES_CONSENT_INTL: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").CookiesConsentElementIntl>>;
/**
 * @public
 *
 * @slot actions - Custom action buttons to override or extend the default accept/dismiss buttons
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class CookiesConsentComponent {
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<Partial<CookiesConsentElement['intl']> | undefined>;
  /**
   * Signal input for the `hasAcceptedCookies` property.
   *
   * @public
   */
  readonly hasAcceptedCookies: InputSignal<CookiesConsentElement['hasAcceptedCookies'] | undefined>;
  /**
   * Signal input for the `acceptable` property.
   *
   * @public
   */
  readonly acceptable: InputSignal<CookiesConsentElement['acceptable'] | undefined>;
  /**
   * Signal input for the `dismissable` property.
   *
   * @public
   */
  readonly dismissable: InputSignal<CookiesConsentElement['dismissable'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<CookiesConsentElement['themeName'] | undefined>;
  /**
   * Signal input for the `enter` property.
   *
   * @public
   */
  readonly enter: InputSignal<CookiesConsentElement['enter'] | undefined>;
  /**
   * Signal input for the `exit` property.
   *
   * @public
   */
  readonly exit: InputSignal<CookiesConsentElement['exit'] | undefined>;
  /**
   * Signal input for the `elevation` property.
   *
   * @public
   */
  readonly elevation: InputSignal<CookiesConsentElement['elevation'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<CookiesConsentElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<CookiesConsentElement['lang'] | undefined>;
  /**
   * Output signal for the `cookiesAccepted` event.
   *
   * @public
   */
  readonly cookiesAccepted: OutputEmitterRef<ElementEventDetail<CookiesConsentElement, 'cookiesAccepted'>>;
  /**
   * Output signal for the `cookiesDismissed` event.
   *
   * @public
   */
  readonly cookiesDismissed: OutputEmitterRef<ElementEventDetail<CookiesConsentElement, 'cookiesDismissed'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<CookiesConsentElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<CookiesConsentElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<CookiesConsentElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * A lifecycle hook that is invoked when the element is added to the DOM.
   *
   * @public
   */
  onEnterAnimation(...args: Parameters<CookiesConsentElement['onEnterAnimation']>): ReturnType<CookiesConsentElement['onEnterAnimation']>;
  /**
   * A lifecycle hook that is invoked when the element is removed from the DOM.
   *
   * @public
   */
  onExitAnimation(...args: Parameters<CookiesConsentElement['onExitAnimation']>): ReturnType<CookiesConsentElement['onExitAnimation']>;
  /**
   * Executes the animation.
   *
   * @public
   */
  play(...args: Parameters<CookiesConsentElement['play']>): ReturnType<CookiesConsentElement['play']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `onEnterAnimation()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends CookiesConsentMethodNames>(method: TMethod, ...args: Parameters<CookiesConsentComponentMethods[TMethod]>): ReturnType<CookiesConsentComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof CookiesConsentElement>(property: TProperty, value: CookiesConsentElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<CookiesConsentElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<CookiesConsentComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<CookiesConsentComponent, "mosaik-cookies-consent", never, {
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "hasAcceptedCookies": {
      "alias": "hasAcceptedCookies";
      "required": false;
      "isSignal": true;
    };
    "acceptable": {
      "alias": "acceptable";
      "required": false;
      "isSignal": true;
    };
    "dismissable": {
      "alias": "dismissable";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "enter": {
      "alias": "enter";
      "required": false;
      "isSignal": true;
    };
    "exit": {
      "alias": "exit";
      "required": false;
      "isSignal": true;
    };
    "elevation": {
      "alias": "elevation";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "cookiesAccepted": "cookiesAccepted";
    "cookiesDismissed": "cookiesDismissed";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on CookiesConsentComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type CookiesConsentMethodNames = 'onEnterAnimation' | 'onExitAnimation' | 'play';
/**
 * Declares the methods interface for CookiesConsentComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type CookiesConsentComponentMethods = MethodMap<CookiesConsentMethodNames>;
/**
 * @public
 */
export declare function provideCookiesConsentComponent(config?: Partial<CookiesConsentElement.Props>, intl?: Partial<CookiesConsentElement['intl']> | Type<Partial<CookiesConsentElement['intl']>>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-cookie-consent.d.ts.map