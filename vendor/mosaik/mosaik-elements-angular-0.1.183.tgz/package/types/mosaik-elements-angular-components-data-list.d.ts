import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { ControlValueAccessor } from "@angular/forms";
import { DataListElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/data-list/DataListElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import * as i1 from "@pixel-brewery/mosaik-elements-angular/runtime";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the DataListComponent.
 * Use this token to provide default properties for the DataListComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const DATA_LIST_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/selectors/data-list/IDataListElementProps").IDataListElementProps>>;
/**
 * @public
 *
 * @slot caption - The caption slot.
 * @slot summary - The summary slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class DataListComponent implements ControlValueAccessor {
  /**
   * Signal input for the `alternating` property.
   *
   * @public
   */
  readonly alternating: InputSignal<DataListElement['alternating'] | undefined>;
  /**
   * Signal input for the `itemDefinitions` property.
   *
   * @public
   */
  readonly itemDefinitions: InputSignal<DataListElement['itemDefinitions'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<DataListElement['themeName'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<DataListElement['disabled'] | undefined>;
  /**
   * Signal input for the `source` property.
   *
   * @public
   */
  readonly source: InputSignal<DataListElement['source'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<DataListElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<DataListElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<DataListElement, 'connected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<DataListElement, 'changed'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<DataListElement, 'disconnected'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  private readonly _accessor;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Applies a value supplied by Angular forms to the native control.
   *
   * @public
   */
  writeValue(obj: unknown): void;
  /**
   * Registers the callback notified when the native control value changes.
   *
   * @public
   */
  registerOnChange(fn: unknown): void;
  /**
   * Registers the callback notified when the native control is touched.
   *
   * @public
   */
  registerOnTouched(fn: unknown): void;
  /**
   * Applies the disabled state supplied by Angular forms.
   *
   * @public
   */
  setDisabledState?(isDisabled: boolean): void;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof DataListElement>(property: TProperty, value: DataListElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<DataListElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<DataListComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<DataListComponent, "mosaik-data-list", never, {
    "alternating": {
      "alias": "alternating";
      "required": false;
      "isSignal": true;
    };
    "itemDefinitions": {
      "alias": "itemDefinitions";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "source": {
      "alias": "source";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "changed": "changed";
    "disconnected": "disconnected";
  }, never, ["*"], true, [{
    directive: typeof i1.FormStatusHostDirective;
    inputs: {};
    outputs: {};
  }, {
    directive: typeof i1.FormFieldStatusHostDirective;
    inputs: {};
    outputs: {};
  }]>;
}
/**
 * Declares the methods available on DataListComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type DataListMethodNames = never;
/**
 * Declares the methods interface for DataListComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type DataListComponentMethods = MethodMap<DataListMethodNames>;
/**
 * @public
 */
export declare function provideDataListComponent(config?: Partial<DataListElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-data-list.d.ts.map