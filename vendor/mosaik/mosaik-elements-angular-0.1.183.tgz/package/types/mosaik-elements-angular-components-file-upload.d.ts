import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef, Type } from "@angular/core";
import { FilePickerElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/file-upload/FilePickerElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import * as i1 from "@pixel-brewery/mosaik-elements-angular/runtime";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { FileUploadItemElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/file-upload/FileUploadItemElement";
import { ControlValueAccessor } from "@angular/forms";
import { FileUploadElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/file-upload/FileUploadElement";
/**
 * @public
 *
 * Injection token for the default properties of the FilePickerComponent.
 * Use this token to provide default properties for the FilePickerComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const FILE_PICKER_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/inputs/file-upload/IFilePickerElementProps").IFilePickerElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot for custom trigger content (e.g., a button or icon).
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class FilePickerComponent {
  /**
   * Signal input for the `multiple` property.
   *
   * @public
   */
  readonly multiple: InputSignal<FilePickerElement['multiple'] | undefined>;
  /**
   * Signal input for the `accept` property.
   *
   * @public
   */
  readonly accept: InputSignal<FilePickerElement['accept'] | undefined>;
  /**
   * Signal input for the `directory` property.
   *
   * @public
   */
  readonly directory: InputSignal<FilePickerElement['directory'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<FilePickerElement['themeName'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<FilePickerElement['disabled'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<FilePickerElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<FilePickerElement['lang'] | undefined>;
  /**
   * Output signal for the `filesPicked` event.
   *
   * @public
   */
  readonly filesPicked: OutputEmitterRef<ElementEventDetail<FilePickerElement, 'filesPicked'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<FilePickerElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<FilePickerElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<FilePickerElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Calls `pick` on the `mosaik-file-picker` element.
   *
   * @public
   */
  pick(...args: Parameters<FilePickerElement['pick']>): ReturnType<FilePickerElement['pick']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `pick()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends FilePickerMethodNames>(method: TMethod, ...args: Parameters<FilePickerComponentMethods[TMethod]>): ReturnType<FilePickerComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof FilePickerElement>(property: TProperty, value: FilePickerElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<FilePickerElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<FilePickerComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<FilePickerComponent, "mosaik-file-picker", never, {
    "multiple": {
      "alias": "multiple";
      "required": false;
      "isSignal": true;
    };
    "accept": {
      "alias": "accept";
      "required": false;
      "isSignal": true;
    };
    "directory": {
      "alias": "directory";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "filesPicked": "filesPicked";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on FilePickerComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FilePickerMethodNames = 'pick';
/**
 * Declares the methods interface for FilePickerComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FilePickerComponentMethods = MethodMap<FilePickerMethodNames>;
/**
 * @public
 */
export declare function provideFilePickerComponent(config?: Partial<FilePickerElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the FileUploadItemComponent.
 * Use this token to provide default properties for the FileUploadItemComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const FILE_UPLOAD_ITEM_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/inputs/file-upload/IFileUploadItemElementProps").IFileUploadItemElementProps>>;
/**
 * @public
 *
 * Injection token for the intl configuration of the FileUploadItemComponent.
 * Provide a partial intl object or an injectable class that resolves translations.
 * This allows third-party applications to override the default intl labels
 * globally, per route, or per component via Angular's dependency injection.
 *
 * Merge order: Foundation defaults → DI intl → [intl] input binding.
 */
export declare const FILE_UPLOAD_ITEM_INTL: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").FileUploadElementIntl>>;
/**
 * @public
 *
 * @slot actions - The slot for custom action content (e.g., remove or retry buttons).
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class FileUploadItemComponent {
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<Partial<FileUploadItemElement['intl']> | undefined>;
  /**
   * Signal input for the `file` property.
   *
   * @public
   */
  readonly file: InputSignal<FileUploadItemElement['file'] | undefined>;
  /**
   * Signal input for the `view` property.
   *
   * @public
   */
  readonly view: InputSignal<FileUploadItemElement['view'] | undefined>;
  /**
   * Signal input for the `progressMode` property.
   *
   * @public
   */
  readonly progressMode: InputSignal<FileUploadItemElement['progressMode'] | undefined>;
  /**
   * Signal input for the `showPreview` property.
   *
   * @public
   */
  readonly showPreview: InputSignal<FileUploadItemElement['showPreview'] | undefined>;
  /**
   * Signal input for the `controlled` property.
   *
   * @public
   */
  readonly controlled: InputSignal<FileUploadItemElement['controlled'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<FileUploadItemElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<FileUploadItemElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<FileUploadItemElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<FileUploadItemElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<FileUploadItemElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<FileUploadItemElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof FileUploadItemElement>(property: TProperty, value: FileUploadItemElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<FileUploadItemElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<FileUploadItemComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<FileUploadItemComponent, "mosaik-file-upload-item", never, {
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "file": {
      "alias": "file";
      "required": false;
      "isSignal": true;
    };
    "view": {
      "alias": "view";
      "required": false;
      "isSignal": true;
    };
    "progressMode": {
      "alias": "progressMode";
      "required": false;
      "isSignal": true;
    };
    "showPreview": {
      "alias": "showPreview";
      "required": false;
      "isSignal": true;
    };
    "controlled": {
      "alias": "controlled";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on FileUploadItemComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FileUploadItemMethodNames = never;
/**
 * Declares the methods interface for FileUploadItemComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FileUploadItemComponentMethods = MethodMap<FileUploadItemMethodNames>;
/**
 * @public
 */
export declare function provideFileUploadItemComponent(config?: Partial<FileUploadItemElement.Props>, intl?: Partial<FileUploadItemElement['intl']> | Type<Partial<FileUploadItemElement['intl']>>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the FileUploadComponent.
 * Use this token to provide default properties for the FileUploadComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const FILE_UPLOAD_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/inputs/file-upload/IFileUploadElementProps").IFileUploadElementProps>>;
/**
 * @public
 *
 * Injection token for the intl configuration of the FileUploadComponent.
 * Provide a partial intl object or an injectable class that resolves translations.
 * This allows third-party applications to override the default intl labels
 * globally, per route, or per component via Angular's dependency injection.
 *
 * Merge order: Foundation defaults → DI intl → [intl] input binding.
 */
export declare const FILE_UPLOAD_INTL: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").FileUploadElementIntl>>;
/**
 * @public
 *
 * @slot actions - The actions slot.
 * @slot drop-zone - Custom browse content, such as an icon, title and limits. Clicking the content opens the file picker. Without content, the browse button is shown.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class FileUploadComponent implements ControlValueAccessor {
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<Partial<FileUploadElement['intl']> | undefined>;
  /**
   * Signal input for the `autoUpload` property.
   *
   * @public
   */
  readonly autoUpload: InputSignal<FileUploadElement['autoUpload'] | undefined>;
  /**
   * Signal input for the `view` property.
   *
   * @public
   */
  readonly view: InputSignal<FileUploadElement['view'] | undefined>;
  /**
   * Signal input for the `progressMode` property.
   *
   * @public
   */
  readonly progressMode: InputSignal<FileUploadElement['progressMode'] | undefined>;
  /**
   * Signal input for the `showPreview` property.
   *
   * @public
   */
  readonly showPreview: InputSignal<FileUploadElement['showPreview'] | undefined>;
  /**
   * Signal input for the `multiple` property.
   *
   * @public
   */
  readonly multiple: InputSignal<FileUploadElement['multiple'] | undefined>;
  /**
   * Signal input for the `directory` property.
   *
   * @public
   */
  readonly directory: InputSignal<FileUploadElement['directory'] | undefined>;
  /**
   * Signal input for the `accept` property.
   *
   * @public
   */
  readonly accept: InputSignal<FileUploadElement['accept'] | undefined>;
  /**
   * Signal input for the `strategy` property.
   *
   * @public
   */
  readonly strategy: InputSignal<FileUploadElement['strategy'] | undefined>;
  /**
   * Signal input for the `placeholder` property.
   *
   * @public
   */
  readonly placeholder: InputSignal<FileUploadElement['placeholder'] | undefined>;
  /**
   * Signal input for the `maxSize` property.
   *
   * @public
   */
  readonly maxSize: InputSignal<FileUploadElement['maxSize'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<FileUploadElement['themeName'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<FileUploadElement['disabled'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<FileUploadElement['appearance'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<FileUploadElement['variant'] | undefined>;
  /**
   * Signal input for the `invalid` property.
   *
   * @public
   */
  readonly invalid: InputSignal<FileUploadElement['invalid'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<FileUploadElement['value'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<FileUploadElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<FileUploadElement['lang'] | undefined>;
  /**
   * Output signal for the `fileAdded` event.
   *
   * @public
   */
  readonly fileAdded: OutputEmitterRef<ElementEventDetail<FileUploadElement, 'fileAdded'>>;
  /**
   * Output signal for the `fileRemoved` event.
   *
   * @public
   */
  readonly fileRemoved: OutputEmitterRef<ElementEventDetail<FileUploadElement, 'fileRemoved'>>;
  /**
   * Output signal for the `fileFailed` event.
   *
   * @public
   */
  readonly fileFailed: OutputEmitterRef<ElementEventDetail<FileUploadElement, 'fileFailed'>>;
  /**
   * Output signal for the `filesChanged` event.
   *
   * @public
   */
  readonly filesChanged: OutputEmitterRef<ElementEventDetail<FileUploadElement, 'filesChanged'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<FileUploadElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<FileUploadElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<FileUploadElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  private readonly _accessor;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Applies a value supplied by Angular forms to the native control.
   *
   * @public
   */
  writeValue(obj: unknown): void;
  /**
   * Registers the callback notified when the native control value changes.
   *
   * @public
   */
  registerOnChange(fn: unknown): void;
  /**
   * Registers the callback notified when the native control is touched.
   *
   * @public
   */
  registerOnTouched(fn: unknown): void;
  /**
   * Applies the disabled state supplied by Angular forms.
   *
   * @public
   */
  setDisabledState?(isDisabled: boolean): void;
  /**
   * Calls `add` on the `mosaik-file-upload` element.
   *
   * @public
   */
  add(...args: Parameters<FileUploadElement['add']>): ReturnType<FileUploadElement['add']>;
  /**
   * Calls `delete` on the `mosaik-file-upload` element.
   *
   * @public
   */
  delete(...args: Parameters<FileUploadElement['delete']>): ReturnType<FileUploadElement['delete']>;
  /**
   * Calls `save` on the `mosaik-file-upload` element.
   *
   * @public
   */
  save(...args: Parameters<FileUploadElement['save']>): ReturnType<FileUploadElement['save']>;
  /**
   * Resets the value, all kinds of validation and errors.
   *
   * @public
   */
  reset(...args: Parameters<FileUploadElement['reset']>): ReturnType<FileUploadElement['reset']>;
  /**
   * Checks the validity of the element and returns `true` if it is valid; otherwise, `false`.
   * The element has no constraints of its own, so it is invalid only while it is marked `invalid`.
   *
   * @public
   */
  checkValidity(...args: Parameters<FileUploadElement['checkValidity']>): ReturnType<FileUploadElement['checkValidity']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `add()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends FileUploadMethodNames>(method: TMethod, ...args: Parameters<FileUploadComponentMethods[TMethod]>): ReturnType<FileUploadComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof FileUploadElement>(property: TProperty, value: FileUploadElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<FileUploadElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<FileUploadComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<FileUploadComponent, "mosaik-file-upload", never, {
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "autoUpload": {
      "alias": "autoUpload";
      "required": false;
      "isSignal": true;
    };
    "view": {
      "alias": "view";
      "required": false;
      "isSignal": true;
    };
    "progressMode": {
      "alias": "progressMode";
      "required": false;
      "isSignal": true;
    };
    "showPreview": {
      "alias": "showPreview";
      "required": false;
      "isSignal": true;
    };
    "multiple": {
      "alias": "multiple";
      "required": false;
      "isSignal": true;
    };
    "directory": {
      "alias": "directory";
      "required": false;
      "isSignal": true;
    };
    "accept": {
      "alias": "accept";
      "required": false;
      "isSignal": true;
    };
    "strategy": {
      "alias": "strategy";
      "required": false;
      "isSignal": true;
    };
    "placeholder": {
      "alias": "placeholder";
      "required": false;
      "isSignal": true;
    };
    "maxSize": {
      "alias": "maxSize";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "invalid": {
      "alias": "invalid";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "fileAdded": "fileAdded";
    "fileRemoved": "fileRemoved";
    "fileFailed": "fileFailed";
    "filesChanged": "filesChanged";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, [{
    directive: typeof i1.FormStatusHostDirective;
    inputs: {};
    outputs: {};
  }, {
    directive: typeof i1.FormFieldStatusHostDirective;
    inputs: {};
    outputs: {};
  }]>;
}
/**
 * Declares the methods available on FileUploadComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FileUploadMethodNames = 'add' | 'delete' | 'save' | 'reset' | 'checkValidity';
/**
 * Declares the methods interface for FileUploadComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FileUploadComponentMethods = MethodMap<FileUploadMethodNames>;
/**
 * @public
 */
export declare function provideFileUploadComponent(config?: Partial<FileUploadElement.Props>, intl?: Partial<FileUploadElement['intl']> | Type<Partial<FileUploadElement['intl']>>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-file-upload.d.ts.map