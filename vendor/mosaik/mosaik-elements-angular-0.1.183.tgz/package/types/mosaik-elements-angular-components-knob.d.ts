import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { KnobElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/ranges/knob/KnobElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the KnobComponent.
 * Use this token to provide default properties for the KnobComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const KNOB_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").IKnobElementProps>>;
/**
 * @public
 *
 * @slot label - Custom content replacing the generated label below the dial.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class KnobComponent {
  /**
   * Signal input for the `step` property.
   *
   * @public
   */
  readonly step: InputSignal<KnobElement['step'] | undefined>;
  /**
   * Signal input for the `diameter` property.
   *
   * @public
   */
  readonly diameter: InputSignal<KnobElement['diameter'] | undefined>;
  /**
   * Signal input for the `mode` property.
   *
   * @public
   */
  readonly mode: InputSignal<KnobElement['mode'] | undefined>;
  /**
   * Signal input for the `startAngle` property.
   *
   * @public
   */
  readonly startAngle: InputSignal<KnobElement['startAngle'] | undefined>;
  /**
   * Signal input for the `endAngle` property.
   *
   * @public
   */
  readonly endAngle: InputSignal<KnobElement['endAngle'] | undefined>;
  /**
   * Signal input for the `ticks` property.
   *
   * @public
   */
  readonly ticks: InputSignal<KnobElement['ticks'] | undefined>;
  /**
   * Signal input for the `tickPlacement` property.
   *
   * @public
   */
  readonly tickPlacement: InputSignal<KnobElement['tickPlacement'] | undefined>;
  /**
   * Signal input for the `tickLength` property.
   *
   * @public
   */
  readonly tickLength: InputSignal<KnobElement['tickLength'] | undefined>;
  /**
   * Signal input for the `tickGap` property.
   *
   * @public
   */
  readonly tickGap: InputSignal<KnobElement['tickGap'] | undefined>;
  /**
   * Signal input for the `pxPerStep` property.
   *
   * @public
   */
  readonly pxPerStep: InputSignal<KnobElement['pxPerStep'] | undefined>;
  /**
   * Signal input for the `wheel` property.
   *
   * @public
   */
  readonly wheel: InputSignal<KnobElement['wheel'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<KnobElement['label'] | undefined>;
  /**
   * Signal input for the `showValue` property.
   *
   * @public
   */
  readonly showValue: InputSignal<KnobElement['showValue'] | undefined>;
  /**
   * Signal input for the `valueAccessor` property.
   *
   * @public
   */
  readonly valueAccessor: InputSignal<KnobElement['valueAccessor'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<KnobElement['themeName'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<KnobElement['disabled'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<KnobElement['variant'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<KnobElement['appearance'] | undefined>;
  /**
   * Signal input for the `isFocused` property.
   *
   * @public
   */
  readonly isFocused: InputSignal<KnobElement['isFocused'] | undefined>;
  /**
   * Signal input for the `invalid` property.
   *
   * @public
   */
  readonly invalid: InputSignal<KnobElement['invalid'] | undefined>;
  /**
   * Signal input for the `min` property.
   *
   * @public
   */
  readonly min: InputSignal<KnobElement['min'] | undefined>;
  /**
   * Signal input for the `max` property.
   *
   * @public
   */
  readonly max: InputSignal<KnobElement['max'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<KnobElement['value'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<KnobElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<KnobElement['lang'] | undefined>;
  /**
   * Output signal for the `rangeValueChanged` event.
   *
   * @public
   */
  readonly rangeValueChanged: OutputEmitterRef<ElementEventDetail<KnobElement, 'rangeValueChanged'>>;
  /**
   * Output signal for the `input` event.
   *
   * @public
   */
  readonly input: OutputEmitterRef<ElementEventDetail<KnobElement, 'input'>>;
  /**
   * Output signal for the `change` event.
   *
   * @public
   */
  readonly change: OutputEmitterRef<ElementEventDetail<KnobElement, 'change'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<KnobElement, 'changed'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<KnobElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<KnobElement, 'disconnected'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Decrements the value by the value given by the `step` property.
   * If the optional parameter is used, it will decrement the step value multiplied by
   * the parameter's value.
   *
   * @public
   * @param args - The arguments of `stepDown`:
   * - `value` - Value to decrement the value by.
   */
  stepDown(...args: Parameters<KnobElement['stepDown']>): ReturnType<KnobElement['stepDown']>;
  /**
   * Increments the value by the value given by the `step` property.
   * If the optional parameter is used, it will increment the step value multiplied by
   * the parameter's value.
   *
   * @public
   * @param args - The arguments of `stepUp`:
   * - `value` - Value to increment the value by.
   */
  stepUp(...args: Parameters<KnobElement['stepUp']>): ReturnType<KnobElement['stepUp']>;
  /**
   * Checks the validity of the element and returns `true` if it is valid; otherwise, `false`.
   *
   * @public
   */
  checkValidity(...args: Parameters<KnobElement['checkValidity']>): ReturnType<KnobElement['checkValidity']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `stepDown()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends KnobMethodNames>(method: TMethod, ...args: Parameters<KnobComponentMethods[TMethod]>): ReturnType<KnobComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof KnobElement>(property: TProperty, value: KnobElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<KnobElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<KnobComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<KnobComponent, "mosaik-knob", never, {
    "step": {
      "alias": "step";
      "required": false;
      "isSignal": true;
    };
    "diameter": {
      "alias": "diameter";
      "required": false;
      "isSignal": true;
    };
    "mode": {
      "alias": "mode";
      "required": false;
      "isSignal": true;
    };
    "startAngle": {
      "alias": "startAngle";
      "required": false;
      "isSignal": true;
    };
    "endAngle": {
      "alias": "endAngle";
      "required": false;
      "isSignal": true;
    };
    "ticks": {
      "alias": "ticks";
      "required": false;
      "isSignal": true;
    };
    "tickPlacement": {
      "alias": "tickPlacement";
      "required": false;
      "isSignal": true;
    };
    "tickLength": {
      "alias": "tickLength";
      "required": false;
      "isSignal": true;
    };
    "tickGap": {
      "alias": "tickGap";
      "required": false;
      "isSignal": true;
    };
    "pxPerStep": {
      "alias": "pxPerStep";
      "required": false;
      "isSignal": true;
    };
    "wheel": {
      "alias": "wheel";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "showValue": {
      "alias": "showValue";
      "required": false;
      "isSignal": true;
    };
    "valueAccessor": {
      "alias": "valueAccessor";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "isFocused": {
      "alias": "isFocused";
      "required": false;
      "isSignal": true;
    };
    "invalid": {
      "alias": "invalid";
      "required": false;
      "isSignal": true;
    };
    "min": {
      "alias": "min";
      "required": false;
      "isSignal": true;
    };
    "max": {
      "alias": "max";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "rangeValueChanged": "rangeValueChanged";
    "input": "input";
    "change": "change";
    "changed": "changed";
    "connected": "connected";
    "disconnected": "disconnected";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on KnobComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type KnobMethodNames = 'stepDown' | 'stepUp' | 'checkValidity';
/**
 * Declares the methods interface for KnobComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type KnobComponentMethods = MethodMap<KnobMethodNames>;
/**
 * @public
 */
export declare function provideKnobComponent(config?: Partial<KnobElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-knob.d.ts.map