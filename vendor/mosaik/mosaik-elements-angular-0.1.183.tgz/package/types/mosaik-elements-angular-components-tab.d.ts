import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { TabItemElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/tab/TabItemElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { TabPanelElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/tab/TabPanelElement";
import { TabElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/tab/TabElement";
/**
 * @public
 *
 * Injection token for the default properties of the TabItemComponent.
 * Use this token to provide default properties for the TabItemComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const TAB_ITEM_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/selectors/tab/ITabItemElementProps").ITabItemElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class TabItemComponent {
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<TabItemElement['themeName'] | undefined>;
  /**
   * Signal input for the `enter` property.
   *
   * @public
   */
  readonly enter: InputSignal<TabItemElement['enter'] | undefined>;
  /**
   * Signal input for the `exit` property.
   *
   * @public
   */
  readonly exit: InputSignal<TabItemElement['exit'] | undefined>;
  /**
   * Signal input for the `orientation` property.
   *
   * @public
   */
  readonly orientation: InputSignal<TabItemElement['orientation'] | undefined>;
  /**
   * Signal input for the `closeable` property.
   *
   * @public
   */
  readonly closeable: InputSignal<TabItemElement['closeable'] | undefined>;
  /**
   * Signal input for the `isSelected` property.
   *
   * @public
   */
  readonly isSelected: InputSignal<TabItemElement['isSelected'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<TabItemElement['disabled'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<TabItemElement['label'] | undefined>;
  /**
   * Signal input for the `icon` property.
   *
   * @public
   */
  readonly icon: InputSignal<TabItemElement['icon'] | undefined>;
  /**
   * Signal input for the `iconPosition` property.
   *
   * @public
   */
  readonly iconPosition: InputSignal<TabItemElement['iconPosition'] | undefined>;
  /**
   * Signal input for the `iconSize` property.
   *
   * @public
   */
  readonly iconSize: InputSignal<TabItemElement['iconSize'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<TabItemElement['value'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<TabItemElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<TabItemElement['lang'] | undefined>;
  /**
   * Output signal for the `selected` event.
   *
   * @public
   */
  readonly selected: OutputEmitterRef<ElementEventDetail<TabItemElement, 'selected'>>;
  /**
   * Output signal for the `deselected` event.
   *
   * @public
   */
  readonly deselected: OutputEmitterRef<ElementEventDetail<TabItemElement, 'deselected'>>;
  /**
   * Output signal for the `closed` event.
   *
   * @public
   */
  readonly closed: OutputEmitterRef<ElementEventDetail<TabItemElement, 'closed'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<TabItemElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<TabItemElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<TabItemElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Executes the animation.
   *
   * @public
   */
  play(...args: Parameters<TabItemElement['play']>): ReturnType<TabItemElement['play']>;
  /**
   * A lifecycle hook that is invoked when the element is added to the DOM.
   *
   * @public
   */
  onEnterAnimation(...args: Parameters<NonNullable<TabItemElement['onEnterAnimation']>>): ReturnType<NonNullable<TabItemElement['onEnterAnimation']>> | undefined;
  /**
   * A lifecycle hook that is invoked when the element is removed from the DOM.
   *
   * @public
   */
  onExitAnimation(...args: Parameters<NonNullable<TabItemElement['onExitAnimation']>>): ReturnType<NonNullable<TabItemElement['onExitAnimation']>> | undefined;
  /**
   * Removes the element from the DOM.
   *
   * @public
   */
  close(...args: Parameters<TabItemElement['close']>): ReturnType<TabItemElement['close']>;
  /**
   * Selects the element.
   *
   * @public
   */
  select(...args: Parameters<TabItemElement['select']>): ReturnType<TabItemElement['select']>;
  /**
   * Deselects the element.
   *
   * @public
   */
  deselect(...args: Parameters<TabItemElement['deselect']>): ReturnType<TabItemElement['deselect']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `play()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends TabItemMethodNames>(method: TMethod, ...args: Parameters<TabItemComponentMethods[TMethod]>): ReturnType<TabItemComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof TabItemElement>(property: TProperty, value: TabItemElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<TabItemElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<TabItemComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<TabItemComponent, "mosaik-tab-item", never, {
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "enter": {
      "alias": "enter";
      "required": false;
      "isSignal": true;
    };
    "exit": {
      "alias": "exit";
      "required": false;
      "isSignal": true;
    };
    "orientation": {
      "alias": "orientation";
      "required": false;
      "isSignal": true;
    };
    "closeable": {
      "alias": "closeable";
      "required": false;
      "isSignal": true;
    };
    "isSelected": {
      "alias": "isSelected";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "icon": {
      "alias": "icon";
      "required": false;
      "isSignal": true;
    };
    "iconPosition": {
      "alias": "iconPosition";
      "required": false;
      "isSignal": true;
    };
    "iconSize": {
      "alias": "iconSize";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "selected": "selected";
    "deselected": "deselected";
    "closed": "closed";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on TabItemComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TabItemMethodNames = 'play' | 'onEnterAnimation' | 'onExitAnimation' | 'close' | 'select' | 'deselect';
/**
 * Declares the methods interface for TabItemComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TabItemComponentMethods = MethodMap<TabItemMethodNames>;
/**
 * @public
 */
export declare function provideTabItemComponent(config?: Partial<TabItemElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the TabPanelComponent.
 * Use this token to provide default properties for the TabPanelComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const TAB_PANEL_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/selectors/tab/ITabPanelElementProps").ITabPanelElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot for the tab strip element
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class TabPanelComponent {
  /**
   * Signal input for the `alignment` property.
   *
   * @public
   */
  readonly alignment: InputSignal<TabPanelElement['alignment'] | undefined>;
  /**
   * Signal input for the `placement` property.
   *
   * @public
   */
  readonly placement: InputSignal<TabPanelElement['placement'] | undefined>;
  /**
   * Signal input for the `hasIndicator` property.
   *
   * @public
   */
  readonly hasIndicator: InputSignal<TabPanelElement['hasIndicator'] | undefined>;
  /**
   * Signal input for the `enableGestures` property.
   *
   * @public
   */
  readonly enableGestures: InputSignal<TabPanelElement['enableGestures'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<TabPanelElement['themeName'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<TabPanelElement['appearance'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<TabPanelElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<TabPanelElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<TabPanelElement, 'connected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<TabPanelElement, 'changed'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<TabPanelElement, 'disconnected'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: TabPanelElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: TabPanelElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<TabPanelElement['assignToSlot']>): ReturnType<TabPanelElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<TabPanelElement['getSlotContent']>): ReturnType<TabPanelElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<TabPanelElement['hasSlotContent']>): ReturnType<TabPanelElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<TabPanelElement['hasSlot']>): ReturnType<TabPanelElement['hasSlot']>;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<TabPanelElement['onSlotChanges']>): ReturnType<TabPanelElement['onSlotChanges']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `assignToSlot()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends TabPanelMethodNames>(method: TMethod, ...args: Parameters<TabPanelComponentMethods[TMethod]>): ReturnType<TabPanelComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof TabPanelElement>(property: TProperty, value: TabPanelElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<TabPanelElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<TabPanelComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<TabPanelComponent, "mosaik-tab-panel", never, {
    "alignment": {
      "alias": "alignment";
      "required": false;
      "isSignal": true;
    };
    "placement": {
      "alias": "placement";
      "required": false;
      "isSignal": true;
    };
    "hasIndicator": {
      "alias": "hasIndicator";
      "required": false;
      "isSignal": true;
    };
    "enableGestures": {
      "alias": "enableGestures";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "changed": "changed";
    "disconnected": "disconnected";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on TabPanelComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TabPanelMethodNames = 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges';
/**
 * Declares the methods interface for TabPanelComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TabPanelComponentMethods = MethodMap<TabPanelMethodNames>;
/**
 * @public
 */
export declare function provideTabPanelComponent(config?: Partial<TabPanelElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the TabComponent.
 * Use this token to provide default properties for the TabComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const TAB_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/selectors/tab/ITabElementProps").ITabElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot for tab items (mosaik-tab-item elements)
 * @slot end - Content displayed after the tab strip (e.g., action buttons)
 * @slot start - Content displayed before the tab strip (e.g., toolbar buttons)
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class TabComponent {
  /**
   * Signal input for the `alignment` property.
   *
   * @public
   */
  readonly alignment: InputSignal<TabElement['alignment'] | undefined>;
  /**
   * Signal input for the `placement` property.
   *
   * @public
   */
  readonly placement: InputSignal<TabElement['placement'] | undefined>;
  /**
   * Signal input for the `hasIndicator` property.
   *
   * @public
   */
  readonly hasIndicator: InputSignal<TabElement['hasIndicator'] | undefined>;
  /**
   * Signal input for the `enableGestures` property.
   *
   * @public
   */
  readonly enableGestures: InputSignal<TabElement['enableGestures'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<TabElement['themeName'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<TabElement['disabled'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<TabElement['variant'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<TabElement['appearance'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<TabElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<TabElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<TabElement, 'connected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<TabElement, 'changed'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<TabElement, 'disconnected'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: TabElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: TabElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Selects the specified tab item.
   *
   * @public
   * @param args - The arguments of `select`:
   * - `tabItem` - The tab item to select.
   */
  select(...args: Parameters<TabElement['select']>): ReturnType<TabElement['select']>;
  /**
   * Selects the specified tab item by its index.
   *
   * @public
   * @param args - The arguments of `selectByIndex`:
   * - `index` - The index of the tab item to select.
   */
  selectByIndex(...args: Parameters<TabElement['selectByIndex']>): ReturnType<TabElement['selectByIndex']>;
  /**
   * Selects the specified tab item by its value.
   *
   * @public
   * @param args - The arguments of `selectByValue`:
   * - `value` - The value of the tab item to select.
   */
  selectByValue(...args: Parameters<TabElement['selectByValue']>): ReturnType<TabElement['selectByValue']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<TabElement['assignToSlot']>): ReturnType<TabElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<TabElement['getSlotContent']>): ReturnType<TabElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<TabElement['hasSlotContent']>): ReturnType<TabElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<TabElement['hasSlot']>): ReturnType<TabElement['hasSlot']>;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<TabElement['onSlotChanges']>): ReturnType<TabElement['onSlotChanges']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `select()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends TabMethodNames>(method: TMethod, ...args: Parameters<TabComponentMethods[TMethod]>): ReturnType<TabComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof TabElement>(property: TProperty, value: TabElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<TabElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<TabComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<TabComponent, "mosaik-tab", never, {
    "alignment": {
      "alias": "alignment";
      "required": false;
      "isSignal": true;
    };
    "placement": {
      "alias": "placement";
      "required": false;
      "isSignal": true;
    };
    "hasIndicator": {
      "alias": "hasIndicator";
      "required": false;
      "isSignal": true;
    };
    "enableGestures": {
      "alias": "enableGestures";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "changed": "changed";
    "disconnected": "disconnected";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on TabComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TabMethodNames = 'select' | 'selectByIndex' | 'selectByValue' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges';
/**
 * Declares the methods interface for TabComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TabComponentMethods = MethodMap<TabMethodNames>;
/**
 * @public
 */
export declare function provideTabComponent(config?: Partial<TabElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-tab.d.ts.map