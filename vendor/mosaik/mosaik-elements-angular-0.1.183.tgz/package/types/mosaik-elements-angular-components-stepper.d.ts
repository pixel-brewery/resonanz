import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { StepperItemElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/stepper/StepperItemElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { StepperElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/stepper/StepperElement";
/**
 * @public
 *
 * Injection token for the default properties of the StepperItemComponent.
 * Use this token to provide default properties for the StepperItemComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const STEPPER_ITEM_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/selectors/stepper/IStepperItemElementProps").IStepperItemElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot for the main step content
 * @slot footer - Action buttons or navigation controls for this step
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class StepperItemComponent {
  /**
   * Signal input for the `isActive` property.
   *
   * @public
   */
  readonly isActive: InputSignal<StepperItemElement['isActive'] | undefined>;
  /**
   * Signal input for the `header` property.
   *
   * @public
   */
  readonly header: InputSignal<StepperItemElement['header'] | undefined>;
  /**
   * Signal input for the `description` property.
   *
   * @public
   */
  readonly description: InputSignal<StepperItemElement['description'] | undefined>;
  /**
   * Signal input for the `hint` property.
   *
   * @public
   */
  readonly hint: InputSignal<StepperItemElement['hint'] | undefined>;
  /**
   * Signal input for the `icon` property.
   *
   * @public
   */
  readonly icon: InputSignal<StepperItemElement['icon'] | undefined>;
  /**
   * Signal input for the `iconSize` property.
   *
   * @public
   */
  readonly iconSize: InputSignal<StepperItemElement['iconSize'] | undefined>;
  /**
   * Signal input for the `state` property.
   *
   * @public
   */
  readonly state: InputSignal<StepperItemElement['state'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<StepperItemElement['themeName'] | undefined>;
  /**
   * Signal input for the `enter` property.
   *
   * @public
   */
  readonly enter: InputSignal<StepperItemElement['enter'] | undefined>;
  /**
   * Signal input for the `exit` property.
   *
   * @public
   */
  readonly exit: InputSignal<StepperItemElement['exit'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<StepperItemElement['disabled'] | undefined>;
  /**
   * Signal input for the `isSelected` property.
   *
   * @public
   */
  readonly isSelected: InputSignal<StepperItemElement['isSelected'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<StepperItemElement['value'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<StepperItemElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<StepperItemElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<StepperItemElement, 'connected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<StepperItemElement, 'changed'>>;
  /**
   * Output signal for the `selected` event.
   *
   * @public
   */
  readonly selected: OutputEmitterRef<ElementEventDetail<StepperItemElement, 'selected'>>;
  /**
   * Output signal for the `deselected` event.
   *
   * @public
   */
  readonly deselected: OutputEmitterRef<ElementEventDetail<StepperItemElement, 'deselected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<StepperItemElement, 'disconnected'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: StepperItemElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: StepperItemElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<StepperItemElement['assignToSlot']>): ReturnType<StepperItemElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<StepperItemElement['getSlotContent']>): ReturnType<StepperItemElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<StepperItemElement['hasSlotContent']>): ReturnType<StepperItemElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<StepperItemElement['hasSlot']>): ReturnType<StepperItemElement['hasSlot']>;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<StepperItemElement['onSlotChanges']>): ReturnType<StepperItemElement['onSlotChanges']>;
  /**
   * Executes the animation.
   *
   * @public
   */
  play(...args: Parameters<StepperItemElement['play']>): ReturnType<StepperItemElement['play']>;
  /**
   * A lifecycle hook that is invoked when the element is added to the DOM.
   *
   * @public
   */
  onEnterAnimation(...args: Parameters<NonNullable<StepperItemElement['onEnterAnimation']>>): ReturnType<NonNullable<StepperItemElement['onEnterAnimation']>> | undefined;
  /**
   * A lifecycle hook that is invoked when the element is removed from the DOM.
   *
   * @public
   */
  onExitAnimation(...args: Parameters<NonNullable<StepperItemElement['onExitAnimation']>>): ReturnType<NonNullable<StepperItemElement['onExitAnimation']>> | undefined;
  /**
   * Selects the item and fires `selected`. Does nothing when the item is already selected.
   *
   * @public
   * @param args - The arguments of `select`:
   * - `forceUpdate` - When `true`, the parent selector also selects the item.
   */
  select(...args: Parameters<StepperItemElement['select']>): ReturnType<StepperItemElement['select']>;
  /**
   * Deselects the item and fires `deselected`. Does nothing when the item is not selected.
   *
   * @public
   * @param args - The arguments of `deselect`:
   * - `forceUpdate` - When `true`, the parent selector also deselects the item.
   */
  deselect(...args: Parameters<StepperItemElement['deselect']>): ReturnType<StepperItemElement['deselect']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `assignToSlot()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends StepperItemMethodNames>(method: TMethod, ...args: Parameters<StepperItemComponentMethods[TMethod]>): ReturnType<StepperItemComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof StepperItemElement>(property: TProperty, value: StepperItemElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<StepperItemElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<StepperItemComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<StepperItemComponent, "mosaik-stepper-item", never, {
    "isActive": {
      "alias": "isActive";
      "required": false;
      "isSignal": true;
    };
    "header": {
      "alias": "header";
      "required": false;
      "isSignal": true;
    };
    "description": {
      "alias": "description";
      "required": false;
      "isSignal": true;
    };
    "hint": {
      "alias": "hint";
      "required": false;
      "isSignal": true;
    };
    "icon": {
      "alias": "icon";
      "required": false;
      "isSignal": true;
    };
    "iconSize": {
      "alias": "iconSize";
      "required": false;
      "isSignal": true;
    };
    "state": {
      "alias": "state";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "enter": {
      "alias": "enter";
      "required": false;
      "isSignal": true;
    };
    "exit": {
      "alias": "exit";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "isSelected": {
      "alias": "isSelected";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "changed": "changed";
    "selected": "selected";
    "deselected": "deselected";
    "disconnected": "disconnected";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on StepperItemComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type StepperItemMethodNames = 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges' | 'play' | 'onEnterAnimation' | 'onExitAnimation' | 'select' | 'deselect';
/**
 * Declares the methods interface for StepperItemComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type StepperItemComponentMethods = MethodMap<StepperItemMethodNames>;
/**
 * @public
 */
export declare function provideStepperItemComponent(config?: Partial<StepperItemElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the StepperComponent.
 * Use this token to provide default properties for the StepperComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const STEPPER_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/selectors/stepper/IStepperElementProps").IStepperElementProps>>;
/**
 * @public
 *
 * @slot footer - Custom footer content below the stepper content
 * @slot steps - The stepper item elements (mosaik-stepper-item)
 * @slot  - Default slot for selector item elements
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class StepperComponent {
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<StepperElement['themeName'] | undefined>;
  /**
   * Signal input for the `fit` property.
   *
   * @public
   */
  readonly fit: InputSignal<StepperElement['fit'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<StepperElement['disabled'] | undefined>;
  /**
   * Signal input for the `orientation` property.
   *
   * @public
   */
  readonly orientation: InputSignal<StepperElement['orientation'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<StepperElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<StepperElement['lang'] | undefined>;
  /**
   * Output signal for the `activeStepChanged` event.
   *
   * @public
   */
  readonly activeStepChanged: OutputEmitterRef<ElementEventDetail<StepperElement, 'activeStepChanged'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<StepperElement, 'connected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<StepperElement, 'changed'>>;
  /**
   * Output signal for the `selectionChanged` event.
   *
   * @public
   */
  readonly selectionChanged: OutputEmitterRef<ElementEventDetail<StepperElement, 'selectionChanged'>>;
  /**
   * Output signal for the `itemsChanged` event.
   *
   * @public
   */
  readonly itemsChanged: OutputEmitterRef<ElementEventDetail<StepperElement, 'itemsChanged'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<StepperElement, 'disconnected'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: StepperElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: StepperElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Handles slotted item changes from the Slottable behavior.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<StepperElement['onSlotChanges']>): ReturnType<StepperElement['onSlotChanges']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<StepperElement['assignToSlot']>): ReturnType<StepperElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<StepperElement['getSlotContent']>): ReturnType<StepperElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<StepperElement['hasSlotContent']>): ReturnType<StepperElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<StepperElement['hasSlot']>): ReturnType<StepperElement['hasSlot']>;
  /**
   * Select the item.
   *
   * @public
   * @param args - The arguments of `select`:
   * - `item` - The element, index or value to select.
   */
  select(...args: Parameters<StepperElement['select']>): ReturnType<StepperElement['select']>;
  /**
   * Deselect the item.
   *
   * @public
   * @param args - The arguments of `deselect`:
   * - `item` - The element or index to deselect.
   */
  deselect(...args: Parameters<StepperElement['deselect']>): ReturnType<StepperElement['deselect']>;
  /**
   * Resets the current selection.
   *
   * @public
   */
  resetSelection(...args: Parameters<StepperElement['resetSelection']>): ReturnType<StepperElement['resetSelection']>;
  /**
   * Select the next item after current selected item/index.
   *
   * @public
   */
  selectNext(...args: Parameters<StepperElement['selectNext']>): ReturnType<StepperElement['selectNext']>;
  /**
   * Select the previous item before current selected item/index.
   *
   * @public
   */
  selectPrevious(...args: Parameters<StepperElement['selectPrevious']>): ReturnType<StepperElement['selectPrevious']>;
  /**
   * Select the first item.
   *
   * @public
   */
  selectFirst(...args: Parameters<StepperElement['selectFirst']>): ReturnType<StepperElement['selectFirst']>;
  /**
   * Select the last item.
   *
   * @public
   */
  selectLast(...args: Parameters<StepperElement['selectLast']>): ReturnType<StepperElement['selectLast']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `onSlotChanges()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends StepperMethodNames>(method: TMethod, ...args: Parameters<StepperComponentMethods[TMethod]>): ReturnType<StepperComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof StepperElement>(property: TProperty, value: StepperElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<StepperElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<StepperComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<StepperComponent, "mosaik-stepper", never, {
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "fit": {
      "alias": "fit";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "orientation": {
      "alias": "orientation";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "activeStepChanged": "activeStepChanged";
    "connected": "connected";
    "changed": "changed";
    "selectionChanged": "selectionChanged";
    "itemsChanged": "itemsChanged";
    "disconnected": "disconnected";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on StepperComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type StepperMethodNames = 'onSlotChanges' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'select' | 'deselect' | 'resetSelection' | 'selectNext' | 'selectPrevious' | 'selectFirst' | 'selectLast';
/**
 * Declares the methods interface for StepperComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type StepperComponentMethods = MethodMap<StepperMethodNames>;
/**
 * @public
 */
export declare function provideStepperComponent(config?: Partial<StepperElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-stepper.d.ts.map