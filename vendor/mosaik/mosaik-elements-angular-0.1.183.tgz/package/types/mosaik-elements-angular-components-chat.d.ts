import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef, Type } from "@angular/core";
import { AttachmentChatToolElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/chat/tools/AttachmentChatToolElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import * as i1 from "@pixel-brewery/mosaik-elements-angular/runtime";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { ChatHeaderElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/chat/ChatHeaderElement";
import { ChatMarkerElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/chat/ChatMarkerElement";
import { ChatMessageAvatarElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/chat/ChatMessageAvatarElement";
import { ChatMessageDividerElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/chat/ChatMessageDividerElement";
import { ChatMessageReactionElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/chat/ChatMessageReactionElement";
import { ChatMessageElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/chat/ChatMessageElement";
import { ChatPromptBoxAttachmentListElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/chat/ChatPromptBoxAttachmentListElement";
import { ChatPromptBoxQueueElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/chat/ChatPromptBoxQueueElement";
import { ControlValueAccessor } from "@angular/forms";
import { ChatPromptBoxElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/chat/ChatPromptBoxElement";
import { ChatElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/chat/ChatElement";
import { MentionTextElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/chat/MentionTextElement";
import { MentionElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/chat/MentionElement";
import { ReactionChatToolElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/chat/tools/ReactionChatToolElement";
import { VoiceRecorderChatToolElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/chat/tools/VoiceRecorderChatToolElement";
/**
 * @public
 *
 * Injection token for the default properties of the AttachmentChatToolComponent.
 * Use this token to provide default properties for the AttachmentChatToolComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const ATTACHMENT_CHAT_TOOL_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/inputs/prompt-box/tools/IPromptBoxAttachmentToolElementProps").IPromptBoxAttachmentToolElementProps>>;
/**
 * @public
 *
 * Injection token for the intl configuration of the AttachmentChatToolComponent.
 * Provide a partial intl object or an injectable class that resolves translations.
 * This allows third-party applications to override the default intl labels
 * globally, per route, or per component via Angular's dependency injection.
 *
 * Merge order: Foundation defaults → DI intl → [intl] input binding.
 */
export declare const ATTACHMENT_CHAT_TOOL_INTL: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").PromptBoxAttachmentToolElementIntl>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class AttachmentChatToolComponent {
  /**
   * Signal input for the `multiple` property.
   *
   * @public
   */
  readonly multiple: InputSignal<AttachmentChatToolElement['multiple'] | undefined>;
  /**
   * Signal input for the `accept` property.
   *
   * @public
   */
  readonly accept: InputSignal<AttachmentChatToolElement['accept'] | undefined>;
  /**
   * Signal input for the `directory` property.
   *
   * @public
   */
  readonly directory: InputSignal<AttachmentChatToolElement['directory'] | undefined>;
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<Partial<AttachmentChatToolElement['intl']> | undefined>;
  /**
   * Signal input for the `maxFiles` property.
   *
   * @public
   */
  readonly maxFiles: InputSignal<AttachmentChatToolElement['maxFiles'] | undefined>;
  /**
   * Signal input for the `maxFileSize` property.
   *
   * @public
   */
  readonly maxFileSize: InputSignal<AttachmentChatToolElement['maxFileSize'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<AttachmentChatToolElement['themeName'] | undefined>;
  /**
   * Signal input for the `dock` property.
   *
   * @public
   */
  readonly dock: InputSignal<AttachmentChatToolElement['dock'] | undefined>;
  /**
   * Signal input for the `disabledWhen` property.
   *
   * @public
   */
  readonly disabledWhen: InputSignal<AttachmentChatToolElement['disabledWhen'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<AttachmentChatToolElement['disabled'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<AttachmentChatToolElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<AttachmentChatToolElement['lang'] | undefined>;
  /**
   * Output signal for the `attachmentReject` event.
   *
   * @public
   */
  readonly attachmentReject: OutputEmitterRef<ElementEventDetail<AttachmentChatToolElement, 'attachmentReject'>>;
  /**
   * Output signal for the `filesPicked` event.
   *
   * @public
   */
  readonly filesPicked: OutputEmitterRef<ElementEventDetail<AttachmentChatToolElement, 'filesPicked'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<AttachmentChatToolElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<AttachmentChatToolElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<AttachmentChatToolElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Validates files and adds them to the associated Prompt Box.
   *
   * @public
   */
  execute(...args: Parameters<AttachmentChatToolElement['execute']>): ReturnType<AttachmentChatToolElement['execute']>;
  /**
   * Attaches this tool to a Prompt Box.
   *
   * @public
   */
  attach(...args: Parameters<AttachmentChatToolElement['attach']>): ReturnType<AttachmentChatToolElement['attach']>;
  /**
   * Detaches this tool from a Prompt Box.
   *
   * @public
   */
  detach(...args: Parameters<AttachmentChatToolElement['detach']>): ReturnType<AttachmentChatToolElement['detach']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `execute()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends AttachmentChatToolMethodNames>(method: TMethod, ...args: Parameters<AttachmentChatToolComponentMethods[TMethod]>): ReturnType<AttachmentChatToolComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof AttachmentChatToolElement>(property: TProperty, value: AttachmentChatToolElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<AttachmentChatToolElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<AttachmentChatToolComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AttachmentChatToolComponent, "mosaik-attachment-chat-tool", never, {
    "multiple": {
      "alias": "multiple";
      "required": false;
      "isSignal": true;
    };
    "accept": {
      "alias": "accept";
      "required": false;
      "isSignal": true;
    };
    "directory": {
      "alias": "directory";
      "required": false;
      "isSignal": true;
    };
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "maxFiles": {
      "alias": "maxFiles";
      "required": false;
      "isSignal": true;
    };
    "maxFileSize": {
      "alias": "maxFileSize";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dock": {
      "alias": "dock";
      "required": false;
      "isSignal": true;
    };
    "disabledWhen": {
      "alias": "disabledWhen";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "attachmentReject": "attachmentReject";
    "filesPicked": "filesPicked";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on AttachmentChatToolComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type AttachmentChatToolMethodNames = 'execute' | 'attach' | 'detach';
/**
 * Declares the methods interface for AttachmentChatToolComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type AttachmentChatToolComponentMethods = MethodMap<AttachmentChatToolMethodNames>;
/**
 * @public
 */
export declare function provideAttachmentChatToolComponent(config?: Partial<AttachmentChatToolElement.Props>, intl?: Partial<AttachmentChatToolElement['intl']> | Type<Partial<AttachmentChatToolElement['intl']>>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the ChatHeaderComponent.
 * Use this token to provide default properties for the ChatHeaderComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const CHAT_HEADER_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/media/chat/IChatHeaderElementProps").IChatHeaderElementProps>>;
/**
 * @public
 *
 * @slot after - The content placed at the end of the chat header.
 * @slot before - The content placed at the beginning of the chat header.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ChatHeaderComponent {
  /**
   * Signal input for the `title` property.
   *
   * @public
   */
  readonly title: InputSignal<ChatHeaderElement['title'] | undefined>;
  /**
   * Signal input for the `subTitle` property.
   *
   * @public
   */
  readonly subTitle: InputSignal<ChatHeaderElement['subTitle'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ChatHeaderElement['themeName'] | undefined>;
  /**
   * Signal input for the `formatter` property.
   *
   * @public
   */
  readonly formatter: InputSignal<ChatHeaderElement['formatter'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ChatHeaderElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ChatHeaderElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ChatHeaderElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ChatHeaderElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ChatHeaderElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ChatHeaderElement>(property: TProperty, value: ChatHeaderElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ChatHeaderElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ChatHeaderComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ChatHeaderComponent, "mosaik-chat-header", never, {
    "title": {
      "alias": "title";
      "required": false;
      "isSignal": true;
    };
    "subTitle": {
      "alias": "subTitle";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "formatter": {
      "alias": "formatter";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on ChatHeaderComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ChatHeaderMethodNames = never;
/**
 * Declares the methods interface for ChatHeaderComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ChatHeaderComponentMethods = MethodMap<ChatHeaderMethodNames>;
/**
 * @public
 */
export declare function provideChatHeaderComponent(config?: Partial<ChatHeaderElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the ChatMarkerComponent.
 * Use this token to provide default properties for the ChatMarkerComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const CHAT_MARKER_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/media/chat/IChatMarkerElementProps").IChatMarkerElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ChatMarkerComponent {
  /**
   * Signal input for the `text` property.
   *
   * @public
   */
  readonly text: InputSignal<ChatMarkerElement['text'] | undefined>;
  /**
   * Signal input for the `icon` property.
   *
   * @public
   */
  readonly icon: InputSignal<ChatMarkerElement['icon'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ChatMarkerElement['themeName'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<ChatMarkerElement['variant'] | undefined>;
  /**
   * Signal input for the `orientation` property.
   *
   * @public
   */
  readonly orientation: InputSignal<ChatMarkerElement['orientation'] | undefined>;
  /**
   * Signal input for the `horizontalContentAlignment` property.
   *
   * @public
   */
  readonly horizontalContentAlignment: InputSignal<ChatMarkerElement['horizontalContentAlignment'] | undefined>;
  /**
   * Signal input for the `verticalContentAlignment` property.
   *
   * @public
   */
  readonly verticalContentAlignment: InputSignal<ChatMarkerElement['verticalContentAlignment'] | undefined>;
  /**
   * Signal input for the `isSticky` property.
   *
   * @public
   */
  readonly isSticky: InputSignal<ChatMarkerElement['isSticky'] | undefined>;
  /**
   * Signal input for the `formatter` property.
   *
   * @public
   */
  readonly formatter: InputSignal<ChatMarkerElement['formatter'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<ChatMarkerElement['appearance'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ChatMarkerElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ChatMarkerElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ChatMarkerElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ChatMarkerElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ChatMarkerElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ChatMarkerElement>(property: TProperty, value: ChatMarkerElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ChatMarkerElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ChatMarkerComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ChatMarkerComponent, "mosaik-chat-marker", never, {
    "text": {
      "alias": "text";
      "required": false;
      "isSignal": true;
    };
    "icon": {
      "alias": "icon";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "orientation": {
      "alias": "orientation";
      "required": false;
      "isSignal": true;
    };
    "horizontalContentAlignment": {
      "alias": "horizontalContentAlignment";
      "required": false;
      "isSignal": true;
    };
    "verticalContentAlignment": {
      "alias": "verticalContentAlignment";
      "required": false;
      "isSignal": true;
    };
    "isSticky": {
      "alias": "isSticky";
      "required": false;
      "isSignal": true;
    };
    "formatter": {
      "alias": "formatter";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on ChatMarkerComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ChatMarkerMethodNames = never;
/**
 * Declares the methods interface for ChatMarkerComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ChatMarkerComponentMethods = MethodMap<ChatMarkerMethodNames>;
/**
 * @public
 */
export declare function provideChatMarkerComponent(config?: Partial<ChatMarkerElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the ChatMessageAvatarComponent.
 * Use this token to provide default properties for the ChatMessageAvatarComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const CHAT_MESSAGE_AVATAR_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/media/chat/IChatMessageAvatarElementProps").IChatMessageAvatarElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ChatMessageAvatarComponent {
  /**
   * Signal input for the `text` property.
   *
   * @public
   */
  readonly text: InputSignal<ChatMessageAvatarElement['text'] | undefined>;
  /**
   * Signal input for the `icon` property.
   *
   * @public
   */
  readonly icon: InputSignal<ChatMessageAvatarElement['icon'] | undefined>;
  /**
   * Signal input for the `src` property.
   *
   * @public
   */
  readonly src: InputSignal<ChatMessageAvatarElement['src'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ChatMessageAvatarElement['themeName'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<ChatMessageAvatarElement['appearance'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<ChatMessageAvatarElement['variant'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<ChatMessageAvatarElement['disabled'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ChatMessageAvatarElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ChatMessageAvatarElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ChatMessageAvatarElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ChatMessageAvatarElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ChatMessageAvatarElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ChatMessageAvatarElement>(property: TProperty, value: ChatMessageAvatarElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ChatMessageAvatarElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ChatMessageAvatarComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ChatMessageAvatarComponent, "mosaik-chat-message-avatar", never, {
    "text": {
      "alias": "text";
      "required": false;
      "isSignal": true;
    };
    "icon": {
      "alias": "icon";
      "required": false;
      "isSignal": true;
    };
    "src": {
      "alias": "src";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on ChatMessageAvatarComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ChatMessageAvatarMethodNames = never;
/**
 * Declares the methods interface for ChatMessageAvatarComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ChatMessageAvatarComponentMethods = MethodMap<ChatMessageAvatarMethodNames>;
/**
 * @public
 */
export declare function provideChatMessageAvatarComponent(config?: Partial<ChatMessageAvatarElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the ChatMessageDividerComponent.
 * Use this token to provide default properties for the ChatMessageDividerComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const CHAT_MESSAGE_DIVIDER_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/media/chat/IChatMessageDividerElementProps").IChatMessageDividerElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ChatMessageDividerComponent {
  /**
   * Signal input for the `text` property.
   *
   * @public
   */
  readonly text: InputSignal<ChatMessageDividerElement['text'] | undefined>;
  /**
   * Signal input for the `thickness` property.
   *
   * @public
   */
  readonly thickness: InputSignal<ChatMessageDividerElement['thickness'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ChatMessageDividerElement['themeName'] | undefined>;
  /**
   * Signal input for the `isSticky` property.
   *
   * @public
   */
  readonly isSticky: InputSignal<ChatMessageDividerElement['isSticky'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ChatMessageDividerElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ChatMessageDividerElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ChatMessageDividerElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ChatMessageDividerElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ChatMessageDividerElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ChatMessageDividerElement>(property: TProperty, value: ChatMessageDividerElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ChatMessageDividerElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ChatMessageDividerComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ChatMessageDividerComponent, "mosaik-chat-message-divider", never, {
    "text": {
      "alias": "text";
      "required": false;
      "isSignal": true;
    };
    "thickness": {
      "alias": "thickness";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "isSticky": {
      "alias": "isSticky";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on ChatMessageDividerComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ChatMessageDividerMethodNames = never;
/**
 * Declares the methods interface for ChatMessageDividerComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ChatMessageDividerComponentMethods = MethodMap<ChatMessageDividerMethodNames>;
/**
 * @public
 */
export declare function provideChatMessageDividerComponent(config?: Partial<ChatMessageDividerElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the ChatMessageReactionComponent.
 * Use this token to provide default properties for the ChatMessageReactionComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const CHAT_MESSAGE_REACTION_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/media/chat/IChatMessageReactionElementProps").IChatMessageReactionElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ChatMessageReactionComponent {
  /**
   * Signal input for the `emoji` property.
   *
   * @public
   */
  readonly emoji: InputSignal<ChatMessageReactionElement['emoji'] | undefined>;
  /**
   * Signal input for the `count` property.
   *
   * @public
   */
  readonly count: InputSignal<ChatMessageReactionElement['count'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ChatMessageReactionElement['themeName'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<ChatMessageReactionElement['disabled'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ChatMessageReactionElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ChatMessageReactionElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ChatMessageReactionElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ChatMessageReactionElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ChatMessageReactionElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ChatMessageReactionElement>(property: TProperty, value: ChatMessageReactionElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ChatMessageReactionElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ChatMessageReactionComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ChatMessageReactionComponent, "mosaik-chat-message-reaction", never, {
    "emoji": {
      "alias": "emoji";
      "required": false;
      "isSignal": true;
    };
    "count": {
      "alias": "count";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on ChatMessageReactionComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ChatMessageReactionMethodNames = never;
/**
 * Declares the methods interface for ChatMessageReactionComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ChatMessageReactionComponentMethods = MethodMap<ChatMessageReactionMethodNames>;
/**
 * @public
 */
export declare function provideChatMessageReactionComponent(config?: Partial<ChatMessageReactionElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the ChatMessageComponent.
 * Use this token to provide default properties for the ChatMessageComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const CHAT_MESSAGE_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/media/chat/IChatMessageElementProps").IChatMessageElementProps>>;
/**
 * @public
 *
 * @slot actions - The actions slot.
 * @slot after - Slot for content displayed after the message bubble.
 * @slot at - The slot for timestamp elements.
 * @slot attachment - The slot for attachment elements.
 * @slot author - The slot for author elements.
 * @slot avatar - The slot for avatar elements.
 * @slot before - Content before the message bubble.
 * @slot reaction - The slot for reaction elements.
 * @slot text - The slot for message elements.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ChatMessageComponent {
  /**
   * Signal input for the `attachments` property.
   *
   * @public
   */
  readonly attachments: InputSignal<ChatMessageElement['attachments'] | undefined>;
  /**
   * Signal input for the `author` property.
   *
   * @public
   */
  readonly author: InputSignal<ChatMessageElement['author'] | undefined>;
  /**
   * Signal input for the `text` property.
   *
   * @public
   */
  readonly text: InputSignal<ChatMessageElement['text'] | undefined>;
  /**
   * Signal input for the `at` property.
   *
   * @public
   */
  readonly at: InputSignal<ChatMessageElement['at'] | undefined>;
  /**
   * Signal input for the `reply` property.
   *
   * @public
   */
  readonly reply: InputSignal<ChatMessageElement['reply'] | undefined>;
  /**
   * Signal input for the `mentions` property.
   *
   * @public
   */
  readonly mentions: InputSignal<ChatMessageElement['mentions'] | undefined>;
  /**
   * Signal input for the `mentionCardProvider` property.
   *
   * @public
   */
  readonly mentionCardProvider: InputSignal<ChatMessageElement['mentionCardProvider'] | undefined>;
  /**
   * Signal input for the `isMentionInteractive` property.
   *
   * @public
   */
  readonly isMentionInteractive: InputSignal<ChatMessageElement['isMentionInteractive'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ChatMessageElement['themeName'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<ChatMessageElement['variant'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<ChatMessageElement['appearance'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<ChatMessageElement['disabled'] | undefined>;
  /**
   * Signal input for the `formatter` property.
   *
   * @public
   */
  readonly formatter: InputSignal<ChatMessageElement['formatter'] | undefined>;
  /**
   * Signal input for the `isBusy` property.
   *
   * @public
   */
  readonly isBusy: InputSignal<ChatMessageElement['isBusy'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<ChatMessageElement['value'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ChatMessageElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ChatMessageElement['lang'] | undefined>;
  /**
   * Output signal for the `mentionInvoked` event.
   *
   * @public
   */
  readonly mentionInvoked: OutputEmitterRef<ElementEventDetail<ChatMessageElement, 'mentionInvoked'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ChatMessageElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ChatMessageElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ChatMessageElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: ChatMessageElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: ChatMessageElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<ChatMessageElement['assignToSlot']>): ReturnType<ChatMessageElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<ChatMessageElement['getSlotContent']>): ReturnType<ChatMessageElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<ChatMessageElement['hasSlotContent']>): ReturnType<ChatMessageElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<ChatMessageElement['hasSlot']>): ReturnType<ChatMessageElement['hasSlot']>;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<ChatMessageElement['onSlotChanges']>): ReturnType<ChatMessageElement['onSlotChanges']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `assignToSlot()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends ChatMessageMethodNames>(method: TMethod, ...args: Parameters<ChatMessageComponentMethods[TMethod]>): ReturnType<ChatMessageComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ChatMessageElement>(property: TProperty, value: ChatMessageElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ChatMessageElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ChatMessageComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ChatMessageComponent, "mosaik-chat-message", never, {
    "attachments": {
      "alias": "attachments";
      "required": false;
      "isSignal": true;
    };
    "author": {
      "alias": "author";
      "required": false;
      "isSignal": true;
    };
    "text": {
      "alias": "text";
      "required": false;
      "isSignal": true;
    };
    "at": {
      "alias": "at";
      "required": false;
      "isSignal": true;
    };
    "reply": {
      "alias": "reply";
      "required": false;
      "isSignal": true;
    };
    "mentions": {
      "alias": "mentions";
      "required": false;
      "isSignal": true;
    };
    "mentionCardProvider": {
      "alias": "mentionCardProvider";
      "required": false;
      "isSignal": true;
    };
    "isMentionInteractive": {
      "alias": "isMentionInteractive";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "formatter": {
      "alias": "formatter";
      "required": false;
      "isSignal": true;
    };
    "isBusy": {
      "alias": "isBusy";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "mentionInvoked": "mentionInvoked";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on ChatMessageComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ChatMessageMethodNames = 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges';
/**
 * Declares the methods interface for ChatMessageComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ChatMessageComponentMethods = MethodMap<ChatMessageMethodNames>;
/**
 * @public
 */
export declare function provideChatMessageComponent(config?: Partial<ChatMessageElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the ChatPromptBoxAttachmentListComponent.
 * Use this token to provide default properties for the ChatPromptBoxAttachmentListComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const CHAT_PROMPT_BOX_ATTACHMENT_LIST_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/inputs/prompt-box/attachments/IPromptBoxAttachmentListElementProps").IPromptBoxAttachmentListElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ChatPromptBoxAttachmentListComponent {
  /**
   * Signal input for the `entries` property.
   *
   * @public
   */
  readonly entries: InputSignal<ChatPromptBoxAttachmentListElement['entries'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ChatPromptBoxAttachmentListElement['themeName'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<ChatPromptBoxAttachmentListElement['variant'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<ChatPromptBoxAttachmentListElement['appearance'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<ChatPromptBoxAttachmentListElement['disabled'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ChatPromptBoxAttachmentListElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ChatPromptBoxAttachmentListElement['lang'] | undefined>;
  /**
   * Output signal for the `attachmentRemove` event.
   *
   * @public
   */
  readonly attachmentRemove: OutputEmitterRef<ElementEventDetail<ChatPromptBoxAttachmentListElement, 'attachmentRemove'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ChatPromptBoxAttachmentListElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ChatPromptBoxAttachmentListElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ChatPromptBoxAttachmentListElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: ChatPromptBoxAttachmentListElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: ChatPromptBoxAttachmentListElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   * @param args - The arguments of `assignToSlot`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * - `node` - The nodes to assign to the slot.
   */
  assignToSlot(...args: Parameters<ChatPromptBoxAttachmentListElement['assignToSlot']>): ReturnType<ChatPromptBoxAttachmentListElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   * This method extracts text content recursively, including from Shadow DOMs
   * and Custom Elements with known text properties (like `mosaik-text`).
   *
   * @public
   * @param args - The arguments of `getSlotContent`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<ChatPromptBoxAttachmentListElement['getSlotContent']>): ReturnType<ChatPromptBoxAttachmentListElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @param args - The arguments of `hasSlotContent`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<ChatPromptBoxAttachmentListElement['hasSlotContent']>): ReturnType<ChatPromptBoxAttachmentListElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @param args - The arguments of `hasSlot`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<ChatPromptBoxAttachmentListElement['hasSlot']>): ReturnType<ChatPromptBoxAttachmentListElement['hasSlot']>;
  /**
   * Called when the slot changes.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<ChatPromptBoxAttachmentListElement['onSlotChanges']>): ReturnType<ChatPromptBoxAttachmentListElement['onSlotChanges']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `assignToSlot()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends ChatPromptBoxAttachmentListMethodNames>(method: TMethod, ...args: Parameters<ChatPromptBoxAttachmentListComponentMethods[TMethod]>): ReturnType<ChatPromptBoxAttachmentListComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ChatPromptBoxAttachmentListElement>(property: TProperty, value: ChatPromptBoxAttachmentListElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ChatPromptBoxAttachmentListElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ChatPromptBoxAttachmentListComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ChatPromptBoxAttachmentListComponent, "mosaik-chat-prompt-box-attachment-list", never, {
    "entries": {
      "alias": "entries";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "attachmentRemove": "attachmentRemove";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on ChatPromptBoxAttachmentListComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ChatPromptBoxAttachmentListMethodNames = 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges';
/**
 * Declares the methods interface for ChatPromptBoxAttachmentListComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ChatPromptBoxAttachmentListComponentMethods = MethodMap<ChatPromptBoxAttachmentListMethodNames>;
/**
 * @public
 */
export declare function provideChatPromptBoxAttachmentListComponent(config?: Partial<ChatPromptBoxAttachmentListElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the ChatPromptBoxQueueComponent.
 * Use this token to provide default properties for the ChatPromptBoxQueueComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const CHAT_PROMPT_BOX_QUEUE_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").IPromptBoxQueueElementProps>>;
/**
 * @public
 *
 * Injection token for the intl configuration of the ChatPromptBoxQueueComponent.
 * Provide a partial intl object or an injectable class that resolves translations.
 * This allows third-party applications to override the default intl labels
 * globally, per route, or per component via Angular's dependency injection.
 *
 * Merge order: Foundation defaults → DI intl → [intl] input binding.
 */
export declare const CHAT_PROMPT_BOX_QUEUE_INTL: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").PromptBoxQueueElementIntl>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ChatPromptBoxQueueComponent {
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<Partial<ChatPromptBoxQueueElement['intl']> | undefined>;
  /**
   * Signal input for the `entries` property.
   *
   * @public
   */
  readonly entries: InputSignal<ChatPromptBoxQueueElement['entries'] | undefined>;
  /**
   * Signal input for the `reorderable` property.
   *
   * @public
   */
  readonly reorderable: InputSignal<ChatPromptBoxQueueElement['reorderable'] | undefined>;
  /**
   * Signal input for the `steerable` property.
   *
   * @public
   */
  readonly steerable: InputSignal<ChatPromptBoxQueueElement['steerable'] | undefined>;
  /**
   * Signal input for the `editable` property.
   *
   * @public
   */
  readonly editable: InputSignal<ChatPromptBoxQueueElement['editable'] | undefined>;
  /**
   * Signal input for the `pausable` property.
   *
   * @public
   */
  readonly pausable: InputSignal<ChatPromptBoxQueueElement['pausable'] | undefined>;
  /**
   * Signal input for the `actions` property.
   *
   * @public
   */
  readonly actions: InputSignal<ChatPromptBoxQueueElement['actions'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ChatPromptBoxQueueElement['themeName'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<ChatPromptBoxQueueElement['variant'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<ChatPromptBoxQueueElement['appearance'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<ChatPromptBoxQueueElement['disabled'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ChatPromptBoxQueueElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ChatPromptBoxQueueElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ChatPromptBoxQueueElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ChatPromptBoxQueueElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ChatPromptBoxQueueElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: ChatPromptBoxQueueElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: ChatPromptBoxQueueElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   * @param args - The arguments of `assignToSlot`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * - `node` - The nodes to assign to the slot.
   */
  assignToSlot(...args: Parameters<ChatPromptBoxQueueElement['assignToSlot']>): ReturnType<ChatPromptBoxQueueElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   * This method extracts text content recursively, including from Shadow DOMs
   * and Custom Elements with known text properties (like `mosaik-text`).
   *
   * @public
   * @param args - The arguments of `getSlotContent`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<ChatPromptBoxQueueElement['getSlotContent']>): ReturnType<ChatPromptBoxQueueElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @param args - The arguments of `hasSlotContent`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<ChatPromptBoxQueueElement['hasSlotContent']>): ReturnType<ChatPromptBoxQueueElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @param args - The arguments of `hasSlot`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<ChatPromptBoxQueueElement['hasSlot']>): ReturnType<ChatPromptBoxQueueElement['hasSlot']>;
  /**
   * Called when the slot changes.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<ChatPromptBoxQueueElement['onSlotChanges']>): ReturnType<ChatPromptBoxQueueElement['onSlotChanges']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `assignToSlot()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends ChatPromptBoxQueueMethodNames>(method: TMethod, ...args: Parameters<ChatPromptBoxQueueComponentMethods[TMethod]>): ReturnType<ChatPromptBoxQueueComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ChatPromptBoxQueueElement>(property: TProperty, value: ChatPromptBoxQueueElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ChatPromptBoxQueueElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ChatPromptBoxQueueComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ChatPromptBoxQueueComponent, "mosaik-chat-prompt-box-queue", never, {
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "entries": {
      "alias": "entries";
      "required": false;
      "isSignal": true;
    };
    "reorderable": {
      "alias": "reorderable";
      "required": false;
      "isSignal": true;
    };
    "steerable": {
      "alias": "steerable";
      "required": false;
      "isSignal": true;
    };
    "editable": {
      "alias": "editable";
      "required": false;
      "isSignal": true;
    };
    "pausable": {
      "alias": "pausable";
      "required": false;
      "isSignal": true;
    };
    "actions": {
      "alias": "actions";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on ChatPromptBoxQueueComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ChatPromptBoxQueueMethodNames = 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges';
/**
 * Declares the methods interface for ChatPromptBoxQueueComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ChatPromptBoxQueueComponentMethods = MethodMap<ChatPromptBoxQueueMethodNames>;
/**
 * @public
 */
export declare function provideChatPromptBoxQueueComponent(config?: Partial<ChatPromptBoxQueueElement.Props>, intl?: Partial<ChatPromptBoxQueueElement['intl']> | Type<Partial<ChatPromptBoxQueueElement['intl']>>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the ChatPromptBoxComponent.
 * Use this token to provide default properties for the ChatPromptBoxComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const CHAT_PROMPT_BOX_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").IPromptBoxBaseElementProps>>;
/**
 * @public
 *
 * Injection token for the intl configuration of the ChatPromptBoxComponent.
 * Provide a partial intl object or an injectable class that resolves translations.
 * This allows third-party applications to override the default intl labels
 * globally, per route, or per component via Angular's dependency injection.
 *
 * Merge order: Foundation defaults → DI intl → [intl] input binding.
 */
export declare const CHAT_PROMPT_BOX_INTL: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").PromptBoxElementIntl>>;
/**
 * @public
 *
 * @slot header - Optional content shown on a strip of its own above the box.
 * @slot content - Arbitrary reference content displayed above the editor.
 * @slot editor - An editor that replaces the native one, e.g. a `mosaik-richtextbox` with mentions.
 * @slot tools - Prompt Box tools and chat-specific actions.
 * @slot top - Optional content shown above the header, without a surface of its own.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ChatPromptBoxComponent implements ControlValueAccessor {
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<Partial<ChatPromptBoxElement['intl']> | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<ChatPromptBoxElement['value'] | undefined>;
  /**
   * Signal input for the `mentionDocument` property.
   *
   * @public
   */
  readonly mentionDocument: InputSignal<ChatPromptBoxElement['mentionDocument'] | undefined>;
  /**
   * Signal input for the `suggestions` property.
   *
   * @public
   */
  readonly suggestions: InputSignal<ChatPromptBoxElement['suggestions'] | undefined>;
  /**
   * Signal input for the `entries` property.
   *
   * @public
   */
  readonly entries: InputSignal<ChatPromptBoxElement['entries'] | undefined>;
  /**
   * Signal input for the `queue` property.
   *
   * @public
   */
  readonly queue: InputSignal<ChatPromptBoxElement['queue'] | undefined>;
  /**
   * Signal input for the `queueOnBusy` property.
   *
   * @public
   */
  readonly queueOnBusy: InputSignal<ChatPromptBoxElement['queueOnBusy'] | undefined>;
  /**
   * Signal input for the `queuePaused` property.
   *
   * @public
   */
  readonly queuePaused: InputSignal<ChatPromptBoxElement['queuePaused'] | undefined>;
  /**
   * Signal input for the `tools` property.
   *
   * @public
   */
  readonly tools: InputSignal<ChatPromptBoxElement['tools'] | undefined>;
  /**
   * Signal input for the `placeholder` property.
   *
   * @public
   */
  readonly placeholder: InputSignal<ChatPromptBoxElement['placeholder'] | undefined>;
  /**
   * Signal input for the `minRows` property.
   *
   * @public
   */
  readonly minRows: InputSignal<ChatPromptBoxElement['minRows'] | undefined>;
  /**
   * Signal input for the `maxRows` property.
   *
   * @public
   */
  readonly maxRows: InputSignal<ChatPromptBoxElement['maxRows'] | undefined>;
  /**
   * Signal input for the `showSubmitButton` property.
   *
   * @public
   */
  readonly showSubmitButton: InputSignal<ChatPromptBoxElement['showSubmitButton'] | undefined>;
  /**
   * Signal input for the `submitOnEnter` property.
   *
   * @public
   */
  readonly submitOnEnter: InputSignal<ChatPromptBoxElement['submitOnEnter'] | undefined>;
  /**
   * Signal input for the `readonly` property.
   *
   * @public
   */
  readonly readonly: InputSignal<ChatPromptBoxElement['readonly'] | undefined>;
  /**
   * Signal input for the `required` property.
   *
   * @public
   */
  readonly required: InputSignal<ChatPromptBoxElement['required'] | undefined>;
  /**
   * Signal input for the `autofocus` property.
   *
   * @public
   */
  readonly autofocus: InputSignal<ChatPromptBoxElement['autofocus'] | undefined>;
  /**
   * Signal input for the `name` property.
   *
   * @public
   */
  readonly name: InputSignal<ChatPromptBoxElement['name'] | undefined>;
  /**
   * Signal input for the `minlength` property.
   *
   * @public
   */
  readonly minlength: InputSignal<ChatPromptBoxElement['minlength'] | undefined>;
  /**
   * Signal input for the `maxlength` property.
   *
   * @public
   */
  readonly maxlength: InputSignal<ChatPromptBoxElement['maxlength'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ChatPromptBoxElement['themeName'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<ChatPromptBoxElement['appearance'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<ChatPromptBoxElement['variant'] | undefined>;
  /**
   * Signal input for the `isBusy` property.
   *
   * @public
   */
  readonly isBusy: InputSignal<ChatPromptBoxElement['isBusy'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<ChatPromptBoxElement['disabled'] | undefined>;
  /**
   * Signal input for the `formatter` property.
   *
   * @public
   */
  readonly formatter: InputSignal<ChatPromptBoxElement['formatter'] | undefined>;
  /**
   * Signal input for the `parser` property.
   *
   * @public
   */
  readonly parser: InputSignal<ChatPromptBoxElement['parser'] | undefined>;
  /**
   * Signal input for the `isFocused` property.
   *
   * @public
   */
  readonly isFocused: InputSignal<ChatPromptBoxElement['isFocused'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ChatPromptBoxElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ChatPromptBoxElement['lang'] | undefined>;
  /**
   * Output signal for the `entriesChanged` event.
   *
   * @public
   */
  readonly entriesChanged: OutputEmitterRef<ElementEventDetail<ChatPromptBoxElement, 'entriesChanged'>>;
  /**
   * Output signal for the `promptQueued` event.
   *
   * @public
   */
  readonly promptQueued: OutputEmitterRef<ElementEventDetail<ChatPromptBoxElement, 'promptQueued'>>;
  /**
   * Output signal for the `promptSubmitted` event.
   *
   * @public
   */
  readonly promptSubmitted: OutputEmitterRef<ElementEventDetail<ChatPromptBoxElement, 'promptSubmitted'>>;
  /**
   * Output signal for the `queueChanged` event.
   *
   * @public
   */
  readonly queueChanged: OutputEmitterRef<ElementEventDetail<ChatPromptBoxElement, 'queueChanged'>>;
  /**
   * Output signal for the `stopRequested` event.
   *
   * @public
   */
  readonly stopRequested: OutputEmitterRef<ElementEventDetail<ChatPromptBoxElement, 'stopRequested'>>;
  /**
   * Output signal for the `steerRequested` event.
   *
   * @public
   */
  readonly steerRequested: OutputEmitterRef<ElementEventDetail<ChatPromptBoxElement, 'steerRequested'>>;
  /**
   * Output signal for the `queuePausedChanged` event.
   *
   * @public
   */
  readonly queuePausedChanged: OutputEmitterRef<ElementEventDetail<ChatPromptBoxElement, 'queuePausedChanged'>>;
  /**
   * Output signal for the `queueActionInvoked` event.
   *
   * @public
   */
  readonly queueActionInvoked: OutputEmitterRef<ElementEventDetail<ChatPromptBoxElement, 'queueActionInvoked'>>;
  /**
   * Output signal for the `suggestionSelected` event.
   *
   * @public
   */
  readonly suggestionSelected: OutputEmitterRef<ElementEventDetail<ChatPromptBoxElement, 'suggestionSelected'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ChatPromptBoxElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ChatPromptBoxElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ChatPromptBoxElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: ChatPromptBoxElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: ChatPromptBoxElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  private readonly _accessor;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Applies a value supplied by Angular forms to the native control.
   *
   * @public
   */
  writeValue(obj: unknown): void;
  /**
   * Registers the callback notified when the native control value changes.
   *
   * @public
   */
  registerOnChange(fn: unknown): void;
  /**
   * Registers the callback notified when the native control is touched.
   *
   * @public
   */
  registerOnTouched(fn: unknown): void;
  /**
   * Applies the disabled state supplied by Angular forms.
   *
   * @public
   */
  setDisabledState?(isDisabled: boolean): void;
  /**
   * Registers a tool and returns an idempotent disposer.
   *
   * @public
   */
  registerTool(...args: Parameters<ChatPromptBoxElement['registerTool']>): ReturnType<ChatPromptBoxElement['registerTool']>;
  /**
   * Unregisters one registration of a tool.
   *
   * @public
   */
  unregisterTool(...args: Parameters<ChatPromptBoxElement['unregisterTool']>): ReturnType<ChatPromptBoxElement['unregisterTool']>;
  /**
   * Adds an entry.
   *
   * @public
   */
  addEntry(...args: Parameters<ChatPromptBoxElement['addEntry']>): ReturnType<ChatPromptBoxElement['addEntry']>;
  /**
   * Replaces an existing entry with the same identifier.
   *
   * @public
   * @returns `true` when an entry was replaced.
   */
  updateEntry(...args: Parameters<ChatPromptBoxElement['updateEntry']>): ReturnType<ChatPromptBoxElement['updateEntry']>;
  /**
   * Removes an entry by identifier.
   *
   * @public
   * @returns `true` when an entry was removed.
   */
  removeEntry(...args: Parameters<ChatPromptBoxElement['removeEntry']>): ReturnType<ChatPromptBoxElement['removeEntry']>;
  /**
   * Removes every entry.
   *
   * @public
   */
  clearEntries(...args: Parameters<ChatPromptBoxElement['clearEntries']>): ReturnType<ChatPromptBoxElement['clearEntries']>;
  /**
   * Appends a prompt to the queue.
   *
   * @public
   * @returns The queued prompt.
   */
  enqueue(...args: Parameters<ChatPromptBoxElement['enqueue']>): ReturnType<ChatPromptBoxElement['enqueue']>;
  /**
   * Removes and returns the prompt at the head of the queue.
   *
   * @public
   * @returns The prompt that was waiting, or `null` when the queue is empty or paused.
   */
  dequeue(...args: Parameters<ChatPromptBoxElement['dequeue']>): ReturnType<ChatPromptBoxElement['dequeue']>;
  /**
   * Returns the prompt at the head of the queue without removing it.
   *
   * @public
   */
  peekQueue(...args: Parameters<ChatPromptBoxElement['peekQueue']>): ReturnType<ChatPromptBoxElement['peekQueue']>;
  /**
   * Removes a queued prompt by identifier.
   *
   * @public
   * @returns `true` when a prompt was removed.
   */
  removeQueued(...args: Parameters<ChatPromptBoxElement['removeQueued']>): ReturnType<ChatPromptBoxElement['removeQueued']>;
  /**
   * Moves a queued prompt to another position.
   *
   * @public
   * @param args - The arguments of `moveQueued`:
   * - `entryId` - The prompt to move.
   * - `toIndex` - The position it should end up at.
   * @returns `true` when the queue order changed.
   */
  moveQueued(...args: Parameters<ChatPromptBoxElement['moveQueued']>): ReturnType<ChatPromptBoxElement['moveQueued']>;
  /**
   * Removes every queued prompt.
   *
   * @public
   */
  clearQueue(...args: Parameters<ChatPromptBoxElement['clearQueue']>): ReturnType<ChatPromptBoxElement['clearQueue']>;
  /**
   * Asks the consumer to steer the prompt it is busy with using a queued
   * prompt.
   *
   * @public
   * @param args - The arguments of `steerQueued`:
   * - `entryId` - The queued prompt that should steer.
   * @returns `true` when a steer was requested.
   */
  steerQueued(...args: Parameters<ChatPromptBoxElement['steerQueued']>): ReturnType<ChatPromptBoxElement['steerQueued']>;
  /**
   * Takes a queued prompt back into the editor.
   *
   * @public
   * @param args - The arguments of `editQueued`:
   * - `entryId` - The queued prompt to edit.
   * @returns `true` when a prompt was taken back into the editor.
   */
  editQueued(...args: Parameters<ChatPromptBoxElement['editQueued']>): ReturnType<ChatPromptBoxElement['editQueued']>;
  /**
   * Raises an application-defined action for a queued prompt.
   *
   * @public
   * @param args - The arguments of `invokeQueuedAction`:
   * - `action` - The action that was chosen.
   * - `entryId` - The queued prompt the action was chosen on.
   * @returns `true` when the action was raised.
   */
  invokeQueuedAction(...args: Parameters<ChatPromptBoxElement['invokeQueuedAction']>): ReturnType<ChatPromptBoxElement['invokeQueuedAction']>;
  /**
   * Clears the text and entry collection.
   *
   * @public
   */
  clear(...args: Parameters<ChatPromptBoxElement['clear']>): ReturnType<ChatPromptBoxElement['clear']>;
  /**
   * Resets the value and validation state.
   *
   * @public
   */
  reset(...args: Parameters<ChatPromptBoxElement['reset']>): ReturnType<ChatPromptBoxElement['reset']>;
  /**
   * Checks the native editor validity.
   *
   * @public
   */
  checkValidity(...args: Parameters<ChatPromptBoxElement['checkValidity']>): ReturnType<ChatPromptBoxElement['checkValidity']>;
  /**
   * Submits the current prompt, or queues it while the Prompt Box is busy.
   *
   * @public
   * @returns `true` when a prompt was submitted or queued.
   */
  submit(...args: Parameters<ChatPromptBoxElement['submit']>): ReturnType<ChatPromptBoxElement['submit']>;
  /**
   * Asks the consumer to stop the prompt it is busy with.
   *
   * @public
   * @returns `true` when a stop was requested.
   */
  stop(...args: Parameters<ChatPromptBoxElement['stop']>): ReturnType<ChatPromptBoxElement['stop']>;
  /**
   * Sets focus to the native editor.
   *
   * @public
   */
  focus(...args: Parameters<ChatPromptBoxElement['focus']>): ReturnType<ChatPromptBoxElement['focus']>;
  /**
   * Removes focus from the native editor.
   *
   * @public
   */
  blur(...args: Parameters<ChatPromptBoxElement['blur']>): ReturnType<ChatPromptBoxElement['blur']>;
  /**
   * Reconciles automatically slotted Web Component tools.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<ChatPromptBoxElement['onSlotChanges']>): ReturnType<ChatPromptBoxElement['onSlotChanges']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<ChatPromptBoxElement['assignToSlot']>): ReturnType<ChatPromptBoxElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<ChatPromptBoxElement['getSlotContent']>): ReturnType<ChatPromptBoxElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<ChatPromptBoxElement['hasSlotContent']>): ReturnType<ChatPromptBoxElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<ChatPromptBoxElement['hasSlot']>): ReturnType<ChatPromptBoxElement['hasSlot']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `registerTool()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * The other names it accepts are not public in the type declarations of `ChatPromptBoxElement`.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends ChatPromptBoxMethodNames>(method: TMethod, ...args: Parameters<ChatPromptBoxComponentMethods[TMethod]>): ReturnType<ChatPromptBoxComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ChatPromptBoxElement>(property: TProperty, value: ChatPromptBoxElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ChatPromptBoxElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ChatPromptBoxComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ChatPromptBoxComponent, "mosaik-chat-prompt-box", never, {
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "mentionDocument": {
      "alias": "mentionDocument";
      "required": false;
      "isSignal": true;
    };
    "suggestions": {
      "alias": "suggestions";
      "required": false;
      "isSignal": true;
    };
    "entries": {
      "alias": "entries";
      "required": false;
      "isSignal": true;
    };
    "queue": {
      "alias": "queue";
      "required": false;
      "isSignal": true;
    };
    "queueOnBusy": {
      "alias": "queueOnBusy";
      "required": false;
      "isSignal": true;
    };
    "queuePaused": {
      "alias": "queuePaused";
      "required": false;
      "isSignal": true;
    };
    "tools": {
      "alias": "tools";
      "required": false;
      "isSignal": true;
    };
    "placeholder": {
      "alias": "placeholder";
      "required": false;
      "isSignal": true;
    };
    "minRows": {
      "alias": "minRows";
      "required": false;
      "isSignal": true;
    };
    "maxRows": {
      "alias": "maxRows";
      "required": false;
      "isSignal": true;
    };
    "showSubmitButton": {
      "alias": "showSubmitButton";
      "required": false;
      "isSignal": true;
    };
    "submitOnEnter": {
      "alias": "submitOnEnter";
      "required": false;
      "isSignal": true;
    };
    "readonly": {
      "alias": "readonly";
      "required": false;
      "isSignal": true;
    };
    "required": {
      "alias": "required";
      "required": false;
      "isSignal": true;
    };
    "autofocus": {
      "alias": "autofocus";
      "required": false;
      "isSignal": true;
    };
    "name": {
      "alias": "name";
      "required": false;
      "isSignal": true;
    };
    "minlength": {
      "alias": "minlength";
      "required": false;
      "isSignal": true;
    };
    "maxlength": {
      "alias": "maxlength";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "isBusy": {
      "alias": "isBusy";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "formatter": {
      "alias": "formatter";
      "required": false;
      "isSignal": true;
    };
    "parser": {
      "alias": "parser";
      "required": false;
      "isSignal": true;
    };
    "isFocused": {
      "alias": "isFocused";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "entriesChanged": "entriesChanged";
    "promptQueued": "promptQueued";
    "promptSubmitted": "promptSubmitted";
    "queueChanged": "queueChanged";
    "stopRequested": "stopRequested";
    "steerRequested": "steerRequested";
    "queuePausedChanged": "queuePausedChanged";
    "queueActionInvoked": "queueActionInvoked";
    "suggestionSelected": "suggestionSelected";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, [{
    directive: typeof i1.FormStatusHostDirective;
    inputs: {};
    outputs: {};
  }, {
    directive: typeof i1.FormFieldStatusHostDirective;
    inputs: {};
    outputs: {};
  }]>;
}
/**
 * Declares the methods available on ChatPromptBoxComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ChatPromptBoxMethodNames = 'registerTool' | 'unregisterTool' | 'addEntry' | 'updateEntry' | 'removeEntry' | 'clearEntries' | 'enqueue' | 'dequeue' | 'peekQueue' | 'removeQueued' | 'moveQueued' | 'clearQueue' | 'steerQueued' | 'editQueued' | 'invokeQueuedAction' | 'clear' | 'reset' | 'checkValidity' | 'submit' | 'stop' | 'focus' | 'blur' | 'onInput' | 'onFocus' | 'onBlur' | 'onSlotChanges' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot';
/**
 * Declares the methods interface for ChatPromptBoxComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ChatPromptBoxComponentMethods = MethodMap<ChatPromptBoxMethodNames>;
/**
 * @public
 */
export declare function provideChatPromptBoxComponent(config?: Partial<ChatPromptBoxElement.Props>, intl?: Partial<ChatPromptBoxElement['intl']> | Type<Partial<ChatPromptBoxElement['intl']>>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the ChatComponent.
 * Use this token to provide default properties for the ChatComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const CHAT_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/media/chat/IChatElementProps").IChatElementProps>>;
/**
 * @public
 *
 * Injection token for the intl configuration of the ChatComponent.
 * Provide a partial intl object or an injectable class that resolves translations.
 * This allows third-party applications to override the default intl labels
 * globally, per route, or per component via Angular's dependency injection.
 *
 * Merge order: Foundation defaults → DI intl → [intl] input binding.
 */
export declare const CHAT_INTL: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").ChatElementIntl>>;
/**
 * @public
 *
 * @slot empty - Content shown in place of the message viewport while the message slot is empty.
 * @slot header - Slot for chat header content.
 * @slot input - Slot for the Chat Prompt Box. A prompt box without its own placeholder shows the chat's `intl.inputPlaceholder`.
 * @slot message - Slot for chat message elements.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ChatComponent {
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<Partial<ChatElement['intl']> | undefined>;
  /**
   * Signal input for the `scrollToEnd` property.
   *
   * @public
   */
  readonly scrollToEnd: InputSignal<ChatElement['scrollToEnd'] | undefined>;
  /**
   * Signal input for the `scrollToEndThreshold` property.
   *
   * @public
   */
  readonly scrollToEndThreshold: InputSignal<ChatElement['scrollToEndThreshold'] | undefined>;
  /**
   * Signal input for the `begin` property.
   *
   * @public
   */
  readonly begin: InputSignal<ChatElement['begin'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ChatElement['themeName'] | undefined>;
  /**
   * Signal input for the `width` property.
   *
   * @public
   */
  readonly width: InputSignal<ChatElement['width'] | undefined>;
  /**
   * Signal input for the `height` property.
   *
   * @public
   */
  readonly height: InputSignal<ChatElement['height'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<ChatElement['appearance'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<ChatElement['variant'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ChatElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ChatElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ChatElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ChatElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ChatElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: ChatElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: ChatElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   * @param args - The arguments of `onSlotChanges`:
   * - `slotName` - The optional slot name (For default slot, passes undefined).
   */
  onSlotChanges(...args: Parameters<ChatElement['onSlotChanges']>): ReturnType<ChatElement['onSlotChanges']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<ChatElement['assignToSlot']>): ReturnType<ChatElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<ChatElement['getSlotContent']>): ReturnType<ChatElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<ChatElement['hasSlotContent']>): ReturnType<ChatElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<ChatElement['hasSlot']>): ReturnType<ChatElement['hasSlot']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `onSlotChanges()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends ChatMethodNames>(method: TMethod, ...args: Parameters<ChatComponentMethods[TMethod]>): ReturnType<ChatComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ChatElement>(property: TProperty, value: ChatElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ChatElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ChatComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ChatComponent, "mosaik-chat", never, {
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "scrollToEnd": {
      "alias": "scrollToEnd";
      "required": false;
      "isSignal": true;
    };
    "scrollToEndThreshold": {
      "alias": "scrollToEndThreshold";
      "required": false;
      "isSignal": true;
    };
    "begin": {
      "alias": "begin";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "width": {
      "alias": "width";
      "required": false;
      "isSignal": true;
    };
    "height": {
      "alias": "height";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on ChatComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ChatMethodNames = 'onSlotChanges' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot';
/**
 * Declares the methods interface for ChatComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ChatComponentMethods = MethodMap<ChatMethodNames>;
/**
 * @public
 */
export declare function provideChatComponent(config?: Partial<ChatElement.Props>, intl?: Partial<ChatElement['intl']> | Type<Partial<ChatElement['intl']>>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the MentionTextComponent.
 * Use this token to provide default properties for the MentionTextComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const MENTION_TEXT_DEFAULT_PROPS: InjectionToken<Partial<MentionTextElement.Props>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class MentionTextComponent {
  /**
   * Signal input for the `document` property.
   *
   * @public
   */
  readonly document: InputSignal<MentionTextElement['document'] | undefined>;
  /**
   * Signal input for the `isInteractive` property.
   *
   * @public
   */
  readonly isInteractive: InputSignal<MentionTextElement['isInteractive'] | undefined>;
  /**
   * Signal input for the `cardProvider` property.
   *
   * @public
   */
  readonly cardProvider: InputSignal<MentionTextElement['cardProvider'] | undefined>;
  /**
   * Signal input for the `formatter` property.
   *
   * @public
   */
  readonly formatter: InputSignal<MentionTextElement['formatter'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<MentionTextElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<MentionTextElement['lang'] | undefined>;
  /**
   * Output signal for the `mentionInvoked` event.
   *
   * @public
   */
  readonly mentionInvoked: OutputEmitterRef<ElementEventDetail<MentionTextElement, 'mentionInvoked'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<MentionTextElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<MentionTextElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<MentionTextElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof MentionTextElement>(property: TProperty, value: MentionTextElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<MentionTextElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<MentionTextComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<MentionTextComponent, "mosaik-mention-text", never, {
    "document": {
      "alias": "document";
      "required": false;
      "isSignal": true;
    };
    "isInteractive": {
      "alias": "isInteractive";
      "required": false;
      "isSignal": true;
    };
    "cardProvider": {
      "alias": "cardProvider";
      "required": false;
      "isSignal": true;
    };
    "formatter": {
      "alias": "formatter";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "mentionInvoked": "mentionInvoked";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on MentionTextComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type MentionTextMethodNames = never;
/**
 * Declares the methods interface for MentionTextComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type MentionTextComponentMethods = MethodMap<MentionTextMethodNames>;
/**
 * @public
 */
export declare function provideMentionTextComponent(config?: Partial<MentionTextElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the MentionComponent.
 * Use this token to provide default properties for the MentionComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const MENTION_DEFAULT_PROPS: InjectionToken<Partial<MentionElement.Props>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class MentionComponent {
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<MentionElement['label'] | undefined>;
  /**
   * Signal input for the `referenceId` property.
   *
   * @public
   */
  readonly referenceId: InputSignal<MentionElement['referenceId'] | undefined>;
  /**
   * Signal input for the `trigger` property.
   *
   * @public
   */
  readonly trigger: InputSignal<MentionElement['trigger'] | undefined>;
  /**
   * Signal input for the `tone` property.
   *
   * @public
   */
  readonly tone: InputSignal<MentionElement['tone'] | undefined>;
  /**
   * Signal input for the `kind` property.
   *
   * @public
   */
  readonly kind: InputSignal<MentionElement['kind'] | undefined>;
  /**
   * Signal input for the `isInteractive` property.
   *
   * @public
   */
  readonly isInteractive: InputSignal<MentionElement['isInteractive'] | undefined>;
  /**
   * Signal input for the `cardProvider` property.
   *
   * @public
   */
  readonly cardProvider: InputSignal<MentionElement['cardProvider'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<MentionElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<MentionElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<MentionElement['lang'] | undefined>;
  /**
   * Output signal for the `mentionInvoked` event.
   *
   * @public
   */
  readonly mentionInvoked: OutputEmitterRef<ElementEventDetail<MentionElement, 'mentionInvoked'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<MentionElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<MentionElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<MentionElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated The names it accepts are not public in the type declarations of `MentionElement`, so there is no typed
   * replacement for them.
   * `invoke` shares its name with another member of the component and is called on `elementRef.nativeElement` instead.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends MentionMethodNames>(method: TMethod, ...args: Parameters<MentionComponentMethods[TMethod]>): ReturnType<MentionComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof MentionElement>(property: TProperty, value: MentionElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<MentionElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<MentionComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<MentionComponent, "mosaik-mention", never, {
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "referenceId": {
      "alias": "referenceId";
      "required": false;
      "isSignal": true;
    };
    "trigger": {
      "alias": "trigger";
      "required": false;
      "isSignal": true;
    };
    "tone": {
      "alias": "tone";
      "required": false;
      "isSignal": true;
    };
    "kind": {
      "alias": "kind";
      "required": false;
      "isSignal": true;
    };
    "isInteractive": {
      "alias": "isInteractive";
      "required": false;
      "isSignal": true;
    };
    "cardProvider": {
      "alias": "cardProvider";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "mentionInvoked": "mentionInvoked";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on MentionComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type MentionMethodNames = 'invoke';
/**
 * Declares the methods interface for MentionComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type MentionComponentMethods = MethodMap<MentionMethodNames>;
/**
 * @public
 */
export declare function provideMentionComponent(config?: Partial<MentionElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the ReactionChatToolComponent.
 * Use this token to provide default properties for the ReactionChatToolComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const REACTION_CHAT_TOOL_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/media/chat/tools/IReactionChatToolElementProps").IReactionChatToolElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ReactionChatToolComponent {
  /**
   * Signal input for the `reactions` property.
   *
   * @public
   */
  readonly reactions: InputSignal<ReactionChatToolElement['reactions'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ReactionChatToolElement['themeName'] | undefined>;
  /**
   * Signal input for the `dock` property.
   *
   * @public
   */
  readonly dock: InputSignal<ReactionChatToolElement['dock'] | undefined>;
  /**
   * Signal input for the `disabledWhen` property.
   *
   * @public
   */
  readonly disabledWhen: InputSignal<ReactionChatToolElement['disabledWhen'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<ReactionChatToolElement['disabled'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ReactionChatToolElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ReactionChatToolElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ReactionChatToolElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ReactionChatToolElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ReactionChatToolElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Executes the tool.
   *
   * @public
   */
  execute(...args: Parameters<ReactionChatToolElement['execute']>): ReturnType<ReactionChatToolElement['execute']>;
  /**
   * Attaches this tool to a Prompt Box.
   *
   * @public
   */
  attach(...args: Parameters<ReactionChatToolElement['attach']>): ReturnType<ReactionChatToolElement['attach']>;
  /**
   * Detaches this tool from a Prompt Box.
   *
   * @public
   */
  detach(...args: Parameters<ReactionChatToolElement['detach']>): ReturnType<ReactionChatToolElement['detach']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `execute()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends ReactionChatToolMethodNames>(method: TMethod, ...args: Parameters<ReactionChatToolComponentMethods[TMethod]>): ReturnType<ReactionChatToolComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ReactionChatToolElement>(property: TProperty, value: ReactionChatToolElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ReactionChatToolElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ReactionChatToolComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ReactionChatToolComponent, "mosaik-reaction-chat-tool", never, {
    "reactions": {
      "alias": "reactions";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dock": {
      "alias": "dock";
      "required": false;
      "isSignal": true;
    };
    "disabledWhen": {
      "alias": "disabledWhen";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on ReactionChatToolComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ReactionChatToolMethodNames = 'execute' | 'attach' | 'detach';
/**
 * Declares the methods interface for ReactionChatToolComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ReactionChatToolComponentMethods = MethodMap<ReactionChatToolMethodNames>;
/**
 * @public
 */
export declare function provideReactionChatToolComponent(config?: Partial<ReactionChatToolElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the VoiceRecorderChatToolComponent.
 * Use this token to provide default properties for the VoiceRecorderChatToolComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const VOICE_RECORDER_CHAT_TOOL_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/inputs/prompt-box/tools/IPromptBoxVoiceRecorderToolElementProps").IPromptBoxVoiceRecorderToolElementProps>>;
/**
 * @public
 *
 * Injection token for the intl configuration of the VoiceRecorderChatToolComponent.
 * Provide a partial intl object or an injectable class that resolves translations.
 * This allows third-party applications to override the default intl labels
 * globally, per route, or per component via Angular's dependency injection.
 *
 * Merge order: Foundation defaults → DI intl → [intl] input binding.
 */
export declare const VOICE_RECORDER_CHAT_TOOL_INTL: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").PromptBoxVoiceRecorderToolElementIntl>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class VoiceRecorderChatToolComponent {
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<Partial<VoiceRecorderChatToolElement['intl']> | undefined>;
  /**
   * Signal input for the `state` property.
   *
   * @public
   */
  readonly state: InputSignal<VoiceRecorderChatToolElement['state'] | undefined>;
  /**
   * Signal input for the `elapsedTime` property.
   *
   * @public
   */
  readonly elapsedTime: InputSignal<VoiceRecorderChatToolElement['elapsedTime'] | undefined>;
  /**
   * Signal input for the `maxDurationTime` property.
   *
   * @public
   */
  readonly maxDurationTime: InputSignal<VoiceRecorderChatToolElement['maxDurationTime'] | undefined>;
  /**
   * Signal input for the `objectUrl` property.
   *
   * @public
   */
  readonly objectUrl: InputSignal<VoiceRecorderChatToolElement['objectUrl'] | undefined>;
  /**
   * Signal input for the `canPause` property.
   *
   * @public
   */
  readonly canPause: InputSignal<VoiceRecorderChatToolElement['canPause'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<VoiceRecorderChatToolElement['themeName'] | undefined>;
  /**
   * Signal input for the `dock` property.
   *
   * @public
   */
  readonly dock: InputSignal<VoiceRecorderChatToolElement['dock'] | undefined>;
  /**
   * Signal input for the `disabledWhen` property.
   *
   * @public
   */
  readonly disabledWhen: InputSignal<VoiceRecorderChatToolElement['disabledWhen'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<VoiceRecorderChatToolElement['disabled'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<VoiceRecorderChatToolElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<VoiceRecorderChatToolElement['lang'] | undefined>;
  /**
   * Output signal for the `recorderCancel` event.
   *
   * @public
   */
  readonly recorderCancel: OutputEmitterRef<ElementEventDetail<VoiceRecorderChatToolElement, 'recorderCancel'>>;
  /**
   * Output signal for the `recorderPause` event.
   *
   * @public
   */
  readonly recorderPause: OutputEmitterRef<ElementEventDetail<VoiceRecorderChatToolElement, 'recorderPause'>>;
  /**
   * Output signal for the `recorderResume` event.
   *
   * @public
   */
  readonly recorderResume: OutputEmitterRef<ElementEventDetail<VoiceRecorderChatToolElement, 'recorderResume'>>;
  /**
   * Output signal for the `recorderStart` event.
   *
   * @public
   */
  readonly recorderStart: OutputEmitterRef<ElementEventDetail<VoiceRecorderChatToolElement, 'recorderStart'>>;
  /**
   * Output signal for the `recorderStop` event.
   *
   * @public
   */
  readonly recorderStop: OutputEmitterRef<ElementEventDetail<VoiceRecorderChatToolElement, 'recorderStop'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<VoiceRecorderChatToolElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<VoiceRecorderChatToolElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<VoiceRecorderChatToolElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Preserves the abstract execution behavior of the former chat voice tool.
   *
   * @public
   */
  execute(...args: Parameters<VoiceRecorderChatToolElement['execute']>): ReturnType<VoiceRecorderChatToolElement['execute']>;
  /**
   * Attaches this tool to a Prompt Box.
   *
   * @public
   */
  attach(...args: Parameters<VoiceRecorderChatToolElement['attach']>): ReturnType<VoiceRecorderChatToolElement['attach']>;
  /**
   * Detaches this tool from a Prompt Box.
   *
   * @public
   */
  detach(...args: Parameters<VoiceRecorderChatToolElement['detach']>): ReturnType<VoiceRecorderChatToolElement['detach']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `execute()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends VoiceRecorderChatToolMethodNames>(method: TMethod, ...args: Parameters<VoiceRecorderChatToolComponentMethods[TMethod]>): ReturnType<VoiceRecorderChatToolComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof VoiceRecorderChatToolElement>(property: TProperty, value: VoiceRecorderChatToolElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<VoiceRecorderChatToolElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<VoiceRecorderChatToolComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<VoiceRecorderChatToolComponent, "mosaik-voice-recorder-chat-tool", never, {
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "state": {
      "alias": "state";
      "required": false;
      "isSignal": true;
    };
    "elapsedTime": {
      "alias": "elapsedTime";
      "required": false;
      "isSignal": true;
    };
    "maxDurationTime": {
      "alias": "maxDurationTime";
      "required": false;
      "isSignal": true;
    };
    "objectUrl": {
      "alias": "objectUrl";
      "required": false;
      "isSignal": true;
    };
    "canPause": {
      "alias": "canPause";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dock": {
      "alias": "dock";
      "required": false;
      "isSignal": true;
    };
    "disabledWhen": {
      "alias": "disabledWhen";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "recorderCancel": "recorderCancel";
    "recorderPause": "recorderPause";
    "recorderResume": "recorderResume";
    "recorderStart": "recorderStart";
    "recorderStop": "recorderStop";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on VoiceRecorderChatToolComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type VoiceRecorderChatToolMethodNames = 'execute' | 'attach' | 'detach';
/**
 * Declares the methods interface for VoiceRecorderChatToolComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type VoiceRecorderChatToolComponentMethods = MethodMap<VoiceRecorderChatToolMethodNames>;
/**
 * @public
 */
export declare function provideVoiceRecorderChatToolComponent(config?: Partial<VoiceRecorderChatToolElement.Props>, intl?: Partial<VoiceRecorderChatToolElement['intl']> | Type<Partial<VoiceRecorderChatToolElement['intl']>>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-chat.d.ts.map