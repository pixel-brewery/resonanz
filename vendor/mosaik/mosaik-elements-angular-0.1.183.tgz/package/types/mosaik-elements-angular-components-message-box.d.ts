import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef, Type } from "@angular/core";
import { MessageBoxElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/overlays/message-box/MessageBoxElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the MessageBoxComponent.
 * Use this token to provide default properties for the MessageBoxComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const MESSAGE_BOX_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/overlays/message-box/IMessageBoxElementProps").IMessageBoxElementProps>>;
/**
 * @public
 *
 * Injection token for the intl configuration of the MessageBoxComponent.
 * Provide a partial intl object or an injectable class that resolves translations.
 * This allows third-party applications to override the default intl labels
 * globally, per route, or per component via Angular's dependency injection.
 *
 * Merge order: Foundation defaults → DI intl → [intl] input binding.
 */
export declare const MESSAGE_BOX_INTL: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").MessageBoxElementIntl>>;
/**
 * @public
 *
 * @slot actions - Action buttons and controls area
 * @slot content - Content area for the main dialog body
 * @slot footer - Dialog footer section for additional information
 * @slot header - Dialog header section for titles and controls
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class MessageBoxComponent {
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<Partial<MessageBoxElement['intl']> | undefined>;
  /**
   * Signal input for the `header` property.
   *
   * @public
   */
  readonly header: InputSignal<MessageBoxElement['header'] | undefined>;
  /**
   * Signal input for the `subHeader` property.
   *
   * @public
   */
  readonly subHeader: InputSignal<MessageBoxElement['subHeader'] | undefined>;
  /**
   * Signal input for the `message` property.
   *
   * @public
   */
  readonly message: InputSignal<MessageBoxElement['message'] | undefined>;
  /**
   * Signal input for the `buttons` property.
   *
   * @public
   */
  readonly buttons: InputSignal<MessageBoxElement['buttons'] | undefined>;
  /**
   * Signal input for the `initialResult` property.
   *
   * @public
   */
  readonly initialResult: InputSignal<MessageBoxElement['initialResult'] | undefined>;
  /**
   * Signal input for the `icon` property.
   *
   * @public
   */
  readonly icon: InputSignal<MessageBoxElement['icon'] | undefined>;
  /**
   * Signal input for the `alignment` property.
   *
   * @public
   */
  readonly alignment: InputSignal<MessageBoxElement['alignment'] | undefined>;
  /**
   * Signal input for the `formatter` property.
   *
   * @public
   */
  readonly formatter: InputSignal<MessageBoxElement['formatter'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<MessageBoxElement['variant'] | undefined>;
  /**
   * Signal input for the `isFullScreen` property.
   *
   * @public
   */
  readonly isFullScreen: InputSignal<MessageBoxElement['isFullScreen'] | undefined>;
  /**
   * Signal input for the `isDraggable` property.
   *
   * @public
   */
  readonly isDraggable: InputSignal<MessageBoxElement['isDraggable'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<MessageBoxElement['themeName'] | undefined>;
  /**
   * Signal input for the `enter` property.
   *
   * @public
   */
  readonly enter: InputSignal<MessageBoxElement['enter'] | undefined>;
  /**
   * Signal input for the `exit` property.
   *
   * @public
   */
  readonly exit: InputSignal<MessageBoxElement['exit'] | undefined>;
  /**
   * Signal input for the `width` property.
   *
   * @public
   */
  readonly width: InputSignal<MessageBoxElement['width'] | undefined>;
  /**
   * Signal input for the `height` property.
   *
   * @public
   */
  readonly height: InputSignal<MessageBoxElement['height'] | undefined>;
  /**
   * Signal input for the `elevation` property.
   *
   * @public
   */
  readonly elevation: InputSignal<MessageBoxElement['elevation'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<MessageBoxElement['appearance'] | undefined>;
  /**
   * Signal input for the `isOpen` property.
   *
   * @public
   */
  readonly isOpen: InputSignal<MessageBoxElement['isOpen'] | undefined>;
  /**
   * Signal input for the `hasBackdrop` property.
   *
   * @public
   */
  readonly hasBackdrop: InputSignal<MessageBoxElement['hasBackdrop'] | undefined>;
  /**
   * Signal input for the `pressEscapeToClose` property.
   *
   * @public
   */
  readonly pressEscapeToClose: InputSignal<MessageBoxElement['pressEscapeToClose'] | undefined>;
  /**
   * Signal input for the `clickOutsideToClose` property.
   *
   * @public
   */
  readonly clickOutsideToClose: InputSignal<MessageBoxElement['clickOutsideToClose'] | undefined>;
  /**
   * Signal input for the `attention` property.
   *
   * @public
   */
  readonly attention: InputSignal<MessageBoxElement['attention'] | undefined>;
  /**
   * Signal input for the `closeable` property.
   *
   * @public
   */
  readonly closeable: InputSignal<MessageBoxElement['closeable'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<MessageBoxElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<MessageBoxElement['lang'] | undefined>;
  /**
   * Output signal for the `dialogResult` event.
   *
   * @public
   */
  readonly dialogResult: OutputEmitterRef<ElementEventDetail<MessageBoxElement, 'dialogResult'>>;
  /**
   * Output signal for the `opened` event.
   *
   * @public
   */
  readonly opened: OutputEmitterRef<ElementEventDetail<MessageBoxElement, 'opened'>>;
  /**
   * Output signal for the `closed` event.
   *
   * @public
   */
  readonly closed: OutputEmitterRef<ElementEventDetail<MessageBoxElement, 'closed'>>;
  /**
   * Output signal for the `closeAttempted` event.
   *
   * @public
   */
  readonly closeAttempted: OutputEmitterRef<ElementEventDetail<MessageBoxElement, 'closeAttempted'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<MessageBoxElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<MessageBoxElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<MessageBoxElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: MessageBoxElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: MessageBoxElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Opens the message box and focuses its configured result without activating it.
   * A result absent from the current button set leaves the existing focus unchanged.
   *
   * @public
   */
  open(...args: Parameters<MessageBoxElement['open']>): ReturnType<MessageBoxElement['open']>;
  /**
   * Closes the `DialogElement`.
   *
   * @public
   */
  close(...args: Parameters<MessageBoxElement['close']>): ReturnType<MessageBoxElement['close']>;
  /**
   * Executes the animation.
   *
   * @public
   */
  play(...args: Parameters<MessageBoxElement['play']>): ReturnType<MessageBoxElement['play']>;
  /**
   * A lifecycle hook that is invoked when the element is added to the DOM.
   *
   * @public
   */
  onEnterAnimation(...args: Parameters<NonNullable<MessageBoxElement['onEnterAnimation']>>): ReturnType<NonNullable<MessageBoxElement['onEnterAnimation']>> | undefined;
  /**
   * A lifecycle hook that is invoked when the element is removed from the DOM.
   *
   * @public
   */
  onExitAnimation(...args: Parameters<NonNullable<MessageBoxElement['onExitAnimation']>>): ReturnType<NonNullable<MessageBoxElement['onExitAnimation']>> | undefined;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<MessageBoxElement['assignToSlot']>): ReturnType<MessageBoxElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<MessageBoxElement['getSlotContent']>): ReturnType<MessageBoxElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<MessageBoxElement['hasSlotContent']>): ReturnType<MessageBoxElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<MessageBoxElement['hasSlot']>): ReturnType<MessageBoxElement['hasSlot']>;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<MessageBoxElement['onSlotChanges']>): ReturnType<MessageBoxElement['onSlotChanges']>;
  /**
   * Requests visual attention for this overlay.
   *
   * @public
   * @param args - The arguments of `requestAttention`:
   * - `animation` - Optional animation used for this attention request.
   * @returns Whether the attention animation finished.
   */
  requestAttention(...args: Parameters<MessageBoxElement['requestAttention']>): ReturnType<MessageBoxElement['requestAttention']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `open()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends MessageBoxMethodNames>(method: TMethod, ...args: Parameters<MessageBoxComponentMethods[TMethod]>): ReturnType<MessageBoxComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof MessageBoxElement>(property: TProperty, value: MessageBoxElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<MessageBoxElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<MessageBoxComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<MessageBoxComponent, "mosaik-message-box", never, {
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "header": {
      "alias": "header";
      "required": false;
      "isSignal": true;
    };
    "subHeader": {
      "alias": "subHeader";
      "required": false;
      "isSignal": true;
    };
    "message": {
      "alias": "message";
      "required": false;
      "isSignal": true;
    };
    "buttons": {
      "alias": "buttons";
      "required": false;
      "isSignal": true;
    };
    "initialResult": {
      "alias": "initialResult";
      "required": false;
      "isSignal": true;
    };
    "icon": {
      "alias": "icon";
      "required": false;
      "isSignal": true;
    };
    "alignment": {
      "alias": "alignment";
      "required": false;
      "isSignal": true;
    };
    "formatter": {
      "alias": "formatter";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "isFullScreen": {
      "alias": "isFullScreen";
      "required": false;
      "isSignal": true;
    };
    "isDraggable": {
      "alias": "isDraggable";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "enter": {
      "alias": "enter";
      "required": false;
      "isSignal": true;
    };
    "exit": {
      "alias": "exit";
      "required": false;
      "isSignal": true;
    };
    "width": {
      "alias": "width";
      "required": false;
      "isSignal": true;
    };
    "height": {
      "alias": "height";
      "required": false;
      "isSignal": true;
    };
    "elevation": {
      "alias": "elevation";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "isOpen": {
      "alias": "isOpen";
      "required": false;
      "isSignal": true;
    };
    "hasBackdrop": {
      "alias": "hasBackdrop";
      "required": false;
      "isSignal": true;
    };
    "pressEscapeToClose": {
      "alias": "pressEscapeToClose";
      "required": false;
      "isSignal": true;
    };
    "clickOutsideToClose": {
      "alias": "clickOutsideToClose";
      "required": false;
      "isSignal": true;
    };
    "attention": {
      "alias": "attention";
      "required": false;
      "isSignal": true;
    };
    "closeable": {
      "alias": "closeable";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "dialogResult": "dialogResult";
    "opened": "opened";
    "closed": "closed";
    "closeAttempted": "closeAttempted";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on MessageBoxComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type MessageBoxMethodNames = 'open' | 'close' | 'play' | 'onEnterAnimation' | 'onExitAnimation' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges' | 'requestAttention';
/**
 * Declares the methods interface for MessageBoxComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type MessageBoxComponentMethods = MethodMap<MessageBoxMethodNames>;
/**
 * @public
 */
export declare function provideMessageBoxComponent(config?: Partial<MessageBoxElement.Props>, intl?: Partial<MessageBoxElement['intl']> | Type<Partial<MessageBoxElement['intl']>>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-message-box.d.ts.map