import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef, Type } from "@angular/core";
import { ListItemGroupElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/list/ListItemGroupElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import * as i1 from "@pixel-brewery/mosaik-elements-angular/runtime";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { ListItemElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/list/ListItemElement";
import { ControlValueAccessor } from "@angular/forms";
import { ListElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/list/ListElement";
/**
 * @public
 *
 * Injection token for the default properties of the ListItemGroupComponent.
 * Use this token to provide default properties for the ListItemGroupComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const LIST_ITEM_GROUP_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/selectors/list/IListItemGroupElementProps").IListItemGroupElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot for list items (mosaik-list-item elements)
 * @slot header - Custom header content (overrides the default header text)
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ListItemGroupComponent {
  /**
   * Signal input for the `header` property.
   *
   * @public
   */
  readonly header: InputSignal<ListItemGroupElement['header'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ListItemGroupElement['themeName'] | undefined>;
  /**
   * Signal input for the `isSticky` property.
   *
   * @public
   */
  readonly isSticky: InputSignal<ListItemGroupElement['isSticky'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<ListItemGroupElement['disabled'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ListItemGroupElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ListItemGroupElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ListItemGroupElement, 'connected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ListItemGroupElement, 'changed'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ListItemGroupElement, 'disconnected'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ListItemGroupElement>(property: TProperty, value: ListItemGroupElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ListItemGroupElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ListItemGroupComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ListItemGroupComponent, "mosaik-list-item-group", never, {
    "header": {
      "alias": "header";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "isSticky": {
      "alias": "isSticky";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "changed": "changed";
    "disconnected": "disconnected";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on ListItemGroupComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ListItemGroupMethodNames = never;
/**
 * Declares the methods interface for ListItemGroupComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ListItemGroupComponentMethods = MethodMap<ListItemGroupMethodNames>;
/**
 * @public
 */
export declare function provideListItemGroupComponent(config?: Partial<ListItemGroupElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the ListItemComponent.
 * Use this token to provide default properties for the ListItemComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const LIST_ITEM_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/selectors/list/IListItemElementProps").IListItemElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot for the main list item content
 * @slot prefix - Content displayed before the main content (e.g., avatar, icon)
 * @slot suffix - Content displayed after the main content (e.g., badge, action button)
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ListItemComponent {
  /**
   * Signal input for the `isChecked` property.
   *
   * @public
   */
  readonly isChecked: InputSignal<ListItemElement['isChecked'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ListItemElement['themeName'] | undefined>;
  /**
   * Signal input for the `ripple` property.
   *
   * @public
   */
  readonly ripple: InputSignal<ListItemElement['ripple'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<ListItemElement['disabled'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<ListItemElement['variant'] | undefined>;
  /**
   * Signal input for the `isFocused` property.
   *
   * @public
   */
  readonly isFocused: InputSignal<ListItemElement['isFocused'] | undefined>;
  /**
   * Signal input for the `isSelected` property.
   *
   * @public
   */
  readonly isSelected: InputSignal<ListItemElement['isSelected'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<ListItemElement['value'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ListItemElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ListItemElement['lang'] | undefined>;
  /**
   * Output signal for the `selected` event.
   *
   * @public
   */
  readonly selected: OutputEmitterRef<ElementEventDetail<ListItemElement, 'selected'>>;
  /**
   * Output signal for the `deselected` event.
   *
   * @public
   */
  readonly deselected: OutputEmitterRef<ElementEventDetail<ListItemElement, 'deselected'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ListItemElement, 'connected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ListItemElement, 'changed'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ListItemElement, 'disconnected'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: ListItemElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: ListItemElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<ListItemElement['assignToSlot']>): ReturnType<ListItemElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<ListItemElement['getSlotContent']>): ReturnType<ListItemElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<ListItemElement['hasSlotContent']>): ReturnType<ListItemElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<ListItemElement['hasSlot']>): ReturnType<ListItemElement['hasSlot']>;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<ListItemElement['onSlotChanges']>): ReturnType<ListItemElement['onSlotChanges']>;
  /**
   * Selects the item and fires `selected`. Does nothing when the item is already selected.
   *
   * @public
   * @param args - The arguments of `select`:
   * - `forceUpdate` - When `true`, the parent selector also selects the item.
   */
  select(...args: Parameters<ListItemElement['select']>): ReturnType<ListItemElement['select']>;
  /**
   * Deselects the item and fires `deselected`. Does nothing when the item is not selected.
   *
   * @public
   * @param args - The arguments of `deselect`:
   * - `forceUpdate` - When `true`, the parent selector also deselects the item.
   */
  deselect(...args: Parameters<ListItemElement['deselect']>): ReturnType<ListItemElement['deselect']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `assignToSlot()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends ListItemMethodNames>(method: TMethod, ...args: Parameters<ListItemComponentMethods[TMethod]>): ReturnType<ListItemComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ListItemElement>(property: TProperty, value: ListItemElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ListItemElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ListItemComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ListItemComponent, "mosaik-list-item", never, {
    "isChecked": {
      "alias": "isChecked";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "ripple": {
      "alias": "ripple";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "isFocused": {
      "alias": "isFocused";
      "required": false;
      "isSignal": true;
    };
    "isSelected": {
      "alias": "isSelected";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "selected": "selected";
    "deselected": "deselected";
    "connected": "connected";
    "changed": "changed";
    "disconnected": "disconnected";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on ListItemComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ListItemMethodNames = 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges' | 'select' | 'deselect';
/**
 * Declares the methods interface for ListItemComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ListItemComponentMethods = MethodMap<ListItemMethodNames>;
/**
 * @public
 */
export declare function provideListItemComponent(config?: Partial<ListItemElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the ListComponent.
 * Use this token to provide default properties for the ListComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const LIST_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/selectors/list/IListElementProps").IListElementProps>>;
/**
 * @public
 *
 * Injection token for the intl configuration of the ListComponent.
 * Provide a partial intl object or an injectable class that resolves translations.
 * This allows third-party applications to override the default intl labels
 * globally, per route, or per component via Angular's dependency injection.
 *
 * Merge order: Foundation defaults → DI intl → [intl] input binding.
 */
export declare const LIST_INTL: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").ListElementIntl>>;
/**
 * @public
 *
 * @slot  - Default content area for list items and groups
 * @slot empty - Empty state content when no items are available
 * @slot filter - Filter controls and search functionality area
 * @slot footer - Footer content below the list items
 * @slot header - Header content above the list items
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ListComponent implements ControlValueAccessor {
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<Partial<ListElement['intl']> | undefined>;
  /**
   * Signal input for the `selectionMode` property.
   *
   * @public
   */
  readonly selectionMode: InputSignal<ListElement['selectionMode'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<ListElement['value'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ListElement['themeName'] | undefined>;
  /**
   * Signal input for the `showScrollButtons` property.
   *
   * @public
   */
  readonly showScrollButtons: InputSignal<ListElement['showScrollButtons'] | undefined>;
  /**
   * Signal input for the `showScrollbar` property.
   *
   * @public
   */
  readonly showScrollbar: InputSignal<ListElement['showScrollbar'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<ListElement['disabled'] | undefined>;
  /**
   * Signal input for the `showFilter` property.
   *
   * @public
   */
  readonly showFilter: InputSignal<ListElement['showFilter'] | undefined>;
  /**
   * Signal input for the `filterMemberPath` property.
   *
   * @public
   */
  readonly filterMemberPath: InputSignal<ListElement['filterMemberPath'] | undefined>;
  /**
   * Signal input for the `filter` property.
   *
   * @public
   */
  readonly filter: InputSignal<ListElement['filter'] | undefined>;
  /**
   * Signal input for the `filterPlaceholder` property.
   *
   * @public
   */
  readonly filterPlaceholder: InputSignal<ListElement['filterPlaceholder'] | undefined>;
  /**
   * Signal input for the `orientation` property.
   *
   * @public
   */
  readonly orientation: InputSignal<ListElement['orientation'] | undefined>;
  /**
   * Signal input for the `inset` property.
   *
   * @public
   */
  readonly inset: InputSignal<ListElement['inset'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ListElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ListElement['lang'] | undefined>;
  /**
   * Output signal for the `selectionChanged` event.
   *
   * @public
   */
  readonly selectionChanged: OutputEmitterRef<ElementEventDetail<ListElement, 'selectionChanged'>>;
  /**
   * Output signal for the `itemsChanged` event.
   *
   * @public
   */
  readonly itemsChanged: OutputEmitterRef<ElementEventDetail<ListElement, 'itemsChanged'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ListElement, 'changed'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ListElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ListElement, 'disconnected'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: ListElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: ListElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  private readonly _accessor;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Applies a value supplied by Angular forms to the native control.
   *
   * @public
   */
  writeValue(obj: unknown): void;
  /**
   * Registers the callback notified when the native control value changes.
   *
   * @public
   */
  registerOnChange(fn: unknown): void;
  /**
   * Registers the callback notified when the native control is touched.
   *
   * @public
   */
  registerOnTouched(fn: unknown): void;
  /**
   * Applies the disabled state supplied by Angular forms.
   *
   * @public
   */
  setDisabledState?(isDisabled: boolean): void;
  /**
   * Returns the scrollable viewport of the list, which is owned by the internal
   * scroll primitive rather than by the list element itself.
   *
   * @public
   */
  getScrollableElement(...args: Parameters<ListElement['getScrollableElement']>): ReturnType<ListElement['getScrollableElement']>;
  /**
   * Reconciles grouped items through the existing slot controller's subtree observation.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<ListElement['onSlotChanges']>): ReturnType<ListElement['onSlotChanges']>;
  /**
   * Clears the single selection and its value in one transition, including an item removed from the list.
   *
   * @public
   */
  resetSelection(...args: Parameters<ListElement['resetSelection']>): ReturnType<ListElement['resetSelection']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<ListElement['assignToSlot']>): ReturnType<ListElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<ListElement['getSlotContent']>): ReturnType<ListElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<ListElement['hasSlotContent']>): ReturnType<ListElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<ListElement['hasSlot']>): ReturnType<ListElement['hasSlot']>;
  /**
   * Select the item.
   *
   * @public
   * @param args - The arguments of `select`:
   * - `item` - The element, index or value to select.
   */
  select(...args: Parameters<ListElement['select']>): ReturnType<ListElement['select']>;
  /**
   * Deselect the item.
   *
   * @public
   * @param args - The arguments of `deselect`:
   * - `item` - The element or index to deselect.
   */
  deselect(...args: Parameters<ListElement['deselect']>): ReturnType<ListElement['deselect']>;
  /**
   * Select the next item after current selected item/index.
   *
   * @public
   */
  selectNext(...args: Parameters<ListElement['selectNext']>): ReturnType<ListElement['selectNext']>;
  /**
   * Select the previous item before current selected item/index.
   *
   * @public
   */
  selectPrevious(...args: Parameters<ListElement['selectPrevious']>): ReturnType<ListElement['selectPrevious']>;
  /**
   * Select the first item.
   *
   * @public
   */
  selectFirst(...args: Parameters<ListElement['selectFirst']>): ReturnType<ListElement['selectFirst']>;
  /**
   * Select the last item.
   *
   * @public
   */
  selectLast(...args: Parameters<ListElement['selectLast']>): ReturnType<ListElement['selectLast']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `getScrollableElement()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends ListMethodNames>(method: TMethod, ...args: Parameters<ListComponentMethods[TMethod]>): ReturnType<ListComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ListElement>(property: TProperty, value: ListElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ListElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ListComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ListComponent, "mosaik-list", never, {
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "selectionMode": {
      "alias": "selectionMode";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "showScrollButtons": {
      "alias": "showScrollButtons";
      "required": false;
      "isSignal": true;
    };
    "showScrollbar": {
      "alias": "showScrollbar";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "showFilter": {
      "alias": "showFilter";
      "required": false;
      "isSignal": true;
    };
    "filterMemberPath": {
      "alias": "filterMemberPath";
      "required": false;
      "isSignal": true;
    };
    "filter": {
      "alias": "filter";
      "required": false;
      "isSignal": true;
    };
    "filterPlaceholder": {
      "alias": "filterPlaceholder";
      "required": false;
      "isSignal": true;
    };
    "orientation": {
      "alias": "orientation";
      "required": false;
      "isSignal": true;
    };
    "inset": {
      "alias": "inset";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "selectionChanged": "selectionChanged";
    "itemsChanged": "itemsChanged";
    "changed": "changed";
    "connected": "connected";
    "disconnected": "disconnected";
  }, never, ["*"], true, [{
    directive: typeof i1.FormStatusHostDirective;
    inputs: {};
    outputs: {};
  }, {
    directive: typeof i1.FormFieldStatusHostDirective;
    inputs: {};
    outputs: {};
  }]>;
}
/**
 * Declares the methods available on ListComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ListMethodNames = 'getScrollableElement' | 'onSlotChanges' | 'resetSelection' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'select' | 'deselect' | 'selectNext' | 'selectPrevious' | 'selectFirst' | 'selectLast';
/**
 * Declares the methods interface for ListComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ListComponentMethods = MethodMap<ListMethodNames>;
/**
 * @public
 */
export declare function provideListComponent(config?: Partial<ListElement.Props>, intl?: Partial<ListElement['intl']> | Type<Partial<ListElement['intl']>>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-list.d.ts.map