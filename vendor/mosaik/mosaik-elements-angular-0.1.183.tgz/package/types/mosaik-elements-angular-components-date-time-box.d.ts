import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef, Type } from "@angular/core";
import { ControlValueAccessor } from "@angular/forms";
import { DateTimeBoxElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/date-time-box/DateTimeBoxElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import * as i1 from "@pixel-brewery/mosaik-elements-angular/runtime";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the DateTimeBoxComponent.
 * Use this token to provide default properties for the DateTimeBoxComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const DATE_TIME_BOX_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/inputs/date-time-box/IDateTimeBoxElementProps").IDateTimeBoxElementProps>>;
/**
 * @public
 *
 * Injection token for the intl configuration of the DateTimeBoxComponent.
 * Provide a partial intl object or an injectable class that resolves translations.
 * This allows third-party applications to override the default intl labels
 * globally, per route, or per component via Angular's dependency injection.
 *
 * Merge order: Foundation defaults → DI intl → [intl] input binding.
 */
export declare const DATE_TIME_BOX_INTL: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").DateTimeBoxElementIntl>>;
/**
 * @public
 *
 * @slot prefix - The prefix slot.
 * @slot suffix - The suffix slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class DateTimeBoxComponent implements ControlValueAccessor {
  /**
   * Signal input for the `displayDate` property.
   *
   * @public
   */
  readonly displayDate: InputSignal<DateTimeBoxElement['displayDate'] | undefined>;
  /**
   * Signal input for the `displayDateStart` property.
   *
   * @public
   */
  readonly displayDateStart: InputSignal<DateTimeBoxElement['displayDateStart'] | undefined>;
  /**
   * Signal input for the `displayDateEnd` property.
   *
   * @public
   */
  readonly displayDateEnd: InputSignal<DateTimeBoxElement['displayDateEnd'] | undefined>;
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<Partial<DateTimeBoxElement['intl']> | undefined>;
  /**
   * Signal input for the `values` property.
   *
   * @public
   */
  readonly values: InputSignal<DateTimeBoxElement['values'] | undefined>;
  /**
   * Signal input for the `view` property.
   *
   * @public
   */
  readonly view: InputSignal<DateTimeBoxElement['view'] | undefined>;
  /**
   * Signal input for the `allowedViews` property.
   *
   * @public
   */
  readonly allowedViews: InputSignal<DateTimeBoxElement['allowedViews'] | undefined>;
  /**
   * Signal input for the `showNavigation` property.
   *
   * @public
   */
  readonly showNavigation: InputSignal<DateTimeBoxElement['showNavigation'] | undefined>;
  /**
   * Signal input for the `blackoutDates` property.
   *
   * @public
   */
  readonly blackoutDates: InputSignal<DateTimeBoxElement['blackoutDates'] | undefined>;
  /**
   * Signal input for the `specialDates` property.
   *
   * @public
   */
  readonly specialDates: InputSignal<DateTimeBoxElement['specialDates'] | undefined>;
  /**
   * Signal input for the `minDate` property.
   *
   * @public
   */
  readonly minDate: InputSignal<DateTimeBoxElement['minDate'] | undefined>;
  /**
   * Signal input for the `maxDate` property.
   *
   * @public
   */
  readonly maxDate: InputSignal<DateTimeBoxElement['maxDate'] | undefined>;
  /**
   * Signal input for the `firstDayOfWeek` property.
   *
   * @public
   */
  readonly firstDayOfWeek: InputSignal<DateTimeBoxElement['firstDayOfWeek'] | undefined>;
  /**
   * Signal input for the `isTodayHighlighted` property.
   *
   * @public
   */
  readonly isTodayHighlighted: InputSignal<DateTimeBoxElement['isTodayHighlighted'] | undefined>;
  /**
   * Signal input for the `isWeekendHighlighted` property.
   *
   * @public
   */
  readonly isWeekendHighlighted: InputSignal<DateTimeBoxElement['isWeekendHighlighted'] | undefined>;
  /**
   * Signal input for the `showWeekNumbers` property.
   *
   * @public
   */
  readonly showWeekNumbers: InputSignal<DateTimeBoxElement['showWeekNumbers'] | undefined>;
  /**
   * Signal input for the `markerHandler` property.
   *
   * @public
   */
  readonly markerHandler: InputSignal<DateTimeBoxElement['markerHandler'] | undefined>;
  /**
   * Signal input for the `showAdjacent` property.
   *
   * @public
   */
  readonly showAdjacent: InputSignal<DateTimeBoxElement['showAdjacent'] | undefined>;
  /**
   * Signal input for the `readonly` property.
   *
   * @public
   */
  readonly readonly: InputSignal<DateTimeBoxElement['readonly'] | undefined>;
  /**
   * Signal input for the `required` property.
   *
   * @public
   */
  readonly required: InputSignal<DateTimeBoxElement['required'] | undefined>;
  /**
   * Signal input for the `autofocus` property.
   *
   * @public
   */
  readonly autofocus: InputSignal<DateTimeBoxElement['autofocus'] | undefined>;
  /**
   * Signal input for the `name` property.
   *
   * @public
   */
  readonly name: InputSignal<DateTimeBoxElement['name'] | undefined>;
  /**
   * Signal input for the `placeholder` property.
   *
   * @public
   */
  readonly placeholder: InputSignal<DateTimeBoxElement['placeholder'] | undefined>;
  /**
   * Signal input for the `autocomplete` property.
   *
   * @public
   */
  readonly autocomplete: InputSignal<DateTimeBoxElement['autocomplete'] | undefined>;
  /**
   * Signal input for the `format` property.
   *
   * @public
   */
  readonly format: InputSignal<DateTimeBoxElement['format'] | undefined>;
  /**
   * Signal input for the `timePrecision` property.
   *
   * @public
   */
  readonly timePrecision: InputSignal<DateTimeBoxElement['timePrecision'] | undefined>;
  /**
   * Signal input for the `textAlign` property.
   *
   * @public
   */
  readonly textAlign: InputSignal<DateTimeBoxElement['textAlign'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<DateTimeBoxElement['themeName'] | undefined>;
  /**
   * Signal input for the `size` property.
   *
   * @public
   */
  readonly size: InputSignal<DateTimeBoxElement['size'] | undefined>;
  /**
   * Signal input for the `isClearable` property.
   *
   * @public
   */
  readonly isClearable: InputSignal<DateTimeBoxElement['isClearable'] | undefined>;
  /**
   * Signal input for the `locale` property.
   *
   * @public
   */
  readonly locale: InputSignal<DateTimeBoxElement['locale'] | undefined>;
  /**
   * Signal input for the `invalid` property.
   *
   * @public
   */
  readonly invalid: InputSignal<DateTimeBoxElement['invalid'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<DateTimeBoxElement['value'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<DateTimeBoxElement['variant'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<DateTimeBoxElement['appearance'] | undefined>;
  /**
   * Signal input for the `dropDownPlacement` property.
   *
   * @public
   */
  readonly dropDownPlacement: InputSignal<DateTimeBoxElement['dropDownPlacement'] | undefined>;
  /**
   * Signal input for the `dropDownStrategy` property.
   *
   * @public
   */
  readonly dropDownStrategy: InputSignal<DateTimeBoxElement['dropDownStrategy'] | undefined>;
  /**
   * Signal input for the `dropDownDistance` property.
   *
   * @public
   */
  readonly dropDownDistance: InputSignal<DateTimeBoxElement['dropDownDistance'] | undefined>;
  /**
   * Signal input for the `dropDownSkidding` property.
   *
   * @public
   */
  readonly dropDownSkidding: InputSignal<DateTimeBoxElement['dropDownSkidding'] | undefined>;
  /**
   * Signal input for the `dropDownStaysOpen` property.
   *
   * @public
   */
  readonly dropDownStaysOpen: InputSignal<DateTimeBoxElement['dropDownStaysOpen'] | undefined>;
  /**
   * Signal input for the `dropDownMaxHeight` property.
   *
   * @public
   */
  readonly dropDownMaxHeight: InputSignal<DateTimeBoxElement['dropDownMaxHeight'] | undefined>;
  /**
   * Signal input for the `dropDownHeight` property.
   *
   * @public
   */
  readonly dropDownHeight: InputSignal<DateTimeBoxElement['dropDownHeight'] | undefined>;
  /**
   * Signal input for the `dropDownWidth` property.
   *
   * @public
   */
  readonly dropDownWidth: InputSignal<DateTimeBoxElement['dropDownWidth'] | undefined>;
  /**
   * Signal input for the `dropDownMaxWidth` property.
   *
   * @public
   */
  readonly dropDownMaxWidth: InputSignal<DateTimeBoxElement['dropDownMaxWidth'] | undefined>;
  /**
   * Signal input for the `isDropDownOpen` property.
   *
   * @public
   */
  readonly isDropDownOpen: InputSignal<DateTimeBoxElement['isDropDownOpen'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<DateTimeBoxElement['label'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<DateTimeBoxElement['disabled'] | undefined>;
  /**
   * Signal input for the `formatter` property.
   *
   * @public
   */
  readonly formatter: InputSignal<DateTimeBoxElement['formatter'] | undefined>;
  /**
   * Signal input for the `parser` property.
   *
   * @public
   */
  readonly parser: InputSignal<DateTimeBoxElement['parser'] | undefined>;
  /**
   * Signal input for the `isFocused` property.
   *
   * @public
   */
  readonly isFocused: InputSignal<DateTimeBoxElement['isFocused'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<DateTimeBoxElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<DateTimeBoxElement['lang'] | undefined>;
  /**
   * Output signal for the `cleared` event.
   *
   * @public
   */
  readonly cleared: OutputEmitterRef<ElementEventDetail<DateTimeBoxElement, 'cleared'>>;
  /**
   * Output signal for the `change` event.
   *
   * @public
   */
  readonly change: OutputEmitterRef<ElementEventDetail<DateTimeBoxElement, 'change'>>;
  /**
   * Output signal for the `input` event.
   *
   * @public
   */
  readonly input: OutputEmitterRef<ElementEventDetail<DateTimeBoxElement, 'input'>>;
  /**
   * Output signal for the `focus` event.
   *
   * @public
   */
  readonly focus: OutputEmitterRef<ElementEventDetail<DateTimeBoxElement, 'focus'>>;
  /**
   * Output signal for the `blur` event.
   *
   * @public
   */
  readonly blur: OutputEmitterRef<ElementEventDetail<DateTimeBoxElement, 'blur'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<DateTimeBoxElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<DateTimeBoxElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<DateTimeBoxElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: DateTimeBoxElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: DateTimeBoxElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  private readonly _accessor;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Applies a value supplied by Angular forms to the native control.
   *
   * @public
   */
  writeValue(obj: unknown): void;
  /**
   * Registers the callback notified when the native control value changes.
   *
   * @public
   */
  registerOnChange(fn: unknown): void;
  /**
   * Registers the callback notified when the native control is touched.
   *
   * @public
   */
  registerOnTouched(fn: unknown): void;
  /**
   * Applies the disabled state supplied by Angular forms.
   *
   * @public
   */
  setDisabledState?(isDisabled: boolean): void;
  /**
   * Opens the picker and snapshots the current committed value.
   *
   * @public
   */
  open(...args: Parameters<DateTimeBoxElement['open']>): ReturnType<DateTimeBoxElement['open']>;
  /**
   * Dismisses the picker and restores a staged selection. Keyboard drafts
   * remain in the editor until their native change event commits them.
   *
   * @public
   */
  close(...args: Parameters<DateTimeBoxElement['close']>): ReturnType<DateTimeBoxElement['close']>;
  /**
   * Commits the staged picker value and closes the picker.
   *
   * @public
   */
  apply(...args: Parameters<DateTimeBoxElement['apply']>): ReturnType<DateTimeBoxElement['apply']>;
  /**
   * Discards the staged picker value and closes the picker.
   *
   * @public
   */
  cancel(...args: Parameters<DateTimeBoxElement['cancel']>): ReturnType<DateTimeBoxElement['cancel']>;
  /**
   * Clears the value of the element but not the validation.
   *
   * @public
   */
  clear(...args: Parameters<DateTimeBoxElement['clear']>): ReturnType<DateTimeBoxElement['clear']>;
  /**
   * Resets the value, all kinds of validation and errors.
   *
   * @public
   */
  reset(...args: Parameters<DateTimeBoxElement['reset']>): ReturnType<DateTimeBoxElement['reset']>;
  /**
   * Checks the validity of the element and returns `true` if it is valid; otherwise, `false`.
   *
   * @public
   */
  checkValidity(...args: Parameters<DateTimeBoxElement['checkValidity']>): ReturnType<DateTimeBoxElement['checkValidity']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<DateTimeBoxElement['assignToSlot']>): ReturnType<DateTimeBoxElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<DateTimeBoxElement['getSlotContent']>): ReturnType<DateTimeBoxElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<DateTimeBoxElement['hasSlotContent']>): ReturnType<DateTimeBoxElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<DateTimeBoxElement['hasSlot']>): ReturnType<DateTimeBoxElement['hasSlot']>;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<DateTimeBoxElement['onSlotChanges']>): ReturnType<DateTimeBoxElement['onSlotChanges']>;
  /**
   * Toggles the drop down.
   *
   * @public
   */
  toggle(...args: Parameters<DateTimeBoxElement['toggle']>): ReturnType<DateTimeBoxElement['toggle']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `open()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * `focus`, `blur` share their name with another member of the component and are called on `elementRef.nativeElement` instead.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends DateTimeBoxMethodNames>(method: TMethod, ...args: Parameters<DateTimeBoxComponentMethods[TMethod]>): ReturnType<DateTimeBoxComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof DateTimeBoxElement>(property: TProperty, value: DateTimeBoxElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<DateTimeBoxElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<DateTimeBoxComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<DateTimeBoxComponent, "mosaik-datetimebox", never, {
    "displayDate": {
      "alias": "displayDate";
      "required": false;
      "isSignal": true;
    };
    "displayDateStart": {
      "alias": "displayDateStart";
      "required": false;
      "isSignal": true;
    };
    "displayDateEnd": {
      "alias": "displayDateEnd";
      "required": false;
      "isSignal": true;
    };
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "values": {
      "alias": "values";
      "required": false;
      "isSignal": true;
    };
    "view": {
      "alias": "view";
      "required": false;
      "isSignal": true;
    };
    "allowedViews": {
      "alias": "allowedViews";
      "required": false;
      "isSignal": true;
    };
    "showNavigation": {
      "alias": "showNavigation";
      "required": false;
      "isSignal": true;
    };
    "blackoutDates": {
      "alias": "blackoutDates";
      "required": false;
      "isSignal": true;
    };
    "specialDates": {
      "alias": "specialDates";
      "required": false;
      "isSignal": true;
    };
    "minDate": {
      "alias": "minDate";
      "required": false;
      "isSignal": true;
    };
    "maxDate": {
      "alias": "maxDate";
      "required": false;
      "isSignal": true;
    };
    "firstDayOfWeek": {
      "alias": "firstDayOfWeek";
      "required": false;
      "isSignal": true;
    };
    "isTodayHighlighted": {
      "alias": "isTodayHighlighted";
      "required": false;
      "isSignal": true;
    };
    "isWeekendHighlighted": {
      "alias": "isWeekendHighlighted";
      "required": false;
      "isSignal": true;
    };
    "showWeekNumbers": {
      "alias": "showWeekNumbers";
      "required": false;
      "isSignal": true;
    };
    "markerHandler": {
      "alias": "markerHandler";
      "required": false;
      "isSignal": true;
    };
    "showAdjacent": {
      "alias": "showAdjacent";
      "required": false;
      "isSignal": true;
    };
    "readonly": {
      "alias": "readonly";
      "required": false;
      "isSignal": true;
    };
    "required": {
      "alias": "required";
      "required": false;
      "isSignal": true;
    };
    "autofocus": {
      "alias": "autofocus";
      "required": false;
      "isSignal": true;
    };
    "name": {
      "alias": "name";
      "required": false;
      "isSignal": true;
    };
    "placeholder": {
      "alias": "placeholder";
      "required": false;
      "isSignal": true;
    };
    "autocomplete": {
      "alias": "autocomplete";
      "required": false;
      "isSignal": true;
    };
    "format": {
      "alias": "format";
      "required": false;
      "isSignal": true;
    };
    "timePrecision": {
      "alias": "timePrecision";
      "required": false;
      "isSignal": true;
    };
    "textAlign": {
      "alias": "textAlign";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "isClearable": {
      "alias": "isClearable";
      "required": false;
      "isSignal": true;
    };
    "locale": {
      "alias": "locale";
      "required": false;
      "isSignal": true;
    };
    "invalid": {
      "alias": "invalid";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "dropDownPlacement": {
      "alias": "dropDownPlacement";
      "required": false;
      "isSignal": true;
    };
    "dropDownStrategy": {
      "alias": "dropDownStrategy";
      "required": false;
      "isSignal": true;
    };
    "dropDownDistance": {
      "alias": "dropDownDistance";
      "required": false;
      "isSignal": true;
    };
    "dropDownSkidding": {
      "alias": "dropDownSkidding";
      "required": false;
      "isSignal": true;
    };
    "dropDownStaysOpen": {
      "alias": "dropDownStaysOpen";
      "required": false;
      "isSignal": true;
    };
    "dropDownMaxHeight": {
      "alias": "dropDownMaxHeight";
      "required": false;
      "isSignal": true;
    };
    "dropDownHeight": {
      "alias": "dropDownHeight";
      "required": false;
      "isSignal": true;
    };
    "dropDownWidth": {
      "alias": "dropDownWidth";
      "required": false;
      "isSignal": true;
    };
    "dropDownMaxWidth": {
      "alias": "dropDownMaxWidth";
      "required": false;
      "isSignal": true;
    };
    "isDropDownOpen": {
      "alias": "isDropDownOpen";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "formatter": {
      "alias": "formatter";
      "required": false;
      "isSignal": true;
    };
    "parser": {
      "alias": "parser";
      "required": false;
      "isSignal": true;
    };
    "isFocused": {
      "alias": "isFocused";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "cleared": "cleared";
    "change": "change";
    "input": "input";
    "focus": "focus";
    "blur": "blur";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, [{
    directive: typeof i1.FormStatusHostDirective;
    inputs: {};
    outputs: {};
  }, {
    directive: typeof i1.FormFieldStatusHostDirective;
    inputs: {};
    outputs: {};
  }]>;
}
/**
 * Declares the methods available on DateTimeBoxComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type DateTimeBoxMethodNames = 'open' | 'close' | 'apply' | 'cancel' | 'focus' | 'blur' | 'clear' | 'reset' | 'checkValidity' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges' | 'toggle';
/**
 * Declares the methods interface for DateTimeBoxComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type DateTimeBoxComponentMethods = MethodMap<DateTimeBoxMethodNames>;
/**
 * @public
 */
export declare function provideDateTimeBoxComponent(config?: Partial<DateTimeBoxElement.Props>, intl?: Partial<DateTimeBoxElement['intl']> | Type<Partial<DateTimeBoxElement['intl']>>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-date-time-box.d.ts.map