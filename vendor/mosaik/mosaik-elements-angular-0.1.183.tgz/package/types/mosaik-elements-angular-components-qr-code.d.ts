import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { QRCodeElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/qr-code/QRCodeElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the QRCodeComponent.
 * Use this token to provide default properties for the QRCodeComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const QRCODE_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/media/qr-code/IQRCodeElementProps").IQRCodeElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class QRCodeComponent {
  /**
   * Signal input for the `text` property.
   *
   * @public
   */
  readonly text: InputSignal<QRCodeElement['text'] | undefined>;
  /**
   * Signal input for the `radius` property.
   *
   * @public
   */
  readonly radius: InputSignal<QRCodeElement['radius'] | undefined>;
  /**
   * Signal input for the `dimension` property.
   *
   * @public
   */
  readonly dimension: InputSignal<QRCodeElement['dimension'] | undefined>;
  /**
   * Signal input for the `errorCorrection` property.
   *
   * @public
   */
  readonly errorCorrection: InputSignal<QRCodeElement['errorCorrection'] | undefined>;
  /**
   * Signal input for the `backgroundColor` property.
   *
   * @public
   */
  readonly backgroundColor: InputSignal<QRCodeElement['backgroundColor'] | undefined>;
  /**
   * Signal input for the `foregroundColor` property.
   *
   * @public
   */
  readonly foregroundColor: InputSignal<QRCodeElement['foregroundColor'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<QRCodeElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<QRCodeElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<QRCodeElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<QRCodeElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<QRCodeElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<QRCodeElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Returns qr code image as data URL (see https://mdn.io/todataurl for the list of possible paramters).
   *
   * @public
   */
  toDataURL(...args: Parameters<QRCodeElement['toDataURL']>): ReturnType<QRCodeElement['toDataURL']>;
  /**
   * Returns qr code image as data URL trimmed from white space.
   *
   * @public
   */
  toBlob(...args: Parameters<QRCodeElement['toBlob']>): ReturnType<QRCodeElement['toBlob']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `toDataURL()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends QRCodeMethodNames>(method: TMethod, ...args: Parameters<QRCodeComponentMethods[TMethod]>): ReturnType<QRCodeComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof QRCodeElement>(property: TProperty, value: QRCodeElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<QRCodeElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<QRCodeComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<QRCodeComponent, "mosaik-qrcode", never, {
    "text": {
      "alias": "text";
      "required": false;
      "isSignal": true;
    };
    "radius": {
      "alias": "radius";
      "required": false;
      "isSignal": true;
    };
    "dimension": {
      "alias": "dimension";
      "required": false;
      "isSignal": true;
    };
    "errorCorrection": {
      "alias": "errorCorrection";
      "required": false;
      "isSignal": true;
    };
    "backgroundColor": {
      "alias": "backgroundColor";
      "required": false;
      "isSignal": true;
    };
    "foregroundColor": {
      "alias": "foregroundColor";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on QRCodeComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type QRCodeMethodNames = 'toDataURL' | 'toBlob';
/**
 * Declares the methods interface for QRCodeComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type QRCodeComponentMethods = MethodMap<QRCodeMethodNames>;
/**
 * @public
 */
export declare function provideQRCodeComponent(config?: Partial<QRCodeElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-qr-code.d.ts.map