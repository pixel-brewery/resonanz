import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef, Type } from "@angular/core";
import { SelectItemGroupElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/select/SelectItemGroupElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import * as i1 from "@pixel-brewery/mosaik-elements-angular/runtime";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { SelectItemVisualElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/select/SelectItemVisualElement";
import { SelectItemElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/select/SelectItemElement";
import { ControlValueAccessor } from "@angular/forms";
import { SelectElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/select/SelectElement";
/**
 * @public
 *
 * Injection token for the default properties of the SelectItemGroupComponent.
 * Use this token to provide default properties for the SelectItemGroupComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const SELECT_ITEM_GROUP_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/inputs/select/ISelectItemGroupElementProps").ISelectItemGroupElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot for Select Item elements within the group
 * @slot header - The header slot for custom group label content
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class SelectItemGroupComponent {
  /**
   * Signal input for the `header` property.
   *
   * @public
   */
  readonly header: InputSignal<SelectItemGroupElement['header'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<SelectItemGroupElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<SelectItemGroupElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<SelectItemGroupElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<SelectItemGroupElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<SelectItemGroupElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<SelectItemGroupElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof SelectItemGroupElement>(property: TProperty, value: SelectItemGroupElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<SelectItemGroupElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SelectItemGroupComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SelectItemGroupComponent, "mosaik-select-item-group", never, {
    "header": {
      "alias": "header";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on SelectItemGroupComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SelectItemGroupMethodNames = never;
/**
 * Declares the methods interface for SelectItemGroupComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SelectItemGroupComponentMethods = MethodMap<SelectItemGroupMethodNames>;
/**
 * @public
 */
export declare function provideSelectItemGroupComponent(config?: Partial<SelectItemGroupElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the SelectItemVisualComponent.
 * Use this token to provide default properties for the SelectItemVisualComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const SELECT_ITEM_VISUAL_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").ISelectItemVisualElementProps>>;
/**
 * @public
 *
 * @slot  - Default selection content.
 * @slot start - Content before the icon.
 * @slot icon - The selection icon.
 * @slot label - The selection label.
 * @slot end - Content after the label.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class SelectItemVisualComponent {
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<SelectItemVisualElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<SelectItemVisualElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<SelectItemVisualElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<SelectItemVisualElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<SelectItemVisualElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<SelectItemVisualElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: SelectItemVisualElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: SelectItemVisualElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   * @param args - The arguments of `assignToSlot`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * - `node` - The nodes to assign to the slot.
   */
  assignToSlot(...args: Parameters<SelectItemVisualElement['assignToSlot']>): ReturnType<SelectItemVisualElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   * This method extracts text content recursively, including from Shadow DOMs
   * and Custom Elements with known text properties (like `mosaik-text`).
   *
   * @public
   * @param args - The arguments of `getSlotContent`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<SelectItemVisualElement['getSlotContent']>): ReturnType<SelectItemVisualElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @param args - The arguments of `hasSlotContent`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<SelectItemVisualElement['hasSlotContent']>): ReturnType<SelectItemVisualElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @param args - The arguments of `hasSlot`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<SelectItemVisualElement['hasSlot']>): ReturnType<SelectItemVisualElement['hasSlot']>;
  /**
   * Called when the slot changes.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<SelectItemVisualElement['onSlotChanges']>): ReturnType<SelectItemVisualElement['onSlotChanges']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `assignToSlot()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends SelectItemVisualMethodNames>(method: TMethod, ...args: Parameters<SelectItemVisualComponentMethods[TMethod]>): ReturnType<SelectItemVisualComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof SelectItemVisualElement>(property: TProperty, value: SelectItemVisualElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<SelectItemVisualElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SelectItemVisualComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SelectItemVisualComponent, "mosaik-select-item-visual", never, {
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on SelectItemVisualComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SelectItemVisualMethodNames = 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges';
/**
 * Declares the methods interface for SelectItemVisualComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SelectItemVisualComponentMethods = MethodMap<SelectItemVisualMethodNames>;
/**
 * @public
 */
export declare function provideSelectItemVisualComponent(config?: Partial<SelectItemVisualElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the SelectItemComponent.
 * Use this token to provide default properties for the SelectItemComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const SELECT_ITEM_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/inputs/select/ISelectItemElementProps").ISelectItemElementProps>>;
/**
 * @public
 *
 * @slot checkmark - The checkmark slot.
 * @slot end - The end slot.
 * @slot icon - The icon display area alongside the label
 * @slot start - Content placed before the icon (e.g., status indicators, badges)
 * @slot selection - A dedicated visual instance used in the Select value surface.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class SelectItemComponent {
  /**
   * Signal input for the `icon` property.
   *
   * @public
   */
  readonly icon: InputSignal<SelectItemElement['icon'] | undefined>;
  /**
   * Signal input for the `isActive` property.
   *
   * @public
   */
  readonly isActive: InputSignal<SelectItemElement['isActive'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<SelectItemElement['themeName'] | undefined>;
  /**
   * Signal input for the `ripple` property.
   *
   * @public
   */
  readonly ripple: InputSignal<SelectItemElement['ripple'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<SelectItemElement['disabled'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<SelectItemElement['variant'] | undefined>;
  /**
   * Signal input for the `isFocused` property.
   *
   * @public
   */
  readonly isFocused: InputSignal<SelectItemElement['isFocused'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<SelectItemElement['label'] | undefined>;
  /**
   * Signal input for the `isSelected` property.
   *
   * @public
   */
  readonly isSelected: InputSignal<SelectItemElement['isSelected'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<SelectItemElement['value'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<SelectItemElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<SelectItemElement['lang'] | undefined>;
  /**
   * Output signal for the `selected` event.
   *
   * @public
   */
  readonly selected: OutputEmitterRef<ElementEventDetail<SelectItemElement, 'selected'>>;
  /**
   * Output signal for the `deselected` event.
   *
   * @public
   */
  readonly deselected: OutputEmitterRef<ElementEventDetail<SelectItemElement, 'deselected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<SelectItemElement, 'changed'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<SelectItemElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<SelectItemElement, 'disconnected'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Selects the item and fires `selected`. Does nothing when the item is already selected.
   *
   * @public
   * @param args - The arguments of `select`:
   * - `forceUpdate` - When `true`, the parent selector also selects the item.
   */
  select(...args: Parameters<SelectItemElement['select']>): ReturnType<SelectItemElement['select']>;
  /**
   * Deselects the item and fires `deselected`. Does nothing when the item is not selected.
   *
   * @public
   * @param args - The arguments of `deselect`:
   * - `forceUpdate` - When `true`, the parent selector also deselects the item.
   */
  deselect(...args: Parameters<SelectItemElement['deselect']>): ReturnType<SelectItemElement['deselect']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `select()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends SelectItemMethodNames>(method: TMethod, ...args: Parameters<SelectItemComponentMethods[TMethod]>): ReturnType<SelectItemComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof SelectItemElement>(property: TProperty, value: SelectItemElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<SelectItemElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SelectItemComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SelectItemComponent, "mosaik-select-item", never, {
    "icon": {
      "alias": "icon";
      "required": false;
      "isSignal": true;
    };
    "isActive": {
      "alias": "isActive";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "ripple": {
      "alias": "ripple";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "isFocused": {
      "alias": "isFocused";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "isSelected": {
      "alias": "isSelected";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "selected": "selected";
    "deselected": "deselected";
    "changed": "changed";
    "connected": "connected";
    "disconnected": "disconnected";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on SelectItemComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SelectItemMethodNames = 'select' | 'deselect';
/**
 * Declares the methods interface for SelectItemComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SelectItemComponentMethods = MethodMap<SelectItemMethodNames>;
/**
 * @public
 */
export declare function provideSelectItemComponent(config?: Partial<SelectItemElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the SelectComponent.
 * Use this token to provide default properties for the SelectComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const SELECT_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/inputs/select/ISelectElementProps").ISelectElementProps>>;
/**
 * @public
 *
 * Injection token for the intl configuration of the SelectComponent.
 * Provide a partial intl object or an injectable class that resolves translations.
 * This allows third-party applications to override the default intl labels
 * globally, per route, or per component via Angular's dependency injection.
 *
 * Merge order: Foundation defaults → DI intl → [intl] input binding.
 */
export declare const SELECT_INTL: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").SelectElementIntl>>;
/**
 * @public
 *
 * @slot  - Default slot for select items and groups.
 * @slot filter - Custom filter input for the dropdown.
 * @slot prefix - Content placed before the input value.
 * @slot suffix - Content placed after the input value.
 * @slot trigger - Custom content that replaces the selected item presentation.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class SelectComponent implements ControlValueAccessor {
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<Partial<SelectElement['intl']> | undefined>;
  /**
   * Signal input for the `isEditable` property.
   *
   * @public
   */
  readonly isEditable: InputSignal<SelectElement['isEditable'] | undefined>;
  /**
   * Signal input for the `isReadOnly` property.
   *
   * @public
   */
  readonly isReadOnly: InputSignal<SelectElement['isReadOnly'] | undefined>;
  /**
   * Signal input for the `placeholder` property.
   *
   * @public
   */
  readonly placeholder: InputSignal<SelectElement['placeholder'] | undefined>;
  /**
   * Signal input for the `required` property.
   *
   * @public
   */
  readonly required: InputSignal<SelectElement['required'] | undefined>;
  /**
   * Signal input for the `textAlign` property.
   *
   * @public
   */
  readonly textAlign: InputSignal<SelectElement['textAlign'] | undefined>;
  /**
   * Signal input for the `showScrollButtons` property.
   *
   * @public
   */
  readonly showScrollButtons: InputSignal<SelectElement['showScrollButtons'] | undefined>;
  /**
   * Signal input for the `showScrollbar` property.
   *
   * @public
   */
  readonly showScrollbar: InputSignal<SelectElement['showScrollbar'] | undefined>;
  /**
   * Signal input for the `dropDownPlacement` property.
   *
   * @public
   */
  readonly dropDownPlacement: InputSignal<SelectElement['dropDownPlacement'] | undefined>;
  /**
   * Signal input for the `dropDownStrategy` property.
   *
   * @public
   */
  readonly dropDownStrategy: InputSignal<SelectElement['dropDownStrategy'] | undefined>;
  /**
   * Signal input for the `dropDownDistance` property.
   *
   * @public
   */
  readonly dropDownDistance: InputSignal<SelectElement['dropDownDistance'] | undefined>;
  /**
   * Signal input for the `dropDownSkidding` property.
   *
   * @public
   */
  readonly dropDownSkidding: InputSignal<SelectElement['dropDownSkidding'] | undefined>;
  /**
   * Signal input for the `dropDownStaysOpen` property.
   *
   * @public
   */
  readonly dropDownStaysOpen: InputSignal<SelectElement['dropDownStaysOpen'] | undefined>;
  /**
   * Signal input for the `dropDownMaxHeight` property.
   *
   * @public
   */
  readonly dropDownMaxHeight: InputSignal<SelectElement['dropDownMaxHeight'] | undefined>;
  /**
   * Signal input for the `dropDownHeight` property.
   *
   * @public
   */
  readonly dropDownHeight: InputSignal<SelectElement['dropDownHeight'] | undefined>;
  /**
   * Signal input for the `dropDownWidth` property.
   *
   * @public
   */
  readonly dropDownWidth: InputSignal<SelectElement['dropDownWidth'] | undefined>;
  /**
   * Signal input for the `dropDownMaxWidth` property.
   *
   * @public
   */
  readonly dropDownMaxWidth: InputSignal<SelectElement['dropDownMaxWidth'] | undefined>;
  /**
   * Signal input for the `isDropDownOpen` property.
   *
   * @public
   */
  readonly isDropDownOpen: InputSignal<SelectElement['isDropDownOpen'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<SelectElement['appearance'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<SelectElement['variant'] | undefined>;
  /**
   * Signal input for the `size` property.
   *
   * @public
   */
  readonly size: InputSignal<SelectElement['size'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<SelectElement['label'] | undefined>;
  /**
   * Signal input for the `isClearable` property.
   *
   * @public
   */
  readonly isClearable: InputSignal<SelectElement['isClearable'] | undefined>;
  /**
   * Signal input for the `invalid` property.
   *
   * @public
   */
  readonly invalid: InputSignal<SelectElement['invalid'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<SelectElement['disabled'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<SelectElement['value'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<SelectElement['themeName'] | undefined>;
  /**
   * Signal input for the `showFilter` property.
   *
   * @public
   */
  readonly showFilter: InputSignal<SelectElement['showFilter'] | undefined>;
  /**
   * Signal input for the `filterMemberPath` property.
   *
   * @public
   */
  readonly filterMemberPath: InputSignal<SelectElement['filterMemberPath'] | undefined>;
  /**
   * Signal input for the `filter` property.
   *
   * @public
   */
  readonly filter: InputSignal<SelectElement['filter'] | undefined>;
  /**
   * Signal input for the `filterPlaceholder` property.
   *
   * @public
   */
  readonly filterPlaceholder: InputSignal<SelectElement['filterPlaceholder'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<SelectElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<SelectElement['lang'] | undefined>;
  /**
   * Output signal for the `cleared` event.
   *
   * @public
   */
  readonly cleared: OutputEmitterRef<ElementEventDetail<SelectElement, 'cleared'>>;
  /**
   * Output signal for the `selectionChanged` event.
   *
   * @public
   */
  readonly selectionChanged: OutputEmitterRef<ElementEventDetail<SelectElement, 'selectionChanged'>>;
  /**
   * Output signal for the `itemsChanged` event.
   *
   * @public
   */
  readonly itemsChanged: OutputEmitterRef<ElementEventDetail<SelectElement, 'itemsChanged'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<SelectElement, 'changed'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<SelectElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<SelectElement, 'disconnected'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: SelectElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: SelectElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  private readonly _accessor;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Applies a value supplied by Angular forms to the native control.
   *
   * @public
   */
  writeValue(obj: unknown): void;
  /**
   * Registers the callback notified when the native control value changes.
   *
   * @public
   */
  registerOnChange(fn: unknown): void;
  /**
   * Registers the callback notified when the native control is touched.
   *
   * @public
   */
  registerOnTouched(fn: unknown): void;
  /**
   * Applies the disabled state supplied by Angular forms.
   *
   * @public
   */
  setDisabledState?(isDisabled: boolean): void;
  /**
   * Resets the value, all kinds of validation and errors.
   *
   * @public
   */
  reset(...args: Parameters<SelectElement['reset']>): ReturnType<SelectElement['reset']>;
  /**
   * Checks the validity of the element and returns `true` if it is valid; otherwise, `false`.
   *
   * @public
   */
  checkValidity(...args: Parameters<SelectElement['checkValidity']>): ReturnType<SelectElement['checkValidity']>;
  /**
   * Clears the value of the element but not the validation.
   *
   * @public
   */
  clear(...args: Parameters<SelectElement['clear']>): ReturnType<SelectElement['clear']>;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<SelectElement['onSlotChanges']>): ReturnType<SelectElement['onSlotChanges']>;
  /**
   * Returns the scrollable viewport of the drop down, which is owned by the
   * internal scroll primitive rather than by the element itself.
   *
   * @public
   */
  getScrollableElement(...args: Parameters<SelectElement['getScrollableElement']>): ReturnType<SelectElement['getScrollableElement']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<SelectElement['assignToSlot']>): ReturnType<SelectElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<SelectElement['getSlotContent']>): ReturnType<SelectElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<SelectElement['hasSlotContent']>): ReturnType<SelectElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<SelectElement['hasSlot']>): ReturnType<SelectElement['hasSlot']>;
  /**
   * Opens the drop down.
   *
   * @public
   */
  open(...args: Parameters<SelectElement['open']>): ReturnType<SelectElement['open']>;
  /**
   * Closes the drop down.
   *
   * @public
   */
  close(...args: Parameters<SelectElement['close']>): ReturnType<SelectElement['close']>;
  /**
   * Toggles the drop down.
   *
   * @public
   */
  toggle(...args: Parameters<SelectElement['toggle']>): ReturnType<SelectElement['toggle']>;
  /**
   * Select the item.
   *
   * @public
   * @param args - The arguments of `select`:
   * - `item` - The element, index or value to select.
   */
  select(...args: Parameters<SelectElement['select']>): ReturnType<SelectElement['select']>;
  /**
   * Deselect the item.
   *
   * @public
   * @param args - The arguments of `deselect`:
   * - `item` - The element or index to deselect.
   */
  deselect(...args: Parameters<SelectElement['deselect']>): ReturnType<SelectElement['deselect']>;
  /**
   * Resets the current selection.
   *
   * @public
   */
  resetSelection(...args: Parameters<SelectElement['resetSelection']>): ReturnType<SelectElement['resetSelection']>;
  /**
   * Select the next item after current selected item/index.
   *
   * @public
   */
  selectNext(...args: Parameters<SelectElement['selectNext']>): ReturnType<SelectElement['selectNext']>;
  /**
   * Select the previous item before current selected item/index.
   *
   * @public
   */
  selectPrevious(...args: Parameters<SelectElement['selectPrevious']>): ReturnType<SelectElement['selectPrevious']>;
  /**
   * Select the first item.
   *
   * @public
   */
  selectFirst(...args: Parameters<SelectElement['selectFirst']>): ReturnType<SelectElement['selectFirst']>;
  /**
   * Select the last item.
   *
   * @public
   */
  selectLast(...args: Parameters<SelectElement['selectLast']>): ReturnType<SelectElement['selectLast']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `reset()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends SelectMethodNames>(method: TMethod, ...args: Parameters<SelectComponentMethods[TMethod]>): ReturnType<SelectComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof SelectElement>(property: TProperty, value: SelectElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<SelectElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SelectComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SelectComponent, "mosaik-select", never, {
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "isEditable": {
      "alias": "isEditable";
      "required": false;
      "isSignal": true;
    };
    "isReadOnly": {
      "alias": "isReadOnly";
      "required": false;
      "isSignal": true;
    };
    "placeholder": {
      "alias": "placeholder";
      "required": false;
      "isSignal": true;
    };
    "required": {
      "alias": "required";
      "required": false;
      "isSignal": true;
    };
    "textAlign": {
      "alias": "textAlign";
      "required": false;
      "isSignal": true;
    };
    "showScrollButtons": {
      "alias": "showScrollButtons";
      "required": false;
      "isSignal": true;
    };
    "showScrollbar": {
      "alias": "showScrollbar";
      "required": false;
      "isSignal": true;
    };
    "dropDownPlacement": {
      "alias": "dropDownPlacement";
      "required": false;
      "isSignal": true;
    };
    "dropDownStrategy": {
      "alias": "dropDownStrategy";
      "required": false;
      "isSignal": true;
    };
    "dropDownDistance": {
      "alias": "dropDownDistance";
      "required": false;
      "isSignal": true;
    };
    "dropDownSkidding": {
      "alias": "dropDownSkidding";
      "required": false;
      "isSignal": true;
    };
    "dropDownStaysOpen": {
      "alias": "dropDownStaysOpen";
      "required": false;
      "isSignal": true;
    };
    "dropDownMaxHeight": {
      "alias": "dropDownMaxHeight";
      "required": false;
      "isSignal": true;
    };
    "dropDownHeight": {
      "alias": "dropDownHeight";
      "required": false;
      "isSignal": true;
    };
    "dropDownWidth": {
      "alias": "dropDownWidth";
      "required": false;
      "isSignal": true;
    };
    "dropDownMaxWidth": {
      "alias": "dropDownMaxWidth";
      "required": false;
      "isSignal": true;
    };
    "isDropDownOpen": {
      "alias": "isDropDownOpen";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "isClearable": {
      "alias": "isClearable";
      "required": false;
      "isSignal": true;
    };
    "invalid": {
      "alias": "invalid";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "showFilter": {
      "alias": "showFilter";
      "required": false;
      "isSignal": true;
    };
    "filterMemberPath": {
      "alias": "filterMemberPath";
      "required": false;
      "isSignal": true;
    };
    "filter": {
      "alias": "filter";
      "required": false;
      "isSignal": true;
    };
    "filterPlaceholder": {
      "alias": "filterPlaceholder";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "cleared": "cleared";
    "selectionChanged": "selectionChanged";
    "itemsChanged": "itemsChanged";
    "changed": "changed";
    "connected": "connected";
    "disconnected": "disconnected";
  }, never, ["*"], true, [{
    directive: typeof i1.FormStatusHostDirective;
    inputs: {};
    outputs: {};
  }, {
    directive: typeof i1.FormFieldStatusHostDirective;
    inputs: {};
    outputs: {};
  }]>;
}
/**
 * Declares the methods available on SelectComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SelectMethodNames = 'reset' | 'checkValidity' | 'clear' | 'onSlotChanges' | 'getScrollableElement' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'open' | 'close' | 'toggle' | 'select' | 'deselect' | 'resetSelection' | 'selectNext' | 'selectPrevious' | 'selectFirst' | 'selectLast';
/**
 * Declares the methods interface for SelectComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SelectComponentMethods = MethodMap<SelectMethodNames>;
/**
 * @public
 */
export declare function provideSelectComponent(config?: Partial<SelectElement.Props>, intl?: Partial<SelectElement['intl']> | Type<Partial<SelectElement['intl']>>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-select.d.ts.map