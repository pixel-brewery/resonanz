import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { AvatarGroupElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/avatar/AvatarGroupElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import * as i1 from "@pixel-brewery/mosaik-elements-angular/runtime";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { ControlValueAccessor } from "@angular/forms";
import { AvatarElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/avatar/AvatarElement";
/**
 * @public
 *
 * Injection token for the default properties of the AvatarGroupComponent.
 * Use this token to provide default properties for the AvatarGroupComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const AVATAR_GROUP_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/media/avatar/IAvatarGroupElementProps").IAvatarGroupElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot.
 * @slot overflow - The overflow slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class AvatarGroupComponent {
  /**
   * Signal input for the `maxLength` property.
   *
   * @public
   */
  readonly maxLength: InputSignal<AvatarGroupElement['maxLength'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<AvatarGroupElement['themeName'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<AvatarGroupElement['disabled'] | undefined>;
  /**
   * Signal input for the `size` property.
   *
   * @public
   */
  readonly size: InputSignal<AvatarGroupElement['size'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<AvatarGroupElement['variant'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<AvatarGroupElement['appearance'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<AvatarGroupElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<AvatarGroupElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<AvatarGroupElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<AvatarGroupElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<AvatarGroupElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof AvatarGroupElement>(property: TProperty, value: AvatarGroupElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<AvatarGroupElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<AvatarGroupComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AvatarGroupComponent, "mosaik-avatar-group", never, {
    "maxLength": {
      "alias": "maxLength";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on AvatarGroupComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type AvatarGroupMethodNames = never;
/**
 * Declares the methods interface for AvatarGroupComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type AvatarGroupComponentMethods = MethodMap<AvatarGroupMethodNames>;
/**
 * @public
 */
export declare function provideAvatarGroupComponent(config?: Partial<AvatarGroupElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the AvatarComponent.
 * Use this token to provide default properties for the AvatarComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const AVATAR_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/media/avatar/IAvatarElementProps").IAvatarElementProps>>;
/**
 * @public
 *
 * @slot  - Default content for avatar display (overrides automatic text/icon generation)
 * @slot badge - Status indicator or notification badge positioned on the avatar
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class AvatarComponent implements ControlValueAccessor {
  /**
   * Signal input for the `text` property.
   *
   * @public
   */
  readonly text: InputSignal<AvatarElement['text'] | undefined>;
  /**
   * Signal input for the `textAccessor` property.
   *
   * @public
   */
  readonly textAccessor: InputSignal<AvatarElement['textAccessor'] | undefined>;
  /**
   * Signal input for the `icon` property.
   *
   * @public
   */
  readonly icon: InputSignal<AvatarElement['icon'] | undefined>;
  /**
   * Signal input for the `src` property.
   *
   * @public
   */
  readonly src: InputSignal<AvatarElement['src'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<AvatarElement['themeName'] | undefined>;
  /**
   * Signal input for the `size` property.
   *
   * @public
   */
  readonly size: InputSignal<AvatarElement['size'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<AvatarElement['appearance'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<AvatarElement['variant'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<AvatarElement['disabled'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<AvatarElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<AvatarElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<AvatarElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<AvatarElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<AvatarElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  private readonly _accessor;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Applies a value supplied by Angular forms to the native control.
   *
   * @public
   */
  writeValue(obj: unknown): void;
  /**
   * Registers the callback notified when the native control value changes.
   *
   * @public
   */
  registerOnChange(fn: unknown): void;
  /**
   * Registers the callback notified when the native control is touched.
   *
   * @public
   */
  registerOnTouched(fn: unknown): void;
  /**
   * Applies the disabled state supplied by Angular forms.
   *
   * @public
   */
  setDisabledState?(isDisabled: boolean): void;
  /**
   * Calls `changeTextAccessor` on the `mosaik-avatar` element.
   *
   * @public
   */
  changeTextAccessor(...args: Parameters<AvatarElement['changeTextAccessor']>): ReturnType<AvatarElement['changeTextAccessor']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `changeTextAccessor()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends AvatarMethodNames>(method: TMethod, ...args: Parameters<AvatarComponentMethods[TMethod]>): ReturnType<AvatarComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof AvatarElement>(property: TProperty, value: AvatarElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<AvatarElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<AvatarComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AvatarComponent, "mosaik-avatar", never, {
    "text": {
      "alias": "text";
      "required": false;
      "isSignal": true;
    };
    "textAccessor": {
      "alias": "textAccessor";
      "required": false;
      "isSignal": true;
    };
    "icon": {
      "alias": "icon";
      "required": false;
      "isSignal": true;
    };
    "src": {
      "alias": "src";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, [{
    directive: typeof i1.FormStatusHostDirective;
    inputs: {};
    outputs: {};
  }, {
    directive: typeof i1.FormFieldStatusHostDirective;
    inputs: {};
    outputs: {};
  }]>;
}
/**
 * Declares the methods available on AvatarComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type AvatarMethodNames = 'changeTextAccessor';
/**
 * Declares the methods interface for AvatarComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type AvatarComponentMethods = MethodMap<AvatarMethodNames>;
/**
 * @public
 */
export declare function provideAvatarComponent(config?: Partial<AvatarElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-avatar.d.ts.map