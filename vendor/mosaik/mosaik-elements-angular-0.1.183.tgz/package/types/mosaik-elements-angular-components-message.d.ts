import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { MessageContentElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/grouping/message/MessageContentElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { MessageElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/grouping/message/MessageElement";
/**
 * @public
 *
 * Injection token for the default properties of the MessageContentComponent.
 * Use this token to provide default properties for the MessageContentComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const MESSAGE_CONTENT_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/grouping/message/IMessageContentElementProps").IMessageContentElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot for placing custom content instead of the text property.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class MessageContentComponent {
  /**
   * Signal input for the `text` property.
   *
   * @public
   */
  readonly text: InputSignal<MessageContentElement['text'] | undefined>;
  /**
   * Signal input for the `collapsedLines` property.
   *
   * @public
   */
  readonly collapsedLines: InputSignal<MessageContentElement['collapsedLines'] | undefined>;
  /**
   * Signal input for the `isExpanded` property.
   *
   * @public
   */
  readonly isExpanded: InputSignal<MessageContentElement['isExpanded'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<MessageContentElement['disabled'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<MessageContentElement['variant'] | undefined>;
  /**
   * Signal input for the `formatter` property.
   *
   * @public
   */
  readonly formatter: InputSignal<MessageContentElement['formatter'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<MessageContentElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<MessageContentElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<MessageContentElement['lang'] | undefined>;
  /**
   * Output signal for the `expanded` event.
   *
   * @public
   */
  readonly expanded: OutputEmitterRef<ElementEventDetail<MessageContentElement, 'expanded'>>;
  /**
   * Output signal for the `collapsed` event.
   *
   * @public
   */
  readonly collapsed: OutputEmitterRef<ElementEventDetail<MessageContentElement, 'collapsed'>>;
  /**
   * Output signal for the `toggled` event.
   *
   * @public
   */
  readonly toggled: OutputEmitterRef<ElementEventDetail<MessageContentElement, 'toggled'>>;
  /**
   * Output signal for the `contentChanged` event.
   *
   * @public
   */
  readonly contentChanged: OutputEmitterRef<ElementEventDetail<MessageContentElement, 'contentChanged'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<MessageContentElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<MessageContentElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<MessageContentElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: MessageContentElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: MessageContentElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Expands the element.
   *
   * @public
   */
  expand(...args: Parameters<MessageContentElement['expand']>): ReturnType<MessageContentElement['expand']>;
  /**
   * Collapses the element.
   *
   * @public
   */
  collapse(...args: Parameters<MessageContentElement['collapse']>): ReturnType<MessageContentElement['collapse']>;
  /**
   * Toggles the element between expanded and collapsed states.
   *
   * @public
   */
  toggle(...args: Parameters<MessageContentElement['toggle']>): ReturnType<MessageContentElement['toggle']>;
  /**
   * This method is invoked when the `isExpanded` property is changed.
   * Override this method to add custom behavior when the expanded state changes.
   *
   * @public
   */
  onIsExpandedChanged(...args: Parameters<MessageContentElement['onIsExpandedChanged']>): ReturnType<MessageContentElement['onIsExpandedChanged']>;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<MessageContentElement['onSlotChanges']>): ReturnType<MessageContentElement['onSlotChanges']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<MessageContentElement['assignToSlot']>): ReturnType<MessageContentElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<MessageContentElement['getSlotContent']>): ReturnType<MessageContentElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<MessageContentElement['hasSlotContent']>): ReturnType<MessageContentElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<MessageContentElement['hasSlot']>): ReturnType<MessageContentElement['hasSlot']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `expand()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends MessageContentMethodNames>(method: TMethod, ...args: Parameters<MessageContentComponentMethods[TMethod]>): ReturnType<MessageContentComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof MessageContentElement>(property: TProperty, value: MessageContentElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<MessageContentElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<MessageContentComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<MessageContentComponent, "mosaik-message-content", never, {
    "text": {
      "alias": "text";
      "required": false;
      "isSignal": true;
    };
    "collapsedLines": {
      "alias": "collapsedLines";
      "required": false;
      "isSignal": true;
    };
    "isExpanded": {
      "alias": "isExpanded";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "formatter": {
      "alias": "formatter";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "expanded": "expanded";
    "collapsed": "collapsed";
    "toggled": "toggled";
    "contentChanged": "contentChanged";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on MessageContentComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type MessageContentMethodNames = 'expand' | 'collapse' | 'toggle' | 'onIsExpandedChanged' | 'onSlotChanges' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot';
/**
 * Declares the methods interface for MessageContentComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type MessageContentComponentMethods = MethodMap<MessageContentMethodNames>;
/**
 * @public
 */
export declare function provideMessageContentComponent(config?: Partial<MessageContentElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the MessageComponent.
 * Use this token to provide default properties for the MessageComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const MESSAGE_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/grouping/message/IMessageElementProps").IMessageElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot for placing rich content inside the message (only used when expandable).
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class MessageComponent {
  /**
   * Signal input for the `icon` property.
   *
   * @public
   */
  readonly icon: InputSignal<MessageElement['icon'] | undefined>;
  /**
   * Signal input for the `iconSize` property.
   *
   * @public
   */
  readonly iconSize: InputSignal<MessageElement['iconSize'] | undefined>;
  /**
   * Signal input for the `header` property.
   *
   * @public
   */
  readonly header: InputSignal<MessageElement['header'] | undefined>;
  /**
   * Signal input for the `content` property.
   *
   * @public
   */
  readonly content: InputSignal<MessageElement['content'] | undefined>;
  /**
   * Signal input for the `expandable` property.
   *
   * @public
   */
  readonly expandable: InputSignal<MessageElement['expandable'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<MessageElement['themeName'] | undefined>;
  /**
   * Signal input for the `isExpanded` property.
   *
   * @public
   */
  readonly isExpanded: InputSignal<MessageElement['isExpanded'] | undefined>;
  /**
   * Signal input for the `enter` property.
   *
   * @public
   */
  readonly enter: InputSignal<MessageElement['enter'] | undefined>;
  /**
   * Signal input for the `exit` property.
   *
   * @public
   */
  readonly exit: InputSignal<MessageElement['exit'] | undefined>;
  /**
   * Signal input for the `closeable` property.
   *
   * @public
   */
  readonly closeable: InputSignal<MessageElement['closeable'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<MessageElement['disabled'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<MessageElement['variant'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<MessageElement['appearance'] | undefined>;
  /**
   * Signal input for the `fit` property.
   *
   * @public
   */
  readonly fit: InputSignal<MessageElement['fit'] | undefined>;
  /**
   * Signal input for the `formatter` property.
   *
   * @public
   */
  readonly formatter: InputSignal<MessageElement['formatter'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<MessageElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<MessageElement['lang'] | undefined>;
  /**
   * Output signal for the `closed` event.
   *
   * @public
   */
  readonly closed: OutputEmitterRef<ElementEventDetail<MessageElement, 'closed'>>;
  /**
   * Output signal for the `expanded` event.
   *
   * @public
   */
  readonly expanded: OutputEmitterRef<ElementEventDetail<MessageElement, 'expanded'>>;
  /**
   * Output signal for the `collapsed` event.
   *
   * @public
   */
  readonly collapsed: OutputEmitterRef<ElementEventDetail<MessageElement, 'collapsed'>>;
  /**
   * Output signal for the `toggled` event.
   *
   * @public
   */
  readonly toggled: OutputEmitterRef<ElementEventDetail<MessageElement, 'toggled'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<MessageElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<MessageElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<MessageElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: MessageElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: MessageElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Closes the `MessageElement`.
   *
   * @public
   */
  close(...args: Parameters<MessageElement['close']>): ReturnType<MessageElement['close']>;
  /**
   * Toggles the message between expanded and collapsed states.
   * Only works when `expandable` is `true`.
   *
   * @public
   */
  toggle(...args: Parameters<MessageElement['toggle']>): ReturnType<MessageElement['toggle']>;
  /**
   * Expands the message content.
   * Only works when `expandable` is `true`.
   *
   * @public
   */
  expand(...args: Parameters<MessageElement['expand']>): ReturnType<MessageElement['expand']>;
  /**
   * Collapses the message content.
   * Only works when `expandable` is `true`.
   *
   * @public
   */
  collapse(...args: Parameters<MessageElement['collapse']>): ReturnType<MessageElement['collapse']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<MessageElement['assignToSlot']>): ReturnType<MessageElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<MessageElement['getSlotContent']>): ReturnType<MessageElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<MessageElement['hasSlotContent']>): ReturnType<MessageElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<MessageElement['hasSlot']>): ReturnType<MessageElement['hasSlot']>;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<MessageElement['onSlotChanges']>): ReturnType<MessageElement['onSlotChanges']>;
  /**
   * Executes the animation.
   *
   * @public
   */
  play(...args: Parameters<MessageElement['play']>): ReturnType<MessageElement['play']>;
  /**
   * A lifecycle hook that is invoked when the element is added to the DOM.
   *
   * @public
   */
  onEnterAnimation(...args: Parameters<NonNullable<MessageElement['onEnterAnimation']>>): ReturnType<NonNullable<MessageElement['onEnterAnimation']>> | undefined;
  /**
   * A lifecycle hook that is invoked when the element is removed from the DOM.
   *
   * @public
   */
  onExitAnimation(...args: Parameters<NonNullable<MessageElement['onExitAnimation']>>): ReturnType<NonNullable<MessageElement['onExitAnimation']>> | undefined;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `close()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends MessageMethodNames>(method: TMethod, ...args: Parameters<MessageComponentMethods[TMethod]>): ReturnType<MessageComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof MessageElement>(property: TProperty, value: MessageElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<MessageElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<MessageComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<MessageComponent, "mosaik-message", never, {
    "icon": {
      "alias": "icon";
      "required": false;
      "isSignal": true;
    };
    "iconSize": {
      "alias": "iconSize";
      "required": false;
      "isSignal": true;
    };
    "header": {
      "alias": "header";
      "required": false;
      "isSignal": true;
    };
    "content": {
      "alias": "content";
      "required": false;
      "isSignal": true;
    };
    "expandable": {
      "alias": "expandable";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "isExpanded": {
      "alias": "isExpanded";
      "required": false;
      "isSignal": true;
    };
    "enter": {
      "alias": "enter";
      "required": false;
      "isSignal": true;
    };
    "exit": {
      "alias": "exit";
      "required": false;
      "isSignal": true;
    };
    "closeable": {
      "alias": "closeable";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "fit": {
      "alias": "fit";
      "required": false;
      "isSignal": true;
    };
    "formatter": {
      "alias": "formatter";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "closed": "closed";
    "expanded": "expanded";
    "collapsed": "collapsed";
    "toggled": "toggled";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on MessageComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type MessageMethodNames = 'close' | 'toggle' | 'expand' | 'collapse' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges' | 'play' | 'onEnterAnimation' | 'onExitAnimation';
/**
 * Declares the methods interface for MessageComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type MessageComponentMethods = MethodMap<MessageMethodNames>;
/**
 * @public
 */
export declare function provideMessageComponent(config?: Partial<MessageElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-message.d.ts.map