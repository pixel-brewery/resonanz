import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { AudioElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/audio/AudioElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the AudioComponent.
 * Use this token to provide default properties for the AudioComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const AUDIO_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/media/audio/IAudioElementProps").IAudioElementProps>>;
/**
 * @public
 *
 * @slot  - The default content slot.
 * @slot legend - The legend slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class AudioComponent {
  /**
   * Signal input for the `src` property.
   *
   * @public
   */
  readonly src: InputSignal<AudioElement['src'] | undefined>;
  /**
   * Signal input for the `autoPlay` property.
   *
   * @public
   */
  readonly autoPlay: InputSignal<AudioElement['autoPlay'] | undefined>;
  /**
   * Signal input for the `showControls` property.
   *
   * @public
   */
  readonly showControls: InputSignal<AudioElement['showControls'] | undefined>;
  /**
   * Signal input for the `legend` property.
   *
   * @public
   */
  readonly legend: InputSignal<AudioElement['legend'] | undefined>;
  /**
   * Signal input for the `legendPosition` property.
   *
   * @public
   */
  readonly legendPosition: InputSignal<AudioElement['legendPosition'] | undefined>;
  /**
   * Signal input for the `ratio` property.
   *
   * @public
   */
  readonly ratio: InputSignal<AudioElement['ratio'] | undefined>;
  /**
   * Signal input for the `muted` property.
   *
   * @public
   */
  readonly muted: InputSignal<AudioElement['muted'] | undefined>;
  /**
   * Signal input for the `loop` property.
   *
   * @public
   */
  readonly loop: InputSignal<AudioElement['loop'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<AudioElement['themeName'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<AudioElement['disabled'] | undefined>;
  /**
   * Signal input for the `width` property.
   *
   * @public
   */
  readonly width: InputSignal<AudioElement['width'] | undefined>;
  /**
   * Signal input for the `height` property.
   *
   * @public
   */
  readonly height: InputSignal<AudioElement['height'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<AudioElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<AudioElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<AudioElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<AudioElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<AudioElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Plays the audio.
   *
   * @public
   */
  play(...args: Parameters<AudioElement['play']>): ReturnType<AudioElement['play']>;
  /**
   * Pauses the audio.
   *
   * @public
   */
  pause(...args: Parameters<AudioElement['pause']>): ReturnType<AudioElement['pause']>;
  /**
   * Toggles playback.
   *
   * @public
   */
  toggle(...args: Parameters<AudioElement['toggle']>): ReturnType<AudioElement['toggle']>;
  /**
   * Reloads the audio source.
   *
   * @public
   */
  load(...args: Parameters<AudioElement['load']>): ReturnType<AudioElement['load']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `play()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends AudioMethodNames>(method: TMethod, ...args: Parameters<AudioComponentMethods[TMethod]>): ReturnType<AudioComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof AudioElement>(property: TProperty, value: AudioElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<AudioElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<AudioComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AudioComponent, "mosaik-audio", never, {
    "src": {
      "alias": "src";
      "required": false;
      "isSignal": true;
    };
    "autoPlay": {
      "alias": "autoPlay";
      "required": false;
      "isSignal": true;
    };
    "showControls": {
      "alias": "showControls";
      "required": false;
      "isSignal": true;
    };
    "legend": {
      "alias": "legend";
      "required": false;
      "isSignal": true;
    };
    "legendPosition": {
      "alias": "legendPosition";
      "required": false;
      "isSignal": true;
    };
    "ratio": {
      "alias": "ratio";
      "required": false;
      "isSignal": true;
    };
    "muted": {
      "alias": "muted";
      "required": false;
      "isSignal": true;
    };
    "loop": {
      "alias": "loop";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "width": {
      "alias": "width";
      "required": false;
      "isSignal": true;
    };
    "height": {
      "alias": "height";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on AudioComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type AudioMethodNames = 'play' | 'pause' | 'toggle' | 'load';
/**
 * Declares the methods interface for AudioComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type AudioComponentMethods = MethodMap<AudioMethodNames>;
/**
 * @public
 */
export declare function provideAudioComponent(config?: Partial<AudioElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-audio.d.ts.map