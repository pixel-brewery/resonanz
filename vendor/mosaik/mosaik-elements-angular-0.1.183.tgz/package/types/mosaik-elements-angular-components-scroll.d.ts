import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { ScrollElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/scroll/ScrollElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the ScrollComponent.
 * Use this token to provide default properties for the ScrollComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const SCROLL_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/primitives/scroll/IScrollElementProps").IScrollElementProps>>;
/**
 * @public
 *
 * @slot  - The default content slot for scrollable content
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ScrollComponent {
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ScrollElement['themeName'] | undefined>;
  /**
   * Signal input for the `showScrollButtons` property.
   *
   * @public
   */
  readonly showScrollButtons: InputSignal<ScrollElement['showScrollButtons'] | undefined>;
  /**
   * Signal input for the `showScrollbar` property.
   *
   * @public
   */
  readonly showScrollbar: InputSignal<ScrollElement['showScrollbar'] | undefined>;
  /**
   * Signal input for the `orientation` property.
   *
   * @public
   */
  readonly orientation: InputSignal<ScrollElement['orientation'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ScrollElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ScrollElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ScrollElement, 'connected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ScrollElement, 'changed'>>;
  /**
   * Output signal for the `scroll` event.
   *
   * @public
   */
  readonly scroll: OutputEmitterRef<ElementEventDetail<ScrollElement, 'scroll'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ScrollElement, 'disconnected'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: ScrollElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: ScrollElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Returns the native scrollable viewport.
   *
   * @public
   */
  getScrollableElement(...args: Parameters<ScrollElement['getScrollableElement']>): ReturnType<ScrollElement['getScrollableElement']>;
  /**
   * Scrolls the content in the specified direction by approximately 80% of the visible dimension.
   * The scroll axis depends on the current `orientation`.
   *
   * @public
   * @param args - The arguments of `scrollByDirection`:
   * - `direction` - The scroll direction (`'prev'` or `'next'`).
   */
  scrollByDirection(...args: Parameters<ScrollElement['scrollByDirection']>): ReturnType<ScrollElement['scrollByDirection']>;
  /**
   * Scrolls the content to a specific position in pixels.
   * The scroll axis depends on the current `orientation`.
   *
   * @public
   * @param args - The arguments of `scrollToPosition`:
   * - `position` - The target scroll position in pixels.
   * - `isSmooth` - Whether the scrolling should be animated (smooth) or immediate. Defaults to `true`.
   */
  scrollToPosition(...args: Parameters<ScrollElement['scrollToPosition']>): ReturnType<ScrollElement['scrollToPosition']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<ScrollElement['assignToSlot']>): ReturnType<ScrollElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<ScrollElement['getSlotContent']>): ReturnType<ScrollElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<ScrollElement['hasSlotContent']>): ReturnType<ScrollElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<ScrollElement['hasSlot']>): ReturnType<ScrollElement['hasSlot']>;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<ScrollElement['onSlotChanges']>): ReturnType<ScrollElement['onSlotChanges']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `getScrollableElement()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends ScrollMethodNames>(method: TMethod, ...args: Parameters<ScrollComponentMethods[TMethod]>): ReturnType<ScrollComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ScrollElement>(property: TProperty, value: ScrollElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ScrollElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ScrollComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ScrollComponent, "mosaik-scroll", never, {
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "showScrollButtons": {
      "alias": "showScrollButtons";
      "required": false;
      "isSignal": true;
    };
    "showScrollbar": {
      "alias": "showScrollbar";
      "required": false;
      "isSignal": true;
    };
    "orientation": {
      "alias": "orientation";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "changed": "changed";
    "scroll": "scroll";
    "disconnected": "disconnected";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on ScrollComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ScrollMethodNames = 'getScrollableElement' | 'scrollByDirection' | 'scrollToPosition' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges';
/**
 * Declares the methods interface for ScrollComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ScrollComponentMethods = MethodMap<ScrollMethodNames>;
/**
 * @public
 */
export declare function provideScrollComponent(config?: Partial<ScrollElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-scroll.d.ts.map