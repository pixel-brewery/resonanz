import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef, Type } from "@angular/core";
import { ControlValueAccessor } from "@angular/forms";
import { DataTableElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/data-table/DataTableElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import * as i1 from "@pixel-brewery/mosaik-elements-angular/runtime";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the DataTableComponent.
 * Use this token to provide default properties for the DataTableComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const DATA_TABLE_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/selectors/data-table/IDataTableElementProps").IDataTableElementProps>>;
/**
 * @public
 *
 * Injection token for the intl configuration of the DataTableComponent.
 * Provide a partial intl object or an injectable class that resolves translations.
 * This allows third-party applications to override the default intl labels
 * globally, per route, or per component via Angular's dependency injection.
 *
 * Merge order: Foundation defaults → DI intl → [intl] input binding.
 */
export declare const DATA_TABLE_INTL: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").DataTableElementIntl>>;
/**
 * @public
 *
 * @slot caption - The caption slot.
 * @slot summary - The summary slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class DataTableComponent implements ControlValueAccessor {
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<Partial<DataTableElement['intl']> | undefined>;
  /**
   * Signal input for the `alternating` property.
   *
   * @public
   */
  readonly alternating: InputSignal<DataTableElement['alternating'] | undefined>;
  /**
   * Signal input for the `autoGenerateColumns` property.
   *
   * @public
   */
  readonly autoGenerateColumns: InputSignal<DataTableElement['autoGenerateColumns'] | undefined>;
  /**
   * Signal input for the `columnDefinitions` property.
   *
   * @public
   */
  readonly columnDefinitions: InputSignal<DataTableElement['columnDefinitions'] | undefined>;
  /**
   * Signal input for the `caption` property.
   *
   * @public
   */
  readonly caption: InputSignal<DataTableElement['caption'] | undefined>;
  /**
   * Signal input for the `selectionType` property.
   *
   * @public
   */
  readonly selectionType: InputSignal<DataTableElement['selectionType'] | undefined>;
  /**
   * Signal input for the `selectionMode` property.
   *
   * @public
   */
  readonly selectionMode: InputSignal<DataTableElement['selectionMode'] | undefined>;
  /**
   * Signal input for the `resizable` property.
   *
   * @public
   */
  readonly resizable: InputSignal<DataTableElement['resizable'] | undefined>;
  /**
   * Signal input for the `selectionColumn` property.
   *
   * @public
   */
  readonly selectionColumn: InputSignal<DataTableElement['selectionColumn'] | undefined>;
  /**
   * Signal input for the `rowClickSelects` property.
   *
   * @public
   */
  readonly rowClickSelects: InputSignal<DataTableElement['rowClickSelects'] | undefined>;
  /**
   * Signal input for the `sortable` property.
   *
   * @public
   */
  readonly sortable: InputSignal<DataTableElement['sortable'] | undefined>;
  /**
   * Signal input for the `pinable` property.
   *
   * @public
   */
  readonly pinable: InputSignal<DataTableElement['pinable'] | undefined>;
  /**
   * Signal input for the `hideable` property.
   *
   * @public
   */
  readonly hideable: InputSignal<DataTableElement['hideable'] | undefined>;
  /**
   * Signal input for the `autoSizeable` property.
   *
   * @public
   */
  readonly autoSizeable: InputSignal<DataTableElement['autoSizeable'] | undefined>;
  /**
   * Signal input for the `columnChoosable` property.
   *
   * @public
   */
  readonly columnChoosable: InputSignal<DataTableElement['columnChoosable'] | undefined>;
  /**
   * Signal input for the `reorderable` property.
   *
   * @public
   */
  readonly reorderable: InputSignal<DataTableElement['reorderable'] | undefined>;
  /**
   * Signal input for the `sortMode` property.
   *
   * @public
   */
  readonly sortMode: InputSignal<DataTableElement['sortMode'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<DataTableElement['themeName'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<DataTableElement['appearance'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<DataTableElement['disabled'] | undefined>;
  /**
   * Signal input for the `source` property.
   *
   * @public
   */
  readonly source: InputSignal<DataTableElement['source'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<DataTableElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<DataTableElement['lang'] | undefined>;
  /**
   * Output signal for the `tableSelectionChanged` event.
   *
   * @public
   */
  readonly tableSelectionChanged: OutputEmitterRef<ElementEventDetail<DataTableElement, 'tableSelectionChanged'>>;
  /**
   * Output signal for the `dataTableEditorOpened` event.
   *
   * @public
   */
  readonly dataTableEditorOpened: OutputEmitterRef<ElementEventDetail<DataTableElement, 'dataTableEditorOpened'>>;
  /**
   * Output signal for the `dataTableEditorClosed` event.
   *
   * @public
   */
  readonly dataTableEditorClosed: OutputEmitterRef<ElementEventDetail<DataTableElement, 'dataTableEditorClosed'>>;
  /**
   * Output signal for the `dataTableSortChanged` event.
   *
   * @public
   */
  readonly dataTableSortChanged: OutputEmitterRef<ElementEventDetail<DataTableElement, 'dataTableSortChanged'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<DataTableElement, 'changed'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<DataTableElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<DataTableElement, 'disconnected'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  private readonly _accessor;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Applies a value supplied by Angular forms to the native control.
   *
   * @public
   */
  writeValue(obj: unknown): void;
  /**
   * Registers the callback notified when the native control value changes.
   *
   * @public
   */
  registerOnChange(fn: unknown): void;
  /**
   * Registers the callback notified when the native control is touched.
   *
   * @public
   */
  registerOnTouched(fn: unknown): void;
  /**
   * Applies the disabled state supplied by Angular forms.
   *
   * @public
   */
  setDisabledState?(isDisabled: boolean): void;
  /**
   * Selects every selectable row. Only effective while `selectionMode` is `multiple`.
   *
   * @public
   */
  selectAll(...args: Parameters<DataTableElement['selectAll']>): ReturnType<DataTableElement['selectAll']>;
  /**
   * Clears the current selection.
   *
   * @public
   */
  clearSelection(...args: Parameters<DataTableElement['clearSelection']>): ReturnType<DataTableElement['clearSelection']>;
  /**
   * Opens the column editor.
   *
   * @public
   */
  openEditor(...args: Parameters<DataTableElement['openEditor']>): ReturnType<DataTableElement['openEditor']>;
  /**
   * Closes the column editor.
   *
   * @public
   */
  closeEditor(...args: Parameters<DataTableElement['closeEditor']>): ReturnType<DataTableElement['closeEditor']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `selectAll()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends DataTableMethodNames>(method: TMethod, ...args: Parameters<DataTableComponentMethods[TMethod]>): ReturnType<DataTableComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof DataTableElement>(property: TProperty, value: DataTableElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<DataTableElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<DataTableComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<DataTableComponent, "mosaik-data-table", never, {
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "alternating": {
      "alias": "alternating";
      "required": false;
      "isSignal": true;
    };
    "autoGenerateColumns": {
      "alias": "autoGenerateColumns";
      "required": false;
      "isSignal": true;
    };
    "columnDefinitions": {
      "alias": "columnDefinitions";
      "required": false;
      "isSignal": true;
    };
    "caption": {
      "alias": "caption";
      "required": false;
      "isSignal": true;
    };
    "selectionType": {
      "alias": "selectionType";
      "required": false;
      "isSignal": true;
    };
    "selectionMode": {
      "alias": "selectionMode";
      "required": false;
      "isSignal": true;
    };
    "resizable": {
      "alias": "resizable";
      "required": false;
      "isSignal": true;
    };
    "selectionColumn": {
      "alias": "selectionColumn";
      "required": false;
      "isSignal": true;
    };
    "rowClickSelects": {
      "alias": "rowClickSelects";
      "required": false;
      "isSignal": true;
    };
    "sortable": {
      "alias": "sortable";
      "required": false;
      "isSignal": true;
    };
    "pinable": {
      "alias": "pinable";
      "required": false;
      "isSignal": true;
    };
    "hideable": {
      "alias": "hideable";
      "required": false;
      "isSignal": true;
    };
    "autoSizeable": {
      "alias": "autoSizeable";
      "required": false;
      "isSignal": true;
    };
    "columnChoosable": {
      "alias": "columnChoosable";
      "required": false;
      "isSignal": true;
    };
    "reorderable": {
      "alias": "reorderable";
      "required": false;
      "isSignal": true;
    };
    "sortMode": {
      "alias": "sortMode";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "source": {
      "alias": "source";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "tableSelectionChanged": "tableSelectionChanged";
    "dataTableEditorOpened": "dataTableEditorOpened";
    "dataTableEditorClosed": "dataTableEditorClosed";
    "dataTableSortChanged": "dataTableSortChanged";
    "changed": "changed";
    "connected": "connected";
    "disconnected": "disconnected";
  }, never, ["*"], true, [{
    directive: typeof i1.FormStatusHostDirective;
    inputs: {};
    outputs: {};
  }, {
    directive: typeof i1.FormFieldStatusHostDirective;
    inputs: {};
    outputs: {};
  }]>;
}
/**
 * Declares the methods available on DataTableComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type DataTableMethodNames = 'selectAll' | 'clearSelection' | 'openEditor' | 'closeEditor';
/**
 * Declares the methods interface for DataTableComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type DataTableComponentMethods = MethodMap<DataTableMethodNames>;
/**
 * @public
 */
export declare function provideDataTableComponent(config?: Partial<DataTableElement.Props>, intl?: Partial<DataTableElement['intl']> | Type<Partial<DataTableElement['intl']>>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-data-table.d.ts.map