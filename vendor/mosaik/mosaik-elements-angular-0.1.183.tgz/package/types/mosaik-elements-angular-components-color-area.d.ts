import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { ColorAreaElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/color-area/ColorAreaElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the ColorAreaComponent.
 * Use this token to provide default properties for the ColorAreaComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const COLOR_AREA_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/media/color-area/IColorAreaElementProps").IColorAreaElementProps>>;
/**
 * @public
 *
 * @slot gradient - Additional content layered over the gradient field.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ColorAreaComponent {
  /**
   * Signal input for the `x` property.
   *
   * @public
   */
  readonly x: InputSignal<ColorAreaElement['x'] | undefined>;
  /**
   * Signal input for the `y` property.
   *
   * @public
   */
  readonly y: InputSignal<ColorAreaElement['y'] | undefined>;
  /**
   * Signal input for the `hue` property.
   *
   * @public
   */
  readonly hue: InputSignal<ColorAreaElement['hue'] | undefined>;
  /**
   * Signal input for the `step` property.
   *
   * @public
   */
  readonly step: InputSignal<ColorAreaElement['step'] | undefined>;
  /**
   * Signal input for the `color` property.
   *
   * @public
   */
  readonly color: InputSignal<ColorAreaElement['color'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ColorAreaElement['themeName'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<ColorAreaElement['disabled'] | undefined>;
  /**
   * Signal input for the `isFocused` property.
   *
   * @public
   */
  readonly isFocused: InputSignal<ColorAreaElement['isFocused'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ColorAreaElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ColorAreaElement['lang'] | undefined>;
  /**
   * Output signal for the `input` event.
   *
   * @public
   */
  readonly input: OutputEmitterRef<ElementEventDetail<ColorAreaElement, 'input'>>;
  /**
   * Output signal for the `change` event.
   *
   * @public
   */
  readonly change: OutputEmitterRef<ElementEventDetail<ColorAreaElement, 'change'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ColorAreaElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ColorAreaElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ColorAreaElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ColorAreaElement>(property: TProperty, value: ColorAreaElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ColorAreaElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ColorAreaComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ColorAreaComponent, "mosaik-color-area", never, {
    "x": {
      "alias": "x";
      "required": false;
      "isSignal": true;
    };
    "y": {
      "alias": "y";
      "required": false;
      "isSignal": true;
    };
    "hue": {
      "alias": "hue";
      "required": false;
      "isSignal": true;
    };
    "step": {
      "alias": "step";
      "required": false;
      "isSignal": true;
    };
    "color": {
      "alias": "color";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "isFocused": {
      "alias": "isFocused";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "input": "input";
    "change": "change";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on ColorAreaComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ColorAreaMethodNames = never;
/**
 * Declares the methods interface for ColorAreaComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ColorAreaComponentMethods = MethodMap<ColorAreaMethodNames>;
/**
 * @public
 */
export declare function provideColorAreaComponent(config?: Partial<ColorAreaElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-color-area.d.ts.map