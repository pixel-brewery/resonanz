import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { HelmetElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/helmet/HelmetElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the HelmetComponent.
 * Use this token to provide default properties for the HelmetComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const HELMET_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/primitives/helmet/IHelmetElementProps").IHelmetElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class HelmetComponent {
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<HelmetElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<HelmetElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<HelmetElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<HelmetElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<HelmetElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof HelmetElement>(property: TProperty, value: HelmetElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<HelmetElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<HelmetComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<HelmetComponent, "mosaik-helmet", never, {
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on HelmetComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type HelmetMethodNames = never;
/**
 * Declares the methods interface for HelmetComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type HelmetComponentMethods = MethodMap<HelmetMethodNames>;
/**
 * @public
 */
export declare function provideHelmetComponent(config?: Partial<HelmetElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-helmet.d.ts.map