import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { VideoElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/video/VideoElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the VideoComponent.
 * Use this token to provide default properties for the VideoComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const VIDEO_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/media/video/IVideoElementProps").IVideoElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot.
 * @slot legend - The legend slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class VideoComponent {
  /**
   * Signal input for the `src` property.
   *
   * @public
   */
  readonly src: InputSignal<VideoElement['src'] | undefined>;
  /**
   * Signal input for the `autoPlay` property.
   *
   * @public
   */
  readonly autoPlay: InputSignal<VideoElement['autoPlay'] | undefined>;
  /**
   * Signal input for the `poster` property.
   *
   * @public
   */
  readonly poster: InputSignal<VideoElement['poster'] | undefined>;
  /**
   * Signal input for the `autoFullScreen` property.
   *
   * @public
   */
  readonly autoFullScreen: InputSignal<VideoElement['autoFullScreen'] | undefined>;
  /**
   * Signal input for the `showControls` property.
   *
   * @public
   */
  readonly showControls: InputSignal<VideoElement['showControls'] | undefined>;
  /**
   * Signal input for the `showPictureInPicture` property.
   *
   * @public
   */
  readonly showPictureInPicture: InputSignal<VideoElement['showPictureInPicture'] | undefined>;
  /**
   * Signal input for the `showDownload` property.
   *
   * @public
   */
  readonly showDownload: InputSignal<VideoElement['showDownload'] | undefined>;
  /**
   * Signal input for the `fit` property.
   *
   * @public
   */
  readonly fit: InputSignal<VideoElement['fit'] | undefined>;
  /**
   * Signal input for the `legend` property.
   *
   * @public
   */
  readonly legend: InputSignal<VideoElement['legend'] | undefined>;
  /**
   * Signal input for the `legendPosition` property.
   *
   * @public
   */
  readonly legendPosition: InputSignal<VideoElement['legendPosition'] | undefined>;
  /**
   * Signal input for the `ratio` property.
   *
   * @public
   */
  readonly ratio: InputSignal<VideoElement['ratio'] | undefined>;
  /**
   * Signal input for the `muted` property.
   *
   * @public
   */
  readonly muted: InputSignal<VideoElement['muted'] | undefined>;
  /**
   * Signal input for the `loop` property.
   *
   * @public
   */
  readonly loop: InputSignal<VideoElement['loop'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<VideoElement['themeName'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<VideoElement['disabled'] | undefined>;
  /**
   * Signal input for the `width` property.
   *
   * @public
   */
  readonly width: InputSignal<VideoElement['width'] | undefined>;
  /**
   * Signal input for the `height` property.
   *
   * @public
   */
  readonly height: InputSignal<VideoElement['height'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<VideoElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<VideoElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<VideoElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<VideoElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<VideoElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Calls `play` on the `mosaik-video` element.
   *
   * @public
   */
  play(...args: Parameters<VideoElement['play']>): ReturnType<VideoElement['play']>;
  /**
   * Calls `pause` on the `mosaik-video` element.
   *
   * @public
   */
  pause(...args: Parameters<VideoElement['pause']>): ReturnType<VideoElement['pause']>;
  /**
   * Calls `toggle` on the `mosaik-video` element.
   *
   * @public
   */
  toggle(...args: Parameters<VideoElement['toggle']>): ReturnType<VideoElement['toggle']>;
  /**
   * Calls `load` on the `mosaik-video` element.
   *
   * @public
   */
  load(...args: Parameters<VideoElement['load']>): ReturnType<VideoElement['load']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `play()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends VideoMethodNames>(method: TMethod, ...args: Parameters<VideoComponentMethods[TMethod]>): ReturnType<VideoComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof VideoElement>(property: TProperty, value: VideoElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<VideoElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<VideoComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<VideoComponent, "mosaik-video", never, {
    "src": {
      "alias": "src";
      "required": false;
      "isSignal": true;
    };
    "autoPlay": {
      "alias": "autoPlay";
      "required": false;
      "isSignal": true;
    };
    "poster": {
      "alias": "poster";
      "required": false;
      "isSignal": true;
    };
    "autoFullScreen": {
      "alias": "autoFullScreen";
      "required": false;
      "isSignal": true;
    };
    "showControls": {
      "alias": "showControls";
      "required": false;
      "isSignal": true;
    };
    "showPictureInPicture": {
      "alias": "showPictureInPicture";
      "required": false;
      "isSignal": true;
    };
    "showDownload": {
      "alias": "showDownload";
      "required": false;
      "isSignal": true;
    };
    "fit": {
      "alias": "fit";
      "required": false;
      "isSignal": true;
    };
    "legend": {
      "alias": "legend";
      "required": false;
      "isSignal": true;
    };
    "legendPosition": {
      "alias": "legendPosition";
      "required": false;
      "isSignal": true;
    };
    "ratio": {
      "alias": "ratio";
      "required": false;
      "isSignal": true;
    };
    "muted": {
      "alias": "muted";
      "required": false;
      "isSignal": true;
    };
    "loop": {
      "alias": "loop";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "width": {
      "alias": "width";
      "required": false;
      "isSignal": true;
    };
    "height": {
      "alias": "height";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on VideoComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type VideoMethodNames = 'play' | 'pause' | 'toggle' | 'load';
/**
 * Declares the methods interface for VideoComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type VideoComponentMethods = MethodMap<VideoMethodNames>;
/**
 * @public
 */
export declare function provideVideoComponent(config?: Partial<VideoElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-video.d.ts.map