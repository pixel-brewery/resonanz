import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef, Type } from "@angular/core";
import { ControlValueAccessor } from "@angular/forms";
import { ColorEditorAlphaSliderElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/color-editor/ColorEditorAlphaSliderElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import * as i1 from "@pixel-brewery/mosaik-elements-angular/runtime";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { ColorEditorAreaElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/color-editor/ColorEditorAreaElement";
import { ColorEditorHueSliderElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/color-editor/ColorEditorHueSliderElement";
import { ColorEditorInputsElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/color-editor/ColorEditorInputsElement";
import { ColorEditorPaletteElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/color-editor/ColorEditorPaletteElement";
import { ColorEditorShadeSliderElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/color-editor/ColorEditorShadeSliderElement";
import { ColorEditorSwatchElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/color-editor/ColorEditorSwatchElement";
import { ColorEditorElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/color-editor/ColorEditorElement";
/**
 * @public
 *
 * Injection token for the default properties of the ColorEditorAlphaSliderComponent.
 * Use this token to provide default properties for the ColorEditorAlphaSliderComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const COLOR_EDITOR_ALPHA_SLIDER_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/media/color-editor/IColorEditorAlphaSliderElementProps").IColorEditorAlphaSliderElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ColorEditorAlphaSliderComponent implements ControlValueAccessor {
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<ColorEditorAlphaSliderElement['intl'] | undefined>;
  /**
   * Signal input for the `alpha` property.
   *
   * @public
   */
  readonly alpha: InputSignal<ColorEditorAlphaSliderElement['alpha'] | undefined>;
  /**
   * Signal input for the `color` property.
   *
   * @public
   */
  readonly color: InputSignal<ColorEditorAlphaSliderElement['color'] | undefined>;
  /**
   * Signal input for the `step` property.
   *
   * @public
   */
  readonly step: InputSignal<ColorEditorAlphaSliderElement['step'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ColorEditorAlphaSliderElement['themeName'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<ColorEditorAlphaSliderElement['disabled'] | undefined>;
  /**
   * Signal input for the `isFocused` property.
   *
   * @public
   */
  readonly isFocused: InputSignal<ColorEditorAlphaSliderElement['isFocused'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ColorEditorAlphaSliderElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ColorEditorAlphaSliderElement['lang'] | undefined>;
  /**
   * Output signal for the `alphaChanged` event.
   *
   * @public
   */
  readonly alphaChanged: OutputEmitterRef<ElementEventDetail<ColorEditorAlphaSliderElement, 'alphaChanged'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ColorEditorAlphaSliderElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ColorEditorAlphaSliderElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ColorEditorAlphaSliderElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  private readonly _accessor;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Applies a value supplied by Angular forms to the native control.
   *
   * @public
   */
  writeValue(obj: unknown): void;
  /**
   * Registers the callback notified when the native control value changes.
   *
   * @public
   */
  registerOnChange(fn: unknown): void;
  /**
   * Registers the callback notified when the native control is touched.
   *
   * @public
   */
  registerOnTouched(fn: unknown): void;
  /**
   * Applies the disabled state supplied by Angular forms.
   *
   * @public
   */
  setDisabledState?(isDisabled: boolean): void;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ColorEditorAlphaSliderElement>(property: TProperty, value: ColorEditorAlphaSliderElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ColorEditorAlphaSliderElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ColorEditorAlphaSliderComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ColorEditorAlphaSliderComponent, "mosaik-color-editor-alpha-slider", never, {
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "alpha": {
      "alias": "alpha";
      "required": false;
      "isSignal": true;
    };
    "color": {
      "alias": "color";
      "required": false;
      "isSignal": true;
    };
    "step": {
      "alias": "step";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "isFocused": {
      "alias": "isFocused";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "alphaChanged": "alphaChanged";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, [{
    directive: typeof i1.FormStatusHostDirective;
    inputs: {};
    outputs: {};
  }, {
    directive: typeof i1.FormFieldStatusHostDirective;
    inputs: {};
    outputs: {};
  }]>;
}
/**
 * Declares the methods available on ColorEditorAlphaSliderComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ColorEditorAlphaSliderMethodNames = never;
/**
 * Declares the methods interface for ColorEditorAlphaSliderComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ColorEditorAlphaSliderComponentMethods = MethodMap<ColorEditorAlphaSliderMethodNames>;
/**
 * @public
 */
export declare function provideColorEditorAlphaSliderComponent(config?: Partial<ColorEditorAlphaSliderElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the ColorEditorAreaComponent.
 * Use this token to provide default properties for the ColorEditorAreaComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const COLOR_EDITOR_AREA_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/media/color-editor/IColorEditorAreaElementProps").IColorEditorAreaElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ColorEditorAreaComponent implements ControlValueAccessor {
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<ColorEditorAreaElement['intl'] | undefined>;
  /**
   * Signal input for the `hue` property.
   *
   * @public
   */
  readonly hue: InputSignal<ColorEditorAreaElement['hue'] | undefined>;
  /**
   * Signal input for the `saturation` property.
   *
   * @public
   */
  readonly saturation: InputSignal<ColorEditorAreaElement['saturation'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<ColorEditorAreaElement['value'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ColorEditorAreaElement['themeName'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<ColorEditorAreaElement['disabled'] | undefined>;
  /**
   * Signal input for the `isFocused` property.
   *
   * @public
   */
  readonly isFocused: InputSignal<ColorEditorAreaElement['isFocused'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ColorEditorAreaElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ColorEditorAreaElement['lang'] | undefined>;
  /**
   * Output signal for the `colorAreaChanged` event.
   *
   * @public
   */
  readonly colorAreaChanged: OutputEmitterRef<ElementEventDetail<ColorEditorAreaElement, 'colorAreaChanged'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ColorEditorAreaElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ColorEditorAreaElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ColorEditorAreaElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  private readonly _accessor;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Applies a value supplied by Angular forms to the native control.
   *
   * @public
   */
  writeValue(obj: unknown): void;
  /**
   * Registers the callback notified when the native control value changes.
   *
   * @public
   */
  registerOnChange(fn: unknown): void;
  /**
   * Registers the callback notified when the native control is touched.
   *
   * @public
   */
  registerOnTouched(fn: unknown): void;
  /**
   * Applies the disabled state supplied by Angular forms.
   *
   * @public
   */
  setDisabledState?(isDisabled: boolean): void;
  /**
   * Updates the color from external HSV values.
   *
   * @public
   * @param args - The arguments of `setColor`:
   * - `hue` - The hue value (0-360)
   * - `saturation` - The saturation value (0-1)
   * - `value` - The value/brightness (0-1)
   */
  setColor(...args: Parameters<ColorEditorAreaElement['setColor']>): ReturnType<ColorEditorAreaElement['setColor']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `setColor()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends ColorEditorAreaMethodNames>(method: TMethod, ...args: Parameters<ColorEditorAreaComponentMethods[TMethod]>): ReturnType<ColorEditorAreaComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ColorEditorAreaElement>(property: TProperty, value: ColorEditorAreaElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ColorEditorAreaElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ColorEditorAreaComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ColorEditorAreaComponent, "mosaik-color-editor-area", never, {
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "hue": {
      "alias": "hue";
      "required": false;
      "isSignal": true;
    };
    "saturation": {
      "alias": "saturation";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "isFocused": {
      "alias": "isFocused";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "colorAreaChanged": "colorAreaChanged";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, [{
    directive: typeof i1.FormStatusHostDirective;
    inputs: {};
    outputs: {};
  }, {
    directive: typeof i1.FormFieldStatusHostDirective;
    inputs: {};
    outputs: {};
  }]>;
}
/**
 * Declares the methods available on ColorEditorAreaComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ColorEditorAreaMethodNames = 'setColor';
/**
 * Declares the methods interface for ColorEditorAreaComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ColorEditorAreaComponentMethods = MethodMap<ColorEditorAreaMethodNames>;
/**
 * @public
 */
export declare function provideColorEditorAreaComponent(config?: Partial<ColorEditorAreaElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the ColorEditorHueSliderComponent.
 * Use this token to provide default properties for the ColorEditorHueSliderComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const COLOR_EDITOR_HUE_SLIDER_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/media/color-editor/IColorEditorHueSliderElementProps").IColorEditorHueSliderElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ColorEditorHueSliderComponent implements ControlValueAccessor {
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<ColorEditorHueSliderElement['intl'] | undefined>;
  /**
   * Signal input for the `hue` property.
   *
   * @public
   */
  readonly hue: InputSignal<ColorEditorHueSliderElement['hue'] | undefined>;
  /**
   * Signal input for the `step` property.
   *
   * @public
   */
  readonly step: InputSignal<ColorEditorHueSliderElement['step'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ColorEditorHueSliderElement['themeName'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<ColorEditorHueSliderElement['disabled'] | undefined>;
  /**
   * Signal input for the `isFocused` property.
   *
   * @public
   */
  readonly isFocused: InputSignal<ColorEditorHueSliderElement['isFocused'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ColorEditorHueSliderElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ColorEditorHueSliderElement['lang'] | undefined>;
  /**
   * Output signal for the `hueChanged` event.
   *
   * @public
   */
  readonly hueChanged: OutputEmitterRef<ElementEventDetail<ColorEditorHueSliderElement, 'hueChanged'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ColorEditorHueSliderElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ColorEditorHueSliderElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ColorEditorHueSliderElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  private readonly _accessor;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Applies a value supplied by Angular forms to the native control.
   *
   * @public
   */
  writeValue(obj: unknown): void;
  /**
   * Registers the callback notified when the native control value changes.
   *
   * @public
   */
  registerOnChange(fn: unknown): void;
  /**
   * Registers the callback notified when the native control is touched.
   *
   * @public
   */
  registerOnTouched(fn: unknown): void;
  /**
   * Applies the disabled state supplied by Angular forms.
   *
   * @public
   */
  setDisabledState?(isDisabled: boolean): void;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ColorEditorHueSliderElement>(property: TProperty, value: ColorEditorHueSliderElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ColorEditorHueSliderElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ColorEditorHueSliderComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ColorEditorHueSliderComponent, "mosaik-color-editor-hue-slider", never, {
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "hue": {
      "alias": "hue";
      "required": false;
      "isSignal": true;
    };
    "step": {
      "alias": "step";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "isFocused": {
      "alias": "isFocused";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "hueChanged": "hueChanged";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, [{
    directive: typeof i1.FormStatusHostDirective;
    inputs: {};
    outputs: {};
  }, {
    directive: typeof i1.FormFieldStatusHostDirective;
    inputs: {};
    outputs: {};
  }]>;
}
/**
 * Declares the methods available on ColorEditorHueSliderComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ColorEditorHueSliderMethodNames = never;
/**
 * Declares the methods interface for ColorEditorHueSliderComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ColorEditorHueSliderComponentMethods = MethodMap<ColorEditorHueSliderMethodNames>;
/**
 * @public
 */
export declare function provideColorEditorHueSliderComponent(config?: Partial<ColorEditorHueSliderElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the ColorEditorInputsComponent.
 * Use this token to provide default properties for the ColorEditorInputsComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const COLOR_EDITOR_INPUTS_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/media/color-editor/IColorEditorInputsElementProps").IColorEditorInputsElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ColorEditorInputsComponent implements ControlValueAccessor {
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<ColorEditorInputsElement['intl'] | undefined>;
  /**
   * Signal input for the `color` property.
   *
   * @public
   */
  readonly color: InputSignal<ColorEditorInputsElement['color'] | undefined>;
  /**
   * Signal input for the `format` property.
   *
   * @public
   */
  readonly format: InputSignal<ColorEditorInputsElement['format'] | undefined>;
  /**
   * Signal input for the `showAlpha` property.
   *
   * @public
   */
  readonly showAlpha: InputSignal<ColorEditorInputsElement['showAlpha'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ColorEditorInputsElement['themeName'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<ColorEditorInputsElement['disabled'] | undefined>;
  /**
   * Signal input for the `isFocused` property.
   *
   * @public
   */
  readonly isFocused: InputSignal<ColorEditorInputsElement['isFocused'] | undefined>;
  /**
   * Signal input for the `size` property.
   *
   * @public
   */
  readonly size: InputSignal<ColorEditorInputsElement['size'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ColorEditorInputsElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ColorEditorInputsElement['lang'] | undefined>;
  /**
   * Output signal for the `colorChanged` event.
   *
   * @public
   */
  readonly colorChanged: OutputEmitterRef<ElementEventDetail<ColorEditorInputsElement, 'colorChanged'>>;
  /**
   * Output signal for the `colorFormatChanged` event.
   *
   * @public
   */
  readonly colorFormatChanged: OutputEmitterRef<ElementEventDetail<ColorEditorInputsElement, 'colorFormatChanged'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ColorEditorInputsElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ColorEditorInputsElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ColorEditorInputsElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  private readonly _accessor;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Applies a value supplied by Angular forms to the native control.
   *
   * @public
   */
  writeValue(obj: unknown): void;
  /**
   * Registers the callback notified when the native control value changes.
   *
   * @public
   */
  registerOnChange(fn: unknown): void;
  /**
   * Registers the callback notified when the native control is touched.
   *
   * @public
   */
  registerOnTouched(fn: unknown): void;
  /**
   * Applies the disabled state supplied by Angular forms.
   *
   * @public
   */
  setDisabledState?(isDisabled: boolean): void;
  /**
   * Navigates to the previous color format in the cycle.
   *
   * @public
   */
  previousFormat(...args: Parameters<ColorEditorInputsElement['previousFormat']>): ReturnType<ColorEditorInputsElement['previousFormat']>;
  /**
   * Navigates to the next color format in the cycle.
   *
   * @public
   */
  nextFormat(...args: Parameters<ColorEditorInputsElement['nextFormat']>): ReturnType<ColorEditorInputsElement['nextFormat']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `previousFormat()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends ColorEditorInputsMethodNames>(method: TMethod, ...args: Parameters<ColorEditorInputsComponentMethods[TMethod]>): ReturnType<ColorEditorInputsComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ColorEditorInputsElement>(property: TProperty, value: ColorEditorInputsElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ColorEditorInputsElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ColorEditorInputsComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ColorEditorInputsComponent, "mosaik-color-editor-inputs", never, {
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "color": {
      "alias": "color";
      "required": false;
      "isSignal": true;
    };
    "format": {
      "alias": "format";
      "required": false;
      "isSignal": true;
    };
    "showAlpha": {
      "alias": "showAlpha";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "isFocused": {
      "alias": "isFocused";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "colorChanged": "colorChanged";
    "colorFormatChanged": "colorFormatChanged";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, [{
    directive: typeof i1.FormStatusHostDirective;
    inputs: {};
    outputs: {};
  }, {
    directive: typeof i1.FormFieldStatusHostDirective;
    inputs: {};
    outputs: {};
  }]>;
}
/**
 * Declares the methods available on ColorEditorInputsComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ColorEditorInputsMethodNames = 'previousFormat' | 'nextFormat';
/**
 * Declares the methods interface for ColorEditorInputsComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ColorEditorInputsComponentMethods = MethodMap<ColorEditorInputsMethodNames>;
/**
 * @public
 */
export declare function provideColorEditorInputsComponent(config?: Partial<ColorEditorInputsElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the ColorEditorPaletteComponent.
 * Use this token to provide default properties for the ColorEditorPaletteComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const COLOR_EDITOR_PALETTE_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/media/color-editor/IColorEditorPaletteElementProps").IColorEditorPaletteElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ColorEditorPaletteComponent implements ControlValueAccessor {
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<ColorEditorPaletteElement['intl'] | undefined>;
  /**
   * Signal input for the `palettes` property.
   *
   * @public
   */
  readonly palettes: InputSignal<ColorEditorPaletteElement['palettes'] | undefined>;
  /**
   * Signal input for the `selectedPalette` property.
   *
   * @public
   */
  readonly selectedPalette: InputSignal<ColorEditorPaletteElement['selectedPalette'] | undefined>;
  /**
   * Signal input for the `allowAdd` property.
   *
   * @public
   */
  readonly allowAdd: InputSignal<ColorEditorPaletteElement['allowAdd'] | undefined>;
  /**
   * Signal input for the `currentColor` property.
   *
   * @public
   */
  readonly currentColor: InputSignal<ColorEditorPaletteElement['currentColor'] | undefined>;
  /**
   * Signal input for the `panelAnchor` property.
   *
   * @public
   */
  readonly panelAnchor: InputSignal<ColorEditorPaletteElement['panelAnchor'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ColorEditorPaletteElement['themeName'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<ColorEditorPaletteElement['disabled'] | undefined>;
  /**
   * Signal input for the `isFocused` property.
   *
   * @public
   */
  readonly isFocused: InputSignal<ColorEditorPaletteElement['isFocused'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ColorEditorPaletteElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ColorEditorPaletteElement['lang'] | undefined>;
  /**
   * Output signal for the `paletteSelect` event.
   *
   * @public
   */
  readonly paletteSelect: OutputEmitterRef<ElementEventDetail<ColorEditorPaletteElement, 'paletteSelect'>>;
  /**
   * Output signal for the `paletteAdd` event.
   *
   * @public
   */
  readonly paletteAdd: OutputEmitterRef<ElementEventDetail<ColorEditorPaletteElement, 'paletteAdd'>>;
  /**
   * Output signal for the `paletteChanged` event.
   *
   * @public
   */
  readonly paletteChanged: OutputEmitterRef<ElementEventDetail<ColorEditorPaletteElement, 'paletteChanged'>>;
  /**
   * Output signal for the `paletteCustomChanged` event.
   *
   * @public
   */
  readonly paletteCustomChanged: OutputEmitterRef<ElementEventDetail<ColorEditorPaletteElement, 'paletteCustomChanged'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ColorEditorPaletteElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ColorEditorPaletteElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ColorEditorPaletteElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  private readonly _accessor;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Applies a value supplied by Angular forms to the native control.
   *
   * @public
   */
  writeValue(obj: unknown): void;
  /**
   * Registers the callback notified when the native control value changes.
   *
   * @public
   */
  registerOnChange(fn: unknown): void;
  /**
   * Registers the callback notified when the native control is touched.
   *
   * @public
   */
  registerOnTouched(fn: unknown): void;
  /**
   * Applies the disabled state supplied by Angular forms.
   *
   * @public
   */
  setDisabledState?(isDisabled: boolean): void;
  /**
   * Adds a color to the custom palette.
   *
   * @public
   * @param args - The arguments of `addColorToCustomPalette`:
   * - `color` - The color to add
   */
  addColorToCustomPalette(...args: Parameters<ColorEditorPaletteElement['addColorToCustomPalette']>): ReturnType<ColorEditorPaletteElement['addColorToCustomPalette']>;
  /**
   * Removes a color from the custom palette.
   *
   * @public
   * @param args - The arguments of `removeColorFromCustomPalette`:
   * - `color` - The color to remove
   */
  removeColorFromCustomPalette(...args: Parameters<ColorEditorPaletteElement['removeColorFromCustomPalette']>): ReturnType<ColorEditorPaletteElement['removeColorFromCustomPalette']>;
  /**
   * Gets the colors from the custom (mutable) palette.
   *
   * @public
   * @returns The array of colors in the custom palette
   */
  getCustomPaletteColors(...args: Parameters<ColorEditorPaletteElement['getCustomPaletteColors']>): ReturnType<ColorEditorPaletteElement['getCustomPaletteColors']>;
  /**
   * Sets the colors for the custom (mutable) palette.
   * This replaces all existing colors in the custom palette.
   *
   * @public
   * @param args - The arguments of `setCustomPaletteColors`:
   * - `colors` - The array of colors to set
   */
  setCustomPaletteColors(...args: Parameters<ColorEditorPaletteElement['setCustomPaletteColors']>): ReturnType<ColorEditorPaletteElement['setCustomPaletteColors']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `addColorToCustomPalette()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends ColorEditorPaletteMethodNames>(method: TMethod, ...args: Parameters<ColorEditorPaletteComponentMethods[TMethod]>): ReturnType<ColorEditorPaletteComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ColorEditorPaletteElement>(property: TProperty, value: ColorEditorPaletteElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ColorEditorPaletteElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ColorEditorPaletteComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ColorEditorPaletteComponent, "mosaik-color-editor-palette", never, {
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "palettes": {
      "alias": "palettes";
      "required": false;
      "isSignal": true;
    };
    "selectedPalette": {
      "alias": "selectedPalette";
      "required": false;
      "isSignal": true;
    };
    "allowAdd": {
      "alias": "allowAdd";
      "required": false;
      "isSignal": true;
    };
    "currentColor": {
      "alias": "currentColor";
      "required": false;
      "isSignal": true;
    };
    "panelAnchor": {
      "alias": "panelAnchor";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "isFocused": {
      "alias": "isFocused";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "paletteSelect": "paletteSelect";
    "paletteAdd": "paletteAdd";
    "paletteChanged": "paletteChanged";
    "paletteCustomChanged": "paletteCustomChanged";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, [{
    directive: typeof i1.FormStatusHostDirective;
    inputs: {};
    outputs: {};
  }, {
    directive: typeof i1.FormFieldStatusHostDirective;
    inputs: {};
    outputs: {};
  }]>;
}
/**
 * Declares the methods available on ColorEditorPaletteComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ColorEditorPaletteMethodNames = 'addColorToCustomPalette' | 'removeColorFromCustomPalette' | 'getCustomPaletteColors' | 'setCustomPaletteColors';
/**
 * Declares the methods interface for ColorEditorPaletteComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ColorEditorPaletteComponentMethods = MethodMap<ColorEditorPaletteMethodNames>;
/**
 * @public
 */
export declare function provideColorEditorPaletteComponent(config?: Partial<ColorEditorPaletteElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the ColorEditorShadeSliderComponent.
 * Use this token to provide default properties for the ColorEditorShadeSliderComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const COLOR_EDITOR_SHADE_SLIDER_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/media/color-editor/IColorEditorShadeSliderElementProps").IColorEditorShadeSliderElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ColorEditorShadeSliderComponent implements ControlValueAccessor {
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<ColorEditorShadeSliderElement['intl'] | undefined>;
  /**
   * Signal input for the `hue` property.
   *
   * @public
   */
  readonly hue: InputSignal<ColorEditorShadeSliderElement['hue'] | undefined>;
  /**
   * Signal input for the `saturation` property.
   *
   * @public
   */
  readonly saturation: InputSignal<ColorEditorShadeSliderElement['saturation'] | undefined>;
  /**
   * Signal input for the `shade` property.
   *
   * @public
   */
  readonly shade: InputSignal<ColorEditorShadeSliderElement['shade'] | undefined>;
  /**
   * Signal input for the `step` property.
   *
   * @public
   */
  readonly step: InputSignal<ColorEditorShadeSliderElement['step'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ColorEditorShadeSliderElement['themeName'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<ColorEditorShadeSliderElement['disabled'] | undefined>;
  /**
   * Signal input for the `isFocused` property.
   *
   * @public
   */
  readonly isFocused: InputSignal<ColorEditorShadeSliderElement['isFocused'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ColorEditorShadeSliderElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ColorEditorShadeSliderElement['lang'] | undefined>;
  /**
   * Output signal for the `shadeChanged` event.
   *
   * @public
   */
  readonly shadeChanged: OutputEmitterRef<ElementEventDetail<ColorEditorShadeSliderElement, 'shadeChanged'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ColorEditorShadeSliderElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ColorEditorShadeSliderElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ColorEditorShadeSliderElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  private readonly _accessor;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Applies a value supplied by Angular forms to the native control.
   *
   * @public
   */
  writeValue(obj: unknown): void;
  /**
   * Registers the callback notified when the native control value changes.
   *
   * @public
   */
  registerOnChange(fn: unknown): void;
  /**
   * Registers the callback notified when the native control is touched.
   *
   * @public
   */
  registerOnTouched(fn: unknown): void;
  /**
   * Applies the disabled state supplied by Angular forms.
   *
   * @public
   */
  setDisabledState?(isDisabled: boolean): void;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ColorEditorShadeSliderElement>(property: TProperty, value: ColorEditorShadeSliderElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ColorEditorShadeSliderElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ColorEditorShadeSliderComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ColorEditorShadeSliderComponent, "mosaik-color-editor-shade-slider", never, {
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "hue": {
      "alias": "hue";
      "required": false;
      "isSignal": true;
    };
    "saturation": {
      "alias": "saturation";
      "required": false;
      "isSignal": true;
    };
    "shade": {
      "alias": "shade";
      "required": false;
      "isSignal": true;
    };
    "step": {
      "alias": "step";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "isFocused": {
      "alias": "isFocused";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "shadeChanged": "shadeChanged";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, [{
    directive: typeof i1.FormStatusHostDirective;
    inputs: {};
    outputs: {};
  }, {
    directive: typeof i1.FormFieldStatusHostDirective;
    inputs: {};
    outputs: {};
  }]>;
}
/**
 * Declares the methods available on ColorEditorShadeSliderComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ColorEditorShadeSliderMethodNames = never;
/**
 * Declares the methods interface for ColorEditorShadeSliderComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ColorEditorShadeSliderComponentMethods = MethodMap<ColorEditorShadeSliderMethodNames>;
/**
 * @public
 */
export declare function provideColorEditorShadeSliderComponent(config?: Partial<ColorEditorShadeSliderElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the ColorEditorSwatchComponent.
 * Use this token to provide default properties for the ColorEditorSwatchComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const COLOR_EDITOR_SWATCH_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/media/color-editor/IColorEditorSwatchElementProps").IColorEditorSwatchElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ColorEditorSwatchComponent implements ControlValueAccessor {
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<ColorEditorSwatchElement['intl'] | undefined>;
  /**
   * Signal input for the `color` property.
   *
   * @public
   */
  readonly color: InputSignal<ColorEditorSwatchElement['color'] | undefined>;
  /**
   * Signal input for the `copyable` property.
   *
   * @public
   */
  readonly copyable: InputSignal<ColorEditorSwatchElement['copyable'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ColorEditorSwatchElement['themeName'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<ColorEditorSwatchElement['disabled'] | undefined>;
  /**
   * Signal input for the `isFocused` property.
   *
   * @public
   */
  readonly isFocused: InputSignal<ColorEditorSwatchElement['isFocused'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ColorEditorSwatchElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ColorEditorSwatchElement['lang'] | undefined>;
  /**
   * Output signal for the `swatchCopy` event.
   *
   * @public
   */
  readonly swatchCopy: OutputEmitterRef<ElementEventDetail<ColorEditorSwatchElement, 'swatchCopy'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ColorEditorSwatchElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ColorEditorSwatchElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ColorEditorSwatchElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  private readonly _accessor;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Applies a value supplied by Angular forms to the native control.
   *
   * @public
   */
  writeValue(obj: unknown): void;
  /**
   * Registers the callback notified when the native control value changes.
   *
   * @public
   */
  registerOnChange(fn: unknown): void;
  /**
   * Registers the callback notified when the native control is touched.
   *
   * @public
   */
  registerOnTouched(fn: unknown): void;
  /**
   * Applies the disabled state supplied by Angular forms.
   *
   * @public
   */
  setDisabledState?(isDisabled: boolean): void;
  /**
   * Handles click on the copy button.
   *
   * @public
   */
  pick(...args: Parameters<ColorEditorSwatchElement['pick']>): ReturnType<ColorEditorSwatchElement['pick']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `pick()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends ColorEditorSwatchMethodNames>(method: TMethod, ...args: Parameters<ColorEditorSwatchComponentMethods[TMethod]>): ReturnType<ColorEditorSwatchComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ColorEditorSwatchElement>(property: TProperty, value: ColorEditorSwatchElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ColorEditorSwatchElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ColorEditorSwatchComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ColorEditorSwatchComponent, "mosaik-color-editor-swatch", never, {
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "color": {
      "alias": "color";
      "required": false;
      "isSignal": true;
    };
    "copyable": {
      "alias": "copyable";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "isFocused": {
      "alias": "isFocused";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "swatchCopy": "swatchCopy";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, [{
    directive: typeof i1.FormStatusHostDirective;
    inputs: {};
    outputs: {};
  }, {
    directive: typeof i1.FormFieldStatusHostDirective;
    inputs: {};
    outputs: {};
  }]>;
}
/**
 * Declares the methods available on ColorEditorSwatchComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ColorEditorSwatchMethodNames = 'pick';
/**
 * Declares the methods interface for ColorEditorSwatchComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ColorEditorSwatchComponentMethods = MethodMap<ColorEditorSwatchMethodNames>;
/**
 * @public
 */
export declare function provideColorEditorSwatchComponent(config?: Partial<ColorEditorSwatchElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the ColorEditorComponent.
 * Use this token to provide default properties for the ColorEditorComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const COLOR_EDITOR_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/media/color-editor/IColorEditorElementProps").IColorEditorElementProps>>;
/**
 * @public
 *
 * Injection token for the intl configuration of the ColorEditorComponent.
 * Provide a partial intl object or an injectable class that resolves translations.
 * This allows third-party applications to override the default intl labels
 * globally, per route, or per component via Angular's dependency injection.
 *
 * Merge order: Foundation defaults → DI intl → [intl] input binding.
 */
export declare const COLOR_EDITOR_INTL: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").ColorEditorElementIntl>>;
/**
 * @public
 *
 * @slot alpha-slider - Custom alpha slider component
 * @slot area - Custom color area component
 * @slot eye-dropper - The eye-dropper slot.
 * @slot hue-slider - Custom hue slider component
 * @slot inputs - Custom inputs component
 * @slot palette - Custom palette component
 * @slot swatch - Custom color swatch component
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ColorEditorComponent implements ControlValueAccessor {
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<Partial<ColorEditorElement['intl']> | undefined>;
  /**
   * Signal input for the `color` property.
   *
   * @public
   */
  readonly color: InputSignal<ColorEditorElement['color'] | undefined>;
  /**
   * Signal input for the `format` property.
   *
   * @public
   */
  readonly format: InputSignal<ColorEditorElement['format'] | undefined>;
  /**
   * Signal input for the `showAlpha` property.
   *
   * @public
   */
  readonly showAlpha: InputSignal<ColorEditorElement['showAlpha'] | undefined>;
  /**
   * Signal input for the `showInputs` property.
   *
   * @public
   */
  readonly showInputs: InputSignal<ColorEditorElement['showInputs'] | undefined>;
  /**
   * Signal input for the `showPalette` property.
   *
   * @public
   */
  readonly showPalette: InputSignal<ColorEditorElement['showPalette'] | undefined>;
  /**
   * Signal input for the `showEyeDropper` property.
   *
   * @public
   */
  readonly showEyeDropper: InputSignal<ColorEditorElement['showEyeDropper'] | undefined>;
  /**
   * Signal input for the `showSwatch` property.
   *
   * @public
   */
  readonly showSwatch: InputSignal<ColorEditorElement['showSwatch'] | undefined>;
  /**
   * Signal input for the `palettes` property.
   *
   * @public
   */
  readonly palettes: InputSignal<ColorEditorElement['palettes'] | undefined>;
  /**
   * Signal input for the `selectedPalette` property.
   *
   * @public
   */
  readonly selectedPalette: InputSignal<ColorEditorElement['selectedPalette'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ColorEditorElement['themeName'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<ColorEditorElement['disabled'] | undefined>;
  /**
   * Signal input for the `isFocused` property.
   *
   * @public
   */
  readonly isFocused: InputSignal<ColorEditorElement['isFocused'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ColorEditorElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ColorEditorElement['lang'] | undefined>;
  /**
   * Output signal for the `colorChanged` event.
   *
   * @public
   */
  readonly colorChanged: OutputEmitterRef<ElementEventDetail<ColorEditorElement, 'colorChanged'>>;
  /**
   * Output signal for the `colorFormatChanged` event.
   *
   * @public
   */
  readonly colorFormatChanged: OutputEmitterRef<ElementEventDetail<ColorEditorElement, 'colorFormatChanged'>>;
  /**
   * Output signal for the `paletteChanged` event.
   *
   * @public
   */
  readonly paletteChanged: OutputEmitterRef<ElementEventDetail<ColorEditorElement, 'paletteChanged'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ColorEditorElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ColorEditorElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ColorEditorElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  private readonly _accessor;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Applies a value supplied by Angular forms to the native control.
   *
   * @public
   */
  writeValue(obj: unknown): void;
  /**
   * Registers the callback notified when the native control value changes.
   *
   * @public
   */
  registerOnChange(fn: unknown): void;
  /**
   * Registers the callback notified when the native control is touched.
   *
   * @public
   */
  registerOnTouched(fn: unknown): void;
  /**
   * Applies the disabled state supplied by Angular forms.
   *
   * @public
   */
  setDisabledState?(isDisabled: boolean): void;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ColorEditorElement>(property: TProperty, value: ColorEditorElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ColorEditorElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ColorEditorComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ColorEditorComponent, "mosaik-color-editor", never, {
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "color": {
      "alias": "color";
      "required": false;
      "isSignal": true;
    };
    "format": {
      "alias": "format";
      "required": false;
      "isSignal": true;
    };
    "showAlpha": {
      "alias": "showAlpha";
      "required": false;
      "isSignal": true;
    };
    "showInputs": {
      "alias": "showInputs";
      "required": false;
      "isSignal": true;
    };
    "showPalette": {
      "alias": "showPalette";
      "required": false;
      "isSignal": true;
    };
    "showEyeDropper": {
      "alias": "showEyeDropper";
      "required": false;
      "isSignal": true;
    };
    "showSwatch": {
      "alias": "showSwatch";
      "required": false;
      "isSignal": true;
    };
    "palettes": {
      "alias": "palettes";
      "required": false;
      "isSignal": true;
    };
    "selectedPalette": {
      "alias": "selectedPalette";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "isFocused": {
      "alias": "isFocused";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "colorChanged": "colorChanged";
    "colorFormatChanged": "colorFormatChanged";
    "paletteChanged": "paletteChanged";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, [{
    directive: typeof i1.FormStatusHostDirective;
    inputs: {};
    outputs: {};
  }, {
    directive: typeof i1.FormFieldStatusHostDirective;
    inputs: {};
    outputs: {};
  }]>;
}
/**
 * Declares the methods available on ColorEditorComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ColorEditorMethodNames = never;
/**
 * Declares the methods interface for ColorEditorComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ColorEditorComponentMethods = MethodMap<ColorEditorMethodNames>;
/**
 * @public
 */
export declare function provideColorEditorComponent(config?: Partial<ColorEditorElement.Props>, intl?: Partial<ColorEditorElement['intl']> | Type<Partial<ColorEditorElement['intl']>>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-color-editor.d.ts.map