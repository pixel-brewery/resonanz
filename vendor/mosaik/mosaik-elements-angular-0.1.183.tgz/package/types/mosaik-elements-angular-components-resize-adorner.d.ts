import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { ResizeAdornerElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/adorners/resize-adorner/ResizeAdornerElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the ResizeAdornerComponent.
 * Use this token to provide default properties for the ResizeAdornerComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const RESIZE_ADORNER_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/primitives/adorners/resize-adorner/IResizeAdornerElementProps").IResizeAdornerElementProps>>;
/**
 * @public
 *
 * @slot  - The content of the resize adorner.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ResizeAdornerComponent {
  /**
   * Signal input for the `angle` property.
   *
   * @public
   */
  readonly angle: InputSignal<ResizeAdornerElement['angle'] | undefined>;
  /**
   * Signal input for the `transformOrigin` property.
   *
   * @public
   */
  readonly transformOrigin: InputSignal<ResizeAdornerElement['transformOrigin'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<ResizeAdornerElement['disabled'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ResizeAdornerElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ResizeAdornerElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ResizeAdornerElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ResizeAdornerElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ResizeAdornerElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ResizeAdornerElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ResizeAdornerElement>(property: TProperty, value: ResizeAdornerElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ResizeAdornerElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ResizeAdornerComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ResizeAdornerComponent, "mosaik-resize-adorner", never, {
    "angle": {
      "alias": "angle";
      "required": false;
      "isSignal": true;
    };
    "transformOrigin": {
      "alias": "transformOrigin";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on ResizeAdornerComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ResizeAdornerMethodNames = never;
/**
 * Declares the methods interface for ResizeAdornerComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ResizeAdornerComponentMethods = MethodMap<ResizeAdornerMethodNames>;
/**
 * @public
 */
export declare function provideResizeAdornerComponent(config?: Partial<ResizeAdornerElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-resize-adorner.d.ts.map