import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { PulseElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/illustrations/pulse/PulseElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the PulseComponent.
 * Use this token to provide default properties for the PulseComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const PULSE_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").IPulseElementProps>>;
/**
 * @public
 *
 * @slot  - The core in the middle of the rings.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class PulseComponent {
  /**
   * Signal input for the `count` property.
   *
   * @public
   */
  readonly count: InputSignal<PulseElement['count'] | undefined>;
  /**
   * Signal input for the `duration` property.
   *
   * @public
   */
  readonly duration: InputSignal<PulseElement['duration'] | undefined>;
  /**
   * Signal input for the `dashed` property.
   *
   * @public
   */
  readonly dashed: InputSignal<PulseElement['dashed'] | undefined>;
  /**
   * Signal input for the `filled` property.
   *
   * @public
   */
  readonly filled: InputSignal<PulseElement['filled'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<PulseElement['themeName'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<PulseElement['variant'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<PulseElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<PulseElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<PulseElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<PulseElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<PulseElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof PulseElement>(property: TProperty, value: PulseElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<PulseElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<PulseComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<PulseComponent, "mosaik-pulse", never, {
    "count": {
      "alias": "count";
      "required": false;
      "isSignal": true;
    };
    "duration": {
      "alias": "duration";
      "required": false;
      "isSignal": true;
    };
    "dashed": {
      "alias": "dashed";
      "required": false;
      "isSignal": true;
    };
    "filled": {
      "alias": "filled";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on PulseComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type PulseMethodNames = never;
/**
 * Declares the methods interface for PulseComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type PulseComponentMethods = MethodMap<PulseMethodNames>;
/**
 * @public
 */
export declare function providePulseComponent(config?: Partial<PulseElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-pulse.d.ts.map