import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { DockPanelElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/dock/DockPanelElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the DockPanelComponent.
 * Use this token to provide default properties for the DockPanelComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const DOCK_PANEL_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/layouts/dock/IDockPanelElementProps").IDockPanelElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot for child elements with dock positioning attributes.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class DockPanelComponent {
  /**
   * Signal input for the `lastChildFill` property.
   *
   * @public
   */
  readonly lastChildFill: InputSignal<DockPanelElement['lastChildFill'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<DockPanelElement['themeName'] | undefined>;
  /**
   * Signal input for the `reverse` property.
   *
   * @public
   */
  readonly reverse: InputSignal<DockPanelElement['reverse'] | undefined>;
  /**
   * Signal input for the `orientation` property.
   *
   * @public
   */
  readonly orientation: InputSignal<DockPanelElement['orientation'] | undefined>;
  /**
   * Signal input for the `fit` property.
   *
   * @public
   */
  readonly fit: InputSignal<DockPanelElement['fit'] | undefined>;
  /**
   * Signal input for the `gap` property.
   *
   * @public
   */
  readonly gap: InputSignal<DockPanelElement['gap'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<DockPanelElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<DockPanelElement['lang'] | undefined>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<DockPanelElement, 'changed'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<DockPanelElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<DockPanelElement, 'disconnected'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof DockPanelElement>(property: TProperty, value: DockPanelElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<DockPanelElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<DockPanelComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<DockPanelComponent, "mosaik-dock-panel", never, {
    "lastChildFill": {
      "alias": "lastChildFill";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "reverse": {
      "alias": "reverse";
      "required": false;
      "isSignal": true;
    };
    "orientation": {
      "alias": "orientation";
      "required": false;
      "isSignal": true;
    };
    "fit": {
      "alias": "fit";
      "required": false;
      "isSignal": true;
    };
    "gap": {
      "alias": "gap";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "changed": "changed";
    "connected": "connected";
    "disconnected": "disconnected";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on DockPanelComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type DockPanelMethodNames = never;
/**
 * Declares the methods interface for DockPanelComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type DockPanelComponentMethods = MethodMap<DockPanelMethodNames>;
/**
 * @public
 */
export declare function provideDockPanelComponent(config?: Partial<DockPanelElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-dock.d.ts.map