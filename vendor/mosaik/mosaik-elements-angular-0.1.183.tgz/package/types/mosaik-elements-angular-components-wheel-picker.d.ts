import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { WheelPickerElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/wheel-picker/WheelPickerElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the WheelPickerComponent.
 * Use this token to provide default properties for the WheelPickerComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const WHEEL_PICKER_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").IWheelPickerElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class WheelPickerComponent {
  /**
   * Signal input for the `items` property.
   *
   * @public
   */
  readonly items: InputSignal<WheelPickerElement['items'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<WheelPickerElement['value'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<WheelPickerElement['themeName'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<WheelPickerElement['variant'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<WheelPickerElement['appearance'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<WheelPickerElement['disabled'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<WheelPickerElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<WheelPickerElement['lang'] | undefined>;
  /**
   * Output signal for the `wheelPickerChange` event.
   *
   * @public
   */
  readonly wheelPickerChange: OutputEmitterRef<ElementEventDetail<WheelPickerElement, 'wheelPickerChange'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<WheelPickerElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<WheelPickerElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<WheelPickerElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Scrolls the currently selected item into the vertical center of the column.
   *
   * @public
   * @param args - The arguments of `scrollToSelected`:
   * - `behavior` - The scroll behavior to use.
   */
  scrollToSelected(...args: Parameters<WheelPickerElement['scrollToSelected']>): ReturnType<WheelPickerElement['scrollToSelected']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `scrollToSelected()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends WheelPickerMethodNames>(method: TMethod, ...args: Parameters<WheelPickerComponentMethods[TMethod]>): ReturnType<WheelPickerComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof WheelPickerElement>(property: TProperty, value: WheelPickerElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<WheelPickerElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<WheelPickerComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<WheelPickerComponent, "mosaik-wheel-picker", never, {
    "items": {
      "alias": "items";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "wheelPickerChange": "wheelPickerChange";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on WheelPickerComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type WheelPickerMethodNames = 'scrollToSelected';
/**
 * Declares the methods interface for WheelPickerComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type WheelPickerComponentMethods = MethodMap<WheelPickerMethodNames>;
/**
 * @public
 */
export declare function provideWheelPickerComponent(config?: Partial<WheelPickerElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-wheel-picker.d.ts.map