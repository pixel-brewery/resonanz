import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { CardStackElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/illustrations/card-stack/CardStackElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the CardStackComponent.
 * Use this token to provide default properties for the CardStackComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const CARD_STACK_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").ICardStackElementProps>>;
/**
 * @public
 *
 * @slot  - The cards, in order.
 * @slot current - The current slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class CardStackComponent {
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<CardStackElement['intl'] | undefined>;
  /**
   * Signal input for the `mode` property.
   *
   * @public
   */
  readonly mode: InputSignal<CardStackElement['mode'] | undefined>;
  /**
   * Signal input for the `interval` property.
   *
   * @public
   */
  readonly interval: InputSignal<CardStackElement['interval'] | undefined>;
  /**
   * Signal input for the `index` property.
   *
   * @public
   */
  readonly index: InputSignal<CardStackElement['index'] | undefined>;
  /**
   * Signal input for the `visible` property.
   *
   * @public
   */
  readonly visible: InputSignal<CardStackElement['visible'] | undefined>;
  /**
   * Signal input for the `showDots` property.
   *
   * @public
   */
  readonly showDots: InputSignal<CardStackElement['showDots'] | undefined>;
  /**
   * Signal input for the `threshold` property.
   *
   * @public
   */
  readonly threshold: InputSignal<CardStackElement['threshold'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<CardStackElement['label'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<CardStackElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<CardStackElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<CardStackElement['lang'] | undefined>;
  /**
   * Output signal for the `change` event.
   *
   * @public
   */
  readonly change: OutputEmitterRef<ElementEventDetail<CardStackElement, 'change'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<CardStackElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<CardStackElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<CardStackElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: CardStackElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: CardStackElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Brings the next card to the front; the front card goes to the back.
   *
   * @public
   */
  next(...args: Parameters<CardStackElement['next']>): ReturnType<CardStackElement['next']>;
  /**
   * Brings the previous card (the one at the back) to the front.
   *
   * @public
   */
  previous(...args: Parameters<CardStackElement['previous']>): ReturnType<CardStackElement['previous']>;
  /**
   * Brings a card to the front. The index wraps around.
   *
   * @public
   * @param args - The arguments of `goTo`:
   * - `index` - The zero-based index of the card.
   * - `reason` - What changed the card.
   */
  goTo(...args: Parameters<CardStackElement['goTo']>): ReturnType<CardStackElement['goTo']>;
  /**
   * Called when the slot changes.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<CardStackElement['onSlotChanges']>): ReturnType<CardStackElement['onSlotChanges']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   * @param args - The arguments of `assignToSlot`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * - `node` - The nodes to assign to the slot.
   */
  assignToSlot(...args: Parameters<CardStackElement['assignToSlot']>): ReturnType<CardStackElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   * This method extracts text content recursively, including from Shadow DOMs
   * and Custom Elements with known text properties (like `mosaik-text`).
   *
   * @public
   * @param args - The arguments of `getSlotContent`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<CardStackElement['getSlotContent']>): ReturnType<CardStackElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @param args - The arguments of `hasSlotContent`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<CardStackElement['hasSlotContent']>): ReturnType<CardStackElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @param args - The arguments of `hasSlot`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<CardStackElement['hasSlot']>): ReturnType<CardStackElement['hasSlot']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `next()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends CardStackMethodNames>(method: TMethod, ...args: Parameters<CardStackComponentMethods[TMethod]>): ReturnType<CardStackComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof CardStackElement>(property: TProperty, value: CardStackElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<CardStackElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<CardStackComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<CardStackComponent, "mosaik-card-stack", never, {
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "mode": {
      "alias": "mode";
      "required": false;
      "isSignal": true;
    };
    "interval": {
      "alias": "interval";
      "required": false;
      "isSignal": true;
    };
    "index": {
      "alias": "index";
      "required": false;
      "isSignal": true;
    };
    "visible": {
      "alias": "visible";
      "required": false;
      "isSignal": true;
    };
    "showDots": {
      "alias": "showDots";
      "required": false;
      "isSignal": true;
    };
    "threshold": {
      "alias": "threshold";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "change": "change";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on CardStackComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type CardStackMethodNames = 'next' | 'previous' | 'goTo' | 'onSlotChanges' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot';
/**
 * Declares the methods interface for CardStackComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type CardStackComponentMethods = MethodMap<CardStackMethodNames>;
/**
 * @public
 */
export declare function provideCardStackComponent(config?: Partial<CardStackElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-card-stack.d.ts.map