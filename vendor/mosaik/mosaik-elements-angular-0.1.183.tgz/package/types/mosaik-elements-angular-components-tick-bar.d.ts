import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { TickBarElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/tick-bar/TickBarElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the TickBarComponent.
 * Use this token to provide default properties for the TickBarComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const TICK_BAR_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/primitives/tick-bar/ITickBarElementProps").ITickBarElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class TickBarComponent {
  /**
   * Signal input for the `min` property.
   *
   * @public
   */
  readonly min: InputSignal<TickBarElement['min'] | undefined>;
  /**
   * Signal input for the `max` property.
   *
   * @public
   */
  readonly max: InputSignal<TickBarElement['max'] | undefined>;
  /**
   * Signal input for the `interval` property.
   *
   * @public
   */
  readonly interval: InputSignal<TickBarElement['interval'] | undefined>;
  /**
   * Signal input for the `showLabels` property.
   *
   * @public
   */
  readonly showLabels: InputSignal<TickBarElement['showLabels'] | undefined>;
  /**
   * Signal input for the `labelAccessor` property.
   *
   * @public
   */
  readonly labelAccessor: InputSignal<TickBarElement['labelAccessor'] | undefined>;
  /**
   * Signal input for the `labelPosition` property.
   *
   * @public
   */
  readonly labelPosition: InputSignal<TickBarElement['labelPosition'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<TickBarElement['themeName'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<TickBarElement['disabled'] | undefined>;
  /**
   * Signal input for the `orientation` property.
   *
   * @public
   */
  readonly orientation: InputSignal<TickBarElement['orientation'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<TickBarElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<TickBarElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<TickBarElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<TickBarElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<TickBarElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof TickBarElement>(property: TProperty, value: TickBarElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<TickBarElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<TickBarComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<TickBarComponent, "mosaik-tick-bar", never, {
    "min": {
      "alias": "min";
      "required": false;
      "isSignal": true;
    };
    "max": {
      "alias": "max";
      "required": false;
      "isSignal": true;
    };
    "interval": {
      "alias": "interval";
      "required": false;
      "isSignal": true;
    };
    "showLabels": {
      "alias": "showLabels";
      "required": false;
      "isSignal": true;
    };
    "labelAccessor": {
      "alias": "labelAccessor";
      "required": false;
      "isSignal": true;
    };
    "labelPosition": {
      "alias": "labelPosition";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "orientation": {
      "alias": "orientation";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on TickBarComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TickBarMethodNames = never;
/**
 * Declares the methods interface for TickBarComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TickBarComponentMethods = MethodMap<TickBarMethodNames>;
/**
 * @public
 */
export declare function provideTickBarComponent(config?: Partial<TickBarElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-tick-bar.d.ts.map