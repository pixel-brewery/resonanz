import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { BeamElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/illustrations/beam/BeamElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the BeamComponent.
 * Use this token to provide default properties for the BeamComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const BEAM_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").IBeamElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class BeamComponent {
  /**
   * Signal input for the `source` property.
   *
   * @public
   */
  readonly source: InputSignal<BeamElement['source'] | undefined>;
  /**
   * Signal input for the `target` property.
   *
   * @public
   */
  readonly target: InputSignal<BeamElement['target'] | undefined>;
  /**
   * Signal input for the `mode` property.
   *
   * @public
   */
  readonly mode: InputSignal<BeamElement['mode'] | undefined>;
  /**
   * Signal input for the `routing` property.
   *
   * @public
   */
  readonly routing: InputSignal<BeamElement['routing'] | undefined>;
  /**
   * Signal input for the `sourceSide` property.
   *
   * @public
   */
  readonly sourceSide: InputSignal<BeamElement['sourceSide'] | undefined>;
  /**
   * Signal input for the `targetSide` property.
   *
   * @public
   */
  readonly targetSide: InputSignal<BeamElement['targetSide'] | undefined>;
  /**
   * Signal input for the `offset` property.
   *
   * @public
   */
  readonly offset: InputSignal<BeamElement['offset'] | undefined>;
  /**
   * Signal input for the `cornerRadius` property.
   *
   * @public
   */
  readonly cornerRadius: InputSignal<BeamElement['cornerRadius'] | undefined>;
  /**
   * Signal input for the `duration` property.
   *
   * @public
   */
  readonly duration: InputSignal<BeamElement['duration'] | undefined>;
  /**
   * Signal input for the `delay` property.
   *
   * @public
   */
  readonly delay: InputSignal<BeamElement['delay'] | undefined>;
  /**
   * Signal input for the `reverse` property.
   *
   * @public
   */
  readonly reverse: InputSignal<BeamElement['reverse'] | undefined>;
  /**
   * Signal input for the `travel` property.
   *
   * @public
   */
  readonly travel: InputSignal<BeamElement['travel'] | undefined>;
  /**
   * Signal input for the `step` property.
   *
   * @public
   */
  readonly step: InputSignal<BeamElement['step'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<BeamElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<BeamElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<BeamElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<BeamElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<BeamElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<BeamElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Measures the anchors and routes the beam again at once. The beam does this by itself on resize and on layout
   * changes of the stage; call it after a change it cannot observe, e.g. a moved anchor in another tree.
   *
   * @public
   */
  refresh(...args: Parameters<BeamElement['refresh']>): ReturnType<BeamElement['refresh']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `refresh()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends BeamMethodNames>(method: TMethod, ...args: Parameters<BeamComponentMethods[TMethod]>): ReturnType<BeamComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof BeamElement>(property: TProperty, value: BeamElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<BeamElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<BeamComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<BeamComponent, "mosaik-beam", never, {
    "source": {
      "alias": "source";
      "required": false;
      "isSignal": true;
    };
    "target": {
      "alias": "target";
      "required": false;
      "isSignal": true;
    };
    "mode": {
      "alias": "mode";
      "required": false;
      "isSignal": true;
    };
    "routing": {
      "alias": "routing";
      "required": false;
      "isSignal": true;
    };
    "sourceSide": {
      "alias": "sourceSide";
      "required": false;
      "isSignal": true;
    };
    "targetSide": {
      "alias": "targetSide";
      "required": false;
      "isSignal": true;
    };
    "offset": {
      "alias": "offset";
      "required": false;
      "isSignal": true;
    };
    "cornerRadius": {
      "alias": "cornerRadius";
      "required": false;
      "isSignal": true;
    };
    "duration": {
      "alias": "duration";
      "required": false;
      "isSignal": true;
    };
    "delay": {
      "alias": "delay";
      "required": false;
      "isSignal": true;
    };
    "reverse": {
      "alias": "reverse";
      "required": false;
      "isSignal": true;
    };
    "travel": {
      "alias": "travel";
      "required": false;
      "isSignal": true;
    };
    "step": {
      "alias": "step";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on BeamComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type BeamMethodNames = 'refresh';
/**
 * Declares the methods interface for BeamComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type BeamComponentMethods = MethodMap<BeamMethodNames>;
/**
 * @public
 */
export declare function provideBeamComponent(config?: Partial<BeamElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-beam.d.ts.map