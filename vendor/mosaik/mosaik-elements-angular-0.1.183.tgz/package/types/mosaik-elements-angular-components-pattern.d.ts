import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { PatternElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/effects/pattern/PatternElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the PatternComponent.
 * Use this token to provide default properties for the PatternComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const PATTERN_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/effects/pattern/IPatternElementProps").IPatternElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class PatternComponent {
  /**
   * Signal input for the `mouseX` property.
   *
   * @public
   */
  readonly mouseX: InputSignal<PatternElement['mouseX'] | undefined>;
  /**
   * Signal input for the `mouseY` property.
   *
   * @public
   */
  readonly mouseY: InputSignal<PatternElement['mouseY'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<PatternElement['themeName'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<PatternElement['variant'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<PatternElement['disabled'] | undefined>;
  /**
   * Signal input for the `for` property.
   *
   * @public
   */
  readonly for: InputSignal<PatternElement['for'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<PatternElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<PatternElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<PatternElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<PatternElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<PatternElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Attaches the element to an interactive control.
   *
   * @public
   */
  attach(...args: Parameters<PatternElement['attach']>): ReturnType<PatternElement['attach']>;
  /**
   * Detaches the element from its current control.
   *
   * @public
   */
  detach(...args: Parameters<PatternElement['detach']>): ReturnType<PatternElement['detach']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `attach()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends PatternMethodNames>(method: TMethod, ...args: Parameters<PatternComponentMethods[TMethod]>): ReturnType<PatternComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof PatternElement>(property: TProperty, value: PatternElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<PatternElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<PatternComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<PatternComponent, "mosaik-pattern", never, {
    "mouseX": {
      "alias": "mouseX";
      "required": false;
      "isSignal": true;
    };
    "mouseY": {
      "alias": "mouseY";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "for": {
      "alias": "for";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on PatternComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type PatternMethodNames = 'attach' | 'detach';
/**
 * Declares the methods interface for PatternComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type PatternComponentMethods = MethodMap<PatternMethodNames>;
/**
 * @public
 */
export declare function providePatternComponent(config?: Partial<PatternElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-pattern.d.ts.map