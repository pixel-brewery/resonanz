import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { TextElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/text/TextElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the TextComponent.
 * Use this token to provide default properties for the TextComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const TEXT_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/primitives/text/ITextElementProps").ITextElementProps>>;
/**
 * @public
 *
 * @slot text - Primary text content area for displaying formatted text
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class TextComponent {
  /**
   * Signal input for the `text` property.
   *
   * @public
   */
  readonly text: InputSignal<TextElement['text'] | undefined>;
  /**
   * Signal input for the `truncate` property.
   *
   * @public
   */
  readonly truncate: InputSignal<TextElement['truncate'] | undefined>;
  /**
   * Signal input for the `wrap` property.
   *
   * @public
   */
  readonly wrap: InputSignal<TextElement['wrap'] | undefined>;
  /**
   * Signal input for the `maxLength` property.
   *
   * @public
   */
  readonly maxLength: InputSignal<TextElement['maxLength'] | undefined>;
  /**
   * Signal input for the `maxLines` property.
   *
   * @public
   */
  readonly maxLines: InputSignal<TextElement['maxLines'] | undefined>;
  /**
   * Signal input for the `readonly` property.
   *
   * @public
   */
  readonly readonly: InputSignal<TextElement['readonly'] | undefined>;
  /**
   * Signal input for the `alignment` property.
   *
   * @public
   */
  readonly alignment: InputSignal<TextElement['alignment'] | undefined>;
  /**
   * Signal input for the `marker` property.
   *
   * @public
   */
  readonly marker: InputSignal<TextElement['marker'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<TextElement['themeName'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<TextElement['variant'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<TextElement['disabled'] | undefined>;
  /**
   * Signal input for the `formatter` property.
   *
   * @public
   */
  readonly formatter: InputSignal<TextElement['formatter'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<TextElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<TextElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<TextElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<TextElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<TextElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Mark the `text` by the given `value`. If the value is a boolean `true`, the text will be marked completely.
   *
   * @public
   */
  mark(...args: Parameters<TextElement['mark']>): ReturnType<TextElement['mark']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `mark()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends TextMethodNames>(method: TMethod, ...args: Parameters<TextComponentMethods[TMethod]>): ReturnType<TextComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof TextElement>(property: TProperty, value: TextElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<TextElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<TextComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<TextComponent, "mosaik-text", never, {
    "text": {
      "alias": "text";
      "required": false;
      "isSignal": true;
    };
    "truncate": {
      "alias": "truncate";
      "required": false;
      "isSignal": true;
    };
    "wrap": {
      "alias": "wrap";
      "required": false;
      "isSignal": true;
    };
    "maxLength": {
      "alias": "maxLength";
      "required": false;
      "isSignal": true;
    };
    "maxLines": {
      "alias": "maxLines";
      "required": false;
      "isSignal": true;
    };
    "readonly": {
      "alias": "readonly";
      "required": false;
      "isSignal": true;
    };
    "alignment": {
      "alias": "alignment";
      "required": false;
      "isSignal": true;
    };
    "marker": {
      "alias": "marker";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "formatter": {
      "alias": "formatter";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on TextComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TextMethodNames = 'mark';
/**
 * Declares the methods interface for TextComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TextComponentMethods = MethodMap<TextMethodNames>;
/**
 * @public
 */
export declare function provideTextComponent(config?: Partial<TextElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-text.d.ts.map