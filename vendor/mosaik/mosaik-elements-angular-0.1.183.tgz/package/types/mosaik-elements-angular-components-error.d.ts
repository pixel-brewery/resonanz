import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { ErrorElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/error/ErrorElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the ErrorComponent.
 * Use this token to provide default properties for the ErrorComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const ERROR_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/primitives/error/IErrorElementProps").IErrorElementProps>>;
/**
 * @public
 *
 * @slot icon - Optional icon to display before the error text
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ErrorComponent {
  /**
   * Signal input for the `text` property.
   *
   * @public
   */
  readonly text: InputSignal<ErrorElement['text'] | undefined>;
  /**
   * Signal input for the `textOverflow` property.
   *
   * @public
   */
  readonly textOverflow: InputSignal<ErrorElement['textOverflow'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ErrorElement['themeName'] | undefined>;
  /**
   * Signal input for the `enter` property.
   *
   * @public
   */
  readonly enter: InputSignal<ErrorElement['enter'] | undefined>;
  /**
   * Signal input for the `exit` property.
   *
   * @public
   */
  readonly exit: InputSignal<ErrorElement['exit'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ErrorElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ErrorElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ErrorElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ErrorElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ErrorElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * A lifecycle hook that is invoked when the element is added to the DOM.
   *
   * @public
   */
  onEnterAnimation(...args: Parameters<ErrorElement['onEnterAnimation']>): ReturnType<ErrorElement['onEnterAnimation']>;
  /**
   * A lifecycle hook that is invoked when the element is removed from the DOM.
   *
   * @public
   */
  onExitAnimation(...args: Parameters<ErrorElement['onExitAnimation']>): ReturnType<ErrorElement['onExitAnimation']>;
  /**
   * Executes the animation.
   *
   * @public
   */
  play(...args: Parameters<ErrorElement['play']>): ReturnType<ErrorElement['play']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `onEnterAnimation()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends ErrorMethodNames>(method: TMethod, ...args: Parameters<ErrorComponentMethods[TMethod]>): ReturnType<ErrorComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ErrorElement>(property: TProperty, value: ErrorElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ErrorElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ErrorComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ErrorComponent, "mosaik-error", never, {
    "text": {
      "alias": "text";
      "required": false;
      "isSignal": true;
    };
    "textOverflow": {
      "alias": "textOverflow";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "enter": {
      "alias": "enter";
      "required": false;
      "isSignal": true;
    };
    "exit": {
      "alias": "exit";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on ErrorComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ErrorMethodNames = 'onEnterAnimation' | 'onExitAnimation' | 'play';
/**
 * Declares the methods interface for ErrorComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ErrorComponentMethods = MethodMap<ErrorMethodNames>;
/**
 * @public
 */
export declare function provideErrorComponent(config?: Partial<ErrorElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-error.d.ts.map