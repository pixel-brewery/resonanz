import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { CursorEffectElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/illustrations/cursor-effect/CursorEffectElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the CursorEffectComponent.
 * Use this token to provide default properties for the CursorEffectComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const CURSOR_EFFECT_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").ICursorEffectElementProps>>;
/**
 * @public
 *
 * @slot  - Readable, operable content above the local pointer decoration.
 * @slot cursor - Decorative content following the pointer in content mode; never interactive.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class CursorEffectComponent {
  /**
   * Signal input for the `mode` property.
   *
   * @public
   */
  readonly mode: InputSignal<CursorEffectElement['mode'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<CursorEffectElement['themeName'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<CursorEffectElement['variant'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<CursorEffectElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<CursorEffectElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<CursorEffectElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<CursorEffectElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<CursorEffectElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof CursorEffectElement>(property: TProperty, value: CursorEffectElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<CursorEffectElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<CursorEffectComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<CursorEffectComponent, "mosaik-cursor-effect", never, {
    "mode": {
      "alias": "mode";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on CursorEffectComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type CursorEffectMethodNames = never;
/**
 * Declares the methods interface for CursorEffectComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type CursorEffectComponentMethods = MethodMap<CursorEffectMethodNames>;
/**
 * @public
 */
export declare function provideCursorEffectComponent(config?: Partial<CursorEffectElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-cursor-effect.d.ts.map