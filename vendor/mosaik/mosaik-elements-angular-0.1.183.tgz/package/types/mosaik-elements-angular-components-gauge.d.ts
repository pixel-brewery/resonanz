import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { GaugeArcElement, GaugeControlElement, GaugeDotElement, GaugeElement, GaugeHubElement, GaugeInsetElement, GaugeMarksElement, GaugeNeedleElement, GaugeStackElement, GaugeTextElement, GaugeTickLabelsElement, GaugeTicksElement, GaugeTooltipElement, GaugeTrackElement, GaugeValueElement, GaugeZonesElement } from "@pixel-brewery/mosaik-elements-foundation/components/gauge";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import * as i1 from "@pixel-brewery/mosaik-elements-angular/runtime";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { ControlValueAccessor } from "@angular/forms";
/**
 * @public
 *
 * Injection token for the default properties of the GaugeArcComponent.
 * Use this token to provide default properties for the GaugeArcComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const GAUGE_ARC_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation/components/gauge").IGaugeArcElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class GaugeArcComponent {
  /**
   * Signal input for the `zones` property.
   *
   * @public
   */
  readonly zones: InputSignal<GaugeArcElement['zones'] | undefined>;
  /**
   * Signal input for the `width` property.
   *
   * @public
   */
  readonly width: InputSignal<GaugeArcElement['width'] | undefined>;
  /**
   * Signal input for the `cap` property.
   *
   * @public
   */
  readonly cap: InputSignal<GaugeArcElement['cap'] | undefined>;
  /**
   * Signal input for the `from` property.
   *
   * @public
   */
  readonly from: InputSignal<GaugeArcElement['from'] | undefined>;
  /**
   * Signal input for the `to` property.
   *
   * @public
   */
  readonly to: InputSignal<GaugeArcElement['to'] | undefined>;
  /**
   * Signal input for the `reverse` property.
   *
   * @public
   */
  readonly reverse: InputSignal<GaugeArcElement['reverse'] | undefined>;
  /**
   * Signal input for the `wrap` property.
   *
   * @public
   */
  readonly wrap: InputSignal<GaugeArcElement['wrap'] | undefined>;
  /**
   * Signal input for the `color` property.
   *
   * @public
   */
  readonly color: InputSignal<GaugeArcElement['color'] | undefined>;
  /**
   * Signal input for the `opacity` property.
   *
   * @public
   */
  readonly opacity: InputSignal<GaugeArcElement['opacity'] | undefined>;
  /**
   * Signal input for the `offset` property.
   *
   * @public
   */
  readonly offset: InputSignal<GaugeArcElement['offset'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<GaugeArcElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<GaugeArcElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<GaugeArcElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<GaugeArcElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<GaugeArcElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<GaugeArcElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Draws this part in the owning gauge's animated context.
   *
   * @public
   */
  renderGauge(...args: Parameters<GaugeArcElement['renderGauge']>): ReturnType<GaugeArcElement['renderGauge']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `renderGauge()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends GaugeArcMethodNames>(method: TMethod, ...args: Parameters<GaugeArcComponentMethods[TMethod]>): ReturnType<GaugeArcComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof GaugeArcElement>(property: TProperty, value: GaugeArcElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<GaugeArcElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<GaugeArcComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<GaugeArcComponent, "mosaik-gauge-arc", never, {
    "zones": {
      "alias": "zones";
      "required": false;
      "isSignal": true;
    };
    "width": {
      "alias": "width";
      "required": false;
      "isSignal": true;
    };
    "cap": {
      "alias": "cap";
      "required": false;
      "isSignal": true;
    };
    "from": {
      "alias": "from";
      "required": false;
      "isSignal": true;
    };
    "to": {
      "alias": "to";
      "required": false;
      "isSignal": true;
    };
    "reverse": {
      "alias": "reverse";
      "required": false;
      "isSignal": true;
    };
    "wrap": {
      "alias": "wrap";
      "required": false;
      "isSignal": true;
    };
    "color": {
      "alias": "color";
      "required": false;
      "isSignal": true;
    };
    "opacity": {
      "alias": "opacity";
      "required": false;
      "isSignal": true;
    };
    "offset": {
      "alias": "offset";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on GaugeArcComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type GaugeArcMethodNames = 'renderGauge';
/**
 * Declares the methods interface for GaugeArcComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type GaugeArcComponentMethods = MethodMap<GaugeArcMethodNames>;
/**
 * @public
 */
export declare function provideGaugeArcComponent(config?: Partial<GaugeArcElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the GaugeControlComponent.
 * Use this token to provide default properties for the GaugeControlComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const GAUGE_CONTROL_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation/components/gauge").IGaugeControlElementProps>>;
/**
 * @public
 *
 * @slot  - One composable gauge, preserved in its original framework render parent.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class GaugeControlComponent implements ControlValueAccessor {
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<GaugeControlElement['value'] | undefined>;
  /**
   * Signal input for the `min` property.
   *
   * @public
   */
  readonly min: InputSignal<GaugeControlElement['min'] | undefined>;
  /**
   * Signal input for the `max` property.
   *
   * @public
   */
  readonly max: InputSignal<GaugeControlElement['max'] | undefined>;
  /**
   * Signal input for the `step` property.
   *
   * @public
   */
  readonly step: InputSignal<GaugeControlElement['step'] | undefined>;
  /**
   * Signal input for the `startAngle` property.
   *
   * @public
   */
  readonly startAngle: InputSignal<GaugeControlElement['startAngle'] | undefined>;
  /**
   * Signal input for the `endAngle` property.
   *
   * @public
   */
  readonly endAngle: InputSignal<GaugeControlElement['endAngle'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<GaugeControlElement['label'] | undefined>;
  /**
   * Signal input for the `valueText` property.
   *
   * @public
   */
  readonly valueText: InputSignal<GaugeControlElement['valueText'] | undefined>;
  /**
   * Signal input for the `knob` property.
   *
   * @public
   */
  readonly knob: InputSignal<GaugeControlElement['knob'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<GaugeControlElement['themeName'] | undefined>;
  /**
   * Signal input for the `isFocused` property.
   *
   * @public
   */
  readonly isFocused: InputSignal<GaugeControlElement['isFocused'] | undefined>;
  /**
   * Signal input for the `name` property.
   *
   * @public
   */
  readonly name: InputSignal<GaugeControlElement['name'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<GaugeControlElement['disabled'] | undefined>;
  /**
   * Signal input for the `form` property.
   *
   * @public
   */
  readonly form: InputSignal<GaugeControlElement['form'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<GaugeControlElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<GaugeControlElement['lang'] | undefined>;
  /**
   * Output signal for the `rangeValueChanged` event.
   *
   * @public
   */
  readonly rangeValueChanged: OutputEmitterRef<ElementEventDetail<GaugeControlElement, 'rangeValueChanged'>>;
  /**
   * Output signal for the `gaugePressed` event.
   *
   * @public
   */
  readonly gaugePressed: OutputEmitterRef<ElementEventDetail<GaugeControlElement, 'gaugePressed'>>;
  /**
   * Output signal for the `input` event.
   *
   * @public
   */
  readonly input: OutputEmitterRef<ElementEventDetail<GaugeControlElement, 'input'>>;
  /**
   * Output signal for the `change` event.
   *
   * @public
   */
  readonly change: OutputEmitterRef<ElementEventDetail<GaugeControlElement, 'change'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<GaugeControlElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<GaugeControlElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<GaugeControlElement, 'changed'>>;
  /**
   * Output signal for the `invalid` event.
   *
   * @public
   */
  readonly invalid: OutputEmitterRef<ElementEventDetail<GaugeControlElement, 'invalid'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  private readonly _accessor;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Applies a value supplied by Angular forms to the native control.
   *
   * @public
   */
  writeValue(obj: unknown): void;
  /**
   * Registers the callback notified when the native control value changes.
   *
   * @public
   */
  registerOnChange(fn: unknown): void;
  /**
   * Registers the callback notified when the native control is touched.
   *
   * @public
   */
  registerOnTouched(fn: unknown): void;
  /**
   * Applies the disabled state supplied by Angular forms.
   *
   * @public
   */
  setDisabledState?(isDisabled: boolean): void;
  /**
   * Native numeric form value; disabled controls submit no value.
   *
   * @public
   */
  getFormValue(...args: Parameters<GaugeControlElement['getFormValue']>): ReturnType<GaugeControlElement['getFormValue']>;
  /**
   * Returns true if internals's target element has no validity problems; false otherwise.
   * Fires an invalid event at the element in the latter case.
   *
   * @public
   */
  checkValidity(...args: Parameters<GaugeControlElement['checkValidity']>): ReturnType<GaugeControlElement['checkValidity']>;
  /**
   * Returns true if internals's target element has no validity problems; otherwise, returns false.
   * Fires an invalid event at the element, and (if the event isn't canceled) reports the problem to the user.
   *
   * @public
   */
  reportValidity(...args: Parameters<GaugeControlElement['reportValidity']>): ReturnType<GaugeControlElement['reportValidity']>;
  /**
   * Gets the current form state of a component. Defaults to the component's `[formValue]`.
   *
   * Use this when the state of an element is different from its value, such as
   * checkboxes (internal boolean state and a user string value).
   *
   * @public
   * @returns The current form state, defaults to the form value.
   */
  getFormState(...args: Parameters<GaugeControlElement['getFormState']>): ReturnType<GaugeControlElement['getFormState']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `getFormValue()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends GaugeControlMethodNames>(method: TMethod, ...args: Parameters<GaugeControlComponentMethods[TMethod]>): ReturnType<GaugeControlComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof GaugeControlElement>(property: TProperty, value: GaugeControlElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<GaugeControlElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<GaugeControlComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<GaugeControlComponent, "mosaik-gauge-control", never, {
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "min": {
      "alias": "min";
      "required": false;
      "isSignal": true;
    };
    "max": {
      "alias": "max";
      "required": false;
      "isSignal": true;
    };
    "step": {
      "alias": "step";
      "required": false;
      "isSignal": true;
    };
    "startAngle": {
      "alias": "startAngle";
      "required": false;
      "isSignal": true;
    };
    "endAngle": {
      "alias": "endAngle";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "valueText": {
      "alias": "valueText";
      "required": false;
      "isSignal": true;
    };
    "knob": {
      "alias": "knob";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "isFocused": {
      "alias": "isFocused";
      "required": false;
      "isSignal": true;
    };
    "name": {
      "alias": "name";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "form": {
      "alias": "form";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "rangeValueChanged": "rangeValueChanged";
    "gaugePressed": "gaugePressed";
    "input": "input";
    "change": "change";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
    "invalid": "invalid";
  }, never, ["*"], true, [{
    directive: typeof i1.FormStatusHostDirective;
    inputs: {};
    outputs: {};
  }, {
    directive: typeof i1.FormFieldStatusHostDirective;
    inputs: {};
    outputs: {};
  }]>;
}
/**
 * Declares the methods available on GaugeControlComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type GaugeControlMethodNames = 'getFormValue' | 'checkValidity' | 'reportValidity' | 'getFormState';
/**
 * Declares the methods interface for GaugeControlComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type GaugeControlComponentMethods = MethodMap<GaugeControlMethodNames>;
/**
 * @public
 */
export declare function provideGaugeControlComponent(config?: Partial<GaugeControlElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the GaugeDotComponent.
 * Use this token to provide default properties for the GaugeDotComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const GAUGE_DOT_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation/components/gauge").IGaugeDotElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class GaugeDotComponent {
  /**
   * Signal input for the `radius` property.
   *
   * @public
   */
  readonly radius: InputSignal<GaugeDotElement['radius'] | undefined>;
  /**
   * Signal input for the `turns` property.
   *
   * @public
   */
  readonly turns: InputSignal<GaugeDotElement['turns'] | undefined>;
  /**
   * Signal input for the `halo` property.
   *
   * @public
   */
  readonly halo: InputSignal<GaugeDotElement['halo'] | undefined>;
  /**
   * Signal input for the `haloColor` property.
   *
   * @public
   */
  readonly haloColor: InputSignal<GaugeDotElement['haloColor'] | undefined>;
  /**
   * Signal input for the `color` property.
   *
   * @public
   */
  readonly color: InputSignal<GaugeDotElement['color'] | undefined>;
  /**
   * Signal input for the `opacity` property.
   *
   * @public
   */
  readonly opacity: InputSignal<GaugeDotElement['opacity'] | undefined>;
  /**
   * Signal input for the `offset` property.
   *
   * @public
   */
  readonly offset: InputSignal<GaugeDotElement['offset'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<GaugeDotElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<GaugeDotElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<GaugeDotElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<GaugeDotElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<GaugeDotElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<GaugeDotElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Draws this part in the owning gauge's animated context.
   *
   * @public
   */
  renderGauge(...args: Parameters<GaugeDotElement['renderGauge']>): ReturnType<GaugeDotElement['renderGauge']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `renderGauge()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends GaugeDotMethodNames>(method: TMethod, ...args: Parameters<GaugeDotComponentMethods[TMethod]>): ReturnType<GaugeDotComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof GaugeDotElement>(property: TProperty, value: GaugeDotElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<GaugeDotElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<GaugeDotComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<GaugeDotComponent, "mosaik-gauge-dot", never, {
    "radius": {
      "alias": "radius";
      "required": false;
      "isSignal": true;
    };
    "turns": {
      "alias": "turns";
      "required": false;
      "isSignal": true;
    };
    "halo": {
      "alias": "halo";
      "required": false;
      "isSignal": true;
    };
    "haloColor": {
      "alias": "haloColor";
      "required": false;
      "isSignal": true;
    };
    "color": {
      "alias": "color";
      "required": false;
      "isSignal": true;
    };
    "opacity": {
      "alias": "opacity";
      "required": false;
      "isSignal": true;
    };
    "offset": {
      "alias": "offset";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on GaugeDotComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type GaugeDotMethodNames = 'renderGauge';
/**
 * Declares the methods interface for GaugeDotComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type GaugeDotComponentMethods = MethodMap<GaugeDotMethodNames>;
/**
 * @public
 */
export declare function provideGaugeDotComponent(config?: Partial<GaugeDotElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the GaugeHubComponent.
 * Use this token to provide default properties for the GaugeHubComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const GAUGE_HUB_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation/components/gauge").IGaugeHubElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class GaugeHubComponent {
  /**
   * Signal input for the `radius` property.
   *
   * @public
   */
  readonly radius: InputSignal<GaugeHubElement['radius'] | undefined>;
  /**
   * Signal input for the `color` property.
   *
   * @public
   */
  readonly color: InputSignal<GaugeHubElement['color'] | undefined>;
  /**
   * Signal input for the `opacity` property.
   *
   * @public
   */
  readonly opacity: InputSignal<GaugeHubElement['opacity'] | undefined>;
  /**
   * Signal input for the `offset` property.
   *
   * @public
   */
  readonly offset: InputSignal<GaugeHubElement['offset'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<GaugeHubElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<GaugeHubElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<GaugeHubElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<GaugeHubElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<GaugeHubElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<GaugeHubElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Draws this part in the owning gauge's animated context.
   *
   * @public
   */
  renderGauge(...args: Parameters<GaugeHubElement['renderGauge']>): ReturnType<GaugeHubElement['renderGauge']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `renderGauge()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends GaugeHubMethodNames>(method: TMethod, ...args: Parameters<GaugeHubComponentMethods[TMethod]>): ReturnType<GaugeHubComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof GaugeHubElement>(property: TProperty, value: GaugeHubElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<GaugeHubElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<GaugeHubComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<GaugeHubComponent, "mosaik-gauge-hub", never, {
    "radius": {
      "alias": "radius";
      "required": false;
      "isSignal": true;
    };
    "color": {
      "alias": "color";
      "required": false;
      "isSignal": true;
    };
    "opacity": {
      "alias": "opacity";
      "required": false;
      "isSignal": true;
    };
    "offset": {
      "alias": "offset";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on GaugeHubComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type GaugeHubMethodNames = 'renderGauge';
/**
 * Declares the methods interface for GaugeHubComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type GaugeHubComponentMethods = MethodMap<GaugeHubMethodNames>;
/**
 * @public
 */
export declare function provideGaugeHubComponent(config?: Partial<GaugeHubElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the GaugeInsetComponent.
 * Use this token to provide default properties for the GaugeInsetComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const GAUGE_INSET_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation/components/gauge").IGaugeInsetElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class GaugeInsetComponent {
  /**
   * Signal input for the `x` property.
   *
   * @public
   */
  readonly x: InputSignal<GaugeInsetElement['x'] | undefined>;
  /**
   * Signal input for the `y` property.
   *
   * @public
   */
  readonly y: InputSignal<GaugeInsetElement['y'] | undefined>;
  /**
   * Signal input for the `scale` property.
   *
   * @public
   */
  readonly scale: InputSignal<GaugeInsetElement['scale'] | undefined>;
  /**
   * Signal input for the `transition` property.
   *
   * @public
   */
  readonly transition: InputSignal<GaugeInsetElement['transition'] | undefined>;
  /**
   * Signal input for the `startAngle` property.
   *
   * @public
   */
  readonly startAngle: InputSignal<GaugeInsetElement['startAngle'] | undefined>;
  /**
   * Signal input for the `endAngle` property.
   *
   * @public
   */
  readonly endAngle: InputSignal<GaugeInsetElement['endAngle'] | undefined>;
  /**
   * Signal input for the `radius` property.
   *
   * @public
   */
  readonly radius: InputSignal<GaugeInsetElement['radius'] | undefined>;
  /**
   * Signal input for the `rotate` property.
   *
   * @public
   */
  readonly rotate: InputSignal<GaugeInsetElement['rotate'] | undefined>;
  /**
   * Signal input for the `wrap` property.
   *
   * @public
   */
  readonly wrap: InputSignal<GaugeInsetElement['wrap'] | undefined>;
  /**
   * Signal input for the `initialValue` property.
   *
   * @public
   */
  readonly initialValue: InputSignal<GaugeInsetElement['initialValue'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<GaugeInsetElement['themeName'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<GaugeInsetElement['label'] | undefined>;
  /**
   * Signal input for the `min` property.
   *
   * @public
   */
  readonly min: InputSignal<GaugeInsetElement['min'] | undefined>;
  /**
   * Signal input for the `max` property.
   *
   * @public
   */
  readonly max: InputSignal<GaugeInsetElement['max'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<GaugeInsetElement['value'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<GaugeInsetElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<GaugeInsetElement['lang'] | undefined>;
  /**
   * Output signal for the `rangeValueChanged` event.
   *
   * @public
   */
  readonly rangeValueChanged: OutputEmitterRef<ElementEventDetail<GaugeInsetElement, 'rangeValueChanged'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<GaugeInsetElement, 'changed'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<GaugeInsetElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<GaugeInsetElement, 'disconnected'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Draws a dial in a parent context.
   *
   * @public
   */
  renderGauge(...args: Parameters<GaugeInsetElement['renderGauge']>): ReturnType<GaugeInsetElement['renderGauge']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `renderGauge()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends GaugeInsetMethodNames>(method: TMethod, ...args: Parameters<GaugeInsetComponentMethods[TMethod]>): ReturnType<GaugeInsetComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof GaugeInsetElement>(property: TProperty, value: GaugeInsetElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<GaugeInsetElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<GaugeInsetComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<GaugeInsetComponent, "mosaik-gauge-inset", never, {
    "x": {
      "alias": "x";
      "required": false;
      "isSignal": true;
    };
    "y": {
      "alias": "y";
      "required": false;
      "isSignal": true;
    };
    "scale": {
      "alias": "scale";
      "required": false;
      "isSignal": true;
    };
    "transition": {
      "alias": "transition";
      "required": false;
      "isSignal": true;
    };
    "startAngle": {
      "alias": "startAngle";
      "required": false;
      "isSignal": true;
    };
    "endAngle": {
      "alias": "endAngle";
      "required": false;
      "isSignal": true;
    };
    "radius": {
      "alias": "radius";
      "required": false;
      "isSignal": true;
    };
    "rotate": {
      "alias": "rotate";
      "required": false;
      "isSignal": true;
    };
    "wrap": {
      "alias": "wrap";
      "required": false;
      "isSignal": true;
    };
    "initialValue": {
      "alias": "initialValue";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "min": {
      "alias": "min";
      "required": false;
      "isSignal": true;
    };
    "max": {
      "alias": "max";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "rangeValueChanged": "rangeValueChanged";
    "changed": "changed";
    "connected": "connected";
    "disconnected": "disconnected";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on GaugeInsetComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type GaugeInsetMethodNames = 'renderGauge';
/**
 * Declares the methods interface for GaugeInsetComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type GaugeInsetComponentMethods = MethodMap<GaugeInsetMethodNames>;
/**
 * @public
 */
export declare function provideGaugeInsetComponent(config?: Partial<GaugeInsetElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the GaugeMarksComponent.
 * Use this token to provide default properties for the GaugeMarksComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const GAUGE_MARKS_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation/components/gauge").IGaugeMarksElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class GaugeMarksComponent {
  /**
   * Signal input for the `width` property.
   *
   * @public
   */
  readonly width: InputSignal<GaugeMarksElement['width'] | undefined>;
  /**
   * Signal input for the `cap` property.
   *
   * @public
   */
  readonly cap: InputSignal<GaugeMarksElement['cap'] | undefined>;
  /**
   * Signal input for the `length` property.
   *
   * @public
   */
  readonly length: InputSignal<GaugeMarksElement['length'] | undefined>;
  /**
   * Signal input for the `count` property.
   *
   * @public
   */
  readonly count: InputSignal<GaugeMarksElement['count'] | undefined>;
  /**
   * Signal input for the `values` property.
   *
   * @public
   */
  readonly values: InputSignal<GaugeMarksElement['values'] | undefined>;
  /**
   * Signal input for the `color` property.
   *
   * @public
   */
  readonly color: InputSignal<GaugeMarksElement['color'] | undefined>;
  /**
   * Signal input for the `opacity` property.
   *
   * @public
   */
  readonly opacity: InputSignal<GaugeMarksElement['opacity'] | undefined>;
  /**
   * Signal input for the `offset` property.
   *
   * @public
   */
  readonly offset: InputSignal<GaugeMarksElement['offset'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<GaugeMarksElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<GaugeMarksElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<GaugeMarksElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<GaugeMarksElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<GaugeMarksElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<GaugeMarksElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Draws this part in the owning gauge's animated context.
   *
   * @public
   */
  renderGauge(...args: Parameters<GaugeMarksElement['renderGauge']>): ReturnType<GaugeMarksElement['renderGauge']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `renderGauge()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends GaugeMarksMethodNames>(method: TMethod, ...args: Parameters<GaugeMarksComponentMethods[TMethod]>): ReturnType<GaugeMarksComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof GaugeMarksElement>(property: TProperty, value: GaugeMarksElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<GaugeMarksElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<GaugeMarksComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<GaugeMarksComponent, "mosaik-gauge-marks", never, {
    "width": {
      "alias": "width";
      "required": false;
      "isSignal": true;
    };
    "cap": {
      "alias": "cap";
      "required": false;
      "isSignal": true;
    };
    "length": {
      "alias": "length";
      "required": false;
      "isSignal": true;
    };
    "count": {
      "alias": "count";
      "required": false;
      "isSignal": true;
    };
    "values": {
      "alias": "values";
      "required": false;
      "isSignal": true;
    };
    "color": {
      "alias": "color";
      "required": false;
      "isSignal": true;
    };
    "opacity": {
      "alias": "opacity";
      "required": false;
      "isSignal": true;
    };
    "offset": {
      "alias": "offset";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on GaugeMarksComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type GaugeMarksMethodNames = 'renderGauge';
/**
 * Declares the methods interface for GaugeMarksComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type GaugeMarksComponentMethods = MethodMap<GaugeMarksMethodNames>;
/**
 * @public
 */
export declare function provideGaugeMarksComponent(config?: Partial<GaugeMarksElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the GaugeNeedleComponent.
 * Use this token to provide default properties for the GaugeNeedleComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const GAUGE_NEEDLE_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation/components/gauge").IGaugeNeedleElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class GaugeNeedleComponent {
  /**
   * Signal input for the `needleStyle` property.
   *
   * @public
   */
  readonly needleStyle: InputSignal<GaugeNeedleElement['needleStyle'] | undefined>;
  /**
   * Signal input for the `length` property.
   *
   * @public
   */
  readonly length: InputSignal<GaugeNeedleElement['length'] | undefined>;
  /**
   * Signal input for the `width` property.
   *
   * @public
   */
  readonly width: InputSignal<GaugeNeedleElement['width'] | undefined>;
  /**
   * Signal input for the `tail` property.
   *
   * @public
   */
  readonly tail: InputSignal<GaugeNeedleElement['tail'] | undefined>;
  /**
   * Signal input for the `tailColor` property.
   *
   * @public
   */
  readonly tailColor: InputSignal<GaugeNeedleElement['tailColor'] | undefined>;
  /**
   * Signal input for the `tailDot` property.
   *
   * @public
   */
  readonly tailDot: InputSignal<GaugeNeedleElement['tailDot'] | undefined>;
  /**
   * Signal input for the `turns` property.
   *
   * @public
   */
  readonly turns: InputSignal<GaugeNeedleElement['turns'] | undefined>;
  /**
   * Signal input for the `gap` property.
   *
   * @public
   */
  readonly gap: InputSignal<GaugeNeedleElement['gap'] | undefined>;
  /**
   * Signal input for the `color` property.
   *
   * @public
   */
  readonly color: InputSignal<GaugeNeedleElement['color'] | undefined>;
  /**
   * Signal input for the `opacity` property.
   *
   * @public
   */
  readonly opacity: InputSignal<GaugeNeedleElement['opacity'] | undefined>;
  /**
   * Signal input for the `offset` property.
   *
   * @public
   */
  readonly offset: InputSignal<GaugeNeedleElement['offset'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<GaugeNeedleElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<GaugeNeedleElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<GaugeNeedleElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<GaugeNeedleElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<GaugeNeedleElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<GaugeNeedleElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Draws this part in the owning gauge's animated context.
   *
   * @public
   */
  renderGauge(...args: Parameters<GaugeNeedleElement['renderGauge']>): ReturnType<GaugeNeedleElement['renderGauge']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `renderGauge()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends GaugeNeedleMethodNames>(method: TMethod, ...args: Parameters<GaugeNeedleComponentMethods[TMethod]>): ReturnType<GaugeNeedleComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof GaugeNeedleElement>(property: TProperty, value: GaugeNeedleElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<GaugeNeedleElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<GaugeNeedleComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<GaugeNeedleComponent, "mosaik-gauge-needle", never, {
    "needleStyle": {
      "alias": "needleStyle";
      "required": false;
      "isSignal": true;
    };
    "length": {
      "alias": "length";
      "required": false;
      "isSignal": true;
    };
    "width": {
      "alias": "width";
      "required": false;
      "isSignal": true;
    };
    "tail": {
      "alias": "tail";
      "required": false;
      "isSignal": true;
    };
    "tailColor": {
      "alias": "tailColor";
      "required": false;
      "isSignal": true;
    };
    "tailDot": {
      "alias": "tailDot";
      "required": false;
      "isSignal": true;
    };
    "turns": {
      "alias": "turns";
      "required": false;
      "isSignal": true;
    };
    "gap": {
      "alias": "gap";
      "required": false;
      "isSignal": true;
    };
    "color": {
      "alias": "color";
      "required": false;
      "isSignal": true;
    };
    "opacity": {
      "alias": "opacity";
      "required": false;
      "isSignal": true;
    };
    "offset": {
      "alias": "offset";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on GaugeNeedleComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type GaugeNeedleMethodNames = 'renderGauge';
/**
 * Declares the methods interface for GaugeNeedleComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type GaugeNeedleComponentMethods = MethodMap<GaugeNeedleMethodNames>;
/**
 * @public
 */
export declare function provideGaugeNeedleComponent(config?: Partial<GaugeNeedleElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the GaugeStackComponent.
 * Use this token to provide default properties for the GaugeStackComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const GAUGE_STACK_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation/components/gauge").IGaugeStackElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class GaugeStackComponent {
  /**
   * Signal input for the `width` property.
   *
   * @public
   */
  readonly width: InputSignal<GaugeStackElement['width'] | undefined>;
  /**
   * Signal input for the `cap` property.
   *
   * @public
   */
  readonly cap: InputSignal<GaugeStackElement['cap'] | undefined>;
  /**
   * Signal input for the `from` property.
   *
   * @public
   */
  readonly from: InputSignal<GaugeStackElement['from'] | undefined>;
  /**
   * Signal input for the `parts` property.
   *
   * @public
   */
  readonly parts: InputSignal<GaugeStackElement['parts'] | undefined>;
  /**
   * Signal input for the `color` property.
   *
   * @public
   */
  readonly color: InputSignal<GaugeStackElement['color'] | undefined>;
  /**
   * Signal input for the `opacity` property.
   *
   * @public
   */
  readonly opacity: InputSignal<GaugeStackElement['opacity'] | undefined>;
  /**
   * Signal input for the `offset` property.
   *
   * @public
   */
  readonly offset: InputSignal<GaugeStackElement['offset'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<GaugeStackElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<GaugeStackElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<GaugeStackElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<GaugeStackElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<GaugeStackElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<GaugeStackElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Draws this part in the owning gauge's animated context.
   *
   * @public
   */
  renderGauge(...args: Parameters<GaugeStackElement['renderGauge']>): ReturnType<GaugeStackElement['renderGauge']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `renderGauge()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends GaugeStackMethodNames>(method: TMethod, ...args: Parameters<GaugeStackComponentMethods[TMethod]>): ReturnType<GaugeStackComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof GaugeStackElement>(property: TProperty, value: GaugeStackElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<GaugeStackElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<GaugeStackComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<GaugeStackComponent, "mosaik-gauge-stack", never, {
    "width": {
      "alias": "width";
      "required": false;
      "isSignal": true;
    };
    "cap": {
      "alias": "cap";
      "required": false;
      "isSignal": true;
    };
    "from": {
      "alias": "from";
      "required": false;
      "isSignal": true;
    };
    "parts": {
      "alias": "parts";
      "required": false;
      "isSignal": true;
    };
    "color": {
      "alias": "color";
      "required": false;
      "isSignal": true;
    };
    "opacity": {
      "alias": "opacity";
      "required": false;
      "isSignal": true;
    };
    "offset": {
      "alias": "offset";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on GaugeStackComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type GaugeStackMethodNames = 'renderGauge';
/**
 * Declares the methods interface for GaugeStackComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type GaugeStackComponentMethods = MethodMap<GaugeStackMethodNames>;
/**
 * @public
 */
export declare function provideGaugeStackComponent(config?: Partial<GaugeStackElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the GaugeTextComponent.
 * Use this token to provide default properties for the GaugeTextComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const GAUGE_TEXT_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation/components/gauge").IGaugeTextElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class GaugeTextComponent {
  /**
   * Signal input for the `x` property.
   *
   * @public
   */
  readonly x: InputSignal<GaugeTextElement['x'] | undefined>;
  /**
   * Signal input for the `y` property.
   *
   * @public
   */
  readonly y: InputSignal<GaugeTextElement['y'] | undefined>;
  /**
   * Signal input for the `fontSize` property.
   *
   * @public
   */
  readonly fontSize: InputSignal<GaugeTextElement['fontSize'] | undefined>;
  /**
   * Signal input for the `font` property.
   *
   * @public
   */
  readonly font: InputSignal<GaugeTextElement['font'] | undefined>;
  /**
   * Signal input for the `weight` property.
   *
   * @public
   */
  readonly weight: InputSignal<GaugeTextElement['weight'] | undefined>;
  /**
   * Signal input for the `anchor` property.
   *
   * @public
   */
  readonly anchor: InputSignal<GaugeTextElement['anchor'] | undefined>;
  /**
   * Signal input for the `text` property.
   *
   * @public
   */
  readonly text: InputSignal<GaugeTextElement['text'] | undefined>;
  /**
   * Signal input for the `color` property.
   *
   * @public
   */
  readonly color: InputSignal<GaugeTextElement['color'] | undefined>;
  /**
   * Signal input for the `opacity` property.
   *
   * @public
   */
  readonly opacity: InputSignal<GaugeTextElement['opacity'] | undefined>;
  /**
   * Signal input for the `offset` property.
   *
   * @public
   */
  readonly offset: InputSignal<GaugeTextElement['offset'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<GaugeTextElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<GaugeTextElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<GaugeTextElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<GaugeTextElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<GaugeTextElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<GaugeTextElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Draws this part in the owning gauge's animated context.
   *
   * @public
   */
  renderGauge(...args: Parameters<GaugeTextElement['renderGauge']>): ReturnType<GaugeTextElement['renderGauge']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `renderGauge()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends GaugeTextMethodNames>(method: TMethod, ...args: Parameters<GaugeTextComponentMethods[TMethod]>): ReturnType<GaugeTextComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof GaugeTextElement>(property: TProperty, value: GaugeTextElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<GaugeTextElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<GaugeTextComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<GaugeTextComponent, "mosaik-gauge-text", never, {
    "x": {
      "alias": "x";
      "required": false;
      "isSignal": true;
    };
    "y": {
      "alias": "y";
      "required": false;
      "isSignal": true;
    };
    "fontSize": {
      "alias": "fontSize";
      "required": false;
      "isSignal": true;
    };
    "font": {
      "alias": "font";
      "required": false;
      "isSignal": true;
    };
    "weight": {
      "alias": "weight";
      "required": false;
      "isSignal": true;
    };
    "anchor": {
      "alias": "anchor";
      "required": false;
      "isSignal": true;
    };
    "text": {
      "alias": "text";
      "required": false;
      "isSignal": true;
    };
    "color": {
      "alias": "color";
      "required": false;
      "isSignal": true;
    };
    "opacity": {
      "alias": "opacity";
      "required": false;
      "isSignal": true;
    };
    "offset": {
      "alias": "offset";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on GaugeTextComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type GaugeTextMethodNames = 'renderGauge';
/**
 * Declares the methods interface for GaugeTextComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type GaugeTextComponentMethods = MethodMap<GaugeTextMethodNames>;
/**
 * @public
 */
export declare function provideGaugeTextComponent(config?: Partial<GaugeTextElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the GaugeTickLabelsComponent.
 * Use this token to provide default properties for the GaugeTickLabelsComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const GAUGE_TICK_LABELS_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation/components/gauge").IGaugeTickLabelsElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class GaugeTickLabelsComponent {
  /**
   * Signal input for the `count` property.
   *
   * @public
   */
  readonly count: InputSignal<GaugeTickLabelsElement['count'] | undefined>;
  /**
   * Signal input for the `fontSize` property.
   *
   * @public
   */
  readonly fontSize: InputSignal<GaugeTickLabelsElement['fontSize'] | undefined>;
  /**
   * Signal input for the `font` property.
   *
   * @public
   */
  readonly font: InputSignal<GaugeTickLabelsElement['font'] | undefined>;
  /**
   * Signal input for the `weight` property.
   *
   * @public
   */
  readonly weight: InputSignal<GaugeTickLabelsElement['weight'] | undefined>;
  /**
   * Signal input for the `decimals` property.
   *
   * @public
   */
  readonly decimals: InputSignal<GaugeTickLabelsElement['decimals'] | undefined>;
  /**
   * Signal input for the `format` property.
   *
   * @public
   */
  readonly format: InputSignal<GaugeTickLabelsElement['format'] | undefined>;
  /**
   * Signal input for the `formatter` property.
   *
   * @public
   */
  readonly formatter: InputSignal<GaugeTickLabelsElement['formatter'] | undefined>;
  /**
   * Signal input for the `color` property.
   *
   * @public
   */
  readonly color: InputSignal<GaugeTickLabelsElement['color'] | undefined>;
  /**
   * Signal input for the `opacity` property.
   *
   * @public
   */
  readonly opacity: InputSignal<GaugeTickLabelsElement['opacity'] | undefined>;
  /**
   * Signal input for the `offset` property.
   *
   * @public
   */
  readonly offset: InputSignal<GaugeTickLabelsElement['offset'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<GaugeTickLabelsElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<GaugeTickLabelsElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<GaugeTickLabelsElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<GaugeTickLabelsElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<GaugeTickLabelsElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<GaugeTickLabelsElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Draws this part in the owning gauge's animated context.
   *
   * @public
   */
  renderGauge(...args: Parameters<GaugeTickLabelsElement['renderGauge']>): ReturnType<GaugeTickLabelsElement['renderGauge']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `renderGauge()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends GaugeTickLabelsMethodNames>(method: TMethod, ...args: Parameters<GaugeTickLabelsComponentMethods[TMethod]>): ReturnType<GaugeTickLabelsComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof GaugeTickLabelsElement>(property: TProperty, value: GaugeTickLabelsElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<GaugeTickLabelsElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<GaugeTickLabelsComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<GaugeTickLabelsComponent, "mosaik-gauge-tick-labels", never, {
    "count": {
      "alias": "count";
      "required": false;
      "isSignal": true;
    };
    "fontSize": {
      "alias": "fontSize";
      "required": false;
      "isSignal": true;
    };
    "font": {
      "alias": "font";
      "required": false;
      "isSignal": true;
    };
    "weight": {
      "alias": "weight";
      "required": false;
      "isSignal": true;
    };
    "decimals": {
      "alias": "decimals";
      "required": false;
      "isSignal": true;
    };
    "format": {
      "alias": "format";
      "required": false;
      "isSignal": true;
    };
    "formatter": {
      "alias": "formatter";
      "required": false;
      "isSignal": true;
    };
    "color": {
      "alias": "color";
      "required": false;
      "isSignal": true;
    };
    "opacity": {
      "alias": "opacity";
      "required": false;
      "isSignal": true;
    };
    "offset": {
      "alias": "offset";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on GaugeTickLabelsComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type GaugeTickLabelsMethodNames = 'renderGauge';
/**
 * Declares the methods interface for GaugeTickLabelsComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type GaugeTickLabelsComponentMethods = MethodMap<GaugeTickLabelsMethodNames>;
/**
 * @public
 */
export declare function provideGaugeTickLabelsComponent(config?: Partial<GaugeTickLabelsElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the GaugeTicksComponent.
 * Use this token to provide default properties for the GaugeTicksComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const GAUGE_TICKS_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation/components/gauge").IGaugeTicksElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class GaugeTicksComponent {
  /**
   * Signal input for the `width` property.
   *
   * @public
   */
  readonly width: InputSignal<GaugeTicksElement['width'] | undefined>;
  /**
   * Signal input for the `cap` property.
   *
   * @public
   */
  readonly cap: InputSignal<GaugeTicksElement['cap'] | undefined>;
  /**
   * Signal input for the `length` property.
   *
   * @public
   */
  readonly length: InputSignal<GaugeTicksElement['length'] | undefined>;
  /**
   * Signal input for the `count` property.
   *
   * @public
   */
  readonly count: InputSignal<GaugeTicksElement['count'] | undefined>;
  /**
   * Signal input for the `color` property.
   *
   * @public
   */
  readonly color: InputSignal<GaugeTicksElement['color'] | undefined>;
  /**
   * Signal input for the `opacity` property.
   *
   * @public
   */
  readonly opacity: InputSignal<GaugeTicksElement['opacity'] | undefined>;
  /**
   * Signal input for the `offset` property.
   *
   * @public
   */
  readonly offset: InputSignal<GaugeTicksElement['offset'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<GaugeTicksElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<GaugeTicksElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<GaugeTicksElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<GaugeTicksElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<GaugeTicksElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<GaugeTicksElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Draws this part in the owning gauge's animated context.
   *
   * @public
   */
  renderGauge(...args: Parameters<GaugeTicksElement['renderGauge']>): ReturnType<GaugeTicksElement['renderGauge']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `renderGauge()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends GaugeTicksMethodNames>(method: TMethod, ...args: Parameters<GaugeTicksComponentMethods[TMethod]>): ReturnType<GaugeTicksComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof GaugeTicksElement>(property: TProperty, value: GaugeTicksElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<GaugeTicksElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<GaugeTicksComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<GaugeTicksComponent, "mosaik-gauge-ticks", never, {
    "width": {
      "alias": "width";
      "required": false;
      "isSignal": true;
    };
    "cap": {
      "alias": "cap";
      "required": false;
      "isSignal": true;
    };
    "length": {
      "alias": "length";
      "required": false;
      "isSignal": true;
    };
    "count": {
      "alias": "count";
      "required": false;
      "isSignal": true;
    };
    "color": {
      "alias": "color";
      "required": false;
      "isSignal": true;
    };
    "opacity": {
      "alias": "opacity";
      "required": false;
      "isSignal": true;
    };
    "offset": {
      "alias": "offset";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on GaugeTicksComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type GaugeTicksMethodNames = 'renderGauge';
/**
 * Declares the methods interface for GaugeTicksComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type GaugeTicksComponentMethods = MethodMap<GaugeTicksMethodNames>;
/**
 * @public
 */
export declare function provideGaugeTicksComponent(config?: Partial<GaugeTicksElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the GaugeTooltipComponent.
 * Use this token to provide default properties for the GaugeTooltipComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const GAUGE_TOOLTIP_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation/components/gauge").IGaugeTooltipElementProps>>;
/**
 * @public
 *
 * @slot  - Custom HTML content, retained in its original framework render parent.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class GaugeTooltipComponent {
  /**
   * Signal input for the `isOpen` property.
   *
   * @public
   */
  readonly isOpen: InputSignal<GaugeTooltipElement['isOpen'] | undefined>;
  /**
   * Signal input for the `position` property.
   *
   * @public
   */
  readonly position: InputSignal<GaugeTooltipElement['position'] | undefined>;
  /**
   * Signal input for the `side` property.
   *
   * @public
   */
  readonly side: InputSignal<GaugeTooltipElement['side'] | undefined>;
  /**
   * Signal input for the `at` property.
   *
   * @public
   */
  readonly at: InputSignal<GaugeTooltipElement['at'] | undefined>;
  /**
   * Signal input for the `gap` property.
   *
   * @public
   */
  readonly gap: InputSignal<GaugeTooltipElement['gap'] | undefined>;
  /**
   * Signal input for the `avoidCollisions` property.
   *
   * @public
   */
  readonly avoidCollisions: InputSignal<GaugeTooltipElement['avoidCollisions'] | undefined>;
  /**
   * Signal input for the `collisionPadding` property.
   *
   * @public
   */
  readonly collisionPadding: InputSignal<GaugeTooltipElement['collisionPadding'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<GaugeTooltipElement['label'] | undefined>;
  /**
   * Signal input for the `unit` property.
   *
   * @public
   */
  readonly unit: InputSignal<GaugeTooltipElement['unit'] | undefined>;
  /**
   * Signal input for the `decimals` property.
   *
   * @public
   */
  readonly decimals: InputSignal<GaugeTooltipElement['decimals'] | undefined>;
  /**
   * Signal input for the `format` property.
   *
   * @public
   */
  readonly format: InputSignal<GaugeTooltipElement['format'] | undefined>;
  /**
   * Signal input for the `formatter` property.
   *
   * @public
   */
  readonly formatter: InputSignal<GaugeTooltipElement['formatter'] | undefined>;
  /**
   * Signal input for the `contentRenderer` property.
   *
   * @public
   */
  readonly contentRenderer: InputSignal<GaugeTooltipElement['contentRenderer'] | undefined>;
  /**
   * Signal input for the `color` property.
   *
   * @public
   */
  readonly color: InputSignal<GaugeTooltipElement['color'] | undefined>;
  /**
   * Signal input for the `opacity` property.
   *
   * @public
   */
  readonly opacity: InputSignal<GaugeTooltipElement['opacity'] | undefined>;
  /**
   * Signal input for the `offset` property.
   *
   * @public
   */
  readonly offset: InputSignal<GaugeTooltipElement['offset'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<GaugeTooltipElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<GaugeTooltipElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<GaugeTooltipElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<GaugeTooltipElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<GaugeTooltipElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<GaugeTooltipElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Draws this part in its nearest gauge's animated context.
   *
   * @public
   */
  renderGauge(...args: Parameters<GaugeTooltipElement['renderGauge']>): ReturnType<GaugeTooltipElement['renderGauge']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `renderGauge()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends GaugeTooltipMethodNames>(method: TMethod, ...args: Parameters<GaugeTooltipComponentMethods[TMethod]>): ReturnType<GaugeTooltipComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof GaugeTooltipElement>(property: TProperty, value: GaugeTooltipElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<GaugeTooltipElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<GaugeTooltipComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<GaugeTooltipComponent, "mosaik-gauge-tooltip", never, {
    "isOpen": {
      "alias": "isOpen";
      "required": false;
      "isSignal": true;
    };
    "position": {
      "alias": "position";
      "required": false;
      "isSignal": true;
    };
    "side": {
      "alias": "side";
      "required": false;
      "isSignal": true;
    };
    "at": {
      "alias": "at";
      "required": false;
      "isSignal": true;
    };
    "gap": {
      "alias": "gap";
      "required": false;
      "isSignal": true;
    };
    "avoidCollisions": {
      "alias": "avoidCollisions";
      "required": false;
      "isSignal": true;
    };
    "collisionPadding": {
      "alias": "collisionPadding";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "unit": {
      "alias": "unit";
      "required": false;
      "isSignal": true;
    };
    "decimals": {
      "alias": "decimals";
      "required": false;
      "isSignal": true;
    };
    "format": {
      "alias": "format";
      "required": false;
      "isSignal": true;
    };
    "formatter": {
      "alias": "formatter";
      "required": false;
      "isSignal": true;
    };
    "contentRenderer": {
      "alias": "contentRenderer";
      "required": false;
      "isSignal": true;
    };
    "color": {
      "alias": "color";
      "required": false;
      "isSignal": true;
    };
    "opacity": {
      "alias": "opacity";
      "required": false;
      "isSignal": true;
    };
    "offset": {
      "alias": "offset";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on GaugeTooltipComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type GaugeTooltipMethodNames = 'renderGauge';
/**
 * Declares the methods interface for GaugeTooltipComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type GaugeTooltipComponentMethods = MethodMap<GaugeTooltipMethodNames>;
/**
 * @public
 */
export declare function provideGaugeTooltipComponent(config?: Partial<GaugeTooltipElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the GaugeTrackComponent.
 * Use this token to provide default properties for the GaugeTrackComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const GAUGE_TRACK_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation/components/gauge").IGaugeTrackElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class GaugeTrackComponent {
  /**
   * Signal input for the `width` property.
   *
   * @public
   */
  readonly width: InputSignal<GaugeTrackElement['width'] | undefined>;
  /**
   * Signal input for the `cap` property.
   *
   * @public
   */
  readonly cap: InputSignal<GaugeTrackElement['cap'] | undefined>;
  /**
   * Signal input for the `color` property.
   *
   * @public
   */
  readonly color: InputSignal<GaugeTrackElement['color'] | undefined>;
  /**
   * Signal input for the `opacity` property.
   *
   * @public
   */
  readonly opacity: InputSignal<GaugeTrackElement['opacity'] | undefined>;
  /**
   * Signal input for the `offset` property.
   *
   * @public
   */
  readonly offset: InputSignal<GaugeTrackElement['offset'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<GaugeTrackElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<GaugeTrackElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<GaugeTrackElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<GaugeTrackElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<GaugeTrackElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<GaugeTrackElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Draws this part in the owning gauge's animated context.
   *
   * @public
   */
  renderGauge(...args: Parameters<GaugeTrackElement['renderGauge']>): ReturnType<GaugeTrackElement['renderGauge']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `renderGauge()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends GaugeTrackMethodNames>(method: TMethod, ...args: Parameters<GaugeTrackComponentMethods[TMethod]>): ReturnType<GaugeTrackComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof GaugeTrackElement>(property: TProperty, value: GaugeTrackElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<GaugeTrackElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<GaugeTrackComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<GaugeTrackComponent, "mosaik-gauge-track", never, {
    "width": {
      "alias": "width";
      "required": false;
      "isSignal": true;
    };
    "cap": {
      "alias": "cap";
      "required": false;
      "isSignal": true;
    };
    "color": {
      "alias": "color";
      "required": false;
      "isSignal": true;
    };
    "opacity": {
      "alias": "opacity";
      "required": false;
      "isSignal": true;
    };
    "offset": {
      "alias": "offset";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on GaugeTrackComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type GaugeTrackMethodNames = 'renderGauge';
/**
 * Declares the methods interface for GaugeTrackComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type GaugeTrackComponentMethods = MethodMap<GaugeTrackMethodNames>;
/**
 * @public
 */
export declare function provideGaugeTrackComponent(config?: Partial<GaugeTrackElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the GaugeValueComponent.
 * Use this token to provide default properties for the GaugeValueComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const GAUGE_VALUE_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation/components/gauge").IGaugeValueElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class GaugeValueComponent {
  /**
   * Signal input for the `x` property.
   *
   * @public
   */
  readonly x: InputSignal<GaugeValueElement['x'] | undefined>;
  /**
   * Signal input for the `y` property.
   *
   * @public
   */
  readonly y: InputSignal<GaugeValueElement['y'] | undefined>;
  /**
   * Signal input for the `fontSize` property.
   *
   * @public
   */
  readonly fontSize: InputSignal<GaugeValueElement['fontSize'] | undefined>;
  /**
   * Signal input for the `font` property.
   *
   * @public
   */
  readonly font: InputSignal<GaugeValueElement['font'] | undefined>;
  /**
   * Signal input for the `weight` property.
   *
   * @public
   */
  readonly weight: InputSignal<GaugeValueElement['weight'] | undefined>;
  /**
   * Signal input for the `anchor` property.
   *
   * @public
   */
  readonly anchor: InputSignal<GaugeValueElement['anchor'] | undefined>;
  /**
   * Signal input for the `decimals` property.
   *
   * @public
   */
  readonly decimals: InputSignal<GaugeValueElement['decimals'] | undefined>;
  /**
   * Signal input for the `format` property.
   *
   * @public
   */
  readonly format: InputSignal<GaugeValueElement['format'] | undefined>;
  /**
   * Signal input for the `unit` property.
   *
   * @public
   */
  readonly unit: InputSignal<GaugeValueElement['unit'] | undefined>;
  /**
   * Signal input for the `formatter` property.
   *
   * @public
   */
  readonly formatter: InputSignal<GaugeValueElement['formatter'] | undefined>;
  /**
   * Signal input for the `color` property.
   *
   * @public
   */
  readonly color: InputSignal<GaugeValueElement['color'] | undefined>;
  /**
   * Signal input for the `opacity` property.
   *
   * @public
   */
  readonly opacity: InputSignal<GaugeValueElement['opacity'] | undefined>;
  /**
   * Signal input for the `offset` property.
   *
   * @public
   */
  readonly offset: InputSignal<GaugeValueElement['offset'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<GaugeValueElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<GaugeValueElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<GaugeValueElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<GaugeValueElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<GaugeValueElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<GaugeValueElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Draws this part in the owning gauge's animated context.
   *
   * @public
   */
  renderGauge(...args: Parameters<GaugeValueElement['renderGauge']>): ReturnType<GaugeValueElement['renderGauge']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `renderGauge()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends GaugeValueMethodNames>(method: TMethod, ...args: Parameters<GaugeValueComponentMethods[TMethod]>): ReturnType<GaugeValueComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof GaugeValueElement>(property: TProperty, value: GaugeValueElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<GaugeValueElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<GaugeValueComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<GaugeValueComponent, "mosaik-gauge-value", never, {
    "x": {
      "alias": "x";
      "required": false;
      "isSignal": true;
    };
    "y": {
      "alias": "y";
      "required": false;
      "isSignal": true;
    };
    "fontSize": {
      "alias": "fontSize";
      "required": false;
      "isSignal": true;
    };
    "font": {
      "alias": "font";
      "required": false;
      "isSignal": true;
    };
    "weight": {
      "alias": "weight";
      "required": false;
      "isSignal": true;
    };
    "anchor": {
      "alias": "anchor";
      "required": false;
      "isSignal": true;
    };
    "decimals": {
      "alias": "decimals";
      "required": false;
      "isSignal": true;
    };
    "format": {
      "alias": "format";
      "required": false;
      "isSignal": true;
    };
    "unit": {
      "alias": "unit";
      "required": false;
      "isSignal": true;
    };
    "formatter": {
      "alias": "formatter";
      "required": false;
      "isSignal": true;
    };
    "color": {
      "alias": "color";
      "required": false;
      "isSignal": true;
    };
    "opacity": {
      "alias": "opacity";
      "required": false;
      "isSignal": true;
    };
    "offset": {
      "alias": "offset";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on GaugeValueComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type GaugeValueMethodNames = 'renderGauge';
/**
 * Declares the methods interface for GaugeValueComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type GaugeValueComponentMethods = MethodMap<GaugeValueMethodNames>;
/**
 * @public
 */
export declare function provideGaugeValueComponent(config?: Partial<GaugeValueElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the GaugeZonesComponent.
 * Use this token to provide default properties for the GaugeZonesComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const GAUGE_ZONES_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation/components/gauge").IGaugeZonesElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class GaugeZonesComponent {
  /**
   * Signal input for the `width` property.
   *
   * @public
   */
  readonly width: InputSignal<GaugeZonesElement['width'] | undefined>;
  /**
   * Signal input for the `cap` property.
   *
   * @public
   */
  readonly cap: InputSignal<GaugeZonesElement['cap'] | undefined>;
  /**
   * Signal input for the `endCap` property.
   *
   * @public
   */
  readonly endCap: InputSignal<GaugeZonesElement['endCap'] | undefined>;
  /**
   * Signal input for the `gap` property.
   *
   * @public
   */
  readonly gap: InputSignal<GaugeZonesElement['gap'] | undefined>;
  /**
   * Signal input for the `zones` property.
   *
   * @public
   */
  readonly zones: InputSignal<GaugeZonesElement['zones'] | undefined>;
  /**
   * Signal input for the `color` property.
   *
   * @public
   */
  readonly color: InputSignal<GaugeZonesElement['color'] | undefined>;
  /**
   * Signal input for the `opacity` property.
   *
   * @public
   */
  readonly opacity: InputSignal<GaugeZonesElement['opacity'] | undefined>;
  /**
   * Signal input for the `offset` property.
   *
   * @public
   */
  readonly offset: InputSignal<GaugeZonesElement['offset'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<GaugeZonesElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<GaugeZonesElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<GaugeZonesElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<GaugeZonesElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<GaugeZonesElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<GaugeZonesElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Draws this part in the owning gauge's animated context.
   *
   * @public
   */
  renderGauge(...args: Parameters<GaugeZonesElement['renderGauge']>): ReturnType<GaugeZonesElement['renderGauge']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `renderGauge()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends GaugeZonesMethodNames>(method: TMethod, ...args: Parameters<GaugeZonesComponentMethods[TMethod]>): ReturnType<GaugeZonesComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof GaugeZonesElement>(property: TProperty, value: GaugeZonesElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<GaugeZonesElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<GaugeZonesComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<GaugeZonesComponent, "mosaik-gauge-zones", never, {
    "width": {
      "alias": "width";
      "required": false;
      "isSignal": true;
    };
    "cap": {
      "alias": "cap";
      "required": false;
      "isSignal": true;
    };
    "endCap": {
      "alias": "endCap";
      "required": false;
      "isSignal": true;
    };
    "gap": {
      "alias": "gap";
      "required": false;
      "isSignal": true;
    };
    "zones": {
      "alias": "zones";
      "required": false;
      "isSignal": true;
    };
    "color": {
      "alias": "color";
      "required": false;
      "isSignal": true;
    };
    "opacity": {
      "alias": "opacity";
      "required": false;
      "isSignal": true;
    };
    "offset": {
      "alias": "offset";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on GaugeZonesComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type GaugeZonesMethodNames = 'renderGauge';
/**
 * Declares the methods interface for GaugeZonesComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type GaugeZonesComponentMethods = MethodMap<GaugeZonesMethodNames>;
/**
 * @public
 */
export declare function provideGaugeZonesComponent(config?: Partial<GaugeZonesElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the GaugeComponent.
 * Use this token to provide default properties for the GaugeComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const GAUGE_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation/components/gauge").IGaugeElementProps>>;
/**
 * @public
 *
 * @slot  - Declarative gauge parts, retained under their original framework render parent.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class GaugeComponent {
  /**
   * Signal input for the `padding` property.
   *
   * @public
   */
  readonly padding: InputSignal<GaugeElement['padding'] | undefined>;
  /**
   * Signal input for the `fit` property.
   *
   * @public
   */
  readonly fit: InputSignal<GaugeElement['fit'] | undefined>;
  /**
   * Signal input for the `transition` property.
   *
   * @public
   */
  readonly transition: InputSignal<GaugeElement['transition'] | undefined>;
  /**
   * Signal input for the `startAngle` property.
   *
   * @public
   */
  readonly startAngle: InputSignal<GaugeElement['startAngle'] | undefined>;
  /**
   * Signal input for the `endAngle` property.
   *
   * @public
   */
  readonly endAngle: InputSignal<GaugeElement['endAngle'] | undefined>;
  /**
   * Signal input for the `radius` property.
   *
   * @public
   */
  readonly radius: InputSignal<GaugeElement['radius'] | undefined>;
  /**
   * Signal input for the `rotate` property.
   *
   * @public
   */
  readonly rotate: InputSignal<GaugeElement['rotate'] | undefined>;
  /**
   * Signal input for the `wrap` property.
   *
   * @public
   */
  readonly wrap: InputSignal<GaugeElement['wrap'] | undefined>;
  /**
   * Signal input for the `initialValue` property.
   *
   * @public
   */
  readonly initialValue: InputSignal<GaugeElement['initialValue'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<GaugeElement['themeName'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<GaugeElement['label'] | undefined>;
  /**
   * Signal input for the `min` property.
   *
   * @public
   */
  readonly min: InputSignal<GaugeElement['min'] | undefined>;
  /**
   * Signal input for the `max` property.
   *
   * @public
   */
  readonly max: InputSignal<GaugeElement['max'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<GaugeElement['value'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<GaugeElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<GaugeElement['lang'] | undefined>;
  /**
   * Output signal for the `rangeValueChanged` event.
   *
   * @public
   */
  readonly rangeValueChanged: OutputEmitterRef<ElementEventDetail<GaugeElement, 'rangeValueChanged'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<GaugeElement, 'changed'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<GaugeElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<GaugeElement, 'disconnected'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Draws a dial in a parent context.
   *
   * @public
   */
  renderGauge(...args: Parameters<GaugeElement['renderGauge']>): ReturnType<GaugeElement['renderGauge']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `renderGauge()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends GaugeMethodNames>(method: TMethod, ...args: Parameters<GaugeComponentMethods[TMethod]>): ReturnType<GaugeComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof GaugeElement>(property: TProperty, value: GaugeElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<GaugeElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<GaugeComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<GaugeComponent, "mosaik-gauge", never, {
    "padding": {
      "alias": "padding";
      "required": false;
      "isSignal": true;
    };
    "fit": {
      "alias": "fit";
      "required": false;
      "isSignal": true;
    };
    "transition": {
      "alias": "transition";
      "required": false;
      "isSignal": true;
    };
    "startAngle": {
      "alias": "startAngle";
      "required": false;
      "isSignal": true;
    };
    "endAngle": {
      "alias": "endAngle";
      "required": false;
      "isSignal": true;
    };
    "radius": {
      "alias": "radius";
      "required": false;
      "isSignal": true;
    };
    "rotate": {
      "alias": "rotate";
      "required": false;
      "isSignal": true;
    };
    "wrap": {
      "alias": "wrap";
      "required": false;
      "isSignal": true;
    };
    "initialValue": {
      "alias": "initialValue";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "min": {
      "alias": "min";
      "required": false;
      "isSignal": true;
    };
    "max": {
      "alias": "max";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "rangeValueChanged": "rangeValueChanged";
    "changed": "changed";
    "connected": "connected";
    "disconnected": "disconnected";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on GaugeComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type GaugeMethodNames = 'renderGauge';
/**
 * Declares the methods interface for GaugeComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type GaugeComponentMethods = MethodMap<GaugeMethodNames>;
/**
 * @public
 */
export declare function provideGaugeComponent(config?: Partial<GaugeElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-gauge.d.ts.map