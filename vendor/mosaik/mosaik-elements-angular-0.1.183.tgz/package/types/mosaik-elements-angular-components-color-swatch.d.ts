import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { ColorSwatchGroupElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/color-swatch/ColorSwatchGroupElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { ColorSwatchElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/color-swatch/ColorSwatchElement";
/**
 * @public
 *
 * Injection token for the default properties of the ColorSwatchGroupComponent.
 * Use this token to provide default properties for the ColorSwatchGroupComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const COLOR_SWATCH_GROUP_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/media/color-swatch/IColorSwatchGroupElementProps").IColorSwatchGroupElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ColorSwatchGroupComponent {
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ColorSwatchGroupElement['themeName'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<ColorSwatchGroupElement['disabled'] | undefined>;
  /**
   * Signal input for the `size` property.
   *
   * @public
   */
  readonly size: InputSignal<ColorSwatchGroupElement['size'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<ColorSwatchGroupElement['variant'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<ColorSwatchGroupElement['appearance'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ColorSwatchGroupElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ColorSwatchGroupElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ColorSwatchGroupElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ColorSwatchGroupElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ColorSwatchGroupElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ColorSwatchGroupElement>(property: TProperty, value: ColorSwatchGroupElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ColorSwatchGroupElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ColorSwatchGroupComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ColorSwatchGroupComponent, "mosaik-color-swatch-group", never, {
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on ColorSwatchGroupComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ColorSwatchGroupMethodNames = never;
/**
 * Declares the methods interface for ColorSwatchGroupComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ColorSwatchGroupComponentMethods = MethodMap<ColorSwatchGroupMethodNames>;
/**
 * @public
 */
export declare function provideColorSwatchGroupComponent(config?: Partial<ColorSwatchGroupElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the ColorSwatchComponent.
 * Use this token to provide default properties for the ColorSwatchComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const COLOR_SWATCH_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/media/color-swatch/IColorSwatchElementProps").IColorSwatchElementProps>>;
/**
 * @public
 *
 * @slot checkmark - The checkmark slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ColorSwatchComponent {
  /**
   * Signal input for the `name` property.
   *
   * @public
   */
  readonly name: InputSignal<ColorSwatchElement['name'] | undefined>;
  /**
   * Signal input for the `hasBackground` property.
   *
   * @public
   */
  readonly hasBackground: InputSignal<ColorSwatchElement['hasBackground'] | undefined>;
  /**
   * Signal input for the `readonly` property.
   *
   * @public
   */
  readonly readonly: InputSignal<ColorSwatchElement['readonly'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ColorSwatchElement['themeName'] | undefined>;
  /**
   * Signal input for the `isChecked` property.
   *
   * @public
   */
  readonly isChecked: InputSignal<ColorSwatchElement['isChecked'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<ColorSwatchElement['disabled'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<ColorSwatchElement['variant'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<ColorSwatchElement['appearance'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<ColorSwatchElement['value'] | undefined>;
  /**
   * Signal input for the `size` property.
   *
   * @public
   */
  readonly size: InputSignal<ColorSwatchElement['size'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ColorSwatchElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ColorSwatchElement['lang'] | undefined>;
  /**
   * Output signal for the `toggled` event.
   *
   * @public
   */
  readonly toggled: OutputEmitterRef<ElementEventDetail<ColorSwatchElement, 'toggled'>>;
  /**
   * Output signal for the `checked` event.
   *
   * @public
   */
  readonly checked: OutputEmitterRef<ElementEventDetail<ColorSwatchElement, 'checked'>>;
  /**
   * Output signal for the `unchecked` event.
   *
   * @public
   */
  readonly unchecked: OutputEmitterRef<ElementEventDetail<ColorSwatchElement, 'unchecked'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ColorSwatchElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ColorSwatchElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ColorSwatchElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Checks the element.
   *
   * @public
   */
  check(...args: Parameters<ColorSwatchElement['check']>): ReturnType<ColorSwatchElement['check']>;
  /**
   * Unchecks the element.
   *
   * @public
   */
  uncheck(...args: Parameters<ColorSwatchElement['uncheck']>): ReturnType<ColorSwatchElement['uncheck']>;
  /**
   * Calls `toggle` on the `mosaik-color-swatch` element.
   *
   * @public
   */
  toggle(...args: Parameters<ColorSwatchElement['toggle']>): ReturnType<ColorSwatchElement['toggle']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `check()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends ColorSwatchMethodNames>(method: TMethod, ...args: Parameters<ColorSwatchComponentMethods[TMethod]>): ReturnType<ColorSwatchComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ColorSwatchElement>(property: TProperty, value: ColorSwatchElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ColorSwatchElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ColorSwatchComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ColorSwatchComponent, "mosaik-color-swatch", never, {
    "name": {
      "alias": "name";
      "required": false;
      "isSignal": true;
    };
    "hasBackground": {
      "alias": "hasBackground";
      "required": false;
      "isSignal": true;
    };
    "readonly": {
      "alias": "readonly";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "isChecked": {
      "alias": "isChecked";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "toggled": "toggled";
    "checked": "checked";
    "unchecked": "unchecked";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on ColorSwatchComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ColorSwatchMethodNames = 'check' | 'uncheck' | 'toggle';
/**
 * Declares the methods interface for ColorSwatchComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ColorSwatchComponentMethods = MethodMap<ColorSwatchMethodNames>;
/**
 * @public
 */
export declare function provideColorSwatchComponent(config?: Partial<ColorSwatchElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-color-swatch.d.ts.map