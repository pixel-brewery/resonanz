import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { AnchorElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/buttons/anchor/AnchorElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the AnchorComponent.
 * Use this token to provide default properties for the AnchorComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const ANCHOR_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/buttons/anchor/IAnchorElementProps").IAnchorElementProps>>;
/**
 * @public
 *
 * @slot label - The text content or elements to display as the link text
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class AnchorComponent {
  /**
   * Signal input for the `underline` property.
   *
   * @public
   */
  readonly underline: InputSignal<AnchorElement['underline'] | undefined>;
  /**
   * Signal input for the `download` property.
   *
   * @public
   */
  readonly download: InputSignal<AnchorElement['download'] | undefined>;
  /**
   * Signal input for the `href` property.
   *
   * @public
   */
  readonly href: InputSignal<AnchorElement['href'] | undefined>;
  /**
   * Signal input for the `rel` property.
   *
   * @public
   */
  readonly rel: InputSignal<AnchorElement['rel'] | undefined>;
  /**
   * Signal input for the `target` property.
   *
   * @public
   */
  readonly target: InputSignal<AnchorElement['target'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<AnchorElement['themeName'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<AnchorElement['variant'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<AnchorElement['disabled'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<AnchorElement['label'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<AnchorElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<AnchorElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<AnchorElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<AnchorElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<AnchorElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof AnchorElement>(property: TProperty, value: AnchorElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<AnchorElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<AnchorComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AnchorComponent, "mosaik-anchor", never, {
    "underline": {
      "alias": "underline";
      "required": false;
      "isSignal": true;
    };
    "download": {
      "alias": "download";
      "required": false;
      "isSignal": true;
    };
    "href": {
      "alias": "href";
      "required": false;
      "isSignal": true;
    };
    "rel": {
      "alias": "rel";
      "required": false;
      "isSignal": true;
    };
    "target": {
      "alias": "target";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on AnchorComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type AnchorMethodNames = never;
/**
 * Declares the methods interface for AnchorComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type AnchorComponentMethods = MethodMap<AnchorMethodNames>;
/**
 * @public
 */
export declare function provideAnchorComponent(config?: Partial<AnchorElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-anchor.d.ts.map