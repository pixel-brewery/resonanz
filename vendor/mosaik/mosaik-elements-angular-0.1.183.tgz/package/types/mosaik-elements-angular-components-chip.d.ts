import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { ControlValueAccessor } from "@angular/forms";
import { ChipGroupElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/chip/ChipGroupElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import * as i1 from "@pixel-brewery/mosaik-elements-angular/runtime";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { ChipElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/chip/ChipElement";
/**
 * @public
 *
 * Injection token for the default properties of the ChipGroupComponent.
 * Use this token to provide default properties for the ChipGroupComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const CHIP_GROUP_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/media/chip/IChipGroupElementProps").IChipGroupElementProps>>;
/**
 * @public
 *
 * @slot  - Default slot for chip elements.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ChipGroupComponent implements ControlValueAccessor {
  /**
   * Signal input for the `name` property.
   *
   * @public
   */
  readonly name: InputSignal<ChipGroupElement['name'] | undefined>;
  /**
   * Signal input for the `required` property.
   *
   * @public
   */
  readonly required: InputSignal<ChipGroupElement['required'] | undefined>;
  /**
   * Signal input for the `selectionMode` property.
   *
   * @public
   */
  readonly selectionMode: InputSignal<ChipGroupElement['selectionMode'] | undefined>;
  /**
   * Signal input for the `wrap` property.
   *
   * @public
   */
  readonly wrap: InputSignal<ChipGroupElement['wrap'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ChipGroupElement['themeName'] | undefined>;
  /**
   * Signal input for the `size` property.
   *
   * @public
   */
  readonly size: InputSignal<ChipGroupElement['size'] | undefined>;
  /**
   * Signal input for the `invalid` property.
   *
   * @public
   */
  readonly invalid: InputSignal<ChipGroupElement['invalid'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<ChipGroupElement['disabled'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<ChipGroupElement['value'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<ChipGroupElement['appearance'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<ChipGroupElement['variant'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ChipGroupElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ChipGroupElement['lang'] | undefined>;
  /**
   * Output signal for the `chipChanged` event.
   *
   * @public
   */
  readonly chipChanged: OutputEmitterRef<ElementEventDetail<ChipGroupElement, 'chipChanged'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ChipGroupElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ChipGroupElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ChipGroupElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: ChipGroupElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: ChipGroupElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  private readonly _accessor;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Applies a value supplied by Angular forms to the native control.
   *
   * @public
   */
  writeValue(obj: unknown): void;
  /**
   * Registers the callback notified when the native control value changes.
   *
   * @public
   */
  registerOnChange(fn: unknown): void;
  /**
   * Registers the callback notified when the native control is touched.
   *
   * @public
   */
  registerOnTouched(fn: unknown): void;
  /**
   * Applies the disabled state supplied by Angular forms.
   *
   * @public
   */
  setDisabledState?(isDisabled: boolean): void;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<ChipGroupElement['onSlotChanges']>): ReturnType<ChipGroupElement['onSlotChanges']>;
  /**
   * Returns whether a form will validate when it is submitted, without having to submit it.
   *
   * @public
   */
  checkValidity(...args: Parameters<ChipGroupElement['checkValidity']>): ReturnType<ChipGroupElement['checkValidity']>;
  /**
   * Resets the element to its initial state.
   *
   * @public
   */
  reset(...args: Parameters<ChipGroupElement['reset']>): ReturnType<ChipGroupElement['reset']>;
  /**
   * Selects all chips in the group (only works in multiple selection mode).
   *
   * @public
   */
  selectAll(...args: Parameters<ChipGroupElement['selectAll']>): ReturnType<ChipGroupElement['selectAll']>;
  /**
   * Deselects all chips in the group.
   *
   * @public
   */
  deselectAll(...args: Parameters<ChipGroupElement['deselectAll']>): ReturnType<ChipGroupElement['deselectAll']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<ChipGroupElement['assignToSlot']>): ReturnType<ChipGroupElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<ChipGroupElement['getSlotContent']>): ReturnType<ChipGroupElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<ChipGroupElement['hasSlotContent']>): ReturnType<ChipGroupElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<ChipGroupElement['hasSlot']>): ReturnType<ChipGroupElement['hasSlot']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `onSlotChanges()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends ChipGroupMethodNames>(method: TMethod, ...args: Parameters<ChipGroupComponentMethods[TMethod]>): ReturnType<ChipGroupComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ChipGroupElement>(property: TProperty, value: ChipGroupElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ChipGroupElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ChipGroupComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ChipGroupComponent, "mosaik-chip-group", never, {
    "name": {
      "alias": "name";
      "required": false;
      "isSignal": true;
    };
    "required": {
      "alias": "required";
      "required": false;
      "isSignal": true;
    };
    "selectionMode": {
      "alias": "selectionMode";
      "required": false;
      "isSignal": true;
    };
    "wrap": {
      "alias": "wrap";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "invalid": {
      "alias": "invalid";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "chipChanged": "chipChanged";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, [{
    directive: typeof i1.FormStatusHostDirective;
    inputs: {};
    outputs: {};
  }, {
    directive: typeof i1.FormFieldStatusHostDirective;
    inputs: {};
    outputs: {};
  }]>;
}
/**
 * Declares the methods available on ChipGroupComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ChipGroupMethodNames = 'onSlotChanges' | 'checkValidity' | 'reset' | 'selectAll' | 'deselectAll' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot';
/**
 * Declares the methods interface for ChipGroupComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ChipGroupComponentMethods = MethodMap<ChipGroupMethodNames>;
/**
 * @public
 */
export declare function provideChipGroupComponent(config?: Partial<ChipGroupElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the ChipComponent.
 * Use this token to provide default properties for the ChipComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const CHIP_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/media/chip/IChipElementProps").IChipElementProps>>;
/**
 * @public
 *
 * @slot checkmark - The checkmark slot.
 * @slot close - The close button slot.
 * @slot icon - The icon slot.
 * @slot label - The label slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ChipComponent {
  /**
   * Signal input for the `icon` property.
   *
   * @public
   */
  readonly icon: InputSignal<ChipElement['icon'] | undefined>;
  /**
   * Signal input for the `isCheckable` property.
   *
   * @public
   */
  readonly isCheckable: InputSignal<ChipElement['isCheckable'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ChipElement['themeName'] | undefined>;
  /**
   * Signal input for the `ripple` property.
   *
   * @public
   */
  readonly ripple: InputSignal<ChipElement['ripple'] | undefined>;
  /**
   * Signal input for the `closeable` property.
   *
   * @public
   */
  readonly closeable: InputSignal<ChipElement['closeable'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<ChipElement['variant'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<ChipElement['appearance'] | undefined>;
  /**
   * Signal input for the `isChecked` property.
   *
   * @public
   */
  readonly isChecked: InputSignal<ChipElement['isChecked'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<ChipElement['disabled'] | undefined>;
  /**
   * Signal input for the `size` property.
   *
   * @public
   */
  readonly size: InputSignal<ChipElement['size'] | undefined>;
  /**
   * Signal input for the `isFocused` property.
   *
   * @public
   */
  readonly isFocused: InputSignal<ChipElement['isFocused'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<ChipElement['label'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<ChipElement['value'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ChipElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ChipElement['lang'] | undefined>;
  /**
   * Output signal for the `toggled` event.
   *
   * @public
   */
  readonly toggled: OutputEmitterRef<ElementEventDetail<ChipElement, 'toggled'>>;
  /**
   * Output signal for the `checked` event.
   *
   * @public
   */
  readonly checked: OutputEmitterRef<ElementEventDetail<ChipElement, 'checked'>>;
  /**
   * Output signal for the `unchecked` event.
   *
   * @public
   */
  readonly unchecked: OutputEmitterRef<ElementEventDetail<ChipElement, 'unchecked'>>;
  /**
   * Output signal for the `closed` event.
   *
   * @public
   */
  readonly closed: OutputEmitterRef<ElementEventDetail<ChipElement, 'closed'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ChipElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ChipElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ChipElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: ChipElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: ChipElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Checks the element.
   *
   * @public
   */
  check(...args: Parameters<ChipElement['check']>): ReturnType<ChipElement['check']>;
  /**
   * Unchecks the element.
   *
   * @public
   */
  uncheck(...args: Parameters<ChipElement['uncheck']>): ReturnType<ChipElement['uncheck']>;
  /**
   * Calls `toggle` on the `mosaik-chip` element.
   *
   * @public
   */
  toggle(...args: Parameters<ChipElement['toggle']>): ReturnType<ChipElement['toggle']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<ChipElement['assignToSlot']>): ReturnType<ChipElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<ChipElement['getSlotContent']>): ReturnType<ChipElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<ChipElement['hasSlotContent']>): ReturnType<ChipElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<ChipElement['hasSlot']>): ReturnType<ChipElement['hasSlot']>;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<ChipElement['onSlotChanges']>): ReturnType<ChipElement['onSlotChanges']>;
  /**
   * Removes the element from the DOM.
   *
   * @public
   */
  close(...args: Parameters<ChipElement['close']>): ReturnType<ChipElement['close']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `check()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends ChipMethodNames>(method: TMethod, ...args: Parameters<ChipComponentMethods[TMethod]>): ReturnType<ChipComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ChipElement>(property: TProperty, value: ChipElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ChipElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ChipComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ChipComponent, "mosaik-chip", never, {
    "icon": {
      "alias": "icon";
      "required": false;
      "isSignal": true;
    };
    "isCheckable": {
      "alias": "isCheckable";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "ripple": {
      "alias": "ripple";
      "required": false;
      "isSignal": true;
    };
    "closeable": {
      "alias": "closeable";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "isChecked": {
      "alias": "isChecked";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "isFocused": {
      "alias": "isFocused";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "toggled": "toggled";
    "checked": "checked";
    "unchecked": "unchecked";
    "closed": "closed";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on ChipComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ChipMethodNames = 'check' | 'uncheck' | 'toggle' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges' | 'close';
/**
 * Declares the methods interface for ChipComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ChipComponentMethods = MethodMap<ChipMethodNames>;
/**
 * @public
 */
export declare function provideChipComponent(config?: Partial<ChipElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-chip.d.ts.map