import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { WalletCardElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/wallet-card/WalletCardElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the WalletCardComponent.
 * Use this token to provide default properties for the WalletCardComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const WALLET_CARD_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").IWalletCardElementProps>>;
/**
 * @public
 *
 * @slot  - A complete custom face replacing the standard composition, including its optional stripe.
 * @slot background - Decorative artwork behind the face; excluded from the accessibility tree.
 * @slot code - An application-supplied QR code or barcode beside the standard content and fields, preserving its intrinsic size.
 * @slot details - Supplementary content such as a balance, benefits or travel route.
 * @slot footer - Supplementary content after the standard fields.
 * @slot header-end - Application-supplied content at the end of the heading, such as status and category labels.
 * @slot identifier - Custom identifier content replacing the identifier text.
 * @slot logo - The issuer logo in the standard header.
 * @slot portrait - A portrait or other media beside the standard content.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class WalletCardComponent {
  /**
   * Signal input for the `issuer` property.
   *
   * @public
   */
  readonly issuer: InputSignal<WalletCardElement['issuer'] | undefined>;
  /**
   * Signal input for the `title` property.
   *
   * @public
   */
  readonly title: InputSignal<WalletCardElement['title'] | undefined>;
  /**
   * Signal input for the `subtitle` property.
   *
   * @public
   */
  readonly subtitle: InputSignal<WalletCardElement['subtitle'] | undefined>;
  /**
   * Signal input for the `holder` property.
   *
   * @public
   */
  readonly holder: InputSignal<WalletCardElement['holder'] | undefined>;
  /**
   * Signal input for the `holderLabel` property.
   *
   * @public
   */
  readonly holderLabel: InputSignal<WalletCardElement['holderLabel'] | undefined>;
  /**
   * Signal input for the `identifier` property.
   *
   * @public
   */
  readonly identifier: InputSignal<WalletCardElement['identifier'] | undefined>;
  /**
   * Signal input for the `identifierLabel` property.
   *
   * @public
   */
  readonly identifierLabel: InputSignal<WalletCardElement['identifierLabel'] | undefined>;
  /**
   * Signal input for the `validity` property.
   *
   * @public
   */
  readonly validity: InputSignal<WalletCardElement['validity'] | undefined>;
  /**
   * Signal input for the `validityLabel` property.
   *
   * @public
   */
  readonly validityLabel: InputSignal<WalletCardElement['validityLabel'] | undefined>;
  /**
   * Signal input for the `image` property.
   *
   * @public
   */
  readonly image: InputSignal<WalletCardElement['image'] | undefined>;
  /**
   * Signal input for the `layout` property.
   *
   * @public
   */
  readonly layout: InputSignal<WalletCardElement['layout'] | undefined>;
  /**
   * Signal input for the `ratio` property.
   *
   * @public
   */
  readonly ratio: InputSignal<WalletCardElement['ratio'] | undefined>;
  /**
   * Signal input for the `showChip` property.
   *
   * @public
   */
  readonly showChip: InputSignal<WalletCardElement['showChip'] | undefined>;
  /**
   * Signal input for the `showContactless` property.
   *
   * @public
   */
  readonly showContactless: InputSignal<WalletCardElement['showContactless'] | undefined>;
  /**
   * Signal input for the `showMagneticStripe` property.
   *
   * @public
   */
  readonly showMagneticStripe: InputSignal<WalletCardElement['showMagneticStripe'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<WalletCardElement['themeName'] | undefined>;
  /**
   * Signal input for the `orientation` property.
   *
   * @public
   */
  readonly orientation: InputSignal<WalletCardElement['orientation'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<WalletCardElement['label'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<WalletCardElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<WalletCardElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<WalletCardElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<WalletCardElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<WalletCardElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: WalletCardElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: WalletCardElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Keeps optional content areas in sync when consumers replace their slotted content.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<WalletCardElement['onSlotChanges']>): ReturnType<WalletCardElement['onSlotChanges']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   * @param args - The arguments of `assignToSlot`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * - `node` - The nodes to assign to the slot.
   */
  assignToSlot(...args: Parameters<WalletCardElement['assignToSlot']>): ReturnType<WalletCardElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   * This method extracts text content recursively, including from Shadow DOMs
   * and Custom Elements with known text properties (like `mosaik-text`).
   *
   * @public
   * @param args - The arguments of `getSlotContent`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<WalletCardElement['getSlotContent']>): ReturnType<WalletCardElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @param args - The arguments of `hasSlotContent`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<WalletCardElement['hasSlotContent']>): ReturnType<WalletCardElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @param args - The arguments of `hasSlot`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<WalletCardElement['hasSlot']>): ReturnType<WalletCardElement['hasSlot']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `onSlotChanges()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends WalletCardMethodNames>(method: TMethod, ...args: Parameters<WalletCardComponentMethods[TMethod]>): ReturnType<WalletCardComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof WalletCardElement>(property: TProperty, value: WalletCardElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<WalletCardElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<WalletCardComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<WalletCardComponent, "mosaik-wallet-card", never, {
    "issuer": {
      "alias": "issuer";
      "required": false;
      "isSignal": true;
    };
    "title": {
      "alias": "title";
      "required": false;
      "isSignal": true;
    };
    "subtitle": {
      "alias": "subtitle";
      "required": false;
      "isSignal": true;
    };
    "holder": {
      "alias": "holder";
      "required": false;
      "isSignal": true;
    };
    "holderLabel": {
      "alias": "holderLabel";
      "required": false;
      "isSignal": true;
    };
    "identifier": {
      "alias": "identifier";
      "required": false;
      "isSignal": true;
    };
    "identifierLabel": {
      "alias": "identifierLabel";
      "required": false;
      "isSignal": true;
    };
    "validity": {
      "alias": "validity";
      "required": false;
      "isSignal": true;
    };
    "validityLabel": {
      "alias": "validityLabel";
      "required": false;
      "isSignal": true;
    };
    "image": {
      "alias": "image";
      "required": false;
      "isSignal": true;
    };
    "layout": {
      "alias": "layout";
      "required": false;
      "isSignal": true;
    };
    "ratio": {
      "alias": "ratio";
      "required": false;
      "isSignal": true;
    };
    "showChip": {
      "alias": "showChip";
      "required": false;
      "isSignal": true;
    };
    "showContactless": {
      "alias": "showContactless";
      "required": false;
      "isSignal": true;
    };
    "showMagneticStripe": {
      "alias": "showMagneticStripe";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "orientation": {
      "alias": "orientation";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on WalletCardComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type WalletCardMethodNames = 'onSlotChanges' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot';
/**
 * Declares the methods interface for WalletCardComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type WalletCardComponentMethods = MethodMap<WalletCardMethodNames>;
/**
 * @public
 */
export declare function provideWalletCardComponent(config?: Partial<WalletCardElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-wallet-card.d.ts.map