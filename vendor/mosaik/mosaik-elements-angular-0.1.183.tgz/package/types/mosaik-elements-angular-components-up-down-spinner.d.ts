import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef, Type } from "@angular/core";
import { UpDownSpinnerElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/up-down-spinner/UpDownSpinnerElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the UpDownSpinnerComponent.
 * Use this token to provide default properties for the UpDownSpinnerComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const UP_DOWN_SPINNER_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/primitives/up-down-spinner/IUpDownSpinnerElementProps").IUpDownSpinnerElementProps>>;
/**
 * @public
 *
 * Injection token for the intl configuration of the UpDownSpinnerComponent.
 * Provide a partial intl object or an injectable class that resolves translations.
 * This allows third-party applications to override the default intl labels
 * globally, per route, or per component via Angular's dependency injection.
 *
 * Merge order: Foundation defaults → DI intl → [intl] input binding.
 */
export declare const UP_DOWN_SPINNER_INTL: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").UpDownSpinnerElementIntl>>;
/**
 * @public
 *
 * @slot  - Default content slot displayed between the spinner buttons
 * @slot prefix - Content displayed before the default slot
 * @slot suffix - Content displayed after the default slot
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class UpDownSpinnerComponent {
  /**
   * Signal input for the `increaseIcon` property.
   *
   * @public
   */
  readonly increaseIcon: InputSignal<UpDownSpinnerElement['increaseIcon'] | undefined>;
  /**
   * Signal input for the `decreaseIcon` property.
   *
   * @public
   */
  readonly decreaseIcon: InputSignal<UpDownSpinnerElement['decreaseIcon'] | undefined>;
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<Partial<UpDownSpinnerElement['intl']> | undefined>;
  /**
   * Signal input for the `delay` property.
   *
   * @public
   */
  readonly delay: InputSignal<UpDownSpinnerElement['delay'] | undefined>;
  /**
   * Signal input for the `interval` property.
   *
   * @public
   */
  readonly interval: InputSignal<UpDownSpinnerElement['interval'] | undefined>;
  /**
   * Signal input for the `position` property.
   *
   * @public
   */
  readonly position: InputSignal<UpDownSpinnerElement['position'] | undefined>;
  /**
   * Signal input for the `increaseDisabled` property.
   *
   * @public
   */
  readonly increaseDisabled: InputSignal<UpDownSpinnerElement['increaseDisabled'] | undefined>;
  /**
   * Signal input for the `decreaseDisabled` property.
   *
   * @public
   */
  readonly decreaseDisabled: InputSignal<UpDownSpinnerElement['decreaseDisabled'] | undefined>;
  /**
   * Signal input for the `focusable` property.
   *
   * @public
   */
  readonly focusable: InputSignal<UpDownSpinnerElement['focusable'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<UpDownSpinnerElement['themeName'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<UpDownSpinnerElement['variant'] | undefined>;
  /**
   * Signal input for the `size` property.
   *
   * @public
   */
  readonly size: InputSignal<UpDownSpinnerElement['size'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<UpDownSpinnerElement['appearance'] | undefined>;
  /**
   * Signal input for the `orientation` property.
   *
   * @public
   */
  readonly orientation: InputSignal<UpDownSpinnerElement['orientation'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<UpDownSpinnerElement['disabled'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<UpDownSpinnerElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<UpDownSpinnerElement['lang'] | undefined>;
  /**
   * Output signal for the `spinned` event.
   *
   * @public
   */
  readonly spinned: OutputEmitterRef<ElementEventDetail<UpDownSpinnerElement, 'spinned'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<UpDownSpinnerElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<UpDownSpinnerElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<UpDownSpinnerElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof UpDownSpinnerElement>(property: TProperty, value: UpDownSpinnerElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<UpDownSpinnerElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<UpDownSpinnerComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<UpDownSpinnerComponent, "mosaik-updown-spinner", never, {
    "increaseIcon": {
      "alias": "increaseIcon";
      "required": false;
      "isSignal": true;
    };
    "decreaseIcon": {
      "alias": "decreaseIcon";
      "required": false;
      "isSignal": true;
    };
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "delay": {
      "alias": "delay";
      "required": false;
      "isSignal": true;
    };
    "interval": {
      "alias": "interval";
      "required": false;
      "isSignal": true;
    };
    "position": {
      "alias": "position";
      "required": false;
      "isSignal": true;
    };
    "increaseDisabled": {
      "alias": "increaseDisabled";
      "required": false;
      "isSignal": true;
    };
    "decreaseDisabled": {
      "alias": "decreaseDisabled";
      "required": false;
      "isSignal": true;
    };
    "focusable": {
      "alias": "focusable";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "orientation": {
      "alias": "orientation";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "spinned": "spinned";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on UpDownSpinnerComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type UpDownSpinnerMethodNames = never;
/**
 * Declares the methods interface for UpDownSpinnerComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type UpDownSpinnerComponentMethods = MethodMap<UpDownSpinnerMethodNames>;
/**
 * @public
 */
export declare function provideUpDownSpinnerComponent(config?: Partial<UpDownSpinnerElement.Props>, intl?: Partial<UpDownSpinnerElement['intl']> | Type<Partial<UpDownSpinnerElement['intl']>>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-up-down-spinner.d.ts.map