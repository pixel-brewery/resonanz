import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { BannerHeaderElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/grouping/banner/BannerHeaderElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { BannerSubHeaderElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/grouping/banner/BannerSubHeaderElement";
import { BannerElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/grouping/banner/BannerElement";
/**
 * @public
 *
 * Injection token for the default properties of the BannerHeaderComponent.
 * Use this token to provide default properties for the BannerHeaderComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const BANNER_HEADER_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/grouping/banner/IBannerHeaderElementProps").IBannerHeaderElementProps>>;
/**
 * @public
 *
 * @slot  - Slot for the banner header content.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class BannerHeaderComponent {
  /**
   * Signal input for the `text` property.
   *
   * @public
   */
  readonly text: InputSignal<BannerHeaderElement['text'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<BannerHeaderElement['themeName'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<BannerHeaderElement['variant'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<BannerHeaderElement['disabled'] | undefined>;
  /**
   * Signal input for the `formatter` property.
   *
   * @public
   */
  readonly formatter: InputSignal<BannerHeaderElement['formatter'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<BannerHeaderElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<BannerHeaderElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<BannerHeaderElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<BannerHeaderElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<BannerHeaderElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof BannerHeaderElement>(property: TProperty, value: BannerHeaderElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<BannerHeaderElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<BannerHeaderComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<BannerHeaderComponent, "mosaik-banner-header", never, {
    "text": {
      "alias": "text";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "formatter": {
      "alias": "formatter";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on BannerHeaderComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type BannerHeaderMethodNames = never;
/**
 * Declares the methods interface for BannerHeaderComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type BannerHeaderComponentMethods = MethodMap<BannerHeaderMethodNames>;
/**
 * @public
 */
export declare function provideBannerHeaderComponent(config?: Partial<BannerHeaderElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the BannerSubHeaderComponent.
 * Use this token to provide default properties for the BannerSubHeaderComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const BANNER_SUB_HEADER_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/grouping/banner/IBannerSubHeaderElementProps").IBannerSubHeaderElementProps>>;
/**
 * @public
 *
 * @slot  - Slot for the banner sub-header content.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class BannerSubHeaderComponent {
  /**
   * Signal input for the `text` property.
   *
   * @public
   */
  readonly text: InputSignal<BannerSubHeaderElement['text'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<BannerSubHeaderElement['themeName'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<BannerSubHeaderElement['disabled'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<BannerSubHeaderElement['variant'] | undefined>;
  /**
   * Signal input for the `formatter` property.
   *
   * @public
   */
  readonly formatter: InputSignal<BannerSubHeaderElement['formatter'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<BannerSubHeaderElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<BannerSubHeaderElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<BannerSubHeaderElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<BannerSubHeaderElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<BannerSubHeaderElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof BannerSubHeaderElement>(property: TProperty, value: BannerSubHeaderElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<BannerSubHeaderElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<BannerSubHeaderComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<BannerSubHeaderComponent, "mosaik-banner-sub-header", never, {
    "text": {
      "alias": "text";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "formatter": {
      "alias": "formatter";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on BannerSubHeaderComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type BannerSubHeaderMethodNames = never;
/**
 * Declares the methods interface for BannerSubHeaderComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type BannerSubHeaderComponentMethods = MethodMap<BannerSubHeaderMethodNames>;
/**
 * @public
 */
export declare function provideBannerSubHeaderComponent(config?: Partial<BannerSubHeaderElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the BannerComponent.
 * Use this token to provide default properties for the BannerComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const BANNER_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/grouping/banner/IBannerElementProps").IBannerElementProps>>;
/**
 * @public
 *
 * @slot actions - Slot for additional actions inside the banner.
 * @slot icon - Slot for a custom status icon.
 * @slot header - Slot for the banner header content.
 * @slot close - Slot for the close button or icon.
 * @slot subHeader - Slot for the banner subheader content.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class BannerComponent {
  /**
   * Signal input for the `icon` property.
   *
   * @public
   */
  readonly icon: InputSignal<BannerElement['icon'] | undefined>;
  /**
   * Signal input for the `iconSize` property.
   *
   * @public
   */
  readonly iconSize: InputSignal<BannerElement['iconSize'] | undefined>;
  /**
   * Signal input for the `header` property.
   *
   * @public
   */
  readonly header: InputSignal<BannerElement['header'] | undefined>;
  /**
   * Signal input for the `subHeader` property.
   *
   * @public
   */
  readonly subHeader: InputSignal<BannerElement['subHeader'] | undefined>;
  /**
   * Signal input for the `isOpen` property.
   *
   * @public
   */
  readonly isOpen: InputSignal<BannerElement['isOpen'] | undefined>;
  /**
   * Signal input for the `collapsible` property.
   *
   * @public
   */
  readonly collapsible: InputSignal<BannerElement['collapsible'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<BannerElement['themeName'] | undefined>;
  /**
   * Signal input for the `closeable` property.
   *
   * @public
   */
  readonly closeable: InputSignal<BannerElement['closeable'] | undefined>;
  /**
   * Signal input for the `isExpanded` property.
   *
   * @public
   */
  readonly isExpanded: InputSignal<BannerElement['isExpanded'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<BannerElement['disabled'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<BannerElement['variant'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<BannerElement['appearance'] | undefined>;
  /**
   * Signal input for the `fit` property.
   *
   * @public
   */
  readonly fit: InputSignal<BannerElement['fit'] | undefined>;
  /**
   * Signal input for the `elevation` property.
   *
   * @public
   */
  readonly elevation: InputSignal<BannerElement['elevation'] | undefined>;
  /**
   * Signal input for the `orientation` property.
   *
   * @public
   */
  readonly orientation: InputSignal<BannerElement['orientation'] | undefined>;
  /**
   * Signal input for the `horizontalContentAlignment` property.
   *
   * @public
   */
  readonly horizontalContentAlignment: InputSignal<BannerElement['horizontalContentAlignment'] | undefined>;
  /**
   * Signal input for the `verticalContentAlignment` property.
   *
   * @public
   */
  readonly verticalContentAlignment: InputSignal<BannerElement['verticalContentAlignment'] | undefined>;
  /**
   * Signal input for the `formatter` property.
   *
   * @public
   */
  readonly formatter: InputSignal<BannerElement['formatter'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<BannerElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<BannerElement['lang'] | undefined>;
  /**
   * Output signal for the `closed` event.
   *
   * @public
   */
  readonly closed: OutputEmitterRef<ElementEventDetail<BannerElement, 'closed'>>;
  /**
   * Output signal for the `expanded` event.
   *
   * @public
   */
  readonly expanded: OutputEmitterRef<ElementEventDetail<BannerElement, 'expanded'>>;
  /**
   * Output signal for the `collapsed` event.
   *
   * @public
   */
  readonly collapsed: OutputEmitterRef<ElementEventDetail<BannerElement, 'collapsed'>>;
  /**
   * Output signal for the `toggled` event.
   *
   * @public
   */
  readonly toggled: OutputEmitterRef<ElementEventDetail<BannerElement, 'toggled'>>;
  /**
   * Output signal for the `opened` event.
   *
   * @public
   */
  readonly opened: OutputEmitterRef<ElementEventDetail<BannerElement, 'opened'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<BannerElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<BannerElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<BannerElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: BannerElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: BannerElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Opens the `BannerElement`.
   *
   * @public
   */
  open(...args: Parameters<BannerElement['open']>): ReturnType<BannerElement['open']>;
  /**
   * Closes the `BannerElement`.
   *
   * @public
   */
  close(...args: Parameters<BannerElement['close']>): ReturnType<BannerElement['close']>;
  /**
   * Toggles the `BannerElement`.
   * If the `BannerElement` is open, it will close it. If it is closed, it will open it.
   *
   * @public
   */
  toggle(...args: Parameters<BannerElement['toggle']>): ReturnType<BannerElement['toggle']>;
  /**
   * Toggles expansion when `collapsible` is enabled and the banner is not disabled.
   *
   * @public
   */
  toggleExpansion(...args: Parameters<BannerElement['toggleExpansion']>): ReturnType<BannerElement['toggleExpansion']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<BannerElement['assignToSlot']>): ReturnType<BannerElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<BannerElement['getSlotContent']>): ReturnType<BannerElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<BannerElement['hasSlotContent']>): ReturnType<BannerElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<BannerElement['hasSlot']>): ReturnType<BannerElement['hasSlot']>;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<BannerElement['onSlotChanges']>): ReturnType<BannerElement['onSlotChanges']>;
  /**
   * Expands the element.
   *
   * @public
   */
  expand(...args: Parameters<BannerElement['expand']>): ReturnType<BannerElement['expand']>;
  /**
   * Collapses the element.
   *
   * @public
   */
  collapse(...args: Parameters<BannerElement['collapse']>): ReturnType<BannerElement['collapse']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `open()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * The other names it accepts are not public in the type declarations of `BannerElement`.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends BannerMethodNames>(method: TMethod, ...args: Parameters<BannerComponentMethods[TMethod]>): ReturnType<BannerComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof BannerElement>(property: TProperty, value: BannerElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<BannerElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<BannerComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<BannerComponent, "mosaik-banner", never, {
    "icon": {
      "alias": "icon";
      "required": false;
      "isSignal": true;
    };
    "iconSize": {
      "alias": "iconSize";
      "required": false;
      "isSignal": true;
    };
    "header": {
      "alias": "header";
      "required": false;
      "isSignal": true;
    };
    "subHeader": {
      "alias": "subHeader";
      "required": false;
      "isSignal": true;
    };
    "isOpen": {
      "alias": "isOpen";
      "required": false;
      "isSignal": true;
    };
    "collapsible": {
      "alias": "collapsible";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "closeable": {
      "alias": "closeable";
      "required": false;
      "isSignal": true;
    };
    "isExpanded": {
      "alias": "isExpanded";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "fit": {
      "alias": "fit";
      "required": false;
      "isSignal": true;
    };
    "elevation": {
      "alias": "elevation";
      "required": false;
      "isSignal": true;
    };
    "orientation": {
      "alias": "orientation";
      "required": false;
      "isSignal": true;
    };
    "horizontalContentAlignment": {
      "alias": "horizontalContentAlignment";
      "required": false;
      "isSignal": true;
    };
    "verticalContentAlignment": {
      "alias": "verticalContentAlignment";
      "required": false;
      "isSignal": true;
    };
    "formatter": {
      "alias": "formatter";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "closed": "closed";
    "expanded": "expanded";
    "collapsed": "collapsed";
    "toggled": "toggled";
    "opened": "opened";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on BannerComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type BannerMethodNames = 'open' | 'close' | 'toggle' | 'toggleExpansion' | 'onBannerClick' | 'onHeaderKeyDown' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges' | 'expand' | 'collapse';
/**
 * Declares the methods interface for BannerComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type BannerComponentMethods = MethodMap<BannerMethodNames>;
/**
 * @public
 */
export declare function provideBannerComponent(config?: Partial<BannerElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-banner.d.ts.map