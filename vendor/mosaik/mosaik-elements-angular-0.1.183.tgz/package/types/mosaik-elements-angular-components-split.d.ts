import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef, Type } from "@angular/core";
import { SplitElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/split/SplitElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the SplitComponent.
 * Use this token to provide default properties for the SplitComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const SPLIT_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/layouts/split/ISplitElementProps").ISplitElementProps>>;
/**
 * @public
 *
 * Injection token for the intl configuration of the SplitComponent.
 * Provide a partial intl object or an injectable class that resolves translations.
 * This allows third-party applications to override the default intl labels
 * globally, per route, or per component via Angular's dependency injection.
 *
 * Merge order: Foundation defaults → DI intl → [intl] input binding.
 */
export declare const SPLIT_INTL: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").SplitElementIntl>>;
/**
 * @public
 *
 * @slot end - Content of the end panel, exchanged with the start panel when reversed.
 * @slot start - Content of the start panel, exchanged with the end panel when reversed.
 * @slot thumb - Custom grip icon for the draggable divider (defaults to three dots icon)
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class SplitComponent {
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<Partial<SplitElement['intl']> | undefined>;
  /**
   * Signal input for the `position` property.
   *
   * @public
   */
  readonly position: InputSignal<SplitElement['position'] | undefined>;
  /**
   * Signal input for the `lock` property.
   *
   * @public
   */
  readonly lock: InputSignal<SplitElement['lock'] | undefined>;
  /**
   * Signal input for the `snaps` property.
   *
   * @public
   */
  readonly snaps: InputSignal<SplitElement['snaps'] | undefined>;
  /**
   * Signal input for the `snapThreshold` property.
   *
   * @public
   */
  readonly snapThreshold: InputSignal<SplitElement['snapThreshold'] | undefined>;
  /**
   * Signal input for the `thickness` property.
   *
   * @public
   */
  readonly thickness: InputSignal<SplitElement['thickness'] | undefined>;
  /**
   * Signal input for the `min` property.
   *
   * @public
   */
  readonly min: InputSignal<SplitElement['min'] | undefined>;
  /**
   * Signal input for the `max` property.
   *
   * @public
   */
  readonly max: InputSignal<SplitElement['max'] | undefined>;
  /**
   * Signal input for the `collapsible` property.
   *
   * @public
   */
  readonly collapsible: InputSignal<SplitElement['collapsible'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<SplitElement['themeName'] | undefined>;
  /**
   * Signal input for the `reverse` property.
   *
   * @public
   */
  readonly reverse: InputSignal<SplitElement['reverse'] | undefined>;
  /**
   * Signal input for the `orientation` property.
   *
   * @public
   */
  readonly orientation: InputSignal<SplitElement['orientation'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<SplitElement['disabled'] | undefined>;
  /**
   * Signal input for the `fit` property.
   *
   * @public
   */
  readonly fit: InputSignal<SplitElement['fit'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<SplitElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<SplitElement['lang'] | undefined>;
  /**
   * Output signal for the `splitReposition` event.
   *
   * @public
   */
  readonly splitReposition: OutputEmitterRef<ElementEventDetail<SplitElement, 'splitReposition'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<SplitElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<SplitElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<SplitElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: SplitElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: SplitElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<SplitElement['onSlotChanges']>): ReturnType<SplitElement['onSlotChanges']>;
  /**
   * Collapses the specified panel by dragging it beyond 50% of its minimum size constraint.
   * Only works when `collapsible` is enabled.
   *
   * @public
   * @param args - The arguments of `collapse`:
   * - `panel` - The panel to collapse
   */
  collapse(...args: Parameters<SplitElement['collapse']>): ReturnType<SplitElement['collapse']>;
  /**
   * Expands the specified collapsed panel back to its minimum/maximum position.
   * Only works when `collapsible` is enabled.
   *
   * @public
   * @param args - The arguments of `expand`:
   * - `panel` - The panel to expand
   */
  expand(...args: Parameters<SplitElement['expand']>): ReturnType<SplitElement['expand']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<SplitElement['assignToSlot']>): ReturnType<SplitElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<SplitElement['getSlotContent']>): ReturnType<SplitElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<SplitElement['hasSlotContent']>): ReturnType<SplitElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<SplitElement['hasSlot']>): ReturnType<SplitElement['hasSlot']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `onSlotChanges()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends SplitMethodNames>(method: TMethod, ...args: Parameters<SplitComponentMethods[TMethod]>): ReturnType<SplitComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof SplitElement>(property: TProperty, value: SplitElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<SplitElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SplitComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SplitComponent, "mosaik-split", never, {
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "position": {
      "alias": "position";
      "required": false;
      "isSignal": true;
    };
    "lock": {
      "alias": "lock";
      "required": false;
      "isSignal": true;
    };
    "snaps": {
      "alias": "snaps";
      "required": false;
      "isSignal": true;
    };
    "snapThreshold": {
      "alias": "snapThreshold";
      "required": false;
      "isSignal": true;
    };
    "thickness": {
      "alias": "thickness";
      "required": false;
      "isSignal": true;
    };
    "min": {
      "alias": "min";
      "required": false;
      "isSignal": true;
    };
    "max": {
      "alias": "max";
      "required": false;
      "isSignal": true;
    };
    "collapsible": {
      "alias": "collapsible";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "reverse": {
      "alias": "reverse";
      "required": false;
      "isSignal": true;
    };
    "orientation": {
      "alias": "orientation";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "fit": {
      "alias": "fit";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "splitReposition": "splitReposition";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on SplitComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SplitMethodNames = 'onSlotChanges' | 'collapse' | 'expand' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot';
/**
 * Declares the methods interface for SplitComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SplitComponentMethods = MethodMap<SplitMethodNames>;
/**
 * @public
 */
export declare function provideSplitComponent(config?: Partial<SplitElement.Props>, intl?: Partial<SplitElement['intl']> | Type<Partial<SplitElement['intl']>>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-split.d.ts.map