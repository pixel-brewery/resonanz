import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { StackElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/stack/StackElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the StackComponent.
 * Use this token to provide default properties for the StackComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const STACK_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/layouts/stack/IStackElementProps").IStackElementProps>>;
/**
 * @public
 *
 * @slot  - Default content area for child elements to be arranged in stack layout
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class StackComponent {
  /**
   * Signal input for the `wrap` property.
   *
   * @public
   */
  readonly wrap: InputSignal<StackElement['wrap'] | undefined>;
  /**
   * Signal input for the `horizontalAlignment` property.
   *
   * @public
   */
  readonly horizontalAlignment: InputSignal<StackElement['horizontalAlignment'] | undefined>;
  /**
   * Signal input for the `verticalAlignment` property.
   *
   * @public
   */
  readonly verticalAlignment: InputSignal<StackElement['verticalAlignment'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<StackElement['themeName'] | undefined>;
  /**
   * Signal input for the `reverse` property.
   *
   * @public
   */
  readonly reverse: InputSignal<StackElement['reverse'] | undefined>;
  /**
   * Signal input for the `orientation` property.
   *
   * @public
   */
  readonly orientation: InputSignal<StackElement['orientation'] | undefined>;
  /**
   * Signal input for the `fit` property.
   *
   * @public
   */
  readonly fit: InputSignal<StackElement['fit'] | undefined>;
  /**
   * Signal input for the `gap` property.
   *
   * @public
   */
  readonly gap: InputSignal<StackElement['gap'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<StackElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<StackElement['lang'] | undefined>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<StackElement, 'changed'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<StackElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<StackElement, 'disconnected'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof StackElement>(property: TProperty, value: StackElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<StackElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<StackComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<StackComponent, "mosaik-stack", never, {
    "wrap": {
      "alias": "wrap";
      "required": false;
      "isSignal": true;
    };
    "horizontalAlignment": {
      "alias": "horizontalAlignment";
      "required": false;
      "isSignal": true;
    };
    "verticalAlignment": {
      "alias": "verticalAlignment";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "reverse": {
      "alias": "reverse";
      "required": false;
      "isSignal": true;
    };
    "orientation": {
      "alias": "orientation";
      "required": false;
      "isSignal": true;
    };
    "fit": {
      "alias": "fit";
      "required": false;
      "isSignal": true;
    };
    "gap": {
      "alias": "gap";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "changed": "changed";
    "connected": "connected";
    "disconnected": "disconnected";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on StackComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type StackMethodNames = never;
/**
 * Declares the methods interface for StackComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type StackComponentMethods = MethodMap<StackMethodNames>;
/**
 * @public
 */
export declare function provideStackComponent(config?: Partial<StackElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-stack.d.ts.map