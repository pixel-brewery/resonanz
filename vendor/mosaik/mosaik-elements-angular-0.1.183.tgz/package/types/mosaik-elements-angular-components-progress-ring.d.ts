import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { ProgressRingElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/ranges/progress-ring/ProgressRingElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the ProgressRingComponent.
 * Use this token to provide default properties for the ProgressRingComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const PROGRESS_RING_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/ranges/progress-ring/IProgressRingElementProps").IProgressRingElementProps>>;
/**
 * @public
 *
 * @slot hint - Secondary text content area for additional progress information or status
 * @slot label - Text label content area for progress description or percentage display
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ProgressRingComponent {
  /**
   * Signal input for the `thickness` property.
   *
   * @public
   */
  readonly thickness: InputSignal<ProgressRingElement['thickness'] | undefined>;
  /**
   * Signal input for the `radius` property.
   *
   * @public
   */
  readonly radius: InputSignal<ProgressRingElement['radius'] | undefined>;
  /**
   * Signal input for the `isIndeterminate` property.
   *
   * @public
   */
  readonly isIndeterminate: InputSignal<ProgressRingElement['isIndeterminate'] | undefined>;
  /**
   * Signal input for the `labelPosition` property.
   *
   * @public
   */
  readonly labelPosition: InputSignal<ProgressRingElement['labelPosition'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ProgressRingElement['themeName'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<ProgressRingElement['variant'] | undefined>;
  /**
   * Signal input for the `orientation` property.
   *
   * @public
   */
  readonly orientation: InputSignal<ProgressRingElement['orientation'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<ProgressRingElement['disabled'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<ProgressRingElement['label'] | undefined>;
  /**
   * Signal input for the `min` property.
   *
   * @public
   */
  readonly min: InputSignal<ProgressRingElement['min'] | undefined>;
  /**
   * Signal input for the `max` property.
   *
   * @public
   */
  readonly max: InputSignal<ProgressRingElement['max'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<ProgressRingElement['value'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ProgressRingElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ProgressRingElement['lang'] | undefined>;
  /**
   * Output signal for the `rangeValueChanged` event.
   *
   * @public
   */
  readonly rangeValueChanged: OutputEmitterRef<ElementEventDetail<ProgressRingElement, 'rangeValueChanged'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ProgressRingElement, 'changed'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ProgressRingElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ProgressRingElement, 'disconnected'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ProgressRingElement>(property: TProperty, value: ProgressRingElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ProgressRingElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ProgressRingComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ProgressRingComponent, "mosaik-progress-ring", never, {
    "thickness": {
      "alias": "thickness";
      "required": false;
      "isSignal": true;
    };
    "radius": {
      "alias": "radius";
      "required": false;
      "isSignal": true;
    };
    "isIndeterminate": {
      "alias": "isIndeterminate";
      "required": false;
      "isSignal": true;
    };
    "labelPosition": {
      "alias": "labelPosition";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "orientation": {
      "alias": "orientation";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "min": {
      "alias": "min";
      "required": false;
      "isSignal": true;
    };
    "max": {
      "alias": "max";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "rangeValueChanged": "rangeValueChanged";
    "changed": "changed";
    "connected": "connected";
    "disconnected": "disconnected";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on ProgressRingComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ProgressRingMethodNames = never;
/**
 * Declares the methods interface for ProgressRingComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ProgressRingComponentMethods = MethodMap<ProgressRingMethodNames>;
/**
 * @public
 */
export declare function provideProgressRingComponent(config?: Partial<ProgressRingElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-progress-ring.d.ts.map