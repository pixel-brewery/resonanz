import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { DesignerCanvasElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/designer/canvas/DesignerCanvasElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { DesignerConnectorElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/designer/connector/DesignerConnectorElement";
import { DesignerContentElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/designer/content/DesignerContentElement";
import { DesignerFrameElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/designer/frame/DesignerFrameElement";
import { DesignerElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/designer/DesignerElement";
/**
 * @public
 *
 * Injection token for the default properties of the DesignerCanvasComponent.
 * Use this token to provide default properties for the DesignerCanvasComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const DESIGNER_CANVAS_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").IDesignerCanvasElementProps>>;
/**
 * @public
 *
 * @slot  - Default slot for one mosaik-designer-frame (`single`) or the frames and connectors of a board (`free`)
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class DesignerCanvasComponent {
  /**
   * Signal input for the `arrangement` property.
   *
   * @public
   */
  readonly arrangement: InputSignal<DesignerCanvasElement['arrangement'] | undefined>;
  /**
   * Signal input for the `zoom` property.
   *
   * @public
   */
  readonly zoom: InputSignal<DesignerCanvasElement['zoom'] | undefined>;
  /**
   * Signal input for the `minZoom` property.
   *
   * @public
   */
  readonly minZoom: InputSignal<DesignerCanvasElement['minZoom'] | undefined>;
  /**
   * Signal input for the `maxZoom` property.
   *
   * @public
   */
  readonly maxZoom: InputSignal<DesignerCanvasElement['maxZoom'] | undefined>;
  /**
   * Signal input for the `interactionMode` property.
   *
   * @public
   */
  readonly interactionMode: InputSignal<DesignerCanvasElement['interactionMode'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<DesignerCanvasElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<DesignerCanvasElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<DesignerCanvasElement['lang'] | undefined>;
  /**
   * Output signal for the `zoomChanged` event.
   *
   * @public
   */
  readonly zoomChanged: OutputEmitterRef<ElementEventDetail<DesignerCanvasElement, 'zoomChanged'>>;
  /**
   * Output signal for the `viewportChanged` event.
   *
   * @public
   */
  readonly viewportChanged: OutputEmitterRef<ElementEventDetail<DesignerCanvasElement, 'viewportChanged'>>;
  /**
   * Output signal for the `viewportSettled` event.
   *
   * @public
   */
  readonly viewportSettled: OutputEmitterRef<ElementEventDetail<DesignerCanvasElement, 'viewportSettled'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<DesignerCanvasElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<DesignerCanvasElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<DesignerCanvasElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Zooms in by one step around the center of the canvas.
   *
   * @public
   */
  zoomIn(...args: Parameters<DesignerCanvasElement['zoomIn']>): ReturnType<DesignerCanvasElement['zoomIn']>;
  /**
   * Zooms out by one step around the center of the canvas.
   *
   * @public
   */
  zoomOut(...args: Parameters<DesignerCanvasElement['zoomOut']>): ReturnType<DesignerCanvasElement['zoomOut']>;
  /**
   * Sets a specific zoom level around the center of the canvas.
   *
   * @public
   * @param args - The arguments of `setZoom`:
   * - `level` - The zoom level (1 = 100%), limited to `minZoom` and `maxZoom`.
   */
  setZoom(...args: Parameters<DesignerCanvasElement['setZoom']>): ReturnType<DesignerCanvasElement['setZoom']>;
  /**
   * Resets zoom and pan to defaults: 100 %, with the frame centered (`single`) or the world origin at the
   * top left of the canvas (`free`).
   *
   * @public
   */
  resetZoom(...args: Parameters<DesignerCanvasElement['resetZoom']>): ReturnType<DesignerCanvasElement['resetZoom']>;
  /**
   * Fits the frame into the visible canvas area: it measures the frame (`single`) or all children
   * (`free`, like `fitToContent`), centers it and zooms it to fit, without magnifying it beyond 100 %.
   *
   * @public
   * @param args - The arguments of `fitToFrame`:
   * - `padding` - The margin around the frame in screen pixels. Defaults to 48.
   * - `options` - Whether the change animates.
   * @returns Whether there was something measurable to fit.
   */
  fitToFrame(...args: Parameters<DesignerCanvasElement['fitToFrame']>): ReturnType<DesignerCanvasElement['fitToFrame']>;
  /**
   * Fits the content into the visible canvas area without magnifying it beyond 100 %: the frame
   * (`single`) or the union of the rectangles of all children (`free`).
   *
   * @public
   * @param args - The arguments of `fitToContent`:
   * - `padding` - The margin around the content in screen pixels. Defaults to 48.
   * - `options` - Whether the change animates.
   * @returns Whether there was something measurable to fit.
   */
  fitToContent(...args: Parameters<DesignerCanvasElement['fitToContent']>): ReturnType<DesignerCanvasElement['fitToContent']>;
  /**
   * Shows a world rectangle as large as possible (up to `maxZoom`), centered in the canvas.
   *
   * @public
   * @param args - The arguments of `zoomToRect`:
   * - `rect` - The world rectangle, for example the rectangle of one frame.
   * - `padding` - The margin around the rectangle in screen pixels. Defaults to 48.
   * - `options` - Whether the change animates.
   * @returns Whether the canvas has a size to fit into.
   */
  zoomToRect(...args: Parameters<DesignerCanvasElement['zoomToRect']>): ReturnType<DesignerCanvasElement['zoomToRect']>;
  /**
   * Sets the viewport: `screen = world × zoom + (x, y)`, with screen points relative to the top left of
   * the canvas. The zoom is limited to `minZoom` and `maxZoom`.
   *
   * @public
   * @param args - The arguments of `setViewport`:
   * - `viewport` - The new viewport.
   * - `options` - Whether the change animates (users who prefer reduced motion get it at once).
   */
  setViewport(...args: Parameters<DesignerCanvasElement['setViewport']>): ReturnType<DesignerCanvasElement['setViewport']>;
  /**
   * Zooms while the world point under a screen anchor stays where it is.
   *
   * @public
   * @param args - The arguments of `zoomAt`:
   * - `zoom` - The new zoom, limited to `minZoom` and `maxZoom`.
   * - `anchor` - The screen point that stays in place, relative to the top left of the canvas. Defaults to the center of the canvas.
   * - `options` - Whether the change animates.
   */
  zoomAt(...args: Parameters<DesignerCanvasElement['zoomAt']>): ReturnType<DesignerCanvasElement['zoomAt']>;
  /**
   * Converts a screen point (relative to the top left of the canvas) to world coordinates.
   *
   * @public
   * @param args - The arguments of `screenToWorld`:
   * - `point` - The screen point.
   * @returns The world point (frame-local in the single arrangement).
   */
  screenToWorld(...args: Parameters<DesignerCanvasElement['screenToWorld']>): ReturnType<DesignerCanvasElement['screenToWorld']>;
  /**
   * Converts a world point to a screen point (relative to the top left of the canvas).
   *
   * @public
   * @param args - The arguments of `worldToScreen`:
   * - `point` - The world point (frame-local in the single arrangement).
   * @returns The screen point.
   */
  worldToScreen(...args: Parameters<DesignerCanvasElement['worldToScreen']>): ReturnType<DesignerCanvasElement['worldToScreen']>;
  /**
   * Pans the canvas by a given delta in unscaled pixels.
   *
   * @public
   * @param args - The arguments of `panBy`:
   * - `deltaX` - The horizontal distance.
   * - `deltaY` - The vertical distance.
   */
  panBy(...args: Parameters<DesignerCanvasElement['panBy']>): ReturnType<DesignerCanvasElement['panBy']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `zoomIn()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends DesignerCanvasMethodNames>(method: TMethod, ...args: Parameters<DesignerCanvasComponentMethods[TMethod]>): ReturnType<DesignerCanvasComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof DesignerCanvasElement>(property: TProperty, value: DesignerCanvasElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<DesignerCanvasElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<DesignerCanvasComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<DesignerCanvasComponent, "mosaik-designer-canvas", never, {
    "arrangement": {
      "alias": "arrangement";
      "required": false;
      "isSignal": true;
    };
    "zoom": {
      "alias": "zoom";
      "required": false;
      "isSignal": true;
    };
    "minZoom": {
      "alias": "minZoom";
      "required": false;
      "isSignal": true;
    };
    "maxZoom": {
      "alias": "maxZoom";
      "required": false;
      "isSignal": true;
    };
    "interactionMode": {
      "alias": "interactionMode";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "zoomChanged": "zoomChanged";
    "viewportChanged": "viewportChanged";
    "viewportSettled": "viewportSettled";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on DesignerCanvasComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type DesignerCanvasMethodNames = 'zoomIn' | 'zoomOut' | 'setZoom' | 'resetZoom' | 'fitToFrame' | 'fitToContent' | 'zoomToRect' | 'setViewport' | 'zoomAt' | 'screenToWorld' | 'worldToScreen' | 'panBy';
/**
 * Declares the methods interface for DesignerCanvasComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type DesignerCanvasComponentMethods = MethodMap<DesignerCanvasMethodNames>;
/**
 * @public
 */
export declare function provideDesignerCanvasComponent(config?: Partial<DesignerCanvasElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the DesignerConnectorComponent.
 * Use this token to provide default properties for the DesignerConnectorComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const DESIGNER_CONNECTOR_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").IDesignerConnectorElementProps>>;
/**
 * @public
 *
 * @slot label - Content shown at the middle of the connector, replacing the `label` text
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class DesignerConnectorComponent {
  /**
   * Signal input for the `from` property.
   *
   * @public
   */
  readonly from: InputSignal<DesignerConnectorElement['from'] | undefined>;
  /**
   * Signal input for the `to` property.
   *
   * @public
   */
  readonly to: InputSignal<DesignerConnectorElement['to'] | undefined>;
  /**
   * Signal input for the `routing` property.
   *
   * @public
   */
  readonly routing: InputSignal<DesignerConnectorElement['routing'] | undefined>;
  /**
   * Signal input for the `arrow` property.
   *
   * @public
   */
  readonly arrow: InputSignal<DesignerConnectorElement['arrow'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<DesignerConnectorElement['label'] | undefined>;
  /**
   * Signal input for the `selected` property.
   *
   * @public
   */
  readonly selected: InputSignal<DesignerConnectorElement['selected'] | undefined>;
  /**
   * Signal input for the `inverseZoom` property.
   *
   * @public
   */
  readonly inverseZoom: InputSignal<DesignerConnectorElement['inverseZoom'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<DesignerConnectorElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<DesignerConnectorElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<DesignerConnectorElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<DesignerConnectorElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<DesignerConnectorElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<DesignerConnectorElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof DesignerConnectorElement>(property: TProperty, value: DesignerConnectorElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<DesignerConnectorElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<DesignerConnectorComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<DesignerConnectorComponent, "mosaik-designer-connector", never, {
    "from": {
      "alias": "from";
      "required": false;
      "isSignal": true;
    };
    "to": {
      "alias": "to";
      "required": false;
      "isSignal": true;
    };
    "routing": {
      "alias": "routing";
      "required": false;
      "isSignal": true;
    };
    "arrow": {
      "alias": "arrow";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "selected": {
      "alias": "selected";
      "required": false;
      "isSignal": true;
    };
    "inverseZoom": {
      "alias": "inverseZoom";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on DesignerConnectorComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type DesignerConnectorMethodNames = never;
/**
 * Declares the methods interface for DesignerConnectorComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type DesignerConnectorComponentMethods = MethodMap<DesignerConnectorMethodNames>;
/**
 * @public
 */
export declare function provideDesignerConnectorComponent(config?: Partial<DesignerConnectorElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the DesignerContentComponent.
 * Use this token to provide default properties for the DesignerContentComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const DESIGNER_CONTENT_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").IDesignerContentElementProps>>;
/**
 * @public
 *
 * @slot  - Default slot for the canvas (mosaik-designer-canvas)
 * @slot after-canvas - Generic extension slot after the canvas
 * @slot before-canvas - Generic extension slot before the canvas
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class DesignerContentComponent {
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<DesignerContentElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<DesignerContentElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<DesignerContentElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<DesignerContentElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<DesignerContentElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<DesignerContentElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof DesignerContentElement>(property: TProperty, value: DesignerContentElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<DesignerContentElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<DesignerContentComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<DesignerContentComponent, "mosaik-designer-content", never, {
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on DesignerContentComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type DesignerContentMethodNames = never;
/**
 * Declares the methods interface for DesignerContentComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type DesignerContentComponentMethods = MethodMap<DesignerContentMethodNames>;
/**
 * @public
 */
export declare function provideDesignerContentComponent(config?: Partial<DesignerContentElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the DesignerFrameComponent.
 * Use this token to provide default properties for the DesignerFrameComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const DESIGNER_FRAME_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").IDesignerFrameElementProps>>;
/**
 * @public
 *
 * @slot  - Default slot for layer content
 * @slot label - The name shown above a placed frame, replacing the `label` text
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class DesignerFrameComponent {
  /**
   * Signal input for the `bounds` property.
   *
   * @public
   */
  readonly bounds: InputSignal<DesignerFrameElement['bounds'] | undefined>;
  /**
   * Signal input for the `showBounds` property.
   *
   * @public
   */
  readonly showBounds: InputSignal<DesignerFrameElement['showBounds'] | undefined>;
  /**
   * Signal input for the `fold` property.
   *
   * @public
   */
  readonly fold: InputSignal<DesignerFrameElement['fold'] | undefined>;
  /**
   * Signal input for the `foldOffset` property.
   *
   * @public
   */
  readonly foldOffset: InputSignal<DesignerFrameElement['foldOffset'] | undefined>;
  /**
   * Signal input for the `x` property.
   *
   * @public
   */
  readonly x: InputSignal<DesignerFrameElement['x'] | undefined>;
  /**
   * Signal input for the `y` property.
   *
   * @public
   */
  readonly y: InputSignal<DesignerFrameElement['y'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<DesignerFrameElement['label'] | undefined>;
  /**
   * Signal input for the `selected` property.
   *
   * @public
   */
  readonly selected: InputSignal<DesignerFrameElement['selected'] | undefined>;
  /**
   * Signal input for the `focused` property.
   *
   * @public
   */
  readonly focused: InputSignal<DesignerFrameElement['focused'] | undefined>;
  /**
   * Signal input for the `inverseZoom` property.
   *
   * @public
   */
  readonly inverseZoom: InputSignal<DesignerFrameElement['inverseZoom'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<DesignerFrameElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<DesignerFrameElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<DesignerFrameElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<DesignerFrameElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<DesignerFrameElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<DesignerFrameElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof DesignerFrameElement>(property: TProperty, value: DesignerFrameElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<DesignerFrameElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<DesignerFrameComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<DesignerFrameComponent, "mosaik-designer-frame", never, {
    "bounds": {
      "alias": "bounds";
      "required": false;
      "isSignal": true;
    };
    "showBounds": {
      "alias": "showBounds";
      "required": false;
      "isSignal": true;
    };
    "fold": {
      "alias": "fold";
      "required": false;
      "isSignal": true;
    };
    "foldOffset": {
      "alias": "foldOffset";
      "required": false;
      "isSignal": true;
    };
    "x": {
      "alias": "x";
      "required": false;
      "isSignal": true;
    };
    "y": {
      "alias": "y";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "selected": {
      "alias": "selected";
      "required": false;
      "isSignal": true;
    };
    "focused": {
      "alias": "focused";
      "required": false;
      "isSignal": true;
    };
    "inverseZoom": {
      "alias": "inverseZoom";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on DesignerFrameComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type DesignerFrameMethodNames = never;
/**
 * Declares the methods interface for DesignerFrameComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type DesignerFrameComponentMethods = MethodMap<DesignerFrameMethodNames>;
/**
 * @public
 */
export declare function provideDesignerFrameComponent(config?: Partial<DesignerFrameElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the DesignerComponent.
 * Use this token to provide default properties for the DesignerComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const DESIGNER_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").IDesignerElementProps>>;
/**
 * @public
 *
 * @slot  - Default slot for the primary workspace structure (mosaik-designer-content)
 * @slot after-content - Generic extension slot after the main content area
 * @slot before-content - Generic extension slot before the main content area
 * @slot footer - Generic extension slot for footer content such as status bars
 * @slot header - Generic extension slot for header content such as toolbars
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class DesignerComponent {
  /**
   * Signal input for the `defaultLayers` property.
   *
   * @public
   */
  readonly defaultLayers: InputSignal<DesignerElement['defaultLayers'] | undefined>;
  /**
   * Signal input for the `layers` property.
   *
   * @public
   */
  readonly layers: InputSignal<DesignerElement['layers'] | undefined>;
  /**
   * Signal input for the `frameSize` property.
   *
   * @public
   */
  readonly frameSize: InputSignal<DesignerElement['frameSize'] | undefined>;
  /**
   * Signal input for the `mode` property.
   *
   * @public
   */
  readonly mode: InputSignal<DesignerElement['mode'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<DesignerElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<DesignerElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<DesignerElement['lang'] | undefined>;
  /**
   * Output signal for the `layersChanged` event.
   *
   * @public
   */
  readonly layersChanged: OutputEmitterRef<ElementEventDetail<DesignerElement, 'layersChanged'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<DesignerElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<DesignerElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<DesignerElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Updates the layers from a user action.
   * In uncontrolled mode, updates internal state directly.
   * In controlled mode, emits the change for the parent to handle.
   *
   * @public
   */
  updateLayers(...args: Parameters<DesignerElement['updateLayers']>): ReturnType<DesignerElement['updateLayers']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `updateLayers()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends DesignerMethodNames>(method: TMethod, ...args: Parameters<DesignerComponentMethods[TMethod]>): ReturnType<DesignerComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof DesignerElement>(property: TProperty, value: DesignerElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<DesignerElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<DesignerComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<DesignerComponent, "mosaik-designer", never, {
    "defaultLayers": {
      "alias": "defaultLayers";
      "required": false;
      "isSignal": true;
    };
    "layers": {
      "alias": "layers";
      "required": false;
      "isSignal": true;
    };
    "frameSize": {
      "alias": "frameSize";
      "required": false;
      "isSignal": true;
    };
    "mode": {
      "alias": "mode";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "layersChanged": "layersChanged";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on DesignerComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type DesignerMethodNames = 'updateLayers';
/**
 * Declares the methods interface for DesignerComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type DesignerComponentMethods = MethodMap<DesignerMethodNames>;
/**
 * @public
 */
export declare function provideDesignerComponent(config?: Partial<DesignerElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-designer.d.ts.map