import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { OrbitElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/illustrations/orbit/OrbitElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the OrbitComponent.
 * Use this token to provide default properties for the OrbitComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const ORBIT_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").IOrbitElementProps>>;
/**
 * @public
 *
 * @slot  - The items of the outermost ring.
 * @slot center - The content in the middle of the rings.
 * @slot ring-1 - The items of ring 1 (the innermost ring); `ring-2`, `ring-3` … for the following rings.
 * @slot ring-${n} - The items of numbered ring n, from 1 through `rings` (for example `ring-2` or `ring-12`).
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class OrbitComponent {
  /**
   * Signal input for the `rings` property.
   *
   * @public
   */
  readonly rings: InputSignal<OrbitElement['rings'] | undefined>;
  /**
   * Signal input for the `radius` property.
   *
   * @public
   */
  readonly radius: InputSignal<OrbitElement['radius'] | undefined>;
  /**
   * Signal input for the `duration` property.
   *
   * @public
   */
  readonly duration: InputSignal<OrbitElement['duration'] | undefined>;
  /**
   * Signal input for the `steps` property.
   *
   * @public
   */
  readonly steps: InputSignal<OrbitElement['steps'] | undefined>;
  /**
   * Signal input for the `ringDurations` property.
   *
   * @public
   */
  readonly ringDurations: InputSignal<OrbitElement['ringDurations'] | undefined>;
  /**
   * Signal input for the `ringReverse` property.
   *
   * @public
   */
  readonly ringReverse: InputSignal<OrbitElement['ringReverse'] | undefined>;
  /**
   * Signal input for the `dashed` property.
   *
   * @public
   */
  readonly dashed: InputSignal<OrbitElement['dashed'] | undefined>;
  /**
   * Signal input for the `startAngle` property.
   *
   * @public
   */
  readonly startAngle: InputSignal<OrbitElement['startAngle'] | undefined>;
  /**
   * Signal input for the `upright` property.
   *
   * @public
   */
  readonly upright: InputSignal<OrbitElement['upright'] | undefined>;
  /**
   * Signal input for the `fanOut` property.
   *
   * @public
   */
  readonly fanOut: InputSignal<OrbitElement['fanOut'] | undefined>;
  /**
   * Signal input for the `reverse` property.
   *
   * @public
   */
  readonly reverse: InputSignal<OrbitElement['reverse'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<OrbitElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<OrbitElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<OrbitElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<OrbitElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<OrbitElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<OrbitElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: OrbitElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: OrbitElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Called when the slot changes.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<OrbitElement['onSlotChanges']>): ReturnType<OrbitElement['onSlotChanges']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   * @param args - The arguments of `assignToSlot`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * - `node` - The nodes to assign to the slot.
   */
  assignToSlot(...args: Parameters<OrbitElement['assignToSlot']>): ReturnType<OrbitElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   * This method extracts text content recursively, including from Shadow DOMs
   * and Custom Elements with known text properties (like `mosaik-text`).
   *
   * @public
   * @param args - The arguments of `getSlotContent`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<OrbitElement['getSlotContent']>): ReturnType<OrbitElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @param args - The arguments of `hasSlotContent`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<OrbitElement['hasSlotContent']>): ReturnType<OrbitElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @param args - The arguments of `hasSlot`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<OrbitElement['hasSlot']>): ReturnType<OrbitElement['hasSlot']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `onSlotChanges()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends OrbitMethodNames>(method: TMethod, ...args: Parameters<OrbitComponentMethods[TMethod]>): ReturnType<OrbitComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof OrbitElement>(property: TProperty, value: OrbitElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<OrbitElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<OrbitComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<OrbitComponent, "mosaik-orbit", never, {
    "rings": {
      "alias": "rings";
      "required": false;
      "isSignal": true;
    };
    "radius": {
      "alias": "radius";
      "required": false;
      "isSignal": true;
    };
    "duration": {
      "alias": "duration";
      "required": false;
      "isSignal": true;
    };
    "steps": {
      "alias": "steps";
      "required": false;
      "isSignal": true;
    };
    "ringDurations": {
      "alias": "ringDurations";
      "required": false;
      "isSignal": true;
    };
    "ringReverse": {
      "alias": "ringReverse";
      "required": false;
      "isSignal": true;
    };
    "dashed": {
      "alias": "dashed";
      "required": false;
      "isSignal": true;
    };
    "startAngle": {
      "alias": "startAngle";
      "required": false;
      "isSignal": true;
    };
    "upright": {
      "alias": "upright";
      "required": false;
      "isSignal": true;
    };
    "fanOut": {
      "alias": "fanOut";
      "required": false;
      "isSignal": true;
    };
    "reverse": {
      "alias": "reverse";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on OrbitComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type OrbitMethodNames = 'onSlotChanges' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot';
/**
 * Declares the methods interface for OrbitComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type OrbitComponentMethods = MethodMap<OrbitMethodNames>;
/**
 * @public
 */
export declare function provideOrbitComponent(config?: Partial<OrbitElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-orbit.d.ts.map