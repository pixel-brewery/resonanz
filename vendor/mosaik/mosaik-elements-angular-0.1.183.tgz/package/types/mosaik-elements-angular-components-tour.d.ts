import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { TourAnchorElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/overlays/tour/TourAnchorElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { TourNavElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/overlays/tour/TourNavElement";
import { TourStepElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/overlays/tour/TourStepElement";
import { TourElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/overlays/tour/TourElement";
/**
 * @public
 *
 * Injection token for the default properties of the TourAnchorComponent.
 * Use this token to provide default properties for the TourAnchorComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const TOUR_ANCHOR_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/overlays/tour/ITourAnchorElementProps").ITourAnchorElementProps>>;
/**
 * @public
 *
 * @slot  - Content that should be associated with the anchor.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class TourAnchorComponent {
  /**
   * Signal input for the `tourId` property.
   *
   * @public
   */
  readonly tourId: InputSignal<TourAnchorElement['tourId'] | undefined>;
  /**
   * Signal input for the `anchorId` property.
   *
   * @public
   */
  readonly anchorId: InputSignal<TourAnchorElement['anchorId'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<TourAnchorElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<TourAnchorElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<TourAnchorElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<TourAnchorElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<TourAnchorElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<TourAnchorElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof TourAnchorElement>(property: TProperty, value: TourAnchorElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<TourAnchorElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<TourAnchorComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<TourAnchorComponent, "mosaik-tour-anchor", never, {
    "tourId": {
      "alias": "tourId";
      "required": false;
      "isSignal": true;
    };
    "anchorId": {
      "alias": "anchorId";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on TourAnchorComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TourAnchorMethodNames = never;
/**
 * Declares the methods interface for TourAnchorComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TourAnchorComponentMethods = MethodMap<TourAnchorMethodNames>;
/**
 * @public
 */
export declare function provideTourAnchorComponent(config?: Partial<TourAnchorElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the TourNavComponent.
 * Use this token to provide default properties for the TourNavComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const TOUR_NAV_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").ITourNavElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class TourNavComponent {
  /**
   * Signal input for the `currentStepIndex` property.
   *
   * @public
   */
  readonly currentStepIndex: InputSignal<TourNavElement['currentStepIndex'] | undefined>;
  /**
   * Signal input for the `stepCount` property.
   *
   * @public
   */
  readonly stepCount: InputSignal<TourNavElement['stepCount'] | undefined>;
  /**
   * Signal input for the `isFirstStep` property.
   *
   * @public
   */
  readonly isFirstStep: InputSignal<TourNavElement['isFirstStep'] | undefined>;
  /**
   * Signal input for the `isLastStep` property.
   *
   * @public
   */
  readonly isLastStep: InputSignal<TourNavElement['isLastStep'] | undefined>;
  /**
   * Signal input for the `showProgress` property.
   *
   * @public
   */
  readonly showProgress: InputSignal<TourNavElement['showProgress'] | undefined>;
  /**
   * Signal input for the `showAutoAdvanceControls` property.
   *
   * @public
   */
  readonly showAutoAdvanceControls: InputSignal<TourNavElement['showAutoAdvanceControls'] | undefined>;
  /**
   * Signal input for the `isAutoAdvancePaused` property.
   *
   * @public
   */
  readonly isAutoAdvancePaused: InputSignal<TourNavElement['isAutoAdvancePaused'] | undefined>;
  /**
   * Signal input for the `stepDuration` property.
   *
   * @public
   */
  readonly stepDuration: InputSignal<TourNavElement['stepDuration'] | undefined>;
  /**
   * Signal input for the `minimumStepDuration` property.
   *
   * @public
   */
  readonly minimumStepDuration: InputSignal<TourNavElement['minimumStepDuration'] | undefined>;
  /**
   * Signal input for the `maximumStepDuration` property.
   *
   * @public
   */
  readonly maximumStepDuration: InputSignal<TourNavElement['maximumStepDuration'] | undefined>;
  /**
   * Signal input for the `stepDurationIncrement` property.
   *
   * @public
   */
  readonly stepDurationIncrement: InputSignal<TourNavElement['stepDurationIncrement'] | undefined>;
  /**
   * Signal input for the `labels` property.
   *
   * @public
   */
  readonly labels: InputSignal<TourNavElement['labels'] | undefined>;
  /**
   * Signal input for the `actions` property.
   *
   * @public
   */
  readonly actions: InputSignal<TourNavElement['actions'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<TourNavElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<TourNavElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<TourNavElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<TourNavElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<TourNavElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<TourNavElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof TourNavElement>(property: TProperty, value: TourNavElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<TourNavElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<TourNavComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<TourNavComponent, "mosaik-tour-nav", never, {
    "currentStepIndex": {
      "alias": "currentStepIndex";
      "required": false;
      "isSignal": true;
    };
    "stepCount": {
      "alias": "stepCount";
      "required": false;
      "isSignal": true;
    };
    "isFirstStep": {
      "alias": "isFirstStep";
      "required": false;
      "isSignal": true;
    };
    "isLastStep": {
      "alias": "isLastStep";
      "required": false;
      "isSignal": true;
    };
    "showProgress": {
      "alias": "showProgress";
      "required": false;
      "isSignal": true;
    };
    "showAutoAdvanceControls": {
      "alias": "showAutoAdvanceControls";
      "required": false;
      "isSignal": true;
    };
    "isAutoAdvancePaused": {
      "alias": "isAutoAdvancePaused";
      "required": false;
      "isSignal": true;
    };
    "stepDuration": {
      "alias": "stepDuration";
      "required": false;
      "isSignal": true;
    };
    "minimumStepDuration": {
      "alias": "minimumStepDuration";
      "required": false;
      "isSignal": true;
    };
    "maximumStepDuration": {
      "alias": "maximumStepDuration";
      "required": false;
      "isSignal": true;
    };
    "stepDurationIncrement": {
      "alias": "stepDurationIncrement";
      "required": false;
      "isSignal": true;
    };
    "labels": {
      "alias": "labels";
      "required": false;
      "isSignal": true;
    };
    "actions": {
      "alias": "actions";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on TourNavComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TourNavMethodNames = never;
/**
 * Declares the methods interface for TourNavComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TourNavComponentMethods = MethodMap<TourNavMethodNames>;
/**
 * @public
 */
export declare function provideTourNavComponent(config?: Partial<TourNavElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the TourStepComponent.
 * Use this token to provide default properties for the TourStepComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const TOUR_STEP_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/overlays/tour/ITourStepElementProps").ITourStepElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class TourStepComponent {
  /**
   * Signal input for the `step` property.
   *
   * @public
   */
  readonly step: InputSignal<TourStepElement['step'] | undefined>;
  /**
   * Signal input for the `isFirstStep` property.
   *
   * @public
   */
  readonly isFirstStep: InputSignal<TourStepElement['isFirstStep'] | undefined>;
  /**
   * Signal input for the `isLastStep` property.
   *
   * @public
   */
  readonly isLastStep: InputSignal<TourStepElement['isLastStep'] | undefined>;
  /**
   * Signal input for the `stepIndex` property.
   *
   * @public
   */
  readonly stepIndex: InputSignal<TourStepElement['stepIndex'] | undefined>;
  /**
   * Signal input for the `stepCount` property.
   *
   * @public
   */
  readonly stepCount: InputSignal<TourStepElement['stepCount'] | undefined>;
  /**
   * Signal input for the `showProgress` property.
   *
   * @public
   */
  readonly showProgress: InputSignal<TourStepElement['showProgress'] | undefined>;
  /**
   * Signal input for the `showAutoAdvanceControl` property.
   *
   * @public
   */
  readonly showAutoAdvanceControl: InputSignal<TourStepElement['showAutoAdvanceControl'] | undefined>;
  /**
   * Signal input for the `isAutoAdvancePaused` property.
   *
   * @public
   */
  readonly isAutoAdvancePaused: InputSignal<TourStepElement['isAutoAdvancePaused'] | undefined>;
  /**
   * Signal input for the `labels` property.
   *
   * @public
   */
  readonly labels: InputSignal<TourStepElement['labels'] | undefined>;
  /**
   * Signal input for the `actions` property.
   *
   * @public
   */
  readonly actions: InputSignal<TourStepElement['actions'] | undefined>;
  /**
   * Signal input for the `titleId` property.
   *
   * @public
   */
  readonly titleId: InputSignal<TourStepElement['titleId'] | undefined>;
  /**
   * Signal input for the `descriptionId` property.
   *
   * @public
   */
  readonly descriptionId: InputSignal<TourStepElement['descriptionId'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<TourStepElement['themeName'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<TourStepElement['variant'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<TourStepElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<TourStepElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<TourStepElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<TourStepElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<TourStepElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof TourStepElement>(property: TProperty, value: TourStepElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<TourStepElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<TourStepComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<TourStepComponent, "mosaik-tour-step", never, {
    "step": {
      "alias": "step";
      "required": false;
      "isSignal": true;
    };
    "isFirstStep": {
      "alias": "isFirstStep";
      "required": false;
      "isSignal": true;
    };
    "isLastStep": {
      "alias": "isLastStep";
      "required": false;
      "isSignal": true;
    };
    "stepIndex": {
      "alias": "stepIndex";
      "required": false;
      "isSignal": true;
    };
    "stepCount": {
      "alias": "stepCount";
      "required": false;
      "isSignal": true;
    };
    "showProgress": {
      "alias": "showProgress";
      "required": false;
      "isSignal": true;
    };
    "showAutoAdvanceControl": {
      "alias": "showAutoAdvanceControl";
      "required": false;
      "isSignal": true;
    };
    "isAutoAdvancePaused": {
      "alias": "isAutoAdvancePaused";
      "required": false;
      "isSignal": true;
    };
    "labels": {
      "alias": "labels";
      "required": false;
      "isSignal": true;
    };
    "actions": {
      "alias": "actions";
      "required": false;
      "isSignal": true;
    };
    "titleId": {
      "alias": "titleId";
      "required": false;
      "isSignal": true;
    };
    "descriptionId": {
      "alias": "descriptionId";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on TourStepComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TourStepMethodNames = never;
/**
 * Declares the methods interface for TourStepComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TourStepComponentMethods = MethodMap<TourStepMethodNames>;
/**
 * @public
 */
export declare function provideTourStepComponent(config?: Partial<TourStepElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the TourComponent.
 * Use this token to provide default properties for the TourComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const TOUR_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/overlays/tour/ITourElementProps").ITourElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class TourComponent {
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<TourElement['intl'] | undefined>;
  /**
   * Signal input for the `tourId` property.
   *
   * @public
   */
  readonly tourId: InputSignal<TourElement['tourId'] | undefined>;
  /**
   * Signal input for the `behaviors` property.
   *
   * @public
   */
  readonly behaviors: InputSignal<TourElement['behaviors'] | undefined>;
  /**
   * Signal input for the `steps` property.
   *
   * @public
   */
  readonly steps: InputSignal<TourElement['steps'] | undefined>;
  /**
   * Signal input for the `context` property.
   *
   * @public
   */
  readonly context: InputSignal<TourElement['context'] | undefined>;
  /**
   * Signal input for the `labels` property.
   *
   * @public
   */
  readonly labels: InputSignal<TourElement['labels'] | undefined>;
  /**
   * Signal input for the `showProgress` property.
   *
   * @public
   */
  readonly showProgress: InputSignal<TourElement['showProgress'] | undefined>;
  /**
   * Signal input for the `showAutoAdvanceControls` property.
   *
   * @public
   */
  readonly showAutoAdvanceControls: InputSignal<TourElement['showAutoAdvanceControls'] | undefined>;
  /**
   * Signal input for the `showFloatingControls` property.
   *
   * @public
   */
  readonly showFloatingControls: InputSignal<TourElement['showFloatingControls'] | undefined>;
  /**
   * Signal input for the `minimumStepDuration` property.
   *
   * @public
   */
  readonly minimumStepDuration: InputSignal<TourElement['minimumStepDuration'] | undefined>;
  /**
   * Signal input for the `maximumStepDuration` property.
   *
   * @public
   */
  readonly maximumStepDuration: InputSignal<TourElement['maximumStepDuration'] | undefined>;
  /**
   * Signal input for the `stepDurationIncrement` property.
   *
   * @public
   */
  readonly stepDurationIncrement: InputSignal<TourElement['stepDurationIncrement'] | undefined>;
  /**
   * Signal input for the `restoreFocus` property.
   *
   * @public
   */
  readonly restoreFocus: InputSignal<TourElement['restoreFocus'] | undefined>;
  /**
   * Signal input for the `blockScroll` property.
   *
   * @public
   */
  readonly blockScroll: InputSignal<TourElement['blockScroll'] | undefined>;
  /**
   * Signal input for the `stepActivator` property.
   *
   * @public
   */
  readonly stepActivator: InputSignal<TourElement['stepActivator'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<TourElement['themeName'] | undefined>;
  /**
   * Signal input for the `enter` property.
   *
   * @public
   */
  readonly enter: InputSignal<TourElement['enter'] | undefined>;
  /**
   * Signal input for the `exit` property.
   *
   * @public
   */
  readonly exit: InputSignal<TourElement['exit'] | undefined>;
  /**
   * Signal input for the `isOpen` property.
   *
   * @public
   */
  readonly isOpen: InputSignal<TourElement['isOpen'] | undefined>;
  /**
   * Signal input for the `hasBackdrop` property.
   *
   * @public
   */
  readonly hasBackdrop: InputSignal<TourElement['hasBackdrop'] | undefined>;
  /**
   * Signal input for the `pressEscapeToClose` property.
   *
   * @public
   */
  readonly pressEscapeToClose: InputSignal<TourElement['pressEscapeToClose'] | undefined>;
  /**
   * Signal input for the `clickOutsideToClose` property.
   *
   * @public
   */
  readonly clickOutsideToClose: InputSignal<TourElement['clickOutsideToClose'] | undefined>;
  /**
   * Signal input for the `attention` property.
   *
   * @public
   */
  readonly attention: InputSignal<TourElement['attention'] | undefined>;
  /**
   * Signal input for the `closeable` property.
   *
   * @public
   */
  readonly closeable: InputSignal<TourElement['closeable'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<TourElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<TourElement['lang'] | undefined>;
  /**
   * Output signal for the `tourStarted` event.
   *
   * @public
   */
  readonly tourStarted: OutputEmitterRef<ElementEventDetail<TourElement, 'tourStarted'>>;
  /**
   * Output signal for the `tourEnded` event.
   *
   * @public
   */
  readonly tourEnded: OutputEmitterRef<ElementEventDetail<TourElement, 'tourEnded'>>;
  /**
   * Output signal for the `tourStepChanged` event.
   *
   * @public
   */
  readonly tourStepChanged: OutputEmitterRef<ElementEventDetail<TourElement, 'tourStepChanged'>>;
  /**
   * Output signal for the `tourFailed` event.
   *
   * @public
   */
  readonly tourFailed: OutputEmitterRef<ElementEventDetail<TourElement, 'tourFailed'>>;
  /**
   * Output signal for the `opened` event.
   *
   * @public
   */
  readonly opened: OutputEmitterRef<ElementEventDetail<TourElement, 'opened'>>;
  /**
   * Output signal for the `closed` event.
   *
   * @public
   */
  readonly closed: OutputEmitterRef<ElementEventDetail<TourElement, 'closed'>>;
  /**
   * Output signal for the `closeAttempted` event.
   *
   * @public
   */
  readonly closeAttempted: OutputEmitterRef<ElementEventDetail<TourElement, 'closeAttempted'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<TourElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<TourElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<TourElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Starts the tour at the first step or at a supplied step identifier.
   *
   * @public
   */
  start(...args: Parameters<TourElement['start']>): ReturnType<TourElement['start']>;
  /**
   * Moves to the next available step or finishes the tour.
   *
   * @public
   */
  next(...args: Parameters<TourElement['next']>): ReturnType<TourElement['next']>;
  /**
   * Moves to the previous available step.
   *
   * @public
   */
  previous(...args: Parameters<TourElement['previous']>): ReturnType<TourElement['previous']>;
  /**
   * Finishes the tour.
   *
   * @public
   */
  finish(...args: Parameters<TourElement['finish']>): ReturnType<TourElement['finish']>;
  /**
   * Skips the remaining tour.
   *
   * @public
   */
  skip(...args: Parameters<TourElement['skip']>): ReturnType<TourElement['skip']>;
  /**
   * Pauses the remaining countdown of the current timed step. The paused
   * state remains active while users navigate between steps manually.
   *
   * @public
   * @returns `true` when automatic progression was paused.
   */
  pauseAutoAdvance(...args: Parameters<TourElement['pauseAutoAdvance']>): ReturnType<TourElement['pauseAutoAdvance']>;
  /**
   * Resumes automatic progression from the currently visible step. If the
   * user navigated while paused, the current timed step receives a fresh full
   * countdown.
   *
   * @public
   * @returns `true` when the user pause was released.
   */
  resumeAutoAdvance(...args: Parameters<TourElement['resumeAutoAdvance']>): ReturnType<TourElement['resumeAutoAdvance']>;
  /**
   * Applies a session-only duration override and restarts the current countdown.
   * The duration is rounded to the nearest configured increment.
   *
   * @public
   * @param args - The arguments of `setStepDuration`:
   * - `duration` - Step duration in milliseconds.
   * @returns `true` when the duration was accepted.
   */
  setStepDuration(...args: Parameters<TourElement['setStepDuration']>): ReturnType<TourElement['setStepDuration']>;
  /**
   * Ends the tour with the supplied reason.
   *
   * @public
   */
  end(...args: Parameters<TourElement['end']>): ReturnType<TourElement['end']>;
  /**
   * Shows a configured step by identifier.
   *
   * @public
   */
  showStep(...args: Parameters<TourElement['showStep']>): ReturnType<TourElement['showStep']>;
  /**
   * Closes the overlay and completes the tour lifecycle.
   *
   * @public
   */
  close(...args: Parameters<TourElement['close']>): ReturnType<TourElement['close']>;
  /**
   * Executes the animation.
   *
   * @public
   */
  play(...args: Parameters<TourElement['play']>): ReturnType<TourElement['play']>;
  /**
   * A lifecycle hook that is invoked when the element is added to the DOM.
   *
   * @public
   */
  onEnterAnimation(...args: Parameters<NonNullable<TourElement['onEnterAnimation']>>): ReturnType<NonNullable<TourElement['onEnterAnimation']>> | undefined;
  /**
   * A lifecycle hook that is invoked when the element is removed from the DOM.
   *
   * @public
   */
  onExitAnimation(...args: Parameters<NonNullable<TourElement['onExitAnimation']>>): ReturnType<NonNullable<TourElement['onExitAnimation']>> | undefined;
  /**
   * Opens the `OverlayElement`.
   *
   * @public
   */
  open(...args: Parameters<TourElement['open']>): ReturnType<TourElement['open']>;
  /**
   * Requests visual attention for this overlay.
   *
   * @public
   * @param args - The arguments of `requestAttention`:
   * - `animation` - Optional animation used for this attention request.
   * @returns Whether the attention animation finished.
   */
  requestAttention(...args: Parameters<TourElement['requestAttention']>): ReturnType<TourElement['requestAttention']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `start()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends TourMethodNames>(method: TMethod, ...args: Parameters<TourComponentMethods[TMethod]>): ReturnType<TourComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof TourElement>(property: TProperty, value: TourElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<TourElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<TourComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<TourComponent, "mosaik-tour", never, {
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "tourId": {
      "alias": "tourId";
      "required": false;
      "isSignal": true;
    };
    "behaviors": {
      "alias": "behaviors";
      "required": false;
      "isSignal": true;
    };
    "steps": {
      "alias": "steps";
      "required": false;
      "isSignal": true;
    };
    "context": {
      "alias": "context";
      "required": false;
      "isSignal": true;
    };
    "labels": {
      "alias": "labels";
      "required": false;
      "isSignal": true;
    };
    "showProgress": {
      "alias": "showProgress";
      "required": false;
      "isSignal": true;
    };
    "showAutoAdvanceControls": {
      "alias": "showAutoAdvanceControls";
      "required": false;
      "isSignal": true;
    };
    "showFloatingControls": {
      "alias": "showFloatingControls";
      "required": false;
      "isSignal": true;
    };
    "minimumStepDuration": {
      "alias": "minimumStepDuration";
      "required": false;
      "isSignal": true;
    };
    "maximumStepDuration": {
      "alias": "maximumStepDuration";
      "required": false;
      "isSignal": true;
    };
    "stepDurationIncrement": {
      "alias": "stepDurationIncrement";
      "required": false;
      "isSignal": true;
    };
    "restoreFocus": {
      "alias": "restoreFocus";
      "required": false;
      "isSignal": true;
    };
    "blockScroll": {
      "alias": "blockScroll";
      "required": false;
      "isSignal": true;
    };
    "stepActivator": {
      "alias": "stepActivator";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "enter": {
      "alias": "enter";
      "required": false;
      "isSignal": true;
    };
    "exit": {
      "alias": "exit";
      "required": false;
      "isSignal": true;
    };
    "isOpen": {
      "alias": "isOpen";
      "required": false;
      "isSignal": true;
    };
    "hasBackdrop": {
      "alias": "hasBackdrop";
      "required": false;
      "isSignal": true;
    };
    "pressEscapeToClose": {
      "alias": "pressEscapeToClose";
      "required": false;
      "isSignal": true;
    };
    "clickOutsideToClose": {
      "alias": "clickOutsideToClose";
      "required": false;
      "isSignal": true;
    };
    "attention": {
      "alias": "attention";
      "required": false;
      "isSignal": true;
    };
    "closeable": {
      "alias": "closeable";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "tourStarted": "tourStarted";
    "tourEnded": "tourEnded";
    "tourStepChanged": "tourStepChanged";
    "tourFailed": "tourFailed";
    "opened": "opened";
    "closed": "closed";
    "closeAttempted": "closeAttempted";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on TourComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TourMethodNames = 'start' | 'next' | 'previous' | 'finish' | 'skip' | 'pauseAutoAdvance' | 'resumeAutoAdvance' | 'setStepDuration' | 'end' | 'showStep' | 'close' | 'play' | 'onEnterAnimation' | 'onExitAnimation' | 'open' | 'requestAttention';
/**
 * Declares the methods interface for TourComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TourComponentMethods = MethodMap<TourMethodNames>;
/**
 * @public
 */
export declare function provideTourComponent(config?: Partial<TourElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-tour.d.ts.map