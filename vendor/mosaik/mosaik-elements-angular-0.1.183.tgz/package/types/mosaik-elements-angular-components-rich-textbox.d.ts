import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef, Type } from "@angular/core";
import { RichTextBoxElement, RichTextBoxToolboxElement } from "@pixel-brewery/mosaik-elements-foundation/components/rich-textbox";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import * as i1 from "@pixel-brewery/mosaik-elements-angular/runtime";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { ControlValueAccessor } from "@angular/forms";
/**
 * @public
 *
 * Injection token for the default properties of the RichTextBoxToolboxComponent.
 * Use this token to provide default properties for the RichTextBoxToolboxComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const RICH_TEXT_BOX_TOOLBOX_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation/components/rich-textbox").IRichTextBoxToolboxElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class RichTextBoxToolboxComponent {
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<RichTextBoxToolboxElement['intl'] | undefined>;
  /**
   * Signal input for the `editor` property.
   *
   * @public
   */
  readonly editor: InputSignal<RichTextBoxToolboxElement['editor'] | undefined>;
  /**
   * Signal input for the `tools` property.
   *
   * @public
   */
  readonly tools: InputSignal<RichTextBoxToolboxElement['tools'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<RichTextBoxToolboxElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<RichTextBoxToolboxElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<RichTextBoxToolboxElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<RichTextBoxToolboxElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<RichTextBoxToolboxElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<RichTextBoxToolboxElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Runs a command, or opens the address popup for `link` and `image`.
   *
   * @public
   * @param args - The arguments of `execute`:
   * - `tool` - The command.
   */
  execute(...args: Parameters<RichTextBoxToolboxElement['execute']>): ReturnType<RichTextBoxToolboxElement['execute']>;
  /**
   * Opens the link popup at the link button, or at the overflow button when the link button does not fit.
   *
   * @public
   */
  openLink(...args: Parameters<RichTextBoxToolboxElement['openLink']>): ReturnType<RichTextBoxToolboxElement['openLink']>;
  /**
   * Removes the link at the selection the popup was opened for.
   *
   * @public
   */
  removeLink(...args: Parameters<RichTextBoxToolboxElement['removeLink']>): ReturnType<RichTextBoxToolboxElement['removeLink']>;
  /**
   * Opens the image popup at the image button, or at the overflow button when the image button does not fit.
   *
   * @public
   */
  openImage(...args: Parameters<RichTextBoxToolboxElement['openImage']>): ReturnType<RichTextBoxToolboxElement['openImage']>;
  /**
   * Closes the open popup without a change and returns the focus with the original selection to the editor.
   *
   * @public
   */
  cancelPopup(...args: Parameters<RichTextBoxToolboxElement['cancelPopup']>): ReturnType<RichTextBoxToolboxElement['cancelPopup']>;
  /**
   * Closes the link popup without a change.
   *
   * @public
   */
  cancelLink(...args: Parameters<RichTextBoxToolboxElement['cancelLink']>): ReturnType<RichTextBoxToolboxElement['cancelLink']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `execute()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends RichTextBoxToolboxMethodNames>(method: TMethod, ...args: Parameters<RichTextBoxToolboxComponentMethods[TMethod]>): ReturnType<RichTextBoxToolboxComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof RichTextBoxToolboxElement>(property: TProperty, value: RichTextBoxToolboxElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<RichTextBoxToolboxElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<RichTextBoxToolboxComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<RichTextBoxToolboxComponent, "mosaik-richtextbox-toolbox", never, {
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "editor": {
      "alias": "editor";
      "required": false;
      "isSignal": true;
    };
    "tools": {
      "alias": "tools";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on RichTextBoxToolboxComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type RichTextBoxToolboxMethodNames = 'execute' | 'openLink' | 'removeLink' | 'openImage' | 'cancelPopup' | 'cancelLink';
/**
 * Declares the methods interface for RichTextBoxToolboxComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type RichTextBoxToolboxComponentMethods = MethodMap<RichTextBoxToolboxMethodNames>;
/**
 * @public
 */
export declare function provideRichTextBoxToolboxComponent(config?: Partial<RichTextBoxToolboxElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the RichTextBoxComponent.
 * Use this token to provide default properties for the RichTextBoxComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const RICH_TEXT_BOX_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation/components/rich-textbox").IRichTextBoxElementProps>>;
/**
 * @public
 *
 * Injection token for the intl configuration of the RichTextBoxComponent.
 * Provide a partial intl object or an injectable class that resolves translations.
 * This allows third-party applications to override the default intl labels
 * globally, per route, or per component via Angular's dependency injection.
 *
 * Merge order: Foundation defaults → DI intl → [intl] input binding.
 */
export declare const RICH_TEXT_BOX_INTL: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation/components/rich-textbox").RichTextBoxElementIntl>>;
/**
 * @public
 *
 * @slot prefix - The prefix slot.
 * @slot suffix - The suffix slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class RichTextBoxComponent implements ControlValueAccessor {
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<Partial<RichTextBoxElement['intl']> | undefined>;
  /**
   * Signal input for the `readonly` property.
   *
   * @public
   */
  readonly readonly: InputSignal<RichTextBoxElement['readonly'] | undefined>;
  /**
   * Signal input for the `required` property.
   *
   * @public
   */
  readonly required: InputSignal<RichTextBoxElement['required'] | undefined>;
  /**
   * Signal input for the `autofocus` property.
   *
   * @public
   */
  readonly autofocus: InputSignal<RichTextBoxElement['autofocus'] | undefined>;
  /**
   * Signal input for the `name` property.
   *
   * @public
   */
  readonly name: InputSignal<RichTextBoxElement['name'] | undefined>;
  /**
   * Signal input for the `pattern` property.
   *
   * @public
   */
  readonly pattern: InputSignal<RichTextBoxElement['pattern'] | undefined>;
  /**
   * Signal input for the `placeholder` property.
   *
   * @public
   */
  readonly placeholder: InputSignal<RichTextBoxElement['placeholder'] | undefined>;
  /**
   * Signal input for the `autocomplete` property.
   *
   * @public
   */
  readonly autocomplete: InputSignal<RichTextBoxElement['autocomplete'] | undefined>;
  /**
   * Signal input for the `minlength` property.
   *
   * @public
   */
  readonly minlength: InputSignal<RichTextBoxElement['minlength'] | undefined>;
  /**
   * Signal input for the `maxlength` property.
   *
   * @public
   */
  readonly maxlength: InputSignal<RichTextBoxElement['maxlength'] | undefined>;
  /**
   * Signal input for the `multilineRows` property.
   *
   * @public
   */
  readonly multilineRows: InputSignal<RichTextBoxElement['multilineRows'] | undefined>;
  /**
   * Signal input for the `resize` property.
   *
   * @public
   */
  readonly resize: InputSignal<RichTextBoxElement['resize'] | undefined>;
  /**
   * Signal input for the `showToolbar` property.
   *
   * @public
   */
  readonly showToolbar: InputSignal<RichTextBoxElement['showToolbar'] | undefined>;
  /**
   * Signal input for the `showToolbox` property.
   *
   * @public
   */
  readonly showToolbox: InputSignal<RichTextBoxElement['showToolbox'] | undefined>;
  /**
   * Signal input for the `submitOnEnter` property.
   *
   * @public
   */
  readonly submitOnEnter: InputSignal<RichTextBoxElement['submitOnEnter'] | undefined>;
  /**
   * Signal input for the `plainTextPaste` property.
   *
   * @public
   */
  readonly plainTextPaste: InputSignal<RichTextBoxElement['plainTextPaste'] | undefined>;
  /**
   * Signal input for the `extensions` property.
   *
   * @public
   */
  readonly extensions: InputSignal<RichTextBoxElement['extensions'] | undefined>;
  /**
   * Signal input for the `suggestions` property.
   *
   * @public
   */
  readonly suggestions: InputSignal<RichTextBoxElement['suggestions'] | undefined>;
  /**
   * Signal input for the `mentionDocument` property.
   *
   * @public
   */
  readonly mentionDocument: InputSignal<RichTextBoxElement['mentionDocument'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<RichTextBoxElement['themeName'] | undefined>;
  /**
   * Signal input for the `isClearable` property.
   *
   * @public
   */
  readonly isClearable: InputSignal<RichTextBoxElement['isClearable'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<RichTextBoxElement['appearance'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<RichTextBoxElement['variant'] | undefined>;
  /**
   * Signal input for the `invalid` property.
   *
   * @public
   */
  readonly invalid: InputSignal<RichTextBoxElement['invalid'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<RichTextBoxElement['value'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<RichTextBoxElement['label'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<RichTextBoxElement['disabled'] | undefined>;
  /**
   * Signal input for the `formatter` property.
   *
   * @public
   */
  readonly formatter: InputSignal<RichTextBoxElement['formatter'] | undefined>;
  /**
   * Signal input for the `parser` property.
   *
   * @public
   */
  readonly parser: InputSignal<RichTextBoxElement['parser'] | undefined>;
  /**
   * Signal input for the `isFocused` property.
   *
   * @public
   */
  readonly isFocused: InputSignal<RichTextBoxElement['isFocused'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<RichTextBoxElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<RichTextBoxElement['lang'] | undefined>;
  /**
   * Output signal for the `editorStateChanged` event.
   *
   * @public
   */
  readonly editorStateChanged: OutputEmitterRef<ElementEventDetail<RichTextBoxElement, 'editorStateChanged'>>;
  /**
   * Output signal for the `documentChanged` event.
   *
   * @public
   */
  readonly documentChanged: OutputEmitterRef<ElementEventDetail<RichTextBoxElement, 'documentChanged'>>;
  /**
   * Output signal for the `suggestionSelected` event.
   *
   * @public
   */
  readonly suggestionSelected: OutputEmitterRef<ElementEventDetail<RichTextBoxElement, 'suggestionSelected'>>;
  /**
   * Output signal for the `submitRequested` event.
   *
   * @public
   */
  readonly submitRequested: OutputEmitterRef<ElementEventDetail<RichTextBoxElement, 'submitRequested'>>;
  /**
   * Output signal for the `linkRequested` event.
   *
   * @public
   */
  readonly linkRequested: OutputEmitterRef<ElementEventDetail<RichTextBoxElement, 'linkRequested'>>;
  /**
   * Output signal for the `cleared` event.
   *
   * @public
   */
  readonly cleared: OutputEmitterRef<ElementEventDetail<RichTextBoxElement, 'cleared'>>;
  /**
   * Output signal for the `input` event.
   *
   * @public
   */
  readonly input: OutputEmitterRef<ElementEventDetail<RichTextBoxElement, 'input'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<RichTextBoxElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<RichTextBoxElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<RichTextBoxElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: RichTextBoxElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: RichTextBoxElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  private readonly _accessor;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Applies a value supplied by Angular forms to the native control.
   *
   * @public
   */
  writeValue(obj: unknown): void;
  /**
   * Registers the callback notified when the native control value changes.
   *
   * @public
   */
  registerOnChange(fn: unknown): void;
  /**
   * Registers the callback notified when the native control is touched.
   *
   * @public
   */
  registerOnTouched(fn: unknown): void;
  /**
   * Applies the disabled state supplied by Angular forms.
   *
   * @public
   */
  setDisabledState?(isDisabled: boolean): void;
  /**
   * Executes a formatting, history or optional extension command.
   *
   * @public
   */
  command(...args: Parameters<RichTextBoxElement['command']>): ReturnType<RichTextBoxElement['command']>;
  /**
   * Whether a command can execute at the current selection.
   *
   * @public
   */
  canCommand(...args: Parameters<RichTextBoxElement['canCommand']>): ReturnType<RichTextBoxElement['canCommand']>;
  /**
   * Whether formatting is active at the current selection.
   *
   * @public
   */
  isCommandActive(...args: Parameters<RichTextBoxElement['isCommandActive']>): ReturnType<RichTextBoxElement['isCommandActive']>;
  /**
   * Selects document positions without exposing the editor SDK.
   *
   * @public
   */
  select(...args: Parameters<RichTextBoxElement['select']>): ReturnType<RichTextBoxElement['select']>;
  /**
   * Focuses the original RichTextBox editor surface.
   *
   * @public
   */
  focus(...args: Parameters<RichTextBoxElement['focus']>): ReturnType<RichTextBoxElement['focus']>;
  /**
   * Blurs the editor surface.
   *
   * @public
   */
  blur(...args: Parameters<RichTextBoxElement['blur']>): ReturnType<RichTextBoxElement['blur']>;
  /**
   * Attaches this RichTextBox to an official Prompt Box editor slot.
   *
   * @public
   */
  attachPromptBox(...args: Parameters<RichTextBoxElement['attachPromptBox']>): ReturnType<RichTextBoxElement['attachPromptBox']>;
  /**
   * Resets the original value and validation state.
   *
   * @public
   */
  reset(...args: Parameters<RichTextBoxElement['reset']>): ReturnType<RichTextBoxElement['reset']>;
  /**
   * Clears content through the existing Clearable behavior.
   *
   * @public
   */
  clear(...args: Parameters<RichTextBoxElement['clear']>): ReturnType<RichTextBoxElement['clear']>;
  /**
   * Checks text constraints against the actual rich document, rather than hidden native controls.
   *
   * @public
   */
  checkValidity(...args: Parameters<RichTextBoxElement['checkValidity']>): ReturnType<RichTextBoxElement['checkValidity']>;
  /**
   * Chooses a suggestion without moving keyboard focus to the popup.
   *
   * @public
   */
  chooseSuggestion(...args: Parameters<RichTextBoxElement['chooseSuggestion']>): ReturnType<RichTextBoxElement['chooseSuggestion']>;
  /**
   * Closes the optional suggestion session.
   *
   * @public
   */
  dismissSuggestions(...args: Parameters<RichTextBoxElement['dismissSuggestions']>): ReturnType<RichTextBoxElement['dismissSuggestions']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<RichTextBoxElement['assignToSlot']>): ReturnType<RichTextBoxElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<RichTextBoxElement['getSlotContent']>): ReturnType<RichTextBoxElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<RichTextBoxElement['hasSlotContent']>): ReturnType<RichTextBoxElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<RichTextBoxElement['hasSlot']>): ReturnType<RichTextBoxElement['hasSlot']>;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<RichTextBoxElement['onSlotChanges']>): ReturnType<RichTextBoxElement['onSlotChanges']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `command()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * The other names it accepts are not public in the type declarations of `RichTextBoxElement`.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends RichTextBoxMethodNames>(method: TMethod, ...args: Parameters<RichTextBoxComponentMethods[TMethod]>): ReturnType<RichTextBoxComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof RichTextBoxElement>(property: TProperty, value: RichTextBoxElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<RichTextBoxElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<RichTextBoxComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<RichTextBoxComponent, "mosaik-richtextbox", never, {
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "readonly": {
      "alias": "readonly";
      "required": false;
      "isSignal": true;
    };
    "required": {
      "alias": "required";
      "required": false;
      "isSignal": true;
    };
    "autofocus": {
      "alias": "autofocus";
      "required": false;
      "isSignal": true;
    };
    "name": {
      "alias": "name";
      "required": false;
      "isSignal": true;
    };
    "pattern": {
      "alias": "pattern";
      "required": false;
      "isSignal": true;
    };
    "placeholder": {
      "alias": "placeholder";
      "required": false;
      "isSignal": true;
    };
    "autocomplete": {
      "alias": "autocomplete";
      "required": false;
      "isSignal": true;
    };
    "minlength": {
      "alias": "minlength";
      "required": false;
      "isSignal": true;
    };
    "maxlength": {
      "alias": "maxlength";
      "required": false;
      "isSignal": true;
    };
    "multilineRows": {
      "alias": "multilineRows";
      "required": false;
      "isSignal": true;
    };
    "resize": {
      "alias": "resize";
      "required": false;
      "isSignal": true;
    };
    "showToolbar": {
      "alias": "showToolbar";
      "required": false;
      "isSignal": true;
    };
    "showToolbox": {
      "alias": "showToolbox";
      "required": false;
      "isSignal": true;
    };
    "submitOnEnter": {
      "alias": "submitOnEnter";
      "required": false;
      "isSignal": true;
    };
    "plainTextPaste": {
      "alias": "plainTextPaste";
      "required": false;
      "isSignal": true;
    };
    "extensions": {
      "alias": "extensions";
      "required": false;
      "isSignal": true;
    };
    "suggestions": {
      "alias": "suggestions";
      "required": false;
      "isSignal": true;
    };
    "mentionDocument": {
      "alias": "mentionDocument";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "isClearable": {
      "alias": "isClearable";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "invalid": {
      "alias": "invalid";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "formatter": {
      "alias": "formatter";
      "required": false;
      "isSignal": true;
    };
    "parser": {
      "alias": "parser";
      "required": false;
      "isSignal": true;
    };
    "isFocused": {
      "alias": "isFocused";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "editorStateChanged": "editorStateChanged";
    "documentChanged": "documentChanged";
    "suggestionSelected": "suggestionSelected";
    "submitRequested": "submitRequested";
    "linkRequested": "linkRequested";
    "cleared": "cleared";
    "input": "input";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, [{
    directive: typeof i1.FormStatusHostDirective;
    inputs: {};
    outputs: {};
  }, {
    directive: typeof i1.FormFieldStatusHostDirective;
    inputs: {};
    outputs: {};
  }]>;
}
/**
 * Declares the methods available on RichTextBoxComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type RichTextBoxMethodNames = 'command' | 'canCommand' | 'isCommandActive' | 'select' | 'focus' | 'blur' | 'attachPromptBox' | 'reset' | 'clear' | 'checkValidity' | 'chooseSuggestion' | 'dismissSuggestions' | 'onFocus' | 'onBlur' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges';
/**
 * Declares the methods interface for RichTextBoxComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type RichTextBoxComponentMethods = MethodMap<RichTextBoxMethodNames>;
/**
 * @public
 */
export declare function provideRichTextBoxComponent(config?: Partial<RichTextBoxElement.Props>, intl?: Partial<RichTextBoxElement['intl']> | Type<Partial<RichTextBoxElement['intl']>>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-rich-textbox.d.ts.map