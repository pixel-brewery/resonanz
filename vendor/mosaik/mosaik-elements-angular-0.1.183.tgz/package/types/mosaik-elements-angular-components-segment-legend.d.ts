import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { SegmentLegendItemElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/ranges/segment-legend/SegmentLegendItemElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { SegmentLegendElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/ranges/segment-legend/SegmentLegendElement";
/**
 * @public
 *
 * Injection token for the default properties of the SegmentLegendItemComponent.
 * Use this token to provide default properties for the SegmentLegendItemComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const SEGMENT_LEGEND_ITEM_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/ranges/segment-legend/ISegmentLegendItemElementProps").ISegmentLegendItemElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class SegmentLegendItemComponent {
  /**
   * Signal input for the `valueText` property.
   *
   * @public
   */
  readonly valueText: InputSignal<SegmentLegendItemElement['valueText'] | undefined>;
  /**
   * Signal input for the `markerFill` property.
   *
   * @public
   */
  readonly markerFill: InputSignal<SegmentLegendItemElement['markerFill'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<SegmentLegendItemElement['themeName'] | undefined>;
  /**
   * Signal input for the `for` property.
   *
   * @public
   */
  readonly for: InputSignal<SegmentLegendItemElement['for'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<SegmentLegendItemElement['variant'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<SegmentLegendItemElement['label'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<SegmentLegendItemElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<SegmentLegendItemElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<SegmentLegendItemElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<SegmentLegendItemElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<SegmentLegendItemElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Calls `attach` on the `mosaik-segment-legend-item` element.
   *
   * @public
   * @param args - The arguments of `attach`:
   * - `control` - The control or id to attach.
   */
  attach(...args: Parameters<SegmentLegendItemElement['attach']>): ReturnType<SegmentLegendItemElement['attach']>;
  /**
   * Calls `detach` on the `mosaik-segment-legend-item` element.
   *
   * @public
   */
  detach(...args: Parameters<SegmentLegendItemElement['detach']>): ReturnType<SegmentLegendItemElement['detach']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `attach()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends SegmentLegendItemMethodNames>(method: TMethod, ...args: Parameters<SegmentLegendItemComponentMethods[TMethod]>): ReturnType<SegmentLegendItemComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof SegmentLegendItemElement>(property: TProperty, value: SegmentLegendItemElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<SegmentLegendItemElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SegmentLegendItemComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SegmentLegendItemComponent, "mosaik-segment-legend-item", never, {
    "valueText": {
      "alias": "valueText";
      "required": false;
      "isSignal": true;
    };
    "markerFill": {
      "alias": "markerFill";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "for": {
      "alias": "for";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on SegmentLegendItemComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SegmentLegendItemMethodNames = 'attach' | 'detach';
/**
 * Declares the methods interface for SegmentLegendItemComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SegmentLegendItemComponentMethods = MethodMap<SegmentLegendItemMethodNames>;
/**
 * @public
 */
export declare function provideSegmentLegendItemComponent(config?: Partial<SegmentLegendItemElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the SegmentLegendComponent.
 * Use this token to provide default properties for the SegmentLegendComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const SEGMENT_LEGEND_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/ranges/segment-legend/ISegmentLegendElementProps").ISegmentLegendElementProps>>;
/**
 * @public
 *
 * @slot  - Segment legend items
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class SegmentLegendComponent {
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<SegmentLegendElement['themeName'] | undefined>;
  /**
   * Signal input for the `orientation` property.
   *
   * @public
   */
  readonly orientation: InputSignal<SegmentLegendElement['orientation'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<SegmentLegendElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<SegmentLegendElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<SegmentLegendElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<SegmentLegendElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<SegmentLegendElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof SegmentLegendElement>(property: TProperty, value: SegmentLegendElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<SegmentLegendElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SegmentLegendComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SegmentLegendComponent, "mosaik-segment-legend", never, {
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "orientation": {
      "alias": "orientation";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on SegmentLegendComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SegmentLegendMethodNames = never;
/**
 * Declares the methods interface for SegmentLegendComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SegmentLegendComponentMethods = MethodMap<SegmentLegendMethodNames>;
/**
 * @public
 */
export declare function provideSegmentLegendComponent(config?: Partial<SegmentLegendElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-segment-legend.d.ts.map