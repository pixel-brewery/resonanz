import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { ControlValueAccessor } from "@angular/forms";
import { CheckBoxGroupElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/check-box/CheckBoxGroupElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import * as i1 from "@pixel-brewery/mosaik-elements-angular/runtime";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { CheckboxElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/check-box/CheckBoxElement";
/**
 * @public
 *
 * Injection token for the default properties of the CheckBoxGroupComponent.
 * Use this token to provide default properties for the CheckBoxGroupComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const CHECK_BOX_GROUP_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/inputs/check-box/ICheckBoxGroupElementProps").ICheckBoxGroupElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class CheckBoxGroupComponent implements ControlValueAccessor {
  /**
   * Signal input for the `name` property.
   *
   * @public
   */
  readonly name: InputSignal<CheckBoxGroupElement['name'] | undefined>;
  /**
   * Signal input for the `required` property.
   *
   * @public
   */
  readonly required: InputSignal<CheckBoxGroupElement['required'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<CheckBoxGroupElement['themeName'] | undefined>;
  /**
   * Signal input for the `invalid` property.
   *
   * @public
   */
  readonly invalid: InputSignal<CheckBoxGroupElement['invalid'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<CheckBoxGroupElement['disabled'] | undefined>;
  /**
   * Signal input for the `orientation` property.
   *
   * @public
   */
  readonly orientation: InputSignal<CheckBoxGroupElement['orientation'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<CheckBoxGroupElement['value'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<CheckBoxGroupElement['appearance'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<CheckBoxGroupElement['variant'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<CheckBoxGroupElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<CheckBoxGroupElement['lang'] | undefined>;
  /**
   * Output signal for the `checkChanged` event.
   *
   * @public
   */
  readonly checkChanged: OutputEmitterRef<ElementEventDetail<CheckBoxGroupElement, 'checkChanged'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<CheckBoxGroupElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<CheckBoxGroupElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<CheckBoxGroupElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: CheckBoxGroupElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: CheckBoxGroupElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  private readonly _accessor;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Applies a value supplied by Angular forms to the native control.
   *
   * @public
   */
  writeValue(obj: unknown): void;
  /**
   * Registers the callback notified when the native control value changes.
   *
   * @public
   */
  registerOnChange(fn: unknown): void;
  /**
   * Registers the callback notified when the native control is touched.
   *
   * @public
   */
  registerOnTouched(fn: unknown): void;
  /**
   * Applies the disabled state supplied by Angular forms.
   *
   * @public
   */
  setDisabledState?(isDisabled: boolean): void;
  /**
   * Checks all checkboxes in the group.
   *
   * @public
   */
  checkAll(...args: Parameters<CheckBoxGroupElement['checkAll']>): ReturnType<CheckBoxGroupElement['checkAll']>;
  /**
   * Unchecks all checkboxes in the group.
   *
   * @public
   */
  uncheckAll(...args: Parameters<CheckBoxGroupElement['uncheckAll']>): ReturnType<CheckBoxGroupElement['uncheckAll']>;
  /**
   * Returns whether a form will validate when it is submitted, without having to submit it.
   *
   * @public
   */
  checkValidity(...args: Parameters<CheckBoxGroupElement['checkValidity']>): ReturnType<CheckBoxGroupElement['checkValidity']>;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<CheckBoxGroupElement['onSlotChanges']>): ReturnType<CheckBoxGroupElement['onSlotChanges']>;
  /**
   * Resets the element to its initial state.
   *
   * @public
   */
  reset(...args: Parameters<CheckBoxGroupElement['reset']>): ReturnType<CheckBoxGroupElement['reset']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<CheckBoxGroupElement['assignToSlot']>): ReturnType<CheckBoxGroupElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<CheckBoxGroupElement['getSlotContent']>): ReturnType<CheckBoxGroupElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<CheckBoxGroupElement['hasSlotContent']>): ReturnType<CheckBoxGroupElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<CheckBoxGroupElement['hasSlot']>): ReturnType<CheckBoxGroupElement['hasSlot']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `checkAll()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends CheckBoxGroupMethodNames>(method: TMethod, ...args: Parameters<CheckBoxGroupComponentMethods[TMethod]>): ReturnType<CheckBoxGroupComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof CheckBoxGroupElement>(property: TProperty, value: CheckBoxGroupElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<CheckBoxGroupElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<CheckBoxGroupComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<CheckBoxGroupComponent, "mosaik-checkbox-group", never, {
    "name": {
      "alias": "name";
      "required": false;
      "isSignal": true;
    };
    "required": {
      "alias": "required";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "invalid": {
      "alias": "invalid";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "orientation": {
      "alias": "orientation";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "checkChanged": "checkChanged";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, [{
    directive: typeof i1.FormStatusHostDirective;
    inputs: {};
    outputs: {};
  }, {
    directive: typeof i1.FormFieldStatusHostDirective;
    inputs: {};
    outputs: {};
  }]>;
}
/**
 * Declares the methods available on CheckBoxGroupComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type CheckBoxGroupMethodNames = 'checkAll' | 'uncheckAll' | 'checkValidity' | 'onSlotChanges' | 'reset' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot';
/**
 * Declares the methods interface for CheckBoxGroupComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type CheckBoxGroupComponentMethods = MethodMap<CheckBoxGroupMethodNames>;
/**
 * @public
 */
export declare function provideCheckBoxGroupComponent(config?: Partial<CheckBoxGroupElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the CheckboxComponent.
 * Use this token to provide default properties for the CheckboxComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const CHECKBOX_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/inputs/check-box/ICheckboxElementProps").ICheckboxElementProps>>;
/**
 * @public
 *
 * @slot checkmark - The checkmark slot.
 * @slot label - The label slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class CheckboxComponent implements ControlValueAccessor {
  /**
   * Signal input for the `labelPosition` property.
   *
   * @public
   */
  readonly labelPosition: InputSignal<CheckboxElement['labelPosition'] | undefined>;
  /**
   * Signal input for the `required` property.
   *
   * @public
   */
  readonly required: InputSignal<CheckboxElement['required'] | undefined>;
  /**
   * Signal input for the `name` property.
   *
   * @public
   */
  readonly name: InputSignal<CheckboxElement['name'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<CheckboxElement['themeName'] | undefined>;
  /**
   * Signal input for the `invalid` property.
   *
   * @public
   */
  readonly invalid: InputSignal<CheckboxElement['invalid'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<CheckboxElement['value'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<CheckboxElement['variant'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<CheckboxElement['appearance'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<CheckboxElement['disabled'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<CheckboxElement['label'] | undefined>;
  /**
   * Signal input for the `formatter` property.
   *
   * @public
   */
  readonly formatter: InputSignal<CheckboxElement['formatter'] | undefined>;
  /**
   * Signal input for the `isChecked` property.
   *
   * @public
   */
  readonly isChecked: InputSignal<CheckboxElement['isChecked'] | undefined>;
  /**
   * Signal input for the `isThreeState` property.
   *
   * @public
   */
  readonly isThreeState: InputSignal<CheckboxElement['isThreeState'] | undefined>;
  /**
   * Signal input for the `isFocused` property.
   *
   * @public
   */
  readonly isFocused: InputSignal<CheckboxElement['isFocused'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<CheckboxElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<CheckboxElement['lang'] | undefined>;
  /**
   * Output signal for the `checked` event.
   *
   * @public
   */
  readonly checked: OutputEmitterRef<ElementEventDetail<CheckboxElement, 'checked'>>;
  /**
   * Output signal for the `unchecked` event.
   *
   * @public
   */
  readonly unchecked: OutputEmitterRef<ElementEventDetail<CheckboxElement, 'unchecked'>>;
  /**
   * Output signal for the `indeterminate` event.
   *
   * @public
   */
  readonly indeterminate: OutputEmitterRef<ElementEventDetail<CheckboxElement, 'indeterminate'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<CheckboxElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<CheckboxElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<CheckboxElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  private readonly _accessor;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Applies a value supplied by Angular forms to the native control.
   *
   * @public
   */
  writeValue(obj: unknown): void;
  /**
   * Registers the callback notified when the native control value changes.
   *
   * @public
   */
  registerOnChange(fn: unknown): void;
  /**
   * Registers the callback notified when the native control is touched.
   *
   * @public
   */
  registerOnTouched(fn: unknown): void;
  /**
   * Applies the disabled state supplied by Angular forms.
   *
   * @public
   */
  setDisabledState?(isDisabled: boolean): void;
  /**
   * Resets the element to its initial state.
   *
   * @public
   */
  reset(...args: Parameters<CheckboxElement['reset']>): ReturnType<CheckboxElement['reset']>;
  /**
   * Checks the validity of the element and returns `true` if it is valid; otherwise, `false`.
   *
   * @public
   */
  checkValidity(...args: Parameters<CheckboxElement['checkValidity']>): ReturnType<CheckboxElement['checkValidity']>;
  /**
   * Calls `check` on the `mosaik-checkbox` element.
   *
   * @public
   */
  check(...args: Parameters<CheckboxElement['check']>): ReturnType<CheckboxElement['check']>;
  /**
   * Calls `uncheck` on the `mosaik-checkbox` element.
   *
   * @public
   */
  uncheck(...args: Parameters<CheckboxElement['uncheck']>): ReturnType<CheckboxElement['uncheck']>;
  /**
   * Toggles the element between checked and unchecked states.
   *
   * @public
   */
  toggle(...args: Parameters<CheckboxElement['toggle']>): ReturnType<CheckboxElement['toggle']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `reset()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends CheckboxMethodNames>(method: TMethod, ...args: Parameters<CheckboxComponentMethods[TMethod]>): ReturnType<CheckboxComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof CheckboxElement>(property: TProperty, value: CheckboxElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<CheckboxElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<CheckboxComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<CheckboxComponent, "mosaik-checkbox", never, {
    "labelPosition": {
      "alias": "labelPosition";
      "required": false;
      "isSignal": true;
    };
    "required": {
      "alias": "required";
      "required": false;
      "isSignal": true;
    };
    "name": {
      "alias": "name";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "invalid": {
      "alias": "invalid";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "formatter": {
      "alias": "formatter";
      "required": false;
      "isSignal": true;
    };
    "isChecked": {
      "alias": "isChecked";
      "required": false;
      "isSignal": true;
    };
    "isThreeState": {
      "alias": "isThreeState";
      "required": false;
      "isSignal": true;
    };
    "isFocused": {
      "alias": "isFocused";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "checked": "checked";
    "unchecked": "unchecked";
    "indeterminate": "indeterminate";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, [{
    directive: typeof i1.FormStatusHostDirective;
    inputs: {};
    outputs: {};
  }, {
    directive: typeof i1.FormFieldStatusHostDirective;
    inputs: {};
    outputs: {};
  }]>;
}
/**
 * Declares the methods available on CheckboxComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type CheckboxMethodNames = 'reset' | 'checkValidity' | 'check' | 'uncheck' | 'toggle';
/**
 * Declares the methods interface for CheckboxComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type CheckboxComponentMethods = MethodMap<CheckboxMethodNames>;
/**
 * @public
 */
export declare function provideCheckboxComponent(config?: Partial<CheckboxElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-check-box.d.ts.map