import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { DropdownAnchorElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/dropdown/DropdownAnchorElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { DropdownPanelElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/dropdown/DropdownPanelElement";
import { DropdownElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/dropdown/DropdownElement";
/**
 * @public
 *
 * Injection token for the default properties of the DropdownAnchorComponent.
 * Use this token to provide default properties for the DropdownAnchorComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const DROPDOWN_ANCHOR_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/primitives/dropdown/IDropdownAnchorElementProps").IDropdownAnchorElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot for anchor content.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class DropdownAnchorComponent {
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<DropdownAnchorElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<DropdownAnchorElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<DropdownAnchorElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<DropdownAnchorElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<DropdownAnchorElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<DropdownAnchorElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof DropdownAnchorElement>(property: TProperty, value: DropdownAnchorElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<DropdownAnchorElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<DropdownAnchorComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<DropdownAnchorComponent, "mosaik-dropdown-anchor", never, {
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on DropdownAnchorComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type DropdownAnchorMethodNames = never;
/**
 * Declares the methods interface for DropdownAnchorComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type DropdownAnchorComponentMethods = MethodMap<DropdownAnchorMethodNames>;
/**
 * @public
 */
export declare function provideDropdownAnchorComponent(config?: Partial<DropdownAnchorElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the DropdownPanelComponent.
 * Use this token to provide default properties for the DropdownPanelComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const DROPDOWN_PANEL_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/primitives/dropdown/IDropdownPanelElementProps").IDropdownPanelElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot for panel content.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class DropdownPanelComponent {
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<DropdownPanelElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<DropdownPanelElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<DropdownPanelElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<DropdownPanelElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<DropdownPanelElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<DropdownPanelElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof DropdownPanelElement>(property: TProperty, value: DropdownPanelElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<DropdownPanelElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<DropdownPanelComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<DropdownPanelComponent, "mosaik-dropdown-panel", never, {
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on DropdownPanelComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type DropdownPanelMethodNames = never;
/**
 * Declares the methods interface for DropdownPanelComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type DropdownPanelComponentMethods = MethodMap<DropdownPanelMethodNames>;
/**
 * @public
 */
export declare function provideDropdownPanelComponent(config?: Partial<DropdownPanelElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the DropdownComponent.
 * Use this token to provide default properties for the DropdownComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const DROPDOWN_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").IDropdownElementProps>>;
/**
 * @public
 *
 * @slot anchor - The anchor content that triggers the dropdown.
 * @slot panel - The floating panel content.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class DropdownComponent {
  /**
   * Signal input for the `placement` property.
   *
   * @public
   */
  readonly placement: InputSignal<DropdownElement['placement'] | undefined>;
  /**
   * Signal input for the `strategy` property.
   *
   * @public
   */
  readonly strategy: InputSignal<DropdownElement['strategy'] | undefined>;
  /**
   * Signal input for the `offset` property.
   *
   * @public
   */
  readonly offset: InputSignal<DropdownElement['offset'] | undefined>;
  /**
   * Signal input for the `skidding` property.
   *
   * @public
   */
  readonly skidding: InputSignal<DropdownElement['skidding'] | undefined>;
  /**
   * Signal input for the `open` property.
   *
   * @public
   */
  readonly open: InputSignal<DropdownElement['open'] | undefined>;
  /**
   * Signal input for the `trigger` property.
   *
   * @public
   */
  readonly trigger: InputSignal<DropdownElement['trigger'] | undefined>;
  /**
   * Signal input for the `closeOnOutsideClick` property.
   *
   * @public
   */
  readonly closeOnOutsideClick: InputSignal<DropdownElement['closeOnOutsideClick'] | undefined>;
  /**
   * Signal input for the `closeOnEscape` property.
   *
   * @public
   */
  readonly closeOnEscape: InputSignal<DropdownElement['closeOnEscape'] | undefined>;
  /**
   * Signal input for the `closeOnSelect` property.
   *
   * @public
   */
  readonly closeOnSelect: InputSignal<DropdownElement['closeOnSelect'] | undefined>;
  /**
   * Signal input for the `restoreFocus` property.
   *
   * @public
   */
  readonly restoreFocus: InputSignal<DropdownElement['restoreFocus'] | undefined>;
  /**
   * Signal input for the `hasPopup` property.
   *
   * @public
   */
  readonly hasPopup: InputSignal<DropdownElement['hasPopup'] | undefined>;
  /**
   * Signal input for the `matchAnchorWidth` property.
   *
   * @public
   */
  readonly matchAnchorWidth: InputSignal<DropdownElement['matchAnchorWidth'] | undefined>;
  /**
   * Signal input for the `maxHeight` property.
   *
   * @public
   */
  readonly maxHeight: InputSignal<DropdownElement['maxHeight'] | undefined>;
  /**
   * Signal input for the `height` property.
   *
   * @public
   */
  readonly height: InputSignal<DropdownElement['height'] | undefined>;
  /**
   * Signal input for the `width` property.
   *
   * @public
   */
  readonly width: InputSignal<DropdownElement['width'] | undefined>;
  /**
   * Signal input for the `maxWidth` property.
   *
   * @public
   */
  readonly maxWidth: InputSignal<DropdownElement['maxWidth'] | undefined>;
  /**
   * Signal input for the `dropDownPlacement` property.
   *
   * @public
   */
  readonly dropDownPlacement: InputSignal<DropdownElement['dropDownPlacement'] | undefined>;
  /**
   * Signal input for the `dropDownStrategy` property.
   *
   * @public
   */
  readonly dropDownStrategy: InputSignal<DropdownElement['dropDownStrategy'] | undefined>;
  /**
   * Signal input for the `dropDownDistance` property.
   *
   * @public
   */
  readonly dropDownDistance: InputSignal<DropdownElement['dropDownDistance'] | undefined>;
  /**
   * Signal input for the `dropDownSkidding` property.
   *
   * @public
   */
  readonly dropDownSkidding: InputSignal<DropdownElement['dropDownSkidding'] | undefined>;
  /**
   * Signal input for the `dropDownStaysOpen` property.
   *
   * @public
   */
  readonly dropDownStaysOpen: InputSignal<DropdownElement['dropDownStaysOpen'] | undefined>;
  /**
   * Signal input for the `dropDownMaxHeight` property.
   *
   * @public
   */
  readonly dropDownMaxHeight: InputSignal<DropdownElement['dropDownMaxHeight'] | undefined>;
  /**
   * Signal input for the `dropDownHeight` property.
   *
   * @public
   */
  readonly dropDownHeight: InputSignal<DropdownElement['dropDownHeight'] | undefined>;
  /**
   * Signal input for the `dropDownMaxWidth` property.
   *
   * @public
   */
  readonly dropDownMaxWidth: InputSignal<DropdownElement['dropDownMaxWidth'] | undefined>;
  /**
   * Signal input for the `dropDownWidth` property.
   *
   * @public
   */
  readonly dropDownWidth: InputSignal<DropdownElement['dropDownWidth'] | undefined>;
  /**
   * Signal input for the `isDropDownOpen` property.
   *
   * @public
   */
  readonly isDropDownOpen: InputSignal<DropdownElement['isDropDownOpen'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<DropdownElement['themeName'] | undefined>;
  /**
   * Signal input for the `enter` property.
   *
   * @public
   */
  readonly enter: InputSignal<DropdownElement['enter'] | undefined>;
  /**
   * Signal input for the `exit` property.
   *
   * @public
   */
  readonly exit: InputSignal<DropdownElement['exit'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<DropdownElement['disabled'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<DropdownElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<DropdownElement['lang'] | undefined>;
  /**
   * Output signal for the `openChanged` event.
   *
   * @public
   */
  readonly openChanged: OutputEmitterRef<ElementEventDetail<DropdownElement, 'openChanged'>>;
  /**
   * Output signal for the `slotchange` event.
   *
   * @public
   */
  readonly slotchange: OutputEmitterRef<ElementEventDetail<DropdownElement, 'slotchange'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<DropdownElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<DropdownElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<DropdownElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Opens the dropdown.
   *
   * @public
   * @param args - The arguments of `openDropdown`:
   * - `reason` - The reason for opening.
   */
  openDropdown(...args: Parameters<DropdownElement['openDropdown']>): ReturnType<DropdownElement['openDropdown']>;
  /**
   * Closes the dropdown.
   *
   * @public
   * @param args - The arguments of `closeDropdown`:
   * - `reason` - The reason for closing.
   */
  closeDropdown(...args: Parameters<DropdownElement['closeDropdown']>): ReturnType<DropdownElement['closeDropdown']>;
  /**
   * Toggles the dropdown.
   *
   * @public
   * @param args - The arguments of `toggleDropdown`:
   * - `reason` - The reason for toggling.
   */
  toggleDropdown(...args: Parameters<DropdownElement['toggleDropdown']>): ReturnType<DropdownElement['toggleDropdown']>;
  /**
   * Updates the panel position. With native CSS Anchor Positioning,
   * this is usually not needed but serves as an imperative escape hatch.
   *
   * @public
   */
  updatePosition(...args: Parameters<DropdownElement['updatePosition']>): ReturnType<DropdownElement['updatePosition']>;
  /**
   * Calls `play` on the `mosaik-dropdown` element.
   *
   * @public
   */
  play(...args: Parameters<DropdownElement['play']>): ReturnType<DropdownElement['play']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `openDropdown()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends DropdownMethodNames>(method: TMethod, ...args: Parameters<DropdownComponentMethods[TMethod]>): ReturnType<DropdownComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof DropdownElement>(property: TProperty, value: DropdownElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<DropdownElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<DropdownComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<DropdownComponent, "mosaik-dropdown", never, {
    "placement": {
      "alias": "placement";
      "required": false;
      "isSignal": true;
    };
    "strategy": {
      "alias": "strategy";
      "required": false;
      "isSignal": true;
    };
    "offset": {
      "alias": "offset";
      "required": false;
      "isSignal": true;
    };
    "skidding": {
      "alias": "skidding";
      "required": false;
      "isSignal": true;
    };
    "open": {
      "alias": "open";
      "required": false;
      "isSignal": true;
    };
    "trigger": {
      "alias": "trigger";
      "required": false;
      "isSignal": true;
    };
    "closeOnOutsideClick": {
      "alias": "closeOnOutsideClick";
      "required": false;
      "isSignal": true;
    };
    "closeOnEscape": {
      "alias": "closeOnEscape";
      "required": false;
      "isSignal": true;
    };
    "closeOnSelect": {
      "alias": "closeOnSelect";
      "required": false;
      "isSignal": true;
    };
    "restoreFocus": {
      "alias": "restoreFocus";
      "required": false;
      "isSignal": true;
    };
    "hasPopup": {
      "alias": "hasPopup";
      "required": false;
      "isSignal": true;
    };
    "matchAnchorWidth": {
      "alias": "matchAnchorWidth";
      "required": false;
      "isSignal": true;
    };
    "maxHeight": {
      "alias": "maxHeight";
      "required": false;
      "isSignal": true;
    };
    "height": {
      "alias": "height";
      "required": false;
      "isSignal": true;
    };
    "width": {
      "alias": "width";
      "required": false;
      "isSignal": true;
    };
    "maxWidth": {
      "alias": "maxWidth";
      "required": false;
      "isSignal": true;
    };
    "dropDownPlacement": {
      "alias": "dropDownPlacement";
      "required": false;
      "isSignal": true;
    };
    "dropDownStrategy": {
      "alias": "dropDownStrategy";
      "required": false;
      "isSignal": true;
    };
    "dropDownDistance": {
      "alias": "dropDownDistance";
      "required": false;
      "isSignal": true;
    };
    "dropDownSkidding": {
      "alias": "dropDownSkidding";
      "required": false;
      "isSignal": true;
    };
    "dropDownStaysOpen": {
      "alias": "dropDownStaysOpen";
      "required": false;
      "isSignal": true;
    };
    "dropDownMaxHeight": {
      "alias": "dropDownMaxHeight";
      "required": false;
      "isSignal": true;
    };
    "dropDownHeight": {
      "alias": "dropDownHeight";
      "required": false;
      "isSignal": true;
    };
    "dropDownMaxWidth": {
      "alias": "dropDownMaxWidth";
      "required": false;
      "isSignal": true;
    };
    "dropDownWidth": {
      "alias": "dropDownWidth";
      "required": false;
      "isSignal": true;
    };
    "isDropDownOpen": {
      "alias": "isDropDownOpen";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "enter": {
      "alias": "enter";
      "required": false;
      "isSignal": true;
    };
    "exit": {
      "alias": "exit";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "openChanged": "openChanged";
    "slotchange": "slotchange";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on DropdownComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type DropdownMethodNames = 'openDropdown' | 'closeDropdown' | 'toggleDropdown' | 'updatePosition' | 'play';
/**
 * Declares the methods interface for DropdownComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type DropdownComponentMethods = MethodMap<DropdownMethodNames>;
/**
 * @public
 */
export declare function provideDropdownComponent(config?: Partial<DropdownElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-dropdown.d.ts.map