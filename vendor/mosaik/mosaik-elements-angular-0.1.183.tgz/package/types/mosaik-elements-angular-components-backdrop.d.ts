import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { BackdropElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/backdrop/BackdropElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the BackdropComponent.
 * Use this token to provide default properties for the BackdropComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const BACKDROP_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/primitives/backdrop/IBackdropElementProps").IBackdropElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class BackdropComponent {
  /**
   * Signal input for the `hidden` property.
   *
   * @public
   */
  readonly hidden: InputSignal<BackdropElement['hidden'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<BackdropElement['themeName'] | undefined>;
  /**
   * Signal input for the `enter` property.
   *
   * @public
   */
  readonly enter: InputSignal<BackdropElement['enter'] | undefined>;
  /**
   * Signal input for the `exit` property.
   *
   * @public
   */
  readonly exit: InputSignal<BackdropElement['exit'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<BackdropElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<BackdropElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<BackdropElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<BackdropElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<BackdropElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * A lifecycle hook that is invoked when the element is added to the DOM.
   *
   * @public
   */
  onEnterAnimation(...args: Parameters<BackdropElement['onEnterAnimation']>): ReturnType<BackdropElement['onEnterAnimation']>;
  /**
   * A lifecycle hook that is invoked when the element is removed from the DOM.
   *
   * @public
   */
  onExitAnimation(...args: Parameters<BackdropElement['onExitAnimation']>): ReturnType<BackdropElement['onExitAnimation']>;
  /**
   * Executes the animation.
   *
   * @public
   */
  play(...args: Parameters<BackdropElement['play']>): ReturnType<BackdropElement['play']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `onEnterAnimation()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends BackdropMethodNames>(method: TMethod, ...args: Parameters<BackdropComponentMethods[TMethod]>): ReturnType<BackdropComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof BackdropElement>(property: TProperty, value: BackdropElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<BackdropElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<BackdropComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<BackdropComponent, "mosaik-backdrop", never, {
    "hidden": {
      "alias": "hidden";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "enter": {
      "alias": "enter";
      "required": false;
      "isSignal": true;
    };
    "exit": {
      "alias": "exit";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on BackdropComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type BackdropMethodNames = 'onEnterAnimation' | 'onExitAnimation' | 'play';
/**
 * Declares the methods interface for BackdropComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type BackdropComponentMethods = MethodMap<BackdropMethodNames>;
/**
 * @public
 */
export declare function provideBackdropComponent(config?: Partial<BackdropElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-backdrop.d.ts.map