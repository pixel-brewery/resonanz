import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { MasonryElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/masonry/MasonryElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the MasonryComponent.
 * Use this token to provide default properties for the MasonryComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const MASONRY_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/layouts/masonry/IMasonryElementProps").IMasonryElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot for elements to be arranged in masonry layout.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class MasonryComponent {
  /**
   * Signal input for the `columns` property.
   *
   * @public
   */
  readonly columns: InputSignal<MasonryElement['columns'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<MasonryElement['themeName'] | undefined>;
  /**
   * Signal input for the `fit` property.
   *
   * @public
   */
  readonly fit: InputSignal<MasonryElement['fit'] | undefined>;
  /**
   * Signal input for the `gap` property.
   *
   * @public
   */
  readonly gap: InputSignal<MasonryElement['gap'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<MasonryElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<MasonryElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<MasonryElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<MasonryElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<MasonryElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof MasonryElement>(property: TProperty, value: MasonryElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<MasonryElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<MasonryComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<MasonryComponent, "mosaik-masonry", never, {
    "columns": {
      "alias": "columns";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "fit": {
      "alias": "fit";
      "required": false;
      "isSignal": true;
    };
    "gap": {
      "alias": "gap";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on MasonryComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type MasonryMethodNames = never;
/**
 * Declares the methods interface for MasonryComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type MasonryComponentMethods = MethodMap<MasonryMethodNames>;
/**
 * @public
 */
export declare function provideMasonryComponent(config?: Partial<MasonryElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-masonry.d.ts.map