import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { SwipeElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/swipe/SwipeElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the SwipeComponent.
 * Use this token to provide default properties for the SwipeComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const SWIPE_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/primitives/swipe/ISwipeElementProps").ISwipeElementProps>>;
/**
 * @public
 *
 * @slot  - The default content slot.
 * @slot after - The after swipe slot.
 * @slot before - The before swipe slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class SwipeComponent {
  /**
   * Signal input for the `panEndTriggeringThreshold` property.
   *
   * @public
   */
  readonly panEndTriggeringThreshold: InputSignal<SwipeElement['panEndTriggeringThreshold'] | undefined>;
  /**
   * Signal input for the `panLeftDisabled` property.
   *
   * @public
   */
  readonly panLeftDisabled: InputSignal<SwipeElement['panLeftDisabled'] | undefined>;
  /**
   * Signal input for the `panRightDisabled` property.
   *
   * @public
   */
  readonly panRightDisabled: InputSignal<SwipeElement['panRightDisabled'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<SwipeElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<SwipeElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<SwipeElement['lang'] | undefined>;
  /**
   * Output signal for the `swipeLeft` event.
   *
   * @public
   */
  readonly swipeLeft: OutputEmitterRef<ElementEventDetail<SwipeElement, 'swipeLeft'>>;
  /**
   * Output signal for the `swipeRight` event.
   *
   * @public
   */
  readonly swipeRight: OutputEmitterRef<ElementEventDetail<SwipeElement, 'swipeRight'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<SwipeElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<SwipeElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<SwipeElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Calls `panLeft` on the `mosaik-swipe` element.
   *
   * @public
   */
  panLeft(...args: Parameters<SwipeElement['panLeft']>): ReturnType<SwipeElement['panLeft']>;
  /**
   * Calls `panRight` on the `mosaik-swipe` element.
   *
   * @public
   */
  panRight(...args: Parameters<SwipeElement['panRight']>): ReturnType<SwipeElement['panRight']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `panLeft()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends SwipeMethodNames>(method: TMethod, ...args: Parameters<SwipeComponentMethods[TMethod]>): ReturnType<SwipeComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof SwipeElement>(property: TProperty, value: SwipeElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<SwipeElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SwipeComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SwipeComponent, "mosaik-swipe", never, {
    "panEndTriggeringThreshold": {
      "alias": "panEndTriggeringThreshold";
      "required": false;
      "isSignal": true;
    };
    "panLeftDisabled": {
      "alias": "panLeftDisabled";
      "required": false;
      "isSignal": true;
    };
    "panRightDisabled": {
      "alias": "panRightDisabled";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "swipeLeft": "swipeLeft";
    "swipeRight": "swipeRight";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on SwipeComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SwipeMethodNames = 'panLeft' | 'panRight';
/**
 * Declares the methods interface for SwipeComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SwipeComponentMethods = MethodMap<SwipeMethodNames>;
/**
 * @public
 */
export declare function provideSwipeComponent(config?: Partial<SwipeElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-swipe.d.ts.map