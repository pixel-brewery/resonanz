import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { TimelineContentElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/timeline/TimelineContentElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { TimelineItemElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/timeline/TimelineItemElement";
import { TimelineMarkerElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/timeline/TimelineMarkerElement";
import { TimelineOppositeElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/timeline/TimelineOppositeElement";
import { TimelineSeparatorElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/timeline/TimelineSeparatorElement";
import { TimelineElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/timeline/TimelineElement";
/**
 * @public
 *
 * Injection token for the default properties of the TimelineContentComponent.
 * Use this token to provide default properties for the TimelineContentComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const TIMELINE_CONTENT_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/media/timeline/ITimelineContentElementProps").ITimelineContentElementProps>>;
/**
 * @public
 *
 * @slot  - Default slot for primary timeline content.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class TimelineContentComponent {
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<TimelineContentElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<TimelineContentElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<TimelineContentElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<TimelineContentElement, 'connected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<TimelineContentElement, 'changed'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<TimelineContentElement, 'disconnected'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof TimelineContentElement>(property: TProperty, value: TimelineContentElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<TimelineContentElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<TimelineContentComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<TimelineContentComponent, "mosaik-timeline-content", never, {
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "changed": "changed";
    "disconnected": "disconnected";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on TimelineContentComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TimelineContentMethodNames = never;
/**
 * Declares the methods interface for TimelineContentComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TimelineContentComponentMethods = MethodMap<TimelineContentMethodNames>;
/**
 * @public
 */
export declare function provideTimelineContentComponent(config?: Partial<TimelineContentElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the TimelineItemComponent.
 * Use this token to provide default properties for the TimelineItemComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const TIMELINE_ITEM_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/media/timeline/ITimelineItemElementProps").ITimelineItemElementProps>>;
/**
 * @public
 *
 * @slot content - Required content slot for a `TimelineContentElement` representing the primary timeline information.
 * @slot marker - Optional marker slot. Accepts a `TimelineMarkerElement`. Defaults to an internally rendered marker when omitted.
 * @slot opposite - Optional slot for a `TimelineOppositeElement` positioned opposite the main content.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class TimelineItemComponent {
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<TimelineItemElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<TimelineItemElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<TimelineItemElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<TimelineItemElement, 'connected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<TimelineItemElement, 'changed'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<TimelineItemElement, 'disconnected'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof TimelineItemElement>(property: TProperty, value: TimelineItemElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<TimelineItemElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<TimelineItemComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<TimelineItemComponent, "mosaik-timeline-item", never, {
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "changed": "changed";
    "disconnected": "disconnected";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on TimelineItemComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TimelineItemMethodNames = never;
/**
 * Declares the methods interface for TimelineItemComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TimelineItemComponentMethods = MethodMap<TimelineItemMethodNames>;
/**
 * @public
 */
export declare function provideTimelineItemComponent(config?: Partial<TimelineItemElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the TimelineMarkerComponent.
 * Use this token to provide default properties for the TimelineMarkerComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const TIMELINE_MARKER_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/media/timeline/ITimelineMarkerElementProps").ITimelineMarkerElementProps>>;
/**
 * @public
 *
 * @slot  - Default slot for custom marker content. Overrides the internal pip when provided.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class TimelineMarkerComponent {
  /**
   * Signal input for the `text` property.
   *
   * @public
   */
  readonly text: InputSignal<TimelineMarkerElement['text'] | undefined>;
  /**
   * Signal input for the `icon` property.
   *
   * @public
   */
  readonly icon: InputSignal<TimelineMarkerElement['icon'] | undefined>;
  /**
   * Signal input for the `iconSize` property.
   *
   * @public
   */
  readonly iconSize: InputSignal<TimelineMarkerElement['iconSize'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<TimelineMarkerElement['themeName'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<TimelineMarkerElement['appearance'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<TimelineMarkerElement['variant'] | undefined>;
  /**
   * Signal input for the `size` property.
   *
   * @public
   */
  readonly size: InputSignal<TimelineMarkerElement['size'] | undefined>;
  /**
   * Signal input for the `isBusy` property.
   *
   * @public
   */
  readonly isBusy: InputSignal<TimelineMarkerElement['isBusy'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<TimelineMarkerElement['disabled'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<TimelineMarkerElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<TimelineMarkerElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<TimelineMarkerElement, 'connected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<TimelineMarkerElement, 'changed'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<TimelineMarkerElement, 'disconnected'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof TimelineMarkerElement>(property: TProperty, value: TimelineMarkerElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<TimelineMarkerElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<TimelineMarkerComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<TimelineMarkerComponent, "mosaik-timeline-marker", never, {
    "text": {
      "alias": "text";
      "required": false;
      "isSignal": true;
    };
    "icon": {
      "alias": "icon";
      "required": false;
      "isSignal": true;
    };
    "iconSize": {
      "alias": "iconSize";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "isBusy": {
      "alias": "isBusy";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "changed": "changed";
    "disconnected": "disconnected";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on TimelineMarkerComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TimelineMarkerMethodNames = never;
/**
 * Declares the methods interface for TimelineMarkerComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TimelineMarkerComponentMethods = MethodMap<TimelineMarkerMethodNames>;
/**
 * @public
 */
export declare function provideTimelineMarkerComponent(config?: Partial<TimelineMarkerElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the TimelineOppositeComponent.
 * Use this token to provide default properties for the TimelineOppositeComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const TIMELINE_OPPOSITE_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/media/timeline/ITimelineOppositeElementProps").ITimelineOppositeElementProps>>;
/**
 * @public
 *
 * @slot  - Default slot for opposite content.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class TimelineOppositeComponent {
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<TimelineOppositeElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<TimelineOppositeElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<TimelineOppositeElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<TimelineOppositeElement, 'connected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<TimelineOppositeElement, 'changed'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<TimelineOppositeElement, 'disconnected'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof TimelineOppositeElement>(property: TProperty, value: TimelineOppositeElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<TimelineOppositeElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<TimelineOppositeComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<TimelineOppositeComponent, "mosaik-timeline-opposite", never, {
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "changed": "changed";
    "disconnected": "disconnected";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on TimelineOppositeComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TimelineOppositeMethodNames = never;
/**
 * Declares the methods interface for TimelineOppositeComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TimelineOppositeComponentMethods = MethodMap<TimelineOppositeMethodNames>;
/**
 * @public
 */
export declare function provideTimelineOppositeComponent(config?: Partial<TimelineOppositeElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the TimelineSeparatorComponent.
 * Use this token to provide default properties for the TimelineSeparatorComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const TIMELINE_SEPARATOR_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/media/timeline/ITimelineSeparatorElementProps").ITimelineSeparatorElementProps>>;
/**
 * @public
 *
 * @slot  - Optional content replacing the visible label; label still names the separator for assistive technology.
 * @slot actions - Optional application-owned actions beside the boundary description.
 * @slot content - The content slot.
 * @slot marker - Optional custom marker replacing the default timeline marker.
 * @slot opposite - The opposite slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class TimelineSeparatorComponent {
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<TimelineSeparatorElement['label'] | undefined>;
  /**
   * Signal input for the `description` property.
   *
   * @public
   */
  readonly description: InputSignal<TimelineSeparatorElement['description'] | undefined>;
  /**
   * Signal input for the `icon` property.
   *
   * @public
   */
  readonly icon: InputSignal<TimelineSeparatorElement['icon'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<TimelineSeparatorElement['appearance'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<TimelineSeparatorElement['variant'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<TimelineSeparatorElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<TimelineSeparatorElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<TimelineSeparatorElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<TimelineSeparatorElement, 'connected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<TimelineSeparatorElement, 'changed'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<TimelineSeparatorElement, 'disconnected'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof TimelineSeparatorElement>(property: TProperty, value: TimelineSeparatorElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<TimelineSeparatorElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<TimelineSeparatorComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<TimelineSeparatorComponent, "mosaik-timeline-separator", never, {
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "description": {
      "alias": "description";
      "required": false;
      "isSignal": true;
    };
    "icon": {
      "alias": "icon";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "changed": "changed";
    "disconnected": "disconnected";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on TimelineSeparatorComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TimelineSeparatorMethodNames = never;
/**
 * Declares the methods interface for TimelineSeparatorComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TimelineSeparatorComponentMethods = MethodMap<TimelineSeparatorMethodNames>;
/**
 * @public
 */
export declare function provideTimelineSeparatorComponent(config?: Partial<TimelineSeparatorElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the TimelineComponent.
 * Use this token to provide default properties for the TimelineComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const TIMELINE_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/media/timeline/ITimelineElementProps").ITimelineElementProps>>;
/**
 * @public
 *
 * @slot  - Default slot for `TimelineItemElement` entries and `TimelineSeparatorElement` boundaries.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class TimelineComponent {
  /**
   * Signal input for the `align` property.
   *
   * @public
   */
  readonly align: InputSignal<TimelineElement['align'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<TimelineElement['themeName'] | undefined>;
  /**
   * Signal input for the `orientation` property.
   *
   * @public
   */
  readonly orientation: InputSignal<TimelineElement['orientation'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<TimelineElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<TimelineElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<TimelineElement, 'connected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<TimelineElement, 'changed'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<TimelineElement, 'disconnected'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof TimelineElement>(property: TProperty, value: TimelineElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<TimelineElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<TimelineComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<TimelineComponent, "mosaik-timeline", never, {
    "align": {
      "alias": "align";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "orientation": {
      "alias": "orientation";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "changed": "changed";
    "disconnected": "disconnected";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on TimelineComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TimelineMethodNames = never;
/**
 * Declares the methods interface for TimelineComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TimelineComponentMethods = MethodMap<TimelineMethodNames>;
/**
 * @public
 */
export declare function provideTimelineComponent(config?: Partial<TimelineElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-timeline.d.ts.map