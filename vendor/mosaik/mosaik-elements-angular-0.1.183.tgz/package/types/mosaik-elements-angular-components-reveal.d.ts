import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { RevealElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/illustrations/reveal/RevealElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the RevealComponent.
 * Use this token to provide default properties for the RevealComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const REVEAL_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").IRevealElementProps>>;
/**
 * @public
 *
 * @slot  - Readable content animated together as one stable layer.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class RevealComponent {
  /**
   * Signal input for the `effect` property.
   *
   * @public
   */
  readonly effect: InputSignal<RevealElement['effect'] | undefined>;
  /**
   * Signal input for the `repeat` property.
   *
   * @public
   */
  readonly repeat: InputSignal<RevealElement['repeat'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<RevealElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<RevealElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<RevealElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<RevealElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<RevealElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<RevealElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof RevealElement>(property: TProperty, value: RevealElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<RevealElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<RevealComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<RevealComponent, "mosaik-reveal", never, {
    "effect": {
      "alias": "effect";
      "required": false;
      "isSignal": true;
    };
    "repeat": {
      "alias": "repeat";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on RevealComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type RevealMethodNames = never;
/**
 * Declares the methods interface for RevealComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type RevealComponentMethods = MethodMap<RevealMethodNames>;
/**
 * @public
 */
export declare function provideRevealComponent(config?: Partial<RevealElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-reveal.d.ts.map