import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { SkeletonElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/skeleton/SkeletonElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the SkeletonComponent.
 * Use this token to provide default properties for the SkeletonComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const SKELETON_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/primitives/skeleton/ISkeletonElementProps").ISkeletonElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class SkeletonComponent {
  /**
   * Signal input for the `target` property.
   *
   * @public
   */
  readonly target: InputSignal<SkeletonElement['target'] | undefined>;
  /**
   * Signal input for the `shape` property.
   *
   * @public
   */
  readonly shape: InputSignal<SkeletonElement['shape'] | undefined>;
  /**
   * Signal input for the `shimmer` property.
   *
   * @public
   */
  readonly shimmer: InputSignal<SkeletonElement['shimmer'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<SkeletonElement['themeName'] | undefined>;
  /**
   * Signal input for the `width` property.
   *
   * @public
   */
  readonly width: InputSignal<SkeletonElement['width'] | undefined>;
  /**
   * Signal input for the `height` property.
   *
   * @public
   */
  readonly height: InputSignal<SkeletonElement['height'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<SkeletonElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<SkeletonElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<SkeletonElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<SkeletonElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<SkeletonElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof SkeletonElement>(property: TProperty, value: SkeletonElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<SkeletonElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SkeletonComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SkeletonComponent, "mosaik-skeleton", never, {
    "target": {
      "alias": "target";
      "required": false;
      "isSignal": true;
    };
    "shape": {
      "alias": "shape";
      "required": false;
      "isSignal": true;
    };
    "shimmer": {
      "alias": "shimmer";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "width": {
      "alias": "width";
      "required": false;
      "isSignal": true;
    };
    "height": {
      "alias": "height";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on SkeletonComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SkeletonMethodNames = never;
/**
 * Declares the methods interface for SkeletonComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SkeletonComponentMethods = MethodMap<SkeletonMethodNames>;
/**
 * @public
 */
export declare function provideSkeletonComponent(config?: Partial<SkeletonElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-skeleton.d.ts.map