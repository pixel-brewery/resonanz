import * as i0 from "@angular/core";
import { InjectionToken, OnInit, OutputEmitterRef, Signal } from "@angular/core";
import { FieldState } from "@angular/forms/signals";
import { ControlValueAccessor } from "@angular/forms";
import { IEventListenerSubscription } from "@pixel-brewery/mosaik-elements";
/**
 * Interface for Mosaik form field providers.
 * This is compatible with Angular's `FORM_FIELD` injection token but uses
 * Mosaik-specific types to avoid conflicts with Angular's `FormField` directive.
 *
 * @public
 */
export interface IFormField<T> {
  /**
   * The current field state, or null if not yet available.
   */
  readonly state: Signal<FieldState<T> | null>;
}
/**
 * Directive that bridges Angular Signal Forms with Mosaik form components.
 *
 * This directive provides the `FORM_FIELD` injection token and handles bidirectional
 * value synchronization between a Signal Forms `FieldState` and a Mosaik component
 * that implements `ControlValueAccessor`.
 *
 * @usage
 * ```html
 * <mosaik-textbox [formField]="form.username"></mosaik-textbox>
 * ```
 *
 * The directive will:
 * - Write values FROM the Signal Form TO the component via `writeValue()`
 * - Write values FROM the component TO the Signal Form via `registerOnChange()`
 * - Mark the field as touched via `registerOnTouched()`
 * - Provide `FORM_FIELD` so that `FormFieldStatusDirective` can sync the `invalid` state
 *
 * @remarks
 * This directive does NOT implement Angular's `FormField<T>` interface directly because
 * that interface has incompatible type signatures (e.g., `FieldTree<T>` vs `() => FieldState<T>`).
 * Instead, it provides the same `FORM_FIELD` token with a compatible shape.
 *
 * @public
 */
export declare class FormFieldDirective<T> implements IFormField<T> {
  private readonly _hostComponent;
  private _isWritingValue;
  constructor();
  /**
   * The Signal Forms field to bind to this component.
   *
   * @example
   * ```html
   * <mosaik-textbox [formField]="form.username"></mosaik-textbox>
   * ```
   *
   * @public
   */
  readonly formField: import("@angular/core").InputSignal<() => FieldState<T>>;
  /**
   * Computed state that provides the field state for `FormFieldStatusDirective`.
   * Returns null if the field function is not yet available.
   *
   * @public
   */
  readonly state: Signal<FieldState<T> | null>;
  static ɵfac: i0.ɵɵFactoryDeclaration<FormFieldDirective<any>, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<FormFieldDirective<any>, "[formField]", never, {
    "formField": {
      "alias": "formField";
      "required": true;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * Host directive (NO selector!) that synchronizes the `invalid` property
 * with a Signal Forms field's validation state.
 *
 * This directive is automatically activated as a hostDirective on Mosaik form components.
 * It injects `FORM_FIELD` (provided by {@link FormFieldDirective}) and updates
 * `host.invalid` based on `field.invalid() && field.touched()`.
 *
 * @remarks
 * This directive has NO selector intentionally - it only works as a hostDirective.
 * The `FormFieldDirective` (selector `[formField]`) provides the `FORM_FIELD` token.
 *
 * @public
 */
export declare class FormFieldStatusHostDirective {
  private readonly _host;
  private readonly _field;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<FormFieldStatusHostDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<FormFieldStatusHostDirective, never, never, {}, {}, never, never, true, never>;
}
/**
 * Contract used by Angular form-status synchronization.
 *
 * @public
 */
export interface IFormStatusHost extends ControlValueAccessor {
  /**
   * Writes a property directly to the wrapped Mosaik custom element.
   */
  setInput?<TValue>(property: 'invalid', value: TValue): void;
  /**
   * Legacy hosts may expose a writable invalid property instead of setInput.
   */
  invalid?: boolean | (() => boolean | undefined);
}
/**
 * Injection token for the form status host.
 *
 * @public
 */
export declare const FORM_STATUS_HOST: InjectionToken<IFormStatusHost>;
/**
 * Matches elements with one or more Angular form state classes:
 * `.ng-invalid`, `.ng-dirty`, or `.ng-touched`.
 * Injects `NgControl` for access to control state.
 *
 * @remarks
 * We need this internally to trigger set the invalid property on the native element.
 *
 * @public
 */
export declare class FormStatusHostDirective implements OnInit {
  private readonly _host;
  private readonly _ngControl;
  private readonly _destroyRef;
  /**
   * Constructs a new instance of the `FormStatusDirective` class.
   *
   * @public
   */
  constructor();
  /**
   * @public
   */
  ngOnInit(): void;
  /**
   * Invalidates the host element by setting the `invalid` property to `true` or `false`.
   *
   * @private
   */
  private invalidate;
  static ɵfac: i0.ɵɵFactoryDeclaration<FormStatusHostDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<FormStatusHostDirective, ".ng-invalid, .ng-dirty, .ng-touched", never, {}, {}, never, never, true, never>;
}
/**
 * Marks a framework-owned light-DOM root whose children are projected through
 * a Mosaik portal without being detached from their Angular render parent.
 *
 * @public
 */
export declare class PortalProjectionDirective {
  static ɵfac: i0.ɵɵFactoryDeclaration<PortalProjectionDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<PortalProjectionDirective, "[mosaikPortalProjection]", never, {}, {}, never, never, true, never>;
}
interface IProxyComponentConstructor extends Function {
  prototype: object;
}
interface IProxyElementRef {
  nativeElement: object;
}
interface IProxyZone {
  runOutsideAngular<TResult>(callback: IProxyZoneCallback<TResult>): TResult;
}
interface IProxyZoneCallback<TResult> {
  (): TResult;
}
interface IProxyHost {
  element?: object;
  elementRef?: IProxyElementRef;
  _elementRef?: IProxyElementRef;
  zone?: IProxyZone;
}
interface IProxyCmpOptions {
  defineCustomElementFn?(): void;
  inputs?: Array<string>;
  methods?: Array<string>;
}
interface IProxyMethod {
  (...args: Array<unknown>): unknown;
}
declare const blockedProxyMethodNames: readonly ["addController", "removeController", "addEventListener", "removeEventListener", "dispatchEvent", "connectedCallback", "disconnectedCallback", "attributeChangedCallback", "createRenderRoot", "performUpdate", "scheduleUpdate", "shouldUpdate", "willUpdate", "update", "updated", "firstUpdated", "render", "adoptStyle", "on", "off", "emit", "requestUpdate"];
type BlockedProxyMethodName = typeof blockedProxyMethodNames[number];
/**
 * Reads a public property from the element behind a framework component.
 *
 * @param target The component or element reference.
 * @param propertyName The element property to read.
 * @public
 */
export declare function readProxyProperty<TElement extends object, TName extends keyof TElement & string>(target: object | undefined, propertyName: TName): TElement[TName] | undefined;
/**
 * A utility function to proxy inputs of a custom element.
 *
 * @public
 */
declare const proxyInputs: (cmp: IProxyComponentConstructor, inputs: Array<string>) => void;
/**
 * A utility function to proxy methods of a custom element.
 *
 * @public
 */
declare const proxyMethods: (cmp: IProxyComponentConstructor, methods: Array<string>) => void;
/**
 * Invokes an exposed method on the proxied custom element.
 *
 * @public
 */
export declare function invokeProxyMethod<TMethod extends IProxyMethod = IProxyMethod>(target: IProxyHost | IProxyElementRef | object, methodName: string, ...args: Parameters<TMethod>): ReturnType<TMethod>;
/**
 * Resolves the parameters of an element method, also of one the element declares as optional.
 *
 * @public
 */
type ElementMethodParameters<TElement, TName extends keyof TElement> = NonNullable<TElement[TName]> extends ((...args: infer TArgs) => unknown) ? TArgs : never;
/**
 * Resolves the return type of an element method, also of one the element declares as optional.
 *
 * @public
 */
type ElementMethodReturnType<TElement, TName extends keyof TElement> = NonNullable<TElement[TName]> extends ((...args: never) => infer TReturn) ? TReturn : never;
/**
 * Invokes a method of the proxied custom element with the signature the element declares for it.
 * This is what the typed methods of the generated components call.
 *
 * It behaves like {@link invokeProxyMethod}: a method the element does not provide, because the
 * custom element is not upgraded while rendering on the server, resolves to `undefined`.
 *
 * @public
 */
export declare function invokeElementMethod<TElement extends object, TName extends keyof TElement & string>(element: TElement, methodName: TName, args: ElementMethodParameters<TElement, TName>): ElementMethodReturnType<TElement, TName>;
/**
 * Defines a custom element if it is not already defined.
 *
 * @param tagName - The name of the custom element.
 * @param customElement - The custom element class to define.
 *
 * @public
 */
export declare const defineCustomElement: (tagName: string, customElement: CustomElementConstructor | undefined) => void;
/**
 * The Angular outputs of a proxy component, by the names of the custom element events they forward.
 *
 * @public
 */
type ProxyOutputs = Readonly<Record<string, OutputEmitterRef<unknown>>>;
/**
 * Forwards the events the proxied custom element dispatches itself to the Angular outputs of the same name, so that an
 * Angular binding gets every event once.
 *
 * @remarks
 * Angular binds a template `(pressed)` on an element twice when a component on the element has an output of that name:
 * as DOM listener of the element and as subscriber of the output. Fed from the DOM event, the output would run the
 * handler a second time. The function forwards the element's own `CustomEvent`s to the outputs - their `detail`, as
 * before - and keeps the DOM listener of an Angular binding from handling an event that the same binding got through
 * the output already. Events of descendants, plain `Event`s and every other listener of the element stay untouched,
 * and the forwarding remains active while the element is disconnected or moved by a portal.
 *
 * The bindings are told apart by two Angular internals (`ANGULAR_UNWRAP_TOKEN`, `ANGULAR_NATIVE_ELEMENT_KEY`).
 * `Proxy.contract.spec.ts` checks both against the installed Angular version, so an upgrade that changes them fails the
 * tests instead of bringing the double calls back unnoticed.
 *
 * @returns The subscriptions of the forwarding, one per output - disposed with the component.
 * @public
 */
export declare function forwardProxyOutputs(target: HTMLElement, outputs: ProxyOutputs): ReadonlyArray<IEventListenerSubscription>;
/**
 * Decorator to define a custom element and proxy inputs and methods.
 *
 * @param opts - Options for the decorator.
 * @returns A class decorator function.
 *
 * @public
 */
export declare function ProxyCmp(opts: IProxyCmpOptions): ClassDecorator;
/**
 * Applies default values to the properties of an object.
 * Properties listed in `mergeKeys` will be shallow-merged via `Object.assign`
 * instead of replaced, which is required for pre-initialized object properties like `intl`.
 *
 * @public
 */
export declare function applyDefaults<T extends {}>(target: T, defaults: Partial<T>, mergeKeys?: Array<string>): void;
/**
 * Maps a list of method names to function types.
 *
 * @public
 */
type MethodMap<T extends string> = { [TMethod in T]: TMethod extends BlockedProxyMethodName ? never : IProxyMethod; };
export type { MethodMap };
//# sourceMappingURL=mosaik-elements-angular-runtime.d.ts.map