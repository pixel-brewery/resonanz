import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef, Type } from "@angular/core";
import { PaginatorElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/paginator/PaginatorElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the PaginatorComponent.
 * Use this token to provide default properties for the PaginatorComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const PAGINATOR_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/primitives/paginator/IPaginatorElementProps").IPaginatorElementProps>>;
/**
 * @public
 *
 * Injection token for the intl configuration of the PaginatorComponent.
 * Provide a partial intl object or an injectable class that resolves translations.
 * This allows third-party applications to override the default intl labels
 * globally, per route, or per component via Angular's dependency injection.
 *
 * Merge order: Foundation defaults → DI intl → [intl] input binding.
 */
export declare const PAGINATOR_INTL: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").PaginatorElementIntl>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class PaginatorComponent {
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<Partial<PaginatorElement['intl']> | undefined>;
  /**
   * Signal input for the `total` property.
   *
   * @public
   */
  readonly total: InputSignal<PaginatorElement['total'] | undefined>;
  /**
   * Signal input for the `totalRecords` property.
   *
   * @public
   */
  readonly totalRecords: InputSignal<PaginatorElement['totalRecords'] | undefined>;
  /**
   * Signal input for the `size` property.
   *
   * @public
   */
  readonly size: InputSignal<PaginatorElement['size'] | undefined>;
  /**
   * Signal input for the `rows` property.
   *
   * @public
   */
  readonly rows: InputSignal<PaginatorElement['rows'] | undefined>;
  /**
   * Signal input for the `sizes` property.
   *
   * @public
   */
  readonly sizes: InputSignal<PaginatorElement['sizes'] | undefined>;
  /**
   * Signal input for the `showSizes` property.
   *
   * @public
   */
  readonly showSizes: InputSignal<PaginatorElement['showSizes'] | undefined>;
  /**
   * Signal input for the `currentPage` property.
   *
   * @public
   */
  readonly currentPage: InputSignal<PaginatorElement['currentPage'] | undefined>;
  /**
   * Signal input for the `first` property.
   *
   * @public
   */
  readonly first: InputSignal<PaginatorElement['first'] | undefined>;
  /**
   * Signal input for the `pageLinkSize` property.
   *
   * @public
   */
  readonly pageLinkSize: InputSignal<PaginatorElement['pageLinkSize'] | undefined>;
  /**
   * Signal input for the `alwaysShow` property.
   *
   * @public
   */
  readonly alwaysShow: InputSignal<PaginatorElement['alwaysShow'] | undefined>;
  /**
   * Signal input for the `showPageLinks` property.
   *
   * @public
   */
  readonly showPageLinks: InputSignal<PaginatorElement['showPageLinks'] | undefined>;
  /**
   * Signal input for the `showFirstLastIcon` property.
   *
   * @public
   */
  readonly showFirstLastIcon: InputSignal<PaginatorElement['showFirstLastIcon'] | undefined>;
  /**
   * Signal input for the `showFirstLastButtons` property.
   *
   * @public
   */
  readonly showFirstLastButtons: InputSignal<PaginatorElement['showFirstLastButtons'] | undefined>;
  /**
   * Signal input for the `showCurrentPageReport` property.
   *
   * @public
   */
  readonly showCurrentPageReport: InputSignal<PaginatorElement['showCurrentPageReport'] | undefined>;
  /**
   * Signal input for the `currentPageReportTemplate` property.
   *
   * @public
   */
  readonly currentPageReportTemplate: InputSignal<PaginatorElement['currentPageReportTemplate'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<PaginatorElement['themeName'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<PaginatorElement['disabled'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<PaginatorElement['variant'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<PaginatorElement['appearance'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<PaginatorElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<PaginatorElement['lang'] | undefined>;
  /**
   * Output signal for the `pageChanged` event.
   *
   * @public
   */
  readonly pageChanged: OutputEmitterRef<ElementEventDetail<PaginatorElement, 'pageChanged'>>;
  /**
   * Output signal for the `pageSizeChanged` event.
   *
   * @public
   */
  readonly pageSizeChanged: OutputEmitterRef<ElementEventDetail<PaginatorElement, 'pageSizeChanged'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<PaginatorElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<PaginatorElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<PaginatorElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Navigates to the first page.
   *
   * @public
   */
  goToFirstPage(...args: Parameters<PaginatorElement['goToFirstPage']>): ReturnType<PaginatorElement['goToFirstPage']>;
  /**
   * Navigates to the last page.
   *
   * @public
   */
  goToLastPage(...args: Parameters<PaginatorElement['goToLastPage']>): ReturnType<PaginatorElement['goToLastPage']>;
  /**
   * Navigates to the next page.
   *
   * @public
   */
  goToNextPage(...args: Parameters<PaginatorElement['goToNextPage']>): ReturnType<PaginatorElement['goToNextPage']>;
  /**
   * Navigates to the previous page.
   *
   * @public
   */
  goToPreviousPage(...args: Parameters<PaginatorElement['goToPreviousPage']>): ReturnType<PaginatorElement['goToPreviousPage']>;
  /**
   * Navigates to a specific page (0-based index).
   *
   * @public
   * @param args - The arguments of `goToPage`:
   * - `pageIndex` - The page index to navigate to.
   */
  goToPage(...args: Parameters<PaginatorElement['goToPage']>): ReturnType<PaginatorElement['goToPage']>;
  /**
   * Changes the page size and resets to the first page.
   *
   * @public
   * @param args - The arguments of `changePageSize`:
   * - `newSize` - The new page size.
   */
  changePageSize(...args: Parameters<PaginatorElement['changePageSize']>): ReturnType<PaginatorElement['changePageSize']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `goToFirstPage()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends PaginatorMethodNames>(method: TMethod, ...args: Parameters<PaginatorComponentMethods[TMethod]>): ReturnType<PaginatorComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof PaginatorElement>(property: TProperty, value: PaginatorElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<PaginatorElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<PaginatorComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<PaginatorComponent, "mosaik-paginator", never, {
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "total": {
      "alias": "total";
      "required": false;
      "isSignal": true;
    };
    "totalRecords": {
      "alias": "totalRecords";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "rows": {
      "alias": "rows";
      "required": false;
      "isSignal": true;
    };
    "sizes": {
      "alias": "sizes";
      "required": false;
      "isSignal": true;
    };
    "showSizes": {
      "alias": "showSizes";
      "required": false;
      "isSignal": true;
    };
    "currentPage": {
      "alias": "currentPage";
      "required": false;
      "isSignal": true;
    };
    "first": {
      "alias": "first";
      "required": false;
      "isSignal": true;
    };
    "pageLinkSize": {
      "alias": "pageLinkSize";
      "required": false;
      "isSignal": true;
    };
    "alwaysShow": {
      "alias": "alwaysShow";
      "required": false;
      "isSignal": true;
    };
    "showPageLinks": {
      "alias": "showPageLinks";
      "required": false;
      "isSignal": true;
    };
    "showFirstLastIcon": {
      "alias": "showFirstLastIcon";
      "required": false;
      "isSignal": true;
    };
    "showFirstLastButtons": {
      "alias": "showFirstLastButtons";
      "required": false;
      "isSignal": true;
    };
    "showCurrentPageReport": {
      "alias": "showCurrentPageReport";
      "required": false;
      "isSignal": true;
    };
    "currentPageReportTemplate": {
      "alias": "currentPageReportTemplate";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "pageChanged": "pageChanged";
    "pageSizeChanged": "pageSizeChanged";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on PaginatorComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type PaginatorMethodNames = 'goToFirstPage' | 'goToLastPage' | 'goToNextPage' | 'goToPreviousPage' | 'goToPage' | 'changePageSize';
/**
 * Declares the methods interface for PaginatorComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type PaginatorComponentMethods = MethodMap<PaginatorMethodNames>;
/**
 * @public
 */
export declare function providePaginatorComponent(config?: Partial<PaginatorElement.Props>, intl?: Partial<PaginatorElement['intl']> | Type<Partial<PaginatorElement['intl']>>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-paginator.d.ts.map