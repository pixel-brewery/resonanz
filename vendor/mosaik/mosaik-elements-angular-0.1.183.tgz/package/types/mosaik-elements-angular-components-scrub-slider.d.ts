import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { ControlValueAccessor } from "@angular/forms";
import { ScrubSliderElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/ranges/scrub-slider/ScrubSliderElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import * as i1 from "@pixel-brewery/mosaik-elements-angular/runtime";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the ScrubSliderComponent.
 * Use this token to provide default properties for the ScrubSliderComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const SCRUB_SLIDER_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/ranges/scrub-slider/IScrubSliderElementProps").IScrubSliderElementProps>>;
/**
 * @public
 *
 * @slot hint - The hint slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ScrubSliderComponent implements ControlValueAccessor {
  /**
   * Signal input for the `step` property.
   *
   * @public
   */
  readonly step: InputSignal<ScrubSliderElement['step'] | undefined>;
  /**
   * Signal input for the `track` property.
   *
   * @public
   */
  readonly track: InputSignal<ScrubSliderElement['track'] | undefined>;
  /**
   * Signal input for the `ticks` property.
   *
   * @public
   */
  readonly ticks: InputSignal<ScrubSliderElement['ticks'] | undefined>;
  /**
   * Signal input for the `tickPlacement` property.
   *
   * @public
   */
  readonly tickPlacement: InputSignal<ScrubSliderElement['tickPlacement'] | undefined>;
  /**
   * Signal input for the `showTickLabels` property.
   *
   * @public
   */
  readonly showTickLabels: InputSignal<ScrubSliderElement['showTickLabels'] | undefined>;
  /**
   * Signal input for the `tickLabelAccessor` property.
   *
   * @public
   */
  readonly tickLabelAccessor: InputSignal<ScrubSliderElement['tickLabelAccessor'] | undefined>;
  /**
   * Signal input for the `tooltipPlacement` property.
   *
   * @public
   */
  readonly tooltipPlacement: InputSignal<ScrubSliderElement['tooltipPlacement'] | undefined>;
  /**
   * Signal input for the `tooltipAccessor` property.
   *
   * @public
   */
  readonly tooltipAccessor: InputSignal<ScrubSliderElement['tooltipAccessor'] | undefined>;
  /**
   * Signal input for the `pxPerStep` property.
   *
   * @public
   */
  readonly pxPerStep: InputSignal<ScrubSliderElement['pxPerStep'] | undefined>;
  /**
   * Signal input for the `accelerate` property.
   *
   * @public
   */
  readonly accelerate: InputSignal<ScrubSliderElement['accelerate'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ScrubSliderElement['themeName'] | undefined>;
  /**
   * Signal input for the `orientation` property.
   *
   * @public
   */
  readonly orientation: InputSignal<ScrubSliderElement['orientation'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<ScrubSliderElement['disabled'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<ScrubSliderElement['variant'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<ScrubSliderElement['appearance'] | undefined>;
  /**
   * Signal input for the `isFocused` property.
   *
   * @public
   */
  readonly isFocused: InputSignal<ScrubSliderElement['isFocused'] | undefined>;
  /**
   * Signal input for the `invalid` property.
   *
   * @public
   */
  readonly invalid: InputSignal<ScrubSliderElement['invalid'] | undefined>;
  /**
   * Signal input for the `min` property.
   *
   * @public
   */
  readonly min: InputSignal<ScrubSliderElement['min'] | undefined>;
  /**
   * Signal input for the `max` property.
   *
   * @public
   */
  readonly max: InputSignal<ScrubSliderElement['max'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<ScrubSliderElement['value'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ScrubSliderElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ScrubSliderElement['lang'] | undefined>;
  /**
   * Output signal for the `input` event.
   *
   * @public
   */
  readonly input: OutputEmitterRef<ElementEventDetail<ScrubSliderElement, 'input'>>;
  /**
   * Output signal for the `change` event.
   *
   * @public
   */
  readonly change: OutputEmitterRef<ElementEventDetail<ScrubSliderElement, 'change'>>;
  /**
   * Output signal for the `rangeValueChanged` event.
   *
   * @public
   */
  readonly rangeValueChanged: OutputEmitterRef<ElementEventDetail<ScrubSliderElement, 'rangeValueChanged'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ScrubSliderElement, 'changed'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ScrubSliderElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ScrubSliderElement, 'disconnected'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  private readonly _accessor;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Applies a value supplied by Angular forms to the native control.
   *
   * @public
   */
  writeValue(obj: unknown): void;
  /**
   * Registers the callback notified when the native control value changes.
   *
   * @public
   */
  registerOnChange(fn: unknown): void;
  /**
   * Registers the callback notified when the native control is touched.
   *
   * @public
   */
  registerOnTouched(fn: unknown): void;
  /**
   * Applies the disabled state supplied by Angular forms.
   *
   * @public
   */
  setDisabledState?(isDisabled: boolean): void;
  /**
   * Checks the validity of the element and returns `true` if it is valid; otherwise, `false`.
   *
   * @public
   */
  checkValidity(...args: Parameters<ScrubSliderElement['checkValidity']>): ReturnType<ScrubSliderElement['checkValidity']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `checkValidity()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends ScrubSliderMethodNames>(method: TMethod, ...args: Parameters<ScrubSliderComponentMethods[TMethod]>): ReturnType<ScrubSliderComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ScrubSliderElement>(property: TProperty, value: ScrubSliderElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ScrubSliderElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ScrubSliderComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ScrubSliderComponent, "mosaik-scrub-slider", never, {
    "step": {
      "alias": "step";
      "required": false;
      "isSignal": true;
    };
    "track": {
      "alias": "track";
      "required": false;
      "isSignal": true;
    };
    "ticks": {
      "alias": "ticks";
      "required": false;
      "isSignal": true;
    };
    "tickPlacement": {
      "alias": "tickPlacement";
      "required": false;
      "isSignal": true;
    };
    "showTickLabels": {
      "alias": "showTickLabels";
      "required": false;
      "isSignal": true;
    };
    "tickLabelAccessor": {
      "alias": "tickLabelAccessor";
      "required": false;
      "isSignal": true;
    };
    "tooltipPlacement": {
      "alias": "tooltipPlacement";
      "required": false;
      "isSignal": true;
    };
    "tooltipAccessor": {
      "alias": "tooltipAccessor";
      "required": false;
      "isSignal": true;
    };
    "pxPerStep": {
      "alias": "pxPerStep";
      "required": false;
      "isSignal": true;
    };
    "accelerate": {
      "alias": "accelerate";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "orientation": {
      "alias": "orientation";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "isFocused": {
      "alias": "isFocused";
      "required": false;
      "isSignal": true;
    };
    "invalid": {
      "alias": "invalid";
      "required": false;
      "isSignal": true;
    };
    "min": {
      "alias": "min";
      "required": false;
      "isSignal": true;
    };
    "max": {
      "alias": "max";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "input": "input";
    "change": "change";
    "rangeValueChanged": "rangeValueChanged";
    "changed": "changed";
    "connected": "connected";
    "disconnected": "disconnected";
  }, never, ["*"], true, [{
    directive: typeof i1.FormStatusHostDirective;
    inputs: {};
    outputs: {};
  }, {
    directive: typeof i1.FormFieldStatusHostDirective;
    inputs: {};
    outputs: {};
  }]>;
}
/**
 * Declares the methods available on ScrubSliderComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ScrubSliderMethodNames = 'checkValidity';
/**
 * Declares the methods interface for ScrubSliderComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ScrubSliderComponentMethods = MethodMap<ScrubSliderMethodNames>;
/**
 * @public
 */
export declare function provideScrubSliderComponent(config?: Partial<ScrubSliderElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-scrub-slider.d.ts.map