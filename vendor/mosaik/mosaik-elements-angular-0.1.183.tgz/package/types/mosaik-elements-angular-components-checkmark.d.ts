import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { CheckmarkElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/checkmark/CheckmarkElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the CheckmarkComponent.
 * Use this token to provide default properties for the CheckmarkComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const CHECKMARK_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/primitives/checkmark/ICheckmarkElementProps").ICheckmarkElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class CheckmarkComponent {
  /**
   * Signal input for the `checked` property.
   *
   * @public
   */
  readonly checked: InputSignal<CheckmarkElement['checked'] | undefined>;
  /**
   * Signal input for the `type` property.
   *
   * @public
   */
  readonly type: InputSignal<CheckmarkElement['type'] | undefined>;
  /**
   * Signal input for the `isThreeState` property.
   *
   * @public
   */
  readonly isThreeState: InputSignal<CheckmarkElement['isThreeState'] | undefined>;
  /**
   * Signal input for the `showStateLabels` property.
   *
   * @public
   */
  readonly showStateLabels: InputSignal<CheckmarkElement['showStateLabels'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<CheckmarkElement['themeName'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<CheckmarkElement['disabled'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<CheckmarkElement['variant'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<CheckmarkElement['appearance'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<CheckmarkElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<CheckmarkElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<CheckmarkElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<CheckmarkElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<CheckmarkElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof CheckmarkElement>(property: TProperty, value: CheckmarkElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<CheckmarkElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<CheckmarkComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<CheckmarkComponent, "mosaik-checkmark", never, {
    "checked": {
      "alias": "checked";
      "required": false;
      "isSignal": true;
    };
    "type": {
      "alias": "type";
      "required": false;
      "isSignal": true;
    };
    "isThreeState": {
      "alias": "isThreeState";
      "required": false;
      "isSignal": true;
    };
    "showStateLabels": {
      "alias": "showStateLabels";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on CheckmarkComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type CheckmarkMethodNames = never;
/**
 * Declares the methods interface for CheckmarkComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type CheckmarkComponentMethods = MethodMap<CheckmarkMethodNames>;
/**
 * @public
 */
export declare function provideCheckmarkComponent(config?: Partial<CheckmarkElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-checkmark.d.ts.map