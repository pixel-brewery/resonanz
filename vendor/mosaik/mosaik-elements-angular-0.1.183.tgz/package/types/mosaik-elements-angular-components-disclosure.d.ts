import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { DisclosureElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/grouping/disclosure/DisclosureElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the DisclosureComponent.
 * Use this token to provide default properties for the DisclosureComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const DISCLOSURE_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/grouping/disclosure/IDisclosureElementProps").IDisclosureElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot for placing the main content inside the disclosure.
 * @slot end - The slot for placing content at the end of the disclosure.
 * @slot start - The slot for placing content at the start of the disclosure.
 * @slot summary - Non-interactive text or icons that replace the summary label.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class DisclosureComponent {
  /**
   * Signal input for the `summary` property.
   *
   * @public
   */
  readonly summary: InputSignal<DisclosureElement['summary'] | undefined>;
  /**
   * Signal input for the `isExpanded` property.
   *
   * @public
   */
  readonly isExpanded: InputSignal<DisclosureElement['isExpanded'] | undefined>;
  /**
   * Signal input for the `caretVisible` property.
   *
   * @public
   */
  readonly caretVisible: InputSignal<DisclosureElement['caretVisible'] | undefined>;
  /**
   * Signal input for the `caretPosition` property.
   *
   * @public
   */
  readonly caretPosition: InputSignal<DisclosureElement['caretPosition'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<DisclosureElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<DisclosureElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<DisclosureElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<DisclosureElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<DisclosureElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<DisclosureElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Reveals the content, including when called before the first render.
   *
   * @public
   */
  show(...args: Parameters<DisclosureElement['show']>): ReturnType<DisclosureElement['show']>;
  /**
   * Hides the content.
   *
   * @public
   */
  hide(...args: Parameters<DisclosureElement['hide']>): ReturnType<DisclosureElement['hide']>;
  /**
   * Toggles the expanded state.
   *
   * @public
   */
  toggle(...args: Parameters<DisclosureElement['toggle']>): ReturnType<DisclosureElement['toggle']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `show()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends DisclosureMethodNames>(method: TMethod, ...args: Parameters<DisclosureComponentMethods[TMethod]>): ReturnType<DisclosureComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof DisclosureElement>(property: TProperty, value: DisclosureElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<DisclosureElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<DisclosureComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<DisclosureComponent, "mosaik-disclosure", never, {
    "summary": {
      "alias": "summary";
      "required": false;
      "isSignal": true;
    };
    "isExpanded": {
      "alias": "isExpanded";
      "required": false;
      "isSignal": true;
    };
    "caretVisible": {
      "alias": "caretVisible";
      "required": false;
      "isSignal": true;
    };
    "caretPosition": {
      "alias": "caretPosition";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on DisclosureComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type DisclosureMethodNames = 'show' | 'hide' | 'toggle';
/**
 * Declares the methods interface for DisclosureComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type DisclosureComponentMethods = MethodMap<DisclosureMethodNames>;
/**
 * @public
 */
export declare function provideDisclosureComponent(config?: Partial<DisclosureElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-disclosure.d.ts.map