import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { AbsoluteItemElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/absolute/AbsoluteItemElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { AbsoluteElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/absolute/AbsoluteElement";
/**
 * @public
 *
 * Injection token for the default properties of the AbsoluteItemComponent.
 * Use this token to provide default properties for the AbsoluteItemComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const ABSOLUTE_ITEM_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/layouts/absolute/IAbsoluteItemElementProps").IAbsoluteItemElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot for placing child elements.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class AbsoluteItemComponent {
  /**
   * Signal input for the `left` property.
   *
   * @public
   */
  readonly left: InputSignal<AbsoluteItemElement['left'] | undefined>;
  /**
   * Signal input for the `top` property.
   *
   * @public
   */
  readonly top: InputSignal<AbsoluteItemElement['top'] | undefined>;
  /**
   * Signal input for the `bottom` property.
   *
   * @public
   */
  readonly bottom: InputSignal<AbsoluteItemElement['bottom'] | undefined>;
  /**
   * Signal input for the `right` property.
   *
   * @public
   */
  readonly right: InputSignal<AbsoluteItemElement['right'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<AbsoluteItemElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<AbsoluteItemElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<AbsoluteItemElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<AbsoluteItemElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<AbsoluteItemElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<AbsoluteItemElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof AbsoluteItemElement>(property: TProperty, value: AbsoluteItemElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<AbsoluteItemElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<AbsoluteItemComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AbsoluteItemComponent, "mosaik-absolute-item", never, {
    "left": {
      "alias": "left";
      "required": false;
      "isSignal": true;
    };
    "top": {
      "alias": "top";
      "required": false;
      "isSignal": true;
    };
    "bottom": {
      "alias": "bottom";
      "required": false;
      "isSignal": true;
    };
    "right": {
      "alias": "right";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on AbsoluteItemComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type AbsoluteItemMethodNames = never;
/**
 * Declares the methods interface for AbsoluteItemComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type AbsoluteItemComponentMethods = MethodMap<AbsoluteItemMethodNames>;
/**
 * @public
 */
export declare function provideAbsoluteItemComponent(config?: Partial<AbsoluteItemElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the AbsoluteComponent.
 * Use this token to provide default properties for the AbsoluteComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const ABSOLUTE_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/layouts/absolute/IAbsoluteElementProps").IAbsoluteElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot for placing absolutely positioned child elements.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class AbsoluteComponent {
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<AbsoluteElement['themeName'] | undefined>;
  /**
   * Signal input for the `fit` property.
   *
   * @public
   */
  readonly fit: InputSignal<AbsoluteElement['fit'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<AbsoluteElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<AbsoluteElement['lang'] | undefined>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<AbsoluteElement, 'changed'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<AbsoluteElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<AbsoluteElement, 'disconnected'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof AbsoluteElement>(property: TProperty, value: AbsoluteElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<AbsoluteElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<AbsoluteComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AbsoluteComponent, "mosaik-absolute", never, {
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "fit": {
      "alias": "fit";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "changed": "changed";
    "connected": "connected";
    "disconnected": "disconnected";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on AbsoluteComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type AbsoluteMethodNames = never;
/**
 * Declares the methods interface for AbsoluteComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type AbsoluteComponentMethods = MethodMap<AbsoluteMethodNames>;
/**
 * @public
 */
export declare function provideAbsoluteComponent(config?: Partial<AbsoluteElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-absolute.d.ts.map