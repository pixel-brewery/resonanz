import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { Theme2Element } from "@pixel-brewery/mosaik-elements-foundation/dist/theming/Theme2Element";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the Theme2Component.
 * Use this token to provide default properties for the Theme2Component.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const THEME2_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/theming/IThemeElementProps").IThemeElementProps>>;
/**
 * @public
 *
 * @slot  - The content that receives the scoped theme variables.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class Theme2Component {
  /**
   * Signal input for the `name` property.
   *
   * @public
   */
  readonly name: InputSignal<Theme2Element['name'] | undefined>;
  /**
   * Signal input for the `theme` property.
   *
   * @public
   */
  readonly theme: InputSignal<Theme2Element['theme'] | undefined>;
  /**
   * Signal input for the `global` property.
   *
   * @public
   */
  readonly global: InputSignal<Theme2Element['global'] | undefined>;
  /**
   * Signal input for the `themeMode` property.
   *
   * @public
   */
  readonly themeMode: InputSignal<Theme2Element['themeMode'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<Theme2Element['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<Theme2Element['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<Theme2Element, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<Theme2Element, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<Theme2Element, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Applies the complete theme.
   * Called by ThemeService to update this provider's internal state.
   * CSS variables are handled by ThemeService directly.
   *
   * @public
   * @param args - The arguments of `applyTheme`:
   * - `theme` - The theme to apply.
   */
  applyTheme(...args: Parameters<Theme2Element['applyTheme']>): ReturnType<Theme2Element['applyTheme']>;
  /**
   * Applies the scheme (light/dark mode color roles) from the theme.
   * Called by ThemeService to update this provider's internal state.
   *
   * @public
   * @param args - The arguments of `applyScheme`:
   * - `scheme` - The scheme to apply.
   */
  applyScheme(...args: Parameters<Theme2Element['applyScheme']>): ReturnType<Theme2Element['applyScheme']>;
  /**
   * Applies the color palette from the theme.
   * Called by ThemeService to update this provider's internal state.
   *
   * @public
   * @param args - The arguments of `applyPalette`:
   * - `palette` - The palette to apply.
   */
  applyPalette(...args: Parameters<Theme2Element['applyPalette']>): ReturnType<Theme2Element['applyPalette']>;
  /**
   * Applies the font family from the theme.
   * Called by ThemeService to update this provider's internal state.
   *
   * @public
   * @param args - The arguments of `applyFontFamily`:
   * - `fontFamily` - The font family to apply.
   */
  applyFontFamily(...args: Parameters<Theme2Element['applyFontFamily']>): ReturnType<Theme2Element['applyFontFamily']>;
  /**
   * Applies the typography settings from the theme.
   * Called by ThemeService to update this provider's internal state.
   *
   * @public
   * @param args - The arguments of `applyTypography`:
   * - `typography` - The typography settings to apply.
   */
  applyTypography(...args: Parameters<Theme2Element['applyTypography']>): ReturnType<Theme2Element['applyTypography']>;
  /**
   * Applies the layout settings from the theme.
   * Called by ThemeService to update this provider's internal state.
   *
   * @public
   * @param args - The arguments of `applyLayout`:
   * - `layout` - The layout settings to apply.
   */
  applyLayout(...args: Parameters<Theme2Element['applyLayout']>): ReturnType<Theme2Element['applyLayout']>;
  /**
   * Applies the elevation (shadow) settings from the theme.
   * Called by ThemeService to update this provider's internal state.
   *
   * @public
   * @param args - The arguments of `applyElevation`:
   * - `elevation` - The elevation settings to apply.
   */
  applyElevation(...args: Parameters<Theme2Element['applyElevation']>): ReturnType<Theme2Element['applyElevation']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `applyTheme()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends Theme2MethodNames>(method: TMethod, ...args: Parameters<Theme2ComponentMethods[TMethod]>): ReturnType<Theme2ComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof Theme2Element>(property: TProperty, value: Theme2Element[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<Theme2Element>;
  static ɵfac: i0.ɵɵFactoryDeclaration<Theme2Component, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<Theme2Component, "mosaik-theme2", never, {
    "name": {
      "alias": "name";
      "required": false;
      "isSignal": true;
    };
    "theme": {
      "alias": "theme";
      "required": false;
      "isSignal": true;
    };
    "global": {
      "alias": "global";
      "required": false;
      "isSignal": true;
    };
    "themeMode": {
      "alias": "themeMode";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on Theme2Component.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type Theme2MethodNames = 'applyTheme' | 'applyScheme' | 'applyPalette' | 'applyFontFamily' | 'applyTypography' | 'applyLayout' | 'applyElevation';
/**
 * Declares the methods interface for Theme2Component.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type Theme2ComponentMethods = MethodMap<Theme2MethodNames>;
/**
 * @public
 */
export declare function provideTheme2Component(config?: Partial<Theme2Element.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-theming.d.ts.map