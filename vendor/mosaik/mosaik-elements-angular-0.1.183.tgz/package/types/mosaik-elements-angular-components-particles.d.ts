import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { ParticlesElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/illustrations/particles/ParticlesElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the ParticlesComponent.
 * Use this token to provide default properties for the ParticlesComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const PARTICLES_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").IParticlesElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ParticlesComponent {
  /**
   * Signal input for the `quantity` property.
   *
   * @public
   */
  readonly quantity: InputSignal<ParticlesElement['quantity'] | undefined>;
  /**
   * Signal input for the `size` property.
   *
   * @public
   */
  readonly size: InputSignal<ParticlesElement['size'] | undefined>;
  /**
   * Signal input for the `speed` property.
   *
   * @public
   */
  readonly speed: InputSignal<ParticlesElement['speed'] | undefined>;
  /**
   * Signal input for the `effect` property.
   *
   * @public
   */
  readonly effect: InputSignal<ParticlesElement['effect'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ParticlesElement['themeName'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<ParticlesElement['variant'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ParticlesElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ParticlesElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ParticlesElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ParticlesElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ParticlesElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ParticlesElement>(property: TProperty, value: ParticlesElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ParticlesElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ParticlesComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ParticlesComponent, "mosaik-particles", never, {
    "quantity": {
      "alias": "quantity";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "speed": {
      "alias": "speed";
      "required": false;
      "isSignal": true;
    };
    "effect": {
      "alias": "effect";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on ParticlesComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ParticlesMethodNames = never;
/**
 * Declares the methods interface for ParticlesComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ParticlesComponentMethods = MethodMap<ParticlesMethodNames>;
/**
 * @public
 */
export declare function provideParticlesComponent(config?: Partial<ParticlesElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-particles.d.ts.map