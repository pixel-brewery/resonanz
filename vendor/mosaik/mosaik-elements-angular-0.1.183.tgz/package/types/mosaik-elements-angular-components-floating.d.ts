import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { FloatingTriggerElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/floating/FloatingTriggerElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { FloatingElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/floating/FloatingElement";
/**
 * @public
 *
 * Injection token for the default properties of the FloatingTriggerComponent.
 * Use this token to provide default properties for the FloatingTriggerComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const FLOATING_TRIGGER_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/primitives/floating/IFloatingTriggerElementProps").IFloatingTriggerElementProps>>;
/**
 * @public
 *
 * @slot  - The trigger element that activates the floating content (typically a button)
 * @slot floating - The floating element to show/hide (typically mosaik-floating)
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class FloatingTriggerComponent {
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<FloatingTriggerElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<FloatingTriggerElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<FloatingTriggerElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<FloatingTriggerElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<FloatingTriggerElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<FloatingTriggerElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof FloatingTriggerElement>(property: TProperty, value: FloatingTriggerElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<FloatingTriggerElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<FloatingTriggerComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<FloatingTriggerComponent, "mosaik-floating-trigger", never, {
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on FloatingTriggerComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FloatingTriggerMethodNames = never;
/**
 * Declares the methods interface for FloatingTriggerComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FloatingTriggerComponentMethods = MethodMap<FloatingTriggerMethodNames>;
/**
 * @public
 */
export declare function provideFloatingTriggerComponent(config?: Partial<FloatingTriggerElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the FloatingComponent.
 * Use this token to provide default properties for the FloatingComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const FLOATING_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/primitives/floating/IFloatingElementProps").IFloatingElementProps>>;
/**
 * @public
 *
 * @slot  - The default content slot for floating content
 * @slot anchor - The anchor slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class FloatingComponent {
  /**
   * Signal input for the `anchor` property.
   *
   * @public
   */
  readonly anchor: InputSignal<FloatingElement['anchor'] | undefined>;
  /**
   * Signal input for the `active` property.
   *
   * @public
   */
  readonly active: InputSignal<FloatingElement['active'] | undefined>;
  /**
   * Signal input for the `placement` property.
   *
   * @public
   */
  readonly placement: InputSignal<FloatingElement['placement'] | undefined>;
  /**
   * Signal input for the `strategy` property.
   *
   * @public
   */
  readonly strategy: InputSignal<FloatingElement['strategy'] | undefined>;
  /**
   * Signal input for the `distance` property.
   *
   * @public
   */
  readonly distance: InputSignal<FloatingElement['distance'] | undefined>;
  /**
   * Signal input for the `skidding` property.
   *
   * @public
   */
  readonly skidding: InputSignal<FloatingElement['skidding'] | undefined>;
  /**
   * Signal input for the `arrow` property.
   *
   * @public
   */
  readonly arrow: InputSignal<FloatingElement['arrow'] | undefined>;
  /**
   * Signal input for the `arrowPlacement` property.
   *
   * @public
   */
  readonly arrowPlacement: InputSignal<FloatingElement['arrowPlacement'] | undefined>;
  /**
   * Signal input for the `arrowPadding` property.
   *
   * @public
   */
  readonly arrowPadding: InputSignal<FloatingElement['arrowPadding'] | undefined>;
  /**
   * Signal input for the `flip` property.
   *
   * @public
   */
  readonly flip: InputSignal<FloatingElement['flip'] | undefined>;
  /**
   * Signal input for the `flipFallbackPlacements` property.
   *
   * @public
   */
  readonly flipFallbackPlacements: InputSignal<FloatingElement['flipFallbackPlacements'] | undefined>;
  /**
   * Signal input for the `flipBoundary` property.
   *
   * @public
   */
  readonly flipBoundary: InputSignal<FloatingElement['flipBoundary'] | undefined>;
  /**
   * Signal input for the `flipPadding` property.
   *
   * @public
   */
  readonly flipPadding: InputSignal<FloatingElement['flipPadding'] | undefined>;
  /**
   * Signal input for the `flipFallbackStrategy` property.
   *
   * @public
   */
  readonly flipFallbackStrategy: InputSignal<FloatingElement['flipFallbackStrategy'] | undefined>;
  /**
   * Signal input for the `shift` property.
   *
   * @public
   */
  readonly shift: InputSignal<FloatingElement['shift'] | undefined>;
  /**
   * Signal input for the `shiftCrossAxis` property.
   *
   * @public
   */
  readonly shiftCrossAxis: InputSignal<FloatingElement['shiftCrossAxis'] | undefined>;
  /**
   * Signal input for the `shiftBoundary` property.
   *
   * @public
   */
  readonly shiftBoundary: InputSignal<FloatingElement['shiftBoundary'] | undefined>;
  /**
   * Signal input for the `shiftPadding` property.
   *
   * @public
   */
  readonly shiftPadding: InputSignal<FloatingElement['shiftPadding'] | undefined>;
  /**
   * Signal input for the `autoSize` property.
   *
   * @public
   */
  readonly autoSize: InputSignal<FloatingElement['autoSize'] | undefined>;
  /**
   * Signal input for the `autoSizeBoundary` property.
   *
   * @public
   */
  readonly autoSizeBoundary: InputSignal<FloatingElement['autoSizeBoundary'] | undefined>;
  /**
   * Signal input for the `autoSizePadding` property.
   *
   * @public
   */
  readonly autoSizePadding: InputSignal<FloatingElement['autoSizePadding'] | undefined>;
  /**
   * Signal input for the `sync` property.
   *
   * @public
   */
  readonly sync: InputSignal<FloatingElement['sync'] | undefined>;
  /**
   * Signal input for the `maxWidth` property.
   *
   * @public
   */
  readonly maxWidth: InputSignal<FloatingElement['maxWidth'] | undefined>;
  /**
   * Signal input for the `width` property.
   *
   * @public
   */
  readonly width: InputSignal<FloatingElement['width'] | undefined>;
  /**
   * Signal input for the `maxHeight` property.
   *
   * @public
   */
  readonly maxHeight: InputSignal<FloatingElement['maxHeight'] | undefined>;
  /**
   * Signal input for the `height` property.
   *
   * @public
   */
  readonly height: InputSignal<FloatingElement['height'] | undefined>;
  /**
   * Signal input for the `isFullScreen` property.
   *
   * @public
   */
  readonly isFullScreen: InputSignal<FloatingElement['isFullScreen'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<FloatingElement['themeName'] | undefined>;
  /**
   * Signal input for the `enter` property.
   *
   * @public
   */
  readonly enter: InputSignal<FloatingElement['enter'] | undefined>;
  /**
   * Signal input for the `exit` property.
   *
   * @public
   */
  readonly exit: InputSignal<FloatingElement['exit'] | undefined>;
  /**
   * Signal input for the `elevation` property.
   *
   * @public
   */
  readonly elevation: InputSignal<FloatingElement['elevation'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<FloatingElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<FloatingElement['lang'] | undefined>;
  /**
   * Output signal for the `repositioned` event.
   *
   * @public
   */
  readonly repositioned: OutputEmitterRef<ElementEventDetail<FloatingElement, 'repositioned'>>;
  /**
   * Output signal for the `activeChanged` event.
   *
   * @public
   */
  readonly activeChanged: OutputEmitterRef<ElementEventDetail<FloatingElement, 'activeChanged'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<FloatingElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<FloatingElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<FloatingElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Opens the popup.
   *
   * @public
   */
  open(...args: Parameters<FloatingElement['open']>): ReturnType<FloatingElement['open']>;
  /**
   * Closes the popup.
   *
   * @public
   */
  close(...args: Parameters<FloatingElement['close']>): ReturnType<FloatingElement['close']>;
  /**
   * Forces the popup to recalculate and reposition itself.
   *
   * @public
   */
  reposition(...args: Parameters<FloatingElement['reposition']>): ReturnType<FloatingElement['reposition']>;
  /**
   * Returns the scrollable element.
   *
   * @public
   */
  getScrollableElement(...args: Parameters<FloatingElement['getScrollableElement']>): ReturnType<FloatingElement['getScrollableElement']>;
  /**
   * Calls `play` on the `mosaik-floating` element.
   *
   * @public
   */
  play(...args: Parameters<FloatingElement['play']>): ReturnType<FloatingElement['play']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `open()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends FloatingMethodNames>(method: TMethod, ...args: Parameters<FloatingComponentMethods[TMethod]>): ReturnType<FloatingComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof FloatingElement>(property: TProperty, value: FloatingElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<FloatingElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<FloatingComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<FloatingComponent, "mosaik-floating", never, {
    "anchor": {
      "alias": "anchor";
      "required": false;
      "isSignal": true;
    };
    "active": {
      "alias": "active";
      "required": false;
      "isSignal": true;
    };
    "placement": {
      "alias": "placement";
      "required": false;
      "isSignal": true;
    };
    "strategy": {
      "alias": "strategy";
      "required": false;
      "isSignal": true;
    };
    "distance": {
      "alias": "distance";
      "required": false;
      "isSignal": true;
    };
    "skidding": {
      "alias": "skidding";
      "required": false;
      "isSignal": true;
    };
    "arrow": {
      "alias": "arrow";
      "required": false;
      "isSignal": true;
    };
    "arrowPlacement": {
      "alias": "arrowPlacement";
      "required": false;
      "isSignal": true;
    };
    "arrowPadding": {
      "alias": "arrowPadding";
      "required": false;
      "isSignal": true;
    };
    "flip": {
      "alias": "flip";
      "required": false;
      "isSignal": true;
    };
    "flipFallbackPlacements": {
      "alias": "flipFallbackPlacements";
      "required": false;
      "isSignal": true;
    };
    "flipBoundary": {
      "alias": "flipBoundary";
      "required": false;
      "isSignal": true;
    };
    "flipPadding": {
      "alias": "flipPadding";
      "required": false;
      "isSignal": true;
    };
    "flipFallbackStrategy": {
      "alias": "flipFallbackStrategy";
      "required": false;
      "isSignal": true;
    };
    "shift": {
      "alias": "shift";
      "required": false;
      "isSignal": true;
    };
    "shiftCrossAxis": {
      "alias": "shiftCrossAxis";
      "required": false;
      "isSignal": true;
    };
    "shiftBoundary": {
      "alias": "shiftBoundary";
      "required": false;
      "isSignal": true;
    };
    "shiftPadding": {
      "alias": "shiftPadding";
      "required": false;
      "isSignal": true;
    };
    "autoSize": {
      "alias": "autoSize";
      "required": false;
      "isSignal": true;
    };
    "autoSizeBoundary": {
      "alias": "autoSizeBoundary";
      "required": false;
      "isSignal": true;
    };
    "autoSizePadding": {
      "alias": "autoSizePadding";
      "required": false;
      "isSignal": true;
    };
    "sync": {
      "alias": "sync";
      "required": false;
      "isSignal": true;
    };
    "maxWidth": {
      "alias": "maxWidth";
      "required": false;
      "isSignal": true;
    };
    "width": {
      "alias": "width";
      "required": false;
      "isSignal": true;
    };
    "maxHeight": {
      "alias": "maxHeight";
      "required": false;
      "isSignal": true;
    };
    "height": {
      "alias": "height";
      "required": false;
      "isSignal": true;
    };
    "isFullScreen": {
      "alias": "isFullScreen";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "enter": {
      "alias": "enter";
      "required": false;
      "isSignal": true;
    };
    "exit": {
      "alias": "exit";
      "required": false;
      "isSignal": true;
    };
    "elevation": {
      "alias": "elevation";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "repositioned": "repositioned";
    "activeChanged": "activeChanged";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on FloatingComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FloatingMethodNames = 'open' | 'close' | 'reposition' | 'getScrollableElement' | 'play';
/**
 * Declares the methods interface for FloatingComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FloatingComponentMethods = MethodMap<FloatingMethodNames>;
/**
 * @public
 */
export declare function provideFloatingComponent(config?: Partial<FloatingElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-floating.d.ts.map