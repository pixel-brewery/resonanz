import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { ImageElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/image/ImageElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the ImageComponent.
 * Use this token to provide default properties for the ImageComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const IMAGE_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/media/image/IImageElementProps").IImageElementProps>>;
/**
 * @public
 *
 * @slot  - Default content overlaid on the image
 * @slot empty - Content shown when no image source is provided
 * @slot failed - Content displayed when image loading fails
 * @slot pending - Content shown while image is loading
 * @slot legend - Caption or description content positioned around the image
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ImageComponent {
  /**
   * Signal input for the `alt` property.
   *
   * @public
   */
  readonly alt: InputSignal<ImageElement['alt'] | undefined>;
  /**
   * Signal input for the `src` property.
   *
   * @public
   */
  readonly src: InputSignal<ImageElement['src'] | undefined>;
  /**
   * Signal input for the `srcset` property.
   *
   * @public
   */
  readonly srcset: InputSignal<ImageElement['srcset'] | undefined>;
  /**
   * Signal input for the `fit` property.
   *
   * @public
   */
  readonly fit: InputSignal<ImageElement['fit'] | undefined>;
  /**
   * Signal input for the `thumbnailSrc` property.
   *
   * @public
   */
  readonly thumbnailSrc: InputSignal<ImageElement['thumbnailSrc'] | undefined>;
  /**
   * Signal input for the `hoverZoom` property.
   *
   * @public
   */
  readonly hoverZoom: InputSignal<ImageElement['hoverZoom'] | undefined>;
  /**
   * Signal input for the `showFailed` property.
   *
   * @public
   */
  readonly showFailed: InputSignal<ImageElement['showFailed'] | undefined>;
  /**
   * Signal input for the `showEmpty` property.
   *
   * @public
   */
  readonly showEmpty: InputSignal<ImageElement['showEmpty'] | undefined>;
  /**
   * Signal input for the `showPending` property.
   *
   * @public
   */
  readonly showPending: InputSignal<ImageElement['showPending'] | undefined>;
  /**
   * Signal input for the `legend` property.
   *
   * @public
   */
  readonly legend: InputSignal<ImageElement['legend'] | undefined>;
  /**
   * Signal input for the `legendPosition` property.
   *
   * @public
   */
  readonly legendPosition: InputSignal<ImageElement['legendPosition'] | undefined>;
  /**
   * Signal input for the `ratio` property.
   *
   * @public
   */
  readonly ratio: InputSignal<ImageElement['ratio'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ImageElement['themeName'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<ImageElement['disabled'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<ImageElement['variant'] | undefined>;
  /**
   * Signal input for the `width` property.
   *
   * @public
   */
  readonly width: InputSignal<ImageElement['width'] | undefined>;
  /**
   * Signal input for the `height` property.
   *
   * @public
   */
  readonly height: InputSignal<ImageElement['height'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ImageElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ImageElement['lang'] | undefined>;
  /**
   * Output signal for the `imageLoaded` event.
   *
   * @public
   */
  readonly imageLoaded: OutputEmitterRef<ElementEventDetail<ImageElement, 'imageLoaded'>>;
  /**
   * Output signal for the `imageFailed` event.
   *
   * @public
   */
  readonly imageFailed: OutputEmitterRef<ElementEventDetail<ImageElement, 'imageFailed'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ImageElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ImageElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ImageElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ImageElement>(property: TProperty, value: ImageElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ImageElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ImageComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ImageComponent, "mosaik-image", never, {
    "alt": {
      "alias": "alt";
      "required": false;
      "isSignal": true;
    };
    "src": {
      "alias": "src";
      "required": false;
      "isSignal": true;
    };
    "srcset": {
      "alias": "srcset";
      "required": false;
      "isSignal": true;
    };
    "fit": {
      "alias": "fit";
      "required": false;
      "isSignal": true;
    };
    "thumbnailSrc": {
      "alias": "thumbnailSrc";
      "required": false;
      "isSignal": true;
    };
    "hoverZoom": {
      "alias": "hoverZoom";
      "required": false;
      "isSignal": true;
    };
    "showFailed": {
      "alias": "showFailed";
      "required": false;
      "isSignal": true;
    };
    "showEmpty": {
      "alias": "showEmpty";
      "required": false;
      "isSignal": true;
    };
    "showPending": {
      "alias": "showPending";
      "required": false;
      "isSignal": true;
    };
    "legend": {
      "alias": "legend";
      "required": false;
      "isSignal": true;
    };
    "legendPosition": {
      "alias": "legendPosition";
      "required": false;
      "isSignal": true;
    };
    "ratio": {
      "alias": "ratio";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "width": {
      "alias": "width";
      "required": false;
      "isSignal": true;
    };
    "height": {
      "alias": "height";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "imageLoaded": "imageLoaded";
    "imageFailed": "imageFailed";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on ImageComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ImageMethodNames = never;
/**
 * Declares the methods interface for ImageComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ImageComponentMethods = MethodMap<ImageMethodNames>;
/**
 * @public
 */
export declare function provideImageComponent(config?: Partial<ImageElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-image.d.ts.map