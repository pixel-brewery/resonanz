import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { FlipElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/flip/FlipElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the FlipComponent.
 * Use this token to provide default properties for the FlipComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const FLIP_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/primitives/flip/IFlipElementProps").IFlipElementProps>>;
/**
 * @public
 *
 * @slot back - the back slot.
 * @slot front - the front slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class FlipComponent {
  /**
   * Signal input for the `side` property.
   *
   * @public
   */
  readonly side: InputSignal<FlipElement['side'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<FlipElement['themeName'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<FlipElement['disabled'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<FlipElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<FlipElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<FlipElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<FlipElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<FlipElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Toggles the flip state of the element.
   *
   * @public
   */
  toggle(...args: Parameters<FlipElement['toggle']>): ReturnType<FlipElement['toggle']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `toggle()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends FlipMethodNames>(method: TMethod, ...args: Parameters<FlipComponentMethods[TMethod]>): ReturnType<FlipComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof FlipElement>(property: TProperty, value: FlipElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<FlipElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<FlipComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<FlipComponent, "mosaik-flip", never, {
    "side": {
      "alias": "side";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on FlipComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FlipMethodNames = 'toggle';
/**
 * Declares the methods interface for FlipComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FlipComponentMethods = MethodMap<FlipMethodNames>;
/**
 * @public
 */
export declare function provideFlipComponent(config?: Partial<FlipElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-flip.d.ts.map