import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { ThumbnailElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/thumbnail/ThumbnailElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the ThumbnailComponent.
 * Use this token to provide default properties for the ThumbnailComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const THUMBNAIL_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/primitives/thumbnail/IThumbnailElementProps").IThumbnailElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ThumbnailComponent {
  /**
   * Signal input for the `preview` property.
   *
   * @public
   */
  readonly preview: InputSignal<ThumbnailElement['preview'] | undefined>;
  /**
   * Signal input for the `fit` property.
   *
   * @public
   */
  readonly fit: InputSignal<ThumbnailElement['fit'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ThumbnailElement['themeName'] | undefined>;
  /**
   * Signal input for the `size` property.
   *
   * @public
   */
  readonly size: InputSignal<ThumbnailElement['size'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<ThumbnailElement['disabled'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ThumbnailElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ThumbnailElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ThumbnailElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ThumbnailElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ThumbnailElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ThumbnailElement>(property: TProperty, value: ThumbnailElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ThumbnailElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ThumbnailComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ThumbnailComponent, "mosaik-thumbnail", never, {
    "preview": {
      "alias": "preview";
      "required": false;
      "isSignal": true;
    };
    "fit": {
      "alias": "fit";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on ThumbnailComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ThumbnailMethodNames = never;
/**
 * Declares the methods interface for ThumbnailComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ThumbnailComponentMethods = MethodMap<ThumbnailMethodNames>;
/**
 * @public
 */
export declare function provideThumbnailComponent(config?: Partial<ThumbnailElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-thumbnail.d.ts.map