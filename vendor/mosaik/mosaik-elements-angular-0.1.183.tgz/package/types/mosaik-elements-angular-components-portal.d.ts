import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { PortalHostElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/portal/PortalHostElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { PortalProjectionElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/portal/PortalProjectionElement";
import { PortalElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/portal/PortalElement";
/**
 * @public
 *
 * Injection token for the default properties of the PortalHostComponent.
 * Use this token to provide default properties for the PortalHostComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const PORTAL_HOST_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/primitives/portal/IPortalHostElementProps").IPortalHostElementProps>>;
/**
 * @public
 *
 * @slot  - The container where portal projections will be rendered
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class PortalHostComponent {
  /**
   * Signal input for the `name` property.
   *
   * @public
   */
  readonly name: InputSignal<PortalHostElement['name'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<PortalHostElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<PortalHostElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<PortalHostElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<PortalHostElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<PortalHostElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<PortalHostElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: PortalHostElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: PortalHostElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<PortalHostElement['assignToSlot']>): ReturnType<PortalHostElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<PortalHostElement['getSlotContent']>): ReturnType<PortalHostElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<PortalHostElement['hasSlotContent']>): ReturnType<PortalHostElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<PortalHostElement['hasSlot']>): ReturnType<PortalHostElement['hasSlot']>;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<PortalHostElement['onSlotChanges']>): ReturnType<PortalHostElement['onSlotChanges']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `assignToSlot()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends PortalHostMethodNames>(method: TMethod, ...args: Parameters<PortalHostComponentMethods[TMethod]>): ReturnType<PortalHostComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof PortalHostElement>(property: TProperty, value: PortalHostElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<PortalHostElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<PortalHostComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<PortalHostComponent, "mosaik-portal-host", never, {
    "name": {
      "alias": "name";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on PortalHostComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type PortalHostMethodNames = 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges';
/**
 * Declares the methods interface for PortalHostComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type PortalHostComponentMethods = MethodMap<PortalHostMethodNames>;
/**
 * @public
 */
export declare function providePortalHostComponent(config?: Partial<PortalHostElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the PortalProjectionComponent.
 * Use this token to provide default properties for the PortalProjectionComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const PORTAL_PROJECTION_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/primitives/portal/IPortalProjectionElementProps").IPortalProjectionElementProps>>;
/**
 * @public
 *
 * @slot  - The projected content from the source portal
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class PortalProjectionComponent {
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<PortalProjectionElement['themeName'] | undefined>;
  /**
   * Signal input for the `isOpen` property.
   *
   * @public
   */
  readonly isOpen: InputSignal<PortalProjectionElement['isOpen'] | undefined>;
  /**
   * Signal input for the `hasBackdrop` property.
   *
   * @public
   */
  readonly hasBackdrop: InputSignal<PortalProjectionElement['hasBackdrop'] | undefined>;
  /**
   * Signal input for the `pressEscapeToClose` property.
   *
   * @public
   */
  readonly pressEscapeToClose: InputSignal<PortalProjectionElement['pressEscapeToClose'] | undefined>;
  /**
   * Signal input for the `clickOutsideToClose` property.
   *
   * @public
   */
  readonly clickOutsideToClose: InputSignal<PortalProjectionElement['clickOutsideToClose'] | undefined>;
  /**
   * Signal input for the `attention` property.
   *
   * @public
   */
  readonly attention: InputSignal<PortalProjectionElement['attention'] | undefined>;
  /**
   * Signal input for the `closeable` property.
   *
   * @public
   */
  readonly closeable: InputSignal<PortalProjectionElement['closeable'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<PortalProjectionElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<PortalProjectionElement['lang'] | undefined>;
  /**
   * Output signal for the `opened` event.
   *
   * @public
   */
  readonly opened: OutputEmitterRef<ElementEventDetail<PortalProjectionElement, 'opened'>>;
  /**
   * Output signal for the `closed` event.
   *
   * @public
   */
  readonly closed: OutputEmitterRef<ElementEventDetail<PortalProjectionElement, 'closed'>>;
  /**
   * Output signal for the `closeAttempted` event.
   *
   * @public
   */
  readonly closeAttempted: OutputEmitterRef<ElementEventDetail<PortalProjectionElement, 'closeAttempted'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<PortalProjectionElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<PortalProjectionElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<PortalProjectionElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: PortalProjectionElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: PortalProjectionElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Assigns the portal to this projection.
   *
   * @public
   * @param args - The arguments of `assign`:
   * - `portal` - The portal element to assign.
   */
  assign(...args: Parameters<PortalProjectionElement['assign']>): ReturnType<PortalProjectionElement['assign']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<PortalProjectionElement['assignToSlot']>): ReturnType<PortalProjectionElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<PortalProjectionElement['getSlotContent']>): ReturnType<PortalProjectionElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<PortalProjectionElement['hasSlotContent']>): ReturnType<PortalProjectionElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<PortalProjectionElement['hasSlot']>): ReturnType<PortalProjectionElement['hasSlot']>;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<PortalProjectionElement['onSlotChanges']>): ReturnType<PortalProjectionElement['onSlotChanges']>;
  /**
   * Opens the `OverlayElement`.
   *
   * @public
   */
  open(...args: Parameters<PortalProjectionElement['open']>): ReturnType<PortalProjectionElement['open']>;
  /**
   * Closes the `OverlayElement`.
   *
   * @public
   * @returns Whether the overlay closed - `false` when it was not open.
   */
  close(...args: Parameters<PortalProjectionElement['close']>): ReturnType<PortalProjectionElement['close']>;
  /**
   * Requests visual attention for this overlay.
   *
   * @public
   * @param args - The arguments of `requestAttention`:
   * - `animation` - Optional animation used for this attention request.
   * @returns Whether the attention animation finished.
   */
  requestAttention(...args: Parameters<PortalProjectionElement['requestAttention']>): ReturnType<PortalProjectionElement['requestAttention']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `assign()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends PortalProjectionMethodNames>(method: TMethod, ...args: Parameters<PortalProjectionComponentMethods[TMethod]>): ReturnType<PortalProjectionComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof PortalProjectionElement>(property: TProperty, value: PortalProjectionElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<PortalProjectionElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<PortalProjectionComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<PortalProjectionComponent, "mosaik-portal-projection", never, {
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "isOpen": {
      "alias": "isOpen";
      "required": false;
      "isSignal": true;
    };
    "hasBackdrop": {
      "alias": "hasBackdrop";
      "required": false;
      "isSignal": true;
    };
    "pressEscapeToClose": {
      "alias": "pressEscapeToClose";
      "required": false;
      "isSignal": true;
    };
    "clickOutsideToClose": {
      "alias": "clickOutsideToClose";
      "required": false;
      "isSignal": true;
    };
    "attention": {
      "alias": "attention";
      "required": false;
      "isSignal": true;
    };
    "closeable": {
      "alias": "closeable";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "opened": "opened";
    "closed": "closed";
    "closeAttempted": "closeAttempted";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on PortalProjectionComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type PortalProjectionMethodNames = 'assign' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges' | 'open' | 'close' | 'requestAttention';
/**
 * Declares the methods interface for PortalProjectionComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type PortalProjectionComponentMethods = MethodMap<PortalProjectionMethodNames>;
/**
 * @public
 */
export declare function providePortalProjectionComponent(config?: Partial<PortalProjectionElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the PortalComponent.
 * Use this token to provide default properties for the PortalComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const PORTAL_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/primitives/portal/IPortalElementProps").IPortalElementProps>>;
/**
 * @public
 *
 * @slot  - The content to be portaled to the destination
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class PortalComponent {
  /**
   * Signal input for the `isActive` property.
   *
   * @public
   */
  readonly isActive: InputSignal<PortalElement['isActive'] | undefined>;
  /**
   * Signal input for the `destination` property.
   *
   * @public
   */
  readonly destination: InputSignal<PortalElement['destination'] | undefined>;
  /**
   * Signal input for the `adoptedStyles` property.
   *
   * @public
   */
  readonly adoptedStyles: InputSignal<PortalElement['adoptedStyles'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<PortalElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<PortalElement['lang'] | undefined>;
  /**
   * Output signal for the `portalAttached` event.
   *
   * @public
   */
  readonly portalAttached: OutputEmitterRef<ElementEventDetail<PortalElement, 'portalAttached'>>;
  /**
   * Output signal for the `portalDetached` event.
   *
   * @public
   */
  readonly portalDetached: OutputEmitterRef<ElementEventDetail<PortalElement, 'portalDetached'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<PortalElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<PortalElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<PortalElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: PortalElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: PortalElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<PortalElement['onSlotChanges']>): ReturnType<PortalElement['onSlotChanges']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<PortalElement['assignToSlot']>): ReturnType<PortalElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<PortalElement['getSlotContent']>): ReturnType<PortalElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<PortalElement['hasSlotContent']>): ReturnType<PortalElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<PortalElement['hasSlot']>): ReturnType<PortalElement['hasSlot']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `onSlotChanges()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends PortalMethodNames>(method: TMethod, ...args: Parameters<PortalComponentMethods[TMethod]>): ReturnType<PortalComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof PortalElement>(property: TProperty, value: PortalElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<PortalElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<PortalComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<PortalComponent, "mosaik-portal", never, {
    "isActive": {
      "alias": "isActive";
      "required": false;
      "isSignal": true;
    };
    "destination": {
      "alias": "destination";
      "required": false;
      "isSignal": true;
    };
    "adoptedStyles": {
      "alias": "adoptedStyles";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "portalAttached": "portalAttached";
    "portalDetached": "portalDetached";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on PortalComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type PortalMethodNames = 'onSlotChanges' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot';
/**
 * Declares the methods interface for PortalComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type PortalComponentMethods = MethodMap<PortalMethodNames>;
/**
 * @public
 */
export declare function providePortalComponent(config?: Partial<PortalElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-portal.d.ts.map