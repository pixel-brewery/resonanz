import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef, Type } from "@angular/core";
import { PromptBoxAttachmentListElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/prompt-box/attachments/PromptBoxAttachmentListElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import * as i1 from "@pixel-brewery/mosaik-elements-angular/runtime";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { PromptBoxAttachmentToolElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/prompt-box/tools/PromptBoxAttachmentToolElement";
import { PromptBoxQueueElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/prompt-box/queue/PromptBoxQueueElement";
import { PromptBoxVoiceRecorderToolElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/prompt-box/tools/PromptBoxVoiceRecorderToolElement";
import { ControlValueAccessor } from "@angular/forms";
import { PromptBoxElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/prompt-box/PromptBoxElement";
/**
 * @public
 *
 * Injection token for the default properties of the PromptBoxAttachmentListComponent.
 * Use this token to provide default properties for the PromptBoxAttachmentListComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const PROMPT_BOX_ATTACHMENT_LIST_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/inputs/prompt-box/attachments/IPromptBoxAttachmentListElementProps").IPromptBoxAttachmentListElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class PromptBoxAttachmentListComponent {
  /**
   * Signal input for the `entries` property.
   *
   * @public
   */
  readonly entries: InputSignal<PromptBoxAttachmentListElement['entries'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<PromptBoxAttachmentListElement['themeName'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<PromptBoxAttachmentListElement['variant'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<PromptBoxAttachmentListElement['appearance'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<PromptBoxAttachmentListElement['disabled'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<PromptBoxAttachmentListElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<PromptBoxAttachmentListElement['lang'] | undefined>;
  /**
   * Output signal for the `attachmentRemove` event.
   *
   * @public
   */
  readonly attachmentRemove: OutputEmitterRef<ElementEventDetail<PromptBoxAttachmentListElement, 'attachmentRemove'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<PromptBoxAttachmentListElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<PromptBoxAttachmentListElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<PromptBoxAttachmentListElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: PromptBoxAttachmentListElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: PromptBoxAttachmentListElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   * @param args - The arguments of `assignToSlot`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * - `node` - The nodes to assign to the slot.
   */
  assignToSlot(...args: Parameters<PromptBoxAttachmentListElement['assignToSlot']>): ReturnType<PromptBoxAttachmentListElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   * This method extracts text content recursively, including from Shadow DOMs
   * and Custom Elements with known text properties (like `mosaik-text`).
   *
   * @public
   * @param args - The arguments of `getSlotContent`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<PromptBoxAttachmentListElement['getSlotContent']>): ReturnType<PromptBoxAttachmentListElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @param args - The arguments of `hasSlotContent`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<PromptBoxAttachmentListElement['hasSlotContent']>): ReturnType<PromptBoxAttachmentListElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @param args - The arguments of `hasSlot`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<PromptBoxAttachmentListElement['hasSlot']>): ReturnType<PromptBoxAttachmentListElement['hasSlot']>;
  /**
   * Called when the slot changes.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<PromptBoxAttachmentListElement['onSlotChanges']>): ReturnType<PromptBoxAttachmentListElement['onSlotChanges']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `assignToSlot()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends PromptBoxAttachmentListMethodNames>(method: TMethod, ...args: Parameters<PromptBoxAttachmentListComponentMethods[TMethod]>): ReturnType<PromptBoxAttachmentListComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof PromptBoxAttachmentListElement>(property: TProperty, value: PromptBoxAttachmentListElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<PromptBoxAttachmentListElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<PromptBoxAttachmentListComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<PromptBoxAttachmentListComponent, "mosaik-prompt-box-attachment-list", never, {
    "entries": {
      "alias": "entries";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "attachmentRemove": "attachmentRemove";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on PromptBoxAttachmentListComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type PromptBoxAttachmentListMethodNames = 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges';
/**
 * Declares the methods interface for PromptBoxAttachmentListComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type PromptBoxAttachmentListComponentMethods = MethodMap<PromptBoxAttachmentListMethodNames>;
/**
 * @public
 */
export declare function providePromptBoxAttachmentListComponent(config?: Partial<PromptBoxAttachmentListElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the PromptBoxAttachmentToolComponent.
 * Use this token to provide default properties for the PromptBoxAttachmentToolComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const PROMPT_BOX_ATTACHMENT_TOOL_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/inputs/prompt-box/tools/IPromptBoxAttachmentToolElementProps").IPromptBoxAttachmentToolElementProps>>;
/**
 * @public
 *
 * Injection token for the intl configuration of the PromptBoxAttachmentToolComponent.
 * Provide a partial intl object or an injectable class that resolves translations.
 * This allows third-party applications to override the default intl labels
 * globally, per route, or per component via Angular's dependency injection.
 *
 * Merge order: Foundation defaults → DI intl → [intl] input binding.
 */
export declare const PROMPT_BOX_ATTACHMENT_TOOL_INTL: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").PromptBoxAttachmentToolElementIntl>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class PromptBoxAttachmentToolComponent {
  /**
   * Signal input for the `multiple` property.
   *
   * @public
   */
  readonly multiple: InputSignal<PromptBoxAttachmentToolElement['multiple'] | undefined>;
  /**
   * Signal input for the `accept` property.
   *
   * @public
   */
  readonly accept: InputSignal<PromptBoxAttachmentToolElement['accept'] | undefined>;
  /**
   * Signal input for the `directory` property.
   *
   * @public
   */
  readonly directory: InputSignal<PromptBoxAttachmentToolElement['directory'] | undefined>;
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<Partial<PromptBoxAttachmentToolElement['intl']> | undefined>;
  /**
   * Signal input for the `maxFiles` property.
   *
   * @public
   */
  readonly maxFiles: InputSignal<PromptBoxAttachmentToolElement['maxFiles'] | undefined>;
  /**
   * Signal input for the `maxFileSize` property.
   *
   * @public
   */
  readonly maxFileSize: InputSignal<PromptBoxAttachmentToolElement['maxFileSize'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<PromptBoxAttachmentToolElement['themeName'] | undefined>;
  /**
   * Signal input for the `dock` property.
   *
   * @public
   */
  readonly dock: InputSignal<PromptBoxAttachmentToolElement['dock'] | undefined>;
  /**
   * Signal input for the `disabledWhen` property.
   *
   * @public
   */
  readonly disabledWhen: InputSignal<PromptBoxAttachmentToolElement['disabledWhen'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<PromptBoxAttachmentToolElement['disabled'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<PromptBoxAttachmentToolElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<PromptBoxAttachmentToolElement['lang'] | undefined>;
  /**
   * Output signal for the `attachmentReject` event.
   *
   * @public
   */
  readonly attachmentReject: OutputEmitterRef<ElementEventDetail<PromptBoxAttachmentToolElement, 'attachmentReject'>>;
  /**
   * Output signal for the `filesPicked` event.
   *
   * @public
   */
  readonly filesPicked: OutputEmitterRef<ElementEventDetail<PromptBoxAttachmentToolElement, 'filesPicked'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<PromptBoxAttachmentToolElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<PromptBoxAttachmentToolElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<PromptBoxAttachmentToolElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Validates files and adds them to the associated Prompt Box.
   *
   * @public
   */
  execute(...args: Parameters<PromptBoxAttachmentToolElement['execute']>): ReturnType<PromptBoxAttachmentToolElement['execute']>;
  /**
   * Attaches this tool to a Prompt Box.
   *
   * @public
   */
  attach(...args: Parameters<PromptBoxAttachmentToolElement['attach']>): ReturnType<PromptBoxAttachmentToolElement['attach']>;
  /**
   * Detaches this tool from a Prompt Box.
   *
   * @public
   */
  detach(...args: Parameters<PromptBoxAttachmentToolElement['detach']>): ReturnType<PromptBoxAttachmentToolElement['detach']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `execute()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends PromptBoxAttachmentToolMethodNames>(method: TMethod, ...args: Parameters<PromptBoxAttachmentToolComponentMethods[TMethod]>): ReturnType<PromptBoxAttachmentToolComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof PromptBoxAttachmentToolElement>(property: TProperty, value: PromptBoxAttachmentToolElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<PromptBoxAttachmentToolElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<PromptBoxAttachmentToolComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<PromptBoxAttachmentToolComponent, "mosaik-prompt-box-attachment-tool", never, {
    "multiple": {
      "alias": "multiple";
      "required": false;
      "isSignal": true;
    };
    "accept": {
      "alias": "accept";
      "required": false;
      "isSignal": true;
    };
    "directory": {
      "alias": "directory";
      "required": false;
      "isSignal": true;
    };
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "maxFiles": {
      "alias": "maxFiles";
      "required": false;
      "isSignal": true;
    };
    "maxFileSize": {
      "alias": "maxFileSize";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dock": {
      "alias": "dock";
      "required": false;
      "isSignal": true;
    };
    "disabledWhen": {
      "alias": "disabledWhen";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "attachmentReject": "attachmentReject";
    "filesPicked": "filesPicked";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on PromptBoxAttachmentToolComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type PromptBoxAttachmentToolMethodNames = 'execute' | 'attach' | 'detach';
/**
 * Declares the methods interface for PromptBoxAttachmentToolComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type PromptBoxAttachmentToolComponentMethods = MethodMap<PromptBoxAttachmentToolMethodNames>;
/**
 * @public
 */
export declare function providePromptBoxAttachmentToolComponent(config?: Partial<PromptBoxAttachmentToolElement.Props>, intl?: Partial<PromptBoxAttachmentToolElement['intl']> | Type<Partial<PromptBoxAttachmentToolElement['intl']>>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the PromptBoxQueueComponent.
 * Use this token to provide default properties for the PromptBoxQueueComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const PROMPT_BOX_QUEUE_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").IPromptBoxQueueElementProps>>;
/**
 * @public
 *
 * Injection token for the intl configuration of the PromptBoxQueueComponent.
 * Provide a partial intl object or an injectable class that resolves translations.
 * This allows third-party applications to override the default intl labels
 * globally, per route, or per component via Angular's dependency injection.
 *
 * Merge order: Foundation defaults → DI intl → [intl] input binding.
 */
export declare const PROMPT_BOX_QUEUE_INTL: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").PromptBoxQueueElementIntl>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class PromptBoxQueueComponent {
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<Partial<PromptBoxQueueElement['intl']> | undefined>;
  /**
   * Signal input for the `entries` property.
   *
   * @public
   */
  readonly entries: InputSignal<PromptBoxQueueElement['entries'] | undefined>;
  /**
   * Signal input for the `reorderable` property.
   *
   * @public
   */
  readonly reorderable: InputSignal<PromptBoxQueueElement['reorderable'] | undefined>;
  /**
   * Signal input for the `steerable` property.
   *
   * @public
   */
  readonly steerable: InputSignal<PromptBoxQueueElement['steerable'] | undefined>;
  /**
   * Signal input for the `editable` property.
   *
   * @public
   */
  readonly editable: InputSignal<PromptBoxQueueElement['editable'] | undefined>;
  /**
   * Signal input for the `pausable` property.
   *
   * @public
   */
  readonly pausable: InputSignal<PromptBoxQueueElement['pausable'] | undefined>;
  /**
   * Signal input for the `actions` property.
   *
   * @public
   */
  readonly actions: InputSignal<PromptBoxQueueElement['actions'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<PromptBoxQueueElement['themeName'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<PromptBoxQueueElement['variant'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<PromptBoxQueueElement['appearance'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<PromptBoxQueueElement['disabled'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<PromptBoxQueueElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<PromptBoxQueueElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<PromptBoxQueueElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<PromptBoxQueueElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<PromptBoxQueueElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: PromptBoxQueueElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: PromptBoxQueueElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   * @param args - The arguments of `assignToSlot`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * - `node` - The nodes to assign to the slot.
   */
  assignToSlot(...args: Parameters<PromptBoxQueueElement['assignToSlot']>): ReturnType<PromptBoxQueueElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   * This method extracts text content recursively, including from Shadow DOMs
   * and Custom Elements with known text properties (like `mosaik-text`).
   *
   * @public
   * @param args - The arguments of `getSlotContent`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<PromptBoxQueueElement['getSlotContent']>): ReturnType<PromptBoxQueueElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @param args - The arguments of `hasSlotContent`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<PromptBoxQueueElement['hasSlotContent']>): ReturnType<PromptBoxQueueElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @param args - The arguments of `hasSlot`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<PromptBoxQueueElement['hasSlot']>): ReturnType<PromptBoxQueueElement['hasSlot']>;
  /**
   * Called when the slot changes.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<PromptBoxQueueElement['onSlotChanges']>): ReturnType<PromptBoxQueueElement['onSlotChanges']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `assignToSlot()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends PromptBoxQueueMethodNames>(method: TMethod, ...args: Parameters<PromptBoxQueueComponentMethods[TMethod]>): ReturnType<PromptBoxQueueComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof PromptBoxQueueElement>(property: TProperty, value: PromptBoxQueueElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<PromptBoxQueueElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<PromptBoxQueueComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<PromptBoxQueueComponent, "mosaik-prompt-box-queue", never, {
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "entries": {
      "alias": "entries";
      "required": false;
      "isSignal": true;
    };
    "reorderable": {
      "alias": "reorderable";
      "required": false;
      "isSignal": true;
    };
    "steerable": {
      "alias": "steerable";
      "required": false;
      "isSignal": true;
    };
    "editable": {
      "alias": "editable";
      "required": false;
      "isSignal": true;
    };
    "pausable": {
      "alias": "pausable";
      "required": false;
      "isSignal": true;
    };
    "actions": {
      "alias": "actions";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on PromptBoxQueueComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type PromptBoxQueueMethodNames = 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges';
/**
 * Declares the methods interface for PromptBoxQueueComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type PromptBoxQueueComponentMethods = MethodMap<PromptBoxQueueMethodNames>;
/**
 * @public
 */
export declare function providePromptBoxQueueComponent(config?: Partial<PromptBoxQueueElement.Props>, intl?: Partial<PromptBoxQueueElement['intl']> | Type<Partial<PromptBoxQueueElement['intl']>>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the PromptBoxVoiceRecorderToolComponent.
 * Use this token to provide default properties for the PromptBoxVoiceRecorderToolComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const PROMPT_BOX_VOICE_RECORDER_TOOL_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/inputs/prompt-box/tools/IPromptBoxVoiceRecorderToolElementProps").IPromptBoxVoiceRecorderToolElementProps>>;
/**
 * @public
 *
 * Injection token for the intl configuration of the PromptBoxVoiceRecorderToolComponent.
 * Provide a partial intl object or an injectable class that resolves translations.
 * This allows third-party applications to override the default intl labels
 * globally, per route, or per component via Angular's dependency injection.
 *
 * Merge order: Foundation defaults → DI intl → [intl] input binding.
 */
export declare const PROMPT_BOX_VOICE_RECORDER_TOOL_INTL: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").PromptBoxVoiceRecorderToolElementIntl>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class PromptBoxVoiceRecorderToolComponent {
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<Partial<PromptBoxVoiceRecorderToolElement['intl']> | undefined>;
  /**
   * Signal input for the `state` property.
   *
   * @public
   */
  readonly state: InputSignal<PromptBoxVoiceRecorderToolElement['state'] | undefined>;
  /**
   * Signal input for the `elapsedTime` property.
   *
   * @public
   */
  readonly elapsedTime: InputSignal<PromptBoxVoiceRecorderToolElement['elapsedTime'] | undefined>;
  /**
   * Signal input for the `maxDurationTime` property.
   *
   * @public
   */
  readonly maxDurationTime: InputSignal<PromptBoxVoiceRecorderToolElement['maxDurationTime'] | undefined>;
  /**
   * Signal input for the `objectUrl` property.
   *
   * @public
   */
  readonly objectUrl: InputSignal<PromptBoxVoiceRecorderToolElement['objectUrl'] | undefined>;
  /**
   * Signal input for the `canPause` property.
   *
   * @public
   */
  readonly canPause: InputSignal<PromptBoxVoiceRecorderToolElement['canPause'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<PromptBoxVoiceRecorderToolElement['themeName'] | undefined>;
  /**
   * Signal input for the `dock` property.
   *
   * @public
   */
  readonly dock: InputSignal<PromptBoxVoiceRecorderToolElement['dock'] | undefined>;
  /**
   * Signal input for the `disabledWhen` property.
   *
   * @public
   */
  readonly disabledWhen: InputSignal<PromptBoxVoiceRecorderToolElement['disabledWhen'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<PromptBoxVoiceRecorderToolElement['disabled'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<PromptBoxVoiceRecorderToolElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<PromptBoxVoiceRecorderToolElement['lang'] | undefined>;
  /**
   * Output signal for the `recorderCancel` event.
   *
   * @public
   */
  readonly recorderCancel: OutputEmitterRef<ElementEventDetail<PromptBoxVoiceRecorderToolElement, 'recorderCancel'>>;
  /**
   * Output signal for the `recorderPause` event.
   *
   * @public
   */
  readonly recorderPause: OutputEmitterRef<ElementEventDetail<PromptBoxVoiceRecorderToolElement, 'recorderPause'>>;
  /**
   * Output signal for the `recorderResume` event.
   *
   * @public
   */
  readonly recorderResume: OutputEmitterRef<ElementEventDetail<PromptBoxVoiceRecorderToolElement, 'recorderResume'>>;
  /**
   * Output signal for the `recorderStart` event.
   *
   * @public
   */
  readonly recorderStart: OutputEmitterRef<ElementEventDetail<PromptBoxVoiceRecorderToolElement, 'recorderStart'>>;
  /**
   * Output signal for the `recorderStop` event.
   *
   * @public
   */
  readonly recorderStop: OutputEmitterRef<ElementEventDetail<PromptBoxVoiceRecorderToolElement, 'recorderStop'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<PromptBoxVoiceRecorderToolElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<PromptBoxVoiceRecorderToolElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<PromptBoxVoiceRecorderToolElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Preserves the abstract execution behavior of the former chat voice tool.
   *
   * @public
   */
  execute(...args: Parameters<PromptBoxVoiceRecorderToolElement['execute']>): ReturnType<PromptBoxVoiceRecorderToolElement['execute']>;
  /**
   * Attaches this tool to a Prompt Box.
   *
   * @public
   */
  attach(...args: Parameters<PromptBoxVoiceRecorderToolElement['attach']>): ReturnType<PromptBoxVoiceRecorderToolElement['attach']>;
  /**
   * Detaches this tool from a Prompt Box.
   *
   * @public
   */
  detach(...args: Parameters<PromptBoxVoiceRecorderToolElement['detach']>): ReturnType<PromptBoxVoiceRecorderToolElement['detach']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `execute()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends PromptBoxVoiceRecorderToolMethodNames>(method: TMethod, ...args: Parameters<PromptBoxVoiceRecorderToolComponentMethods[TMethod]>): ReturnType<PromptBoxVoiceRecorderToolComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof PromptBoxVoiceRecorderToolElement>(property: TProperty, value: PromptBoxVoiceRecorderToolElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<PromptBoxVoiceRecorderToolElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<PromptBoxVoiceRecorderToolComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<PromptBoxVoiceRecorderToolComponent, "mosaik-prompt-box-voice-recorder-tool", never, {
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "state": {
      "alias": "state";
      "required": false;
      "isSignal": true;
    };
    "elapsedTime": {
      "alias": "elapsedTime";
      "required": false;
      "isSignal": true;
    };
    "maxDurationTime": {
      "alias": "maxDurationTime";
      "required": false;
      "isSignal": true;
    };
    "objectUrl": {
      "alias": "objectUrl";
      "required": false;
      "isSignal": true;
    };
    "canPause": {
      "alias": "canPause";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dock": {
      "alias": "dock";
      "required": false;
      "isSignal": true;
    };
    "disabledWhen": {
      "alias": "disabledWhen";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "recorderCancel": "recorderCancel";
    "recorderPause": "recorderPause";
    "recorderResume": "recorderResume";
    "recorderStart": "recorderStart";
    "recorderStop": "recorderStop";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on PromptBoxVoiceRecorderToolComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type PromptBoxVoiceRecorderToolMethodNames = 'execute' | 'attach' | 'detach';
/**
 * Declares the methods interface for PromptBoxVoiceRecorderToolComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type PromptBoxVoiceRecorderToolComponentMethods = MethodMap<PromptBoxVoiceRecorderToolMethodNames>;
/**
 * @public
 */
export declare function providePromptBoxVoiceRecorderToolComponent(config?: Partial<PromptBoxVoiceRecorderToolElement.Props>, intl?: Partial<PromptBoxVoiceRecorderToolElement['intl']> | Type<Partial<PromptBoxVoiceRecorderToolElement['intl']>>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the PromptBoxComponent.
 * Use this token to provide default properties for the PromptBoxComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const PROMPT_BOX_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").IPromptBoxElementProps>>;
/**
 * @public
 *
 * Injection token for the intl configuration of the PromptBoxComponent.
 * Provide a partial intl object or an injectable class that resolves translations.
 * This allows third-party applications to override the default intl labels
 * globally, per route, or per component via Angular's dependency injection.
 *
 * Merge order: Foundation defaults → DI intl → [intl] input binding.
 */
export declare const PROMPT_BOX_INTL: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").PromptBoxElementIntl>>;
/**
 * @public
 *
 * @slot content - The content slot.
 * @slot editor - The editor slot.
 * @slot header - Optional content shown on a strip of its own above the box.
 * @slot tools - The tools slot.
 * @slot top - Optional content shown above the header, without a surface of its own.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class PromptBoxComponent implements ControlValueAccessor {
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<PromptBoxElement['label'] | undefined>;
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<Partial<PromptBoxElement['intl']> | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<PromptBoxElement['value'] | undefined>;
  /**
   * Signal input for the `mentionDocument` property.
   *
   * @public
   */
  readonly mentionDocument: InputSignal<PromptBoxElement['mentionDocument'] | undefined>;
  /**
   * Signal input for the `suggestions` property.
   *
   * @public
   */
  readonly suggestions: InputSignal<PromptBoxElement['suggestions'] | undefined>;
  /**
   * Signal input for the `entries` property.
   *
   * @public
   */
  readonly entries: InputSignal<PromptBoxElement['entries'] | undefined>;
  /**
   * Signal input for the `queue` property.
   *
   * @public
   */
  readonly queue: InputSignal<PromptBoxElement['queue'] | undefined>;
  /**
   * Signal input for the `queueOnBusy` property.
   *
   * @public
   */
  readonly queueOnBusy: InputSignal<PromptBoxElement['queueOnBusy'] | undefined>;
  /**
   * Signal input for the `queuePaused` property.
   *
   * @public
   */
  readonly queuePaused: InputSignal<PromptBoxElement['queuePaused'] | undefined>;
  /**
   * Signal input for the `tools` property.
   *
   * @public
   */
  readonly tools: InputSignal<PromptBoxElement['tools'] | undefined>;
  /**
   * Signal input for the `placeholder` property.
   *
   * @public
   */
  readonly placeholder: InputSignal<PromptBoxElement['placeholder'] | undefined>;
  /**
   * Signal input for the `minRows` property.
   *
   * @public
   */
  readonly minRows: InputSignal<PromptBoxElement['minRows'] | undefined>;
  /**
   * Signal input for the `maxRows` property.
   *
   * @public
   */
  readonly maxRows: InputSignal<PromptBoxElement['maxRows'] | undefined>;
  /**
   * Signal input for the `showSubmitButton` property.
   *
   * @public
   */
  readonly showSubmitButton: InputSignal<PromptBoxElement['showSubmitButton'] | undefined>;
  /**
   * Signal input for the `submitOnEnter` property.
   *
   * @public
   */
  readonly submitOnEnter: InputSignal<PromptBoxElement['submitOnEnter'] | undefined>;
  /**
   * Signal input for the `readonly` property.
   *
   * @public
   */
  readonly readonly: InputSignal<PromptBoxElement['readonly'] | undefined>;
  /**
   * Signal input for the `required` property.
   *
   * @public
   */
  readonly required: InputSignal<PromptBoxElement['required'] | undefined>;
  /**
   * Signal input for the `autofocus` property.
   *
   * @public
   */
  readonly autofocus: InputSignal<PromptBoxElement['autofocus'] | undefined>;
  /**
   * Signal input for the `name` property.
   *
   * @public
   */
  readonly name: InputSignal<PromptBoxElement['name'] | undefined>;
  /**
   * Signal input for the `minlength` property.
   *
   * @public
   */
  readonly minlength: InputSignal<PromptBoxElement['minlength'] | undefined>;
  /**
   * Signal input for the `maxlength` property.
   *
   * @public
   */
  readonly maxlength: InputSignal<PromptBoxElement['maxlength'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<PromptBoxElement['themeName'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<PromptBoxElement['appearance'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<PromptBoxElement['variant'] | undefined>;
  /**
   * Signal input for the `isBusy` property.
   *
   * @public
   */
  readonly isBusy: InputSignal<PromptBoxElement['isBusy'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<PromptBoxElement['disabled'] | undefined>;
  /**
   * Signal input for the `formatter` property.
   *
   * @public
   */
  readonly formatter: InputSignal<PromptBoxElement['formatter'] | undefined>;
  /**
   * Signal input for the `parser` property.
   *
   * @public
   */
  readonly parser: InputSignal<PromptBoxElement['parser'] | undefined>;
  /**
   * Signal input for the `isFocused` property.
   *
   * @public
   */
  readonly isFocused: InputSignal<PromptBoxElement['isFocused'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<PromptBoxElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<PromptBoxElement['lang'] | undefined>;
  /**
   * Output signal for the `entriesChanged` event.
   *
   * @public
   */
  readonly entriesChanged: OutputEmitterRef<ElementEventDetail<PromptBoxElement, 'entriesChanged'>>;
  /**
   * Output signal for the `promptQueued` event.
   *
   * @public
   */
  readonly promptQueued: OutputEmitterRef<ElementEventDetail<PromptBoxElement, 'promptQueued'>>;
  /**
   * Output signal for the `promptSubmitted` event.
   *
   * @public
   */
  readonly promptSubmitted: OutputEmitterRef<ElementEventDetail<PromptBoxElement, 'promptSubmitted'>>;
  /**
   * Output signal for the `queueChanged` event.
   *
   * @public
   */
  readonly queueChanged: OutputEmitterRef<ElementEventDetail<PromptBoxElement, 'queueChanged'>>;
  /**
   * Output signal for the `stopRequested` event.
   *
   * @public
   */
  readonly stopRequested: OutputEmitterRef<ElementEventDetail<PromptBoxElement, 'stopRequested'>>;
  /**
   * Output signal for the `steerRequested` event.
   *
   * @public
   */
  readonly steerRequested: OutputEmitterRef<ElementEventDetail<PromptBoxElement, 'steerRequested'>>;
  /**
   * Output signal for the `queuePausedChanged` event.
   *
   * @public
   */
  readonly queuePausedChanged: OutputEmitterRef<ElementEventDetail<PromptBoxElement, 'queuePausedChanged'>>;
  /**
   * Output signal for the `queueActionInvoked` event.
   *
   * @public
   */
  readonly queueActionInvoked: OutputEmitterRef<ElementEventDetail<PromptBoxElement, 'queueActionInvoked'>>;
  /**
   * Output signal for the `suggestionSelected` event.
   *
   * @public
   */
  readonly suggestionSelected: OutputEmitterRef<ElementEventDetail<PromptBoxElement, 'suggestionSelected'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<PromptBoxElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<PromptBoxElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<PromptBoxElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: PromptBoxElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: PromptBoxElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  private readonly _accessor;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Applies a value supplied by Angular forms to the native control.
   *
   * @public
   */
  writeValue(obj: unknown): void;
  /**
   * Registers the callback notified when the native control value changes.
   *
   * @public
   */
  registerOnChange(fn: unknown): void;
  /**
   * Registers the callback notified when the native control is touched.
   *
   * @public
   */
  registerOnTouched(fn: unknown): void;
  /**
   * Applies the disabled state supplied by Angular forms.
   *
   * @public
   */
  setDisabledState?(isDisabled: boolean): void;
  /**
   * Registers a tool and returns an idempotent disposer.
   *
   * @public
   */
  registerTool(...args: Parameters<PromptBoxElement['registerTool']>): ReturnType<PromptBoxElement['registerTool']>;
  /**
   * Unregisters one registration of a tool.
   *
   * @public
   */
  unregisterTool(...args: Parameters<PromptBoxElement['unregisterTool']>): ReturnType<PromptBoxElement['unregisterTool']>;
  /**
   * Adds an entry.
   *
   * @public
   */
  addEntry(...args: Parameters<PromptBoxElement['addEntry']>): ReturnType<PromptBoxElement['addEntry']>;
  /**
   * Replaces an existing entry with the same identifier.
   *
   * @public
   * @returns `true` when an entry was replaced.
   */
  updateEntry(...args: Parameters<PromptBoxElement['updateEntry']>): ReturnType<PromptBoxElement['updateEntry']>;
  /**
   * Removes an entry by identifier.
   *
   * @public
   * @returns `true` when an entry was removed.
   */
  removeEntry(...args: Parameters<PromptBoxElement['removeEntry']>): ReturnType<PromptBoxElement['removeEntry']>;
  /**
   * Removes every entry.
   *
   * @public
   */
  clearEntries(...args: Parameters<PromptBoxElement['clearEntries']>): ReturnType<PromptBoxElement['clearEntries']>;
  /**
   * Appends a prompt to the queue.
   *
   * @public
   * @returns The queued prompt.
   */
  enqueue(...args: Parameters<PromptBoxElement['enqueue']>): ReturnType<PromptBoxElement['enqueue']>;
  /**
   * Removes and returns the prompt at the head of the queue.
   *
   * @public
   * @returns The prompt that was waiting, or `null` when the queue is empty or paused.
   */
  dequeue(...args: Parameters<PromptBoxElement['dequeue']>): ReturnType<PromptBoxElement['dequeue']>;
  /**
   * Returns the prompt at the head of the queue without removing it.
   *
   * @public
   */
  peekQueue(...args: Parameters<PromptBoxElement['peekQueue']>): ReturnType<PromptBoxElement['peekQueue']>;
  /**
   * Removes a queued prompt by identifier.
   *
   * @public
   * @returns `true` when a prompt was removed.
   */
  removeQueued(...args: Parameters<PromptBoxElement['removeQueued']>): ReturnType<PromptBoxElement['removeQueued']>;
  /**
   * Moves a queued prompt to another position.
   *
   * @public
   * @param args - The arguments of `moveQueued`:
   * - `entryId` - The prompt to move.
   * - `toIndex` - The position it should end up at.
   * @returns `true` when the queue order changed.
   */
  moveQueued(...args: Parameters<PromptBoxElement['moveQueued']>): ReturnType<PromptBoxElement['moveQueued']>;
  /**
   * Removes every queued prompt.
   *
   * @public
   */
  clearQueue(...args: Parameters<PromptBoxElement['clearQueue']>): ReturnType<PromptBoxElement['clearQueue']>;
  /**
   * Asks the consumer to steer the prompt it is busy with using a queued
   * prompt.
   *
   * @public
   * @param args - The arguments of `steerQueued`:
   * - `entryId` - The queued prompt that should steer.
   * @returns `true` when a steer was requested.
   */
  steerQueued(...args: Parameters<PromptBoxElement['steerQueued']>): ReturnType<PromptBoxElement['steerQueued']>;
  /**
   * Takes a queued prompt back into the editor.
   *
   * @public
   * @param args - The arguments of `editQueued`:
   * - `entryId` - The queued prompt to edit.
   * @returns `true` when a prompt was taken back into the editor.
   */
  editQueued(...args: Parameters<PromptBoxElement['editQueued']>): ReturnType<PromptBoxElement['editQueued']>;
  /**
   * Raises an application-defined action for a queued prompt.
   *
   * @public
   * @param args - The arguments of `invokeQueuedAction`:
   * - `action` - The action that was chosen.
   * - `entryId` - The queued prompt the action was chosen on.
   * @returns `true` when the action was raised.
   */
  invokeQueuedAction(...args: Parameters<PromptBoxElement['invokeQueuedAction']>): ReturnType<PromptBoxElement['invokeQueuedAction']>;
  /**
   * Clears the text and entry collection.
   *
   * @public
   */
  clear(...args: Parameters<PromptBoxElement['clear']>): ReturnType<PromptBoxElement['clear']>;
  /**
   * Resets the value and validation state.
   *
   * @public
   */
  reset(...args: Parameters<PromptBoxElement['reset']>): ReturnType<PromptBoxElement['reset']>;
  /**
   * Checks the native editor validity.
   *
   * @public
   */
  checkValidity(...args: Parameters<PromptBoxElement['checkValidity']>): ReturnType<PromptBoxElement['checkValidity']>;
  /**
   * Submits the current prompt, or queues it while the Prompt Box is busy.
   *
   * @public
   * @returns `true` when a prompt was submitted or queued.
   */
  submit(...args: Parameters<PromptBoxElement['submit']>): ReturnType<PromptBoxElement['submit']>;
  /**
   * Asks the consumer to stop the prompt it is busy with.
   *
   * @public
   * @returns `true` when a stop was requested.
   */
  stop(...args: Parameters<PromptBoxElement['stop']>): ReturnType<PromptBoxElement['stop']>;
  /**
   * Sets focus to the native editor.
   *
   * @public
   */
  focus(...args: Parameters<PromptBoxElement['focus']>): ReturnType<PromptBoxElement['focus']>;
  /**
   * Removes focus from the native editor.
   *
   * @public
   */
  blur(...args: Parameters<PromptBoxElement['blur']>): ReturnType<PromptBoxElement['blur']>;
  /**
   * Reconciles automatically slotted Web Component tools.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<PromptBoxElement['onSlotChanges']>): ReturnType<PromptBoxElement['onSlotChanges']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<PromptBoxElement['assignToSlot']>): ReturnType<PromptBoxElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<PromptBoxElement['getSlotContent']>): ReturnType<PromptBoxElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<PromptBoxElement['hasSlotContent']>): ReturnType<PromptBoxElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<PromptBoxElement['hasSlot']>): ReturnType<PromptBoxElement['hasSlot']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `registerTool()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * The other names it accepts are not public in the type declarations of `PromptBoxElement`.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends PromptBoxMethodNames>(method: TMethod, ...args: Parameters<PromptBoxComponentMethods[TMethod]>): ReturnType<PromptBoxComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof PromptBoxElement>(property: TProperty, value: PromptBoxElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<PromptBoxElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<PromptBoxComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<PromptBoxComponent, "mosaik-prompt-box", never, {
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "mentionDocument": {
      "alias": "mentionDocument";
      "required": false;
      "isSignal": true;
    };
    "suggestions": {
      "alias": "suggestions";
      "required": false;
      "isSignal": true;
    };
    "entries": {
      "alias": "entries";
      "required": false;
      "isSignal": true;
    };
    "queue": {
      "alias": "queue";
      "required": false;
      "isSignal": true;
    };
    "queueOnBusy": {
      "alias": "queueOnBusy";
      "required": false;
      "isSignal": true;
    };
    "queuePaused": {
      "alias": "queuePaused";
      "required": false;
      "isSignal": true;
    };
    "tools": {
      "alias": "tools";
      "required": false;
      "isSignal": true;
    };
    "placeholder": {
      "alias": "placeholder";
      "required": false;
      "isSignal": true;
    };
    "minRows": {
      "alias": "minRows";
      "required": false;
      "isSignal": true;
    };
    "maxRows": {
      "alias": "maxRows";
      "required": false;
      "isSignal": true;
    };
    "showSubmitButton": {
      "alias": "showSubmitButton";
      "required": false;
      "isSignal": true;
    };
    "submitOnEnter": {
      "alias": "submitOnEnter";
      "required": false;
      "isSignal": true;
    };
    "readonly": {
      "alias": "readonly";
      "required": false;
      "isSignal": true;
    };
    "required": {
      "alias": "required";
      "required": false;
      "isSignal": true;
    };
    "autofocus": {
      "alias": "autofocus";
      "required": false;
      "isSignal": true;
    };
    "name": {
      "alias": "name";
      "required": false;
      "isSignal": true;
    };
    "minlength": {
      "alias": "minlength";
      "required": false;
      "isSignal": true;
    };
    "maxlength": {
      "alias": "maxlength";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "isBusy": {
      "alias": "isBusy";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "formatter": {
      "alias": "formatter";
      "required": false;
      "isSignal": true;
    };
    "parser": {
      "alias": "parser";
      "required": false;
      "isSignal": true;
    };
    "isFocused": {
      "alias": "isFocused";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "entriesChanged": "entriesChanged";
    "promptQueued": "promptQueued";
    "promptSubmitted": "promptSubmitted";
    "queueChanged": "queueChanged";
    "stopRequested": "stopRequested";
    "steerRequested": "steerRequested";
    "queuePausedChanged": "queuePausedChanged";
    "queueActionInvoked": "queueActionInvoked";
    "suggestionSelected": "suggestionSelected";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, [{
    directive: typeof i1.FormStatusHostDirective;
    inputs: {};
    outputs: {};
  }, {
    directive: typeof i1.FormFieldStatusHostDirective;
    inputs: {};
    outputs: {};
  }]>;
}
/**
 * Declares the methods available on PromptBoxComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type PromptBoxMethodNames = 'registerTool' | 'unregisterTool' | 'addEntry' | 'updateEntry' | 'removeEntry' | 'clearEntries' | 'enqueue' | 'dequeue' | 'peekQueue' | 'removeQueued' | 'moveQueued' | 'clearQueue' | 'steerQueued' | 'editQueued' | 'invokeQueuedAction' | 'clear' | 'reset' | 'checkValidity' | 'submit' | 'stop' | 'focus' | 'blur' | 'onInput' | 'onFocus' | 'onBlur' | 'onSlotChanges' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot';
/**
 * Declares the methods interface for PromptBoxComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type PromptBoxComponentMethods = MethodMap<PromptBoxMethodNames>;
/**
 * @public
 */
export declare function providePromptBoxComponent(config?: Partial<PromptBoxElement.Props>, intl?: Partial<PromptBoxElement['intl']> | Type<Partial<PromptBoxElement['intl']>>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-prompt-box.d.ts.map