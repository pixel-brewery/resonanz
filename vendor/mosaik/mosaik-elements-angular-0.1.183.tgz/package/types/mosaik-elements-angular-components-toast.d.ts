import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { ToastActionsElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/overlays/toast/ToastActionsElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { ToastElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/overlays/toast/ToastElement";
/**
 * @public
 *
 * Injection token for the default properties of the ToastActionsComponent.
 * Use this token to provide default properties for the ToastActionsComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const TOAST_ACTIONS_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/overlays/toast/IToastActionsElementProps").IToastActionsElementProps>>;
/**
 * @public
 *
 * @slot  - The default content slot for action buttons.
 * @slot prefix - The prefix slot.
 * @slot suffix - The suffix slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ToastActionsComponent {
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ToastActionsElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ToastActionsElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ToastActionsElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ToastActionsElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ToastActionsElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ToastActionsElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: ToastActionsElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: ToastActionsElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<ToastActionsElement['assignToSlot']>): ReturnType<ToastActionsElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<ToastActionsElement['getSlotContent']>): ReturnType<ToastActionsElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<ToastActionsElement['hasSlotContent']>): ReturnType<ToastActionsElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<ToastActionsElement['hasSlot']>): ReturnType<ToastActionsElement['hasSlot']>;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<ToastActionsElement['onSlotChanges']>): ReturnType<ToastActionsElement['onSlotChanges']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `assignToSlot()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends ToastActionsMethodNames>(method: TMethod, ...args: Parameters<ToastActionsComponentMethods[TMethod]>): ReturnType<ToastActionsComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ToastActionsElement>(property: TProperty, value: ToastActionsElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ToastActionsElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ToastActionsComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ToastActionsComponent, "mosaik-toast-actions", never, {
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on ToastActionsComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ToastActionsMethodNames = 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges';
/**
 * Declares the methods interface for ToastActionsComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ToastActionsComponentMethods = MethodMap<ToastActionsMethodNames>;
/**
 * @public
 */
export declare function provideToastActionsComponent(config?: Partial<ToastActionsElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the ToastComponent.
 * Use this token to provide default properties for the ToastComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const TOAST_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/overlays/toast/IToastElementProps").IToastElementProps>>;
/**
 * @public
 *
 * @slot actions - The actions slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ToastComponent {
  /**
   * Signal input for the `header` property.
   *
   * @public
   */
  readonly header: InputSignal<ToastElement['header'] | undefined>;
  /**
   * Signal input for the `content` property.
   *
   * @public
   */
  readonly content: InputSignal<ToastElement['content'] | undefined>;
  /**
   * Signal input for the `icon` property.
   *
   * @public
   */
  readonly icon: InputSignal<ToastElement['icon'] | undefined>;
  /**
   * Signal input for the `iconSize` property.
   *
   * @public
   */
  readonly iconSize: InputSignal<ToastElement['iconSize'] | undefined>;
  /**
   * Signal input for the `maxWidth` property.
   *
   * @public
   */
  readonly maxWidth: InputSignal<ToastElement['maxWidth'] | undefined>;
  /**
   * Signal input for the `timeout` property.
   *
   * @public
   */
  readonly timeout: InputSignal<ToastElement['timeout'] | undefined>;
  /**
   * Signal input for the `position` property.
   *
   * @public
   */
  readonly position: InputSignal<ToastElement['position'] | undefined>;
  /**
   * Signal input for the `showProgress` property.
   *
   * @public
   */
  readonly showProgress: InputSignal<ToastElement['showProgress'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ToastElement['themeName'] | undefined>;
  /**
   * Signal input for the `enter` property.
   *
   * @public
   */
  readonly enter: InputSignal<ToastElement['enter'] | undefined>;
  /**
   * Signal input for the `exit` property.
   *
   * @public
   */
  readonly exit: InputSignal<ToastElement['exit'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<ToastElement['variant'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<ToastElement['appearance'] | undefined>;
  /**
   * Signal input for the `formatter` property.
   *
   * @public
   */
  readonly formatter: InputSignal<ToastElement['formatter'] | undefined>;
  /**
   * Signal input for the `isBusy` property.
   *
   * @public
   */
  readonly isBusy: InputSignal<ToastElement['isBusy'] | undefined>;
  /**
   * Signal input for the `isOpen` property.
   *
   * @public
   */
  readonly isOpen: InputSignal<ToastElement['isOpen'] | undefined>;
  /**
   * Signal input for the `hasBackdrop` property.
   *
   * @public
   */
  readonly hasBackdrop: InputSignal<ToastElement['hasBackdrop'] | undefined>;
  /**
   * Signal input for the `pressEscapeToClose` property.
   *
   * @public
   */
  readonly pressEscapeToClose: InputSignal<ToastElement['pressEscapeToClose'] | undefined>;
  /**
   * Signal input for the `clickOutsideToClose` property.
   *
   * @public
   */
  readonly clickOutsideToClose: InputSignal<ToastElement['clickOutsideToClose'] | undefined>;
  /**
   * Signal input for the `attention` property.
   *
   * @public
   */
  readonly attention: InputSignal<ToastElement['attention'] | undefined>;
  /**
   * Signal input for the `closeable` property.
   *
   * @public
   */
  readonly closeable: InputSignal<ToastElement['closeable'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ToastElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ToastElement['lang'] | undefined>;
  /**
   * Output signal for the `opened` event.
   *
   * @public
   */
  readonly opened: OutputEmitterRef<ElementEventDetail<ToastElement, 'opened'>>;
  /**
   * Output signal for the `closed` event.
   *
   * @public
   */
  readonly closed: OutputEmitterRef<ElementEventDetail<ToastElement, 'closed'>>;
  /**
   * Output signal for the `closeAttempted` event.
   *
   * @public
   */
  readonly closeAttempted: OutputEmitterRef<ElementEventDetail<ToastElement, 'closeAttempted'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ToastElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ToastElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ToastElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Opens the `ToastElement`.
   *
   * @public
   */
  open(...args: Parameters<ToastElement['open']>): ReturnType<ToastElement['open']>;
  /**
   * Closes the `ToastElement`.
   *
   * @public
   */
  close(...args: Parameters<ToastElement['close']>): ReturnType<ToastElement['close']>;
  /**
   * Executes the animation.
   *
   * @public
   */
  play(...args: Parameters<ToastElement['play']>): ReturnType<ToastElement['play']>;
  /**
   * A lifecycle hook that is invoked when the element is added to the DOM.
   *
   * @public
   */
  onEnterAnimation(...args: Parameters<NonNullable<ToastElement['onEnterAnimation']>>): ReturnType<NonNullable<ToastElement['onEnterAnimation']>> | undefined;
  /**
   * A lifecycle hook that is invoked when the element is removed from the DOM.
   *
   * @public
   */
  onExitAnimation(...args: Parameters<NonNullable<ToastElement['onExitAnimation']>>): ReturnType<NonNullable<ToastElement['onExitAnimation']>> | undefined;
  /**
   * Requests visual attention for this overlay.
   *
   * @public
   * @param args - The arguments of `requestAttention`:
   * - `animation` - Optional animation used for this attention request.
   * @returns Whether the attention animation finished.
   */
  requestAttention(...args: Parameters<ToastElement['requestAttention']>): ReturnType<ToastElement['requestAttention']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `open()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends ToastMethodNames>(method: TMethod, ...args: Parameters<ToastComponentMethods[TMethod]>): ReturnType<ToastComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ToastElement>(property: TProperty, value: ToastElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ToastElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ToastComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ToastComponent, "mosaik-toast", never, {
    "header": {
      "alias": "header";
      "required": false;
      "isSignal": true;
    };
    "content": {
      "alias": "content";
      "required": false;
      "isSignal": true;
    };
    "icon": {
      "alias": "icon";
      "required": false;
      "isSignal": true;
    };
    "iconSize": {
      "alias": "iconSize";
      "required": false;
      "isSignal": true;
    };
    "maxWidth": {
      "alias": "maxWidth";
      "required": false;
      "isSignal": true;
    };
    "timeout": {
      "alias": "timeout";
      "required": false;
      "isSignal": true;
    };
    "position": {
      "alias": "position";
      "required": false;
      "isSignal": true;
    };
    "showProgress": {
      "alias": "showProgress";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "enter": {
      "alias": "enter";
      "required": false;
      "isSignal": true;
    };
    "exit": {
      "alias": "exit";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "formatter": {
      "alias": "formatter";
      "required": false;
      "isSignal": true;
    };
    "isBusy": {
      "alias": "isBusy";
      "required": false;
      "isSignal": true;
    };
    "isOpen": {
      "alias": "isOpen";
      "required": false;
      "isSignal": true;
    };
    "hasBackdrop": {
      "alias": "hasBackdrop";
      "required": false;
      "isSignal": true;
    };
    "pressEscapeToClose": {
      "alias": "pressEscapeToClose";
      "required": false;
      "isSignal": true;
    };
    "clickOutsideToClose": {
      "alias": "clickOutsideToClose";
      "required": false;
      "isSignal": true;
    };
    "attention": {
      "alias": "attention";
      "required": false;
      "isSignal": true;
    };
    "closeable": {
      "alias": "closeable";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "opened": "opened";
    "closed": "closed";
    "closeAttempted": "closeAttempted";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on ToastComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ToastMethodNames = 'open' | 'close' | 'play' | 'onEnterAnimation' | 'onExitAnimation' | 'requestAttention';
/**
 * Declares the methods interface for ToastComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ToastComponentMethods = MethodMap<ToastMethodNames>;
/**
 * @public
 */
export declare function provideToastComponent(config?: Partial<ToastElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-toast.d.ts.map