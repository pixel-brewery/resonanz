import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { MenuItemGroupElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/menu/MenuItemGroupElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { MenuItemElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/menu/MenuItemElement";
import { MenuElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/menu/MenuElement";
/**
 * @public
 *
 * Injection token for the default properties of the MenuItemGroupComponent.
 * Use this token to provide default properties for the MenuItemGroupComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const MENU_ITEM_GROUP_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/selectors/menu/IMenuItemGroupElementProps").IMenuItemGroupElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot for menu items (mosaik-menu-item elements)
 * @slot header - Custom header content (overrides the default header text)
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class MenuItemGroupComponent {
  /**
   * Signal input for the `textOverflow` property.
   *
   * @public
   */
  readonly textOverflow: InputSignal<MenuItemGroupElement['textOverflow'] | undefined>;
  /**
   * Signal input for the `header` property.
   *
   * @public
   */
  readonly header: InputSignal<MenuItemGroupElement['header'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<MenuItemGroupElement['themeName'] | undefined>;
  /**
   * Signal input for the `formatter` property.
   *
   * @public
   */
  readonly formatter: InputSignal<MenuItemGroupElement['formatter'] | undefined>;
  /**
   * Signal input for the `orientation` property.
   *
   * @public
   */
  readonly orientation: InputSignal<MenuItemGroupElement['orientation'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<MenuItemGroupElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<MenuItemGroupElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<MenuItemGroupElement, 'connected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<MenuItemGroupElement, 'changed'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<MenuItemGroupElement, 'disconnected'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof MenuItemGroupElement>(property: TProperty, value: MenuItemGroupElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<MenuItemGroupElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<MenuItemGroupComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<MenuItemGroupComponent, "mosaik-menu-item-group", never, {
    "textOverflow": {
      "alias": "textOverflow";
      "required": false;
      "isSignal": true;
    };
    "header": {
      "alias": "header";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "formatter": {
      "alias": "formatter";
      "required": false;
      "isSignal": true;
    };
    "orientation": {
      "alias": "orientation";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "changed": "changed";
    "disconnected": "disconnected";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on MenuItemGroupComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type MenuItemGroupMethodNames = never;
/**
 * Declares the methods interface for MenuItemGroupComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type MenuItemGroupComponentMethods = MethodMap<MenuItemGroupMethodNames>;
/**
 * @public
 */
export declare function provideMenuItemGroupComponent(config?: Partial<MenuItemGroupElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the MenuItemComponent.
 * Use this token to provide default properties for the MenuItemComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const MENU_ITEM_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/selectors/menu/IMenuItemElementProps").IMenuItemElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot.
 * @slot end - Content displayed at the end (after label)
 * @slot icon - The icon displayed for this menu item
 * @slot label - The primary label text
 * @slot start - Content displayed at the start (before icon)
 * @slot subLabel - Secondary descriptive text below the label
 * @slot submenu - Child menu items rendered as a submenu
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class MenuItemComponent {
  /**
   * Signal input for the `subLabel` property.
   *
   * @public
   */
  readonly subLabel: InputSignal<MenuItemElement['subLabel'] | undefined>;
  /**
   * Signal input for the `icon` property.
   *
   * @public
   */
  readonly icon: InputSignal<MenuItemElement['icon'] | undefined>;
  /**
   * Signal input for the `isActive` property.
   *
   * @public
   */
  readonly isActive: InputSignal<MenuItemElement['isActive'] | undefined>;
  /**
   * Signal input for the `isChecked` property.
   *
   * @public
   */
  readonly isChecked: InputSignal<MenuItemElement['isChecked'] | undefined>;
  /**
   * Signal input for the `isExpanded` property.
   *
   * @public
   */
  readonly isExpanded: InputSignal<MenuItemElement['isExpanded'] | undefined>;
  /**
   * Signal input for the `menuMode` property.
   *
   * @public
   */
  readonly menuMode: InputSignal<MenuItemElement['menuMode'] | undefined>;
  /**
   * Signal input for the `textOverflow` property.
   *
   * @public
   */
  readonly textOverflow: InputSignal<MenuItemElement['textOverflow'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<MenuItemElement['themeName'] | undefined>;
  /**
   * Signal input for the `size` property.
   *
   * @public
   */
  readonly size: InputSignal<MenuItemElement['size'] | undefined>;
  /**
   * Signal input for the `ripple` property.
   *
   * @public
   */
  readonly ripple: InputSignal<MenuItemElement['ripple'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<MenuItemElement['disabled'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<MenuItemElement['value'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<MenuItemElement['variant'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<MenuItemElement['appearance'] | undefined>;
  /**
   * Signal input for the `isFocused` property.
   *
   * @public
   */
  readonly isFocused: InputSignal<MenuItemElement['isFocused'] | undefined>;
  /**
   * Signal input for the `formatter` property.
   *
   * @public
   */
  readonly formatter: InputSignal<MenuItemElement['formatter'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<MenuItemElement['label'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<MenuItemElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<MenuItemElement['lang'] | undefined>;
  /**
   * Output signal for the `activated` event.
   *
   * @public
   */
  readonly activated: OutputEmitterRef<ElementEventDetail<MenuItemElement, 'activated'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<MenuItemElement, 'connected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<MenuItemElement, 'changed'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<MenuItemElement, 'disconnected'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: MenuItemElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: MenuItemElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Expands the menu item.
   *
   * @public
   */
  expand(...args: Parameters<MenuItemElement['expand']>): ReturnType<MenuItemElement['expand']>;
  /**
   * Collapses the menu item.
   *
   * @public
   */
  collapse(...args: Parameters<MenuItemElement['collapse']>): ReturnType<MenuItemElement['collapse']>;
  /**
   * Toggles the expanded state of the menu item.
   *
   * @public
   */
  toggle(...args: Parameters<MenuItemElement['toggle']>): ReturnType<MenuItemElement['toggle']>;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<MenuItemElement['onSlotChanges']>): ReturnType<MenuItemElement['onSlotChanges']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<MenuItemElement['assignToSlot']>): ReturnType<MenuItemElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<MenuItemElement['getSlotContent']>): ReturnType<MenuItemElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<MenuItemElement['hasSlotContent']>): ReturnType<MenuItemElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<MenuItemElement['hasSlot']>): ReturnType<MenuItemElement['hasSlot']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `expand()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends MenuItemMethodNames>(method: TMethod, ...args: Parameters<MenuItemComponentMethods[TMethod]>): ReturnType<MenuItemComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof MenuItemElement>(property: TProperty, value: MenuItemElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<MenuItemElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<MenuItemComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<MenuItemComponent, "mosaik-menu-item", never, {
    "subLabel": {
      "alias": "subLabel";
      "required": false;
      "isSignal": true;
    };
    "icon": {
      "alias": "icon";
      "required": false;
      "isSignal": true;
    };
    "isActive": {
      "alias": "isActive";
      "required": false;
      "isSignal": true;
    };
    "isChecked": {
      "alias": "isChecked";
      "required": false;
      "isSignal": true;
    };
    "isExpanded": {
      "alias": "isExpanded";
      "required": false;
      "isSignal": true;
    };
    "menuMode": {
      "alias": "menuMode";
      "required": false;
      "isSignal": true;
    };
    "textOverflow": {
      "alias": "textOverflow";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "ripple": {
      "alias": "ripple";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "isFocused": {
      "alias": "isFocused";
      "required": false;
      "isSignal": true;
    };
    "formatter": {
      "alias": "formatter";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "activated": "activated";
    "connected": "connected";
    "changed": "changed";
    "disconnected": "disconnected";
  }, never, ["[slot=end]", "[slot=icon]", "[slot=label]", "[slot=start]", "[slot=subLabel]", "[slot=submenu]", "[slot=style]", "*"], true, never>;
}
/**
 * Declares the methods available on MenuItemComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type MenuItemMethodNames = 'expand' | 'collapse' | 'toggle' | 'onSlotChanges' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot';
/**
 * Declares the methods interface for MenuItemComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type MenuItemComponentMethods = MethodMap<MenuItemMethodNames>;
/**
 * @public
 */
export declare function provideMenuItemComponent(config?: Partial<MenuItemElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the MenuComponent.
 * Use this token to provide default properties for the MenuComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const MENU_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/selectors/menu/IMenuElementProps").IMenuElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class MenuComponent {
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<MenuElement['themeName'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<MenuElement['disabled'] | undefined>;
  /**
   * Signal input for the `inset` property.
   *
   * @public
   */
  readonly inset: InputSignal<MenuElement['inset'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<MenuElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<MenuElement['lang'] | undefined>;
  /**
   * Output signal for the `activated` event.
   *
   * @public
   */
  readonly activated: OutputEmitterRef<ElementEventDetail<MenuElement, 'activated'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<MenuElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<MenuElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<MenuElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof MenuElement>(property: TProperty, value: MenuElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<MenuElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<MenuComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<MenuComponent, "mosaik-menu", never, {
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "inset": {
      "alias": "inset";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "activated": "activated";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on MenuComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type MenuMethodNames = never;
/**
 * Declares the methods interface for MenuComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type MenuComponentMethods = MethodMap<MenuMethodNames>;
/**
 * @public
 */
export declare function provideMenuComponent(config?: Partial<MenuElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-menu.d.ts.map