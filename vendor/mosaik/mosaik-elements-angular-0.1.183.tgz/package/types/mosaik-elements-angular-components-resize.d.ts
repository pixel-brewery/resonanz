import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { ResizeElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/resize/ResizeElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the ResizeComponent.
 * Use this token to provide default properties for the ResizeComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const RESIZE_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/layouts/resize/IResizeElementProps").IResizeElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot for the content to be resized.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ResizeComponent {
  /**
   * Signal input for the `ghostFactory` property.
   *
   * @public
   */
  readonly ghostFactory: InputSignal<ResizeElement['ghostFactory'] | undefined>;
  /**
   * Signal input for the `mode` property.
   *
   * @public
   */
  readonly mode: InputSignal<ResizeElement['mode'] | undefined>;
  /**
   * Signal input for the `active` property.
   *
   * @public
   */
  readonly active: InputSignal<ResizeElement['active'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ResizeElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ResizeElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ResizeElement['lang'] | undefined>;
  /**
   * Output signal for the `resizeResizeStarted` event.
   *
   * @public
   */
  readonly resizeResizeStarted: OutputEmitterRef<ElementEventDetail<ResizeElement, 'resizeResizeStarted'>>;
  /**
   * Output signal for the `resizeResized` event.
   *
   * @public
   */
  readonly resizeResized: OutputEmitterRef<ElementEventDetail<ResizeElement, 'resizeResized'>>;
  /**
   * Output signal for the `resizeResizeEnded` event.
   *
   * @public
   */
  readonly resizeResizeEnded: OutputEmitterRef<ElementEventDetail<ResizeElement, 'resizeResizeEnded'>>;
  /**
   * Output signal for the `resizeResizeCanceled` event.
   *
   * @public
   */
  readonly resizeResizeCanceled: OutputEmitterRef<ElementEventDetail<ResizeElement, 'resizeResizeCanceled'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ResizeElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ResizeElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ResizeElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: ResizeElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: ResizeElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<ResizeElement['assignToSlot']>): ReturnType<ResizeElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<ResizeElement['getSlotContent']>): ReturnType<ResizeElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<ResizeElement['hasSlotContent']>): ReturnType<ResizeElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<ResizeElement['hasSlot']>): ReturnType<ResizeElement['hasSlot']>;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<ResizeElement['onSlotChanges']>): ReturnType<ResizeElement['onSlotChanges']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `assignToSlot()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends ResizeMethodNames>(method: TMethod, ...args: Parameters<ResizeComponentMethods[TMethod]>): ReturnType<ResizeComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ResizeElement>(property: TProperty, value: ResizeElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ResizeElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ResizeComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ResizeComponent, "mosaik-resize", never, {
    "ghostFactory": {
      "alias": "ghostFactory";
      "required": false;
      "isSignal": true;
    };
    "mode": {
      "alias": "mode";
      "required": false;
      "isSignal": true;
    };
    "active": {
      "alias": "active";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "resizeResizeStarted": "resizeResizeStarted";
    "resizeResized": "resizeResized";
    "resizeResizeEnded": "resizeResizeEnded";
    "resizeResizeCanceled": "resizeResizeCanceled";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on ResizeComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ResizeMethodNames = 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges';
/**
 * Declares the methods interface for ResizeComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ResizeComponentMethods = MethodMap<ResizeMethodNames>;
/**
 * @public
 */
export declare function provideResizeComponent(config?: Partial<ResizeElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-resize.d.ts.map