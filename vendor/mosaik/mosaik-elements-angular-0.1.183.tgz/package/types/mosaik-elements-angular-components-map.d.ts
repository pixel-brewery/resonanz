import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef, Type } from "@angular/core";
import { MapElement } from "@pixel-brewery/mosaik-elements-foundation/components/map";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the MapComponent.
 * Use this token to provide default properties for the MapComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const MAP_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation/components/map").IMapElementProps>>;
/**
 * @public
 *
 * Injection token for the intl configuration of the MapComponent.
 * Provide a partial intl object or an injectable class that resolves translations.
 * This allows third-party applications to override the default intl labels
 * globally, per route, or per component via Angular's dependency injection.
 *
 * Merge order: Foundation defaults → DI intl → [intl] input binding.
 */
export declare const MAP_INTL: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation/components/map").MapElementIntl>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class MapComponent {
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<Partial<MapElement['intl']> | undefined>;
  /**
   * Signal input for the `latitude` property.
   *
   * @public
   */
  readonly latitude: InputSignal<MapElement['latitude'] | undefined>;
  /**
   * Signal input for the `longitude` property.
   *
   * @public
   */
  readonly longitude: InputSignal<MapElement['longitude'] | undefined>;
  /**
   * Signal input for the `zoom` property.
   *
   * @public
   */
  readonly zoom: InputSignal<MapElement['zoom'] | undefined>;
  /**
   * Signal input for the `mode` property.
   *
   * @public
   */
  readonly mode: InputSignal<MapElement['mode'] | undefined>;
  /**
   * Signal input for the `provider` property.
   *
   * @public
   */
  readonly provider: InputSignal<MapElement['provider'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<MapElement['label'] | undefined>;
  /**
   * Signal input for the `markers` property.
   *
   * @public
   */
  readonly markers: InputSignal<MapElement['markers'] | undefined>;
  /**
   * Signal input for the `routes` property.
   *
   * @public
   */
  readonly routes: InputSignal<MapElement['routes'] | undefined>;
  /**
   * Signal input for the `cluster` property.
   *
   * @public
   */
  readonly cluster: InputSignal<MapElement['cluster'] | undefined>;
  /**
   * Signal input for the `showControls` property.
   *
   * @public
   */
  readonly showControls: InputSignal<MapElement['showControls'] | undefined>;
  /**
   * Signal input for the `mapStyle` property.
   *
   * @public
   */
  readonly mapStyle: InputSignal<MapElement['mapStyle'] | undefined>;
  /**
   * Signal input for the `vectorSource` property.
   *
   * @public
   */
  readonly vectorSource: InputSignal<MapElement['vectorSource'] | undefined>;
  /**
   * Signal input for the `workerUrl` property.
   *
   * @public
   */
  readonly workerUrl: InputSignal<MapElement['workerUrl'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<MapElement['themeName'] | undefined>;
  /**
   * Signal input for the `width` property.
   *
   * @public
   */
  readonly width: InputSignal<MapElement['width'] | undefined>;
  /**
   * Signal input for the `height` property.
   *
   * @public
   */
  readonly height: InputSignal<MapElement['height'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<MapElement['disabled'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<MapElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<MapElement['lang'] | undefined>;
  /**
   * Output signal for the `mapReady` event.
   *
   * @public
   */
  readonly mapReady: OutputEmitterRef<ElementEventDetail<MapElement, 'mapReady'>>;
  /**
   * Output signal for the `mapMarkerSelected` event.
   *
   * @public
   */
  readonly mapMarkerSelected: OutputEmitterRef<ElementEventDetail<MapElement, 'mapMarkerSelected'>>;
  /**
   * Output signal for the `mapCameraChanged` event.
   *
   * @public
   */
  readonly mapCameraChanged: OutputEmitterRef<ElementEventDetail<MapElement, 'mapCameraChanged'>>;
  /**
   * Output signal for the `mapError` event.
   *
   * @public
   */
  readonly mapError: OutputEmitterRef<ElementEventDetail<MapElement, 'mapError'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<MapElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<MapElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<MapElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Fits the current valid markers/routes. With no data it restores latitude, longitude and zoom.
   *
   * @public
   */
  fitBounds(...args: Parameters<MapElement['fitBounds']>): ReturnType<MapElement['fitBounds']>;
  /**
   * Retries a failed renderer or resource load with the current source and style configuration.
   *
   * @public
   */
  retry(...args: Parameters<MapElement['retry']>): ReturnType<MapElement['retry']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `fitBounds()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * The other names it accepts are not public in the type declarations of `MapElement`.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends MapMethodNames>(method: TMethod, ...args: Parameters<MapComponentMethods[TMethod]>): ReturnType<MapComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof MapElement>(property: TProperty, value: MapElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<MapElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<MapComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<MapComponent, "mosaik-map", never, {
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "latitude": {
      "alias": "latitude";
      "required": false;
      "isSignal": true;
    };
    "longitude": {
      "alias": "longitude";
      "required": false;
      "isSignal": true;
    };
    "zoom": {
      "alias": "zoom";
      "required": false;
      "isSignal": true;
    };
    "mode": {
      "alias": "mode";
      "required": false;
      "isSignal": true;
    };
    "provider": {
      "alias": "provider";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "markers": {
      "alias": "markers";
      "required": false;
      "isSignal": true;
    };
    "routes": {
      "alias": "routes";
      "required": false;
      "isSignal": true;
    };
    "cluster": {
      "alias": "cluster";
      "required": false;
      "isSignal": true;
    };
    "showControls": {
      "alias": "showControls";
      "required": false;
      "isSignal": true;
    };
    "mapStyle": {
      "alias": "mapStyle";
      "required": false;
      "isSignal": true;
    };
    "vectorSource": {
      "alias": "vectorSource";
      "required": false;
      "isSignal": true;
    };
    "workerUrl": {
      "alias": "workerUrl";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "width": {
      "alias": "width";
      "required": false;
      "isSignal": true;
    };
    "height": {
      "alias": "height";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "mapReady": "mapReady";
    "mapMarkerSelected": "mapMarkerSelected";
    "mapCameraChanged": "mapCameraChanged";
    "mapError": "mapError";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on MapComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type MapMethodNames = 'fitBounds' | 'retry' | 'zoomBy' | 'selectMarker' | 'getEmbedUrl';
/**
 * Declares the methods interface for MapComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type MapComponentMethods = MethodMap<MapMethodNames>;
/**
 * @public
 */
export declare function provideMapComponent(config?: Partial<MapElement.Props>, intl?: Partial<MapElement['intl']> | Type<Partial<MapElement['intl']>>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-map.d.ts.map