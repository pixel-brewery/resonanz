import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { RatingElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/rating/RatingElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the RatingComponent.
 * Use this token to provide default properties for the RatingComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const RATING_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/inputs/rating/IRatingElementProps").IRatingElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class RatingComponent {
  /**
   * Signal input for the `hoverValue` property.
   *
   * @public
   */
  readonly hoverValue: InputSignal<RatingElement['hoverValue'] | undefined>;
  /**
   * Signal input for the `isHovering` property.
   *
   * @public
   */
  readonly isHovering: InputSignal<RatingElement['isHovering'] | undefined>;
  /**
   * Signal input for the `length` property.
   *
   * @public
   */
  readonly length: InputSignal<RatingElement['length'] | undefined>;
  /**
   * Signal input for the `precision` property.
   *
   * @public
   */
  readonly precision: InputSignal<RatingElement['precision'] | undefined>;
  /**
   * Signal input for the `readonly` property.
   *
   * @public
   */
  readonly readonly: InputSignal<RatingElement['readonly'] | undefined>;
  /**
   * Signal input for the `symbol` property.
   *
   * @public
   */
  readonly symbol: InputSignal<RatingElement['symbol'] | undefined>;
  /**
   * Signal input for the `activeSymbol` property.
   *
   * @public
   */
  readonly activeSymbol: InputSignal<RatingElement['activeSymbol'] | undefined>;
  /**
   * Signal input for the `symbolAccessor` property.
   *
   * @public
   */
  readonly symbolAccessor: InputSignal<RatingElement['symbolAccessor'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<RatingElement['themeName'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<RatingElement['disabled'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<RatingElement['value'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<RatingElement['label'] | undefined>;
  /**
   * Signal input for the `orientation` property.
   *
   * @public
   */
  readonly orientation: InputSignal<RatingElement['orientation'] | undefined>;
  /**
   * Signal input for the `size` property.
   *
   * @public
   */
  readonly size: InputSignal<RatingElement['size'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<RatingElement['variant'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<RatingElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<RatingElement['lang'] | undefined>;
  /**
   * Output signal for the `change` event.
   *
   * @public
   */
  readonly change: OutputEmitterRef<ElementEventDetail<RatingElement, 'change'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<RatingElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<RatingElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<RatingElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Calls `focus` on the `mosaik-rating` element.
   *
   * @public
   */
  focus(...args: Parameters<RatingElement['focus']>): ReturnType<RatingElement['focus']>;
  /**
   * Calls `blur` on the `mosaik-rating` element.
   *
   * @public
   */
  blur(...args: Parameters<RatingElement['blur']>): ReturnType<RatingElement['blur']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `focus()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends RatingMethodNames>(method: TMethod, ...args: Parameters<RatingComponentMethods[TMethod]>): ReturnType<RatingComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof RatingElement>(property: TProperty, value: RatingElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<RatingElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<RatingComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<RatingComponent, "mosaik-rating", never, {
    "hoverValue": {
      "alias": "hoverValue";
      "required": false;
      "isSignal": true;
    };
    "isHovering": {
      "alias": "isHovering";
      "required": false;
      "isSignal": true;
    };
    "length": {
      "alias": "length";
      "required": false;
      "isSignal": true;
    };
    "precision": {
      "alias": "precision";
      "required": false;
      "isSignal": true;
    };
    "readonly": {
      "alias": "readonly";
      "required": false;
      "isSignal": true;
    };
    "symbol": {
      "alias": "symbol";
      "required": false;
      "isSignal": true;
    };
    "activeSymbol": {
      "alias": "activeSymbol";
      "required": false;
      "isSignal": true;
    };
    "symbolAccessor": {
      "alias": "symbolAccessor";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "orientation": {
      "alias": "orientation";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "change": "change";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on RatingComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type RatingMethodNames = 'focus' | 'blur';
/**
 * Declares the methods interface for RatingComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type RatingComponentMethods = MethodMap<RatingMethodNames>;
/**
 * @public
 */
export declare function provideRatingComponent(config?: Partial<RatingElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-rating.d.ts.map