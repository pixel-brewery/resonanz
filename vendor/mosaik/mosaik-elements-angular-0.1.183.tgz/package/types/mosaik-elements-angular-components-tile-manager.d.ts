import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { TileManagerTileElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/tile-manager/TileManagerTileElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { TileManagerElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/tile-manager/TileManagerElement";
/**
 * @public
 *
 * Injection token for the default properties of the TileManagerTileComponent.
 * Use this token to provide default properties for the TileManagerTileComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const TILE_MANAGER_TILE_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/layouts/tile-manager/ITileManagerTileElementProps").ITileManagerTileElementProps>>;
/**
 * @public
 *
 * @slot  - Default slot for the tile's content.
 * @slot actions - Renders items after the default actions in the tile header.
 * @slot bottom-adorner - Renders the bottom resize handle of the tile.
 * @slot corner-adorner - Renders the corner resize handle of the tile.
 * @slot fullscreen-action - Renders the fullscreen action element of the tile header.
 * @slot maximize-action - Renders the maximize action element of the tile header.
 * @slot side-adorner - Renders the side resize handle of the tile.
 * @slot title - Renders the title of the tile header.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class TileManagerTileComponent {
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<TileManagerTileElement['intl'] | undefined>;
  /**
   * Signal input for the `colSpan` property.
   *
   * @public
   */
  readonly colSpan: InputSignal<TileManagerTileElement['colSpan'] | undefined>;
  /**
   * Signal input for the `rowSpan` property.
   *
   * @public
   */
  readonly rowSpan: InputSignal<TileManagerTileElement['rowSpan'] | undefined>;
  /**
   * Signal input for the `colStart` property.
   *
   * @public
   */
  readonly colStart: InputSignal<TileManagerTileElement['colStart'] | undefined>;
  /**
   * Signal input for the `rowStart` property.
   *
   * @public
   */
  readonly rowStart: InputSignal<TileManagerTileElement['rowStart'] | undefined>;
  /**
   * Signal input for the `position` property.
   *
   * @public
   */
  readonly position: InputSignal<TileManagerTileElement['position'] | undefined>;
  /**
   * Signal input for the `maximized` property.
   *
   * @public
   */
  readonly maximized: InputSignal<TileManagerTileElement['maximized'] | undefined>;
  /**
   * Signal input for the `disableResize` property.
   *
   * @public
   */
  readonly disableResize: InputSignal<TileManagerTileElement['disableResize'] | undefined>;
  /**
   * Signal input for the `disableFullscreen` property.
   *
   * @public
   */
  readonly disableFullscreen: InputSignal<TileManagerTileElement['disableFullscreen'] | undefined>;
  /**
   * Signal input for the `disableMaximize` property.
   *
   * @public
   */
  readonly disableMaximize: InputSignal<TileManagerTileElement['disableMaximize'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<TileManagerTileElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<TileManagerTileElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<TileManagerTileElement['lang'] | undefined>;
  /**
   * Output signal for the `tileFullscreen` event.
   *
   * @public
   */
  readonly tileFullscreen: OutputEmitterRef<ElementEventDetail<TileManagerTileElement, 'tileFullscreen'>>;
  /**
   * Output signal for the `tileMaximize` event.
   *
   * @public
   */
  readonly tileMaximize: OutputEmitterRef<ElementEventDetail<TileManagerTileElement, 'tileMaximize'>>;
  /**
   * Output signal for the `tileDragStart` event.
   *
   * @public
   */
  readonly tileDragStart: OutputEmitterRef<ElementEventDetail<TileManagerTileElement, 'tileDragStart'>>;
  /**
   * Output signal for the `tileDragEnd` event.
   *
   * @public
   */
  readonly tileDragEnd: OutputEmitterRef<ElementEventDetail<TileManagerTileElement, 'tileDragEnd'>>;
  /**
   * Output signal for the `tileDragCancel` event.
   *
   * @public
   */
  readonly tileDragCancel: OutputEmitterRef<ElementEventDetail<TileManagerTileElement, 'tileDragCancel'>>;
  /**
   * Output signal for the `tileResizeStart` event.
   *
   * @public
   */
  readonly tileResizeStart: OutputEmitterRef<ElementEventDetail<TileManagerTileElement, 'tileResizeStart'>>;
  /**
   * Output signal for the `tileResizeEnd` event.
   *
   * @public
   */
  readonly tileResizeEnd: OutputEmitterRef<ElementEventDetail<TileManagerTileElement, 'tileResizeEnd'>>;
  /**
   * Output signal for the `tileResizeCancel` event.
   *
   * @public
   */
  readonly tileResizeCancel: OutputEmitterRef<ElementEventDetail<TileManagerTileElement, 'tileResizeCancel'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<TileManagerTileElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<TileManagerTileElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<TileManagerTileElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets the drag state (visual appearance while dragging).
   *
   * @public
   * @param args - The arguments of `setDragState`:
   * - `state` - Whether dragging is active.
   */
  setDragState(...args: Parameters<TileManagerTileElement['setDragState']>): ReturnType<TileManagerTileElement['setDragState']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `setDragState()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends TileManagerTileMethodNames>(method: TMethod, ...args: Parameters<TileManagerTileComponentMethods[TMethod]>): ReturnType<TileManagerTileComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof TileManagerTileElement>(property: TProperty, value: TileManagerTileElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<TileManagerTileElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<TileManagerTileComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<TileManagerTileComponent, "mosaik-tile-manager-tile", never, {
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "colSpan": {
      "alias": "colSpan";
      "required": false;
      "isSignal": true;
    };
    "rowSpan": {
      "alias": "rowSpan";
      "required": false;
      "isSignal": true;
    };
    "colStart": {
      "alias": "colStart";
      "required": false;
      "isSignal": true;
    };
    "rowStart": {
      "alias": "rowStart";
      "required": false;
      "isSignal": true;
    };
    "position": {
      "alias": "position";
      "required": false;
      "isSignal": true;
    };
    "maximized": {
      "alias": "maximized";
      "required": false;
      "isSignal": true;
    };
    "disableResize": {
      "alias": "disableResize";
      "required": false;
      "isSignal": true;
    };
    "disableFullscreen": {
      "alias": "disableFullscreen";
      "required": false;
      "isSignal": true;
    };
    "disableMaximize": {
      "alias": "disableMaximize";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "tileFullscreen": "tileFullscreen";
    "tileMaximize": "tileMaximize";
    "tileDragStart": "tileDragStart";
    "tileDragEnd": "tileDragEnd";
    "tileDragCancel": "tileDragCancel";
    "tileResizeStart": "tileResizeStart";
    "tileResizeEnd": "tileResizeEnd";
    "tileResizeCancel": "tileResizeCancel";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on TileManagerTileComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TileManagerTileMethodNames = 'setDragState';
/**
 * Declares the methods interface for TileManagerTileComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TileManagerTileComponentMethods = MethodMap<TileManagerTileMethodNames>;
/**
 * @public
 */
export declare function provideTileManagerTileComponent(config?: Partial<TileManagerTileElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the TileManagerComponent.
 * Use this token to provide default properties for the TileManagerComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const TILE_MANAGER_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/layouts/tile-manager/ITileManagerElementProps").ITileManagerElementProps>>;
/**
 * @public
 *
 * @slot  - Default slot for tile elements.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class TileManagerComponent {
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<TileManagerElement['intl'] | undefined>;
  /**
   * Signal input for the `resizeMode` property.
   *
   * @public
   */
  readonly resizeMode: InputSignal<TileManagerElement['resizeMode'] | undefined>;
  /**
   * Signal input for the `dragMode` property.
   *
   * @public
   */
  readonly dragMode: InputSignal<TileManagerElement['dragMode'] | undefined>;
  /**
   * Signal input for the `columnCount` property.
   *
   * @public
   */
  readonly columnCount: InputSignal<TileManagerElement['columnCount'] | undefined>;
  /**
   * Signal input for the `minColumnWidth` property.
   *
   * @public
   */
  readonly minColumnWidth: InputSignal<TileManagerElement['minColumnWidth'] | undefined>;
  /**
   * Signal input for the `minRowHeight` property.
   *
   * @public
   */
  readonly minRowHeight: InputSignal<TileManagerElement['minRowHeight'] | undefined>;
  /**
   * Signal input for the `gap` property.
   *
   * @public
   */
  readonly gap: InputSignal<TileManagerElement['gap'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<TileManagerElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<TileManagerElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<TileManagerElement['lang'] | undefined>;
  /**
   * Output signal for the `layoutChanged` event.
   *
   * @public
   */
  readonly layoutChanged: OutputEmitterRef<ElementEventDetail<TileManagerElement, 'layoutChanged'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<TileManagerElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<TileManagerElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<TileManagerElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Saves the current layout state.
   *
   * @public
   * @returns An array of serialized tile states.
   */
  saveLayout(...args: Parameters<TileManagerElement['saveLayout']>): ReturnType<TileManagerElement['saveLayout']>;
  /**
   * Saves the current layout state as a JSON string.
   *
   * @public
   * @returns A JSON string representing the layout.
   */
  saveLayoutAsJSON(...args: Parameters<TileManagerElement['saveLayoutAsJSON']>): ReturnType<TileManagerElement['saveLayoutAsJSON']>;
  /**
   * Loads a previously saved layout.
   *
   * @public
   * @param args - The arguments of `loadLayout`:
   * - `layout` - The serialized layout to load.
   */
  loadLayout(...args: Parameters<TileManagerElement['loadLayout']>): ReturnType<TileManagerElement['loadLayout']>;
  /**
   * Loads a layout from a JSON string.
   *
   * @public
   * @param args - The arguments of `loadLayoutFromJSON`:
   * - `json` - The JSON string representing the layout.
   */
  loadLayoutFromJSON(...args: Parameters<TileManagerElement['loadLayoutFromJSON']>): ReturnType<TileManagerElement['loadLayoutFromJSON']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `saveLayout()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends TileManagerMethodNames>(method: TMethod, ...args: Parameters<TileManagerComponentMethods[TMethod]>): ReturnType<TileManagerComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof TileManagerElement>(property: TProperty, value: TileManagerElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<TileManagerElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<TileManagerComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<TileManagerComponent, "mosaik-tile-manager", never, {
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "resizeMode": {
      "alias": "resizeMode";
      "required": false;
      "isSignal": true;
    };
    "dragMode": {
      "alias": "dragMode";
      "required": false;
      "isSignal": true;
    };
    "columnCount": {
      "alias": "columnCount";
      "required": false;
      "isSignal": true;
    };
    "minColumnWidth": {
      "alias": "minColumnWidth";
      "required": false;
      "isSignal": true;
    };
    "minRowHeight": {
      "alias": "minRowHeight";
      "required": false;
      "isSignal": true;
    };
    "gap": {
      "alias": "gap";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "layoutChanged": "layoutChanged";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on TileManagerComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TileManagerMethodNames = 'saveLayout' | 'saveLayoutAsJSON' | 'loadLayout' | 'loadLayoutFromJSON';
/**
 * Declares the methods interface for TileManagerComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TileManagerComponentMethods = MethodMap<TileManagerMethodNames>;
/**
 * @public
 */
export declare function provideTileManagerComponent(config?: Partial<TileManagerElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-tile-manager.d.ts.map