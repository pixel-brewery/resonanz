import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { IllustrationElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/illustrations/illustration/IllustrationElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the IllustrationComponent.
 * Use this token to provide default properties for the IllustrationComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const ILLUSTRATION_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").IIllustrationElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot for the composition: engines and Mosaik elements.
 * @slot background - A custom background layer, such as a `mosaik-particles` field; it is drawn behind the content.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class IllustrationComponent {
  /**
   * Signal input for the `ratio` property.
   *
   * @public
   */
  readonly ratio: InputSignal<IllustrationElement['ratio'] | undefined>;
  /**
   * Signal input for the `background` property.
   *
   * @public
   */
  readonly background: InputSignal<IllustrationElement['background'] | undefined>;
  /**
   * Signal input for the `frameless` property.
   *
   * @public
   */
  readonly frameless: InputSignal<IllustrationElement['frameless'] | undefined>;
  /**
   * Signal input for the `isometric` property.
   *
   * @public
   */
  readonly isometric: InputSignal<IllustrationElement['isometric'] | undefined>;
  /**
   * Signal input for the `motion` property.
   *
   * @public
   */
  readonly motion: InputSignal<IllustrationElement['motion'] | undefined>;
  /**
   * Signal input for the `paused` property.
   *
   * @public
   */
  readonly paused: InputSignal<IllustrationElement['paused'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<IllustrationElement['label'] | undefined>;
  /**
   * Signal input for the `description` property.
   *
   * @public
   */
  readonly description: InputSignal<IllustrationElement['description'] | undefined>;
  /**
   * Signal input for the `interactive` property.
   *
   * @public
   */
  readonly interactive: InputSignal<IllustrationElement['interactive'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<IllustrationElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<IllustrationElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<IllustrationElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<IllustrationElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<IllustrationElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<IllustrationElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: IllustrationElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: IllustrationElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Called when the slot content changes.
   *
   * @public
   * @param args - The arguments of `onSlotChanges`:
   * - `slotName` - The name of the slot that changed.
   */
  onSlotChanges(...args: Parameters<IllustrationElement['onSlotChanges']>): ReturnType<IllustrationElement['onSlotChanges']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<IllustrationElement['assignToSlot']>): ReturnType<IllustrationElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<IllustrationElement['getSlotContent']>): ReturnType<IllustrationElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<IllustrationElement['hasSlotContent']>): ReturnType<IllustrationElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<IllustrationElement['hasSlot']>): ReturnType<IllustrationElement['hasSlot']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `onSlotChanges()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends IllustrationMethodNames>(method: TMethod, ...args: Parameters<IllustrationComponentMethods[TMethod]>): ReturnType<IllustrationComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof IllustrationElement>(property: TProperty, value: IllustrationElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<IllustrationElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<IllustrationComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<IllustrationComponent, "mosaik-illustration", never, {
    "ratio": {
      "alias": "ratio";
      "required": false;
      "isSignal": true;
    };
    "background": {
      "alias": "background";
      "required": false;
      "isSignal": true;
    };
    "frameless": {
      "alias": "frameless";
      "required": false;
      "isSignal": true;
    };
    "isometric": {
      "alias": "isometric";
      "required": false;
      "isSignal": true;
    };
    "motion": {
      "alias": "motion";
      "required": false;
      "isSignal": true;
    };
    "paused": {
      "alias": "paused";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "description": {
      "alias": "description";
      "required": false;
      "isSignal": true;
    };
    "interactive": {
      "alias": "interactive";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on IllustrationComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type IllustrationMethodNames = 'onSlotChanges' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot';
/**
 * Declares the methods interface for IllustrationComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type IllustrationComponentMethods = MethodMap<IllustrationMethodNames>;
/**
 * @public
 */
export declare function provideIllustrationComponent(config?: Partial<IllustrationElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-illustration.d.ts.map