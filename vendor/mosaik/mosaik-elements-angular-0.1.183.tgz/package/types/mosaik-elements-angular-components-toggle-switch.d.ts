import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { ControlValueAccessor } from "@angular/forms";
import { ToggleSwitchElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/toggle-switch/ToggleSwitchElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import * as i1 from "@pixel-brewery/mosaik-elements-angular/runtime";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the ToggleSwitchComponent.
 * Use this token to provide default properties for the ToggleSwitchComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const TOGGLE_SWITCH_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/inputs/toggle-switch/IToggleSwitchElementProps").IToggleSwitchElementProps>>;
/**
 * @public
 *
 * @slot checkmark - Custom checkmark/switch indicator content.
 * @slot label - Custom label content.
 * @slot prefix - Content placed before the switch control.
 * @slot suffix - Content placed after the switch control.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ToggleSwitchComponent implements ControlValueAccessor {
  /**
   * Signal input for the `labelPosition` property.
   *
   * @public
   */
  readonly labelPosition: InputSignal<ToggleSwitchElement['labelPosition'] | undefined>;
  /**
   * Signal input for the `showStateLabels` property.
   *
   * @public
   */
  readonly showStateLabels: InputSignal<ToggleSwitchElement['showStateLabels'] | undefined>;
  /**
   * Signal input for the `required` property.
   *
   * @public
   */
  readonly required: InputSignal<ToggleSwitchElement['required'] | undefined>;
  /**
   * Signal input for the `name` property.
   *
   * @public
   */
  readonly name: InputSignal<ToggleSwitchElement['name'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ToggleSwitchElement['themeName'] | undefined>;
  /**
   * Signal input for the `invalid` property.
   *
   * @public
   */
  readonly invalid: InputSignal<ToggleSwitchElement['invalid'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<ToggleSwitchElement['value'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<ToggleSwitchElement['variant'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<ToggleSwitchElement['appearance'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<ToggleSwitchElement['disabled'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<ToggleSwitchElement['label'] | undefined>;
  /**
   * Signal input for the `formatter` property.
   *
   * @public
   */
  readonly formatter: InputSignal<ToggleSwitchElement['formatter'] | undefined>;
  /**
   * Signal input for the `isChecked` property.
   *
   * @public
   */
  readonly isChecked: InputSignal<ToggleSwitchElement['isChecked'] | undefined>;
  /**
   * Signal input for the `isThreeState` property.
   *
   * @public
   */
  readonly isThreeState: InputSignal<ToggleSwitchElement['isThreeState'] | undefined>;
  /**
   * Signal input for the `isFocused` property.
   *
   * @public
   */
  readonly isFocused: InputSignal<ToggleSwitchElement['isFocused'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ToggleSwitchElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ToggleSwitchElement['lang'] | undefined>;
  /**
   * Output signal for the `checked` event.
   *
   * @public
   */
  readonly checked: OutputEmitterRef<ElementEventDetail<ToggleSwitchElement, 'checked'>>;
  /**
   * Output signal for the `unchecked` event.
   *
   * @public
   */
  readonly unchecked: OutputEmitterRef<ElementEventDetail<ToggleSwitchElement, 'unchecked'>>;
  /**
   * Output signal for the `indeterminate` event.
   *
   * @public
   */
  readonly indeterminate: OutputEmitterRef<ElementEventDetail<ToggleSwitchElement, 'indeterminate'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ToggleSwitchElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ToggleSwitchElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ToggleSwitchElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  private readonly _accessor;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Applies a value supplied by Angular forms to the native control.
   *
   * @public
   */
  writeValue(obj: unknown): void;
  /**
   * Registers the callback notified when the native control value changes.
   *
   * @public
   */
  registerOnChange(fn: unknown): void;
  /**
   * Registers the callback notified when the native control is touched.
   *
   * @public
   */
  registerOnTouched(fn: unknown): void;
  /**
   * Applies the disabled state supplied by Angular forms.
   *
   * @public
   */
  setDisabledState?(isDisabled: boolean): void;
  /**
   * Checks the validity of the element and returns `true` if it is valid; otherwise, `false`.
   *
   * @public
   */
  checkValidity(...args: Parameters<ToggleSwitchElement['checkValidity']>): ReturnType<ToggleSwitchElement['checkValidity']>;
  /**
   * Resets the element to its initial state.
   *
   * @public
   */
  reset(...args: Parameters<ToggleSwitchElement['reset']>): ReturnType<ToggleSwitchElement['reset']>;
  /**
   * Checks the element.
   * If the element is disabled, nothing happens.
   *
   * @public
   */
  check(...args: Parameters<ToggleSwitchElement['check']>): ReturnType<ToggleSwitchElement['check']>;
  /**
   * Unchecks the element.
   * If the element is disabled, nothing happens.
   *
   * @public
   */
  uncheck(...args: Parameters<ToggleSwitchElement['uncheck']>): ReturnType<ToggleSwitchElement['uncheck']>;
  /**
   * Toggles the element between checked and unchecked states.
   *
   * @public
   */
  toggle(...args: Parameters<ToggleSwitchElement['toggle']>): ReturnType<ToggleSwitchElement['toggle']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `checkValidity()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends ToggleSwitchMethodNames>(method: TMethod, ...args: Parameters<ToggleSwitchComponentMethods[TMethod]>): ReturnType<ToggleSwitchComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ToggleSwitchElement>(property: TProperty, value: ToggleSwitchElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ToggleSwitchElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ToggleSwitchComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ToggleSwitchComponent, "mosaik-toggle-switch", never, {
    "labelPosition": {
      "alias": "labelPosition";
      "required": false;
      "isSignal": true;
    };
    "showStateLabels": {
      "alias": "showStateLabels";
      "required": false;
      "isSignal": true;
    };
    "required": {
      "alias": "required";
      "required": false;
      "isSignal": true;
    };
    "name": {
      "alias": "name";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "invalid": {
      "alias": "invalid";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "formatter": {
      "alias": "formatter";
      "required": false;
      "isSignal": true;
    };
    "isChecked": {
      "alias": "isChecked";
      "required": false;
      "isSignal": true;
    };
    "isThreeState": {
      "alias": "isThreeState";
      "required": false;
      "isSignal": true;
    };
    "isFocused": {
      "alias": "isFocused";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "checked": "checked";
    "unchecked": "unchecked";
    "indeterminate": "indeterminate";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, [{
    directive: typeof i1.FormStatusHostDirective;
    inputs: {};
    outputs: {};
  }, {
    directive: typeof i1.FormFieldStatusHostDirective;
    inputs: {};
    outputs: {};
  }]>;
}
/**
 * Declares the methods available on ToggleSwitchComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ToggleSwitchMethodNames = 'checkValidity' | 'reset' | 'check' | 'uncheck' | 'toggle';
/**
 * Declares the methods interface for ToggleSwitchComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ToggleSwitchComponentMethods = MethodMap<ToggleSwitchMethodNames>;
/**
 * @public
 */
export declare function provideToggleSwitchComponent(config?: Partial<ToggleSwitchElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-toggle-switch.d.ts.map