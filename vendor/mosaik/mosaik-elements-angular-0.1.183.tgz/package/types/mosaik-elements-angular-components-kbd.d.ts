import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { KbdShortcutElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/kbd/KbdShortcutElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { KbdElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/kbd/KbdElement";
/**
 * @public
 *
 * Injection token for the default properties of the KbdShortcutComponent.
 * Use this token to provide default properties for the KbdShortcutComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const KBD_SHORTCUT_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/primitives/kbd/IKbdShortcutElementProps").IKbdShortcutElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class KbdShortcutComponent {
  /**
   * Signal input for the `gesture` property.
   *
   * @public
   */
  readonly gesture: InputSignal<KbdShortcutElement['gesture'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<KbdShortcutElement['disabled'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<KbdShortcutElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<KbdShortcutElement['lang'] | undefined>;
  /**
   * Output signal for the `change` event.
   *
   * @public
   */
  readonly change: OutputEmitterRef<ElementEventDetail<KbdShortcutElement, 'change'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<KbdShortcutElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<KbdShortcutElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<KbdShortcutElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof KbdShortcutElement>(property: TProperty, value: KbdShortcutElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<KbdShortcutElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<KbdShortcutComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<KbdShortcutComponent, "mosaik-kbd-shortcut", never, {
    "gesture": {
      "alias": "gesture";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "change": "change";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on KbdShortcutComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type KbdShortcutMethodNames = never;
/**
 * Declares the methods interface for KbdShortcutComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type KbdShortcutComponentMethods = MethodMap<KbdShortcutMethodNames>;
/**
 * @public
 */
export declare function provideKbdShortcutComponent(config?: Partial<KbdShortcutElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the KbdComponent.
 * Use this token to provide default properties for the KbdComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const KBD_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/primitives/kbd/IKbdElementProps").IKbdElementProps>>;
/**
 * @public
 *
 * @slot  - The key text, rendered when `value` is empty.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class KbdComponent {
  /**
   * Signal input for the `isCompact` property.
   *
   * @public
   */
  readonly isCompact: InputSignal<KbdElement['isCompact'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<KbdElement['themeName'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<KbdElement['value'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<KbdElement['variant'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<KbdElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<KbdElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<KbdElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<KbdElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<KbdElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof KbdElement>(property: TProperty, value: KbdElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<KbdElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<KbdComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<KbdComponent, "mosaik-kbd", never, {
    "isCompact": {
      "alias": "isCompact";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on KbdComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type KbdMethodNames = never;
/**
 * Declares the methods interface for KbdComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type KbdComponentMethods = MethodMap<KbdMethodNames>;
/**
 * @public
 */
export declare function provideKbdComponent(config?: Partial<KbdElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-kbd.d.ts.map