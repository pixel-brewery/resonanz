import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { SheetContentElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/overlays/sheet/SheetContentElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { SheetFooterElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/overlays/sheet/SheetFooterElement";
import { SheetHeaderSubTextElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/overlays/sheet/SheetHeaderSubTextElement";
import { SheetHeaderTextElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/overlays/sheet/SheetHeaderTextElement";
import { SheetHeaderElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/overlays/sheet/SheetHeaderElement";
import { SheetElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/overlays/sheet/SheetElement";
/**
 * @public
 *
 * Injection token for the default properties of the SheetContentComponent.
 * Use this token to provide default properties for the SheetContentComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const SHEET_CONTENT_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/overlays/sheet/ISheetContentElementProps").ISheetContentElementProps>>;
/**
 * @public
 *
 * @slot  - Default slot for content children.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class SheetContentComponent {
  /**
   * Signal input for the `text` property.
   *
   * @public
   */
  readonly text: InputSignal<SheetContentElement['text'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<SheetContentElement['themeName'] | undefined>;
  /**
   * Signal input for the `formatter` property.
   *
   * @public
   */
  readonly formatter: InputSignal<SheetContentElement['formatter'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<SheetContentElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<SheetContentElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<SheetContentElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<SheetContentElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<SheetContentElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: SheetContentElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: SheetContentElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<SheetContentElement['assignToSlot']>): ReturnType<SheetContentElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<SheetContentElement['getSlotContent']>): ReturnType<SheetContentElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<SheetContentElement['hasSlotContent']>): ReturnType<SheetContentElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<SheetContentElement['hasSlot']>): ReturnType<SheetContentElement['hasSlot']>;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<SheetContentElement['onSlotChanges']>): ReturnType<SheetContentElement['onSlotChanges']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `assignToSlot()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends SheetContentMethodNames>(method: TMethod, ...args: Parameters<SheetContentComponentMethods[TMethod]>): ReturnType<SheetContentComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof SheetContentElement>(property: TProperty, value: SheetContentElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<SheetContentElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SheetContentComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SheetContentComponent, "mosaik-sheet-content", never, {
    "text": {
      "alias": "text";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "formatter": {
      "alias": "formatter";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on SheetContentComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SheetContentMethodNames = 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges';
/**
 * Declares the methods interface for SheetContentComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SheetContentComponentMethods = MethodMap<SheetContentMethodNames>;
/**
 * @public
 */
export declare function provideSheetContentComponent(config?: Partial<SheetContentElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the SheetFooterComponent.
 * Use this token to provide default properties for the SheetFooterComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const SHEET_FOOTER_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/overlays/sheet/ISheetFooterElementProps").ISheetFooterElementProps>>;
/**
 * @public
 *
 * @slot  - The default content slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class SheetFooterComponent {
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<SheetFooterElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<SheetFooterElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<SheetFooterElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<SheetFooterElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<SheetFooterElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<SheetFooterElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: SheetFooterElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: SheetFooterElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<SheetFooterElement['assignToSlot']>): ReturnType<SheetFooterElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<SheetFooterElement['getSlotContent']>): ReturnType<SheetFooterElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<SheetFooterElement['hasSlotContent']>): ReturnType<SheetFooterElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<SheetFooterElement['hasSlot']>): ReturnType<SheetFooterElement['hasSlot']>;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<SheetFooterElement['onSlotChanges']>): ReturnType<SheetFooterElement['onSlotChanges']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `assignToSlot()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends SheetFooterMethodNames>(method: TMethod, ...args: Parameters<SheetFooterComponentMethods[TMethod]>): ReturnType<SheetFooterComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof SheetFooterElement>(property: TProperty, value: SheetFooterElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<SheetFooterElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SheetFooterComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SheetFooterComponent, "mosaik-sheet-footer", never, {
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on SheetFooterComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SheetFooterMethodNames = 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges';
/**
 * Declares the methods interface for SheetFooterComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SheetFooterComponentMethods = MethodMap<SheetFooterMethodNames>;
/**
 * @public
 */
export declare function provideSheetFooterComponent(config?: Partial<SheetFooterElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the SheetHeaderSubTextComponent.
 * Use this token to provide default properties for the SheetHeaderSubTextComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const SHEET_HEADER_SUB_TEXT_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/overlays/sheet/ISheetHeaderSubTextElementProps").ISheetHeaderSubTextElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class SheetHeaderSubTextComponent {
  /**
   * Signal input for the `text` property.
   *
   * @public
   */
  readonly text: InputSignal<SheetHeaderSubTextElement['text'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<SheetHeaderSubTextElement['themeName'] | undefined>;
  /**
   * Signal input for the `formatter` property.
   *
   * @public
   */
  readonly formatter: InputSignal<SheetHeaderSubTextElement['formatter'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<SheetHeaderSubTextElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<SheetHeaderSubTextElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<SheetHeaderSubTextElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<SheetHeaderSubTextElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<SheetHeaderSubTextElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof SheetHeaderSubTextElement>(property: TProperty, value: SheetHeaderSubTextElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<SheetHeaderSubTextElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SheetHeaderSubTextComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SheetHeaderSubTextComponent, "mosaik-sheet-header-sub-text", never, {
    "text": {
      "alias": "text";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "formatter": {
      "alias": "formatter";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on SheetHeaderSubTextComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SheetHeaderSubTextMethodNames = never;
/**
 * Declares the methods interface for SheetHeaderSubTextComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SheetHeaderSubTextComponentMethods = MethodMap<SheetHeaderSubTextMethodNames>;
/**
 * @public
 */
export declare function provideSheetHeaderSubTextComponent(config?: Partial<SheetHeaderSubTextElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the SheetHeaderTextComponent.
 * Use this token to provide default properties for the SheetHeaderTextComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const SHEET_HEADER_TEXT_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/overlays/sheet/ISheetHeaderTextElementProps").ISheetHeaderTextElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class SheetHeaderTextComponent {
  /**
   * Signal input for the `text` property.
   *
   * @public
   */
  readonly text: InputSignal<SheetHeaderTextElement['text'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<SheetHeaderTextElement['themeName'] | undefined>;
  /**
   * Signal input for the `formatter` property.
   *
   * @public
   */
  readonly formatter: InputSignal<SheetHeaderTextElement['formatter'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<SheetHeaderTextElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<SheetHeaderTextElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<SheetHeaderTextElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<SheetHeaderTextElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<SheetHeaderTextElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof SheetHeaderTextElement>(property: TProperty, value: SheetHeaderTextElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<SheetHeaderTextElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SheetHeaderTextComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SheetHeaderTextComponent, "mosaik-sheet-header-text", never, {
    "text": {
      "alias": "text";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "formatter": {
      "alias": "formatter";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on SheetHeaderTextComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SheetHeaderTextMethodNames = never;
/**
 * Declares the methods interface for SheetHeaderTextComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SheetHeaderTextComponentMethods = MethodMap<SheetHeaderTextMethodNames>;
/**
 * @public
 */
export declare function provideSheetHeaderTextComponent(config?: Partial<SheetHeaderTextElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the SheetHeaderComponent.
 * Use this token to provide default properties for the SheetHeaderComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const SHEET_HEADER_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/overlays/sheet/ISheetHeaderElementProps").ISheetHeaderElementProps>>;
/**
 * @public
 *
 * @slot header - The header slot.
 * @slot prefix - The prefix slot.
 * @slot subHeader - The subHeader slot.
 * @slot suffix - The suffix slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class SheetHeaderComponent {
  /**
   * Signal input for the `text` property.
   *
   * @public
   */
  readonly text: InputSignal<SheetHeaderElement['text'] | undefined>;
  /**
   * Signal input for the `subText` property.
   *
   * @public
   */
  readonly subText: InputSignal<SheetHeaderElement['subText'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<SheetHeaderElement['themeName'] | undefined>;
  /**
   * Signal input for the `formatter` property.
   *
   * @public
   */
  readonly formatter: InputSignal<SheetHeaderElement['formatter'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<SheetHeaderElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<SheetHeaderElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<SheetHeaderElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<SheetHeaderElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<SheetHeaderElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: SheetHeaderElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: SheetHeaderElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * A method that will be called when the element template is applied.
   * In this method are the element children available.
   *
   * @public
   */
  onApplyTemplate(...args: Parameters<SheetHeaderElement['onApplyTemplate']>): ReturnType<SheetHeaderElement['onApplyTemplate']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<SheetHeaderElement['assignToSlot']>): ReturnType<SheetHeaderElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<SheetHeaderElement['getSlotContent']>): ReturnType<SheetHeaderElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<SheetHeaderElement['hasSlotContent']>): ReturnType<SheetHeaderElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<SheetHeaderElement['hasSlot']>): ReturnType<SheetHeaderElement['hasSlot']>;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<SheetHeaderElement['onSlotChanges']>): ReturnType<SheetHeaderElement['onSlotChanges']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `onApplyTemplate()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends SheetHeaderMethodNames>(method: TMethod, ...args: Parameters<SheetHeaderComponentMethods[TMethod]>): ReturnType<SheetHeaderComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof SheetHeaderElement>(property: TProperty, value: SheetHeaderElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<SheetHeaderElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SheetHeaderComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SheetHeaderComponent, "mosaik-sheet-header", never, {
    "text": {
      "alias": "text";
      "required": false;
      "isSignal": true;
    };
    "subText": {
      "alias": "subText";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "formatter": {
      "alias": "formatter";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on SheetHeaderComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SheetHeaderMethodNames = 'onApplyTemplate' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges';
/**
 * Declares the methods interface for SheetHeaderComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SheetHeaderComponentMethods = MethodMap<SheetHeaderMethodNames>;
/**
 * @public
 */
export declare function provideSheetHeaderComponent(config?: Partial<SheetHeaderElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the SheetComponent.
 * Use this token to provide default properties for the SheetComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const SHEET_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/overlays/sheet/ISheetElementProps").ISheetElementProps>>;
/**
 * @public
 *
 * @slot content - The content slot for `SheetContentElement`.
 * @slot footer - The footer slot for `SheetFooterElement`.
 * @slot header - The header slot for `SheetHeaderElement`.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class SheetComponent {
  /**
   * Signal input for the `width` property.
   *
   * @public
   */
  readonly width: InputSignal<SheetElement['width'] | undefined>;
  /**
   * Signal input for the `height` property.
   *
   * @public
   */
  readonly height: InputSignal<SheetElement['height'] | undefined>;
  /**
   * Signal input for the `position` property.
   *
   * @public
   */
  readonly position: InputSignal<SheetElement['position'] | undefined>;
  /**
   * Signal input for the `snaps` property.
   *
   * @public
   */
  readonly snaps: InputSignal<SheetElement['snaps'] | undefined>;
  /**
   * Signal input for the `activeSnapIndex` property.
   *
   * @public
   */
  readonly activeSnapIndex: InputSignal<SheetElement['activeSnapIndex'] | undefined>;
  /**
   * Signal input for the `closeThreshold` property.
   *
   * @public
   */
  readonly closeThreshold: InputSignal<SheetElement['closeThreshold'] | undefined>;
  /**
   * Signal input for the `elastic` property.
   *
   * @public
   */
  readonly elastic: InputSignal<SheetElement['elastic'] | undefined>;
  /**
   * Signal input for the `inertia` property.
   *
   * @public
   */
  readonly inertia: InputSignal<SheetElement['inertia'] | undefined>;
  /**
   * Signal input for the `dragMode` property.
   *
   * @public
   */
  readonly dragMode: InputSignal<SheetElement['dragMode'] | undefined>;
  /**
   * Signal input for the `hasHandle` property.
   *
   * @public
   */
  readonly hasHandle: InputSignal<SheetElement['hasHandle'] | undefined>;
  /**
   * Signal input for the `hasSnapIndicator` property.
   *
   * @public
   */
  readonly hasSnapIndicator: InputSignal<SheetElement['hasSnapIndicator'] | undefined>;
  /**
   * Signal input for the `isModal` property.
   *
   * @public
   */
  readonly isModal: InputSignal<SheetElement['isModal'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<SheetElement['themeName'] | undefined>;
  /**
   * Signal input for the `isOpen` property.
   *
   * @public
   */
  readonly isOpen: InputSignal<SheetElement['isOpen'] | undefined>;
  /**
   * Signal input for the `hasBackdrop` property.
   *
   * @public
   */
  readonly hasBackdrop: InputSignal<SheetElement['hasBackdrop'] | undefined>;
  /**
   * Signal input for the `pressEscapeToClose` property.
   *
   * @public
   */
  readonly pressEscapeToClose: InputSignal<SheetElement['pressEscapeToClose'] | undefined>;
  /**
   * Signal input for the `clickOutsideToClose` property.
   *
   * @public
   */
  readonly clickOutsideToClose: InputSignal<SheetElement['clickOutsideToClose'] | undefined>;
  /**
   * Signal input for the `attention` property.
   *
   * @public
   */
  readonly attention: InputSignal<SheetElement['attention'] | undefined>;
  /**
   * Signal input for the `closeable` property.
   *
   * @public
   */
  readonly closeable: InputSignal<SheetElement['closeable'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<SheetElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<SheetElement['lang'] | undefined>;
  /**
   * Output signal for the `activeSnapChanged` event.
   *
   * @public
   */
  readonly activeSnapChanged: OutputEmitterRef<ElementEventDetail<SheetElement, 'activeSnapChanged'>>;
  /**
   * Output signal for the `dragStart` event.
   *
   * @public
   */
  readonly dragStart: OutputEmitterRef<ElementEventDetail<SheetElement, 'dragStart'>>;
  /**
   * Output signal for the `dragging` event.
   *
   * @public
   */
  readonly dragging: OutputEmitterRef<ElementEventDetail<SheetElement, 'dragging'>>;
  /**
   * Output signal for the `dragEnd` event.
   *
   * @public
   */
  readonly dragEnd: OutputEmitterRef<ElementEventDetail<SheetElement, 'dragEnd'>>;
  /**
   * Output signal for the `opened` event.
   *
   * @public
   */
  readonly opened: OutputEmitterRef<ElementEventDetail<SheetElement, 'opened'>>;
  /**
   * Output signal for the `closed` event.
   *
   * @public
   */
  readonly closed: OutputEmitterRef<ElementEventDetail<SheetElement, 'closed'>>;
  /**
   * Output signal for the `closeAttempted` event.
   *
   * @public
   */
  readonly closeAttempted: OutputEmitterRef<ElementEventDetail<SheetElement, 'closeAttempted'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<SheetElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<SheetElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<SheetElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: SheetElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: SheetElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Opens the sheet at its active snap.
   *
   * @public
   * @returns A promise that resolves after the sheet has opened.
   */
  open(...args: Parameters<SheetElement['open']>): ReturnType<SheetElement['open']>;
  /**
   * Closes the sheet through the normal overlay lifecycle.
   *
   * @public
   * @returns A promise resolving to whether the sheet was closed.
   */
  close(...args: Parameters<SheetElement['close']>): ReturnType<SheetElement['close']>;
  /**
   * Moves the open sheet to a configured snap.
   * Invalid indices are clamped to the resolved snap range.
   *
   * @public
   * @param args - The arguments of `snapTo`:
   * - `index` - The target index in the resolved, ascending snap list.
   */
  snapTo(...args: Parameters<SheetElement['snapTo']>): ReturnType<SheetElement['snapTo']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<SheetElement['assignToSlot']>): ReturnType<SheetElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<SheetElement['getSlotContent']>): ReturnType<SheetElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<SheetElement['hasSlotContent']>): ReturnType<SheetElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<SheetElement['hasSlot']>): ReturnType<SheetElement['hasSlot']>;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<SheetElement['onSlotChanges']>): ReturnType<SheetElement['onSlotChanges']>;
  /**
   * Requests visual attention for this overlay.
   *
   * @public
   * @param args - The arguments of `requestAttention`:
   * - `animation` - Optional animation used for this attention request.
   * @returns Whether the attention animation finished.
   */
  requestAttention(...args: Parameters<SheetElement['requestAttention']>): ReturnType<SheetElement['requestAttention']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `open()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends SheetMethodNames>(method: TMethod, ...args: Parameters<SheetComponentMethods[TMethod]>): ReturnType<SheetComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof SheetElement>(property: TProperty, value: SheetElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<SheetElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SheetComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SheetComponent, "mosaik-sheet", never, {
    "width": {
      "alias": "width";
      "required": false;
      "isSignal": true;
    };
    "height": {
      "alias": "height";
      "required": false;
      "isSignal": true;
    };
    "position": {
      "alias": "position";
      "required": false;
      "isSignal": true;
    };
    "snaps": {
      "alias": "snaps";
      "required": false;
      "isSignal": true;
    };
    "activeSnapIndex": {
      "alias": "activeSnapIndex";
      "required": false;
      "isSignal": true;
    };
    "closeThreshold": {
      "alias": "closeThreshold";
      "required": false;
      "isSignal": true;
    };
    "elastic": {
      "alias": "elastic";
      "required": false;
      "isSignal": true;
    };
    "inertia": {
      "alias": "inertia";
      "required": false;
      "isSignal": true;
    };
    "dragMode": {
      "alias": "dragMode";
      "required": false;
      "isSignal": true;
    };
    "hasHandle": {
      "alias": "hasHandle";
      "required": false;
      "isSignal": true;
    };
    "hasSnapIndicator": {
      "alias": "hasSnapIndicator";
      "required": false;
      "isSignal": true;
    };
    "isModal": {
      "alias": "isModal";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "isOpen": {
      "alias": "isOpen";
      "required": false;
      "isSignal": true;
    };
    "hasBackdrop": {
      "alias": "hasBackdrop";
      "required": false;
      "isSignal": true;
    };
    "pressEscapeToClose": {
      "alias": "pressEscapeToClose";
      "required": false;
      "isSignal": true;
    };
    "clickOutsideToClose": {
      "alias": "clickOutsideToClose";
      "required": false;
      "isSignal": true;
    };
    "attention": {
      "alias": "attention";
      "required": false;
      "isSignal": true;
    };
    "closeable": {
      "alias": "closeable";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "activeSnapChanged": "activeSnapChanged";
    "dragStart": "dragStart";
    "dragging": "dragging";
    "dragEnd": "dragEnd";
    "opened": "opened";
    "closed": "closed";
    "closeAttempted": "closeAttempted";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on SheetComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SheetMethodNames = 'open' | 'close' | 'snapTo' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges' | 'requestAttention';
/**
 * Declares the methods interface for SheetComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SheetComponentMethods = MethodMap<SheetMethodNames>;
/**
 * @public
 */
export declare function provideSheetComponent(config?: Partial<SheetElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-sheet.d.ts.map