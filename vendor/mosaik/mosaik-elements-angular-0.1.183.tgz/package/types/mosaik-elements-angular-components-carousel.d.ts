import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { CarouselItemElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/carousel/CarouselItemElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { CarouselElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/carousel/CarouselElement";
/**
 * @public
 *
 * Injection token for the default properties of the CarouselItemComponent.
 * Use this token to provide default properties for the CarouselItemComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const CAROUSEL_ITEM_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/selectors/carousel/ICarouselItemElementProps").ICarouselItemElementProps>>;
/**
 * @public
 *
 * @slot  - Default content area for the carousel item's content
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class CarouselItemComponent {
  /**
   * Signal input for the `timeout` property.
   *
   * @public
   */
  readonly timeout: InputSignal<CarouselItemElement['timeout'] | undefined>;
  /**
   * Signal input for the `isDismissed` property.
   *
   * @public
   */
  readonly isDismissed: InputSignal<CarouselItemElement['isDismissed'] | undefined>;
  /**
   * Signal input for the `isActive` property.
   *
   * @public
   */
  readonly isActive: InputSignal<CarouselItemElement['isActive'] | undefined>;
  /**
   * Signal input for the `dismissDirection` property.
   *
   * @public
   */
  readonly dismissDirection: InputSignal<CarouselItemElement['dismissDirection'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<CarouselItemElement['themeName'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<CarouselItemElement['disabled'] | undefined>;
  /**
   * Signal input for the `isSelected` property.
   *
   * @public
   */
  readonly isSelected: InputSignal<CarouselItemElement['isSelected'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<CarouselItemElement['value'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<CarouselItemElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<CarouselItemElement['lang'] | undefined>;
  /**
   * Output signal for the `selected` event.
   *
   * @public
   */
  readonly selected: OutputEmitterRef<ElementEventDetail<CarouselItemElement, 'selected'>>;
  /**
   * Output signal for the `deselected` event.
   *
   * @public
   */
  readonly deselected: OutputEmitterRef<ElementEventDetail<CarouselItemElement, 'deselected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<CarouselItemElement, 'changed'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<CarouselItemElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<CarouselItemElement, 'disconnected'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Selects the item and fires `selected`. Does nothing when the item is already selected.
   *
   * @public
   * @param args - The arguments of `select`:
   * - `forceUpdate` - When `true`, the parent selector also selects the item.
   */
  select(...args: Parameters<CarouselItemElement['select']>): ReturnType<CarouselItemElement['select']>;
  /**
   * Deselects the item and fires `deselected`. Does nothing when the item is not selected.
   *
   * @public
   * @param args - The arguments of `deselect`:
   * - `forceUpdate` - When `true`, the parent selector also deselects the item.
   */
  deselect(...args: Parameters<CarouselItemElement['deselect']>): ReturnType<CarouselItemElement['deselect']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `select()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends CarouselItemMethodNames>(method: TMethod, ...args: Parameters<CarouselItemComponentMethods[TMethod]>): ReturnType<CarouselItemComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof CarouselItemElement>(property: TProperty, value: CarouselItemElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<CarouselItemElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<CarouselItemComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<CarouselItemComponent, "mosaik-carousel-item", never, {
    "timeout": {
      "alias": "timeout";
      "required": false;
      "isSignal": true;
    };
    "isDismissed": {
      "alias": "isDismissed";
      "required": false;
      "isSignal": true;
    };
    "isActive": {
      "alias": "isActive";
      "required": false;
      "isSignal": true;
    };
    "dismissDirection": {
      "alias": "dismissDirection";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "isSelected": {
      "alias": "isSelected";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "selected": "selected";
    "deselected": "deselected";
    "changed": "changed";
    "connected": "connected";
    "disconnected": "disconnected";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on CarouselItemComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type CarouselItemMethodNames = 'select' | 'deselect';
/**
 * Declares the methods interface for CarouselItemComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type CarouselItemComponentMethods = MethodMap<CarouselItemMethodNames>;
/**
 * @public
 */
export declare function provideCarouselItemComponent(config?: Partial<CarouselItemElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the CarouselComponent.
 * Use this token to provide default properties for the CarouselComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const CAROUSEL_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/selectors/carousel/ICarouselElementProps").ICarouselElementProps>>;
/**
 * @public
 *
 * @slot  - Default content area for carousel items and navigation elements
 * @slot indicator - The indicator slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class CarouselComponent {
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<CarouselElement['intl'] | undefined>;
  /**
   * Signal input for the `autoplay` property.
   *
   * @public
   */
  readonly autoplay: InputSignal<CarouselElement['autoplay'] | undefined>;
  /**
   * Signal input for the `timeout` property.
   *
   * @public
   */
  readonly timeout: InputSignal<CarouselElement['timeout'] | undefined>;
  /**
   * Signal input for the `showNavigation` property.
   *
   * @public
   */
  readonly showNavigation: InputSignal<CarouselElement['showNavigation'] | undefined>;
  /**
   * Signal input for the `showIndicator` property.
   *
   * @public
   */
  readonly showIndicator: InputSignal<CarouselElement['showIndicator'] | undefined>;
  /**
   * Signal input for the `indicatorMode` property.
   *
   * @public
   */
  readonly indicatorMode: InputSignal<CarouselElement['indicatorMode'] | undefined>;
  /**
   * Signal input for the `slideAlignment` property.
   *
   * @public
   */
  readonly slideAlignment: InputSignal<CarouselElement['slideAlignment'] | undefined>;
  /**
   * Signal input for the `loop` property.
   *
   * @public
   */
  readonly loop: InputSignal<CarouselElement['loop'] | undefined>;
  /**
   * Signal input for the `navigationPosition` property.
   *
   * @public
   */
  readonly navigationPosition: InputSignal<CarouselElement['navigationPosition'] | undefined>;
  /**
   * Signal input for the `displayMode` property.
   *
   * @public
   */
  readonly displayMode: InputSignal<CarouselElement['displayMode'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<CarouselElement['themeName'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<CarouselElement['disabled'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<CarouselElement['appearance'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<CarouselElement['variant'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<CarouselElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<CarouselElement['lang'] | undefined>;
  /**
   * Output signal for the `selectionChanged` event.
   *
   * @public
   */
  readonly selectionChanged: OutputEmitterRef<ElementEventDetail<CarouselElement, 'selectionChanged'>>;
  /**
   * Output signal for the `itemsChanged` event.
   *
   * @public
   */
  readonly itemsChanged: OutputEmitterRef<ElementEventDetail<CarouselElement, 'itemsChanged'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<CarouselElement, 'changed'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<CarouselElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<CarouselElement, 'disconnected'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Starts autoplay.
   *
   * @public
   */
  start(...args: Parameters<CarouselElement['start']>): ReturnType<CarouselElement['start']>;
  /**
   * Stops autoplay.
   *
   * @public
   */
  stop(...args: Parameters<CarouselElement['stop']>): ReturnType<CarouselElement['stop']>;
  /**
   * Pauses autoplay.
   *
   * @public
   */
  pause(...args: Parameters<CarouselElement['pause']>): ReturnType<CarouselElement['pause']>;
  /**
   * Resumes autoplay.
   *
   * @public
   */
  resume(...args: Parameters<CarouselElement['resume']>): ReturnType<CarouselElement['resume']>;
  /**
   * Select the item.
   *
   * @public
   */
  select(...args: Parameters<CarouselElement['select']>): ReturnType<CarouselElement['select']>;
  /**
   * Select the next item after current selected item/index.
   *
   * @public
   */
  selectNext(...args: Parameters<CarouselElement['selectNext']>): ReturnType<CarouselElement['selectNext']>;
  /**
   * Select the previous item before current selected item/index.
   *
   * @public
   */
  selectPrevious(...args: Parameters<CarouselElement['selectPrevious']>): ReturnType<CarouselElement['selectPrevious']>;
  /**
   * Select the first item.
   *
   * @public
   */
  selectFirst(...args: Parameters<CarouselElement['selectFirst']>): ReturnType<CarouselElement['selectFirst']>;
  /**
   * Select the last item.
   *
   * @public
   */
  selectLast(...args: Parameters<CarouselElement['selectLast']>): ReturnType<CarouselElement['selectLast']>;
  /**
   * Deselect the item.
   *
   * @public
   * @param args - The arguments of `deselect`:
   * - `item` - The element or index to deselect.
   */
  deselect(...args: Parameters<CarouselElement['deselect']>): ReturnType<CarouselElement['deselect']>;
  /**
   * Resets the current selection.
   *
   * @public
   */
  resetSelection(...args: Parameters<CarouselElement['resetSelection']>): ReturnType<CarouselElement['resetSelection']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `start()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends CarouselMethodNames>(method: TMethod, ...args: Parameters<CarouselComponentMethods[TMethod]>): ReturnType<CarouselComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof CarouselElement>(property: TProperty, value: CarouselElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<CarouselElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<CarouselComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<CarouselComponent, "mosaik-carousel", never, {
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "autoplay": {
      "alias": "autoplay";
      "required": false;
      "isSignal": true;
    };
    "timeout": {
      "alias": "timeout";
      "required": false;
      "isSignal": true;
    };
    "showNavigation": {
      "alias": "showNavigation";
      "required": false;
      "isSignal": true;
    };
    "showIndicator": {
      "alias": "showIndicator";
      "required": false;
      "isSignal": true;
    };
    "indicatorMode": {
      "alias": "indicatorMode";
      "required": false;
      "isSignal": true;
    };
    "slideAlignment": {
      "alias": "slideAlignment";
      "required": false;
      "isSignal": true;
    };
    "loop": {
      "alias": "loop";
      "required": false;
      "isSignal": true;
    };
    "navigationPosition": {
      "alias": "navigationPosition";
      "required": false;
      "isSignal": true;
    };
    "displayMode": {
      "alias": "displayMode";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "selectionChanged": "selectionChanged";
    "itemsChanged": "itemsChanged";
    "changed": "changed";
    "connected": "connected";
    "disconnected": "disconnected";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on CarouselComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type CarouselMethodNames = 'start' | 'stop' | 'pause' | 'resume' | 'select' | 'selectNext' | 'selectPrevious' | 'selectFirst' | 'selectLast' | 'deselect' | 'resetSelection';
/**
 * Declares the methods interface for CarouselComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type CarouselComponentMethods = MethodMap<CarouselMethodNames>;
/**
 * @public
 */
export declare function provideCarouselComponent(config?: Partial<CarouselElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-carousel.d.ts.map