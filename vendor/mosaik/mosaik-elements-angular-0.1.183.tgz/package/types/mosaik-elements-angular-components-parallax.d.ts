import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { ParallaxElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/illustrations/parallax/ParallaxElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the ParallaxComponent.
 * Use this token to provide default properties for the ParallaxComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const PARALLAX_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").IParallaxElementProps>>;
/**
 * @public
 *
 * @slot  - Readable content that moves as a single layer.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ParallaxComponent {
  /**
   * Signal input for the `distance` property.
   *
   * @public
   */
  readonly distance: InputSignal<ParallaxElement['distance'] | undefined>;
  /**
   * Signal input for the `axis` property.
   *
   * @public
   */
  readonly axis: InputSignal<ParallaxElement['axis'] | undefined>;
  /**
   * Signal input for the `reverse` property.
   *
   * @public
   */
  readonly reverse: InputSignal<ParallaxElement['reverse'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ParallaxElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ParallaxElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ParallaxElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ParallaxElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ParallaxElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ParallaxElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ParallaxElement>(property: TProperty, value: ParallaxElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ParallaxElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ParallaxComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ParallaxComponent, "mosaik-parallax", never, {
    "distance": {
      "alias": "distance";
      "required": false;
      "isSignal": true;
    };
    "axis": {
      "alias": "axis";
      "required": false;
      "isSignal": true;
    };
    "reverse": {
      "alias": "reverse";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on ParallaxComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ParallaxMethodNames = never;
/**
 * Declares the methods interface for ParallaxComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ParallaxComponentMethods = MethodMap<ParallaxMethodNames>;
/**
 * @public
 */
export declare function provideParallaxComponent(config?: Partial<ParallaxElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-parallax.d.ts.map