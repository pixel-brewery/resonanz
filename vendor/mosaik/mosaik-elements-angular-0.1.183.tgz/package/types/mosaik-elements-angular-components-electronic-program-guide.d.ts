import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { EpgChannelElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/electronic-program-guide/EpgChannelElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { EpgProgramElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/electronic-program-guide/EpgProgramElement";
import { EpgElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/electronic-program-guide/EpgElement";
/**
 * @public
 *
 * Injection token for the default properties of the EpgChannelComponent.
 * Use this token to provide default properties for the EpgChannelComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const EPG_CHANNEL_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/selectors/electronic-program-guide/IEpgChannelElementProps").IEpgChannelElementProps>>;
/**
 * @public
 *
 * @slot  - Default content area for channel program items
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class EpgChannelComponent {
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<EpgChannelElement['themeName'] | undefined>;
  /**
   * Signal input for the `locale` property.
   *
   * @public
   */
  readonly locale: InputSignal<EpgChannelElement['locale'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<EpgChannelElement['value'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<EpgChannelElement['variant'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<EpgChannelElement['appearance'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<EpgChannelElement['disabled'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<EpgChannelElement['label'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<EpgChannelElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<EpgChannelElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<EpgChannelElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<EpgChannelElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<EpgChannelElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof EpgChannelElement>(property: TProperty, value: EpgChannelElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<EpgChannelElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<EpgChannelComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<EpgChannelComponent, "mosaik-epg-channel", never, {
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "locale": {
      "alias": "locale";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on EpgChannelComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type EpgChannelMethodNames = never;
/**
 * Declares the methods interface for EpgChannelComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type EpgChannelComponentMethods = MethodMap<EpgChannelMethodNames>;
/**
 * @public
 */
export declare function provideEpgChannelComponent(config?: Partial<EpgChannelElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the EpgProgramComponent.
 * Use this token to provide default properties for the EpgProgramComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const EPG_PROGRAM_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/selectors/electronic-program-guide/IEpgProgramElementProps").IEpgProgramElementProps>>;
/**
 * @public
 *
 * @slot  - Default content area for program title text
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class EpgProgramComponent {
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<EpgProgramElement['intl'] | undefined>;
  /**
   * Signal input for the `header` property.
   *
   * @public
   */
  readonly header: InputSignal<EpgProgramElement['header'] | undefined>;
  /**
   * Signal input for the `lane` property.
   *
   * @public
   */
  readonly lane: InputSignal<EpgProgramElement['lane'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<EpgProgramElement['themeName'] | undefined>;
  /**
   * Signal input for the `isFiltered` property.
   *
   * @public
   */
  readonly isFiltered: InputSignal<EpgProgramElement['isFiltered'] | undefined>;
  /**
   * Signal input for the `locale` property.
   *
   * @public
   */
  readonly locale: InputSignal<EpgProgramElement['locale'] | undefined>;
  /**
   * Signal input for the `start` property.
   *
   * @public
   */
  readonly start: InputSignal<EpgProgramElement['start'] | undefined>;
  /**
   * Signal input for the `end` property.
   *
   * @public
   */
  readonly end: InputSignal<EpgProgramElement['end'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<EpgProgramElement['variant'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<EpgProgramElement['appearance'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<EpgProgramElement['disabled'] | undefined>;
  /**
   * Signal input for the `isFocused` property.
   *
   * @public
   */
  readonly isFocused: InputSignal<EpgProgramElement['isFocused'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<EpgProgramElement['value'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<EpgProgramElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<EpgProgramElement['lang'] | undefined>;
  /**
   * Output signal for the `select` event.
   *
   * @public
   */
  readonly select: OutputEmitterRef<ElementEventDetail<EpgProgramElement, 'select'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<EpgProgramElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<EpgProgramElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<EpgProgramElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof EpgProgramElement>(property: TProperty, value: EpgProgramElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<EpgProgramElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<EpgProgramComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<EpgProgramComponent, "mosaik-epg-program", never, {
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "header": {
      "alias": "header";
      "required": false;
      "isSignal": true;
    };
    "lane": {
      "alias": "lane";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "isFiltered": {
      "alias": "isFiltered";
      "required": false;
      "isSignal": true;
    };
    "locale": {
      "alias": "locale";
      "required": false;
      "isSignal": true;
    };
    "start": {
      "alias": "start";
      "required": false;
      "isSignal": true;
    };
    "end": {
      "alias": "end";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "isFocused": {
      "alias": "isFocused";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "select": "select";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on EpgProgramComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type EpgProgramMethodNames = never;
/**
 * Declares the methods interface for EpgProgramComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type EpgProgramComponentMethods = MethodMap<EpgProgramMethodNames>;
/**
 * @public
 */
export declare function provideEpgProgramComponent(config?: Partial<EpgProgramElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the EpgComponent.
 * Use this token to provide default properties for the EpgComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const EPG_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/selectors/electronic-program-guide/IEpgElementProps").IEpgElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot.
 * @slot channels - `mosaik-epg-channel` elements for each broadcast channel row
 * @slot toolbar - The toolbar slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class EpgComponent {
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<EpgElement['intl'] | undefined>;
  /**
   * Signal input for the `zoom` property.
   *
   * @public
   */
  readonly zoom: InputSignal<EpgElement['zoom'] | undefined>;
  /**
   * Signal input for the `showNowLine` property.
   *
   * @public
   */
  readonly showNowLine: InputSignal<EpgElement['showNowLine'] | undefined>;
  /**
   * Signal input for the `showMinimap` property.
   *
   * @public
   */
  readonly showMinimap: InputSignal<EpgElement['showMinimap'] | undefined>;
  /**
   * Signal input for the `timelineFormat` property.
   *
   * @public
   */
  readonly timelineFormat: InputSignal<EpgElement['timelineFormat'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<EpgElement['themeName'] | undefined>;
  /**
   * Signal input for the `showFilter` property.
   *
   * @public
   */
  readonly showFilter: InputSignal<EpgElement['showFilter'] | undefined>;
  /**
   * Signal input for the `filterMemberPath` property.
   *
   * @public
   */
  readonly filterMemberPath: InputSignal<EpgElement['filterMemberPath'] | undefined>;
  /**
   * Signal input for the `filter` property.
   *
   * @public
   */
  readonly filter: InputSignal<EpgElement['filter'] | undefined>;
  /**
   * Signal input for the `filterPlaceholder` property.
   *
   * @public
   */
  readonly filterPlaceholder: InputSignal<EpgElement['filterPlaceholder'] | undefined>;
  /**
   * Signal input for the `start` property.
   *
   * @public
   */
  readonly start: InputSignal<EpgElement['start'] | undefined>;
  /**
   * Signal input for the `end` property.
   *
   * @public
   */
  readonly end: InputSignal<EpgElement['end'] | undefined>;
  /**
   * Signal input for the `locale` property.
   *
   * @public
   */
  readonly locale: InputSignal<EpgElement['locale'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<EpgElement['appearance'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<EpgElement['variant'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<EpgElement['disabled'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<EpgElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<EpgElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<EpgElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<EpgElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<EpgElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Calls `zoomIn` on the `mosaik-epg` element.
   *
   * @public
   */
  zoomIn(...args: Parameters<EpgElement['zoomIn']>): ReturnType<EpgElement['zoomIn']>;
  /**
   * Calls `zoomOut` on the `mosaik-epg` element.
   *
   * @public
   */
  zoomOut(...args: Parameters<EpgElement['zoomOut']>): ReturnType<EpgElement['zoomOut']>;
  /**
   * Moves the guide one day ahead (`start` and `end` move by one calendar day).
   *
   * @public
   */
  nextDate(...args: Parameters<EpgElement['nextDate']>): ReturnType<EpgElement['nextDate']>;
  /**
   * Moves the guide one day back (`start` and `end` move by one calendar day).
   *
   * @public
   */
  previousDate(...args: Parameters<EpgElement['previousDate']>): ReturnType<EpgElement['previousDate']>;
  /**
   * Scrolls the time axis so that the current time sits in the middle of the visible programme area.
   *
   * @public
   * @param args - The arguments of `scrollToNow`:
   * - `smooth` - Whether the guide scrolls smoothly.
   */
  scrollToNow(...args: Parameters<EpgElement['scrollToNow']>): ReturnType<EpgElement['scrollToNow']>;
  /**
   * Calls `dragStart` on the `mosaik-epg` element.
   *
   * @public
   */
  dragStart(...args: Parameters<EpgElement['dragStart']>): ReturnType<EpgElement['dragStart']>;
  /**
   * Calls `touchStart` on the `mosaik-epg` element.
   *
   * @public
   */
  touchStart(...args: Parameters<EpgElement['touchStart']>): ReturnType<EpgElement['touchStart']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `zoomIn()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends EpgMethodNames>(method: TMethod, ...args: Parameters<EpgComponentMethods[TMethod]>): ReturnType<EpgComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof EpgElement>(property: TProperty, value: EpgElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<EpgElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<EpgComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<EpgComponent, "mosaik-epg", never, {
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "zoom": {
      "alias": "zoom";
      "required": false;
      "isSignal": true;
    };
    "showNowLine": {
      "alias": "showNowLine";
      "required": false;
      "isSignal": true;
    };
    "showMinimap": {
      "alias": "showMinimap";
      "required": false;
      "isSignal": true;
    };
    "timelineFormat": {
      "alias": "timelineFormat";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "showFilter": {
      "alias": "showFilter";
      "required": false;
      "isSignal": true;
    };
    "filterMemberPath": {
      "alias": "filterMemberPath";
      "required": false;
      "isSignal": true;
    };
    "filter": {
      "alias": "filter";
      "required": false;
      "isSignal": true;
    };
    "filterPlaceholder": {
      "alias": "filterPlaceholder";
      "required": false;
      "isSignal": true;
    };
    "start": {
      "alias": "start";
      "required": false;
      "isSignal": true;
    };
    "end": {
      "alias": "end";
      "required": false;
      "isSignal": true;
    };
    "locale": {
      "alias": "locale";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on EpgComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type EpgMethodNames = 'zoomIn' | 'zoomOut' | 'nextDate' | 'previousDate' | 'scrollToNow' | 'dragStart' | 'touchStart';
/**
 * Declares the methods interface for EpgComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type EpgComponentMethods = MethodMap<EpgMethodNames>;
/**
 * @public
 */
export declare function provideEpgComponent(config?: Partial<EpgElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-electronic-program-guide.d.ts.map