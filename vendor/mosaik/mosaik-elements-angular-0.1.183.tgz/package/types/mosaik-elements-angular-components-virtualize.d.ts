import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { VirtualizeElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/virtualize/VirtualizeElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the VirtualizeComponent.
 * Use this token to provide default properties for the VirtualizeComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const VIRTUALIZE_DEFAULT_PROPS: InjectionToken<Partial<VirtualizeElement.Props>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class VirtualizeComponent {
  /**
   * Signal input for the `items` property.
   *
   * @public
   */
  readonly items: InputSignal<VirtualizeElement['items'] | undefined>;
  /**
   * Signal input for the `renderItem` property.
   *
   * @public
   */
  readonly renderItem: InputSignal<VirtualizeElement['renderItem'] | undefined>;
  /**
   * Signal input for the `keyFunction` property.
   *
   * @public
   */
  readonly keyFunction: InputSignal<VirtualizeElement['keyFunction'] | undefined>;
  /**
   * Signal input for the `layout` property.
   *
   * @public
   */
  readonly layout: InputSignal<VirtualizeElement['layout'] | undefined>;
  /**
   * Signal input for the `scroller` property.
   *
   * @public
   */
  readonly scroller: InputSignal<VirtualizeElement['scroller'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<VirtualizeElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<VirtualizeElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<VirtualizeElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<VirtualizeElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<VirtualizeElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<VirtualizeElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof VirtualizeElement>(property: TProperty, value: VirtualizeElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<VirtualizeElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<VirtualizeComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<VirtualizeComponent, "mosaik-virtualize", never, {
    "items": {
      "alias": "items";
      "required": false;
      "isSignal": true;
    };
    "renderItem": {
      "alias": "renderItem";
      "required": false;
      "isSignal": true;
    };
    "keyFunction": {
      "alias": "keyFunction";
      "required": false;
      "isSignal": true;
    };
    "layout": {
      "alias": "layout";
      "required": false;
      "isSignal": true;
    };
    "scroller": {
      "alias": "scroller";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on VirtualizeComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type VirtualizeMethodNames = never;
/**
 * Declares the methods interface for VirtualizeComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type VirtualizeComponentMethods = MethodMap<VirtualizeMethodNames>;
/**
 * @public
 */
export declare function provideVirtualizeComponent(config?: Partial<VirtualizeElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-virtualize.d.ts.map