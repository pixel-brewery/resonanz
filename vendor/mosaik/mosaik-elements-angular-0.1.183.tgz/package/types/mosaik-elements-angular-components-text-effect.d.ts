import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { TextEffectElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/illustrations/text-effect/TextEffectElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the TextEffectComponent.
 * Use this token to provide default properties for the TextEffectComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const TEXT_EFFECT_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").ITextEffectElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class TextEffectComponent {
  /**
   * Signal input for the `effect` property.
   *
   * @public
   */
  readonly effect: InputSignal<TextEffectElement['effect'] | undefined>;
  /**
   * Signal input for the `text` property.
   *
   * @public
   */
  readonly text: InputSignal<TextEffectElement['text'] | undefined>;
  /**
   * Signal input for the `words` property.
   *
   * @public
   */
  readonly words: InputSignal<TextEffectElement['words'] | undefined>;
  /**
   * Signal input for the `interval` property.
   *
   * @public
   */
  readonly interval: InputSignal<TextEffectElement['interval'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<TextEffectElement['label'] | undefined>;
  /**
   * Signal input for the `mediaSource` property.
   *
   * @public
   */
  readonly mediaSource: InputSignal<TextEffectElement['mediaSource'] | undefined>;
  /**
   * Signal input for the `mediaKind` property.
   *
   * @public
   */
  readonly mediaKind: InputSignal<TextEffectElement['mediaKind'] | undefined>;
  /**
   * Signal input for the `poster` property.
   *
   * @public
   */
  readonly poster: InputSignal<TextEffectElement['poster'] | undefined>;
  /**
   * Signal input for the `reverse` property.
   *
   * @public
   */
  readonly reverse: InputSignal<TextEffectElement['reverse'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<TextEffectElement['themeName'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<TextEffectElement['variant'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<TextEffectElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<TextEffectElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<TextEffectElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<TextEffectElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<TextEffectElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof TextEffectElement>(property: TProperty, value: TextEffectElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<TextEffectElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<TextEffectComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<TextEffectComponent, "mosaik-text-effect", never, {
    "effect": {
      "alias": "effect";
      "required": false;
      "isSignal": true;
    };
    "text": {
      "alias": "text";
      "required": false;
      "isSignal": true;
    };
    "words": {
      "alias": "words";
      "required": false;
      "isSignal": true;
    };
    "interval": {
      "alias": "interval";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "mediaSource": {
      "alias": "mediaSource";
      "required": false;
      "isSignal": true;
    };
    "mediaKind": {
      "alias": "mediaKind";
      "required": false;
      "isSignal": true;
    };
    "poster": {
      "alias": "poster";
      "required": false;
      "isSignal": true;
    };
    "reverse": {
      "alias": "reverse";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on TextEffectComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TextEffectMethodNames = never;
/**
 * Declares the methods interface for TextEffectComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TextEffectComponentMethods = MethodMap<TextEffectMethodNames>;
/**
 * @public
 */
export declare function provideTextEffectComponent(config?: Partial<TextEffectElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-text-effect.d.ts.map