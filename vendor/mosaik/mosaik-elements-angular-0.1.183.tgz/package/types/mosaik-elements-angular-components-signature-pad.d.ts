import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef, Type } from "@angular/core";
import { ControlValueAccessor } from "@angular/forms";
import { SignaturePadElement } from "@pixel-brewery/mosaik-elements-foundation/components/signature-pad";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import * as i1 from "@pixel-brewery/mosaik-elements-angular/runtime";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the SignaturePadComponent.
 * Use this token to provide default properties for the SignaturePadComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const SIGNATURE_PAD_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation/components/signature-pad").ISignaturePadElementProps>>;
/**
 * @public
 *
 * Injection token for the intl configuration of the SignaturePadComponent.
 * Provide a partial intl object or an injectable class that resolves translations.
 * This allows third-party applications to override the default intl labels
 * globally, per route, or per component via Angular's dependency injection.
 *
 * Merge order: Foundation defaults → DI intl → [intl] input binding.
 */
export declare const SIGNATURE_PAD_INTL: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation/components/signature-pad").SignaturePadElementIntl>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class SignaturePadComponent implements ControlValueAccessor {
  /**
   * Signal input for the `width` property.
   *
   * @public
   */
  readonly width: InputSignal<SignaturePadElement['width'] | undefined>;
  /**
   * Signal input for the `height` property.
   *
   * @public
   */
  readonly height: InputSignal<SignaturePadElement['height'] | undefined>;
  /**
   * Signal input for the `placeholder` property.
   *
   * @public
   */
  readonly placeholder: InputSignal<SignaturePadElement['placeholder'] | undefined>;
  /**
   * Signal input for the `minDistance` property.
   *
   * @public
   */
  readonly minDistance: InputSignal<SignaturePadElement['minDistance'] | undefined>;
  /**
   * Signal input for the `throttle` property.
   *
   * @public
   */
  readonly throttle: InputSignal<SignaturePadElement['throttle'] | undefined>;
  /**
   * Signal input for the `dotSize` property.
   *
   * @public
   */
  readonly dotSize: InputSignal<SignaturePadElement['dotSize'] | undefined>;
  /**
   * Signal input for the `minWidth` property.
   *
   * @public
   */
  readonly minWidth: InputSignal<SignaturePadElement['minWidth'] | undefined>;
  /**
   * Signal input for the `maxWidth` property.
   *
   * @public
   */
  readonly maxWidth: InputSignal<SignaturePadElement['maxWidth'] | undefined>;
  /**
   * Signal input for the `velocityFilterWeight` property.
   *
   * @public
   */
  readonly velocityFilterWeight: InputSignal<SignaturePadElement['velocityFilterWeight'] | undefined>;
  /**
   * Signal input for the `backgroundColor` property.
   *
   * @public
   */
  readonly backgroundColor: InputSignal<SignaturePadElement['backgroundColor'] | undefined>;
  /**
   * Signal input for the `penColor` property.
   *
   * @public
   */
  readonly penColor: InputSignal<SignaturePadElement['penColor'] | undefined>;
  /**
   * Signal input for the `required` property.
   *
   * @public
   */
  readonly required: InputSignal<SignaturePadElement['required'] | undefined>;
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<Partial<SignaturePadElement['intl']> | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<SignaturePadElement['themeName'] | undefined>;
  /**
   * Signal input for the `isClearable` property.
   *
   * @public
   */
  readonly isClearable: InputSignal<SignaturePadElement['isClearable'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<SignaturePadElement['disabled'] | undefined>;
  /**
   * Signal input for the `isFocused` property.
   *
   * @public
   */
  readonly isFocused: InputSignal<SignaturePadElement['isFocused'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<SignaturePadElement['variant'] | undefined>;
  /**
   * Signal input for the `invalid` property.
   *
   * @public
   */
  readonly invalid: InputSignal<SignaturePadElement['invalid'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<SignaturePadElement['value'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<SignaturePadElement['label'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<SignaturePadElement['appearance'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<SignaturePadElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<SignaturePadElement['lang'] | undefined>;
  /**
   * Output signal for the `cleared` event.
   *
   * @public
   */
  readonly cleared: OutputEmitterRef<ElementEventDetail<SignaturePadElement, 'cleared'>>;
  /**
   * Output signal for the `signStarted` event.
   *
   * @public
   */
  readonly signStarted: OutputEmitterRef<ElementEventDetail<SignaturePadElement, 'signStarted'>>;
  /**
   * Output signal for the `signEnded` event.
   *
   * @public
   */
  readonly signEnded: OutputEmitterRef<ElementEventDetail<SignaturePadElement, 'signEnded'>>;
  /**
   * Output signal for the `signStrokeBeforeUpdate` event.
   *
   * @public
   */
  readonly signStrokeBeforeUpdate: OutputEmitterRef<ElementEventDetail<SignaturePadElement, 'signStrokeBeforeUpdate'>>;
  /**
   * Output signal for the `signStrokeAfterUpdate` event.
   *
   * @public
   */
  readonly signStrokeAfterUpdate: OutputEmitterRef<ElementEventDetail<SignaturePadElement, 'signStrokeAfterUpdate'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<SignaturePadElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<SignaturePadElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<SignaturePadElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  private readonly _accessor;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Applies a value supplied by Angular forms to the native control.
   *
   * @public
   */
  writeValue(obj: unknown): void;
  /**
   * Registers the callback notified when the native control value changes.
   *
   * @public
   */
  registerOnChange(fn: unknown): void;
  /**
   * Registers the callback notified when the native control is touched.
   *
   * @public
   */
  registerOnTouched(fn: unknown): void;
  /**
   * Applies the disabled state supplied by Angular forms.
   *
   * @public
   */
  setDisabledState?(isDisabled: boolean): void;
  /**
   * Checks the validity of the element and returns `true` if it is valid; otherwise, `false`.
   *
   * @public
   */
  checkValidity(...args: Parameters<SignaturePadElement['checkValidity']>): ReturnType<SignaturePadElement['checkValidity']>;
  /**
   * Resets the value, all kinds of validation and errors.
   *
   * @public
   */
  reset(...args: Parameters<SignaturePadElement['reset']>): ReturnType<SignaturePadElement['reset']>;
  /**
   * Returns signature image as an array of point groups.
   *
   * @public
   */
  toData(...args: Parameters<SignaturePadElement['toData']>): ReturnType<SignaturePadElement['toData']>;
  /**
   * Returns signature image as data URL (see https://mdn.io/todataurl for the list of possible parameters).
   *
   * @public
   */
  toDataURL(...args: Parameters<SignaturePadElement['toDataURL']>): ReturnType<SignaturePadElement['toDataURL']>;
  /**
   * Returns signature image as data URL trimmed from white space.
   *
   * @public
   */
  toBlob(...args: Parameters<SignaturePadElement['toBlob']>): ReturnType<SignaturePadElement['toBlob']>;
  /**
   * Draws signature image from an array of point groups.
   *
   * @public
   */
  fromData(...args: Parameters<SignaturePadElement['fromData']>): ReturnType<SignaturePadElement['fromData']>;
  /**
   * Draws a signature image and refreshes its empty-state controls after decoding.
   *
   * @public
   */
  fromDataURL(...args: Parameters<SignaturePadElement['fromDataURL']>): ReturnType<SignaturePadElement['fromDataURL']>;
  /**
   * Clears the canvas before notifying listeners, without resetting validation.
   *
   * @public
   */
  clear(...args: Parameters<SignaturePadElement['clear']>): ReturnType<SignaturePadElement['clear']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `checkValidity()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends SignaturePadMethodNames>(method: TMethod, ...args: Parameters<SignaturePadComponentMethods[TMethod]>): ReturnType<SignaturePadComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof SignaturePadElement>(property: TProperty, value: SignaturePadElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<SignaturePadElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SignaturePadComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SignaturePadComponent, "mosaik-signaturepad", never, {
    "width": {
      "alias": "width";
      "required": false;
      "isSignal": true;
    };
    "height": {
      "alias": "height";
      "required": false;
      "isSignal": true;
    };
    "placeholder": {
      "alias": "placeholder";
      "required": false;
      "isSignal": true;
    };
    "minDistance": {
      "alias": "minDistance";
      "required": false;
      "isSignal": true;
    };
    "throttle": {
      "alias": "throttle";
      "required": false;
      "isSignal": true;
    };
    "dotSize": {
      "alias": "dotSize";
      "required": false;
      "isSignal": true;
    };
    "minWidth": {
      "alias": "minWidth";
      "required": false;
      "isSignal": true;
    };
    "maxWidth": {
      "alias": "maxWidth";
      "required": false;
      "isSignal": true;
    };
    "velocityFilterWeight": {
      "alias": "velocityFilterWeight";
      "required": false;
      "isSignal": true;
    };
    "backgroundColor": {
      "alias": "backgroundColor";
      "required": false;
      "isSignal": true;
    };
    "penColor": {
      "alias": "penColor";
      "required": false;
      "isSignal": true;
    };
    "required": {
      "alias": "required";
      "required": false;
      "isSignal": true;
    };
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "isClearable": {
      "alias": "isClearable";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "isFocused": {
      "alias": "isFocused";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "invalid": {
      "alias": "invalid";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "cleared": "cleared";
    "signStarted": "signStarted";
    "signEnded": "signEnded";
    "signStrokeBeforeUpdate": "signStrokeBeforeUpdate";
    "signStrokeAfterUpdate": "signStrokeAfterUpdate";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, [{
    directive: typeof i1.FormStatusHostDirective;
    inputs: {};
    outputs: {};
  }, {
    directive: typeof i1.FormFieldStatusHostDirective;
    inputs: {};
    outputs: {};
  }]>;
}
/**
 * Declares the methods available on SignaturePadComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SignaturePadMethodNames = 'checkValidity' | 'reset' | 'toData' | 'toDataURL' | 'toBlob' | 'fromData' | 'fromDataURL' | 'clear';
/**
 * Declares the methods interface for SignaturePadComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SignaturePadComponentMethods = MethodMap<SignaturePadMethodNames>;
/**
 * @public
 */
export declare function provideSignaturePadComponent(config?: Partial<SignaturePadElement.Props>, intl?: Partial<SignaturePadElement['intl']> | Type<Partial<SignaturePadElement['intl']>>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-signature-pad.d.ts.map