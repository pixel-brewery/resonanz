import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { PerspectiveElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/effects/perspective/PerspectiveElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the PerspectiveComponent.
 * Use this token to provide default properties for the PerspectiveComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const PERSPECTIVE_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/effects/perspective/IPerspectiveElementProps").IPerspectiveElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class PerspectiveComponent {
  /**
   * Signal input for the `duration` property.
   *
   * @public
   */
  readonly duration: InputSignal<PerspectiveElement['duration'] | undefined>;
  /**
   * Signal input for the `factor` property.
   *
   * @public
   */
  readonly factor: InputSignal<PerspectiveElement['factor'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<PerspectiveElement['themeName'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<PerspectiveElement['disabled'] | undefined>;
  /**
   * Signal input for the `for` property.
   *
   * @public
   */
  readonly for: InputSignal<PerspectiveElement['for'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<PerspectiveElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<PerspectiveElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<PerspectiveElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<PerspectiveElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<PerspectiveElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Calls `attach` on the `mosaik-perspective` element.
   *
   * @public
   * @param args - The arguments of `attach`:
   * - `control` - The control or id to attach.
   */
  attach(...args: Parameters<PerspectiveElement['attach']>): ReturnType<PerspectiveElement['attach']>;
  /**
   * Calls `detach` on the `mosaik-perspective` element.
   *
   * @public
   */
  detach(...args: Parameters<PerspectiveElement['detach']>): ReturnType<PerspectiveElement['detach']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `attach()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * The other names it accepts are not public in the type declarations of `PerspectiveElement`.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends PerspectiveMethodNames>(method: TMethod, ...args: Parameters<PerspectiveComponentMethods[TMethod]>): ReturnType<PerspectiveComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof PerspectiveElement>(property: TProperty, value: PerspectiveElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<PerspectiveElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<PerspectiveComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<PerspectiveComponent, "mosaik-perspective", never, {
    "duration": {
      "alias": "duration";
      "required": false;
      "isSignal": true;
    };
    "factor": {
      "alias": "factor";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "for": {
      "alias": "for";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on PerspectiveComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type PerspectiveMethodNames = 'onApplyTemplate' | 'attach' | 'detach';
/**
 * Declares the methods interface for PerspectiveComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type PerspectiveComponentMethods = MethodMap<PerspectiveMethodNames>;
/**
 * @public
 */
export declare function providePerspectiveComponent(config?: Partial<PerspectiveElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-perspective.d.ts.map