import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { DrawerActionsElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/overlays/drawer/DrawerActionsElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { DrawerContainerElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/overlays/drawer/DrawerContainerElement";
import { DrawerContentElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/overlays/drawer/DrawerContentElement";
import { DrawerFooterElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/overlays/drawer/DrawerFooterElement";
import { DrawerHeaderSubTextElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/overlays/drawer/DrawerHeaderSubTextElement";
import { DrawerHeaderTextElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/overlays/drawer/DrawerHeaderTextElement";
import { DrawerHeaderElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/overlays/drawer/DrawerHeaderElement";
import { DrawerRailElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/overlays/drawer/DrawerRailElement";
import { DrawerElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/overlays/drawer/DrawerElement";
/**
 * @public
 *
 * Injection token for the default properties of the DrawerActionsComponent.
 * Use this token to provide default properties for the DrawerActionsComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const DRAWER_ACTIONS_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/overlays/drawer/IDrawerActionsElementProps").IDrawerActionsElementProps>>;
/**
 * @public
 *
 * @slot  - The default content slot for action buttons.
 * @slot prefix - The prefix slot.
 * @slot suffix - The suffix slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class DrawerActionsComponent {
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<DrawerActionsElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<DrawerActionsElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<DrawerActionsElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<DrawerActionsElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<DrawerActionsElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<DrawerActionsElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: DrawerActionsElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: DrawerActionsElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<DrawerActionsElement['assignToSlot']>): ReturnType<DrawerActionsElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<DrawerActionsElement['getSlotContent']>): ReturnType<DrawerActionsElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<DrawerActionsElement['hasSlotContent']>): ReturnType<DrawerActionsElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<DrawerActionsElement['hasSlot']>): ReturnType<DrawerActionsElement['hasSlot']>;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<DrawerActionsElement['onSlotChanges']>): ReturnType<DrawerActionsElement['onSlotChanges']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `assignToSlot()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends DrawerActionsMethodNames>(method: TMethod, ...args: Parameters<DrawerActionsComponentMethods[TMethod]>): ReturnType<DrawerActionsComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof DrawerActionsElement>(property: TProperty, value: DrawerActionsElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<DrawerActionsElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<DrawerActionsComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<DrawerActionsComponent, "mosaik-drawer-actions", never, {
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on DrawerActionsComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type DrawerActionsMethodNames = 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges';
/**
 * Declares the methods interface for DrawerActionsComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type DrawerActionsComponentMethods = MethodMap<DrawerActionsMethodNames>;
/**
 * @public
 */
export declare function provideDrawerActionsComponent(config?: Partial<DrawerActionsElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the DrawerContainerComponent.
 * Use this token to provide default properties for the DrawerContainerComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const DRAWER_CONTAINER_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/overlays/drawer/IDrawerContainerElementProps").IDrawerContainerElementProps>>;
/**
 * @public
 *
 * @slot content - The content element.
 * @slot drawer - The drawer element.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class DrawerContainerComponent {
  /**
   * Signal input for the `autoSize` property.
   *
   * @public
   */
  readonly autoSize: InputSignal<DrawerContainerElement['autoSize'] | undefined>;
  /**
   * Signal input for the `hasBackdrop` property.
   *
   * @public
   */
  readonly hasBackdrop: InputSignal<DrawerContainerElement['hasBackdrop'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<DrawerContainerElement['themeName'] | undefined>;
  /**
   * Signal input for the `fit` property.
   *
   * @public
   */
  readonly fit: InputSignal<DrawerContainerElement['fit'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<DrawerContainerElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<DrawerContainerElement['lang'] | undefined>;
  /**
   * Output signal for the `contentMarginChanged` event.
   *
   * @public
   */
  readonly contentMarginChanged: OutputEmitterRef<ElementEventDetail<DrawerContainerElement, 'contentMarginChanged'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<DrawerContainerElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<DrawerContainerElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<DrawerContainerElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Calls `open` on the `mosaik-drawer-container` element.
   *
   * @public
   */
  open(...args: Parameters<DrawerContainerElement['open']>): ReturnType<DrawerContainerElement['open']>;
  /**
   * Calls `close` on the `mosaik-drawer-container` element.
   *
   * @public
   */
  close(...args: Parameters<DrawerContainerElement['close']>): ReturnType<DrawerContainerElement['close']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `open()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends DrawerContainerMethodNames>(method: TMethod, ...args: Parameters<DrawerContainerComponentMethods[TMethod]>): ReturnType<DrawerContainerComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof DrawerContainerElement>(property: TProperty, value: DrawerContainerElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<DrawerContainerElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<DrawerContainerComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<DrawerContainerComponent, "mosaik-drawer-container", never, {
    "autoSize": {
      "alias": "autoSize";
      "required": false;
      "isSignal": true;
    };
    "hasBackdrop": {
      "alias": "hasBackdrop";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "fit": {
      "alias": "fit";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "contentMarginChanged": "contentMarginChanged";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on DrawerContainerComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type DrawerContainerMethodNames = 'open' | 'close';
/**
 * Declares the methods interface for DrawerContainerComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type DrawerContainerComponentMethods = MethodMap<DrawerContainerMethodNames>;
/**
 * @public
 */
export declare function provideDrawerContainerComponent(config?: Partial<DrawerContainerElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the DrawerContentComponent.
 * Use this token to provide default properties for the DrawerContentComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const DRAWER_CONTENT_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/overlays/drawer/IDrawerContentElementProps").IDrawerContentElementProps>>;
/**
 * @public
 *
 * @slot  - The default content element.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class DrawerContentComponent {
  /**
   * Signal input for the `isOpen` property.
   *
   * @public
   */
  readonly isOpen: InputSignal<DrawerContentElement['isOpen'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<DrawerContentElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<DrawerContentElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<DrawerContentElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<DrawerContentElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<DrawerContentElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<DrawerContentElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof DrawerContentElement>(property: TProperty, value: DrawerContentElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<DrawerContentElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<DrawerContentComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<DrawerContentComponent, "mosaik-drawer-content", never, {
    "isOpen": {
      "alias": "isOpen";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on DrawerContentComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type DrawerContentMethodNames = never;
/**
 * Declares the methods interface for DrawerContentComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type DrawerContentComponentMethods = MethodMap<DrawerContentMethodNames>;
/**
 * @public
 */
export declare function provideDrawerContentComponent(config?: Partial<DrawerContentElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the DrawerFooterComponent.
 * Use this token to provide default properties for the DrawerFooterComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const DRAWER_FOOTER_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/overlays/drawer/IDrawerFooterElementProps").IDrawerFooterElementProps>>;
/**
 * @public
 *
 * @slot  - The default content slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class DrawerFooterComponent {
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<DrawerFooterElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<DrawerFooterElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<DrawerFooterElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<DrawerFooterElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<DrawerFooterElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<DrawerFooterElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: DrawerFooterElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: DrawerFooterElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<DrawerFooterElement['assignToSlot']>): ReturnType<DrawerFooterElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<DrawerFooterElement['getSlotContent']>): ReturnType<DrawerFooterElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<DrawerFooterElement['hasSlotContent']>): ReturnType<DrawerFooterElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<DrawerFooterElement['hasSlot']>): ReturnType<DrawerFooterElement['hasSlot']>;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<DrawerFooterElement['onSlotChanges']>): ReturnType<DrawerFooterElement['onSlotChanges']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `assignToSlot()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends DrawerFooterMethodNames>(method: TMethod, ...args: Parameters<DrawerFooterComponentMethods[TMethod]>): ReturnType<DrawerFooterComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof DrawerFooterElement>(property: TProperty, value: DrawerFooterElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<DrawerFooterElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<DrawerFooterComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<DrawerFooterComponent, "mosaik-drawer-footer", never, {
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on DrawerFooterComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type DrawerFooterMethodNames = 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges';
/**
 * Declares the methods interface for DrawerFooterComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type DrawerFooterComponentMethods = MethodMap<DrawerFooterMethodNames>;
/**
 * @public
 */
export declare function provideDrawerFooterComponent(config?: Partial<DrawerFooterElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the DrawerHeaderSubTextComponent.
 * Use this token to provide default properties for the DrawerHeaderSubTextComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const DRAWER_HEADER_SUB_TEXT_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/overlays/drawer/IDrawerHeaderSubTextElementProps").IDrawerHeaderSubTextElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class DrawerHeaderSubTextComponent {
  /**
   * Signal input for the `text` property.
   *
   * @public
   */
  readonly text: InputSignal<DrawerHeaderSubTextElement['text'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<DrawerHeaderSubTextElement['themeName'] | undefined>;
  /**
   * Signal input for the `formatter` property.
   *
   * @public
   */
  readonly formatter: InputSignal<DrawerHeaderSubTextElement['formatter'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<DrawerHeaderSubTextElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<DrawerHeaderSubTextElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<DrawerHeaderSubTextElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<DrawerHeaderSubTextElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<DrawerHeaderSubTextElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof DrawerHeaderSubTextElement>(property: TProperty, value: DrawerHeaderSubTextElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<DrawerHeaderSubTextElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<DrawerHeaderSubTextComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<DrawerHeaderSubTextComponent, "mosaik-drawer-header-sub-text", never, {
    "text": {
      "alias": "text";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "formatter": {
      "alias": "formatter";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on DrawerHeaderSubTextComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type DrawerHeaderSubTextMethodNames = never;
/**
 * Declares the methods interface for DrawerHeaderSubTextComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type DrawerHeaderSubTextComponentMethods = MethodMap<DrawerHeaderSubTextMethodNames>;
/**
 * @public
 */
export declare function provideDrawerHeaderSubTextComponent(config?: Partial<DrawerHeaderSubTextElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the DrawerHeaderTextComponent.
 * Use this token to provide default properties for the DrawerHeaderTextComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const DRAWER_HEADER_TEXT_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/overlays/drawer/IDrawerHeaderTextElementProps").IDrawerHeaderTextElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class DrawerHeaderTextComponent {
  /**
   * Signal input for the `text` property.
   *
   * @public
   */
  readonly text: InputSignal<DrawerHeaderTextElement['text'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<DrawerHeaderTextElement['themeName'] | undefined>;
  /**
   * Signal input for the `formatter` property.
   *
   * @public
   */
  readonly formatter: InputSignal<DrawerHeaderTextElement['formatter'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<DrawerHeaderTextElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<DrawerHeaderTextElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<DrawerHeaderTextElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<DrawerHeaderTextElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<DrawerHeaderTextElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof DrawerHeaderTextElement>(property: TProperty, value: DrawerHeaderTextElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<DrawerHeaderTextElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<DrawerHeaderTextComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<DrawerHeaderTextComponent, "mosaik-drawer-header-text", never, {
    "text": {
      "alias": "text";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "formatter": {
      "alias": "formatter";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on DrawerHeaderTextComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type DrawerHeaderTextMethodNames = never;
/**
 * Declares the methods interface for DrawerHeaderTextComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type DrawerHeaderTextComponentMethods = MethodMap<DrawerHeaderTextMethodNames>;
/**
 * @public
 */
export declare function provideDrawerHeaderTextComponent(config?: Partial<DrawerHeaderTextElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the DrawerHeaderComponent.
 * Use this token to provide default properties for the DrawerHeaderComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const DRAWER_HEADER_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/overlays/drawer/IDrawerHeaderElementProps").IDrawerHeaderElementProps>>;
/**
 * @public
 *
 * @slot header - The header slot.
 * @slot prefix - The prefix slot.
 * @slot subHeader - The subHeader slot.
 * @slot suffix - The suffix slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class DrawerHeaderComponent {
  /**
   * Signal input for the `text` property.
   *
   * @public
   */
  readonly text: InputSignal<DrawerHeaderElement['text'] | undefined>;
  /**
   * Signal input for the `subText` property.
   *
   * @public
   */
  readonly subText: InputSignal<DrawerHeaderElement['subText'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<DrawerHeaderElement['themeName'] | undefined>;
  /**
   * Signal input for the `formatter` property.
   *
   * @public
   */
  readonly formatter: InputSignal<DrawerHeaderElement['formatter'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<DrawerHeaderElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<DrawerHeaderElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<DrawerHeaderElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<DrawerHeaderElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<DrawerHeaderElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: DrawerHeaderElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: DrawerHeaderElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * A method that will be called when the element template is applied.
   * In this method are the element children available.
   *
   * @public
   */
  onApplyTemplate(...args: Parameters<DrawerHeaderElement['onApplyTemplate']>): ReturnType<DrawerHeaderElement['onApplyTemplate']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<DrawerHeaderElement['assignToSlot']>): ReturnType<DrawerHeaderElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<DrawerHeaderElement['getSlotContent']>): ReturnType<DrawerHeaderElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<DrawerHeaderElement['hasSlotContent']>): ReturnType<DrawerHeaderElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<DrawerHeaderElement['hasSlot']>): ReturnType<DrawerHeaderElement['hasSlot']>;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<DrawerHeaderElement['onSlotChanges']>): ReturnType<DrawerHeaderElement['onSlotChanges']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `onApplyTemplate()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends DrawerHeaderMethodNames>(method: TMethod, ...args: Parameters<DrawerHeaderComponentMethods[TMethod]>): ReturnType<DrawerHeaderComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof DrawerHeaderElement>(property: TProperty, value: DrawerHeaderElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<DrawerHeaderElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<DrawerHeaderComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<DrawerHeaderComponent, "mosaik-drawer-header", never, {
    "text": {
      "alias": "text";
      "required": false;
      "isSignal": true;
    };
    "subText": {
      "alias": "subText";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "formatter": {
      "alias": "formatter";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on DrawerHeaderComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type DrawerHeaderMethodNames = 'onApplyTemplate' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges';
/**
 * Declares the methods interface for DrawerHeaderComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type DrawerHeaderComponentMethods = MethodMap<DrawerHeaderMethodNames>;
/**
 * @public
 */
export declare function provideDrawerHeaderComponent(config?: Partial<DrawerHeaderElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the DrawerRailComponent.
 * Use this token to provide default properties for the DrawerRailComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const DRAWER_RAIL_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/overlays/drawer/IDrawerRailElementProps").IDrawerRailElementProps>>;
/**
 * @public
 *
 * @slot  - The contextual rail content.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class DrawerRailComponent {
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<DrawerRailElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<DrawerRailElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<DrawerRailElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<DrawerRailElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<DrawerRailElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<DrawerRailElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: DrawerRailElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: DrawerRailElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<DrawerRailElement['assignToSlot']>): ReturnType<DrawerRailElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<DrawerRailElement['getSlotContent']>): ReturnType<DrawerRailElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<DrawerRailElement['hasSlotContent']>): ReturnType<DrawerRailElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<DrawerRailElement['hasSlot']>): ReturnType<DrawerRailElement['hasSlot']>;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<DrawerRailElement['onSlotChanges']>): ReturnType<DrawerRailElement['onSlotChanges']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `assignToSlot()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends DrawerRailMethodNames>(method: TMethod, ...args: Parameters<DrawerRailComponentMethods[TMethod]>): ReturnType<DrawerRailComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof DrawerRailElement>(property: TProperty, value: DrawerRailElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<DrawerRailElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<DrawerRailComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<DrawerRailComponent, "mosaik-drawer-rail", never, {
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on DrawerRailComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type DrawerRailMethodNames = 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges';
/**
 * Declares the methods interface for DrawerRailComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type DrawerRailComponentMethods = MethodMap<DrawerRailMethodNames>;
/**
 * @public
 */
export declare function provideDrawerRailComponent(config?: Partial<DrawerRailElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the DrawerComponent.
 * Use this token to provide default properties for the DrawerComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const DRAWER_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/overlays/drawer/IDrawerElementProps").IDrawerElementProps>>;
/**
 * @public
 *
 * @slot  - The default content slot.
 * @slot actions - The actions content slot.
 * @slot footer - The footer content slot.
 * @slot header - The header content slot.
 * @slot rail - The rail content slot displayed beside the primary drawer sections.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class DrawerComponent {
  /**
   * Signal input for the `isFullScreen` property.
   *
   * @public
   */
  readonly isFullScreen: InputSignal<DrawerElement['isFullScreen'] | undefined>;
  /**
   * Signal input for the `header` property.
   *
   * @public
   */
  readonly header: InputSignal<DrawerElement['header'] | undefined>;
  /**
   * Signal input for the `subHeader` property.
   *
   * @public
   */
  readonly subHeader: InputSignal<DrawerElement['subHeader'] | undefined>;
  /**
   * Signal input for the `position` property.
   *
   * @public
   */
  readonly position: InputSignal<DrawerElement['position'] | undefined>;
  /**
   * Signal input for the `mode` property.
   *
   * @public
   */
  readonly mode: InputSignal<DrawerElement['mode'] | undefined>;
  /**
   * Signal input for the `hasShadow` property.
   *
   * @public
   */
  readonly hasShadow: InputSignal<DrawerElement['hasShadow'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<DrawerElement['themeName'] | undefined>;
  /**
   * Signal input for the `enter` property.
   *
   * @public
   */
  readonly enter: InputSignal<DrawerElement['enter'] | undefined>;
  /**
   * Signal input for the `exit` property.
   *
   * @public
   */
  readonly exit: InputSignal<DrawerElement['exit'] | undefined>;
  /**
   * Signal input for the `width` property.
   *
   * @public
   */
  readonly width: InputSignal<DrawerElement['width'] | undefined>;
  /**
   * Signal input for the `height` property.
   *
   * @public
   */
  readonly height: InputSignal<DrawerElement['height'] | undefined>;
  /**
   * Signal input for the `elevation` property.
   *
   * @public
   */
  readonly elevation: InputSignal<DrawerElement['elevation'] | undefined>;
  /**
   * Signal input for the `isOpen` property.
   *
   * @public
   */
  readonly isOpen: InputSignal<DrawerElement['isOpen'] | undefined>;
  /**
   * Signal input for the `hasBackdrop` property.
   *
   * @public
   */
  readonly hasBackdrop: InputSignal<DrawerElement['hasBackdrop'] | undefined>;
  /**
   * Signal input for the `pressEscapeToClose` property.
   *
   * @public
   */
  readonly pressEscapeToClose: InputSignal<DrawerElement['pressEscapeToClose'] | undefined>;
  /**
   * Signal input for the `clickOutsideToClose` property.
   *
   * @public
   */
  readonly clickOutsideToClose: InputSignal<DrawerElement['clickOutsideToClose'] | undefined>;
  /**
   * Signal input for the `attention` property.
   *
   * @public
   */
  readonly attention: InputSignal<DrawerElement['attention'] | undefined>;
  /**
   * Signal input for the `closeable` property.
   *
   * @public
   */
  readonly closeable: InputSignal<DrawerElement['closeable'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<DrawerElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<DrawerElement['lang'] | undefined>;
  /**
   * Output signal for the `closed` event.
   *
   * @public
   */
  readonly closed: OutputEmitterRef<ElementEventDetail<DrawerElement, 'closed'>>;
  /**
   * Output signal for the `opened` event.
   *
   * @public
   */
  readonly opened: OutputEmitterRef<ElementEventDetail<DrawerElement, 'opened'>>;
  /**
   * Output signal for the `closeAttempted` event.
   *
   * @public
   */
  readonly closeAttempted: OutputEmitterRef<ElementEventDetail<DrawerElement, 'closeAttempted'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<DrawerElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<DrawerElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<DrawerElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: DrawerElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: DrawerElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Opens the drawer.
   *
   * @public
   */
  open(...args: Parameters<DrawerElement['open']>): ReturnType<DrawerElement['open']>;
  /**
   * Closes the drawer.
   *
   * @public
   */
  close(...args: Parameters<DrawerElement['close']>): ReturnType<DrawerElement['close']>;
  /**
   * Toggles the drawer between open and closed states.
   *
   * @public
   */
  toggle(...args: Parameters<DrawerElement['toggle']>): ReturnType<DrawerElement['toggle']>;
  /**
   * Returns the inner offset width of the drawer.
   *
   * @public
   */
  innerOffsetWidth(...args: Parameters<DrawerElement['innerOffsetWidth']>): ReturnType<DrawerElement['innerOffsetWidth']>;
  /**
   * Executes the animation.
   *
   * @public
   */
  play(...args: Parameters<DrawerElement['play']>): ReturnType<DrawerElement['play']>;
  /**
   * A lifecycle hook that is invoked when the element is added to the DOM.
   *
   * @public
   */
  onEnterAnimation(...args: Parameters<NonNullable<DrawerElement['onEnterAnimation']>>): ReturnType<NonNullable<DrawerElement['onEnterAnimation']>> | undefined;
  /**
   * A lifecycle hook that is invoked when the element is removed from the DOM.
   *
   * @public
   */
  onExitAnimation(...args: Parameters<NonNullable<DrawerElement['onExitAnimation']>>): ReturnType<NonNullable<DrawerElement['onExitAnimation']>> | undefined;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<DrawerElement['assignToSlot']>): ReturnType<DrawerElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<DrawerElement['getSlotContent']>): ReturnType<DrawerElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<DrawerElement['hasSlotContent']>): ReturnType<DrawerElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<DrawerElement['hasSlot']>): ReturnType<DrawerElement['hasSlot']>;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<DrawerElement['onSlotChanges']>): ReturnType<DrawerElement['onSlotChanges']>;
  /**
   * Requests visual attention for this overlay.
   *
   * @public
   * @param args - The arguments of `requestAttention`:
   * - `animation` - Optional animation used for this attention request.
   * @returns Whether the attention animation finished.
   */
  requestAttention(...args: Parameters<DrawerElement['requestAttention']>): ReturnType<DrawerElement['requestAttention']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `open()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends DrawerMethodNames>(method: TMethod, ...args: Parameters<DrawerComponentMethods[TMethod]>): ReturnType<DrawerComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof DrawerElement>(property: TProperty, value: DrawerElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<DrawerElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<DrawerComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<DrawerComponent, "mosaik-drawer", never, {
    "isFullScreen": {
      "alias": "isFullScreen";
      "required": false;
      "isSignal": true;
    };
    "header": {
      "alias": "header";
      "required": false;
      "isSignal": true;
    };
    "subHeader": {
      "alias": "subHeader";
      "required": false;
      "isSignal": true;
    };
    "position": {
      "alias": "position";
      "required": false;
      "isSignal": true;
    };
    "mode": {
      "alias": "mode";
      "required": false;
      "isSignal": true;
    };
    "hasShadow": {
      "alias": "hasShadow";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "enter": {
      "alias": "enter";
      "required": false;
      "isSignal": true;
    };
    "exit": {
      "alias": "exit";
      "required": false;
      "isSignal": true;
    };
    "width": {
      "alias": "width";
      "required": false;
      "isSignal": true;
    };
    "height": {
      "alias": "height";
      "required": false;
      "isSignal": true;
    };
    "elevation": {
      "alias": "elevation";
      "required": false;
      "isSignal": true;
    };
    "isOpen": {
      "alias": "isOpen";
      "required": false;
      "isSignal": true;
    };
    "hasBackdrop": {
      "alias": "hasBackdrop";
      "required": false;
      "isSignal": true;
    };
    "pressEscapeToClose": {
      "alias": "pressEscapeToClose";
      "required": false;
      "isSignal": true;
    };
    "clickOutsideToClose": {
      "alias": "clickOutsideToClose";
      "required": false;
      "isSignal": true;
    };
    "attention": {
      "alias": "attention";
      "required": false;
      "isSignal": true;
    };
    "closeable": {
      "alias": "closeable";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "closed": "closed";
    "opened": "opened";
    "closeAttempted": "closeAttempted";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on DrawerComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type DrawerMethodNames = 'open' | 'close' | 'toggle' | 'innerOffsetWidth' | 'play' | 'onEnterAnimation' | 'onExitAnimation' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges' | 'requestAttention';
/**
 * Declares the methods interface for DrawerComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type DrawerComponentMethods = MethodMap<DrawerMethodNames>;
/**
 * @public
 */
export declare function provideDrawerComponent(config?: Partial<DrawerElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-drawer.d.ts.map