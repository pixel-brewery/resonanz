import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { ColorSliderElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/color-slider/ColorSliderElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the ColorSliderComponent.
 * Use this token to provide default properties for the ColorSliderComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const COLOR_SLIDER_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/media/color-slider/IColorSliderElementProps").IColorSliderElementProps>>;
/**
 * @public
 *
 * @slot gradient - Additional content layered over the hue track.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ColorSliderComponent {
  /**
   * Signal input for the `step` property.
   *
   * @public
   */
  readonly step: InputSignal<ColorSliderElement['step'] | undefined>;
  /**
   * Signal input for the `color` property.
   *
   * @public
   */
  readonly color: InputSignal<ColorSliderElement['color'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ColorSliderElement['themeName'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<ColorSliderElement['disabled'] | undefined>;
  /**
   * Signal input for the `orientation` property.
   *
   * @public
   */
  readonly orientation: InputSignal<ColorSliderElement['orientation'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<ColorSliderElement['value'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ColorSliderElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ColorSliderElement['lang'] | undefined>;
  /**
   * Output signal for the `input` event.
   *
   * @public
   */
  readonly input: OutputEmitterRef<ElementEventDetail<ColorSliderElement, 'input'>>;
  /**
   * Output signal for the `change` event.
   *
   * @public
   */
  readonly change: OutputEmitterRef<ElementEventDetail<ColorSliderElement, 'change'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ColorSliderElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ColorSliderElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ColorSliderElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ColorSliderElement>(property: TProperty, value: ColorSliderElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ColorSliderElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ColorSliderComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ColorSliderComponent, "mosaik-color-slider", never, {
    "step": {
      "alias": "step";
      "required": false;
      "isSignal": true;
    };
    "color": {
      "alias": "color";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "orientation": {
      "alias": "orientation";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "input": "input";
    "change": "change";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on ColorSliderComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ColorSliderMethodNames = never;
/**
 * Declares the methods interface for ColorSliderComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ColorSliderComponentMethods = MethodMap<ColorSliderMethodNames>;
/**
 * @public
 */
export declare function provideColorSliderComponent(config?: Partial<ColorSliderElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-color-slider.d.ts.map