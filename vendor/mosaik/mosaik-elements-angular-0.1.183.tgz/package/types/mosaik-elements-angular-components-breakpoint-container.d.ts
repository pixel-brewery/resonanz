import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { BreakpointContainerElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/breakpoint-container/BreakpointContainerElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the BreakpointContainerComponent.
 * Use this token to provide default properties for the BreakpointContainerComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const BREAKPOINT_CONTAINER_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/layouts/breakpoint-container/IBreakpointContainerElementProps").IBreakpointContainerElementProps>>;
/**
 * @public
 *
 * @slot  - The content that follows the width of the container instead of the window.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class BreakpointContainerComponent {
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<BreakpointContainerElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<BreakpointContainerElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<BreakpointContainerElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<BreakpointContainerElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<BreakpointContainerElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<BreakpointContainerElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof BreakpointContainerElement>(property: TProperty, value: BreakpointContainerElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<BreakpointContainerElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<BreakpointContainerComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<BreakpointContainerComponent, "mosaik-breakpoint-container", never, {
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on BreakpointContainerComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type BreakpointContainerMethodNames = never;
/**
 * Declares the methods interface for BreakpointContainerComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type BreakpointContainerComponentMethods = MethodMap<BreakpointContainerMethodNames>;
/**
 * @public
 */
export declare function provideBreakpointContainerComponent(config?: Partial<BreakpointContainerElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-breakpoint-container.d.ts.map