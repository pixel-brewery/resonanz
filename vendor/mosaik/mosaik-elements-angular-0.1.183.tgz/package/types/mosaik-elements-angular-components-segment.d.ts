import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { SegmentItemElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/segment/SegmentItemElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { SegmentElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/segment/SegmentElement";
/**
 * @public
 *
 * Injection token for the default properties of the SegmentItemComponent.
 * Use this token to provide default properties for the SegmentItemComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const SEGMENT_ITEM_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/selectors/segment/ISegmentItemElementProps").ISegmentItemElementProps>>;
/**
 * @public
 *
 * @slot icon - The icon displayed within the segment item
 * @slot label - The text label displayed within the segment item
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class SegmentItemComponent {
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<SegmentItemElement['themeName'] | undefined>;
  /**
   * Signal input for the `orientation` property.
   *
   * @public
   */
  readonly orientation: InputSignal<SegmentItemElement['orientation'] | undefined>;
  /**
   * Signal input for the `horizontalContentAlignment` property.
   *
   * @public
   */
  readonly horizontalContentAlignment: InputSignal<SegmentItemElement['horizontalContentAlignment'] | undefined>;
  /**
   * Signal input for the `verticalContentAlignment` property.
   *
   * @public
   */
  readonly verticalContentAlignment: InputSignal<SegmentItemElement['verticalContentAlignment'] | undefined>;
  /**
   * Signal input for the `fit` property.
   *
   * @public
   */
  readonly fit: InputSignal<SegmentItemElement['fit'] | undefined>;
  /**
   * Signal input for the `isChecked` property.
   *
   * @public
   */
  readonly isChecked: InputSignal<SegmentItemElement['isChecked'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<SegmentItemElement['label'] | undefined>;
  /**
   * Signal input for the `icon` property.
   *
   * @public
   */
  readonly icon: InputSignal<SegmentItemElement['icon'] | undefined>;
  /**
   * Signal input for the `iconPosition` property.
   *
   * @public
   */
  readonly iconPosition: InputSignal<SegmentItemElement['iconPosition'] | undefined>;
  /**
   * Signal input for the `iconSize` property.
   *
   * @public
   */
  readonly iconSize: InputSignal<SegmentItemElement['iconSize'] | undefined>;
  /**
   * Signal input for the `type` property.
   *
   * @public
   */
  readonly type: InputSignal<SegmentItemElement['type'] | undefined>;
  /**
   * Signal input for the `ripple` property.
   *
   * @public
   */
  readonly ripple: InputSignal<SegmentItemElement['ripple'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<SegmentItemElement['variant'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<SegmentItemElement['appearance'] | undefined>;
  /**
   * Signal input for the `size` property.
   *
   * @public
   */
  readonly size: InputSignal<SegmentItemElement['size'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<SegmentItemElement['value'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<SegmentItemElement['disabled'] | undefined>;
  /**
   * Signal input for the `isFocused` property.
   *
   * @public
   */
  readonly isFocused: InputSignal<SegmentItemElement['isFocused'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<SegmentItemElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<SegmentItemElement['lang'] | undefined>;
  /**
   * Output signal for the `toggled` event.
   *
   * @public
   */
  readonly toggled: OutputEmitterRef<ElementEventDetail<SegmentItemElement, 'toggled'>>;
  /**
   * Output signal for the `checked` event.
   *
   * @public
   */
  readonly checked: OutputEmitterRef<ElementEventDetail<SegmentItemElement, 'checked'>>;
  /**
   * Output signal for the `unchecked` event.
   *
   * @public
   */
  readonly unchecked: OutputEmitterRef<ElementEventDetail<SegmentItemElement, 'unchecked'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<SegmentItemElement, 'connected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<SegmentItemElement, 'changed'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<SegmentItemElement, 'disconnected'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Checks the element.
   *
   * @public
   */
  check(...args: Parameters<SegmentItemElement['check']>): ReturnType<SegmentItemElement['check']>;
  /**
   * Unchecks the element.
   *
   * @public
   */
  uncheck(...args: Parameters<SegmentItemElement['uncheck']>): ReturnType<SegmentItemElement['uncheck']>;
  /**
   * Calls `toggle` on the `mosaik-segment-item` element.
   *
   * @public
   */
  toggle(...args: Parameters<SegmentItemElement['toggle']>): ReturnType<SegmentItemElement['toggle']>;
  /**
   * Forwards the standard focus API to this button's native interactive control.
   * Disabled and not-yet-rendered controls keep the current focus unchanged.
   *
   * @public
   * @param args - The arguments of `focus`:
   * - `options` - Standard browser focus options.
   */
  focus(...args: Parameters<SegmentItemElement['focus']>): ReturnType<SegmentItemElement['focus']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `check()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends SegmentItemMethodNames>(method: TMethod, ...args: Parameters<SegmentItemComponentMethods[TMethod]>): ReturnType<SegmentItemComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof SegmentItemElement>(property: TProperty, value: SegmentItemElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<SegmentItemElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SegmentItemComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SegmentItemComponent, "mosaik-segment-item", never, {
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "orientation": {
      "alias": "orientation";
      "required": false;
      "isSignal": true;
    };
    "horizontalContentAlignment": {
      "alias": "horizontalContentAlignment";
      "required": false;
      "isSignal": true;
    };
    "verticalContentAlignment": {
      "alias": "verticalContentAlignment";
      "required": false;
      "isSignal": true;
    };
    "fit": {
      "alias": "fit";
      "required": false;
      "isSignal": true;
    };
    "isChecked": {
      "alias": "isChecked";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "icon": {
      "alias": "icon";
      "required": false;
      "isSignal": true;
    };
    "iconPosition": {
      "alias": "iconPosition";
      "required": false;
      "isSignal": true;
    };
    "iconSize": {
      "alias": "iconSize";
      "required": false;
      "isSignal": true;
    };
    "type": {
      "alias": "type";
      "required": false;
      "isSignal": true;
    };
    "ripple": {
      "alias": "ripple";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "isFocused": {
      "alias": "isFocused";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "toggled": "toggled";
    "checked": "checked";
    "unchecked": "unchecked";
    "connected": "connected";
    "changed": "changed";
    "disconnected": "disconnected";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on SegmentItemComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SegmentItemMethodNames = 'check' | 'uncheck' | 'toggle' | 'focus';
/**
 * Declares the methods interface for SegmentItemComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SegmentItemComponentMethods = MethodMap<SegmentItemMethodNames>;
/**
 * @public
 */
export declare function provideSegmentItemComponent(config?: Partial<SegmentItemElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the SegmentComponent.
 * Use this token to provide default properties for the SegmentComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const SEGMENT_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/selectors/segment/ISegmentElementProps").ISegmentElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot for segment items (mosaik-segment-item elements)
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class SegmentComponent {
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<SegmentElement['themeName'] | undefined>;
  /**
   * Signal input for the `size` property.
   *
   * @public
   */
  readonly size: InputSignal<SegmentElement['size'] | undefined>;
  /**
   * Signal input for the `showScrollButtons` property.
   *
   * @public
   */
  readonly showScrollButtons: InputSignal<SegmentElement['showScrollButtons'] | undefined>;
  /**
   * Signal input for the `showScrollbar` property.
   *
   * @public
   */
  readonly showScrollbar: InputSignal<SegmentElement['showScrollbar'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<SegmentElement['disabled'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<SegmentElement['variant'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<SegmentElement['appearance'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<SegmentElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<SegmentElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<SegmentElement, 'connected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<SegmentElement, 'changed'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<SegmentElement, 'disconnected'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: SegmentElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: SegmentElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Returns the scrollable viewport of the segment, which is owned by the
   * internal scroll primitive rather than by the segment element itself.
   *
   * @public
   */
  getScrollableElement(...args: Parameters<SegmentElement['getScrollableElement']>): ReturnType<SegmentElement['getScrollableElement']>;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<SegmentElement['onSlotChanges']>): ReturnType<SegmentElement['onSlotChanges']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<SegmentElement['assignToSlot']>): ReturnType<SegmentElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<SegmentElement['getSlotContent']>): ReturnType<SegmentElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<SegmentElement['hasSlotContent']>): ReturnType<SegmentElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<SegmentElement['hasSlot']>): ReturnType<SegmentElement['hasSlot']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `getScrollableElement()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends SegmentMethodNames>(method: TMethod, ...args: Parameters<SegmentComponentMethods[TMethod]>): ReturnType<SegmentComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof SegmentElement>(property: TProperty, value: SegmentElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<SegmentElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SegmentComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SegmentComponent, "mosaik-segment", never, {
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "showScrollButtons": {
      "alias": "showScrollButtons";
      "required": false;
      "isSignal": true;
    };
    "showScrollbar": {
      "alias": "showScrollbar";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "changed": "changed";
    "disconnected": "disconnected";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on SegmentComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SegmentMethodNames = 'getScrollableElement' | 'onSlotChanges' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot';
/**
 * Declares the methods interface for SegmentComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SegmentComponentMethods = MethodMap<SegmentMethodNames>;
/**
 * @public
 */
export declare function provideSegmentComponent(config?: Partial<SegmentElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-segment.d.ts.map