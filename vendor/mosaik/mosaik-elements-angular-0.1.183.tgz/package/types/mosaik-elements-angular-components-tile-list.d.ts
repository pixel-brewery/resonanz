import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { TileListItemElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/tile-list/TileListItemElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { TileListElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/tile-list/TileListElement";
/**
 * @public
 *
 * Injection token for the default properties of the TileListItemComponent.
 * Use this token to provide default properties for the TileListItemComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const TILE_LIST_ITEM_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/layouts/tile-list/ITileListItemElementProps").ITileListItemElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class TileListItemComponent {
  /**
   * Signal input for the `col` property.
   *
   * @public
   */
  readonly col: InputSignal<TileListItemElement['col'] | undefined>;
  /**
   * Signal input for the `colSpan` property.
   *
   * @public
   */
  readonly colSpan: InputSignal<TileListItemElement['colSpan'] | undefined>;
  /**
   * Signal input for the `order` property.
   *
   * @public
   */
  readonly order: InputSignal<TileListItemElement['order'] | undefined>;
  /**
   * Signal input for the `reorderable` property.
   *
   * @public
   */
  readonly reorderable: InputSignal<TileListItemElement['reorderable'] | undefined>;
  /**
   * Signal input for the `resizable` property.
   *
   * @public
   */
  readonly resizable: InputSignal<TileListItemElement['resizable'] | undefined>;
  /**
   * Signal input for the `row` property.
   *
   * @public
   */
  readonly row: InputSignal<TileListItemElement['row'] | undefined>;
  /**
   * Signal input for the `rowSpan` property.
   *
   * @public
   */
  readonly rowSpan: InputSignal<TileListItemElement['rowSpan'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<TileListItemElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<TileListItemElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<TileListItemElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<TileListItemElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<TileListItemElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<TileListItemElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof TileListItemElement>(property: TProperty, value: TileListItemElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<TileListItemElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<TileListItemComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<TileListItemComponent, "mosaik-tile-list-item", never, {
    "col": {
      "alias": "col";
      "required": false;
      "isSignal": true;
    };
    "colSpan": {
      "alias": "colSpan";
      "required": false;
      "isSignal": true;
    };
    "order": {
      "alias": "order";
      "required": false;
      "isSignal": true;
    };
    "reorderable": {
      "alias": "reorderable";
      "required": false;
      "isSignal": true;
    };
    "resizable": {
      "alias": "resizable";
      "required": false;
      "isSignal": true;
    };
    "row": {
      "alias": "row";
      "required": false;
      "isSignal": true;
    };
    "rowSpan": {
      "alias": "rowSpan";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on TileListItemComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TileListItemMethodNames = never;
/**
 * Declares the methods interface for TileListItemComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TileListItemComponentMethods = MethodMap<TileListItemMethodNames>;
/**
 * @public
 */
export declare function provideTileListItemComponent(config?: Partial<TileListItemElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the TileListComponent.
 * Use this token to provide default properties for the TileListComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const TILE_LIST_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/layouts/tile-list/ITileListElementProps").ITileListElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class TileListComponent {
  /**
   * Signal input for the `cols` property.
   *
   * @public
   */
  readonly cols: InputSignal<TileListElement['cols'] | undefined>;
  /**
   * Signal input for the `rowHeight` property.
   *
   * @public
   */
  readonly rowHeight: InputSignal<TileListElement['rowHeight'] | undefined>;
  /**
   * Signal input for the `gutterSize` property.
   *
   * @public
   */
  readonly gutterSize: InputSignal<TileListElement['gutterSize'] | undefined>;
  /**
   * Signal input for the `autoFlow` property.
   *
   * @public
   */
  readonly autoFlow: InputSignal<TileListElement['autoFlow'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<TileListElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<TileListElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<TileListElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<TileListElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<TileListElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<TileListElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof TileListElement>(property: TProperty, value: TileListElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<TileListElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<TileListComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<TileListComponent, "mosaik-tile-list", never, {
    "cols": {
      "alias": "cols";
      "required": false;
      "isSignal": true;
    };
    "rowHeight": {
      "alias": "rowHeight";
      "required": false;
      "isSignal": true;
    };
    "gutterSize": {
      "alias": "gutterSize";
      "required": false;
      "isSignal": true;
    };
    "autoFlow": {
      "alias": "autoFlow";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on TileListComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TileListMethodNames = never;
/**
 * Declares the methods interface for TileListComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TileListComponentMethods = MethodMap<TileListMethodNames>;
/**
 * @public
 */
export declare function provideTileListComponent(config?: Partial<TileListElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-tile-list.d.ts.map