import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef, Type } from "@angular/core";
import { ControlValueAccessor } from "@angular/forms";
import { DateBoxElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/date-box/DateBoxElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import * as i1 from "@pixel-brewery/mosaik-elements-angular/runtime";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the DateBoxComponent.
 * Use this token to provide default properties for the DateBoxComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const DATE_BOX_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/inputs/date-box/IDateBoxElementProps").IDateBoxElementProps>>;
/**
 * @public
 *
 * Injection token for the intl configuration of the DateBoxComponent.
 * Provide a partial intl object or an injectable class that resolves translations.
 * This allows third-party applications to override the default intl labels
 * globally, per route, or per component via Angular's dependency injection.
 *
 * Merge order: Foundation defaults → DI intl → [intl] input binding.
 */
export declare const DATE_BOX_INTL: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").CalendarElementIntl>>;
/**
 * @public
 *
 * @slot prefix - Content placed before the input field.
 * @slot suffix - Content placed after the input field.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class DateBoxComponent implements ControlValueAccessor {
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<Partial<DateBoxElement['intl']> | undefined>;
  /**
   * Signal input for the `displayDate` property.
   *
   * @public
   */
  readonly displayDate: InputSignal<DateBoxElement['displayDate'] | undefined>;
  /**
   * Signal input for the `displayDateStart` property.
   *
   * @public
   */
  readonly displayDateStart: InputSignal<DateBoxElement['displayDateStart'] | undefined>;
  /**
   * Signal input for the `displayDateEnd` property.
   *
   * @public
   */
  readonly displayDateEnd: InputSignal<DateBoxElement['displayDateEnd'] | undefined>;
  /**
   * Signal input for the `values` property.
   *
   * @public
   */
  readonly values: InputSignal<DateBoxElement['values'] | undefined>;
  /**
   * Signal input for the `view` property.
   *
   * @public
   */
  readonly view: InputSignal<DateBoxElement['view'] | undefined>;
  /**
   * Signal input for the `allowedViews` property.
   *
   * @public
   */
  readonly allowedViews: InputSignal<DateBoxElement['allowedViews'] | undefined>;
  /**
   * Signal input for the `showNavigation` property.
   *
   * @public
   */
  readonly showNavigation: InputSignal<DateBoxElement['showNavigation'] | undefined>;
  /**
   * Signal input for the `selectionMode` property.
   *
   * @public
   */
  readonly selectionMode: InputSignal<DateBoxElement['selectionMode'] | undefined>;
  /**
   * Signal input for the `blackoutDates` property.
   *
   * @public
   */
  readonly blackoutDates: InputSignal<DateBoxElement['blackoutDates'] | undefined>;
  /**
   * Signal input for the `specialDates` property.
   *
   * @public
   */
  readonly specialDates: InputSignal<DateBoxElement['specialDates'] | undefined>;
  /**
   * Signal input for the `minDate` property.
   *
   * @public
   */
  readonly minDate: InputSignal<DateBoxElement['minDate'] | undefined>;
  /**
   * Signal input for the `maxDate` property.
   *
   * @public
   */
  readonly maxDate: InputSignal<DateBoxElement['maxDate'] | undefined>;
  /**
   * Signal input for the `firstDayOfWeek` property.
   *
   * @public
   */
  readonly firstDayOfWeek: InputSignal<DateBoxElement['firstDayOfWeek'] | undefined>;
  /**
   * Signal input for the `isTodayHighlighted` property.
   *
   * @public
   */
  readonly isTodayHighlighted: InputSignal<DateBoxElement['isTodayHighlighted'] | undefined>;
  /**
   * Signal input for the `isWeekendHighlighted` property.
   *
   * @public
   */
  readonly isWeekendHighlighted: InputSignal<DateBoxElement['isWeekendHighlighted'] | undefined>;
  /**
   * Signal input for the `showWeekNumbers` property.
   *
   * @public
   */
  readonly showWeekNumbers: InputSignal<DateBoxElement['showWeekNumbers'] | undefined>;
  /**
   * Signal input for the `markerHandler` property.
   *
   * @public
   */
  readonly markerHandler: InputSignal<DateBoxElement['markerHandler'] | undefined>;
  /**
   * Signal input for the `showAdjacent` property.
   *
   * @public
   */
  readonly showAdjacent: InputSignal<DateBoxElement['showAdjacent'] | undefined>;
  /**
   * Signal input for the `readonly` property.
   *
   * @public
   */
  readonly readonly: InputSignal<DateBoxElement['readonly'] | undefined>;
  /**
   * Signal input for the `required` property.
   *
   * @public
   */
  readonly required: InputSignal<DateBoxElement['required'] | undefined>;
  /**
   * Signal input for the `autofocus` property.
   *
   * @public
   */
  readonly autofocus: InputSignal<DateBoxElement['autofocus'] | undefined>;
  /**
   * Signal input for the `name` property.
   *
   * @public
   */
  readonly name: InputSignal<DateBoxElement['name'] | undefined>;
  /**
   * Signal input for the `placeholder` property.
   *
   * @public
   */
  readonly placeholder: InputSignal<DateBoxElement['placeholder'] | undefined>;
  /**
   * Signal input for the `autocomplete` property.
   *
   * @public
   */
  readonly autocomplete: InputSignal<DateBoxElement['autocomplete'] | undefined>;
  /**
   * Signal input for the `format` property.
   *
   * @public
   */
  readonly format: InputSignal<DateBoxElement['format'] | undefined>;
  /**
   * Signal input for the `textAlign` property.
   *
   * @public
   */
  readonly textAlign: InputSignal<DateBoxElement['textAlign'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<DateBoxElement['themeName'] | undefined>;
  /**
   * Signal input for the `size` property.
   *
   * @public
   */
  readonly size: InputSignal<DateBoxElement['size'] | undefined>;
  /**
   * Signal input for the `isClearable` property.
   *
   * @public
   */
  readonly isClearable: InputSignal<DateBoxElement['isClearable'] | undefined>;
  /**
   * Signal input for the `locale` property.
   *
   * @public
   */
  readonly locale: InputSignal<DateBoxElement['locale'] | undefined>;
  /**
   * Signal input for the `invalid` property.
   *
   * @public
   */
  readonly invalid: InputSignal<DateBoxElement['invalid'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<DateBoxElement['value'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<DateBoxElement['variant'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<DateBoxElement['appearance'] | undefined>;
  /**
   * Signal input for the `dropDownPlacement` property.
   *
   * @public
   */
  readonly dropDownPlacement: InputSignal<DateBoxElement['dropDownPlacement'] | undefined>;
  /**
   * Signal input for the `dropDownStrategy` property.
   *
   * @public
   */
  readonly dropDownStrategy: InputSignal<DateBoxElement['dropDownStrategy'] | undefined>;
  /**
   * Signal input for the `dropDownDistance` property.
   *
   * @public
   */
  readonly dropDownDistance: InputSignal<DateBoxElement['dropDownDistance'] | undefined>;
  /**
   * Signal input for the `dropDownSkidding` property.
   *
   * @public
   */
  readonly dropDownSkidding: InputSignal<DateBoxElement['dropDownSkidding'] | undefined>;
  /**
   * Signal input for the `dropDownStaysOpen` property.
   *
   * @public
   */
  readonly dropDownStaysOpen: InputSignal<DateBoxElement['dropDownStaysOpen'] | undefined>;
  /**
   * Signal input for the `dropDownMaxHeight` property.
   *
   * @public
   */
  readonly dropDownMaxHeight: InputSignal<DateBoxElement['dropDownMaxHeight'] | undefined>;
  /**
   * Signal input for the `dropDownHeight` property.
   *
   * @public
   */
  readonly dropDownHeight: InputSignal<DateBoxElement['dropDownHeight'] | undefined>;
  /**
   * Signal input for the `dropDownWidth` property.
   *
   * @public
   */
  readonly dropDownWidth: InputSignal<DateBoxElement['dropDownWidth'] | undefined>;
  /**
   * Signal input for the `dropDownMaxWidth` property.
   *
   * @public
   */
  readonly dropDownMaxWidth: InputSignal<DateBoxElement['dropDownMaxWidth'] | undefined>;
  /**
   * Signal input for the `isDropDownOpen` property.
   *
   * @public
   */
  readonly isDropDownOpen: InputSignal<DateBoxElement['isDropDownOpen'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<DateBoxElement['label'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<DateBoxElement['disabled'] | undefined>;
  /**
   * Signal input for the `formatter` property.
   *
   * @public
   */
  readonly formatter: InputSignal<DateBoxElement['formatter'] | undefined>;
  /**
   * Signal input for the `parser` property.
   *
   * @public
   */
  readonly parser: InputSignal<DateBoxElement['parser'] | undefined>;
  /**
   * Signal input for the `isFocused` property.
   *
   * @public
   */
  readonly isFocused: InputSignal<DateBoxElement['isFocused'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<DateBoxElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<DateBoxElement['lang'] | undefined>;
  /**
   * Output signal for the `cleared` event.
   *
   * @public
   */
  readonly cleared: OutputEmitterRef<ElementEventDetail<DateBoxElement, 'cleared'>>;
  /**
   * Output signal for the `change` event.
   *
   * @public
   */
  readonly change: OutputEmitterRef<ElementEventDetail<DateBoxElement, 'change'>>;
  /**
   * Output signal for the `input` event.
   *
   * @public
   */
  readonly input: OutputEmitterRef<ElementEventDetail<DateBoxElement, 'input'>>;
  /**
   * Output signal for the `focus` event.
   *
   * @public
   */
  readonly focus: OutputEmitterRef<ElementEventDetail<DateBoxElement, 'focus'>>;
  /**
   * Output signal for the `blur` event.
   *
   * @public
   */
  readonly blur: OutputEmitterRef<ElementEventDetail<DateBoxElement, 'blur'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<DateBoxElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<DateBoxElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<DateBoxElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: DateBoxElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: DateBoxElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  private readonly _accessor;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Applies a value supplied by Angular forms to the native control.
   *
   * @public
   */
  writeValue(obj: unknown): void;
  /**
   * Registers the callback notified when the native control value changes.
   *
   * @public
   */
  registerOnChange(fn: unknown): void;
  /**
   * Registers the callback notified when the native control is touched.
   *
   * @public
   */
  registerOnTouched(fn: unknown): void;
  /**
   * Applies the disabled state supplied by Angular forms.
   *
   * @public
   */
  setDisabledState?(isDisabled: boolean): void;
  /**
   * Clears the value of the element but not the validation.
   *
   * @public
   */
  clear(...args: Parameters<DateBoxElement['clear']>): ReturnType<DateBoxElement['clear']>;
  /**
   * Resets the value, all kinds of validation and errors.
   *
   * @public
   */
  reset(...args: Parameters<DateBoxElement['reset']>): ReturnType<DateBoxElement['reset']>;
  /**
   * Checks the validity of the element and returns `true` if it is valid; otherwise, `false`.
   *
   * @public
   */
  checkValidity(...args: Parameters<DateBoxElement['checkValidity']>): ReturnType<DateBoxElement['checkValidity']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<DateBoxElement['assignToSlot']>): ReturnType<DateBoxElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<DateBoxElement['getSlotContent']>): ReturnType<DateBoxElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<DateBoxElement['hasSlotContent']>): ReturnType<DateBoxElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<DateBoxElement['hasSlot']>): ReturnType<DateBoxElement['hasSlot']>;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<DateBoxElement['onSlotChanges']>): ReturnType<DateBoxElement['onSlotChanges']>;
  /**
   * Opens the drop down.
   *
   * @public
   */
  open(...args: Parameters<DateBoxElement['open']>): ReturnType<DateBoxElement['open']>;
  /**
   * Closes the drop down.
   *
   * @public
   */
  close(...args: Parameters<DateBoxElement['close']>): ReturnType<DateBoxElement['close']>;
  /**
   * Toggles the drop down.
   *
   * @public
   */
  toggle(...args: Parameters<DateBoxElement['toggle']>): ReturnType<DateBoxElement['toggle']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `clear()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * `focus`, `blur` share their name with another member of the component and are called on `elementRef.nativeElement` instead.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends DateBoxMethodNames>(method: TMethod, ...args: Parameters<DateBoxComponentMethods[TMethod]>): ReturnType<DateBoxComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof DateBoxElement>(property: TProperty, value: DateBoxElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<DateBoxElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<DateBoxComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<DateBoxComponent, "mosaik-datebox", never, {
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "displayDate": {
      "alias": "displayDate";
      "required": false;
      "isSignal": true;
    };
    "displayDateStart": {
      "alias": "displayDateStart";
      "required": false;
      "isSignal": true;
    };
    "displayDateEnd": {
      "alias": "displayDateEnd";
      "required": false;
      "isSignal": true;
    };
    "values": {
      "alias": "values";
      "required": false;
      "isSignal": true;
    };
    "view": {
      "alias": "view";
      "required": false;
      "isSignal": true;
    };
    "allowedViews": {
      "alias": "allowedViews";
      "required": false;
      "isSignal": true;
    };
    "showNavigation": {
      "alias": "showNavigation";
      "required": false;
      "isSignal": true;
    };
    "selectionMode": {
      "alias": "selectionMode";
      "required": false;
      "isSignal": true;
    };
    "blackoutDates": {
      "alias": "blackoutDates";
      "required": false;
      "isSignal": true;
    };
    "specialDates": {
      "alias": "specialDates";
      "required": false;
      "isSignal": true;
    };
    "minDate": {
      "alias": "minDate";
      "required": false;
      "isSignal": true;
    };
    "maxDate": {
      "alias": "maxDate";
      "required": false;
      "isSignal": true;
    };
    "firstDayOfWeek": {
      "alias": "firstDayOfWeek";
      "required": false;
      "isSignal": true;
    };
    "isTodayHighlighted": {
      "alias": "isTodayHighlighted";
      "required": false;
      "isSignal": true;
    };
    "isWeekendHighlighted": {
      "alias": "isWeekendHighlighted";
      "required": false;
      "isSignal": true;
    };
    "showWeekNumbers": {
      "alias": "showWeekNumbers";
      "required": false;
      "isSignal": true;
    };
    "markerHandler": {
      "alias": "markerHandler";
      "required": false;
      "isSignal": true;
    };
    "showAdjacent": {
      "alias": "showAdjacent";
      "required": false;
      "isSignal": true;
    };
    "readonly": {
      "alias": "readonly";
      "required": false;
      "isSignal": true;
    };
    "required": {
      "alias": "required";
      "required": false;
      "isSignal": true;
    };
    "autofocus": {
      "alias": "autofocus";
      "required": false;
      "isSignal": true;
    };
    "name": {
      "alias": "name";
      "required": false;
      "isSignal": true;
    };
    "placeholder": {
      "alias": "placeholder";
      "required": false;
      "isSignal": true;
    };
    "autocomplete": {
      "alias": "autocomplete";
      "required": false;
      "isSignal": true;
    };
    "format": {
      "alias": "format";
      "required": false;
      "isSignal": true;
    };
    "textAlign": {
      "alias": "textAlign";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "isClearable": {
      "alias": "isClearable";
      "required": false;
      "isSignal": true;
    };
    "locale": {
      "alias": "locale";
      "required": false;
      "isSignal": true;
    };
    "invalid": {
      "alias": "invalid";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "dropDownPlacement": {
      "alias": "dropDownPlacement";
      "required": false;
      "isSignal": true;
    };
    "dropDownStrategy": {
      "alias": "dropDownStrategy";
      "required": false;
      "isSignal": true;
    };
    "dropDownDistance": {
      "alias": "dropDownDistance";
      "required": false;
      "isSignal": true;
    };
    "dropDownSkidding": {
      "alias": "dropDownSkidding";
      "required": false;
      "isSignal": true;
    };
    "dropDownStaysOpen": {
      "alias": "dropDownStaysOpen";
      "required": false;
      "isSignal": true;
    };
    "dropDownMaxHeight": {
      "alias": "dropDownMaxHeight";
      "required": false;
      "isSignal": true;
    };
    "dropDownHeight": {
      "alias": "dropDownHeight";
      "required": false;
      "isSignal": true;
    };
    "dropDownWidth": {
      "alias": "dropDownWidth";
      "required": false;
      "isSignal": true;
    };
    "dropDownMaxWidth": {
      "alias": "dropDownMaxWidth";
      "required": false;
      "isSignal": true;
    };
    "isDropDownOpen": {
      "alias": "isDropDownOpen";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "formatter": {
      "alias": "formatter";
      "required": false;
      "isSignal": true;
    };
    "parser": {
      "alias": "parser";
      "required": false;
      "isSignal": true;
    };
    "isFocused": {
      "alias": "isFocused";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "cleared": "cleared";
    "change": "change";
    "input": "input";
    "focus": "focus";
    "blur": "blur";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, [{
    directive: typeof i1.FormStatusHostDirective;
    inputs: {};
    outputs: {};
  }, {
    directive: typeof i1.FormFieldStatusHostDirective;
    inputs: {};
    outputs: {};
  }]>;
}
/**
 * Declares the methods available on DateBoxComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type DateBoxMethodNames = 'focus' | 'blur' | 'clear' | 'reset' | 'checkValidity' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges' | 'open' | 'close' | 'toggle';
/**
 * Declares the methods interface for DateBoxComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type DateBoxComponentMethods = MethodMap<DateBoxMethodNames>;
/**
 * @public
 */
export declare function provideDateBoxComponent(config?: Partial<DateBoxElement.Props>, intl?: Partial<DateBoxElement['intl']> | Type<Partial<DateBoxElement['intl']>>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-date-box.d.ts.map