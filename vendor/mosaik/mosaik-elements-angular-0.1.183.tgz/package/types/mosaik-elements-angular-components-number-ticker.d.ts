import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { NumberTickerElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/illustrations/number-ticker/NumberTickerElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the NumberTickerComponent.
 * Use this token to provide default properties for the NumberTickerComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const NUMBER_TICKER_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").INumberTickerElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class NumberTickerComponent {
  /**
   * Signal input for the `from` property.
   *
   * @public
   */
  readonly from: InputSignal<NumberTickerElement['from'] | undefined>;
  /**
   * Signal input for the `to` property.
   *
   * @public
   */
  readonly to: InputSignal<NumberTickerElement['to'] | undefined>;
  /**
   * Signal input for the `duration` property.
   *
   * @public
   */
  readonly duration: InputSignal<NumberTickerElement['duration'] | undefined>;
  /**
   * Signal input for the `decimals` property.
   *
   * @public
   */
  readonly decimals: InputSignal<NumberTickerElement['decimals'] | undefined>;
  /**
   * Signal input for the `grouping` property.
   *
   * @public
   */
  readonly grouping: InputSignal<NumberTickerElement['grouping'] | undefined>;
  /**
   * Signal input for the `locale` property.
   *
   * @public
   */
  readonly locale: InputSignal<NumberTickerElement['locale'] | undefined>;
  /**
   * Signal input for the `prefixText` property.
   *
   * @public
   */
  readonly prefixText: InputSignal<NumberTickerElement['prefixText'] | undefined>;
  /**
   * Signal input for the `suffixText` property.
   *
   * @public
   */
  readonly suffixText: InputSignal<NumberTickerElement['suffixText'] | undefined>;
  /**
   * Signal input for the `alignment` property.
   *
   * @public
   */
  readonly alignment: InputSignal<NumberTickerElement['alignment'] | undefined>;
  /**
   * Signal input for the `repeat` property.
   *
   * @public
   */
  readonly repeat: InputSignal<NumberTickerElement['repeat'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<NumberTickerElement['themeName'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<NumberTickerElement['variant'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<NumberTickerElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<NumberTickerElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<NumberTickerElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<NumberTickerElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<NumberTickerElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Formats a value like the figure: the fraction digits of `decimals`, the grouping of `grouping` and the language
   * of `resolvedLocale`.
   *
   * @public
   */
  format(...args: Parameters<NumberTickerElement['format']>): ReturnType<NumberTickerElement['format']>;
  /**
   * Counts again from `from` to `to`, unless the motion state is `static` (then the final value shows).
   *
   * @public
   */
  replay(...args: Parameters<NumberTickerElement['replay']>): ReturnType<NumberTickerElement['replay']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `format()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends NumberTickerMethodNames>(method: TMethod, ...args: Parameters<NumberTickerComponentMethods[TMethod]>): ReturnType<NumberTickerComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof NumberTickerElement>(property: TProperty, value: NumberTickerElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<NumberTickerElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<NumberTickerComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NumberTickerComponent, "mosaik-number-ticker", never, {
    "from": {
      "alias": "from";
      "required": false;
      "isSignal": true;
    };
    "to": {
      "alias": "to";
      "required": false;
      "isSignal": true;
    };
    "duration": {
      "alias": "duration";
      "required": false;
      "isSignal": true;
    };
    "decimals": {
      "alias": "decimals";
      "required": false;
      "isSignal": true;
    };
    "grouping": {
      "alias": "grouping";
      "required": false;
      "isSignal": true;
    };
    "locale": {
      "alias": "locale";
      "required": false;
      "isSignal": true;
    };
    "prefixText": {
      "alias": "prefixText";
      "required": false;
      "isSignal": true;
    };
    "suffixText": {
      "alias": "suffixText";
      "required": false;
      "isSignal": true;
    };
    "alignment": {
      "alias": "alignment";
      "required": false;
      "isSignal": true;
    };
    "repeat": {
      "alias": "repeat";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on NumberTickerComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type NumberTickerMethodNames = 'format' | 'replay';
/**
 * Declares the methods interface for NumberTickerComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type NumberTickerComponentMethods = MethodMap<NumberTickerMethodNames>;
/**
 * @public
 */
export declare function provideNumberTickerComponent(config?: Partial<NumberTickerElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-number-ticker.d.ts.map