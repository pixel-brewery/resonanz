import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { FontEditorElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/font-editor/FontEditorElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the FontEditorComponent.
 * Use this token to provide default properties for the FontEditorComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const FONT_EDITOR_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/media/font-editor/IFontEditorElementProps").IFontEditorElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class FontEditorComponent {
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<FontEditorElement['intl'] | undefined>;
  /**
   * Signal input for the `selectedFont` property.
   *
   * @public
   */
  readonly selectedFont: InputSignal<FontEditorElement['selectedFont'] | undefined>;
  /**
   * Signal input for the `providers` property.
   *
   * @public
   */
  readonly providers: InputSignal<FontEditorElement['providers'] | undefined>;
  /**
   * Signal input for the `collections` property.
   *
   * @public
   */
  readonly collections: InputSignal<FontEditorElement['collections'] | undefined>;
  /**
   * Signal input for the `showPreview` property.
   *
   * @public
   */
  readonly showPreview: InputSignal<FontEditorElement['showPreview'] | undefined>;
  /**
   * Signal input for the `showAlphabetFilter` property.
   *
   * @public
   */
  readonly showAlphabetFilter: InputSignal<FontEditorElement['showAlphabetFilter'] | undefined>;
  /**
   * Signal input for the `showCategoryFilter` property.
   *
   * @public
   */
  readonly showCategoryFilter: InputSignal<FontEditorElement['showCategoryFilter'] | undefined>;
  /**
   * Signal input for the `showSearch` property.
   *
   * @public
   */
  readonly showSearch: InputSignal<FontEditorElement['showSearch'] | undefined>;
  /**
   * Signal input for the `showCollections` property.
   *
   * @public
   */
  readonly showCollections: InputSignal<FontEditorElement['showCollections'] | undefined>;
  /**
   * Signal input for the `previewText` property.
   *
   * @public
   */
  readonly previewText: InputSignal<FontEditorElement['previewText'] | undefined>;
  /**
   * Signal input for the `selectedCategory` property.
   *
   * @public
   */
  readonly selectedCategory: InputSignal<FontEditorElement['selectedCategory'] | undefined>;
  /**
   * Signal input for the `selectedLetter` property.
   *
   * @public
   */
  readonly selectedLetter: InputSignal<FontEditorElement['selectedLetter'] | undefined>;
  /**
   * Signal input for the `searchText` property.
   *
   * @public
   */
  readonly searchText: InputSignal<FontEditorElement['searchText'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<FontEditorElement['disabled'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<FontEditorElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<FontEditorElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<FontEditorElement['lang'] | undefined>;
  /**
   * Output signal for the `fontSelected` event.
   *
   * @public
   */
  readonly fontSelected: OutputEmitterRef<ElementEventDetail<FontEditorElement, 'fontSelected'>>;
  /**
   * Output signal for the `fontChanged` event.
   *
   * @public
   */
  readonly fontChanged: OutputEmitterRef<ElementEventDetail<FontEditorElement, 'fontChanged'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<FontEditorElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<FontEditorElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<FontEditorElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Adds a font provider.
   *
   * @public
   * @param args - The arguments of `addProvider`:
   * - `provider` - The provider to add.
   */
  addProvider(...args: Parameters<FontEditorElement['addProvider']>): ReturnType<FontEditorElement['addProvider']>;
  /**
   * Removes a font provider.
   *
   * @public
   * @param args - The arguments of `removeProvider`:
   * - `providerId` - The ID of the provider to remove.
   */
  removeProvider(...args: Parameters<FontEditorElement['removeProvider']>): ReturnType<FontEditorElement['removeProvider']>;
  /**
   * Loads fonts from all providers.
   *
   * @public
   */
  loadFonts(...args: Parameters<FontEditorElement['loadFonts']>): ReturnType<FontEditorElement['loadFonts']>;
  /**
   * Filters fonts by letter.
   *
   * @public
   * @param args - The arguments of `filterByLetter`:
   * - `letter` - The letter to filter by, or null for all.
   */
  filterByLetter(...args: Parameters<FontEditorElement['filterByLetter']>): ReturnType<FontEditorElement['filterByLetter']>;
  /**
   * Filters fonts by category.
   *
   * @public
   * @param args - The arguments of `filterByCategory`:
   * - `category` - The category to filter by, or null for all.
   */
  filterByCategory(...args: Parameters<FontEditorElement['filterByCategory']>): ReturnType<FontEditorElement['filterByCategory']>;
  /**
   * Filters fonts by search text.
   *
   * @public
   * @param args - The arguments of `filterBySearch`:
   * - `text` - The search text.
   */
  filterBySearch(...args: Parameters<FontEditorElement['filterBySearch']>): ReturnType<FontEditorElement['filterBySearch']>;
  /**
   * Selects a font.
   *
   * @public
   * @param args - The arguments of `selectFont`:
   * - `font` - The font to select.
   */
  selectFont(...args: Parameters<FontEditorElement['selectFont']>): ReturnType<FontEditorElement['selectFont']>;
  /**
   * Loads a font for preview.
   *
   * @public
   * @param args - The arguments of `loadFont`:
   * - `font` - The font to load.
   */
  loadFont(...args: Parameters<FontEditorElement['loadFont']>): ReturnType<FontEditorElement['loadFont']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `addProvider()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends FontEditorMethodNames>(method: TMethod, ...args: Parameters<FontEditorComponentMethods[TMethod]>): ReturnType<FontEditorComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof FontEditorElement>(property: TProperty, value: FontEditorElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<FontEditorElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<FontEditorComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<FontEditorComponent, "mosaik-font-editor", never, {
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "selectedFont": {
      "alias": "selectedFont";
      "required": false;
      "isSignal": true;
    };
    "providers": {
      "alias": "providers";
      "required": false;
      "isSignal": true;
    };
    "collections": {
      "alias": "collections";
      "required": false;
      "isSignal": true;
    };
    "showPreview": {
      "alias": "showPreview";
      "required": false;
      "isSignal": true;
    };
    "showAlphabetFilter": {
      "alias": "showAlphabetFilter";
      "required": false;
      "isSignal": true;
    };
    "showCategoryFilter": {
      "alias": "showCategoryFilter";
      "required": false;
      "isSignal": true;
    };
    "showSearch": {
      "alias": "showSearch";
      "required": false;
      "isSignal": true;
    };
    "showCollections": {
      "alias": "showCollections";
      "required": false;
      "isSignal": true;
    };
    "previewText": {
      "alias": "previewText";
      "required": false;
      "isSignal": true;
    };
    "selectedCategory": {
      "alias": "selectedCategory";
      "required": false;
      "isSignal": true;
    };
    "selectedLetter": {
      "alias": "selectedLetter";
      "required": false;
      "isSignal": true;
    };
    "searchText": {
      "alias": "searchText";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "fontSelected": "fontSelected";
    "fontChanged": "fontChanged";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on FontEditorComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FontEditorMethodNames = 'addProvider' | 'removeProvider' | 'loadFonts' | 'filterByLetter' | 'filterByCategory' | 'filterBySearch' | 'selectFont' | 'loadFont';
/**
 * Declares the methods interface for FontEditorComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FontEditorComponentMethods = MethodMap<FontEditorMethodNames>;
/**
 * @public
 */
export declare function provideFontEditorComponent(config?: Partial<FontEditorElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-font-editor.d.ts.map