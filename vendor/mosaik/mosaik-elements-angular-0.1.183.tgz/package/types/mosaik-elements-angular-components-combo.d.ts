import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef, Type } from "@angular/core";
import { ComboItemGroupElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/combo/ComboItemGroupElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import * as i1 from "@pixel-brewery/mosaik-elements-angular/runtime";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { ComboItemVisualElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/combo/ComboItemVisualElement";
import { ComboItemElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/combo/ComboItemElement";
import { ControlValueAccessor } from "@angular/forms";
import { ComboElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/combo/ComboElement";
/**
 * @public
 *
 * Injection token for the default properties of the ComboItemGroupComponent.
 * Use this token to provide default properties for the ComboItemGroupComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const COMBO_ITEM_GROUP_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/selectors/combo/IComboItemGroupElementProps").IComboItemGroupElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot for Combo Item elements within the group
 * @slot header - The header slot for custom group label content
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ComboItemGroupComponent {
  /**
   * Signal input for the `header` property.
   *
   * @public
   */
  readonly header: InputSignal<ComboItemGroupElement['header'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ComboItemGroupElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ComboItemGroupElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ComboItemGroupElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ComboItemGroupElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ComboItemGroupElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ComboItemGroupElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ComboItemGroupElement>(property: TProperty, value: ComboItemGroupElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ComboItemGroupElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ComboItemGroupComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ComboItemGroupComponent, "mosaik-combo-item-group", never, {
    "header": {
      "alias": "header";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on ComboItemGroupComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ComboItemGroupMethodNames = never;
/**
 * Declares the methods interface for ComboItemGroupComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ComboItemGroupComponentMethods = MethodMap<ComboItemGroupMethodNames>;
/**
 * @public
 */
export declare function provideComboItemGroupComponent(config?: Partial<ComboItemGroupElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the ComboItemVisualComponent.
 * Use this token to provide default properties for the ComboItemVisualComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const COMBO_ITEM_VISUAL_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").IComboItemVisualElementProps>>;
/**
 * @public
 *
 * @slot  - Default selection content.
 * @slot start - Content before the icon.
 * @slot icon - The selection icon.
 * @slot label - The selection label.
 * @slot end - Content after the label.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ComboItemVisualComponent {
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ComboItemVisualElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ComboItemVisualElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ComboItemVisualElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ComboItemVisualElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ComboItemVisualElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ComboItemVisualElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: ComboItemVisualElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: ComboItemVisualElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   * @param args - The arguments of `assignToSlot`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * - `node` - The nodes to assign to the slot.
   */
  assignToSlot(...args: Parameters<ComboItemVisualElement['assignToSlot']>): ReturnType<ComboItemVisualElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   * This method extracts text content recursively, including from Shadow DOMs
   * and Custom Elements with known text properties (like `mosaik-text`).
   *
   * @public
   * @param args - The arguments of `getSlotContent`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<ComboItemVisualElement['getSlotContent']>): ReturnType<ComboItemVisualElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @param args - The arguments of `hasSlotContent`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<ComboItemVisualElement['hasSlotContent']>): ReturnType<ComboItemVisualElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @param args - The arguments of `hasSlot`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<ComboItemVisualElement['hasSlot']>): ReturnType<ComboItemVisualElement['hasSlot']>;
  /**
   * Called when the slot changes.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<ComboItemVisualElement['onSlotChanges']>): ReturnType<ComboItemVisualElement['onSlotChanges']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `assignToSlot()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends ComboItemVisualMethodNames>(method: TMethod, ...args: Parameters<ComboItemVisualComponentMethods[TMethod]>): ReturnType<ComboItemVisualComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ComboItemVisualElement>(property: TProperty, value: ComboItemVisualElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ComboItemVisualElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ComboItemVisualComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ComboItemVisualComponent, "mosaik-combo-item-visual", never, {
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on ComboItemVisualComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ComboItemVisualMethodNames = 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges';
/**
 * Declares the methods interface for ComboItemVisualComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ComboItemVisualComponentMethods = MethodMap<ComboItemVisualMethodNames>;
/**
 * @public
 */
export declare function provideComboItemVisualComponent(config?: Partial<ComboItemVisualElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the ComboItemComponent.
 * Use this token to provide default properties for the ComboItemComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const COMBO_ITEM_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/selectors/combo/IComboItemElementProps").IComboItemElementProps>>;
/**
 * @public
 *
 * @slot checkmark - The checkmark slot.
 * @slot end - The end slot.
 * @slot icon - The icon slot.
 * @slot label - Content area for the option label and description
 * @slot start - The start slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ComboItemComponent {
  /**
   * Signal input for the `isChecked` property.
   *
   * @public
   */
  readonly isChecked: InputSignal<ComboItemElement['isChecked'] | undefined>;
  /**
   * Signal input for the `icon` property.
   *
   * @public
   */
  readonly icon: InputSignal<ComboItemElement['icon'] | undefined>;
  /**
   * Signal input for the `isActive` property.
   *
   * @public
   */
  readonly isActive: InputSignal<ComboItemElement['isActive'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ComboItemElement['themeName'] | undefined>;
  /**
   * Signal input for the `ripple` property.
   *
   * @public
   */
  readonly ripple: InputSignal<ComboItemElement['ripple'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<ComboItemElement['disabled'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<ComboItemElement['variant'] | undefined>;
  /**
   * Signal input for the `isFocused` property.
   *
   * @public
   */
  readonly isFocused: InputSignal<ComboItemElement['isFocused'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<ComboItemElement['label'] | undefined>;
  /**
   * Signal input for the `isSelected` property.
   *
   * @public
   */
  readonly isSelected: InputSignal<ComboItemElement['isSelected'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<ComboItemElement['value'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ComboItemElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ComboItemElement['lang'] | undefined>;
  /**
   * Output signal for the `selected` event.
   *
   * @public
   */
  readonly selected: OutputEmitterRef<ElementEventDetail<ComboItemElement, 'selected'>>;
  /**
   * Output signal for the `deselected` event.
   *
   * @public
   */
  readonly deselected: OutputEmitterRef<ElementEventDetail<ComboItemElement, 'deselected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ComboItemElement, 'changed'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ComboItemElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ComboItemElement, 'disconnected'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Selects the item and fires `selected`. Does nothing when the item is already selected.
   *
   * @public
   * @param args - The arguments of `select`:
   * - `forceUpdate` - When `true`, the parent selector also selects the item.
   */
  select(...args: Parameters<ComboItemElement['select']>): ReturnType<ComboItemElement['select']>;
  /**
   * Deselects the item and fires `deselected`. Does nothing when the item is not selected.
   *
   * @public
   * @param args - The arguments of `deselect`:
   * - `forceUpdate` - When `true`, the parent selector also deselects the item.
   */
  deselect(...args: Parameters<ComboItemElement['deselect']>): ReturnType<ComboItemElement['deselect']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `select()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends ComboItemMethodNames>(method: TMethod, ...args: Parameters<ComboItemComponentMethods[TMethod]>): ReturnType<ComboItemComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ComboItemElement>(property: TProperty, value: ComboItemElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ComboItemElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ComboItemComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ComboItemComponent, "mosaik-combo-item", never, {
    "isChecked": {
      "alias": "isChecked";
      "required": false;
      "isSignal": true;
    };
    "icon": {
      "alias": "icon";
      "required": false;
      "isSignal": true;
    };
    "isActive": {
      "alias": "isActive";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "ripple": {
      "alias": "ripple";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "isFocused": {
      "alias": "isFocused";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "isSelected": {
      "alias": "isSelected";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "selected": "selected";
    "deselected": "deselected";
    "changed": "changed";
    "connected": "connected";
    "disconnected": "disconnected";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on ComboItemComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ComboItemMethodNames = 'select' | 'deselect';
/**
 * Declares the methods interface for ComboItemComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ComboItemComponentMethods = MethodMap<ComboItemMethodNames>;
/**
 * @public
 */
export declare function provideComboItemComponent(config?: Partial<ComboItemElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the ComboComponent.
 * Use this token to provide default properties for the ComboComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const COMBO_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/selectors/combo/IComboElementProps").IComboElementProps>>;
/**
 * @public
 *
 * Injection token for the intl configuration of the ComboComponent.
 * Provide a partial intl object or an injectable class that resolves translations.
 * This allows third-party applications to override the default intl labels
 * globally, per route, or per component via Angular's dependency injection.
 *
 * Merge order: Foundation defaults → DI intl → [intl] input binding.
 */
export declare const COMBO_INTL: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").ComboElementIntl>>;
/**
 * @public
 *
 * @slot  - Default content area for combo items and item groups
 * @slot prefix - Leading content before the input (icons, labels)
 * @slot suffix - Trailing content after the input (actions, indicators)
 * @slot trigger - Custom content that replaces the normal selection presentation.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ComboComponent implements ControlValueAccessor {
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<Partial<ComboElement['intl']> | undefined>;
  /**
   * Signal input for the `selectionMode` property.
   *
   * @public
   */
  readonly selectionMode: InputSignal<ComboElement['selectionMode'] | undefined>;
  /**
   * Signal input for the `placeholder` property.
   *
   * @public
   */
  readonly placeholder: InputSignal<ComboElement['placeholder'] | undefined>;
  /**
   * Signal input for the `required` property.
   *
   * @public
   */
  readonly required: InputSignal<ComboElement['required'] | undefined>;
  /**
   * Signal input for the `textAlign` property.
   *
   * @public
   */
  readonly textAlign: InputSignal<ComboElement['textAlign'] | undefined>;
  /**
   * Signal input for the `showScrollButtons` property.
   *
   * @public
   */
  readonly showScrollButtons: InputSignal<ComboElement['showScrollButtons'] | undefined>;
  /**
   * Signal input for the `showScrollbar` property.
   *
   * @public
   */
  readonly showScrollbar: InputSignal<ComboElement['showScrollbar'] | undefined>;
  /**
   * Signal input for the `dropDownPlacement` property.
   *
   * @public
   */
  readonly dropDownPlacement: InputSignal<ComboElement['dropDownPlacement'] | undefined>;
  /**
   * Signal input for the `dropDownStrategy` property.
   *
   * @public
   */
  readonly dropDownStrategy: InputSignal<ComboElement['dropDownStrategy'] | undefined>;
  /**
   * Signal input for the `dropDownDistance` property.
   *
   * @public
   */
  readonly dropDownDistance: InputSignal<ComboElement['dropDownDistance'] | undefined>;
  /**
   * Signal input for the `dropDownSkidding` property.
   *
   * @public
   */
  readonly dropDownSkidding: InputSignal<ComboElement['dropDownSkidding'] | undefined>;
  /**
   * Signal input for the `dropDownStaysOpen` property.
   *
   * @public
   */
  readonly dropDownStaysOpen: InputSignal<ComboElement['dropDownStaysOpen'] | undefined>;
  /**
   * Signal input for the `dropDownMaxHeight` property.
   *
   * @public
   */
  readonly dropDownMaxHeight: InputSignal<ComboElement['dropDownMaxHeight'] | undefined>;
  /**
   * Signal input for the `dropDownHeight` property.
   *
   * @public
   */
  readonly dropDownHeight: InputSignal<ComboElement['dropDownHeight'] | undefined>;
  /**
   * Signal input for the `dropDownWidth` property.
   *
   * @public
   */
  readonly dropDownWidth: InputSignal<ComboElement['dropDownWidth'] | undefined>;
  /**
   * Signal input for the `dropDownMaxWidth` property.
   *
   * @public
   */
  readonly dropDownMaxWidth: InputSignal<ComboElement['dropDownMaxWidth'] | undefined>;
  /**
   * Signal input for the `isDropDownOpen` property.
   *
   * @public
   */
  readonly isDropDownOpen: InputSignal<ComboElement['isDropDownOpen'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<ComboElement['appearance'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<ComboElement['variant'] | undefined>;
  /**
   * Signal input for the `size` property.
   *
   * @public
   */
  readonly size: InputSignal<ComboElement['size'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<ComboElement['label'] | undefined>;
  /**
   * Signal input for the `isClearable` property.
   *
   * @public
   */
  readonly isClearable: InputSignal<ComboElement['isClearable'] | undefined>;
  /**
   * Signal input for the `invalid` property.
   *
   * @public
   */
  readonly invalid: InputSignal<ComboElement['invalid'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<ComboElement['disabled'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<ComboElement['value'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ComboElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ComboElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ComboElement['lang'] | undefined>;
  /**
   * Output signal for the `cleared` event.
   *
   * @public
   */
  readonly cleared: OutputEmitterRef<ElementEventDetail<ComboElement, 'cleared'>>;
  /**
   * Output signal for the `selectionChanged` event.
   *
   * @public
   */
  readonly selectionChanged: OutputEmitterRef<ElementEventDetail<ComboElement, 'selectionChanged'>>;
  /**
   * Output signal for the `itemsChanged` event.
   *
   * @public
   */
  readonly itemsChanged: OutputEmitterRef<ElementEventDetail<ComboElement, 'itemsChanged'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ComboElement, 'changed'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ComboElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ComboElement, 'disconnected'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: ComboElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: ComboElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  private readonly _accessor;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Applies a value supplied by Angular forms to the native control.
   *
   * @public
   */
  writeValue(obj: unknown): void;
  /**
   * Registers the callback notified when the native control value changes.
   *
   * @public
   */
  registerOnChange(fn: unknown): void;
  /**
   * Registers the callback notified when the native control is touched.
   *
   * @public
   */
  registerOnTouched(fn: unknown): void;
  /**
   * Applies the disabled state supplied by Angular forms.
   *
   * @public
   */
  setDisabledState?(isDisabled: boolean): void;
  /**
   * Resets the value, all kinds of validation and errors.
   *
   * @public
   */
  reset(...args: Parameters<ComboElement['reset']>): ReturnType<ComboElement['reset']>;
  /**
   * Deselect the item when it is part of the selection, as a click on it would.
   *
   * @public
   * @param args - The arguments of `deselect`:
   * - `item` - The element or index to deselect.
   */
  deselect(...args: Parameters<ComboElement['deselect']>): ReturnType<ComboElement['deselect']>;
  /**
   * Resets the current selection together with the value and the check marks of the options.
   *
   * @public
   */
  resetSelection(...args: Parameters<ComboElement['resetSelection']>): ReturnType<ComboElement['resetSelection']>;
  /**
   * Checks the validity of the element and returns `true` if it is valid; otherwise, `false`.
   *
   * @public
   */
  checkValidity(...args: Parameters<ComboElement['checkValidity']>): ReturnType<ComboElement['checkValidity']>;
  /**
   * Clears the value of the element but not the validation.
   * Also clears the selected items and resets the active state.
   *
   * @public
   */
  clear(...args: Parameters<ComboElement['clear']>): ReturnType<ComboElement['clear']>;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<ComboElement['onSlotChanges']>): ReturnType<ComboElement['onSlotChanges']>;
  /**
   * Returns the scrollable viewport of the drop down, which is owned by the
   * internal scroll primitive rather than by the element itself.
   *
   * @public
   */
  getScrollableElement(...args: Parameters<ComboElement['getScrollableElement']>): ReturnType<ComboElement['getScrollableElement']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<ComboElement['assignToSlot']>): ReturnType<ComboElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<ComboElement['getSlotContent']>): ReturnType<ComboElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<ComboElement['hasSlotContent']>): ReturnType<ComboElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<ComboElement['hasSlot']>): ReturnType<ComboElement['hasSlot']>;
  /**
   * Opens the drop down.
   *
   * @public
   */
  open(...args: Parameters<ComboElement['open']>): ReturnType<ComboElement['open']>;
  /**
   * Closes the drop down.
   *
   * @public
   */
  close(...args: Parameters<ComboElement['close']>): ReturnType<ComboElement['close']>;
  /**
   * Toggles the drop down.
   *
   * @public
   */
  toggle(...args: Parameters<ComboElement['toggle']>): ReturnType<ComboElement['toggle']>;
  /**
   * Select the item.
   *
   * @public
   * @param args - The arguments of `select`:
   * - `item` - The element, index or value to select.
   */
  select(...args: Parameters<ComboElement['select']>): ReturnType<ComboElement['select']>;
  /**
   * Select the next item after current selected item/index.
   *
   * @public
   */
  selectNext(...args: Parameters<ComboElement['selectNext']>): ReturnType<ComboElement['selectNext']>;
  /**
   * Select the previous item before current selected item/index.
   *
   * @public
   */
  selectPrevious(...args: Parameters<ComboElement['selectPrevious']>): ReturnType<ComboElement['selectPrevious']>;
  /**
   * Select the first item.
   *
   * @public
   */
  selectFirst(...args: Parameters<ComboElement['selectFirst']>): ReturnType<ComboElement['selectFirst']>;
  /**
   * Select the last item.
   *
   * @public
   */
  selectLast(...args: Parameters<ComboElement['selectLast']>): ReturnType<ComboElement['selectLast']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `reset()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends ComboMethodNames>(method: TMethod, ...args: Parameters<ComboComponentMethods[TMethod]>): ReturnType<ComboComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ComboElement>(property: TProperty, value: ComboElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ComboElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ComboComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ComboComponent, "mosaik-combo", never, {
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "selectionMode": {
      "alias": "selectionMode";
      "required": false;
      "isSignal": true;
    };
    "placeholder": {
      "alias": "placeholder";
      "required": false;
      "isSignal": true;
    };
    "required": {
      "alias": "required";
      "required": false;
      "isSignal": true;
    };
    "textAlign": {
      "alias": "textAlign";
      "required": false;
      "isSignal": true;
    };
    "showScrollButtons": {
      "alias": "showScrollButtons";
      "required": false;
      "isSignal": true;
    };
    "showScrollbar": {
      "alias": "showScrollbar";
      "required": false;
      "isSignal": true;
    };
    "dropDownPlacement": {
      "alias": "dropDownPlacement";
      "required": false;
      "isSignal": true;
    };
    "dropDownStrategy": {
      "alias": "dropDownStrategy";
      "required": false;
      "isSignal": true;
    };
    "dropDownDistance": {
      "alias": "dropDownDistance";
      "required": false;
      "isSignal": true;
    };
    "dropDownSkidding": {
      "alias": "dropDownSkidding";
      "required": false;
      "isSignal": true;
    };
    "dropDownStaysOpen": {
      "alias": "dropDownStaysOpen";
      "required": false;
      "isSignal": true;
    };
    "dropDownMaxHeight": {
      "alias": "dropDownMaxHeight";
      "required": false;
      "isSignal": true;
    };
    "dropDownHeight": {
      "alias": "dropDownHeight";
      "required": false;
      "isSignal": true;
    };
    "dropDownWidth": {
      "alias": "dropDownWidth";
      "required": false;
      "isSignal": true;
    };
    "dropDownMaxWidth": {
      "alias": "dropDownMaxWidth";
      "required": false;
      "isSignal": true;
    };
    "isDropDownOpen": {
      "alias": "isDropDownOpen";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "isClearable": {
      "alias": "isClearable";
      "required": false;
      "isSignal": true;
    };
    "invalid": {
      "alias": "invalid";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "cleared": "cleared";
    "selectionChanged": "selectionChanged";
    "itemsChanged": "itemsChanged";
    "changed": "changed";
    "connected": "connected";
    "disconnected": "disconnected";
  }, never, ["*"], true, [{
    directive: typeof i1.FormStatusHostDirective;
    inputs: {};
    outputs: {};
  }, {
    directive: typeof i1.FormFieldStatusHostDirective;
    inputs: {};
    outputs: {};
  }]>;
}
/**
 * Declares the methods available on ComboComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ComboMethodNames = 'reset' | 'deselect' | 'resetSelection' | 'checkValidity' | 'clear' | 'onSlotChanges' | 'getScrollableElement' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'open' | 'close' | 'toggle' | 'select' | 'selectNext' | 'selectPrevious' | 'selectFirst' | 'selectLast';
/**
 * Declares the methods interface for ComboComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ComboComponentMethods = MethodMap<ComboMethodNames>;
/**
 * @public
 */
export declare function provideComboComponent(config?: Partial<ComboElement.Props>, intl?: Partial<ComboElement['intl']> | Type<Partial<ComboElement['intl']>>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-combo.d.ts.map