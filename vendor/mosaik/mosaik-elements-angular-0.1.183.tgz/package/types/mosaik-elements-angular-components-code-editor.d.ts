import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef, Type } from "@angular/core";
import { ControlValueAccessor } from "@angular/forms";
import { CodeEditorElement } from "@pixel-brewery/mosaik-elements-foundation/components/code-editor";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import * as i1 from "@pixel-brewery/mosaik-elements-angular/runtime";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the CodeEditorComponent.
 * Use this token to provide default properties for the CodeEditorComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const CODE_EDITOR_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation/components/code-editor").ICodeEditorElementProps>>;
/**
 * @public
 *
 * Injection token for the intl configuration of the CodeEditorComponent.
 * Provide a partial intl object or an injectable class that resolves translations.
 * This allows third-party applications to override the default intl labels
 * globally, per route, or per component via Angular's dependency injection.
 *
 * Merge order: Foundation defaults → DI intl → [intl] input binding.
 */
export declare const CODE_EDITOR_INTL: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation/components/code-editor").CodeEditorElementIntl>>;
/**
 * @public
 *
 * @slot status - Content at the end of the status bar (`status-bar` must be set).
 * @slot toolbar - Content at the start of the toolbar (`toolbar` must be set).
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class CodeEditorComponent implements ControlValueAccessor {
  /**
   * Signal input for the `text` property.
   *
   * @public
   */
  readonly text: InputSignal<CodeEditorElement['text'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<CodeEditorElement['value'] | undefined>;
  /**
   * Signal input for the `language` property.
   *
   * @public
   */
  readonly language: InputSignal<CodeEditorElement['language'] | undefined>;
  /**
   * Signal input for the `readonly` property.
   *
   * @public
   */
  readonly readonly: InputSignal<CodeEditorElement['readonly'] | undefined>;
  /**
   * Signal input for the `required` property.
   *
   * @public
   */
  readonly required: InputSignal<CodeEditorElement['required'] | undefined>;
  /**
   * Signal input for the `invalid` property.
   *
   * @public
   */
  readonly invalid: InputSignal<CodeEditorElement['invalid'] | undefined>;
  /**
   * Signal input for the `name` property.
   *
   * @public
   */
  readonly name: InputSignal<CodeEditorElement['name'] | undefined>;
  /**
   * Signal input for the `placeholder` property.
   *
   * @public
   */
  readonly placeholder: InputSignal<CodeEditorElement['placeholder'] | undefined>;
  /**
   * Signal input for the `lineNumbers` property.
   *
   * @public
   */
  readonly lineNumbers: InputSignal<CodeEditorElement['lineNumbers'] | undefined>;
  /**
   * Signal input for the `lineWrapping` property.
   *
   * @public
   */
  readonly lineWrapping: InputSignal<CodeEditorElement['lineWrapping'] | undefined>;
  /**
   * Signal input for the `foldGutter` property.
   *
   * @public
   */
  readonly foldGutter: InputSignal<CodeEditorElement['foldGutter'] | undefined>;
  /**
   * Signal input for the `highlightActiveLine` property.
   *
   * @public
   */
  readonly highlightActiveLine: InputSignal<CodeEditorElement['highlightActiveLine'] | undefined>;
  /**
   * Signal input for the `highlightWhitespace` property.
   *
   * @public
   */
  readonly highlightWhitespace: InputSignal<CodeEditorElement['highlightWhitespace'] | undefined>;
  /**
   * Signal input for the `closeBrackets` property.
   *
   * @public
   */
  readonly closeBrackets: InputSignal<CodeEditorElement['closeBrackets'] | undefined>;
  /**
   * Signal input for the `autocompletion` property.
   *
   * @public
   */
  readonly autocompletion: InputSignal<CodeEditorElement['autocompletion'] | undefined>;
  /**
   * Signal input for the `indentWithTab` property.
   *
   * @public
   */
  readonly indentWithTab: InputSignal<CodeEditorElement['indentWithTab'] | undefined>;
  /**
   * Signal input for the `tabSize` property.
   *
   * @public
   */
  readonly tabSize: InputSignal<CodeEditorElement['tabSize'] | undefined>;
  /**
   * Signal input for the `indentWithTabs` property.
   *
   * @public
   */
  readonly indentWithTabs: InputSignal<CodeEditorElement['indentWithTabs'] | undefined>;
  /**
   * Signal input for the `minLines` property.
   *
   * @public
   */
  readonly minLines: InputSignal<CodeEditorElement['minLines'] | undefined>;
  /**
   * Signal input for the `maxLines` property.
   *
   * @public
   */
  readonly maxLines: InputSignal<CodeEditorElement['maxLines'] | undefined>;
  /**
   * Signal input for the `toolbar` property.
   *
   * @public
   */
  readonly toolbar: InputSignal<CodeEditorElement['toolbar'] | undefined>;
  /**
   * Signal input for the `statusBar` property.
   *
   * @public
   */
  readonly statusBar: InputSignal<CodeEditorElement['statusBar'] | undefined>;
  /**
   * Signal input for the `copyable` property.
   *
   * @public
   */
  readonly copyable: InputSignal<CodeEditorElement['copyable'] | undefined>;
  /**
   * Signal input for the `maximized` property.
   *
   * @public
   */
  readonly maximized: InputSignal<CodeEditorElement['maximized'] | undefined>;
  /**
   * Signal input for the `preview` property.
   *
   * @public
   */
  readonly preview: InputSignal<CodeEditorElement['preview'] | undefined>;
  /**
   * Signal input for the `autoFormat` property.
   *
   * @public
   */
  readonly autoFormat: InputSignal<CodeEditorElement['autoFormat'] | undefined>;
  /**
   * Signal input for the `tooltipPosition` property.
   *
   * @public
   */
  readonly tooltipPosition: InputSignal<CodeEditorElement['tooltipPosition'] | undefined>;
  /**
   * Signal input for the `completions` property.
   *
   * @public
   */
  readonly completions: InputSignal<CodeEditorElement['completions'] | undefined>;
  /**
   * Signal input for the `diagnostics` property.
   *
   * @public
   */
  readonly diagnostics: InputSignal<CodeEditorElement['diagnostics'] | undefined>;
  /**
   * Signal input for the `linter` property.
   *
   * @public
   */
  readonly linter: InputSignal<CodeEditorElement['linter'] | undefined>;
  /**
   * Signal input for the `formatter` property.
   *
   * @public
   */
  readonly formatter: InputSignal<CodeEditorElement['formatter'] | undefined>;
  /**
   * Signal input for the `previewRenderer` property.
   *
   * @public
   */
  readonly previewRenderer: InputSignal<CodeEditorElement['previewRenderer'] | undefined>;
  /**
   * Signal input for the `copyHandler` property.
   *
   * @public
   */
  readonly copyHandler: InputSignal<CodeEditorElement['copyHandler'] | undefined>;
  /**
   * Signal input for the `extensions` property.
   *
   * @public
   */
  readonly extensions: InputSignal<CodeEditorElement['extensions'] | undefined>;
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<Partial<CodeEditorElement['intl']> | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<CodeEditorElement['themeName'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<CodeEditorElement['appearance'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<CodeEditorElement['label'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<CodeEditorElement['disabled'] | undefined>;
  /**
   * Signal input for the `locale` property.
   *
   * @public
   */
  readonly locale: InputSignal<CodeEditorElement['locale'] | undefined>;
  /**
   * Signal input for the `isFocused` property.
   *
   * @public
   */
  readonly isFocused: InputSignal<CodeEditorElement['isFocused'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<CodeEditorElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<CodeEditorElement['lang'] | undefined>;
  /**
   * Output signal for the `input` event.
   *
   * @public
   */
  readonly input: OutputEmitterRef<ElementEventDetail<CodeEditorElement, 'input'>>;
  /**
   * Output signal for the `change` event.
   *
   * @public
   */
  readonly change: OutputEmitterRef<ElementEventDetail<CodeEditorElement, 'change'>>;
  /**
   * Output signal for the `selectionChanged` event.
   *
   * @public
   */
  readonly selectionChanged: OutputEmitterRef<ElementEventDetail<CodeEditorElement, 'selectionChanged'>>;
  /**
   * Output signal for the `copied` event.
   *
   * @public
   */
  readonly copied: OutputEmitterRef<ElementEventDetail<CodeEditorElement, 'copied'>>;
  /**
   * Output signal for the `formatted` event.
   *
   * @public
   */
  readonly formatted: OutputEmitterRef<ElementEventDetail<CodeEditorElement, 'formatted'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<CodeEditorElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<CodeEditorElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<CodeEditorElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  private readonly _accessor;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Applies a value supplied by Angular forms to the native control.
   *
   * @public
   */
  writeValue(obj: unknown): void;
  /**
   * Registers the callback notified when the native control value changes.
   *
   * @public
   */
  registerOnChange(fn: unknown): void;
  /**
   * Registers the callback notified when the native control is touched.
   *
   * @public
   */
  registerOnTouched(fn: unknown): void;
  /**
   * Applies the disabled state supplied by Angular forms.
   *
   * @public
   */
  setDisabledState?(isDisabled: boolean): void;
  /**
   * Focuses the code.
   *
   * @public
   */
  focus(...args: Parameters<CodeEditorElement['focus']>): ReturnType<CodeEditorElement['focus']>;
  /**
   * Removes the focus from the code.
   *
   * @public
   */
  blur(...args: Parameters<CodeEditorElement['blur']>): ReturnType<CodeEditorElement['blur']>;
  /**
   * Selects a range of the code, or all of it without arguments, and scrolls it into view.
   *
   * @public
   * @param args - The arguments of `select`:
   * - `from` - The start offset (the anchor).
   * - `to` - The end offset (the head). The default is `from`.
   */
  select(...args: Parameters<CodeEditorElement['select']>): ReturnType<CodeEditorElement['select']>;
  /**
   * Moves the cursor to a line (and a column) and scrolls it to the middle of the editor.
   *
   * @public
   * @param args - The arguments of `goToLine`:
   * - `line` - The one-based line.
   * - `column` - The one-based column. The default is `1`.
   */
  goToLine(...args: Parameters<CodeEditorElement['goToLine']>): ReturnType<CodeEditorElement['goToLine']>;
  /**
   * Replaces the selections with a text (inserts it at the cursors) as an edit of the user (`input` fires).
   *
   * @public
   * @param args - The arguments of `insertText`:
   * - `text` - The text.
   */
  insertText(...args: Parameters<CodeEditorElement['insertText']>): ReturnType<CodeEditorElement['insertText']>;
  /**
   * Undoes the last change.
   *
   * @public
   * @returns Whether there was a change to undo.
   */
  undo(...args: Parameters<CodeEditorElement['undo']>): ReturnType<CodeEditorElement['undo']>;
  /**
   * Redoes the last undone change.
   *
   * @public
   * @returns Whether there was a change to redo.
   */
  redo(...args: Parameters<CodeEditorElement['redo']>): ReturnType<CodeEditorElement['redo']>;
  /**
   * Folds every foldable range.
   *
   * @public
   */
  foldAll(...args: Parameters<CodeEditorElement['foldAll']>): ReturnType<CodeEditorElement['foldAll']>;
  /**
   * Unfolds every folded range.
   *
   * @public
   */
  unfoldAll(...args: Parameters<CodeEditorElement['unfoldAll']>): ReturnType<CodeEditorElement['unfoldAll']>;
  /**
   * Runs the `linter` now instead of after the next pause.
   *
   * @public
   */
  lint(...args: Parameters<CodeEditorElement['lint']>): ReturnType<CodeEditorElement['lint']>;
  /**
   * Formats the code with the `formatter` as an edit of the user (undoable, `input` fires). Only the changed range
   * is replaced, so the cursor and the folds outside of it stay.
   *
   * @public
   * @returns Whether the code changed.
   */
  format(...args: Parameters<CodeEditorElement['format']>): ReturnType<CodeEditorElement['format']>;
  /**
   * Copies the code (or a given text) to the clipboard and confirms it on the copy actions.
   *
   * @public
   * @param args - The arguments of `copy`:
   * - `text` - The text to copy. The default is the code.
   * @returns Whether the text was copied.
   */
  copy(...args: Parameters<CodeEditorElement['copy']>): ReturnType<CodeEditorElement['copy']>;
  /**
   * Opens the search panel (with a query, or the selected word) and focuses its search field.
   *
   * @public
   * @param args - The arguments of `openSearch`:
   * - `query` - The text to search for.
   */
  openSearch(...args: Parameters<CodeEditorElement['openSearch']>): ReturnType<CodeEditorElement['openSearch']>;
  /**
   * Closes the search panel and returns the focus to the code.
   *
   * @public
   */
  closeSearch(...args: Parameters<CodeEditorElement['closeSearch']>): ReturnType<CodeEditorElement['closeSearch']>;
  /**
   * Opens or closes the search panel.
   *
   * @public
   */
  toggleSearch(...args: Parameters<CodeEditorElement['toggleSearch']>): ReturnType<CodeEditorElement['toggleSearch']>;
  /**
   * Selects the next match of the search.
   *
   * @public
   * @returns Whether a match was found.
   */
  findNext(...args: Parameters<CodeEditorElement['findNext']>): ReturnType<CodeEditorElement['findNext']>;
  /**
   * Selects the previous match of the search.
   *
   * @public
   * @returns Whether a match was found.
   */
  findPrevious(...args: Parameters<CodeEditorElement['findPrevious']>): ReturnType<CodeEditorElement['findPrevious']>;
  /**
   * Selects every match of the search (one cursor per match).
   *
   * @public
   * @returns Whether there were matches.
   */
  selectAllMatches(...args: Parameters<CodeEditorElement['selectAllMatches']>): ReturnType<CodeEditorElement['selectAllMatches']>;
  /**
   * Replaces the selected match (or the next one) with the replacement of the search.
   *
   * @public
   * @returns Whether a match was replaced.
   */
  replaceNext(...args: Parameters<CodeEditorElement['replaceNext']>): ReturnType<CodeEditorElement['replaceNext']>;
  /**
   * Replaces every match of the search with its replacement.
   *
   * @public
   * @returns Whether matches were replaced.
   */
  replaceAll(...args: Parameters<CodeEditorElement['replaceAll']>): ReturnType<CodeEditorElement['replaceAll']>;
  /**
   * Turns line wrapping on or off.
   *
   * @public
   */
  toggleLineWrapping(...args: Parameters<CodeEditorElement['toggleLineWrapping']>): ReturnType<CodeEditorElement['toggleLineWrapping']>;
  /**
   * Turns the maximized mode on or off.
   *
   * @public
   */
  toggleMaximized(...args: Parameters<CodeEditorElement['toggleMaximized']>): ReturnType<CodeEditorElement['toggleMaximized']>;
  /**
   * Shows or hides the preview.
   *
   * @public
   */
  togglePreview(...args: Parameters<CodeEditorElement['togglePreview']>): ReturnType<CodeEditorElement['togglePreview']>;
  /**
   * Returns a promise that resolves once the editor is rendered and the grammar of its language is applied.
   *
   * @public
   */
  whenReady(...args: Parameters<CodeEditorElement['whenReady']>): ReturnType<CodeEditorElement['whenReady']>;
  /**
   * Returns whether the code is valid (a required editor needs code).
   *
   * @public
   */
  checkValidity(...args: Parameters<CodeEditorElement['checkValidity']>): ReturnType<CodeEditorElement['checkValidity']>;
  /**
   * Restores the initial code and clears the validation state.
   *
   * @public
   */
  reset(...args: Parameters<CodeEditorElement['reset']>): ReturnType<CodeEditorElement['reset']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `focus()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends CodeEditorMethodNames>(method: TMethod, ...args: Parameters<CodeEditorComponentMethods[TMethod]>): ReturnType<CodeEditorComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof CodeEditorElement>(property: TProperty, value: CodeEditorElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<CodeEditorElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<CodeEditorComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<CodeEditorComponent, "mosaik-code-editor", never, {
    "text": {
      "alias": "text";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "language": {
      "alias": "language";
      "required": false;
      "isSignal": true;
    };
    "readonly": {
      "alias": "readonly";
      "required": false;
      "isSignal": true;
    };
    "required": {
      "alias": "required";
      "required": false;
      "isSignal": true;
    };
    "invalid": {
      "alias": "invalid";
      "required": false;
      "isSignal": true;
    };
    "name": {
      "alias": "name";
      "required": false;
      "isSignal": true;
    };
    "placeholder": {
      "alias": "placeholder";
      "required": false;
      "isSignal": true;
    };
    "lineNumbers": {
      "alias": "lineNumbers";
      "required": false;
      "isSignal": true;
    };
    "lineWrapping": {
      "alias": "lineWrapping";
      "required": false;
      "isSignal": true;
    };
    "foldGutter": {
      "alias": "foldGutter";
      "required": false;
      "isSignal": true;
    };
    "highlightActiveLine": {
      "alias": "highlightActiveLine";
      "required": false;
      "isSignal": true;
    };
    "highlightWhitespace": {
      "alias": "highlightWhitespace";
      "required": false;
      "isSignal": true;
    };
    "closeBrackets": {
      "alias": "closeBrackets";
      "required": false;
      "isSignal": true;
    };
    "autocompletion": {
      "alias": "autocompletion";
      "required": false;
      "isSignal": true;
    };
    "indentWithTab": {
      "alias": "indentWithTab";
      "required": false;
      "isSignal": true;
    };
    "tabSize": {
      "alias": "tabSize";
      "required": false;
      "isSignal": true;
    };
    "indentWithTabs": {
      "alias": "indentWithTabs";
      "required": false;
      "isSignal": true;
    };
    "minLines": {
      "alias": "minLines";
      "required": false;
      "isSignal": true;
    };
    "maxLines": {
      "alias": "maxLines";
      "required": false;
      "isSignal": true;
    };
    "toolbar": {
      "alias": "toolbar";
      "required": false;
      "isSignal": true;
    };
    "statusBar": {
      "alias": "statusBar";
      "required": false;
      "isSignal": true;
    };
    "copyable": {
      "alias": "copyable";
      "required": false;
      "isSignal": true;
    };
    "maximized": {
      "alias": "maximized";
      "required": false;
      "isSignal": true;
    };
    "preview": {
      "alias": "preview";
      "required": false;
      "isSignal": true;
    };
    "autoFormat": {
      "alias": "autoFormat";
      "required": false;
      "isSignal": true;
    };
    "tooltipPosition": {
      "alias": "tooltipPosition";
      "required": false;
      "isSignal": true;
    };
    "completions": {
      "alias": "completions";
      "required": false;
      "isSignal": true;
    };
    "diagnostics": {
      "alias": "diagnostics";
      "required": false;
      "isSignal": true;
    };
    "linter": {
      "alias": "linter";
      "required": false;
      "isSignal": true;
    };
    "formatter": {
      "alias": "formatter";
      "required": false;
      "isSignal": true;
    };
    "previewRenderer": {
      "alias": "previewRenderer";
      "required": false;
      "isSignal": true;
    };
    "copyHandler": {
      "alias": "copyHandler";
      "required": false;
      "isSignal": true;
    };
    "extensions": {
      "alias": "extensions";
      "required": false;
      "isSignal": true;
    };
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "locale": {
      "alias": "locale";
      "required": false;
      "isSignal": true;
    };
    "isFocused": {
      "alias": "isFocused";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "input": "input";
    "change": "change";
    "selectionChanged": "selectionChanged";
    "copied": "copied";
    "formatted": "formatted";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, [{
    directive: typeof i1.FormStatusHostDirective;
    inputs: {};
    outputs: {};
  }, {
    directive: typeof i1.FormFieldStatusHostDirective;
    inputs: {};
    outputs: {};
  }]>;
}
/**
 * Declares the methods available on CodeEditorComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type CodeEditorMethodNames = 'focus' | 'blur' | 'select' | 'goToLine' | 'insertText' | 'undo' | 'redo' | 'foldAll' | 'unfoldAll' | 'lint' | 'format' | 'copy' | 'openSearch' | 'closeSearch' | 'toggleSearch' | 'findNext' | 'findPrevious' | 'selectAllMatches' | 'replaceNext' | 'replaceAll' | 'toggleLineWrapping' | 'toggleMaximized' | 'togglePreview' | 'whenReady' | 'checkValidity' | 'reset';
/**
 * Declares the methods interface for CodeEditorComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type CodeEditorComponentMethods = MethodMap<CodeEditorMethodNames>;
/**
 * @public
 */
export declare function provideCodeEditorComponent(config?: Partial<CodeEditorElement.Props>, intl?: Partial<CodeEditorElement['intl']> | Type<Partial<CodeEditorElement['intl']>>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-code-editor.d.ts.map