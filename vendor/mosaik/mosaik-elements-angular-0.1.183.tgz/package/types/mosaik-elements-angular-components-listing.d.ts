import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { ListingItemMarkerElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/listing/ListingItemMarkerElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { ListingItemElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/listing/ListingItemElement";
import { ListingElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/listing/ListingElement";
/**
 * @public
 *
 * Injection token for the default properties of the ListingItemMarkerComponent.
 * Use this token to provide default properties for the ListingItemMarkerComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const LISTING_ITEM_MARKER_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").IListingItemMarkerElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ListingItemMarkerComponent {
  /**
   * Signal input for the `type` property.
   *
   * @public
   */
  readonly type: InputSignal<ListingItemMarkerElement['type'] | undefined>;
  /**
   * Signal input for the `numberingType` property.
   *
   * @public
   */
  readonly numberingType: InputSignal<ListingItemMarkerElement['numberingType'] | undefined>;
  /**
   * Signal input for the `bulletType` property.
   *
   * @public
   */
  readonly bulletType: InputSignal<ListingItemMarkerElement['bulletType'] | undefined>;
  /**
   * Signal input for the `index` property.
   *
   * @public
   */
  readonly index: InputSignal<ListingItemMarkerElement['index'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ListingItemMarkerElement['themeName'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<ListingItemMarkerElement['appearance'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<ListingItemMarkerElement['variant'] | undefined>;
  /**
   * Signal input for the `size` property.
   *
   * @public
   */
  readonly size: InputSignal<ListingItemMarkerElement['size'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<ListingItemMarkerElement['disabled'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ListingItemMarkerElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ListingItemMarkerElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ListingItemMarkerElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ListingItemMarkerElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ListingItemMarkerElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ListingItemMarkerElement>(property: TProperty, value: ListingItemMarkerElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ListingItemMarkerElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ListingItemMarkerComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ListingItemMarkerComponent, "mosaik-listing-item-marker", never, {
    "type": {
      "alias": "type";
      "required": false;
      "isSignal": true;
    };
    "numberingType": {
      "alias": "numberingType";
      "required": false;
      "isSignal": true;
    };
    "bulletType": {
      "alias": "bulletType";
      "required": false;
      "isSignal": true;
    };
    "index": {
      "alias": "index";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on ListingItemMarkerComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ListingItemMarkerMethodNames = never;
/**
 * Declares the methods interface for ListingItemMarkerComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ListingItemMarkerComponentMethods = MethodMap<ListingItemMarkerMethodNames>;
/**
 * @public
 */
export declare function provideListingItemMarkerComponent(config?: Partial<ListingItemMarkerElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the ListingItemComponent.
 * Use this token to provide default properties for the ListingItemComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const LISTING_ITEM_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").IListingItemElementProps>>;
/**
 * @public
 *
 * @slot  - Default slot for list item content.
 * @slot marker - Slot for a custom marker element. Defaults to an auto-configured `<mosaik-listing-item-marker>`.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ListingItemComponent {
  /**
   * Signal input for the `header` property.
   *
   * @public
   */
  readonly header: InputSignal<ListingItemElement['header'] | undefined>;
  /**
   * Signal input for the `content` property.
   *
   * @public
   */
  readonly content: InputSignal<ListingItemElement['content'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<ListingItemElement['value'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ListingItemElement['themeName'] | undefined>;
  /**
   * Signal input for the `formatter` property.
   *
   * @public
   */
  readonly formatter: InputSignal<ListingItemElement['formatter'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<ListingItemElement['appearance'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<ListingItemElement['variant'] | undefined>;
  /**
   * Signal input for the `size` property.
   *
   * @public
   */
  readonly size: InputSignal<ListingItemElement['size'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<ListingItemElement['disabled'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ListingItemElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ListingItemElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ListingItemElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ListingItemElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ListingItemElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ListingItemElement>(property: TProperty, value: ListingItemElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ListingItemElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ListingItemComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ListingItemComponent, "mosaik-listing-item", never, {
    "header": {
      "alias": "header";
      "required": false;
      "isSignal": true;
    };
    "content": {
      "alias": "content";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "formatter": {
      "alias": "formatter";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on ListingItemComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ListingItemMethodNames = never;
/**
 * Declares the methods interface for ListingItemComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ListingItemComponentMethods = MethodMap<ListingItemMethodNames>;
/**
 * @public
 */
export declare function provideListingItemComponent(config?: Partial<ListingItemElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the ListingComponent.
 * Use this token to provide default properties for the ListingComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const LISTING_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").IListingElementProps>>;
/**
 * @public
 *
 * @slot  - Default slot for `<mosaik-listing-item>` children.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ListingComponent {
  /**
   * Signal input for the `type` property.
   *
   * @public
   */
  readonly type: InputSignal<ListingElement['type'] | undefined>;
  /**
   * Signal input for the `numberingType` property.
   *
   * @public
   */
  readonly numberingType: InputSignal<ListingElement['numberingType'] | undefined>;
  /**
   * Signal input for the `bulletType` property.
   *
   * @public
   */
  readonly bulletType: InputSignal<ListingElement['bulletType'] | undefined>;
  /**
   * Signal input for the `reversed` property.
   *
   * @public
   */
  readonly reversed: InputSignal<ListingElement['reversed'] | undefined>;
  /**
   * Signal input for the `start` property.
   *
   * @public
   */
  readonly start: InputSignal<ListingElement['start'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ListingElement['themeName'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<ListingElement['appearance'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<ListingElement['variant'] | undefined>;
  /**
   * Signal input for the `size` property.
   *
   * @public
   */
  readonly size: InputSignal<ListingElement['size'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<ListingElement['disabled'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ListingElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ListingElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ListingElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ListingElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ListingElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ListingElement>(property: TProperty, value: ListingElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ListingElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ListingComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ListingComponent, "mosaik-listing", never, {
    "type": {
      "alias": "type";
      "required": false;
      "isSignal": true;
    };
    "numberingType": {
      "alias": "numberingType";
      "required": false;
      "isSignal": true;
    };
    "bulletType": {
      "alias": "bulletType";
      "required": false;
      "isSignal": true;
    };
    "reversed": {
      "alias": "reversed";
      "required": false;
      "isSignal": true;
    };
    "start": {
      "alias": "start";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on ListingComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ListingMethodNames = never;
/**
 * Declares the methods interface for ListingComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ListingComponentMethods = MethodMap<ListingMethodNames>;
/**
 * @public
 */
export declare function provideListingComponent(config?: Partial<ListingElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-listing.d.ts.map