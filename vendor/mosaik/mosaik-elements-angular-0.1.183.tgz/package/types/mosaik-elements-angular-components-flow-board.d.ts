import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { FlowBoardColumnComposerElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/flow-board/FlowBoardColumnComposerElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { FlowBoardColumnItemComposerElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/flow-board/FlowBoardColumnItemComposerElement";
import { FlowBoardColumnItemGroupElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/flow-board/FlowBoardColumnItemGroupElement";
import { FlowBoardColumnItemElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/flow-board/FlowBoardColumnItemElement";
import { FlowBoardColumnElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/flow-board/FlowBoardColumnElement";
import { FlowBoardElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/flow-board/FlowBoardElement";
/**
 * @public
 *
 * Injection token for the default properties of the FlowBoardColumnComposerComponent.
 * Use this token to provide default properties for the FlowBoardColumnComposerComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const FLOW_BOARD_COLUMN_COMPOSER_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/layouts/flow-board/IFlowBoardColumnComposerElementProps").IFlowBoardColumnComposerElementProps>>;
/**
 * @public
 *
 * @slot form - The form content for creating new columns (completely user-defined)
 * @slot trigger - The trigger element that opens the form (e.g., "Add another list" button)
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class FlowBoardColumnComposerComponent {
  /**
   * Signal input for the `open` property.
   *
   * @public
   */
  readonly open: InputSignal<FlowBoardColumnComposerElement['open'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<FlowBoardColumnComposerElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<FlowBoardColumnComposerElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<FlowBoardColumnComposerElement['lang'] | undefined>;
  /**
   * Output signal for the `flowBoardBeforeColumnCreate` event.
   *
   * @public
   */
  readonly flowBoardBeforeColumnCreate: OutputEmitterRef<ElementEventDetail<FlowBoardColumnComposerElement, 'flowBoardBeforeColumnCreate'>>;
  /**
   * Output signal for the `flowBoardColumnCreate` event.
   *
   * @public
   */
  readonly flowBoardColumnCreate: OutputEmitterRef<ElementEventDetail<FlowBoardColumnComposerElement, 'flowBoardColumnCreate'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<FlowBoardColumnComposerElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<FlowBoardColumnComposerElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<FlowBoardColumnComposerElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: FlowBoardColumnComposerElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: FlowBoardColumnComposerElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Creates a new column with the provided data.
   * Emits flowBoardBeforeColumnCreate (cancelable) and flowBoardColumnCreate events.
   *
   * @public
   * @param args - The arguments of `create`:
   * - `data` - The data for the new column (completely user-defined)
   * @returns True if created, false if canceled
   */
  create(...args: Parameters<FlowBoardColumnComposerElement['create']>): ReturnType<FlowBoardColumnComposerElement['create']>;
  /**
   * Toggles the composer between open and closed state.
   *
   * @public
   */
  toggle(...args: Parameters<FlowBoardColumnComposerElement['toggle']>): ReturnType<FlowBoardColumnComposerElement['toggle']>;
  /**
   * Closes the composer form.
   *
   * @public
   */
  close(...args: Parameters<FlowBoardColumnComposerElement['close']>): ReturnType<FlowBoardColumnComposerElement['close']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   * @param args - The arguments of `assignToSlot`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * - `node` - The nodes to assign to the slot.
   */
  assignToSlot(...args: Parameters<FlowBoardColumnComposerElement['assignToSlot']>): ReturnType<FlowBoardColumnComposerElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   * This method extracts text content recursively, including from Shadow DOMs
   * and Custom Elements with known text properties (like `mosaik-text`).
   *
   * @public
   * @param args - The arguments of `getSlotContent`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<FlowBoardColumnComposerElement['getSlotContent']>): ReturnType<FlowBoardColumnComposerElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @param args - The arguments of `hasSlotContent`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<FlowBoardColumnComposerElement['hasSlotContent']>): ReturnType<FlowBoardColumnComposerElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @param args - The arguments of `hasSlot`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<FlowBoardColumnComposerElement['hasSlot']>): ReturnType<FlowBoardColumnComposerElement['hasSlot']>;
  /**
   * Called when the slot changes.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<FlowBoardColumnComposerElement['onSlotChanges']>): ReturnType<FlowBoardColumnComposerElement['onSlotChanges']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `create()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends FlowBoardColumnComposerMethodNames>(method: TMethod, ...args: Parameters<FlowBoardColumnComposerComponentMethods[TMethod]>): ReturnType<FlowBoardColumnComposerComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof FlowBoardColumnComposerElement>(property: TProperty, value: FlowBoardColumnComposerElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<FlowBoardColumnComposerElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<FlowBoardColumnComposerComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<FlowBoardColumnComposerComponent, "mosaik-flow-board-column-composer", never, {
    "open": {
      "alias": "open";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "flowBoardBeforeColumnCreate": "flowBoardBeforeColumnCreate";
    "flowBoardColumnCreate": "flowBoardColumnCreate";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on FlowBoardColumnComposerComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FlowBoardColumnComposerMethodNames = 'create' | 'toggle' | 'close' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges';
/**
 * Declares the methods interface for FlowBoardColumnComposerComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FlowBoardColumnComposerComponentMethods = MethodMap<FlowBoardColumnComposerMethodNames>;
/**
 * @public
 */
export declare function provideFlowBoardColumnComposerComponent(config?: Partial<FlowBoardColumnComposerElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the FlowBoardColumnItemComposerComponent.
 * Use this token to provide default properties for the FlowBoardColumnItemComposerComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const FLOW_BOARD_COLUMN_ITEM_COMPOSER_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/layouts/flow-board/IFlowBoardColumnItemComposerElementProps").IFlowBoardColumnItemComposerElementProps>>;
/**
 * @public
 *
 * @slot form - The form content for creating new items (completely user-defined)
 * @slot trigger - The trigger element that opens the form (e.g., "Add another item" button)
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class FlowBoardColumnItemComposerComponent {
  /**
   * Signal input for the `open` property.
   *
   * @public
   */
  readonly open: InputSignal<FlowBoardColumnItemComposerElement['open'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<FlowBoardColumnItemComposerElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<FlowBoardColumnItemComposerElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<FlowBoardColumnItemComposerElement['lang'] | undefined>;
  /**
   * Output signal for the `flowBoardBeforeItemCreate` event.
   *
   * @public
   */
  readonly flowBoardBeforeItemCreate: OutputEmitterRef<ElementEventDetail<FlowBoardColumnItemComposerElement, 'flowBoardBeforeItemCreate'>>;
  /**
   * Output signal for the `flowBoardItemCreate` event.
   *
   * @public
   */
  readonly flowBoardItemCreate: OutputEmitterRef<ElementEventDetail<FlowBoardColumnItemComposerElement, 'flowBoardItemCreate'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<FlowBoardColumnItemComposerElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<FlowBoardColumnItemComposerElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<FlowBoardColumnItemComposerElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: FlowBoardColumnItemComposerElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: FlowBoardColumnItemComposerElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Creates a new item with the provided data.
   * Emits flowBoardBeforeItemCreate (cancelable) and flowBoardItemCreate events.
   *
   * @public
   * @param args - The arguments of `create`:
   * - `data` - The data for the new item (completely user-defined)
   * @returns True if created, false if canceled
   */
  create(...args: Parameters<FlowBoardColumnItemComposerElement['create']>): ReturnType<FlowBoardColumnItemComposerElement['create']>;
  /**
   * Toggles the composer between open and closed state.
   *
   * @public
   */
  toggle(...args: Parameters<FlowBoardColumnItemComposerElement['toggle']>): ReturnType<FlowBoardColumnItemComposerElement['toggle']>;
  /**
   * Closes the composer form.
   *
   * @public
   */
  close(...args: Parameters<FlowBoardColumnItemComposerElement['close']>): ReturnType<FlowBoardColumnItemComposerElement['close']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   * @param args - The arguments of `assignToSlot`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * - `node` - The nodes to assign to the slot.
   */
  assignToSlot(...args: Parameters<FlowBoardColumnItemComposerElement['assignToSlot']>): ReturnType<FlowBoardColumnItemComposerElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   * This method extracts text content recursively, including from Shadow DOMs
   * and Custom Elements with known text properties (like `mosaik-text`).
   *
   * @public
   * @param args - The arguments of `getSlotContent`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<FlowBoardColumnItemComposerElement['getSlotContent']>): ReturnType<FlowBoardColumnItemComposerElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @param args - The arguments of `hasSlotContent`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<FlowBoardColumnItemComposerElement['hasSlotContent']>): ReturnType<FlowBoardColumnItemComposerElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @param args - The arguments of `hasSlot`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<FlowBoardColumnItemComposerElement['hasSlot']>): ReturnType<FlowBoardColumnItemComposerElement['hasSlot']>;
  /**
   * Called when the slot changes.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<FlowBoardColumnItemComposerElement['onSlotChanges']>): ReturnType<FlowBoardColumnItemComposerElement['onSlotChanges']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `create()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends FlowBoardColumnItemComposerMethodNames>(method: TMethod, ...args: Parameters<FlowBoardColumnItemComposerComponentMethods[TMethod]>): ReturnType<FlowBoardColumnItemComposerComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof FlowBoardColumnItemComposerElement>(property: TProperty, value: FlowBoardColumnItemComposerElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<FlowBoardColumnItemComposerElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<FlowBoardColumnItemComposerComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<FlowBoardColumnItemComposerComponent, "mosaik-flow-board-column-item-composer", never, {
    "open": {
      "alias": "open";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "flowBoardBeforeItemCreate": "flowBoardBeforeItemCreate";
    "flowBoardItemCreate": "flowBoardItemCreate";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on FlowBoardColumnItemComposerComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FlowBoardColumnItemComposerMethodNames = 'create' | 'toggle' | 'close' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges';
/**
 * Declares the methods interface for FlowBoardColumnItemComposerComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FlowBoardColumnItemComposerComponentMethods = MethodMap<FlowBoardColumnItemComposerMethodNames>;
/**
 * @public
 */
export declare function provideFlowBoardColumnItemComposerComponent(config?: Partial<FlowBoardColumnItemComposerElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the FlowBoardColumnItemGroupComponent.
 * Use this token to provide default properties for the FlowBoardColumnItemGroupComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const FLOW_BOARD_COLUMN_ITEM_GROUP_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/layouts/flow-board/IFlowBoardColumnItemGroupElementProps").IFlowBoardColumnItemGroupElementProps>>;
/**
 * @public
 *
 * @slot  - Additional grouped items kept compact and non-interactive
 * @slot actions - Actions for the group as one board entry
 * @slot root - The item represented by rootItemKey and shown at the front of the stack
 * @slot eyebrow - Compact context shown above the title and beside the selection control
 * @slot footer - Footer content with actions or avatars
 * @slot meta - Additional metadata like price or status
 * @slot subtitle - The subtitle content of the item
 * @slot title - The title content of the item
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class FlowBoardColumnItemGroupComponent {
  /**
   * Signal input for the `groupKey` property.
   *
   * @public
   */
  readonly groupKey: InputSignal<FlowBoardColumnItemGroupElement['groupKey'] | undefined>;
  /**
   * Signal input for the `rootItemKey` property.
   *
   * @public
   */
  readonly rootItemKey: InputSignal<FlowBoardColumnItemGroupElement['rootItemKey'] | undefined>;
  /**
   * Signal input for the `stacking` property.
   *
   * @public
   */
  readonly stacking: InputSignal<FlowBoardColumnItemGroupElement['stacking'] | undefined>;
  /**
   * Signal input for the `maxStackDepth` property.
   *
   * @public
   */
  readonly maxStackDepth: InputSignal<FlowBoardColumnItemGroupElement['maxStackDepth'] | undefined>;
  /**
   * Signal input for the `revealTrigger` property.
   *
   * @public
   */
  readonly revealTrigger: InputSignal<FlowBoardColumnItemGroupElement['revealTrigger'] | undefined>;
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<FlowBoardColumnItemGroupElement['intl'] | undefined>;
  /**
   * Signal input for the `itemKey` property.
   *
   * @public
   */
  readonly itemKey: InputSignal<FlowBoardColumnItemGroupElement['itemKey'] | undefined>;
  /**
   * Signal input for the `draggable` property.
   *
   * @public
   */
  readonly draggable: InputSignal<FlowBoardColumnItemGroupElement['draggable'] | undefined>;
  /**
   * Signal input for the `reorderable` property.
   *
   * @public
   */
  readonly reorderable: InputSignal<FlowBoardColumnItemGroupElement['reorderable'] | undefined>;
  /**
   * Signal input for the `pinned` property.
   *
   * @public
   */
  readonly pinned: InputSignal<FlowBoardColumnItemGroupElement['pinned'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<FlowBoardColumnItemGroupElement['themeName'] | undefined>;
  /**
   * Signal input for the `ripple` property.
   *
   * @public
   */
  readonly ripple: InputSignal<FlowBoardColumnItemGroupElement['ripple'] | undefined>;
  /**
   * Signal input for the `isFocused` property.
   *
   * @public
   */
  readonly isFocused: InputSignal<FlowBoardColumnItemGroupElement['isFocused'] | undefined>;
  /**
   * Signal input for the `isSelected` property.
   *
   * @public
   */
  readonly isSelected: InputSignal<FlowBoardColumnItemGroupElement['isSelected'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<FlowBoardColumnItemGroupElement['disabled'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<FlowBoardColumnItemGroupElement['variant'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<FlowBoardColumnItemGroupElement['value'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<FlowBoardColumnItemGroupElement['appearance'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<FlowBoardColumnItemGroupElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<FlowBoardColumnItemGroupElement['lang'] | undefined>;
  /**
   * Output signal for the `flowBoardBeforeItemActivate` event.
   *
   * @public
   */
  readonly flowBoardBeforeItemActivate: OutputEmitterRef<ElementEventDetail<FlowBoardColumnItemGroupElement, 'flowBoardBeforeItemActivate'>>;
  /**
   * Output signal for the `flowBoardItemActivate` event.
   *
   * @public
   */
  readonly flowBoardItemActivate: OutputEmitterRef<ElementEventDetail<FlowBoardColumnItemGroupElement, 'flowBoardItemActivate'>>;
  /**
   * Output signal for the `flowBoardBeforeItemPinChange` event.
   *
   * @public
   */
  readonly flowBoardBeforeItemPinChange: OutputEmitterRef<ElementEventDetail<FlowBoardColumnItemGroupElement, 'flowBoardBeforeItemPinChange'>>;
  /**
   * Output signal for the `flowBoardItemPinChange` event.
   *
   * @public
   */
  readonly flowBoardItemPinChange: OutputEmitterRef<ElementEventDetail<FlowBoardColumnItemGroupElement, 'flowBoardItemPinChange'>>;
  /**
   * Output signal for the `selected` event.
   *
   * @public
   */
  readonly selected: OutputEmitterRef<ElementEventDetail<FlowBoardColumnItemGroupElement, 'selected'>>;
  /**
   * Output signal for the `deselected` event.
   *
   * @public
   */
  readonly deselected: OutputEmitterRef<ElementEventDetail<FlowBoardColumnItemGroupElement, 'deselected'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<FlowBoardColumnItemGroupElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<FlowBoardColumnItemGroupElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<FlowBoardColumnItemGroupElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: FlowBoardColumnItemGroupElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: FlowBoardColumnItemGroupElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Expands the group so its members become visible and operable.
   *
   * @public
   */
  expand(...args: Parameters<FlowBoardColumnItemGroupElement['expand']>): ReturnType<FlowBoardColumnItemGroupElement['expand']>;
  /**
   * Collapses the group back into a pile.
   *
   * @public
   */
  collapse(...args: Parameters<FlowBoardColumnItemGroupElement['collapse']>): ReturnType<FlowBoardColumnItemGroupElement['collapse']>;
  /**
   * Suppresses the reveal, for instance for the duration of a drag.
   *
   * @public
   * @param args - The arguments of `suppressReveal`:
   * - `suppress` - Whether the reveal is suppressed.
   */
  suppressReveal(...args: Parameters<FlowBoardColumnItemGroupElement['suppressReveal']>): ReturnType<FlowBoardColumnItemGroupElement['suppressReveal']>;
  /**
   * Activates the item, triggering the appropriate events.
   *
   * @public
   * @param args - The arguments of `activate`:
   * - `trigger` - The trigger for the activation.
   */
  activate(...args: Parameters<FlowBoardColumnItemGroupElement['activate']>): ReturnType<FlowBoardColumnItemGroupElement['activate']>;
  /**
   * Pins the item, making it fixed at the top of the column.
   *
   * @public
   */
  pin(...args: Parameters<FlowBoardColumnItemGroupElement['pin']>): ReturnType<FlowBoardColumnItemGroupElement['pin']>;
  /**
   * Unpins the item, allowing it to be reordered with other items.
   *
   * @public
   */
  unpin(...args: Parameters<FlowBoardColumnItemGroupElement['unpin']>): ReturnType<FlowBoardColumnItemGroupElement['unpin']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   * @param args - The arguments of `assignToSlot`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * - `node` - The nodes to assign to the slot.
   */
  assignToSlot(...args: Parameters<FlowBoardColumnItemGroupElement['assignToSlot']>): ReturnType<FlowBoardColumnItemGroupElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   * This method extracts text content recursively, including from Shadow DOMs
   * and Custom Elements with known text properties (like `mosaik-text`).
   *
   * @public
   * @param args - The arguments of `getSlotContent`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<FlowBoardColumnItemGroupElement['getSlotContent']>): ReturnType<FlowBoardColumnItemGroupElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @param args - The arguments of `hasSlotContent`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<FlowBoardColumnItemGroupElement['hasSlotContent']>): ReturnType<FlowBoardColumnItemGroupElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @param args - The arguments of `hasSlot`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<FlowBoardColumnItemGroupElement['hasSlot']>): ReturnType<FlowBoardColumnItemGroupElement['hasSlot']>;
  /**
   * Called when the slot changes.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<FlowBoardColumnItemGroupElement['onSlotChanges']>): ReturnType<FlowBoardColumnItemGroupElement['onSlotChanges']>;
  /**
   * Selects the element.
   *
   * @public
   */
  select(...args: Parameters<FlowBoardColumnItemGroupElement['select']>): ReturnType<FlowBoardColumnItemGroupElement['select']>;
  /**
   * Deselects the element.
   *
   * @public
   */
  deselect(...args: Parameters<FlowBoardColumnItemGroupElement['deselect']>): ReturnType<FlowBoardColumnItemGroupElement['deselect']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `expand()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends FlowBoardColumnItemGroupMethodNames>(method: TMethod, ...args: Parameters<FlowBoardColumnItemGroupComponentMethods[TMethod]>): ReturnType<FlowBoardColumnItemGroupComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof FlowBoardColumnItemGroupElement>(property: TProperty, value: FlowBoardColumnItemGroupElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<FlowBoardColumnItemGroupElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<FlowBoardColumnItemGroupComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<FlowBoardColumnItemGroupComponent, "mosaik-flow-board-column-item-group", never, {
    "groupKey": {
      "alias": "groupKey";
      "required": false;
      "isSignal": true;
    };
    "rootItemKey": {
      "alias": "rootItemKey";
      "required": false;
      "isSignal": true;
    };
    "stacking": {
      "alias": "stacking";
      "required": false;
      "isSignal": true;
    };
    "maxStackDepth": {
      "alias": "maxStackDepth";
      "required": false;
      "isSignal": true;
    };
    "revealTrigger": {
      "alias": "revealTrigger";
      "required": false;
      "isSignal": true;
    };
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "itemKey": {
      "alias": "itemKey";
      "required": false;
      "isSignal": true;
    };
    "draggable": {
      "alias": "draggable";
      "required": false;
      "isSignal": true;
    };
    "reorderable": {
      "alias": "reorderable";
      "required": false;
      "isSignal": true;
    };
    "pinned": {
      "alias": "pinned";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "ripple": {
      "alias": "ripple";
      "required": false;
      "isSignal": true;
    };
    "isFocused": {
      "alias": "isFocused";
      "required": false;
      "isSignal": true;
    };
    "isSelected": {
      "alias": "isSelected";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "flowBoardBeforeItemActivate": "flowBoardBeforeItemActivate";
    "flowBoardItemActivate": "flowBoardItemActivate";
    "flowBoardBeforeItemPinChange": "flowBoardBeforeItemPinChange";
    "flowBoardItemPinChange": "flowBoardItemPinChange";
    "selected": "selected";
    "deselected": "deselected";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on FlowBoardColumnItemGroupComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FlowBoardColumnItemGroupMethodNames = 'expand' | 'collapse' | 'suppressReveal' | 'activate' | 'pin' | 'unpin' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges' | 'select' | 'deselect';
/**
 * Declares the methods interface for FlowBoardColumnItemGroupComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FlowBoardColumnItemGroupComponentMethods = MethodMap<FlowBoardColumnItemGroupMethodNames>;
/**
 * @public
 */
export declare function provideFlowBoardColumnItemGroupComponent(config?: Partial<FlowBoardColumnItemGroupElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the FlowBoardColumnItemComponent.
 * Use this token to provide default properties for the FlowBoardColumnItemComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const FLOW_BOARD_COLUMN_ITEM_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/layouts/flow-board/IFlowBoardColumnItemElementProps").IFlowBoardColumnItemElementProps>>;
/**
 * @public
 *
 * @slot  - Custom card content, kept in the item's light DOM while the item is dragged
 * @slot actions - Action buttons or links related to the item
 * @slot eyebrow - Compact context shown above the title and beside the selection control
 * @slot footer - Footer content with actions or avatars
 * @slot meta - Additional metadata like price or status
 * @slot subtitle - The subtitle content of the item
 * @slot title - The title content of the item
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class FlowBoardColumnItemComponent {
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<FlowBoardColumnItemElement['intl'] | undefined>;
  /**
   * Signal input for the `itemKey` property.
   *
   * @public
   */
  readonly itemKey: InputSignal<FlowBoardColumnItemElement['itemKey'] | undefined>;
  /**
   * Signal input for the `draggable` property.
   *
   * @public
   */
  readonly draggable: InputSignal<FlowBoardColumnItemElement['draggable'] | undefined>;
  /**
   * Signal input for the `reorderable` property.
   *
   * @public
   */
  readonly reorderable: InputSignal<FlowBoardColumnItemElement['reorderable'] | undefined>;
  /**
   * Signal input for the `pinned` property.
   *
   * @public
   */
  readonly pinned: InputSignal<FlowBoardColumnItemElement['pinned'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<FlowBoardColumnItemElement['themeName'] | undefined>;
  /**
   * Signal input for the `ripple` property.
   *
   * @public
   */
  readonly ripple: InputSignal<FlowBoardColumnItemElement['ripple'] | undefined>;
  /**
   * Signal input for the `isFocused` property.
   *
   * @public
   */
  readonly isFocused: InputSignal<FlowBoardColumnItemElement['isFocused'] | undefined>;
  /**
   * Signal input for the `isSelected` property.
   *
   * @public
   */
  readonly isSelected: InputSignal<FlowBoardColumnItemElement['isSelected'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<FlowBoardColumnItemElement['disabled'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<FlowBoardColumnItemElement['variant'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<FlowBoardColumnItemElement['value'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<FlowBoardColumnItemElement['appearance'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<FlowBoardColumnItemElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<FlowBoardColumnItemElement['lang'] | undefined>;
  /**
   * Output signal for the `flowBoardBeforeItemActivate` event.
   *
   * @public
   */
  readonly flowBoardBeforeItemActivate: OutputEmitterRef<ElementEventDetail<FlowBoardColumnItemElement, 'flowBoardBeforeItemActivate'>>;
  /**
   * Output signal for the `flowBoardItemActivate` event.
   *
   * @public
   */
  readonly flowBoardItemActivate: OutputEmitterRef<ElementEventDetail<FlowBoardColumnItemElement, 'flowBoardItemActivate'>>;
  /**
   * Output signal for the `flowBoardBeforeItemPinChange` event.
   *
   * @public
   */
  readonly flowBoardBeforeItemPinChange: OutputEmitterRef<ElementEventDetail<FlowBoardColumnItemElement, 'flowBoardBeforeItemPinChange'>>;
  /**
   * Output signal for the `flowBoardItemPinChange` event.
   *
   * @public
   */
  readonly flowBoardItemPinChange: OutputEmitterRef<ElementEventDetail<FlowBoardColumnItemElement, 'flowBoardItemPinChange'>>;
  /**
   * Output signal for the `selected` event.
   *
   * @public
   */
  readonly selected: OutputEmitterRef<ElementEventDetail<FlowBoardColumnItemElement, 'selected'>>;
  /**
   * Output signal for the `deselected` event.
   *
   * @public
   */
  readonly deselected: OutputEmitterRef<ElementEventDetail<FlowBoardColumnItemElement, 'deselected'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<FlowBoardColumnItemElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<FlowBoardColumnItemElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<FlowBoardColumnItemElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: FlowBoardColumnItemElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: FlowBoardColumnItemElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Activates the item, triggering the appropriate events.
   *
   * @public
   * @param args - The arguments of `activate`:
   * - `trigger` - The trigger for the activation.
   */
  activate(...args: Parameters<FlowBoardColumnItemElement['activate']>): ReturnType<FlowBoardColumnItemElement['activate']>;
  /**
   * Pins the item, making it fixed at the top of the column.
   *
   * @public
   */
  pin(...args: Parameters<FlowBoardColumnItemElement['pin']>): ReturnType<FlowBoardColumnItemElement['pin']>;
  /**
   * Unpins the item, allowing it to be reordered with other items.
   *
   * @public
   */
  unpin(...args: Parameters<FlowBoardColumnItemElement['unpin']>): ReturnType<FlowBoardColumnItemElement['unpin']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   * @param args - The arguments of `assignToSlot`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * - `node` - The nodes to assign to the slot.
   */
  assignToSlot(...args: Parameters<FlowBoardColumnItemElement['assignToSlot']>): ReturnType<FlowBoardColumnItemElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   * This method extracts text content recursively, including from Shadow DOMs
   * and Custom Elements with known text properties (like `mosaik-text`).
   *
   * @public
   * @param args - The arguments of `getSlotContent`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<FlowBoardColumnItemElement['getSlotContent']>): ReturnType<FlowBoardColumnItemElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @param args - The arguments of `hasSlotContent`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<FlowBoardColumnItemElement['hasSlotContent']>): ReturnType<FlowBoardColumnItemElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @param args - The arguments of `hasSlot`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<FlowBoardColumnItemElement['hasSlot']>): ReturnType<FlowBoardColumnItemElement['hasSlot']>;
  /**
   * Called when the slot changes.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<FlowBoardColumnItemElement['onSlotChanges']>): ReturnType<FlowBoardColumnItemElement['onSlotChanges']>;
  /**
   * Selects the element.
   *
   * @public
   */
  select(...args: Parameters<FlowBoardColumnItemElement['select']>): ReturnType<FlowBoardColumnItemElement['select']>;
  /**
   * Deselects the element.
   *
   * @public
   */
  deselect(...args: Parameters<FlowBoardColumnItemElement['deselect']>): ReturnType<FlowBoardColumnItemElement['deselect']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `activate()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends FlowBoardColumnItemMethodNames>(method: TMethod, ...args: Parameters<FlowBoardColumnItemComponentMethods[TMethod]>): ReturnType<FlowBoardColumnItemComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof FlowBoardColumnItemElement>(property: TProperty, value: FlowBoardColumnItemElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<FlowBoardColumnItemElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<FlowBoardColumnItemComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<FlowBoardColumnItemComponent, "mosaik-flow-board-column-item", never, {
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "itemKey": {
      "alias": "itemKey";
      "required": false;
      "isSignal": true;
    };
    "draggable": {
      "alias": "draggable";
      "required": false;
      "isSignal": true;
    };
    "reorderable": {
      "alias": "reorderable";
      "required": false;
      "isSignal": true;
    };
    "pinned": {
      "alias": "pinned";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "ripple": {
      "alias": "ripple";
      "required": false;
      "isSignal": true;
    };
    "isFocused": {
      "alias": "isFocused";
      "required": false;
      "isSignal": true;
    };
    "isSelected": {
      "alias": "isSelected";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "flowBoardBeforeItemActivate": "flowBoardBeforeItemActivate";
    "flowBoardItemActivate": "flowBoardItemActivate";
    "flowBoardBeforeItemPinChange": "flowBoardBeforeItemPinChange";
    "flowBoardItemPinChange": "flowBoardItemPinChange";
    "selected": "selected";
    "deselected": "deselected";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on FlowBoardColumnItemComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FlowBoardColumnItemMethodNames = 'activate' | 'pin' | 'unpin' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges' | 'select' | 'deselect';
/**
 * Declares the methods interface for FlowBoardColumnItemComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FlowBoardColumnItemComponentMethods = MethodMap<FlowBoardColumnItemMethodNames>;
/**
 * @public
 */
export declare function provideFlowBoardColumnItemComponent(config?: Partial<FlowBoardColumnItemElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the FlowBoardColumnComponent.
 * Use this token to provide default properties for the FlowBoardColumnComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const FLOW_BOARD_COLUMN_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/layouts/flow-board/IFlowBoardColumnElementProps").IFlowBoardColumnElementProps>>;
/**
 * @public
 *
 * @slot  - Default slot for FlowBoardColumnItem elements
 * @slot actions - Action buttons for the column
 * @slot empty - Content to show when the column has no items
 * @slot footer - Footer content (usually contains a composer)
 * @slot meta - Metadata content (badges, counts, KPIs); overrides the optional automatic item count
 * @slot title - The title content of the column header
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class FlowBoardColumnComponent {
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<FlowBoardColumnElement['intl'] | undefined>;
  /**
   * Signal input for the `columnKey` property.
   *
   * @public
   */
  readonly columnKey: InputSignal<FlowBoardColumnElement['columnKey'] | undefined>;
  /**
   * Signal input for the `reorderable` property.
   *
   * @public
   */
  readonly reorderable: InputSignal<FlowBoardColumnElement['reorderable'] | undefined>;
  /**
   * Signal input for the `pinned` property.
   *
   * @public
   */
  readonly pinned: InputSignal<FlowBoardColumnElement['pinned'] | undefined>;
  /**
   * Signal input for the `collapsible` property.
   *
   * @public
   */
  readonly collapsible: InputSignal<FlowBoardColumnElement['collapsible'] | undefined>;
  /**
   * Signal input for the `showItemCount` property.
   *
   * @public
   */
  readonly showItemCount: InputSignal<FlowBoardColumnElement['showItemCount'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<FlowBoardColumnElement['themeName'] | undefined>;
  /**
   * Signal input for the `isExpanded` property.
   *
   * @public
   */
  readonly isExpanded: InputSignal<FlowBoardColumnElement['isExpanded'] | undefined>;
  /**
   * Signal input for the `expanded` property.
   *
   * @public
   */
  readonly expanded: InputSignal<FlowBoardColumnElement['expanded'] | undefined>;
  /**
   * Signal input for the `collapsed` property.
   *
   * @public
   */
  readonly collapsed: InputSignal<FlowBoardColumnElement['collapsed'] | undefined>;
  /**
   * Signal input for the `toggled` property.
   *
   * @public
   */
  readonly toggled: InputSignal<FlowBoardColumnElement['toggled'] | undefined>;
  /**
   * Signal input for the `showScrollButtons` property.
   *
   * @public
   */
  readonly showScrollButtons: InputSignal<FlowBoardColumnElement['showScrollButtons'] | undefined>;
  /**
   * Signal input for the `showScrollbar` property.
   *
   * @public
   */
  readonly showScrollbar: InputSignal<FlowBoardColumnElement['showScrollbar'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<FlowBoardColumnElement['disabled'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<FlowBoardColumnElement['appearance'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<FlowBoardColumnElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<FlowBoardColumnElement['lang'] | undefined>;
  /**
   * Output signal for the `flowBoardBeforeColumnPinChange` event.
   *
   * @public
   */
  readonly flowBoardBeforeColumnPinChange: OutputEmitterRef<ElementEventDetail<FlowBoardColumnElement, 'flowBoardBeforeColumnPinChange'>>;
  /**
   * Output signal for the `flowBoardColumnPinChange` event.
   *
   * @public
   */
  readonly flowBoardColumnPinChange: OutputEmitterRef<ElementEventDetail<FlowBoardColumnElement, 'flowBoardColumnPinChange'>>;
  /**
   * Output signal for the `flowBoardBeforeColumnExpandChange` event.
   *
   * @public
   */
  readonly flowBoardBeforeColumnExpandChange: OutputEmitterRef<ElementEventDetail<FlowBoardColumnElement, 'flowBoardBeforeColumnExpandChange'>>;
  /**
   * Output signal for the `flowBoardColumnExpandChange` event.
   *
   * @public
   */
  readonly flowBoardColumnExpandChange: OutputEmitterRef<ElementEventDetail<FlowBoardColumnElement, 'flowBoardColumnExpandChange'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<FlowBoardColumnElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<FlowBoardColumnElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<FlowBoardColumnElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: FlowBoardColumnElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: FlowBoardColumnElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Returns the scrollable viewport of the column body, which is owned by the
   * internal scroll primitive rather than by the column element itself.
   *
   * @public
   */
  getScrollableElement(...args: Parameters<FlowBoardColumnElement['getScrollableElement']>): ReturnType<FlowBoardColumnElement['getScrollableElement']>;
  /**
   * Gets all item elements in this column.
   *
   * @public
   * @returns Array of FlowBoardColumnItemElement.
   */
  getItems(...args: Parameters<FlowBoardColumnElement['getItems']>): ReturnType<FlowBoardColumnElement['getItems']>;
  /**
   * Gets the pinned items in this column.
   *
   * @public
   * @returns Array of pinned FlowBoardColumnItemElement.
   */
  getPinnedItems(...args: Parameters<FlowBoardColumnElement['getPinnedItems']>): ReturnType<FlowBoardColumnElement['getPinnedItems']>;
  /**
   * Gets the non-pinned items in this column.
   *
   * @public
   * @returns Array of non-pinned FlowBoardColumnItemElement.
   */
  getNonPinnedItems(...args: Parameters<FlowBoardColumnElement['getNonPinnedItems']>): ReturnType<FlowBoardColumnElement['getNonPinnedItems']>;
  /**
   * Sets the pinned state with event support.
   *
   * @public
   * @param args - The arguments of `setPinned`:
   * - `pinned` - The new pinned state.
   */
  setPinned(...args: Parameters<FlowBoardColumnElement['setPinned']>): ReturnType<FlowBoardColumnElement['setPinned']>;
  /**
   * Expands the element.
   *
   * @public
   */
  expand(...args: Parameters<FlowBoardColumnElement['expand']>): ReturnType<FlowBoardColumnElement['expand']>;
  /**
   * Collapses the element.
   *
   * @public
   */
  collapse(...args: Parameters<FlowBoardColumnElement['collapse']>): ReturnType<FlowBoardColumnElement['collapse']>;
  /**
   * Toggles the element between expanded and collapsed states.
   *
   * @public
   */
  toggle(...args: Parameters<FlowBoardColumnElement['toggle']>): ReturnType<FlowBoardColumnElement['toggle']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   * @param args - The arguments of `assignToSlot`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * - `node` - The nodes to assign to the slot.
   */
  assignToSlot(...args: Parameters<FlowBoardColumnElement['assignToSlot']>): ReturnType<FlowBoardColumnElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   * This method extracts text content recursively, including from Shadow DOMs
   * and Custom Elements with known text properties (like `mosaik-text`).
   *
   * @public
   * @param args - The arguments of `getSlotContent`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<FlowBoardColumnElement['getSlotContent']>): ReturnType<FlowBoardColumnElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @param args - The arguments of `hasSlotContent`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<FlowBoardColumnElement['hasSlotContent']>): ReturnType<FlowBoardColumnElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @param args - The arguments of `hasSlot`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<FlowBoardColumnElement['hasSlot']>): ReturnType<FlowBoardColumnElement['hasSlot']>;
  /**
   * Called when the slot changes.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<FlowBoardColumnElement['onSlotChanges']>): ReturnType<FlowBoardColumnElement['onSlotChanges']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `getScrollableElement()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends FlowBoardColumnMethodNames>(method: TMethod, ...args: Parameters<FlowBoardColumnComponentMethods[TMethod]>): ReturnType<FlowBoardColumnComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof FlowBoardColumnElement>(property: TProperty, value: FlowBoardColumnElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<FlowBoardColumnElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<FlowBoardColumnComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<FlowBoardColumnComponent, "mosaik-flow-board-column", never, {
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "columnKey": {
      "alias": "columnKey";
      "required": false;
      "isSignal": true;
    };
    "reorderable": {
      "alias": "reorderable";
      "required": false;
      "isSignal": true;
    };
    "pinned": {
      "alias": "pinned";
      "required": false;
      "isSignal": true;
    };
    "collapsible": {
      "alias": "collapsible";
      "required": false;
      "isSignal": true;
    };
    "showItemCount": {
      "alias": "showItemCount";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "isExpanded": {
      "alias": "isExpanded";
      "required": false;
      "isSignal": true;
    };
    "expanded": {
      "alias": "expanded";
      "required": false;
      "isSignal": true;
    };
    "collapsed": {
      "alias": "collapsed";
      "required": false;
      "isSignal": true;
    };
    "toggled": {
      "alias": "toggled";
      "required": false;
      "isSignal": true;
    };
    "showScrollButtons": {
      "alias": "showScrollButtons";
      "required": false;
      "isSignal": true;
    };
    "showScrollbar": {
      "alias": "showScrollbar";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "flowBoardBeforeColumnPinChange": "flowBoardBeforeColumnPinChange";
    "flowBoardColumnPinChange": "flowBoardColumnPinChange";
    "flowBoardBeforeColumnExpandChange": "flowBoardBeforeColumnExpandChange";
    "flowBoardColumnExpandChange": "flowBoardColumnExpandChange";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on FlowBoardColumnComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FlowBoardColumnMethodNames = 'getScrollableElement' | 'getItems' | 'getPinnedItems' | 'getNonPinnedItems' | 'setPinned' | 'expand' | 'collapse' | 'toggle' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges';
/**
 * Declares the methods interface for FlowBoardColumnComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FlowBoardColumnComponentMethods = MethodMap<FlowBoardColumnMethodNames>;
/**
 * @public
 */
export declare function provideFlowBoardColumnComponent(config?: Partial<FlowBoardColumnElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the FlowBoardComponent.
 * Use this token to provide default properties for the FlowBoardComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const FLOW_BOARD_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/layouts/flow-board/IFlowBoardElementProps").IFlowBoardElementProps>>;
/**
 * @public
 *
 * @slot  - Default slot for mosaik-flow-board-column elements
 * @slot append - Slot for add column action (mosaik-flow-board-column-composer)
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class FlowBoardComponent {
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<FlowBoardElement['intl'] | undefined>;
  /**
   * Signal input for the `displayMode` property.
   *
   * @public
   */
  readonly displayMode: InputSignal<FlowBoardElement['displayMode'] | undefined>;
  /**
   * Signal input for the `dragdrop` property.
   *
   * @public
   */
  readonly dragdrop: InputSignal<FlowBoardElement['dragdrop'] | undefined>;
  /**
   * Signal input for the `mutationMode` property.
   *
   * @public
   */
  readonly mutationMode: InputSignal<FlowBoardElement['mutationMode'] | undefined>;
  /**
   * Signal input for the `selectionMode` property.
   *
   * @public
   */
  readonly selectionMode: InputSignal<FlowBoardElement['selectionMode'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<FlowBoardElement['themeName'] | undefined>;
  /**
   * Signal input for the `size` property.
   *
   * @public
   */
  readonly size: InputSignal<FlowBoardElement['size'] | undefined>;
  /**
   * Signal input for the `gap` property.
   *
   * @public
   */
  readonly gap: InputSignal<FlowBoardElement['gap'] | undefined>;
  /**
   * Signal input for the `isFocused` property.
   *
   * @public
   */
  readonly isFocused: InputSignal<FlowBoardElement['isFocused'] | undefined>;
  /**
   * Signal input for the `showScrollButtons` property.
   *
   * @public
   */
  readonly showScrollButtons: InputSignal<FlowBoardElement['showScrollButtons'] | undefined>;
  /**
   * Signal input for the `showScrollbar` property.
   *
   * @public
   */
  readonly showScrollbar: InputSignal<FlowBoardElement['showScrollbar'] | undefined>;
  /**
   * Signal input for the `orientation` property.
   *
   * @public
   */
  readonly orientation: InputSignal<FlowBoardElement['orientation'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<FlowBoardElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<FlowBoardElement['lang'] | undefined>;
  /**
   * Output signal for the `flowBoardBeforeColumnReorder` event.
   *
   * @public
   */
  readonly flowBoardBeforeColumnReorder: OutputEmitterRef<ElementEventDetail<FlowBoardElement, 'flowBoardBeforeColumnReorder'>>;
  /**
   * Output signal for the `flowBoardColumnReorder` event.
   *
   * @public
   */
  readonly flowBoardColumnReorder: OutputEmitterRef<ElementEventDetail<FlowBoardElement, 'flowBoardColumnReorder'>>;
  /**
   * Output signal for the `flowBoardBeforeItemReorder` event.
   *
   * @public
   */
  readonly flowBoardBeforeItemReorder: OutputEmitterRef<ElementEventDetail<FlowBoardElement, 'flowBoardBeforeItemReorder'>>;
  /**
   * Output signal for the `flowBoardItemReorder` event.
   *
   * @public
   */
  readonly flowBoardItemReorder: OutputEmitterRef<ElementEventDetail<FlowBoardElement, 'flowBoardItemReorder'>>;
  /**
   * Output signal for the `flowBoardBeforeItemMove` event.
   *
   * @public
   */
  readonly flowBoardBeforeItemMove: OutputEmitterRef<ElementEventDetail<FlowBoardElement, 'flowBoardBeforeItemMove'>>;
  /**
   * Output signal for the `flowBoardItemMove` event.
   *
   * @public
   */
  readonly flowBoardItemMove: OutputEmitterRef<ElementEventDetail<FlowBoardElement, 'flowBoardItemMove'>>;
  /**
   * Output signal for the `flowBoardBeforeItemGroup` event.
   *
   * @public
   */
  readonly flowBoardBeforeItemGroup: OutputEmitterRef<ElementEventDetail<FlowBoardElement, 'flowBoardBeforeItemGroup'>>;
  /**
   * Output signal for the `flowBoardItemGroup` event.
   *
   * @public
   */
  readonly flowBoardItemGroup: OutputEmitterRef<ElementEventDetail<FlowBoardElement, 'flowBoardItemGroup'>>;
  /**
   * Output signal for the `flowBoardDragStart` event.
   *
   * @public
   */
  readonly flowBoardDragStart: OutputEmitterRef<ElementEventDetail<FlowBoardElement, 'flowBoardDragStart'>>;
  /**
   * Output signal for the `flowBoardSelectionChanged` event.
   *
   * @public
   */
  readonly flowBoardSelectionChanged: OutputEmitterRef<ElementEventDetail<FlowBoardElement, 'flowBoardSelectionChanged'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<FlowBoardElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<FlowBoardElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<FlowBoardElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: FlowBoardElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: FlowBoardElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Returns the scrollable viewport of the board, which is owned by the internal
   * scroll primitive rather than by the board element itself.
   *
   * @public
   */
  getScrollableElement(...args: Parameters<FlowBoardElement['getScrollableElement']>): ReturnType<FlowBoardElement['getScrollableElement']>;
  /**
   * Gets all column elements in the board.
   *
   * @public
   * @returns Array of FlowBoardColumnElement instances.
   */
  getColumns(...args: Parameters<FlowBoardElement['getColumns']>): ReturnType<FlowBoardElement['getColumns']>;
  /**
   * Gets a column by its key.
   *
   * @public
   * @param args - The arguments of `getColumnByKey`:
   * - `columnKey` - The column key to find.
   * @returns The column element or undefined if not found.
   */
  getColumnByKey(...args: Parameters<FlowBoardElement['getColumnByKey']>): ReturnType<FlowBoardElement['getColumnByKey']>;
  /**
   * Selects every selectable item on the board.
   *
   * @public
   */
  selectAll(...args: Parameters<FlowBoardElement['selectAll']>): ReturnType<FlowBoardElement['selectAll']>;
  /**
   * Clears the current item selection.
   *
   * @public
   */
  clearSelection(...args: Parameters<FlowBoardElement['clearSelection']>): ReturnType<FlowBoardElement['clearSelection']>;
  /**
   * Returns every item that can take part in selection, in board order.
   *
   * @public
   */
  getSelectableItems(...args: Parameters<FlowBoardElement['getSelectableItems']>): ReturnType<FlowBoardElement['getSelectableItems']>;
  /**
   * Moves an item between columns programmatically.
   *
   * @public
   * @param args - The arguments of `moveItem`:
   * - `itemKey` - The key of the item to move.
   * - `fromColumnKey` - The source column key.
   * - `toColumnKey` - The target column key.
   * - `toIndex` - Optional target index in the target column.
   * @returns True if the move was successful.
   */
  moveItem(...args: Parameters<FlowBoardElement['moveItem']>): ReturnType<FlowBoardElement['moveItem']>;
  /**
   * Reorders a column to a new index.
   *
   * @public
   * @param args - The arguments of `reorderColumn`:
   * - `columnKey` - The key of the column to reorder.
   * - `newIndex` - The target index.
   * @returns True if the reorder was successful.
   */
  reorderColumn(...args: Parameters<FlowBoardElement['reorderColumn']>): ReturnType<FlowBoardElement['reorderColumn']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   * @param args - The arguments of `assignToSlot`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * - `node` - The nodes to assign to the slot.
   */
  assignToSlot(...args: Parameters<FlowBoardElement['assignToSlot']>): ReturnType<FlowBoardElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   * This method extracts text content recursively, including from Shadow DOMs
   * and Custom Elements with known text properties (like `mosaik-text`).
   *
   * @public
   * @param args - The arguments of `getSlotContent`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<FlowBoardElement['getSlotContent']>): ReturnType<FlowBoardElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @param args - The arguments of `hasSlotContent`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<FlowBoardElement['hasSlotContent']>): ReturnType<FlowBoardElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @param args - The arguments of `hasSlot`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<FlowBoardElement['hasSlot']>): ReturnType<FlowBoardElement['hasSlot']>;
  /**
   * Called when the slot changes.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<FlowBoardElement['onSlotChanges']>): ReturnType<FlowBoardElement['onSlotChanges']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `getScrollableElement()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends FlowBoardMethodNames>(method: TMethod, ...args: Parameters<FlowBoardComponentMethods[TMethod]>): ReturnType<FlowBoardComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof FlowBoardElement>(property: TProperty, value: FlowBoardElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<FlowBoardElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<FlowBoardComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<FlowBoardComponent, "mosaik-flow-board", never, {
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "displayMode": {
      "alias": "displayMode";
      "required": false;
      "isSignal": true;
    };
    "dragdrop": {
      "alias": "dragdrop";
      "required": false;
      "isSignal": true;
    };
    "mutationMode": {
      "alias": "mutationMode";
      "required": false;
      "isSignal": true;
    };
    "selectionMode": {
      "alias": "selectionMode";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "gap": {
      "alias": "gap";
      "required": false;
      "isSignal": true;
    };
    "isFocused": {
      "alias": "isFocused";
      "required": false;
      "isSignal": true;
    };
    "showScrollButtons": {
      "alias": "showScrollButtons";
      "required": false;
      "isSignal": true;
    };
    "showScrollbar": {
      "alias": "showScrollbar";
      "required": false;
      "isSignal": true;
    };
    "orientation": {
      "alias": "orientation";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "flowBoardBeforeColumnReorder": "flowBoardBeforeColumnReorder";
    "flowBoardColumnReorder": "flowBoardColumnReorder";
    "flowBoardBeforeItemReorder": "flowBoardBeforeItemReorder";
    "flowBoardItemReorder": "flowBoardItemReorder";
    "flowBoardBeforeItemMove": "flowBoardBeforeItemMove";
    "flowBoardItemMove": "flowBoardItemMove";
    "flowBoardBeforeItemGroup": "flowBoardBeforeItemGroup";
    "flowBoardItemGroup": "flowBoardItemGroup";
    "flowBoardDragStart": "flowBoardDragStart";
    "flowBoardSelectionChanged": "flowBoardSelectionChanged";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on FlowBoardComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FlowBoardMethodNames = 'getScrollableElement' | 'getColumns' | 'getColumnByKey' | 'selectAll' | 'clearSelection' | 'getSelectableItems' | 'moveItem' | 'reorderColumn' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges';
/**
 * Declares the methods interface for FlowBoardComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FlowBoardComponentMethods = MethodMap<FlowBoardMethodNames>;
/**
 * @public
 */
export declare function provideFlowBoardComponent(config?: Partial<FlowBoardElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-flow-board.d.ts.map