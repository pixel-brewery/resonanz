import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { CellGroupElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/cells/CellGroupElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { CellElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/cells/CellElement";
/**
 * @public
 *
 * Injection token for the default properties of the CellGroupComponent.
 * Use this token to provide default properties for the CellGroupComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const CELL_GROUP_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/cells/ICellGroupElementProps").ICellGroupElementProps>>;
/**
 * @public
 *
 * @slot  - Default content area for cell components and related content
 * @slot header - Header content area for group titles, descriptions, or section labels
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class CellGroupComponent {
  /**
   * Signal input for the `header` property.
   *
   * @public
   */
  readonly header: InputSignal<CellGroupElement['header'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<CellGroupElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<CellGroupElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<CellGroupElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<CellGroupElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<CellGroupElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<CellGroupElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof CellGroupElement>(property: TProperty, value: CellGroupElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<CellGroupElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<CellGroupComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<CellGroupComponent, "mosaik-cell-group", never, {
    "header": {
      "alias": "header";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on CellGroupComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type CellGroupMethodNames = never;
/**
 * Declares the methods interface for CellGroupComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type CellGroupComponentMethods = MethodMap<CellGroupMethodNames>;
/**
 * @public
 */
export declare function provideCellGroupComponent(config?: Partial<CellGroupElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the CellComponent.
 * Use this token to provide default properties for the CellComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const CELL_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/cells/ICellElementProps").ICellElementProps>>;
/**
 * @public
 *
 * @slot end - Trailing content area for actions, status indicators, or secondary controls
 * @slot label - Primary content area for main text, titles, or primary information
 * @slot start - Leading content area for icons, avatars, thumbnails, or visual indicators
 * @slot subLabel - Secondary content area for descriptions, metadata, or supplementary text
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class CellComponent {
  /**
   * Signal input for the `isNavigation` property.
   *
   * @public
   */
  readonly isNavigation: InputSignal<CellElement['isNavigation'] | undefined>;
  /**
   * Signal input for the `subLabel` property.
   *
   * @public
   */
  readonly subLabel: InputSignal<CellElement['subLabel'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<CellElement['themeName'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<CellElement['label'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<CellElement['disabled'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<CellElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<CellElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<CellElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<CellElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<CellElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof CellElement>(property: TProperty, value: CellElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<CellElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<CellComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<CellComponent, "mosaik-cell", never, {
    "isNavigation": {
      "alias": "isNavigation";
      "required": false;
      "isSignal": true;
    };
    "subLabel": {
      "alias": "subLabel";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on CellComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type CellMethodNames = never;
/**
 * Declares the methods interface for CellComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type CellComponentMethods = MethodMap<CellMethodNames>;
/**
 * @public
 */
export declare function provideCellComponent(config?: Partial<CellElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-cells.d.ts.map