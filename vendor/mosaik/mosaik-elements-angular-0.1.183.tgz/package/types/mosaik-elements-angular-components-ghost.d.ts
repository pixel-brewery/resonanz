import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { GhostElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/ghost/GhostElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the GhostComponent.
 * Use this token to provide default properties for the GhostComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const GHOST_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/primitives/ghost/IGhostElementProps").IGhostElementProps>>;
/**
 * @public
 *
 * @slot  - The default content slot (typically empty or used for hidden reference content)
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class GhostComponent {
  /**
   * Signal input for the `top` property.
   *
   * @public
   */
  readonly top: InputSignal<GhostElement['top'] | undefined>;
  /**
   * Signal input for the `left` property.
   *
   * @public
   */
  readonly left: InputSignal<GhostElement['left'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<GhostElement['themeName'] | undefined>;
  /**
   * Signal input for the `width` property.
   *
   * @public
   */
  readonly width: InputSignal<GhostElement['width'] | undefined>;
  /**
   * Signal input for the `height` property.
   *
   * @public
   */
  readonly height: InputSignal<GhostElement['height'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<GhostElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<GhostElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<GhostElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<GhostElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<GhostElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof GhostElement>(property: TProperty, value: GhostElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<GhostElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<GhostComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<GhostComponent, "mosaik-ghost", never, {
    "top": {
      "alias": "top";
      "required": false;
      "isSignal": true;
    };
    "left": {
      "alias": "left";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "width": {
      "alias": "width";
      "required": false;
      "isSignal": true;
    };
    "height": {
      "alias": "height";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on GhostComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type GhostMethodNames = never;
/**
 * Declares the methods interface for GhostComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type GhostComponentMethods = MethodMap<GhostMethodNames>;
/**
 * @public
 */
export declare function provideGhostComponent(config?: Partial<GhostElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-ghost.d.ts.map