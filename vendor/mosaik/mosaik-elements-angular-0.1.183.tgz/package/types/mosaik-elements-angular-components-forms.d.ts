import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { FormFieldElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/forms/FormFieldElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { FormElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/forms/FormElement";
/**
 * @public
 *
 * Injection token for the default properties of the FormFieldComponent.
 * Use this token to provide default properties for the FormFieldComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const FORM_FIELD_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/forms/IFormFieldElementProps").IFormFieldElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot for the form field control.
 * @slot actions - Slot for additional information or helper text.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class FormFieldComponent {
  /**
   * Signal input for the `hint` property.
   *
   * @public
   */
  readonly hint: InputSignal<FormFieldElement['hint'] | undefined>;
  /**
   * Signal input for the `error` property.
   *
   * @public
   */
  readonly error: InputSignal<FormFieldElement['error'] | undefined>;
  /**
   * Signal input for the `info` property.
   *
   * @public
   */
  readonly info: InputSignal<FormFieldElement['info'] | undefined>;
  /**
   * Signal input for the `validators` property.
   *
   * @public
   */
  readonly validators: InputSignal<FormFieldElement['validators'] | undefined>;
  /**
   * Signal input for the `accessor` property.
   *
   * @public
   */
  readonly accessor: InputSignal<FormFieldElement['accessor'] | undefined>;
  /**
   * Signal input for the `required` property.
   *
   * @public
   */
  readonly required: InputSignal<FormFieldElement['required'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<FormFieldElement['themeName'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<FormFieldElement['label'] | undefined>;
  /**
   * Signal input for the `name` property.
   *
   * @public
   */
  readonly name: InputSignal<FormFieldElement['name'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<FormFieldElement['disabled'] | undefined>;
  /**
   * Signal input for the `form` property.
   *
   * @public
   */
  readonly form: InputSignal<FormFieldElement['form'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<FormFieldElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<FormFieldElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<FormFieldElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<FormFieldElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<FormFieldElement, 'changed'>>;
  /**
   * Output signal for the `invalid` event.
   *
   * @public
   */
  readonly invalid: OutputEmitterRef<ElementEventDetail<FormFieldElement, 'invalid'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Returns true if internals's target element has no validity problems; false otherwise.
   * Fires an invalid event at the element in the latter case.
   *
   * @public
   */
  checkValidity(...args: Parameters<FormFieldElement['checkValidity']>): ReturnType<FormFieldElement['checkValidity']>;
  /**
   * Returns true if internals's target element has no validity problems; otherwise, returns false.
   * Fires an invalid event at the element, and (if the event isn't canceled) reports the problem to the user.
   *
   * @public
   */
  reportValidity(...args: Parameters<FormFieldElement['reportValidity']>): ReturnType<FormFieldElement['reportValidity']>;
  /**
   * Gets the current form value of a component.
   *
   * @public
   */
  getFormValue(...args: Parameters<FormFieldElement['getFormValue']>): ReturnType<FormFieldElement['getFormValue']>;
  /**
   * Gets the current form state of a component. Defaults to the component's `[formValue]`.
   *
   * Use this when the state of an element is different from its value, such as
   * checkboxes (internal boolean state and a user string value).
   *
   * @public
   * @returns The current form state, defaults to the form value.
   */
  getFormState(...args: Parameters<FormFieldElement['getFormState']>): ReturnType<FormFieldElement['getFormState']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `checkValidity()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends FormFieldMethodNames>(method: TMethod, ...args: Parameters<FormFieldComponentMethods[TMethod]>): ReturnType<FormFieldComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof FormFieldElement>(property: TProperty, value: FormFieldElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<FormFieldElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<FormFieldComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<FormFieldComponent, "mosaik-form-field", never, {
    "hint": {
      "alias": "hint";
      "required": false;
      "isSignal": true;
    };
    "error": {
      "alias": "error";
      "required": false;
      "isSignal": true;
    };
    "info": {
      "alias": "info";
      "required": false;
      "isSignal": true;
    };
    "validators": {
      "alias": "validators";
      "required": false;
      "isSignal": true;
    };
    "accessor": {
      "alias": "accessor";
      "required": false;
      "isSignal": true;
    };
    "required": {
      "alias": "required";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "name": {
      "alias": "name";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "form": {
      "alias": "form";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
    "invalid": "invalid";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on FormFieldComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FormFieldMethodNames = 'checkValidity' | 'reportValidity' | 'getFormValue' | 'getFormState';
/**
 * Declares the methods interface for FormFieldComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FormFieldComponentMethods = MethodMap<FormFieldMethodNames>;
/**
 * @public
 */
export declare function provideFormFieldComponent(config?: Partial<FormFieldElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the FormComponent.
 * Use this token to provide default properties for the FormComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const FORM_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/forms/IFormElementProps").IFormElementProps>>;
/**
 * @public
 *
 * @slot  - Default content area for form controls, form fields, and layout elements
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class FormComponent {
  /**
   * Signal input for the `novalidate` property.
   *
   * @public
   */
  readonly novalidate: InputSignal<FormElement['novalidate'] | undefined>;
  /**
   * Signal input for the `autocomplete` property.
   *
   * @public
   */
  readonly autocomplete: InputSignal<FormElement['autocomplete'] | undefined>;
  /**
   * Signal input for the `name` property.
   *
   * @public
   */
  readonly name: InputSignal<FormElement['name'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<FormElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<FormElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<FormElement['lang'] | undefined>;
  /**
   * Output signal for the `submitted` event.
   *
   * @public
   */
  readonly submitted: OutputEmitterRef<ElementEventDetail<FormElement, 'submitted'>>;
  /**
   * Output signal for the `formReset` event.
   *
   * @public
   */
  readonly formReset: OutputEmitterRef<ElementEventDetail<FormElement, 'formReset'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<FormElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<FormElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<FormElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: FormElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: FormElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Submits the form. It returns `true` if the form is valid, otherwise it returns `false`.
   *
   * @public
   */
  submit(...args: Parameters<FormElement['submit']>): ReturnType<FormElement['submit']>;
  /**
   * Resets the form.
   *
   * @public
   */
  reset(...args: Parameters<FormElement['reset']>): ReturnType<FormElement['reset']>;
  /**
   * Reports the validity of the form.
   * It returns `true` if the form is valid, otherwise it returns `false`.
   *
   * @public
   */
  reportValidity(...args: Parameters<FormElement['reportValidity']>): ReturnType<FormElement['reportValidity']>;
  /**
   * Checks the validity of the form.
   * It returns `true` if the form is valid, otherwise it returns `false`.
   *
   * @public
   */
  checkValidity(...args: Parameters<FormElement['checkValidity']>): ReturnType<FormElement['checkValidity']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<FormElement['assignToSlot']>): ReturnType<FormElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<FormElement['getSlotContent']>): ReturnType<FormElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<FormElement['hasSlotContent']>): ReturnType<FormElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<FormElement['hasSlot']>): ReturnType<FormElement['hasSlot']>;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<FormElement['onSlotChanges']>): ReturnType<FormElement['onSlotChanges']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `submit()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends FormMethodNames>(method: TMethod, ...args: Parameters<FormComponentMethods[TMethod]>): ReturnType<FormComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof FormElement>(property: TProperty, value: FormElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<FormElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<FormComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<FormComponent, "mosaik-form", never, {
    "novalidate": {
      "alias": "novalidate";
      "required": false;
      "isSignal": true;
    };
    "autocomplete": {
      "alias": "autocomplete";
      "required": false;
      "isSignal": true;
    };
    "name": {
      "alias": "name";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "submitted": "submitted";
    "formReset": "formReset";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on FormComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FormMethodNames = 'submit' | 'reset' | 'reportValidity' | 'checkValidity' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges';
/**
 * Declares the methods interface for FormComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FormComponentMethods = MethodMap<FormMethodNames>;
/**
 * @public
 */
export declare function provideFormComponent(config?: Partial<FormElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-forms.d.ts.map