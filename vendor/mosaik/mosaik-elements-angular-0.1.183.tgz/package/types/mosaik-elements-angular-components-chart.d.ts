import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { ChartElement, ChartToolboxElement } from "@pixel-brewery/mosaik-elements-foundation/components/chart";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the ChartToolboxComponent.
 * Use this token to provide default properties for the ChartToolboxComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const CHART_TOOLBOX_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation/components/chart").IChartToolboxElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ChartToolboxComponent {
  /**
   * Signal input for the `chart` property.
   *
   * @public
   */
  readonly chart: InputSignal<ChartToolboxElement['chart'] | undefined>;
  /**
   * Signal input for the `tools` property.
   *
   * @public
   */
  readonly tools: InputSignal<ChartToolboxElement['tools'] | undefined>;
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<ChartToolboxElement['intl'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ChartToolboxElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ChartToolboxElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ChartToolboxElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ChartToolboxElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ChartToolboxElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ChartToolboxElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ChartToolboxElement>(property: TProperty, value: ChartToolboxElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ChartToolboxElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ChartToolboxComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ChartToolboxComponent, "mosaik-chart-toolbox", never, {
    "chart": {
      "alias": "chart";
      "required": false;
      "isSignal": true;
    };
    "tools": {
      "alias": "tools";
      "required": false;
      "isSignal": true;
    };
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on ChartToolboxComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ChartToolboxMethodNames = never;
/**
 * Declares the methods interface for ChartToolboxComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ChartToolboxComponentMethods = MethodMap<ChartToolboxMethodNames>;
/**
 * @public
 */
export declare function provideChartToolboxComponent(config?: Partial<ChartToolboxElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the ChartComponent.
 * Use this token to provide default properties for the ChartComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const CHART_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation/components/chart").IChartElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ChartComponent {
  /**
   * Signal input for the `chart` property.
   *
   * @public
   */
  readonly chart: InputSignal<ChartElement['chart'] | undefined>;
  /**
   * Signal input for the `showToolbox` property.
   *
   * @public
   */
  readonly showToolbox: InputSignal<ChartElement['showToolbox'] | undefined>;
  /**
   * Signal input for the `toolboxTools` property.
   *
   * @public
   */
  readonly toolboxTools: InputSignal<ChartElement['toolboxTools'] | undefined>;
  /**
   * Signal input for the `annotations` property.
   *
   * @public
   */
  readonly annotations: InputSignal<ChartElement['annotations'] | undefined>;
  /**
   * Signal input for the `colors` property.
   *
   * @public
   */
  readonly colors: InputSignal<ChartElement['colors'] | undefined>;
  /**
   * Signal input for the `dataLabels` property.
   *
   * @public
   */
  readonly dataLabels: InputSignal<ChartElement['dataLabels'] | undefined>;
  /**
   * Signal input for the `series` property.
   *
   * @public
   */
  readonly series: InputSignal<ChartElement['series'] | undefined>;
  /**
   * Signal input for the `stroke` property.
   *
   * @public
   */
  readonly stroke: InputSignal<ChartElement['stroke'] | undefined>;
  /**
   * Signal input for the `labels` property.
   *
   * @public
   */
  readonly labels: InputSignal<ChartElement['labels'] | undefined>;
  /**
   * Signal input for the `legend` property.
   *
   * @public
   */
  readonly legend: InputSignal<ChartElement['legend'] | undefined>;
  /**
   * Signal input for the `markers` property.
   *
   * @public
   */
  readonly markers: InputSignal<ChartElement['markers'] | undefined>;
  /**
   * Signal input for the `noData` property.
   *
   * @public
   */
  readonly noData: InputSignal<ChartElement['noData'] | undefined>;
  /**
   * Signal input for the `fill` property.
   *
   * @public
   */
  readonly fill: InputSignal<ChartElement['fill'] | undefined>;
  /**
   * Signal input for the `tooltip` property.
   *
   * @public
   */
  readonly tooltip: InputSignal<ChartElement['tooltip'] | undefined>;
  /**
   * Signal input for the `plotOptions` property.
   *
   * @public
   */
  readonly plotOptions: InputSignal<ChartElement['plotOptions'] | undefined>;
  /**
   * Signal input for the `responsive` property.
   *
   * @public
   */
  readonly responsive: InputSignal<ChartElement['responsive'] | undefined>;
  /**
   * Signal input for the `xAxis` property.
   *
   * @public
   */
  readonly xAxis: InputSignal<ChartElement['xAxis'] | undefined>;
  /**
   * Signal input for the `yAxis` property.
   *
   * @public
   */
  readonly yAxis: InputSignal<ChartElement['yAxis'] | undefined>;
  /**
   * Signal input for the `grid` property.
   *
   * @public
   */
  readonly grid: InputSignal<ChartElement['grid'] | undefined>;
  /**
   * Signal input for the `states` property.
   *
   * @public
   */
  readonly states: InputSignal<ChartElement['states'] | undefined>;
  /**
   * Signal input for the `theme` property.
   *
   * @public
   */
  readonly theme: InputSignal<ChartElement['theme'] | undefined>;
  /**
   * Signal input for the `display` property.
   *
   * @public
   */
  readonly display: InputSignal<ChartElement['display'] | undefined>;
  /**
   * Signal input for the `stacked` property.
   *
   * @public
   */
  readonly stacked: InputSignal<ChartElement['stacked'] | undefined>;
  /**
   * Signal input for the `stackType` property.
   *
   * @public
   */
  readonly stackType: InputSignal<ChartElement['stackType'] | undefined>;
  /**
   * Signal input for the `isYAxisVisible` property.
   *
   * @public
   */
  readonly isYAxisVisible: InputSignal<ChartElement['isYAxisVisible'] | undefined>;
  /**
   * Signal input for the `isXAxisVisible` property.
   *
   * @public
   */
  readonly isXAxisVisible: InputSignal<ChartElement['isXAxisVisible'] | undefined>;
  /**
   * Signal input for the `isLegendVisible` property.
   *
   * @public
   */
  readonly isLegendVisible: InputSignal<ChartElement['isLegendVisible'] | undefined>;
  /**
   * Signal input for the `legendPosition` property.
   *
   * @public
   */
  readonly legendPosition: InputSignal<ChartElement['legendPosition'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ChartElement['themeName'] | undefined>;
  /**
   * Signal input for the `header` property.
   *
   * @public
   */
  readonly header: InputSignal<ChartElement['header'] | undefined>;
  /**
   * Signal input for the `subHeader` property.
   *
   * @public
   */
  readonly subHeader: InputSignal<ChartElement['subHeader'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<ChartElement['variant'] | undefined>;
  /**
   * Signal input for the `fit` property.
   *
   * @public
   */
  readonly fit: InputSignal<ChartElement['fit'] | undefined>;
  /**
   * Signal input for the `width` property.
   *
   * @public
   */
  readonly width: InputSignal<ChartElement['width'] | undefined>;
  /**
   * Signal input for the `height` property.
   *
   * @public
   */
  readonly height: InputSignal<ChartElement['height'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ChartElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ChartElement['lang'] | undefined>;
  /**
   * Output signal for the `chartReady` event.
   *
   * @public
   */
  readonly chartReady: OutputEmitterRef<ElementEventDetail<ChartElement, 'chartReady'>>;
  /**
   * Output signal for the `chartToolChanged` event.
   *
   * @public
   */
  readonly chartToolChanged: OutputEmitterRef<ElementEventDetail<ChartElement, 'chartToolChanged'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ChartElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ChartElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ChartElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Whether an action is available for this chart and visible in its toolbox by default.
   *
   * @public
   * @param args - The arguments of `isToolVisible`:
   * - `tool` - Action to inspect.
   * @returns Whether the toolbox should display the action.
   */
  isToolVisible(...args: Parameters<ChartElement['isToolVisible']>): ReturnType<ChartElement['isToolVisible']>;
  /**
   * Runs a chart action without requiring the built-in toolbox or Apex toolbar.
   *
   * @public
   * @param args - The arguments of `command`:
   * - `name` - Action to run.
   * @returns Whether the action ran on a rendered chart.
   */
  command(...args: Parameters<ChartElement['command']>): ReturnType<ChartElement['command']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `isToolVisible()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends ChartMethodNames>(method: TMethod, ...args: Parameters<ChartComponentMethods[TMethod]>): ReturnType<ChartComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ChartElement>(property: TProperty, value: ChartElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ChartElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ChartComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ChartComponent, "mosaik-chart", never, {
    "chart": {
      "alias": "chart";
      "required": false;
      "isSignal": true;
    };
    "showToolbox": {
      "alias": "showToolbox";
      "required": false;
      "isSignal": true;
    };
    "toolboxTools": {
      "alias": "toolboxTools";
      "required": false;
      "isSignal": true;
    };
    "annotations": {
      "alias": "annotations";
      "required": false;
      "isSignal": true;
    };
    "colors": {
      "alias": "colors";
      "required": false;
      "isSignal": true;
    };
    "dataLabels": {
      "alias": "dataLabels";
      "required": false;
      "isSignal": true;
    };
    "series": {
      "alias": "series";
      "required": false;
      "isSignal": true;
    };
    "stroke": {
      "alias": "stroke";
      "required": false;
      "isSignal": true;
    };
    "labels": {
      "alias": "labels";
      "required": false;
      "isSignal": true;
    };
    "legend": {
      "alias": "legend";
      "required": false;
      "isSignal": true;
    };
    "markers": {
      "alias": "markers";
      "required": false;
      "isSignal": true;
    };
    "noData": {
      "alias": "noData";
      "required": false;
      "isSignal": true;
    };
    "fill": {
      "alias": "fill";
      "required": false;
      "isSignal": true;
    };
    "tooltip": {
      "alias": "tooltip";
      "required": false;
      "isSignal": true;
    };
    "plotOptions": {
      "alias": "plotOptions";
      "required": false;
      "isSignal": true;
    };
    "responsive": {
      "alias": "responsive";
      "required": false;
      "isSignal": true;
    };
    "xAxis": {
      "alias": "xAxis";
      "required": false;
      "isSignal": true;
    };
    "yAxis": {
      "alias": "yAxis";
      "required": false;
      "isSignal": true;
    };
    "grid": {
      "alias": "grid";
      "required": false;
      "isSignal": true;
    };
    "states": {
      "alias": "states";
      "required": false;
      "isSignal": true;
    };
    "theme": {
      "alias": "theme";
      "required": false;
      "isSignal": true;
    };
    "display": {
      "alias": "display";
      "required": false;
      "isSignal": true;
    };
    "stacked": {
      "alias": "stacked";
      "required": false;
      "isSignal": true;
    };
    "stackType": {
      "alias": "stackType";
      "required": false;
      "isSignal": true;
    };
    "isYAxisVisible": {
      "alias": "isYAxisVisible";
      "required": false;
      "isSignal": true;
    };
    "isXAxisVisible": {
      "alias": "isXAxisVisible";
      "required": false;
      "isSignal": true;
    };
    "isLegendVisible": {
      "alias": "isLegendVisible";
      "required": false;
      "isSignal": true;
    };
    "legendPosition": {
      "alias": "legendPosition";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "header": {
      "alias": "header";
      "required": false;
      "isSignal": true;
    };
    "subHeader": {
      "alias": "subHeader";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "fit": {
      "alias": "fit";
      "required": false;
      "isSignal": true;
    };
    "width": {
      "alias": "width";
      "required": false;
      "isSignal": true;
    };
    "height": {
      "alias": "height";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "chartReady": "chartReady";
    "chartToolChanged": "chartToolChanged";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on ChartComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ChartMethodNames = 'isToolVisible' | 'command';
/**
 * Declares the methods interface for ChartComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ChartComponentMethods = MethodMap<ChartMethodNames>;
/**
 * @public
 */
export declare function provideChartComponent(config?: Partial<ChartElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-chart.d.ts.map