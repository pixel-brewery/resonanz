import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { SuggestionMenuElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/text-suggestions/SuggestionMenuElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the SuggestionMenuComponent.
 * Use this token to provide default properties for the SuggestionMenuComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const SUGGESTION_MENU_DEFAULT_PROPS: InjectionToken<Partial<SuggestionMenuElement.Props>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class SuggestionMenuComponent {
  /**
   * Signal input for the `state` property.
   *
   * @public
   */
  readonly state: InputSignal<SuggestionMenuElement['state'] | undefined>;
  /**
   * Signal input for the `anchor` property.
   *
   * @public
   */
  readonly anchor: InputSignal<SuggestionMenuElement['anchor'] | undefined>;
  /**
   * Signal input for the `placement` property.
   *
   * @public
   */
  readonly placement: InputSignal<SuggestionMenuElement['placement'] | undefined>;
  /**
   * Signal input for the `menuId` property.
   *
   * @public
   */
  readonly menuId: InputSignal<SuggestionMenuElement['menuId'] | undefined>;
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<SuggestionMenuElement['intl'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<SuggestionMenuElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<SuggestionMenuElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<SuggestionMenuElement['lang'] | undefined>;
  /**
   * Output signal for the `suggestionChosen` event.
   *
   * @public
   */
  readonly suggestionChosen: OutputEmitterRef<ElementEventDetail<SuggestionMenuElement, 'suggestionChosen'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<SuggestionMenuElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<SuggestionMenuElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<SuggestionMenuElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Shows or updates the list next to an anchor, or closes it when the state has no match. The focus stays where
   * it is.
   *
   * @public
   * @param args - The arguments of `show`:
   * - `anchor` - The element the list is placed next to.
   * - `state` - The state to show.
   */
  show(...args: Parameters<SuggestionMenuElement['show']>): ReturnType<SuggestionMenuElement['show']>;
  /**
   * Closes the list.
   *
   * @public
   */
  hide(...args: Parameters<SuggestionMenuElement['hide']>): ReturnType<SuggestionMenuElement['hide']>;
  /**
   * The element of an option. The list lives in a portal while it is open, outside the menu.
   *
   * @public
   * @param args - The arguments of `optionElement`:
   * - `index` - The index of the option.
   */
  optionElement(...args: Parameters<SuggestionMenuElement['optionElement']>): ReturnType<SuggestionMenuElement['optionElement']>;
  /**
   * The element of the list, for `aria-controls`.
   *
   * @public
   */
  listElement(...args: Parameters<SuggestionMenuElement['listElement']>): ReturnType<SuggestionMenuElement['listElement']>;
  /**
   * Fires `suggestionChosen` for an option.
   *
   * @public
   * @param args - The arguments of `choose`:
   * - `index` - The index of the option.
   */
  choose(...args: Parameters<SuggestionMenuElement['choose']>): ReturnType<SuggestionMenuElement['choose']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `show()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends SuggestionMenuMethodNames>(method: TMethod, ...args: Parameters<SuggestionMenuComponentMethods[TMethod]>): ReturnType<SuggestionMenuComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof SuggestionMenuElement>(property: TProperty, value: SuggestionMenuElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<SuggestionMenuElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SuggestionMenuComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SuggestionMenuComponent, "mosaik-suggestion-menu", never, {
    "state": {
      "alias": "state";
      "required": false;
      "isSignal": true;
    };
    "anchor": {
      "alias": "anchor";
      "required": false;
      "isSignal": true;
    };
    "placement": {
      "alias": "placement";
      "required": false;
      "isSignal": true;
    };
    "menuId": {
      "alias": "menuId";
      "required": false;
      "isSignal": true;
    };
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "suggestionChosen": "suggestionChosen";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on SuggestionMenuComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SuggestionMenuMethodNames = 'show' | 'hide' | 'optionElement' | 'listElement' | 'choose';
/**
 * Declares the methods interface for SuggestionMenuComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SuggestionMenuComponentMethods = MethodMap<SuggestionMenuMethodNames>;
/**
 * @public
 */
export declare function provideSuggestionMenuComponent(config?: Partial<SuggestionMenuElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-text-suggestions.d.ts.map