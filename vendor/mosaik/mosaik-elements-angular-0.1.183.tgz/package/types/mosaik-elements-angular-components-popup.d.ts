import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { PopupElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/popup/PopupElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the PopupComponent.
 * Use this token to provide default properties for the PopupComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const POPUP_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/primitives/popup/IPopupElementProps").IPopupElementProps>>;
/**
 * @public
 *
 * @slot  - Default slot for the trigger/anchor element.
 * @slot content - The popup content to display.
 * @slot footer - Optional footer content for the popup.
 * @slot header - Optional header content for the popup.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class PopupComponent {
  /**
   * Signal input for the `placement` property.
   *
   * @public
   */
  readonly placement: InputSignal<PopupElement['placement'] | undefined>;
  /**
   * Signal input for the `placements` property.
   *
   * @public
   */
  readonly placements: InputSignal<PopupElement['placements'] | undefined>;
  /**
   * Signal input for the `distance` property.
   *
   * @public
   */
  readonly distance: InputSignal<PopupElement['distance'] | undefined>;
  /**
   * Signal input for the `skidding` property.
   *
   * @public
   */
  readonly skidding: InputSignal<PopupElement['skidding'] | undefined>;
  /**
   * Signal input for the `trigger` property.
   *
   * @public
   */
  readonly trigger: InputSignal<PopupElement['trigger'] | undefined>;
  /**
   * Signal input for the `showDelay` property.
   *
   * @public
   */
  readonly showDelay: InputSignal<PopupElement['showDelay'] | undefined>;
  /**
   * Signal input for the `hideDelay` property.
   *
   * @public
   */
  readonly hideDelay: InputSignal<PopupElement['hideDelay'] | undefined>;
  /**
   * Signal input for the `staysOpen` property.
   *
   * @public
   */
  readonly staysOpen: InputSignal<PopupElement['staysOpen'] | undefined>;
  /**
   * Signal input for the `closeOnScroll` property.
   *
   * @public
   */
  readonly closeOnScroll: InputSignal<PopupElement['closeOnScroll'] | undefined>;
  /**
   * Signal input for the `interactive` property.
   *
   * @public
   */
  readonly interactive: InputSignal<PopupElement['interactive'] | undefined>;
  /**
   * Signal input for the `flip` property.
   *
   * @public
   */
  readonly flip: InputSignal<PopupElement['flip'] | undefined>;
  /**
   * Signal input for the `shift` property.
   *
   * @public
   */
  readonly shift: InputSignal<PopupElement['shift'] | undefined>;
  /**
   * Signal input for the `boundary` property.
   *
   * @public
   */
  readonly boundary: InputSignal<PopupElement['boundary'] | undefined>;
  /**
   * Signal input for the `shiftBoundary` property.
   *
   * @public
   */
  readonly shiftBoundary: InputSignal<PopupElement['shiftBoundary'] | undefined>;
  /**
   * Signal input for the `shiftPadding` property.
   *
   * @public
   */
  readonly shiftPadding: InputSignal<PopupElement['shiftPadding'] | undefined>;
  /**
   * Signal input for the `trapFocus` property.
   *
   * @public
   */
  readonly trapFocus: InputSignal<PopupElement['trapFocus'] | undefined>;
  /**
   * Signal input for the `restoreFocus` property.
   *
   * @public
   */
  readonly restoreFocus: InputSignal<PopupElement['restoreFocus'] | undefined>;
  /**
   * Signal input for the `sync` property.
   *
   * @public
   */
  readonly sync: InputSignal<PopupElement['sync'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<PopupElement['themeName'] | undefined>;
  /**
   * Signal input for the `enter` property.
   *
   * @public
   */
  readonly enter: InputSignal<PopupElement['enter'] | undefined>;
  /**
   * Signal input for the `exit` property.
   *
   * @public
   */
  readonly exit: InputSignal<PopupElement['exit'] | undefined>;
  /**
   * Signal input for the `for` property.
   *
   * @public
   */
  readonly for: InputSignal<PopupElement['for'] | undefined>;
  /**
   * Signal input for the `elevation` property.
   *
   * @public
   */
  readonly elevation: InputSignal<PopupElement['elevation'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<PopupElement['variant'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<PopupElement['appearance'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<PopupElement['disabled'] | undefined>;
  /**
   * Signal input for the `isOpen` property.
   *
   * @public
   */
  readonly isOpen: InputSignal<PopupElement['isOpen'] | undefined>;
  /**
   * Signal input for the `hasBackdrop` property.
   *
   * @public
   */
  readonly hasBackdrop: InputSignal<PopupElement['hasBackdrop'] | undefined>;
  /**
   * Signal input for the `pressEscapeToClose` property.
   *
   * @public
   */
  readonly pressEscapeToClose: InputSignal<PopupElement['pressEscapeToClose'] | undefined>;
  /**
   * Signal input for the `clickOutsideToClose` property.
   *
   * @public
   */
  readonly clickOutsideToClose: InputSignal<PopupElement['clickOutsideToClose'] | undefined>;
  /**
   * Signal input for the `attention` property.
   *
   * @public
   */
  readonly attention: InputSignal<PopupElement['attention'] | undefined>;
  /**
   * Signal input for the `closeable` property.
   *
   * @public
   */
  readonly closeable: InputSignal<PopupElement['closeable'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<PopupElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<PopupElement['lang'] | undefined>;
  /**
   * Output signal for the `opened` event.
   *
   * @public
   */
  readonly opened: OutputEmitterRef<ElementEventDetail<PopupElement, 'opened'>>;
  /**
   * Output signal for the `closed` event.
   *
   * @public
   */
  readonly closed: OutputEmitterRef<ElementEventDetail<PopupElement, 'closed'>>;
  /**
   * Output signal for the `closeAttempted` event.
   *
   * @public
   */
  readonly closeAttempted: OutputEmitterRef<ElementEventDetail<PopupElement, 'closeAttempted'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<PopupElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<PopupElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<PopupElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: PopupElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: PopupElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Attaches the popup to a control and immediately updates an open floating layer.
   *
   * @public
   * @param args - The arguments of `attach`:
   * - `control` - The control or id to attach.
   */
  attach(...args: Parameters<PopupElement['attach']>): ReturnType<PopupElement['attach']>;
  /**
   * Detaches the popup from its control and updates the floating layer.
   *
   * @public
   */
  detach(...args: Parameters<PopupElement['detach']>): ReturnType<PopupElement['detach']>;
  /**
   * Opens the popup.
   * Focus trap, close on scroll, outside clicks and focus restoration follow `isOpen`, so setting the
   * property directly behaves the same.
   *
   * @public
   */
  open(...args: Parameters<PopupElement['open']>): ReturnType<PopupElement['open']>;
  /**
   * Closes the popup.
   *
   * @public
   */
  close(...args: Parameters<PopupElement['close']>): ReturnType<PopupElement['close']>;
  /**
   * Toggles the popup open/closed state.
   *
   * @public
   */
  toggle(...args: Parameters<PopupElement['toggle']>): ReturnType<PopupElement['toggle']>;
  /**
   * Requests visual attention for the overlay without changing its open state.
   *
   * @public
   */
  requestAttention(...args: Parameters<PopupElement['requestAttention']>): ReturnType<PopupElement['requestAttention']>;
  /**
   * Executes the animation.
   *
   * @public
   */
  play(...args: Parameters<PopupElement['play']>): ReturnType<PopupElement['play']>;
  /**
   * A lifecycle hook that is invoked when the element is added to the DOM.
   *
   * @public
   */
  onEnterAnimation(...args: Parameters<NonNullable<PopupElement['onEnterAnimation']>>): ReturnType<NonNullable<PopupElement['onEnterAnimation']>> | undefined;
  /**
   * A lifecycle hook that is invoked when the element is removed from the DOM.
   *
   * @public
   */
  onExitAnimation(...args: Parameters<NonNullable<PopupElement['onExitAnimation']>>): ReturnType<NonNullable<PopupElement['onExitAnimation']>> | undefined;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<PopupElement['assignToSlot']>): ReturnType<PopupElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<PopupElement['getSlotContent']>): ReturnType<PopupElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<PopupElement['hasSlotContent']>): ReturnType<PopupElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<PopupElement['hasSlot']>): ReturnType<PopupElement['hasSlot']>;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<PopupElement['onSlotChanges']>): ReturnType<PopupElement['onSlotChanges']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `attach()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends PopupMethodNames>(method: TMethod, ...args: Parameters<PopupComponentMethods[TMethod]>): ReturnType<PopupComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof PopupElement>(property: TProperty, value: PopupElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<PopupElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<PopupComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<PopupComponent, "mosaik-popup", never, {
    "placement": {
      "alias": "placement";
      "required": false;
      "isSignal": true;
    };
    "placements": {
      "alias": "placements";
      "required": false;
      "isSignal": true;
    };
    "distance": {
      "alias": "distance";
      "required": false;
      "isSignal": true;
    };
    "skidding": {
      "alias": "skidding";
      "required": false;
      "isSignal": true;
    };
    "trigger": {
      "alias": "trigger";
      "required": false;
      "isSignal": true;
    };
    "showDelay": {
      "alias": "showDelay";
      "required": false;
      "isSignal": true;
    };
    "hideDelay": {
      "alias": "hideDelay";
      "required": false;
      "isSignal": true;
    };
    "staysOpen": {
      "alias": "staysOpen";
      "required": false;
      "isSignal": true;
    };
    "closeOnScroll": {
      "alias": "closeOnScroll";
      "required": false;
      "isSignal": true;
    };
    "interactive": {
      "alias": "interactive";
      "required": false;
      "isSignal": true;
    };
    "flip": {
      "alias": "flip";
      "required": false;
      "isSignal": true;
    };
    "shift": {
      "alias": "shift";
      "required": false;
      "isSignal": true;
    };
    "boundary": {
      "alias": "boundary";
      "required": false;
      "isSignal": true;
    };
    "shiftBoundary": {
      "alias": "shiftBoundary";
      "required": false;
      "isSignal": true;
    };
    "shiftPadding": {
      "alias": "shiftPadding";
      "required": false;
      "isSignal": true;
    };
    "trapFocus": {
      "alias": "trapFocus";
      "required": false;
      "isSignal": true;
    };
    "restoreFocus": {
      "alias": "restoreFocus";
      "required": false;
      "isSignal": true;
    };
    "sync": {
      "alias": "sync";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "enter": {
      "alias": "enter";
      "required": false;
      "isSignal": true;
    };
    "exit": {
      "alias": "exit";
      "required": false;
      "isSignal": true;
    };
    "for": {
      "alias": "for";
      "required": false;
      "isSignal": true;
    };
    "elevation": {
      "alias": "elevation";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "isOpen": {
      "alias": "isOpen";
      "required": false;
      "isSignal": true;
    };
    "hasBackdrop": {
      "alias": "hasBackdrop";
      "required": false;
      "isSignal": true;
    };
    "pressEscapeToClose": {
      "alias": "pressEscapeToClose";
      "required": false;
      "isSignal": true;
    };
    "clickOutsideToClose": {
      "alias": "clickOutsideToClose";
      "required": false;
      "isSignal": true;
    };
    "attention": {
      "alias": "attention";
      "required": false;
      "isSignal": true;
    };
    "closeable": {
      "alias": "closeable";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "opened": "opened";
    "closed": "closed";
    "closeAttempted": "closeAttempted";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["[slot=content]", "[slot=footer]", "[slot=header]", "[slot=style]", "*"], true, never>;
}
/**
 * Declares the methods available on PopupComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type PopupMethodNames = 'attach' | 'detach' | 'open' | 'close' | 'toggle' | 'requestAttention' | 'play' | 'onEnterAnimation' | 'onExitAnimation' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges';
/**
 * Declares the methods interface for PopupComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type PopupComponentMethods = MethodMap<PopupMethodNames>;
/**
 * @public
 */
export declare function providePopupComponent(config?: Partial<PopupElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-popup.d.ts.map