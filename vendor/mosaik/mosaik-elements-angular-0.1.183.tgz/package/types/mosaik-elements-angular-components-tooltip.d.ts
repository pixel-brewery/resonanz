import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { TooltipElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/tooltip/TooltipElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the TooltipComponent.
 * Use this token to provide default properties for the TooltipComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const TOOLTIP_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/primitives/tooltip/ITooltipElementProps").ITooltipElementProps>>;
/**
 * @public
 *
 * @slot  - The trigger element that activates the tooltip
 * @slot content - The tooltip content (text, elements, or formatted content)
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class TooltipComponent {
  /**
   * Signal input for the `content` property.
   *
   * @public
   */
  readonly content: InputSignal<TooltipElement['content'] | undefined>;
  /**
   * Signal input for the `placement` property.
   *
   * @public
   */
  readonly placement: InputSignal<TooltipElement['placement'] | undefined>;
  /**
   * Signal input for the `horizontalOffset` property.
   *
   * @public
   */
  readonly horizontalOffset: InputSignal<TooltipElement['horizontalOffset'] | undefined>;
  /**
   * Signal input for the `verticalOffset` property.
   *
   * @public
   */
  readonly verticalOffset: InputSignal<TooltipElement['verticalOffset'] | undefined>;
  /**
   * Signal input for the `isOpen` property.
   *
   * @public
   */
  readonly isOpen: InputSignal<TooltipElement['isOpen'] | undefined>;
  /**
   * Signal input for the `showDelay` property.
   *
   * @public
   */
  readonly showDelay: InputSignal<TooltipElement['showDelay'] | undefined>;
  /**
   * Signal input for the `hideDelay` property.
   *
   * @public
   */
  readonly hideDelay: InputSignal<TooltipElement['hideDelay'] | undefined>;
  /**
   * Signal input for the `trigger` property.
   *
   * @public
   */
  readonly trigger: InputSignal<TooltipElement['trigger'] | undefined>;
  /**
   * Signal input for the `staysOpen` property.
   *
   * @public
   */
  readonly staysOpen: InputSignal<TooltipElement['staysOpen'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<TooltipElement['themeName'] | undefined>;
  /**
   * Signal input for the `enter` property.
   *
   * @public
   */
  readonly enter: InputSignal<TooltipElement['enter'] | undefined>;
  /**
   * Signal input for the `exit` property.
   *
   * @public
   */
  readonly exit: InputSignal<TooltipElement['exit'] | undefined>;
  /**
   * Signal input for the `for` property.
   *
   * @public
   */
  readonly for: InputSignal<TooltipElement['for'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<TooltipElement['disabled'] | undefined>;
  /**
   * Signal input for the `formatter` property.
   *
   * @public
   */
  readonly formatter: InputSignal<TooltipElement['formatter'] | undefined>;
  /**
   * Signal input for the `closeable` property.
   *
   * @public
   */
  readonly closeable: InputSignal<TooltipElement['closeable'] | undefined>;
  /**
   * Signal input for the `width` property.
   *
   * @public
   */
  readonly width: InputSignal<TooltipElement['width'] | undefined>;
  /**
   * Signal input for the `height` property.
   *
   * @public
   */
  readonly height: InputSignal<TooltipElement['height'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<TooltipElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<TooltipElement['lang'] | undefined>;
  /**
   * Output signal for the `opened` event.
   *
   * @public
   */
  readonly opened: OutputEmitterRef<ElementEventDetail<TooltipElement, 'opened'>>;
  /**
   * Output signal for the `closed` event.
   *
   * @public
   */
  readonly closed: OutputEmitterRef<ElementEventDetail<TooltipElement, 'closed'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<TooltipElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<TooltipElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<TooltipElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: TooltipElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: TooltipElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Opens the tooltip.
   *
   * @public
   */
  open(...args: Parameters<TooltipElement['open']>): ReturnType<TooltipElement['open']>;
  /**
   * Closes the tooltip.
   *
   * @public
   */
  close(...args: Parameters<TooltipElement['close']>): ReturnType<TooltipElement['close']>;
  /**
   * Attaches the element to an interactive control.
   *
   * @public
   */
  attach(...args: Parameters<TooltipElement['attach']>): ReturnType<TooltipElement['attach']>;
  /**
   * Executes the animation.
   *
   * @public
   */
  play(...args: Parameters<TooltipElement['play']>): ReturnType<TooltipElement['play']>;
  /**
   * A lifecycle hook that is invoked when the element is added to the DOM.
   *
   * @public
   */
  onEnterAnimation(...args: Parameters<NonNullable<TooltipElement['onEnterAnimation']>>): ReturnType<NonNullable<TooltipElement['onEnterAnimation']>> | undefined;
  /**
   * A lifecycle hook that is invoked when the element is removed from the DOM.
   *
   * @public
   */
  onExitAnimation(...args: Parameters<NonNullable<TooltipElement['onExitAnimation']>>): ReturnType<NonNullable<TooltipElement['onExitAnimation']>> | undefined;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<TooltipElement['assignToSlot']>): ReturnType<TooltipElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<TooltipElement['getSlotContent']>): ReturnType<TooltipElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<TooltipElement['hasSlotContent']>): ReturnType<TooltipElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<TooltipElement['hasSlot']>): ReturnType<TooltipElement['hasSlot']>;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<TooltipElement['onSlotChanges']>): ReturnType<TooltipElement['onSlotChanges']>;
  /**
   * Detaches the element from its current control.
   *
   * @public
   */
  detach(...args: Parameters<TooltipElement['detach']>): ReturnType<TooltipElement['detach']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `open()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends TooltipMethodNames>(method: TMethod, ...args: Parameters<TooltipComponentMethods[TMethod]>): ReturnType<TooltipComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof TooltipElement>(property: TProperty, value: TooltipElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<TooltipElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<TooltipComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<TooltipComponent, "mosaik-tooltip", never, {
    "content": {
      "alias": "content";
      "required": false;
      "isSignal": true;
    };
    "placement": {
      "alias": "placement";
      "required": false;
      "isSignal": true;
    };
    "horizontalOffset": {
      "alias": "horizontalOffset";
      "required": false;
      "isSignal": true;
    };
    "verticalOffset": {
      "alias": "verticalOffset";
      "required": false;
      "isSignal": true;
    };
    "isOpen": {
      "alias": "isOpen";
      "required": false;
      "isSignal": true;
    };
    "showDelay": {
      "alias": "showDelay";
      "required": false;
      "isSignal": true;
    };
    "hideDelay": {
      "alias": "hideDelay";
      "required": false;
      "isSignal": true;
    };
    "trigger": {
      "alias": "trigger";
      "required": false;
      "isSignal": true;
    };
    "staysOpen": {
      "alias": "staysOpen";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "enter": {
      "alias": "enter";
      "required": false;
      "isSignal": true;
    };
    "exit": {
      "alias": "exit";
      "required": false;
      "isSignal": true;
    };
    "for": {
      "alias": "for";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "formatter": {
      "alias": "formatter";
      "required": false;
      "isSignal": true;
    };
    "closeable": {
      "alias": "closeable";
      "required": false;
      "isSignal": true;
    };
    "width": {
      "alias": "width";
      "required": false;
      "isSignal": true;
    };
    "height": {
      "alias": "height";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "opened": "opened";
    "closed": "closed";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["[slot=content]", "[slot=style]", "*"], true, never>;
}
/**
 * Declares the methods available on TooltipComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TooltipMethodNames = 'open' | 'close' | 'attach' | 'play' | 'onEnterAnimation' | 'onExitAnimation' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges' | 'detach';
/**
 * Declares the methods interface for TooltipComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TooltipComponentMethods = MethodMap<TooltipMethodNames>;
/**
 * @public
 */
export declare function provideTooltipComponent(config?: Partial<TooltipElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-tooltip.d.ts.map