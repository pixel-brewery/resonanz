import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { EmojiElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/emoji/EmojiElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the EmojiComponent.
 * Use this token to provide default properties for the EmojiComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const EMOJI_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/media/emoji/IEmojiElementProps").IEmojiElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class EmojiComponent {
  /**
   * Signal input for the `emoji` property.
   *
   * @public
   */
  readonly emoji: InputSignal<EmojiElement['emoji'] | undefined>;
  /**
   * Signal input for the `unicode` property.
   *
   * @public
   */
  readonly unicode: InputSignal<EmojiElement['unicode'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<EmojiElement['themeName'] | undefined>;
  /**
   * Signal input for the `size` property.
   *
   * @public
   */
  readonly size: InputSignal<EmojiElement['size'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<EmojiElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<EmojiElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<EmojiElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<EmojiElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<EmojiElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Converts the current unicode value to its emoji string.
   *
   * @public
   */
  toEmoji(...args: Parameters<EmojiElement['toEmoji']>): ReturnType<EmojiElement['toEmoji']>;
  /**
   * Converts the current emoji string to a normalized unicode representation.
   * Returns an uppercase, hyphen-separated hex codepoint string (e.g., "1F469-200D-1F4BB").
   *
   * @public
   */
  toUnicode(...args: Parameters<EmojiElement['toUnicode']>): ReturnType<EmojiElement['toUnicode']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `toEmoji()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends EmojiMethodNames>(method: TMethod, ...args: Parameters<EmojiComponentMethods[TMethod]>): ReturnType<EmojiComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof EmojiElement>(property: TProperty, value: EmojiElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<EmojiElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<EmojiComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<EmojiComponent, "mosaik-emoji", never, {
    "emoji": {
      "alias": "emoji";
      "required": false;
      "isSignal": true;
    };
    "unicode": {
      "alias": "unicode";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on EmojiComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type EmojiMethodNames = 'toEmoji' | 'toUnicode';
/**
 * Declares the methods interface for EmojiComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type EmojiComponentMethods = MethodMap<EmojiMethodNames>;
/**
 * @public
 */
export declare function provideEmojiComponent(config?: Partial<EmojiElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-emoji.d.ts.map