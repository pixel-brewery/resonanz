import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef, Type } from "@angular/core";
import { SchedulerEventElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/scheduler/SchedulerEventElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { SchedulerElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/scheduler/SchedulerElement";
/**
 * @public
 *
 * Injection token for the default properties of the SchedulerEventComponent.
 * Use this token to provide default properties for the SchedulerEventComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const SCHEDULER_EVENT_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/inputs/scheduler/ISchedulerEventElementProps").ISchedulerEventElementProps>>;
/**
 * @public
 *
 * @slot content - The content of the event (timeGrid, timeline and agenda layouts)
 * @slot footer - Footer content (timeGrid and timeline card layouts)
 * @slot title - The title content of the event (all layouts)
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class SchedulerEventComponent {
  /**
   * Signal input for the `eventKey` property.
   *
   * @public
   */
  readonly eventKey: InputSignal<SchedulerEventElement['eventKey'] | undefined>;
  /**
   * Signal input for the `allDay` property.
   *
   * @public
   */
  readonly allDay: InputSignal<SchedulerEventElement['allDay'] | undefined>;
  /**
   * Signal input for the `draggable` property.
   *
   * @public
   */
  readonly draggable: InputSignal<SchedulerEventElement['draggable'] | undefined>;
  /**
   * Signal input for the `resizable` property.
   *
   * @public
   */
  readonly resizable: InputSignal<SchedulerEventElement['resizable'] | undefined>;
  /**
   * Signal input for the `resizeEdges` property.
   *
   * @public
   */
  readonly resizeEdges: InputSignal<SchedulerEventElement['resizeEdges'] | undefined>;
  /**
   * Signal input for the `pinned` property.
   *
   * @public
   */
  readonly pinned: InputSignal<SchedulerEventElement['pinned'] | undefined>;
  /**
   * Signal input for the `status` property.
   *
   * @public
   */
  readonly status: InputSignal<SchedulerEventElement['status'] | undefined>;
  /**
   * Signal input for the `popupTemplate` property.
   *
   * @public
   */
  readonly popupTemplate: InputSignal<SchedulerEventElement['popupTemplate'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<SchedulerEventElement['themeName'] | undefined>;
  /**
   * Signal input for the `ripple` property.
   *
   * @public
   */
  readonly ripple: InputSignal<SchedulerEventElement['ripple'] | undefined>;
  /**
   * Signal input for the `isFocused` property.
   *
   * @public
   */
  readonly isFocused: InputSignal<SchedulerEventElement['isFocused'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<SchedulerEventElement['disabled'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<SchedulerEventElement['variant'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<SchedulerEventElement['value'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<SchedulerEventElement['appearance'] | undefined>;
  /**
   * Signal input for the `start` property.
   *
   * @public
   */
  readonly start: InputSignal<SchedulerEventElement['start'] | undefined>;
  /**
   * Signal input for the `end` property.
   *
   * @public
   */
  readonly end: InputSignal<SchedulerEventElement['end'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<SchedulerEventElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<SchedulerEventElement['lang'] | undefined>;
  /**
   * Output signal for the `schedulerEventChange` event.
   *
   * @public
   */
  readonly schedulerEventChange: OutputEmitterRef<ElementEventDetail<SchedulerEventElement, 'schedulerEventChange'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<SchedulerEventElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<SchedulerEventElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<SchedulerEventElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: SchedulerEventElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: SchedulerEventElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   * @param args - The arguments of `assignToSlot`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * - `node` - The nodes to assign to the slot.
   */
  assignToSlot(...args: Parameters<SchedulerEventElement['assignToSlot']>): ReturnType<SchedulerEventElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   * This method extracts text content recursively, including from Shadow DOMs
   * and Custom Elements with known text properties (like `mosaik-text`).
   *
   * @public
   * @param args - The arguments of `getSlotContent`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<SchedulerEventElement['getSlotContent']>): ReturnType<SchedulerEventElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @param args - The arguments of `hasSlotContent`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<SchedulerEventElement['hasSlotContent']>): ReturnType<SchedulerEventElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @param args - The arguments of `hasSlot`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<SchedulerEventElement['hasSlot']>): ReturnType<SchedulerEventElement['hasSlot']>;
  /**
   * Called when the slot changes.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<SchedulerEventElement['onSlotChanges']>): ReturnType<SchedulerEventElement['onSlotChanges']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `assignToSlot()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * The other names it accepts are not public in the type declarations of `SchedulerEventElement`.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends SchedulerEventMethodNames>(method: TMethod, ...args: Parameters<SchedulerEventComponentMethods[TMethod]>): ReturnType<SchedulerEventComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof SchedulerEventElement>(property: TProperty, value: SchedulerEventElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<SchedulerEventElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SchedulerEventComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SchedulerEventComponent, "mosaik-scheduler-event", never, {
    "eventKey": {
      "alias": "eventKey";
      "required": false;
      "isSignal": true;
    };
    "allDay": {
      "alias": "allDay";
      "required": false;
      "isSignal": true;
    };
    "draggable": {
      "alias": "draggable";
      "required": false;
      "isSignal": true;
    };
    "resizable": {
      "alias": "resizable";
      "required": false;
      "isSignal": true;
    };
    "resizeEdges": {
      "alias": "resizeEdges";
      "required": false;
      "isSignal": true;
    };
    "pinned": {
      "alias": "pinned";
      "required": false;
      "isSignal": true;
    };
    "status": {
      "alias": "status";
      "required": false;
      "isSignal": true;
    };
    "popupTemplate": {
      "alias": "popupTemplate";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "ripple": {
      "alias": "ripple";
      "required": false;
      "isSignal": true;
    };
    "isFocused": {
      "alias": "isFocused";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "start": {
      "alias": "start";
      "required": false;
      "isSignal": true;
    };
    "end": {
      "alias": "end";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "schedulerEventChange": "schedulerEventChange";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on SchedulerEventComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SchedulerEventMethodNames = 'setInteractionActive' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges';
/**
 * Declares the methods interface for SchedulerEventComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SchedulerEventComponentMethods = MethodMap<SchedulerEventMethodNames>;
/**
 * @public
 */
export declare function provideSchedulerEventComponent(config?: Partial<SchedulerEventElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the SchedulerComponent.
 * Use this token to provide default properties for the SchedulerComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const SCHEDULER_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/inputs/scheduler/ISchedulerElementProps").ISchedulerElementProps>>;
/**
 * @public
 *
 * Injection token for the intl configuration of the SchedulerComponent.
 * Provide a partial intl object or an injectable class that resolves translations.
 * This allows third-party applications to override the default intl labels
 * globally, per route, or per component via Angular's dependency injection.
 *
 * Merge order: Foundation defaults → DI intl → [intl] input binding.
 */
export declare const SCHEDULER_INTL: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").SchedulerElementIntl>>;
/**
 * @public
 *
 * @slot  - Default slot for mosaik-scheduler-event elements
 * @slot toolbar - The toolbar slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class SchedulerComponent {
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<Partial<SchedulerElement['intl']> | undefined>;
  /**
   * Signal input for the `view` property.
   *
   * @public
   */
  readonly view: InputSignal<SchedulerElement['view'] | undefined>;
  /**
   * Signal input for the `startDate` property.
   *
   * @public
   */
  readonly startDate: InputSignal<SchedulerElement['startDate'] | undefined>;
  /**
   * Signal input for the `days` property.
   *
   * @public
   */
  readonly days: InputSignal<SchedulerElement['days'] | undefined>;
  /**
   * Signal input for the `timelineScale` property.
   *
   * @public
   */
  readonly timelineScale: InputSignal<SchedulerElement['timelineScale'] | undefined>;
  /**
   * Signal input for the `timelineSlotWidth` property.
   *
   * @public
   */
  readonly timelineSlotWidth: InputSignal<SchedulerElement['timelineSlotWidth'] | undefined>;
  /**
   * Signal input for the `hourStart` property.
   *
   * @public
   */
  readonly hourStart: InputSignal<SchedulerElement['hourStart'] | undefined>;
  /**
   * Signal input for the `hourEnd` property.
   *
   * @public
   */
  readonly hourEnd: InputSignal<SchedulerElement['hourEnd'] | undefined>;
  /**
   * Signal input for the `stepMinutes` property.
   *
   * @public
   */
  readonly stepMinutes: InputSignal<SchedulerElement['stepMinutes'] | undefined>;
  /**
   * Signal input for the `eventLayout` property.
   *
   * @public
   */
  readonly eventLayout: InputSignal<SchedulerElement['eventLayout'] | undefined>;
  /**
   * Signal input for the `gestureEnabled` property.
   *
   * @public
   */
  readonly gestureEnabled: InputSignal<SchedulerElement['gestureEnabled'] | undefined>;
  /**
   * Signal input for the `dragdrop` property.
   *
   * @public
   */
  readonly dragdrop: InputSignal<SchedulerElement['dragdrop'] | undefined>;
  /**
   * Signal input for the `dragPreviewMode` property.
   *
   * @public
   */
  readonly dragPreviewMode: InputSignal<SchedulerElement['dragPreviewMode'] | undefined>;
  /**
   * Signal input for the `resizable` property.
   *
   * @public
   */
  readonly resizable: InputSignal<SchedulerElement['resizable'] | undefined>;
  /**
   * Signal input for the `mutationMode` property.
   *
   * @public
   */
  readonly mutationMode: InputSignal<SchedulerElement['mutationMode'] | undefined>;
  /**
   * Signal input for the `snapMinutes` property.
   *
   * @public
   */
  readonly snapMinutes: InputSignal<SchedulerElement['snapMinutes'] | undefined>;
  /**
   * Signal input for the `eventAllow` property.
   *
   * @public
   */
  readonly eventAllow: InputSignal<SchedulerElement['eventAllow'] | undefined>;
  /**
   * Signal input for the `rangeSelection` property.
   *
   * @public
   */
  readonly rangeSelection: InputSignal<SchedulerElement['rangeSelection'] | undefined>;
  /**
   * Signal input for the `selectAllow` property.
   *
   * @public
   */
  readonly selectAllow: InputSignal<SchedulerElement['selectAllow'] | undefined>;
  /**
   * Signal input for the `workingHours` property.
   *
   * @public
   */
  readonly workingHours: InputSignal<SchedulerElement['workingHours'] | undefined>;
  /**
   * Signal input for the `blockedRanges` property.
   *
   * @public
   */
  readonly blockedRanges: InputSignal<SchedulerElement['blockedRanges'] | undefined>;
  /**
   * Signal input for the `allowOverlap` property.
   *
   * @public
   */
  readonly allowOverlap: InputSignal<SchedulerElement['allowOverlap'] | undefined>;
  /**
   * Signal input for the `timezone` property.
   *
   * @public
   */
  readonly timezone: InputSignal<SchedulerElement['timezone'] | undefined>;
  /**
   * Signal input for the `blackoutDates` property.
   *
   * @public
   */
  readonly blackoutDates: InputSignal<SchedulerElement['blackoutDates'] | undefined>;
  /**
   * Signal input for the `specialDates` property.
   *
   * @public
   */
  readonly specialDates: InputSignal<SchedulerElement['specialDates'] | undefined>;
  /**
   * Signal input for the `firstDayOfWeek` property.
   *
   * @public
   */
  readonly firstDayOfWeek: InputSignal<SchedulerElement['firstDayOfWeek'] | undefined>;
  /**
   * Signal input for the `isTodayHighlighted` property.
   *
   * @public
   */
  readonly isTodayHighlighted: InputSignal<SchedulerElement['isTodayHighlighted'] | undefined>;
  /**
   * Signal input for the `isWeekendHighlighted` property.
   *
   * @public
   */
  readonly isWeekendHighlighted: InputSignal<SchedulerElement['isWeekendHighlighted'] | undefined>;
  /**
   * Signal input for the `allDayVisibility` property.
   *
   * @public
   */
  readonly allDayVisibility: InputSignal<SchedulerElement['allDayVisibility'] | undefined>;
  /**
   * Signal input for the `showWeekNumbers` property.
   *
   * @public
   */
  readonly showWeekNumbers: InputSignal<SchedulerElement['showWeekNumbers'] | undefined>;
  /**
   * Signal input for the `showAdjacent` property.
   *
   * @public
   */
  readonly showAdjacent: InputSignal<SchedulerElement['showAdjacent'] | undefined>;
  /**
   * Signal input for the `maxEventsPerDay` property.
   *
   * @public
   */
  readonly maxEventsPerDay: InputSignal<SchedulerElement['maxEventsPerDay'] | undefined>;
  /**
   * Signal input for the `daysAhead` property.
   *
   * @public
   */
  readonly daysAhead: InputSignal<SchedulerElement['daysAhead'] | undefined>;
  /**
   * Signal input for the `weekdayFormat` property.
   *
   * @public
   */
  readonly weekdayFormat: InputSignal<SchedulerElement['weekdayFormat'] | undefined>;
  /**
   * Signal input for the `dayFormat` property.
   *
   * @public
   */
  readonly dayFormat: InputSignal<SchedulerElement['dayFormat'] | undefined>;
  /**
   * Signal input for the `timeFormat` property.
   *
   * @public
   */
  readonly timeFormat: InputSignal<SchedulerElement['timeFormat'] | undefined>;
  /**
   * Signal input for the `monthDayFormat` property.
   *
   * @public
   */
  readonly monthDayFormat: InputSignal<SchedulerElement['monthDayFormat'] | undefined>;
  /**
   * Signal input for the `showTools` property.
   *
   * @public
   */
  readonly showTools: InputSignal<SchedulerElement['showTools'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<SchedulerElement['themeName'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<SchedulerElement['appearance'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<SchedulerElement['variant'] | undefined>;
  /**
   * Signal input for the `locale` property.
   *
   * @public
   */
  readonly locale: InputSignal<SchedulerElement['locale'] | undefined>;
  /**
   * Signal input for the `size` property.
   *
   * @public
   */
  readonly size: InputSignal<SchedulerElement['size'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<SchedulerElement['disabled'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<SchedulerElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<SchedulerElement['lang'] | undefined>;
  /**
   * Output signal for the `schedulerBeforeEventActivate` event.
   *
   * @public
   */
  readonly schedulerBeforeEventActivate: OutputEmitterRef<ElementEventDetail<SchedulerElement, 'schedulerBeforeEventActivate'>>;
  /**
   * Output signal for the `schedulerEventActivate` event.
   *
   * @public
   */
  readonly schedulerEventActivate: OutputEmitterRef<ElementEventDetail<SchedulerElement, 'schedulerEventActivate'>>;
  /**
   * Output signal for the `schedulerBeforeSelectRange` event.
   *
   * @public
   */
  readonly schedulerBeforeSelectRange: OutputEmitterRef<ElementEventDetail<SchedulerElement, 'schedulerBeforeSelectRange'>>;
  /**
   * Output signal for the `schedulerSelectRange` event.
   *
   * @public
   */
  readonly schedulerSelectRange: OutputEmitterRef<ElementEventDetail<SchedulerElement, 'schedulerSelectRange'>>;
  /**
   * Output signal for the `schedulerRangeChange` event.
   *
   * @public
   */
  readonly schedulerRangeChange: OutputEmitterRef<ElementEventDetail<SchedulerElement, 'schedulerRangeChange'>>;
  /**
   * Output signal for the `schedulerBeforeEventMove` event.
   *
   * @public
   */
  readonly schedulerBeforeEventMove: OutputEmitterRef<ElementEventDetail<SchedulerElement, 'schedulerBeforeEventMove'>>;
  /**
   * Output signal for the `schedulerEventMove` event.
   *
   * @public
   */
  readonly schedulerEventMove: OutputEmitterRef<ElementEventDetail<SchedulerElement, 'schedulerEventMove'>>;
  /**
   * Output signal for the `schedulerBeforeEventResize` event.
   *
   * @public
   */
  readonly schedulerBeforeEventResize: OutputEmitterRef<ElementEventDetail<SchedulerElement, 'schedulerBeforeEventResize'>>;
  /**
   * Output signal for the `schedulerEventResize` event.
   *
   * @public
   */
  readonly schedulerEventResize: OutputEmitterRef<ElementEventDetail<SchedulerElement, 'schedulerEventResize'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<SchedulerElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<SchedulerElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<SchedulerElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: SchedulerElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: SchedulerElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Returns true when a date is configured as blackout date.
   *
   * @public
   * @param args - The arguments of `isBlackoutDate`:
   * - `date` - The date to check.
   */
  isBlackoutDate(...args: Parameters<SchedulerElement['isBlackoutDate']>): ReturnType<SchedulerElement['isBlackoutDate']>;
  /**
   * Returns true when a date is configured as special date.
   *
   * @public
   * @param args - The arguments of `isSpecialDate`:
   * - `date` - The date to check.
   */
  isSpecialDate(...args: Parameters<SchedulerElement['isSpecialDate']>): ReturnType<SchedulerElement['isSpecialDate']>;
  /**
   * Returns true when the given date is weekend.
   *
   * @public
   * @param args - The arguments of `isWeekend`:
   * - `date` - The date to check.
   */
  isWeekend(...args: Parameters<SchedulerElement['isWeekend']>): ReturnType<SchedulerElement['isWeekend']>;
  /**
   * Returns true when the given date is today.
   *
   * @public
   * @param args - The arguments of `isToday`:
   * - `date` - The date to check.
   */
  isToday(...args: Parameters<SchedulerElement['isToday']>): ReturnType<SchedulerElement['isToday']>;
  /**
   * Returns the current time in the configured display time zone.
   *
   * @public
   */
  now(...args: Parameters<SchedulerElement['now']>): ReturnType<SchedulerElement['now']>;
  /**
   * Gets events for a specific day.
   *
   * @public
   * @param args - The arguments of `getEventsForDay`:
   * - `dayKey` - The day key (YYYY-MM-DD).
   * @returns Array of positioned events for that day.
   */
  getEventsForDay(...args: Parameters<SchedulerElement['getEventsForDay']>): ReturnType<SchedulerElement['getEventsForDay']>;
  /**
   * Gets all-day events for a specific day.
   *
   * @public
   * @param args - The arguments of `getAllDayEventsForDay`:
   * - `dayKey` - The day key (YYYY-MM-DD).
   * @returns Array of all-day events for that day.
   */
  getAllDayEventsForDay(...args: Parameters<SchedulerElement['getAllDayEventsForDay']>): ReturnType<SchedulerElement['getAllDayEventsForDay']>;
  /**
   * Gets all all-day events across all visible days.
   *
   * @public
   * @returns Array of all all-day events.
   */
  getAllDayEvents(...args: Parameters<SchedulerElement['getAllDayEvents']>): ReturnType<SchedulerElement['getAllDayEvents']>;
  /**
   * Activates an event programmatically.
   *
   * @public
   * @param args - The arguments of `activateEvent`:
   * - `eventKey` - The event key to activate.
   * - `trigger` - The activation trigger.
   * @returns True if activation succeeded.
   */
  activateEvent(...args: Parameters<SchedulerElement['activateEvent']>): ReturnType<SchedulerElement['activateEvent']>;
  /**
   * Navigates to a specific date.
   *
   * @public
   * @param args - The arguments of `navigateToDate`:
   * - `date` - The date to navigate to.
   */
  navigateToDate(...args: Parameters<SchedulerElement['navigateToDate']>): ReturnType<SchedulerElement['navigateToDate']>;
  /**
   * Navigates to today.
   *
   * @public
   */
  navigateToday(...args: Parameters<SchedulerElement['navigateToday']>): ReturnType<SchedulerElement['navigateToday']>;
  /**
   * Navigates to the previous period.
   *
   * @public
   */
  navigatePrevious(...args: Parameters<SchedulerElement['navigatePrevious']>): ReturnType<SchedulerElement['navigatePrevious']>;
  /**
   * Navigates to the next period.
   *
   * @public
   */
  navigateNext(...args: Parameters<SchedulerElement['navigateNext']>): ReturnType<SchedulerElement['navigateNext']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   * @param args - The arguments of `assignToSlot`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * - `node` - The nodes to assign to the slot.
   */
  assignToSlot(...args: Parameters<SchedulerElement['assignToSlot']>): ReturnType<SchedulerElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   * This method extracts text content recursively, including from Shadow DOMs
   * and Custom Elements with known text properties (like `mosaik-text`).
   *
   * @public
   * @param args - The arguments of `getSlotContent`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<SchedulerElement['getSlotContent']>): ReturnType<SchedulerElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @param args - The arguments of `hasSlotContent`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<SchedulerElement['hasSlotContent']>): ReturnType<SchedulerElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @param args - The arguments of `hasSlot`:
   * - `slotName` - The slot name (For default slot, pass an empty string).
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<SchedulerElement['hasSlot']>): ReturnType<SchedulerElement['hasSlot']>;
  /**
   * Called when the slot changes.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<SchedulerElement['onSlotChanges']>): ReturnType<SchedulerElement['onSlotChanges']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `isBlackoutDate()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * The other names it accepts are not public in the type declarations of `SchedulerElement`.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends SchedulerMethodNames>(method: TMethod, ...args: Parameters<SchedulerComponentMethods[TMethod]>): ReturnType<SchedulerComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof SchedulerElement>(property: TProperty, value: SchedulerElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<SchedulerElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SchedulerComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SchedulerComponent, "mosaik-scheduler", never, {
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "view": {
      "alias": "view";
      "required": false;
      "isSignal": true;
    };
    "startDate": {
      "alias": "startDate";
      "required": false;
      "isSignal": true;
    };
    "days": {
      "alias": "days";
      "required": false;
      "isSignal": true;
    };
    "timelineScale": {
      "alias": "timelineScale";
      "required": false;
      "isSignal": true;
    };
    "timelineSlotWidth": {
      "alias": "timelineSlotWidth";
      "required": false;
      "isSignal": true;
    };
    "hourStart": {
      "alias": "hourStart";
      "required": false;
      "isSignal": true;
    };
    "hourEnd": {
      "alias": "hourEnd";
      "required": false;
      "isSignal": true;
    };
    "stepMinutes": {
      "alias": "stepMinutes";
      "required": false;
      "isSignal": true;
    };
    "eventLayout": {
      "alias": "eventLayout";
      "required": false;
      "isSignal": true;
    };
    "gestureEnabled": {
      "alias": "gestureEnabled";
      "required": false;
      "isSignal": true;
    };
    "dragdrop": {
      "alias": "dragdrop";
      "required": false;
      "isSignal": true;
    };
    "dragPreviewMode": {
      "alias": "dragPreviewMode";
      "required": false;
      "isSignal": true;
    };
    "resizable": {
      "alias": "resizable";
      "required": false;
      "isSignal": true;
    };
    "mutationMode": {
      "alias": "mutationMode";
      "required": false;
      "isSignal": true;
    };
    "snapMinutes": {
      "alias": "snapMinutes";
      "required": false;
      "isSignal": true;
    };
    "eventAllow": {
      "alias": "eventAllow";
      "required": false;
      "isSignal": true;
    };
    "rangeSelection": {
      "alias": "rangeSelection";
      "required": false;
      "isSignal": true;
    };
    "selectAllow": {
      "alias": "selectAllow";
      "required": false;
      "isSignal": true;
    };
    "workingHours": {
      "alias": "workingHours";
      "required": false;
      "isSignal": true;
    };
    "blockedRanges": {
      "alias": "blockedRanges";
      "required": false;
      "isSignal": true;
    };
    "allowOverlap": {
      "alias": "allowOverlap";
      "required": false;
      "isSignal": true;
    };
    "timezone": {
      "alias": "timezone";
      "required": false;
      "isSignal": true;
    };
    "blackoutDates": {
      "alias": "blackoutDates";
      "required": false;
      "isSignal": true;
    };
    "specialDates": {
      "alias": "specialDates";
      "required": false;
      "isSignal": true;
    };
    "firstDayOfWeek": {
      "alias": "firstDayOfWeek";
      "required": false;
      "isSignal": true;
    };
    "isTodayHighlighted": {
      "alias": "isTodayHighlighted";
      "required": false;
      "isSignal": true;
    };
    "isWeekendHighlighted": {
      "alias": "isWeekendHighlighted";
      "required": false;
      "isSignal": true;
    };
    "allDayVisibility": {
      "alias": "allDayVisibility";
      "required": false;
      "isSignal": true;
    };
    "showWeekNumbers": {
      "alias": "showWeekNumbers";
      "required": false;
      "isSignal": true;
    };
    "showAdjacent": {
      "alias": "showAdjacent";
      "required": false;
      "isSignal": true;
    };
    "maxEventsPerDay": {
      "alias": "maxEventsPerDay";
      "required": false;
      "isSignal": true;
    };
    "daysAhead": {
      "alias": "daysAhead";
      "required": false;
      "isSignal": true;
    };
    "weekdayFormat": {
      "alias": "weekdayFormat";
      "required": false;
      "isSignal": true;
    };
    "dayFormat": {
      "alias": "dayFormat";
      "required": false;
      "isSignal": true;
    };
    "timeFormat": {
      "alias": "timeFormat";
      "required": false;
      "isSignal": true;
    };
    "monthDayFormat": {
      "alias": "monthDayFormat";
      "required": false;
      "isSignal": true;
    };
    "showTools": {
      "alias": "showTools";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "locale": {
      "alias": "locale";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "schedulerBeforeEventActivate": "schedulerBeforeEventActivate";
    "schedulerEventActivate": "schedulerEventActivate";
    "schedulerBeforeSelectRange": "schedulerBeforeSelectRange";
    "schedulerSelectRange": "schedulerSelectRange";
    "schedulerRangeChange": "schedulerRangeChange";
    "schedulerBeforeEventMove": "schedulerBeforeEventMove";
    "schedulerEventMove": "schedulerEventMove";
    "schedulerBeforeEventResize": "schedulerBeforeEventResize";
    "schedulerEventResize": "schedulerEventResize";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on SchedulerComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SchedulerMethodNames = 'cancelEventInteraction' | 'cancelRangeSelection' | 'isRangeSelectionAllowed' | 'commitRangeSelection' | 'canMoveEvent' | 'canResizeEvent' | 'isEventInteractionAllowed' | 'commitEventInteraction' | 'isBlackoutDate' | 'isSpecialDate' | 'isWeekend' | 'isToday' | 'now' | 'getEventsForDay' | 'getAllDayEventsForDay' | 'getAllDayEvents' | 'activateEvent' | 'navigateToDate' | 'navigateToday' | 'navigatePrevious' | 'navigateNext' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges';
/**
 * Declares the methods interface for SchedulerComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SchedulerComponentMethods = MethodMap<SchedulerMethodNames>;
/**
 * @public
 */
export declare function provideSchedulerComponent(config?: Partial<SchedulerElement.Props>, intl?: Partial<SchedulerElement['intl']> | Type<Partial<SchedulerElement['intl']>>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-scheduler.d.ts.map