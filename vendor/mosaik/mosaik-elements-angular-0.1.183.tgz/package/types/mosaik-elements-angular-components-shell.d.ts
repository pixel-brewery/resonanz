import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { AppHeaderElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/shell/AppHeaderElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { AppElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/shell/AppElement";
/**
 * @public
 *
 * Injection token for the default properties of the AppHeaderComponent.
 * Use this token to provide default properties for the AppHeaderComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const APP_HEADER_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/shell/IAppHeaderElementProps").IAppHeaderElementProps>>;
/**
 * @public
 *
 * @slot actions - The slot for action buttons or icons, typically used for user profile options or quick actions.
 * @slot brand - The slot for the application branding, such as a logo or title.
 * @slot menu - The slot for the menu button, which can be used to toggle navigation drawers or other menus.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class AppHeaderComponent {
  /**
   * Signal input for the `isToggled` property.
   *
   * @public
   */
  readonly isToggled: InputSignal<AppHeaderElement['isToggled'] | undefined>;
  /**
   * Signal input for the `scrollTargetFn` property.
   *
   * @public
   */
  readonly scrollTargetFn: InputSignal<AppHeaderElement['scrollTargetFn'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<AppHeaderElement['themeName'] | undefined>;
  /**
   * Signal input for the `isBusy` property.
   *
   * @public
   */
  readonly isBusy: InputSignal<AppHeaderElement['isBusy'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<AppHeaderElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<AppHeaderElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<AppHeaderElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<AppHeaderElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<AppHeaderElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: AppHeaderElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: AppHeaderElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<AppHeaderElement['onSlotChanges']>): ReturnType<AppHeaderElement['onSlotChanges']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<AppHeaderElement['assignToSlot']>): ReturnType<AppHeaderElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<AppHeaderElement['getSlotContent']>): ReturnType<AppHeaderElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<AppHeaderElement['hasSlotContent']>): ReturnType<AppHeaderElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<AppHeaderElement['hasSlot']>): ReturnType<AppHeaderElement['hasSlot']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `onSlotChanges()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends AppHeaderMethodNames>(method: TMethod, ...args: Parameters<AppHeaderComponentMethods[TMethod]>): ReturnType<AppHeaderComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof AppHeaderElement>(property: TProperty, value: AppHeaderElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<AppHeaderElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<AppHeaderComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AppHeaderComponent, "mosaik-app-header", never, {
    "isToggled": {
      "alias": "isToggled";
      "required": false;
      "isSignal": true;
    };
    "scrollTargetFn": {
      "alias": "scrollTargetFn";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "isBusy": {
      "alias": "isBusy";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on AppHeaderComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type AppHeaderMethodNames = 'onSlotChanges' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot';
/**
 * Declares the methods interface for AppHeaderComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type AppHeaderComponentMethods = MethodMap<AppHeaderMethodNames>;
/**
 * @public
 */
export declare function provideAppHeaderComponent(config?: Partial<AppHeaderElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the AppComponent.
 * Use this token to provide default properties for the AppComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const APP_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/shell/IAppElementProps").IAppElementProps>>;
/**
 * @public
 *
 * @slot content - Main content area for primary application content and views
 * @slot footer - Footer area for secondary information, links, and application metadata
 * @slot header - The header slot.
 * @slot headerActions - The headerActions slot.
 * @slot headerLogo - The headerLogo slot.
 * @slot headerMenu - The headerMenu slot.
 * @slot nav - Navigation drawer content area for primary navigation links and menu items
 * @slot rail - The rail slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class AppComponent {
  /**
   * Signal input for the `theme` property.
   *
   * @public
   */
  readonly theme: InputSignal<AppElement['theme'] | undefined>;
  /**
   * Signal input for the `isNavOpen` property.
   *
   * @public
   */
  readonly isNavOpen: InputSignal<AppElement['isNavOpen'] | undefined>;
  /**
   * Signal input for the `hasNav` property.
   *
   * @public
   */
  readonly hasNav: InputSignal<AppElement['hasNav'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<AppElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<AppElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<AppElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<AppElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<AppElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<AppElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: AppElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: AppElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Toggles the navigation drawer.
   *
   * @public
   */
  toggleNavigation(...args: Parameters<AppElement['toggleNavigation']>): ReturnType<AppElement['toggleNavigation']>;
  /**
   * Opens the navigation drawer.
   *
   * @public
   */
  openNavigation(...args: Parameters<AppElement['openNavigation']>): ReturnType<AppElement['openNavigation']>;
  /**
   * Closes the navigation drawer.
   *
   * @public
   */
  closeNavigation(...args: Parameters<AppElement['closeNavigation']>): ReturnType<AppElement['closeNavigation']>;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   * @param args - The arguments of `onSlotChanges`:
   * - `slotName` - The optional slot name (For default slot, passes undefined).
   */
  onSlotChanges(...args: Parameters<AppElement['onSlotChanges']>): ReturnType<AppElement['onSlotChanges']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<AppElement['assignToSlot']>): ReturnType<AppElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<AppElement['getSlotContent']>): ReturnType<AppElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<AppElement['hasSlotContent']>): ReturnType<AppElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<AppElement['hasSlot']>): ReturnType<AppElement['hasSlot']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `toggleNavigation()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends AppMethodNames>(method: TMethod, ...args: Parameters<AppComponentMethods[TMethod]>): ReturnType<AppComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof AppElement>(property: TProperty, value: AppElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<AppElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<AppComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AppComponent, "mosaik-app", never, {
    "theme": {
      "alias": "theme";
      "required": false;
      "isSignal": true;
    };
    "isNavOpen": {
      "alias": "isNavOpen";
      "required": false;
      "isSignal": true;
    };
    "hasNav": {
      "alias": "hasNav";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on AppComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type AppMethodNames = 'toggleNavigation' | 'openNavigation' | 'closeNavigation' | 'onSlotChanges' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot';
/**
 * Declares the methods interface for AppComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type AppComponentMethods = MethodMap<AppMethodNames>;
/**
 * @public
 */
export declare function provideAppComponent(config?: Partial<AppElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-shell.d.ts.map