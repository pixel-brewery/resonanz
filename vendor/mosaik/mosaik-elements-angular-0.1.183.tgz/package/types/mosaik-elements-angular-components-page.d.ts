import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { PageContentElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/page/PageContentElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { PageHeaderElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/page/PageHeaderElement";
import { PagePreContentElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/page/PagePreContentElement";
import { PagePreHeaderElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/page/PagePreHeaderElement";
import { PageElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/page/PageElement";
import { PageMenuElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/page/PageMenuElement";
/**
 * @public
 *
 * Injection token for the default properties of the PageContentComponent.
 * Use this token to provide default properties for the PageContentComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const PAGE_CONTENT_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/layouts/page/IPageContentElementProps").IPageContentElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot for placing child elements.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class PageContentComponent {
  /**
   * Signal input for the `fullWidth` property.
   *
   * @public
   */
  readonly fullWidth: InputSignal<PageContentElement['fullWidth'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<PageContentElement['themeName'] | undefined>;
  /**
   * Signal input for the `inset` property.
   *
   * @public
   */
  readonly inset: InputSignal<PageContentElement['inset'] | undefined>;
  /**
   * Signal input for the `horizontalAlignment` property.
   *
   * @public
   */
  readonly horizontalAlignment: InputSignal<PageContentElement['horizontalAlignment'] | undefined>;
  /**
   * Signal input for the `verticalAlignment` property.
   *
   * @public
   */
  readonly verticalAlignment: InputSignal<PageContentElement['verticalAlignment'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<PageContentElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<PageContentElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<PageContentElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<PageContentElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<PageContentElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof PageContentElement>(property: TProperty, value: PageContentElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<PageContentElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<PageContentComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<PageContentComponent, "mosaik-page-content", never, {
    "fullWidth": {
      "alias": "fullWidth";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "inset": {
      "alias": "inset";
      "required": false;
      "isSignal": true;
    };
    "horizontalAlignment": {
      "alias": "horizontalAlignment";
      "required": false;
      "isSignal": true;
    };
    "verticalAlignment": {
      "alias": "verticalAlignment";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on PageContentComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type PageContentMethodNames = never;
/**
 * Declares the methods interface for PageContentComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type PageContentComponentMethods = MethodMap<PageContentMethodNames>;
/**
 * @public
 */
export declare function providePageContentComponent(config?: Partial<PageContentElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the PageHeaderComponent.
 * Use this token to provide default properties for the PageHeaderComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const PAGE_HEADER_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/layouts/page/IPageHeaderElementProps").IPageHeaderElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot.
 * @slot additionalHeader - The additionalHeader slot.
 * @slot header - The header content.
 * @slot prefix - The prefix slot.
 * @slot subHeader - The subHeader slot.
 * @slot suffix - The suffix slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class PageHeaderComponent {
  /**
   * Signal input for the `text` property.
   *
   * @public
   */
  readonly text: InputSignal<PageHeaderElement['text'] | undefined>;
  /**
   * Signal input for the `subText` property.
   *
   * @public
   */
  readonly subText: InputSignal<PageHeaderElement['subText'] | undefined>;
  /**
   * Signal input for the `additionalText` property.
   *
   * @public
   */
  readonly additionalText: InputSignal<PageHeaderElement['additionalText'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<PageHeaderElement['themeName'] | undefined>;
  /**
   * Signal input for the `inset` property.
   *
   * @public
   */
  readonly inset: InputSignal<PageHeaderElement['inset'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<PageHeaderElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<PageHeaderElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<PageHeaderElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<PageHeaderElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<PageHeaderElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: PageHeaderElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: PageHeaderElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<PageHeaderElement['assignToSlot']>): ReturnType<PageHeaderElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<PageHeaderElement['getSlotContent']>): ReturnType<PageHeaderElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<PageHeaderElement['hasSlotContent']>): ReturnType<PageHeaderElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<PageHeaderElement['hasSlot']>): ReturnType<PageHeaderElement['hasSlot']>;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<PageHeaderElement['onSlotChanges']>): ReturnType<PageHeaderElement['onSlotChanges']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `assignToSlot()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends PageHeaderMethodNames>(method: TMethod, ...args: Parameters<PageHeaderComponentMethods[TMethod]>): ReturnType<PageHeaderComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof PageHeaderElement>(property: TProperty, value: PageHeaderElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<PageHeaderElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<PageHeaderComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<PageHeaderComponent, "mosaik-page-header", never, {
    "text": {
      "alias": "text";
      "required": false;
      "isSignal": true;
    };
    "subText": {
      "alias": "subText";
      "required": false;
      "isSignal": true;
    };
    "additionalText": {
      "alias": "additionalText";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "inset": {
      "alias": "inset";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on PageHeaderComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type PageHeaderMethodNames = 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges';
/**
 * Declares the methods interface for PageHeaderComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type PageHeaderComponentMethods = MethodMap<PageHeaderMethodNames>;
/**
 * @public
 */
export declare function providePageHeaderComponent(config?: Partial<PageHeaderElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the PagePreContentComponent.
 * Use this token to provide default properties for the PagePreContentComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const PAGE_PRE_CONTENT_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/layouts/page/IPagePreContentElementProps").IPagePreContentElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class PagePreContentComponent {
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<PagePreContentElement['themeName'] | undefined>;
  /**
   * Signal input for the `inset` property.
   *
   * @public
   */
  readonly inset: InputSignal<PagePreContentElement['inset'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<PagePreContentElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<PagePreContentElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<PagePreContentElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<PagePreContentElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<PagePreContentElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof PagePreContentElement>(property: TProperty, value: PagePreContentElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<PagePreContentElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<PagePreContentComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<PagePreContentComponent, "mosaik-page-pre-content", never, {
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "inset": {
      "alias": "inset";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on PagePreContentComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type PagePreContentMethodNames = never;
/**
 * Declares the methods interface for PagePreContentComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type PagePreContentComponentMethods = MethodMap<PagePreContentMethodNames>;
/**
 * @public
 */
export declare function providePagePreContentComponent(config?: Partial<PagePreContentElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the PagePreHeaderComponent.
 * Use this token to provide default properties for the PagePreHeaderComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const PAGE_PRE_HEADER_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/layouts/page/IPagePreHeaderElementProps").IPagePreHeaderElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class PagePreHeaderComponent {
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<PagePreHeaderElement['themeName'] | undefined>;
  /**
   * Signal input for the `inset` property.
   *
   * @public
   */
  readonly inset: InputSignal<PagePreHeaderElement['inset'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<PagePreHeaderElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<PagePreHeaderElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<PagePreHeaderElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<PagePreHeaderElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<PagePreHeaderElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof PagePreHeaderElement>(property: TProperty, value: PagePreHeaderElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<PagePreHeaderElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<PagePreHeaderComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<PagePreHeaderComponent, "mosaik-page-pre-header", never, {
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "inset": {
      "alias": "inset";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on PagePreHeaderComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type PagePreHeaderMethodNames = never;
/**
 * Declares the methods interface for PagePreHeaderComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type PagePreHeaderComponentMethods = MethodMap<PagePreHeaderMethodNames>;
/**
 * @public
 */
export declare function providePagePreHeaderComponent(config?: Partial<PagePreHeaderElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the PageComponent.
 * Use this token to provide default properties for the PageComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const PAGE_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/layouts/page/IPageElementProps").IPageElementProps>>;
/**
 * @public
 *
 * @slot content - Main page content area
 * @slot footer - Page footer content (e.g., copyright, links)
 * @slot header - Primary page header content (e.g., navigation, title, actions)
 * @slot preContent - Content between header and main content (e.g., breadcrumbs, filters)
 * @slot preHeader - Content displayed before the main header (e.g., notifications, alerts)
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class PageComponent {
  /**
   * Signal input for the `breakpoint` property.
   *
   * @public
   */
  readonly breakpoint: InputSignal<PageElement['breakpoint'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<PageElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<PageElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<PageElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<PageElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<PageElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<PageElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof PageElement>(property: TProperty, value: PageElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<PageElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<PageComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<PageComponent, "mosaik-page", never, {
    "breakpoint": {
      "alias": "breakpoint";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on PageComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type PageMethodNames = never;
/**
 * Declares the methods interface for PageComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type PageComponentMethods = MethodMap<PageMethodNames>;
/**
 * @public
 */
export declare function providePageComponent(config?: Partial<PageElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the PageMenuComponent.
 * Use this token to provide default properties for the PageMenuComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const PAGE_MENU_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/layouts/page/IPageMenuElementProps").IPageMenuElementProps>>;
/**
 * @public
 *
 * @slot  - The content of the page menu.
 * @slot end - The end content of the page menu.
 * @slot start - The start content of the page menu.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class PageMenuComponent {
  /**
   * Signal input for the `breakpoint` property.
   *
   * @public
   */
  readonly breakpoint: InputSignal<PageMenuElement['breakpoint'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<PageMenuElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<PageMenuElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<PageMenuElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<PageMenuElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<PageMenuElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<PageMenuElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof PageMenuElement>(property: TProperty, value: PageMenuElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<PageMenuElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<PageMenuComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<PageMenuComponent, "mosaik-pagemenu", never, {
    "breakpoint": {
      "alias": "breakpoint";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on PageMenuComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type PageMenuMethodNames = never;
/**
 * Declares the methods interface for PageMenuComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type PageMenuComponentMethods = MethodMap<PageMenuMethodNames>;
/**
 * @public
 */
export declare function providePageMenuComponent(config?: Partial<PageMenuElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-page.d.ts.map