import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { LightChainElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/misc/light-chain/LightChainElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the LightChainComponent.
 * Use this token to provide default properties for the LightChainComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const LIGHT_CHAIN_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/misc/light-chain/ILightChainElementProps").ILightChainElementProps>>;
/**
 * @public
 *
 * @slot  - Default slot (currently unused, lights are generated programmatically)
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class LightChainComponent {
  /**
   * Signal input for the `count` property.
   *
   * @public
   */
  readonly count: InputSignal<LightChainElement['count'] | undefined>;
  /**
   * Signal input for the `state` property.
   *
   * @public
   */
  readonly state: InputSignal<LightChainElement['state'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<LightChainElement['themeName'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<LightChainElement['disabled'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<LightChainElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<LightChainElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<LightChainElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<LightChainElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<LightChainElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof LightChainElement>(property: TProperty, value: LightChainElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<LightChainElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<LightChainComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<LightChainComponent, "mosaik-light-chain", never, {
    "count": {
      "alias": "count";
      "required": false;
      "isSignal": true;
    };
    "state": {
      "alias": "state";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on LightChainComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type LightChainMethodNames = never;
/**
 * Declares the methods interface for LightChainComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type LightChainComponentMethods = MethodMap<LightChainMethodNames>;
/**
 * @public
 */
export declare function provideLightChainComponent(config?: Partial<LightChainElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-light-chain.d.ts.map