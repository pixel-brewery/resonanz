import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { JumbotronHeaderElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/jumbotron/JumbotronHeaderElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { JumbotronSubHeaderElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/jumbotron/JumbotronSubHeaderElement";
import { JumbotronElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/jumbotron/JumbotronElement";
/**
 * @public
 *
 * Injection token for the default properties of the JumbotronHeaderComponent.
 * Use this token to provide default properties for the JumbotronHeaderComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const JUMBOTRON_HEADER_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/jumbotron/JumbotronHeaderElement").IJumbotronHeaderElementProps>>;
/**
 * @public
 *
 * @slot  - Default slot for custom header content (overrides text attribute)
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class JumbotronHeaderComponent {
  /**
   * Signal input for the `text` property.
   *
   * @public
   */
  readonly text: InputSignal<JumbotronHeaderElement['text'] | undefined>;
  /**
   * Signal input for the `alignment` property.
   *
   * @public
   */
  readonly alignment: InputSignal<JumbotronHeaderElement['alignment'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<JumbotronHeaderElement['themeName'] | undefined>;
  /**
   * Signal input for the `formatter` property.
   *
   * @public
   */
  readonly formatter: InputSignal<JumbotronHeaderElement['formatter'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<JumbotronHeaderElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<JumbotronHeaderElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<JumbotronHeaderElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<JumbotronHeaderElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<JumbotronHeaderElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof JumbotronHeaderElement>(property: TProperty, value: JumbotronHeaderElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<JumbotronHeaderElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<JumbotronHeaderComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<JumbotronHeaderComponent, "mosaik-jumbotron-header", never, {
    "text": {
      "alias": "text";
      "required": false;
      "isSignal": true;
    };
    "alignment": {
      "alias": "alignment";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "formatter": {
      "alias": "formatter";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on JumbotronHeaderComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type JumbotronHeaderMethodNames = never;
/**
 * Declares the methods interface for JumbotronHeaderComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type JumbotronHeaderComponentMethods = MethodMap<JumbotronHeaderMethodNames>;
/**
 * @public
 */
export declare function provideJumbotronHeaderComponent(config?: Partial<JumbotronHeaderElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the JumbotronSubHeaderComponent.
 * Use this token to provide default properties for the JumbotronSubHeaderComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const JUMBOTRON_SUB_HEADER_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/jumbotron/JumbotronSubHeaderElement").IJumbotronSubHeaderElementProps>>;
/**
 * @public
 *
 * @slot  - Default slot for custom subheader content (overrides text attribute)
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class JumbotronSubHeaderComponent {
  /**
   * Signal input for the `text` property.
   *
   * @public
   */
  readonly text: InputSignal<JumbotronSubHeaderElement['text'] | undefined>;
  /**
   * Signal input for the `alignment` property.
   *
   * @public
   */
  readonly alignment: InputSignal<JumbotronSubHeaderElement['alignment'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<JumbotronSubHeaderElement['themeName'] | undefined>;
  /**
   * Signal input for the `formatter` property.
   *
   * @public
   */
  readonly formatter: InputSignal<JumbotronSubHeaderElement['formatter'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<JumbotronSubHeaderElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<JumbotronSubHeaderElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<JumbotronSubHeaderElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<JumbotronSubHeaderElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<JumbotronSubHeaderElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof JumbotronSubHeaderElement>(property: TProperty, value: JumbotronSubHeaderElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<JumbotronSubHeaderElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<JumbotronSubHeaderComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<JumbotronSubHeaderComponent, "mosaik-jumbotron-sub-header", never, {
    "text": {
      "alias": "text";
      "required": false;
      "isSignal": true;
    };
    "alignment": {
      "alias": "alignment";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "formatter": {
      "alias": "formatter";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on JumbotronSubHeaderComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type JumbotronSubHeaderMethodNames = never;
/**
 * Declares the methods interface for JumbotronSubHeaderComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type JumbotronSubHeaderComponentMethods = MethodMap<JumbotronSubHeaderMethodNames>;
/**
 * @public
 */
export declare function provideJumbotronSubHeaderComponent(config?: Partial<JumbotronSubHeaderElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the JumbotronComponent.
 * Use this token to provide default properties for the JumbotronComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const JUMBOTRON_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/jumbotron/JumbotronElement").IJumbotronElementProps>>;
/**
 * @public
 *
 * @slot actions - Action buttons or interactive elements
 * @slot header - Main heading content (or use header attribute)
 * @slot hint - Descriptive text or instructions (or use hint attribute)
 * @slot subHeader - Secondary heading content (or use subHeader attribute)
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class JumbotronComponent {
  /**
   * Signal input for the `header` property.
   *
   * @public
   */
  readonly header: InputSignal<JumbotronElement['header'] | undefined>;
  /**
   * Signal input for the `subHeader` property.
   *
   * @public
   */
  readonly subHeader: InputSignal<JumbotronElement['subHeader'] | undefined>;
  /**
   * Signal input for the `hint` property.
   *
   * @public
   */
  readonly hint: InputSignal<JumbotronElement['hint'] | undefined>;
  /**
   * Signal input for the `alignment` property.
   *
   * @public
   */
  readonly alignment: InputSignal<JumbotronElement['alignment'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<JumbotronElement['themeName'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<JumbotronElement['appearance'] | undefined>;
  /**
   * Signal input for the `formatter` property.
   *
   * @public
   */
  readonly formatter: InputSignal<JumbotronElement['formatter'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<JumbotronElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<JumbotronElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<JumbotronElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<JumbotronElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<JumbotronElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof JumbotronElement>(property: TProperty, value: JumbotronElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<JumbotronElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<JumbotronComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<JumbotronComponent, "mosaik-jumbotron", never, {
    "header": {
      "alias": "header";
      "required": false;
      "isSignal": true;
    };
    "subHeader": {
      "alias": "subHeader";
      "required": false;
      "isSignal": true;
    };
    "hint": {
      "alias": "hint";
      "required": false;
      "isSignal": true;
    };
    "alignment": {
      "alias": "alignment";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "formatter": {
      "alias": "formatter";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on JumbotronComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type JumbotronMethodNames = never;
/**
 * Declares the methods interface for JumbotronComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type JumbotronComponentMethods = MethodMap<JumbotronMethodNames>;
/**
 * @public
 */
export declare function provideJumbotronComponent(config?: Partial<JumbotronElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-jumbotron.d.ts.map