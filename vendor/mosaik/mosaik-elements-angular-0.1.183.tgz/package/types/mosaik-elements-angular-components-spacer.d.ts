import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { SpacerElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/spacer/SpacerElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the SpacerComponent.
 * Use this token to provide default properties for the SpacerComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const SPACER_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/primitives/spacer/ISpacerElementProps").ISpacerElementProps>>;
/**
 * @public
 *
 * @slot  - Default content slot for spacer element (typically empty)
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class SpacerComponent {
  /**
   * Signal input for the `multiplier` property.
   *
   * @public
   */
  readonly multiplier: InputSignal<SpacerElement['multiplier'] | undefined>;
  /**
   * Signal input for the `multiplierValidator` property.
   *
   * @public
   */
  readonly multiplierValidator: InputSignal<SpacerElement['multiplierValidator'] | undefined>;
  /**
   * Signal input for the `size` property.
   *
   * @public
   */
  readonly size: InputSignal<SpacerElement['size'] | undefined>;
  /**
   * Signal input for the `thickness` property.
   *
   * @public
   */
  readonly thickness: InputSignal<SpacerElement['thickness'] | undefined>;
  /**
   * Signal input for the `invert` property.
   *
   * @public
   */
  readonly invert: InputSignal<SpacerElement['invert'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<SpacerElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<SpacerElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<SpacerElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<SpacerElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<SpacerElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<SpacerElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof SpacerElement>(property: TProperty, value: SpacerElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<SpacerElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SpacerComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SpacerComponent, "mosaik-spacer", never, {
    "multiplier": {
      "alias": "multiplier";
      "required": false;
      "isSignal": true;
    };
    "multiplierValidator": {
      "alias": "multiplierValidator";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "thickness": {
      "alias": "thickness";
      "required": false;
      "isSignal": true;
    };
    "invert": {
      "alias": "invert";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on SpacerComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SpacerMethodNames = never;
/**
 * Declares the methods interface for SpacerComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SpacerComponentMethods = MethodMap<SpacerMethodNames>;
/**
 * @public
 */
export declare function provideSpacerComponent(config?: Partial<SpacerElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-spacer.d.ts.map