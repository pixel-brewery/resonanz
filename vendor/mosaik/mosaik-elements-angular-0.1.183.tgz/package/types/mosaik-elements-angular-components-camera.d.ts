import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { CameraElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/camera/CameraElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the CameraComponent.
 * Use this token to provide default properties for the CameraComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const CAMERA_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/media/camera/ICameraElementProps").ICameraElementProps>>;
/**
 * @public
 *
 * @slot overlay - The overlay slot.
 * @slot underlay - The underlay slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class CameraComponent {
  /**
   * Signal input for the `src` property.
   *
   * @public
   */
  readonly src: InputSignal<CameraElement['src'] | undefined>;
  /**
   * Signal input for the `autoPlay` property.
   *
   * @public
   */
  readonly autoPlay: InputSignal<CameraElement['autoPlay'] | undefined>;
  /**
   * Signal input for the `poster` property.
   *
   * @public
   */
  readonly poster: InputSignal<CameraElement['poster'] | undefined>;
  /**
   * Signal input for the `autoFullScreen` property.
   *
   * @public
   */
  readonly autoFullScreen: InputSignal<CameraElement['autoFullScreen'] | undefined>;
  /**
   * Signal input for the `type` property.
   *
   * @public
   */
  readonly type: InputSignal<CameraElement['type'] | undefined>;
  /**
   * Signal input for the `recorderFormat` property.
   *
   * @public
   */
  readonly recorderFormat: InputSignal<CameraElement['recorderFormat'] | undefined>;
  /**
   * Signal input for the `captureFormat` property.
   *
   * @public
   */
  readonly captureFormat: InputSignal<CameraElement['captureFormat'] | undefined>;
  /**
   * Signal input for the `frame` property.
   *
   * @public
   */
  readonly frame: InputSignal<CameraElement['frame'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<CameraElement['themeName'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<CameraElement['disabled'] | undefined>;
  /**
   * Signal input for the `width` property.
   *
   * @public
   */
  readonly width: InputSignal<CameraElement['width'] | undefined>;
  /**
   * Signal input for the `height` property.
   *
   * @public
   */
  readonly height: InputSignal<CameraElement['height'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<CameraElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<CameraElement['lang'] | undefined>;
  /**
   * Output signal for the `captured` event.
   *
   * @public
   */
  readonly captured: OutputEmitterRef<ElementEventDetail<CameraElement, 'captured'>>;
  /**
   * Output signal for the `recorded` event.
   *
   * @public
   */
  readonly recorded: OutputEmitterRef<ElementEventDetail<CameraElement, 'recorded'>>;
  /**
   * Output signal for the `error` event.
   *
   * @public
   */
  readonly error: OutputEmitterRef<ElementEventDetail<CameraElement, 'error'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<CameraElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<CameraElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<CameraElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Record a stream of the current video element.
   *
   * @public
   */
  record(...args: Parameters<CameraElement['record']>): ReturnType<CameraElement['record']>;
  /**
   * Captures a image of the current video element.
   *
   * @public
   */
  capture(...args: Parameters<CameraElement['capture']>): ReturnType<CameraElement['capture']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `record()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends CameraMethodNames>(method: TMethod, ...args: Parameters<CameraComponentMethods[TMethod]>): ReturnType<CameraComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof CameraElement>(property: TProperty, value: CameraElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<CameraElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<CameraComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<CameraComponent, "mosaik-camera", never, {
    "src": {
      "alias": "src";
      "required": false;
      "isSignal": true;
    };
    "autoPlay": {
      "alias": "autoPlay";
      "required": false;
      "isSignal": true;
    };
    "poster": {
      "alias": "poster";
      "required": false;
      "isSignal": true;
    };
    "autoFullScreen": {
      "alias": "autoFullScreen";
      "required": false;
      "isSignal": true;
    };
    "type": {
      "alias": "type";
      "required": false;
      "isSignal": true;
    };
    "recorderFormat": {
      "alias": "recorderFormat";
      "required": false;
      "isSignal": true;
    };
    "captureFormat": {
      "alias": "captureFormat";
      "required": false;
      "isSignal": true;
    };
    "frame": {
      "alias": "frame";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "width": {
      "alias": "width";
      "required": false;
      "isSignal": true;
    };
    "height": {
      "alias": "height";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "captured": "captured";
    "recorded": "recorded";
    "error": "error";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on CameraComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type CameraMethodNames = 'record' | 'capture';
/**
 * Declares the methods interface for CameraComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type CameraComponentMethods = MethodMap<CameraMethodNames>;
/**
 * @public
 */
export declare function provideCameraComponent(config?: Partial<CameraElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-camera.d.ts.map