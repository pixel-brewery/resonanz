import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { BreadcrumbItemElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/grouping/breadcrumb/BreadcrumbItemElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { BreadcrumbElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/grouping/breadcrumb/BreadcrumbElement";
/**
 * @public
 *
 * Injection token for the default properties of the BreadcrumbItemComponent.
 * Use this token to provide default properties for the BreadcrumbItemComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const BREADCRUMB_ITEM_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/grouping/breadcrumb/IBreadcrumbItemElementProps").IBreadcrumbItemElementProps>>;
/**
 * @public
 *
 * @slot label - The label content when using the anchor behavior.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class BreadcrumbItemComponent {
  /**
   * Signal input for the `hasSeparator` property.
   *
   * @public
   */
  readonly hasSeparator: InputSignal<BreadcrumbItemElement['hasSeparator'] | undefined>;
  /**
   * Signal input for the `isActive` property.
   *
   * @public
   */
  readonly isActive: InputSignal<BreadcrumbItemElement['isActive'] | undefined>;
  /**
   * Signal input for the `underline` property.
   *
   * @public
   */
  readonly underline: InputSignal<BreadcrumbItemElement['underline'] | undefined>;
  /**
   * Signal input for the `download` property.
   *
   * @public
   */
  readonly download: InputSignal<BreadcrumbItemElement['download'] | undefined>;
  /**
   * Signal input for the `href` property.
   *
   * @public
   */
  readonly href: InputSignal<BreadcrumbItemElement['href'] | undefined>;
  /**
   * Signal input for the `rel` property.
   *
   * @public
   */
  readonly rel: InputSignal<BreadcrumbItemElement['rel'] | undefined>;
  /**
   * Signal input for the `target` property.
   *
   * @public
   */
  readonly target: InputSignal<BreadcrumbItemElement['target'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<BreadcrumbItemElement['themeName'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<BreadcrumbItemElement['variant'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<BreadcrumbItemElement['disabled'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<BreadcrumbItemElement['label'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<BreadcrumbItemElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<BreadcrumbItemElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<BreadcrumbItemElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<BreadcrumbItemElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<BreadcrumbItemElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof BreadcrumbItemElement>(property: TProperty, value: BreadcrumbItemElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<BreadcrumbItemElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<BreadcrumbItemComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<BreadcrumbItemComponent, "mosaik-breadcrumb-item", never, {
    "hasSeparator": {
      "alias": "hasSeparator";
      "required": false;
      "isSignal": true;
    };
    "isActive": {
      "alias": "isActive";
      "required": false;
      "isSignal": true;
    };
    "underline": {
      "alias": "underline";
      "required": false;
      "isSignal": true;
    };
    "download": {
      "alias": "download";
      "required": false;
      "isSignal": true;
    };
    "href": {
      "alias": "href";
      "required": false;
      "isSignal": true;
    };
    "rel": {
      "alias": "rel";
      "required": false;
      "isSignal": true;
    };
    "target": {
      "alias": "target";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on BreadcrumbItemComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type BreadcrumbItemMethodNames = never;
/**
 * Declares the methods interface for BreadcrumbItemComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type BreadcrumbItemComponentMethods = MethodMap<BreadcrumbItemMethodNames>;
/**
 * @public
 */
export declare function provideBreadcrumbItemComponent(config?: Partial<BreadcrumbItemElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the BreadcrumbComponent.
 * Use this token to provide default properties for the BreadcrumbComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const BREADCRUMB_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/grouping/breadcrumb/IBreadcrumbElementProps").IBreadcrumbElementProps>>;
/**
 * @public
 *
 * @slot  - The breadcrumb items in their navigation order.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class BreadcrumbComponent {
  /**
   * Signal input for the `wrap` property.
   *
   * @public
   */
  readonly wrap: InputSignal<BreadcrumbElement['wrap'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<BreadcrumbElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<BreadcrumbElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<BreadcrumbElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<BreadcrumbElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<BreadcrumbElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<BreadcrumbElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof BreadcrumbElement>(property: TProperty, value: BreadcrumbElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<BreadcrumbElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<BreadcrumbComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<BreadcrumbComponent, "mosaik-breadcrumb", never, {
    "wrap": {
      "alias": "wrap";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on BreadcrumbComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type BreadcrumbMethodNames = never;
/**
 * Declares the methods interface for BreadcrumbComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type BreadcrumbComponentMethods = MethodMap<BreadcrumbMethodNames>;
/**
 * @public
 */
export declare function provideBreadcrumbComponent(config?: Partial<BreadcrumbElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-breadcrumb.d.ts.map