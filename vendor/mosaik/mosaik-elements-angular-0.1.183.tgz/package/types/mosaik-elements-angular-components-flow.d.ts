import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef, Provider, Type } from "@angular/core";
import { FlowControlsElement, FlowEdgeElement, FlowElement, FlowLayoutMode, FlowMinimapElement, FlowNodeElement, IFlowLayoutEngine, IFlowLayoutOptions, IFlowReflowEngine } from "@pixel-brewery/mosaik-elements-foundation/components/flow";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the FlowControlsComponent.
 * Use this token to provide default properties for the FlowControlsComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const FLOW_CONTROLS_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation/components/flow").IFlowControlsElementProps>>;
/**
 * @public
 *
 * @slot lock - Application-owned lock action and state.
 * @slot pan - Application-owned pan-mode action and state.
 * @slot redo - Application-owned redo action and disabled state.
 * @slot select - Application-owned select-mode action and state.
 * @slot undo - Application-owned undo action and disabled state.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class FlowControlsComponent {
  /**
   * Signal input for the `showZoom` property.
   *
   * @public
   */
  readonly showZoom: InputSignal<FlowControlsElement['showZoom'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<FlowControlsElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<FlowControlsElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<FlowControlsElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<FlowControlsElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<FlowControlsElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<FlowControlsElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof FlowControlsElement>(property: TProperty, value: FlowControlsElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<FlowControlsElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<FlowControlsComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<FlowControlsComponent, "mosaik-flow-controls", never, {
    "showZoom": {
      "alias": "showZoom";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on FlowControlsComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FlowControlsMethodNames = never;
/**
 * Declares the methods interface for FlowControlsComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FlowControlsComponentMethods = MethodMap<FlowControlsMethodNames>;
/**
 * @public
 */
export declare function provideFlowControlsComponent(config?: Partial<FlowControlsElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the FlowEdgeComponent.
 * Use this token to provide default properties for the FlowEdgeComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const FLOW_EDGE_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation/components/flow").IFlowEdgeElementProps>>;
/**
 * @public
 *
 * @slot label - Application-owned HTML placed along the connection; falls back to label.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class FlowEdgeComponent {
  /**
   * Signal input for the `edgeKey` property.
   *
   * @public
   */
  readonly edgeKey: InputSignal<FlowEdgeElement['edgeKey'] | undefined>;
  /**
   * Signal input for the `source` property.
   *
   * @public
   */
  readonly source: InputSignal<FlowEdgeElement['source'] | undefined>;
  /**
   * Signal input for the `target` property.
   *
   * @public
   */
  readonly target: InputSignal<FlowEdgeElement['target'] | undefined>;
  /**
   * Signal input for the `sourceSide` property.
   *
   * @public
   */
  readonly sourceSide: InputSignal<FlowEdgeElement['sourceSide'] | undefined>;
  /**
   * Signal input for the `sourcePort` property.
   *
   * @public
   */
  readonly sourcePort: InputSignal<FlowEdgeElement['sourcePort'] | undefined>;
  /**
   * Signal input for the `showPorts` property.
   *
   * @public
   */
  readonly showPorts: InputSignal<FlowEdgeElement['showPorts'] | undefined>;
  /**
   * Signal input for the `targetSide` property.
   *
   * @public
   */
  readonly targetSide: InputSignal<FlowEdgeElement['targetSide'] | undefined>;
  /**
   * Signal input for the `routing` property.
   *
   * @public
   */
  readonly routing: InputSignal<FlowEdgeElement['routing'] | undefined>;
  /**
   * Signal input for the `markerEnd` property.
   *
   * @public
   */
  readonly markerEnd: InputSignal<FlowEdgeElement['markerEnd'] | undefined>;
  /**
   * Signal input for the `offset` property.
   *
   * @public
   */
  readonly offset: InputSignal<FlowEdgeElement['offset'] | undefined>;
  /**
   * Signal input for the `cornerRadius` property.
   *
   * @public
   */
  readonly cornerRadius: InputSignal<FlowEdgeElement['cornerRadius'] | undefined>;
  /**
   * Signal input for the `labelPosition` property.
   *
   * @public
   */
  readonly labelPosition: InputSignal<FlowEdgeElement['labelPosition'] | undefined>;
  /**
   * Signal input for the `waypoints` property.
   *
   * @public
   */
  readonly waypoints: InputSignal<FlowEdgeElement['waypoints'] | undefined>;
  /**
   * Signal input for the `pathBuilder` property.
   *
   * @public
   */
  readonly pathBuilder: InputSignal<FlowEdgeElement['pathBuilder'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<FlowEdgeElement['themeName'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<FlowEdgeElement['label'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<FlowEdgeElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<FlowEdgeElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<FlowEdgeElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<FlowEdgeElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<FlowEdgeElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Focuses the native edge selection control.
   *
   * @public
   * @param args - The arguments of `focus`:
   * - `options` - Native focus options.
   */
  focus(...args: Parameters<FlowEdgeElement['focus']>): ReturnType<FlowEdgeElement['focus']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `focus()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends FlowEdgeMethodNames>(method: TMethod, ...args: Parameters<FlowEdgeComponentMethods[TMethod]>): ReturnType<FlowEdgeComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof FlowEdgeElement>(property: TProperty, value: FlowEdgeElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<FlowEdgeElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<FlowEdgeComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<FlowEdgeComponent, "mosaik-flow-edge", never, {
    "edgeKey": {
      "alias": "edgeKey";
      "required": false;
      "isSignal": true;
    };
    "source": {
      "alias": "source";
      "required": false;
      "isSignal": true;
    };
    "target": {
      "alias": "target";
      "required": false;
      "isSignal": true;
    };
    "sourceSide": {
      "alias": "sourceSide";
      "required": false;
      "isSignal": true;
    };
    "sourcePort": {
      "alias": "sourcePort";
      "required": false;
      "isSignal": true;
    };
    "showPorts": {
      "alias": "showPorts";
      "required": false;
      "isSignal": true;
    };
    "targetSide": {
      "alias": "targetSide";
      "required": false;
      "isSignal": true;
    };
    "routing": {
      "alias": "routing";
      "required": false;
      "isSignal": true;
    };
    "markerEnd": {
      "alias": "markerEnd";
      "required": false;
      "isSignal": true;
    };
    "offset": {
      "alias": "offset";
      "required": false;
      "isSignal": true;
    };
    "cornerRadius": {
      "alias": "cornerRadius";
      "required": false;
      "isSignal": true;
    };
    "labelPosition": {
      "alias": "labelPosition";
      "required": false;
      "isSignal": true;
    };
    "waypoints": {
      "alias": "waypoints";
      "required": false;
      "isSignal": true;
    };
    "pathBuilder": {
      "alias": "pathBuilder";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on FlowEdgeComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FlowEdgeMethodNames = 'focus';
/**
 * Declares the methods interface for FlowEdgeComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FlowEdgeComponentMethods = MethodMap<FlowEdgeMethodNames>;
/**
 * @public
 */
export declare function provideFlowEdgeComponent(config?: Partial<FlowEdgeElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the FlowMinimapComponent.
 * Use this token to provide default properties for the FlowMinimapComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const FLOW_MINIMAP_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation/components/flow").IFlowMinimapElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class FlowMinimapComponent {
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<FlowMinimapElement['themeName'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<FlowMinimapElement['label'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<FlowMinimapElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<FlowMinimapElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<FlowMinimapElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<FlowMinimapElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<FlowMinimapElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof FlowMinimapElement>(property: TProperty, value: FlowMinimapElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<FlowMinimapElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<FlowMinimapComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<FlowMinimapComponent, "mosaik-flow-minimap", never, {
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on FlowMinimapComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FlowMinimapMethodNames = never;
/**
 * Declares the methods interface for FlowMinimapComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FlowMinimapComponentMethods = MethodMap<FlowMinimapMethodNames>;
/**
 * @public
 */
export declare function provideFlowMinimapComponent(config?: Partial<FlowMinimapElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the FlowNodeComponent.
 * Use this token to provide default properties for the FlowNodeComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const FLOW_NODE_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation/components/flow").IFlowNodeElementProps>>;
/**
 * @public
 *
 * @slot  - The node's HTML content; the label is shown when the slot is empty.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class FlowNodeComponent {
  /**
   * Signal input for the `nodeKey` property.
   *
   * @public
   */
  readonly nodeKey: InputSignal<FlowNodeElement['nodeKey'] | undefined>;
  /**
   * Signal input for the `x` property.
   *
   * @public
   */
  readonly x: InputSignal<FlowNodeElement['x'] | undefined>;
  /**
   * Signal input for the `y` property.
   *
   * @public
   */
  readonly y: InputSignal<FlowNodeElement['y'] | undefined>;
  /**
   * Signal input for the `shape` property.
   *
   * @public
   */
  readonly shape: InputSignal<FlowNodeElement['shape'] | undefined>;
  /**
   * Signal input for the `layoutGroup` property.
   *
   * @public
   */
  readonly layoutGroup: InputSignal<FlowNodeElement['layoutGroup'] | undefined>;
  /**
   * Signal input for the `reflowIgnore` property.
   *
   * @public
   */
  readonly reflowIgnore: InputSignal<FlowNodeElement['reflowIgnore'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<FlowNodeElement['themeName'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<FlowNodeElement['variant'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<FlowNodeElement['label'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<FlowNodeElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<FlowNodeElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<FlowNodeElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<FlowNodeElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<FlowNodeElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Focuses the Mosaik node selection control.
   *
   * @public
   * @param args - The arguments of `focus`:
   * - `options` - Native focus options.
   */
  focus(...args: Parameters<FlowNodeElement['focus']>): ReturnType<FlowNodeElement['focus']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `focus()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends FlowNodeMethodNames>(method: TMethod, ...args: Parameters<FlowNodeComponentMethods[TMethod]>): ReturnType<FlowNodeComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof FlowNodeElement>(property: TProperty, value: FlowNodeElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<FlowNodeElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<FlowNodeComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<FlowNodeComponent, "mosaik-flow-node", never, {
    "nodeKey": {
      "alias": "nodeKey";
      "required": false;
      "isSignal": true;
    };
    "x": {
      "alias": "x";
      "required": false;
      "isSignal": true;
    };
    "y": {
      "alias": "y";
      "required": false;
      "isSignal": true;
    };
    "shape": {
      "alias": "shape";
      "required": false;
      "isSignal": true;
    };
    "layoutGroup": {
      "alias": "layoutGroup";
      "required": false;
      "isSignal": true;
    };
    "reflowIgnore": {
      "alias": "reflowIgnore";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on FlowNodeComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FlowNodeMethodNames = 'focus';
/**
 * Declares the methods interface for FlowNodeComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FlowNodeComponentMethods = MethodMap<FlowNodeMethodNames>;
/**
 * @public
 */
export declare function provideFlowNodeComponent(config?: Partial<FlowNodeElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the FlowComponent.
 * Use this token to provide default properties for the FlowComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const FLOW_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation/components/flow").IFlowElementProps>>;
/**
 * @public
 *
 * Injection token for the intl configuration of the FlowComponent.
 * Provide a partial intl object or an injectable class that resolves translations.
 * This allows third-party applications to override the default intl labels
 * globally, per route, or per component via Angular's dependency injection.
 *
 * Merge order: Foundation defaults → DI intl → [intl] input binding.
 */
export declare const FLOW_INTL: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation/components/flow").FlowElementIntl>>;
/**
 * @public
 *
 * @slot  - Authored flow nodes, edges and world-space annotations.
 * @slot controls - Optional mosaik-flow-controls or application-owned viewport controls.
 * @slot minimap - Optional mosaik-flow-minimap accessory.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class FlowComponent {
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<Partial<FlowElement['intl']> | undefined>;
  /**
   * Signal input for the `layout` property.
   *
   * @public
   */
  readonly layout: InputSignal<FlowElement['layout'] | undefined>;
  /**
   * Signal input for the `layoutEngine` property.
   *
   * @public
   */
  readonly layoutEngine: InputSignal<FlowElement['layoutEngine'] | undefined>;
  /**
   * Signal input for the `layoutOptions` property.
   *
   * @public
   */
  readonly layoutOptions: InputSignal<FlowElement['layoutOptions'] | undefined>;
  /**
   * Signal input for the `reflowEngine` property.
   *
   * @public
   */
  readonly reflowEngine: InputSignal<FlowElement['reflowEngine'] | undefined>;
  /**
   * Signal input for the `direction` property.
   *
   * @public
   */
  readonly direction: InputSignal<FlowElement['direction'] | undefined>;
  /**
   * Signal input for the `edgeRouting` property.
   *
   * @public
   */
  readonly edgeRouting: InputSignal<FlowElement['edgeRouting'] | undefined>;
  /**
   * Signal input for the `edgeMarkerEnd` property.
   *
   * @public
   */
  readonly edgeMarkerEnd: InputSignal<FlowElement['edgeMarkerEnd'] | undefined>;
  /**
   * Signal input for the `selectionMode` property.
   *
   * @public
   */
  readonly selectionMode: InputSignal<FlowElement['selectionMode'] | undefined>;
  /**
   * Signal input for the `selectedKey` property.
   *
   * @public
   */
  readonly selectedKey: InputSignal<FlowElement['selectedKey'] | undefined>;
  /**
   * Signal input for the `highlightMode` property.
   *
   * @public
   */
  readonly highlightMode: InputSignal<FlowElement['highlightMode'] | undefined>;
  /**
   * Signal input for the `grid` property.
   *
   * @public
   */
  readonly grid: InputSignal<FlowElement['grid'] | undefined>;
  /**
   * Signal input for the `controlsPosition` property.
   *
   * @public
   */
  readonly controlsPosition: InputSignal<FlowElement['controlsPosition'] | undefined>;
  /**
   * Signal input for the `minimapPosition` property.
   *
   * @public
   */
  readonly minimapPosition: InputSignal<FlowElement['minimapPosition'] | undefined>;
  /**
   * Signal input for the `fitOnLoad` property.
   *
   * @public
   */
  readonly fitOnLoad: InputSignal<FlowElement['fitOnLoad'] | undefined>;
  /**
   * Signal input for the `fitPadding` property.
   *
   * @public
   */
  readonly fitPadding: InputSignal<FlowElement['fitPadding'] | undefined>;
  /**
   * Signal input for the `fitMinZoom` property.
   *
   * @public
   */
  readonly fitMinZoom: InputSignal<FlowElement['fitMinZoom'] | undefined>;
  /**
   * Signal input for the `zoom` property.
   *
   * @public
   */
  readonly zoom: InputSignal<FlowElement['zoom'] | undefined>;
  /**
   * Signal input for the `minZoom` property.
   *
   * @public
   */
  readonly minZoom: InputSignal<FlowElement['minZoom'] | undefined>;
  /**
   * Signal input for the `maxZoom` property.
   *
   * @public
   */
  readonly maxZoom: InputSignal<FlowElement['maxZoom'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<FlowElement['themeName'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<FlowElement['label'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<FlowElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<FlowElement['lang'] | undefined>;
  /**
   * Output signal for the `flowSelectionChanged` event.
   *
   * @public
   */
  readonly flowSelectionChanged: OutputEmitterRef<ElementEventDetail<FlowElement, 'flowSelectionChanged'>>;
  /**
   * Output signal for the `flowViewportChanged` event.
   *
   * @public
   */
  readonly flowViewportChanged: OutputEmitterRef<ElementEventDetail<FlowElement, 'flowViewportChanged'>>;
  /**
   * Output signal for the `flowLayoutCompleted` event.
   *
   * @public
   */
  readonly flowLayoutCompleted: OutputEmitterRef<ElementEventDetail<FlowElement, 'flowLayoutCompleted'>>;
  /**
   * Output signal for the `flowPositionsChanged` event.
   *
   * @public
   */
  readonly flowPositionsChanged: OutputEmitterRef<ElementEventDetail<FlowElement, 'flowPositionsChanged'>>;
  /**
   * Output signal for the `flowError` event.
   *
   * @public
   */
  readonly flowError: OutputEmitterRef<ElementEventDetail<FlowElement, 'flowError'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<FlowElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<FlowElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<FlowElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Measures the latest manual graph and applies one connection geometry per edge.
   * Concurrent calls share one pass; changes arriving during measurement are folded
   * into the next pass before the promise settles. Hidden containers remain pending
   * until they become measurable and do not consume the initial fit.
   *
   * @public
   * @returns Completion of the current measurement pass.
   */
  relayout(...args: Parameters<FlowElement['relayout']>): ReturnType<FlowElement['relayout']>;
  /**
   * Runs the optional engine once, including in manual mode. Merge flowPositionsChanged into application state.
   *
   * @public
   * @returns Completion after positions and connection geometry have been applied.
   */
  applyLayout(...args: Parameters<FlowElement['applyLayout']>): ReturnType<FlowElement['applyLayout']>;
  /**
   * Selects a resolved graph item. User interactions honor selectionMode; API
   * selection can also highlight an item in a noninteractive diagram.
   *
   * @public
   * @param args - The arguments of `select`:
   * - `key` - Node or edge key scoped to this diagram.
   * - `trigger` - The interaction source; defaults to api.
   * @returns Whether the item could be selected.
   */
  select(...args: Parameters<FlowElement['select']>): ReturnType<FlowElement['select']>;
  /**
   * Clears the selected item and its neighborhood.
   *
   * @public
   * @param args - The arguments of `clearSelection`:
   * - `trigger` - The interaction source; defaults to api.
   */
  clearSelection(...args: Parameters<FlowElement['clearSelection']>): ReturnType<FlowElement['clearSelection']>;
  /**
   * Fits nodes, complete connection paths and measured labels into the viewport.
   * Small diagrams are not magnified beyond their authored size.
   *
   * @public
   * @returns Whether a measurable graph and viewport were available.
   */
  fitToView(...args: Parameters<FlowElement['fitToView']>): ReturnType<FlowElement['fitToView']>;
  /**
   * Zooms in around the viewport center.
   *
   * @public
   */
  zoomIn(...args: Parameters<FlowElement['zoomIn']>): ReturnType<FlowElement['zoomIn']>;
  /**
   * Zooms out around the viewport center.
   *
   * @public
   */
  zoomOut(...args: Parameters<FlowElement['zoomOut']>): ReturnType<FlowElement['zoomOut']>;
  /**
   * Sets a positive zoom while preserving the world position under the screen anchor.
   *
   * @public
   * @param args - The arguments of `setZoom`:
   * - `zoom` - Requested positive scale, clamped to the configured limits.
   * - `anchor` - Screen point relative to the viewport; defaults to its center.
   */
  setZoom(...args: Parameters<FlowElement['setZoom']>): ReturnType<FlowElement['setZoom']>;
  /**
   * Applies a viewport transform without changing authored node coordinates.
   * The transform of the world layer is written at once, before native focus scrolling,
   * and without a template render.
   *
   * @public
   * @param args - The arguments of `setViewport`:
   * - `viewport` - Translation in screen pixels and positive scale.
   */
  setViewport(...args: Parameters<FlowElement['setViewport']>): ReturnType<FlowElement['setViewport']>;
  /**
   * Moves the viewport by a screen-space delta.
   *
   * @public
   * @param args - The arguments of `panBy`:
   * - `x` - Horizontal translation in screen pixels.
   * - `y` - Vertical translation in screen pixels.
   */
  panBy(...args: Parameters<FlowElement['panBy']>): ReturnType<FlowElement['panBy']>;
  /**
   * Centers a world position, for example one chosen in the mini-map.
   *
   * @public
   * @param args - The arguments of `centerOn`:
   * - `point` - Position in unscaled flow coordinates.
   */
  centerOn(...args: Parameters<FlowElement['centerOn']>): ReturnType<FlowElement['centerOn']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `relayout()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends FlowMethodNames>(method: TMethod, ...args: Parameters<FlowComponentMethods[TMethod]>): ReturnType<FlowComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof FlowElement>(property: TProperty, value: FlowElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<FlowElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<FlowComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<FlowComponent, "mosaik-flow", never, {
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "layout": {
      "alias": "layout";
      "required": false;
      "isSignal": true;
    };
    "layoutEngine": {
      "alias": "layoutEngine";
      "required": false;
      "isSignal": true;
    };
    "layoutOptions": {
      "alias": "layoutOptions";
      "required": false;
      "isSignal": true;
    };
    "reflowEngine": {
      "alias": "reflowEngine";
      "required": false;
      "isSignal": true;
    };
    "direction": {
      "alias": "direction";
      "required": false;
      "isSignal": true;
    };
    "edgeRouting": {
      "alias": "edgeRouting";
      "required": false;
      "isSignal": true;
    };
    "edgeMarkerEnd": {
      "alias": "edgeMarkerEnd";
      "required": false;
      "isSignal": true;
    };
    "selectionMode": {
      "alias": "selectionMode";
      "required": false;
      "isSignal": true;
    };
    "selectedKey": {
      "alias": "selectedKey";
      "required": false;
      "isSignal": true;
    };
    "highlightMode": {
      "alias": "highlightMode";
      "required": false;
      "isSignal": true;
    };
    "grid": {
      "alias": "grid";
      "required": false;
      "isSignal": true;
    };
    "controlsPosition": {
      "alias": "controlsPosition";
      "required": false;
      "isSignal": true;
    };
    "minimapPosition": {
      "alias": "minimapPosition";
      "required": false;
      "isSignal": true;
    };
    "fitOnLoad": {
      "alias": "fitOnLoad";
      "required": false;
      "isSignal": true;
    };
    "fitPadding": {
      "alias": "fitPadding";
      "required": false;
      "isSignal": true;
    };
    "fitMinZoom": {
      "alias": "fitMinZoom";
      "required": false;
      "isSignal": true;
    };
    "zoom": {
      "alias": "zoom";
      "required": false;
      "isSignal": true;
    };
    "minZoom": {
      "alias": "minZoom";
      "required": false;
      "isSignal": true;
    };
    "maxZoom": {
      "alias": "maxZoom";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "flowSelectionChanged": "flowSelectionChanged";
    "flowViewportChanged": "flowViewportChanged";
    "flowLayoutCompleted": "flowLayoutCompleted";
    "flowPositionsChanged": "flowPositionsChanged";
    "flowError": "flowError";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on FlowComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FlowMethodNames = 'relayout' | 'applyLayout' | 'select' | 'clearSelection' | 'fitToView' | 'zoomIn' | 'zoomOut' | 'setZoom' | 'setViewport' | 'panBy' | 'centerOn';
/**
 * Declares the methods interface for FlowComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FlowComponentMethods = MethodMap<FlowMethodNames>;
/**
 * @public
 */
export declare function provideFlowComponent(config?: Partial<FlowElement.Props>, intl?: Partial<FlowElement['intl']> | Type<Partial<FlowElement['intl']>>): EnvironmentProviders;
/**
 * Optional provider feature, following the dialog/drawer provider contract.
 * @public
 */
export interface IFlowFeature {
  readonly id: string;
  provide(): ReadonlyArray<Provider>;
}
/**
 * Provides Flow defaults and optional features. Explicit component inputs override injected defaults.
 * Factories run in Angular's injection context; the provider itself imports no Dagre or ELK code.
 *
 * @public
 * @param features - Defaults, layout and resize-reflow features in merge order.
 */
export declare function provideFlows(...features: ReadonlyArray<IFlowFeature>): EnvironmentProviders;
/**
 * Provides ordinary defaults without enabling an optional engine.
 * @public
 * @param defaults - Default component properties.
 */
export declare function withFlowDefaultBehavior(defaults: Partial<FlowElement.Props>): IFlowFeature;
/**
 * Installs an independently imported engine. Use manual mode for explicit applyLayout calls.
 * @public
 * @param createEngine - Injection-context factory; import only the engine needed by the application.
 * @param config - Automatic/manual orchestration and common calculation options.
 */
export declare function withFlowLayoutBehavior(createEngine: () => IFlowLayoutEngine, config?: {
  readonly mode?: FlowLayoutMode;
  readonly options?: IFlowLayoutOptions;
}): IFlowFeature;
/**
 * Installs optional local resize reflow for manual graphs. Automatic layout takes precedence.
 * @public
 * @param createEngine - Factory for an independently imported resize planner.
 */
export declare function withFlowReflowOnResize(createEngine: () => IFlowReflowEngine): IFlowFeature;
//# sourceMappingURL=mosaik-elements-angular-components-flow.d.ts.map