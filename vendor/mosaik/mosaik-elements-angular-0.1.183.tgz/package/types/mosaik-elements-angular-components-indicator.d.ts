import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { IndicatorElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/indicator/IndicatorElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the IndicatorComponent.
 * Use this token to provide default properties for the IndicatorComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const INDICATOR_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/primitives/indicator/IIndicatorElementProps").IIndicatorElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class IndicatorComponent {
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<IndicatorElement['intl'] | undefined>;
  /**
   * Signal input for the `total` property.
   *
   * @public
   */
  readonly total: InputSignal<IndicatorElement['total'] | undefined>;
  /**
   * Signal input for the `selected` property.
   *
   * @public
   */
  readonly selected: InputSignal<IndicatorElement['selected'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<IndicatorElement['themeName'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<IndicatorElement['disabled'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<IndicatorElement['variant'] | undefined>;
  /**
   * Signal input for the `orientation` property.
   *
   * @public
   */
  readonly orientation: InputSignal<IndicatorElement['orientation'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<IndicatorElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<IndicatorElement['lang'] | undefined>;
  /**
   * Output signal for the `indicated` event.
   *
   * @public
   */
  readonly indicated: OutputEmitterRef<ElementEventDetail<IndicatorElement, 'indicated'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<IndicatorElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<IndicatorElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<IndicatorElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof IndicatorElement>(property: TProperty, value: IndicatorElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<IndicatorElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<IndicatorComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<IndicatorComponent, "mosaik-indicator", never, {
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "total": {
      "alias": "total";
      "required": false;
      "isSignal": true;
    };
    "selected": {
      "alias": "selected";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "orientation": {
      "alias": "orientation";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "indicated": "indicated";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on IndicatorComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type IndicatorMethodNames = never;
/**
 * Declares the methods interface for IndicatorComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type IndicatorComponentMethods = MethodMap<IndicatorMethodNames>;
/**
 * @public
 */
export declare function provideIndicatorComponent(config?: Partial<IndicatorElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-indicator.d.ts.map