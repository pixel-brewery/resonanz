import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { ScaleElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/effects/scale/ScaleElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the ScaleComponent.
 * Use this token to provide default properties for the ScaleComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const SCALE_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/effects/scale/IScaleElementProps").IScaleElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ScaleComponent {
  /**
   * Signal input for the `mode` property.
   *
   * @public
   */
  readonly mode: InputSignal<ScaleElement['mode'] | undefined>;
  /**
   * Signal input for the `factor` property.
   *
   * @public
   */
  readonly factor: InputSignal<ScaleElement['factor'] | undefined>;
  /**
   * Signal input for the `duration` property.
   *
   * @public
   */
  readonly duration: InputSignal<ScaleElement['duration'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ScaleElement['themeName'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<ScaleElement['disabled'] | undefined>;
  /**
   * Signal input for the `for` property.
   *
   * @public
   */
  readonly for: InputSignal<ScaleElement['for'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ScaleElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ScaleElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ScaleElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ScaleElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ScaleElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Calls `attach` on the `mosaik-scale` element.
   *
   * @public
   * @param args - The arguments of `attach`:
   * - `control` - The control or id to attach.
   */
  attach(...args: Parameters<ScaleElement['attach']>): ReturnType<ScaleElement['attach']>;
  /**
   * Calls `detach` on the `mosaik-scale` element.
   *
   * @public
   */
  detach(...args: Parameters<ScaleElement['detach']>): ReturnType<ScaleElement['detach']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `attach()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * The other names it accepts are not public in the type declarations of `ScaleElement`.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends ScaleMethodNames>(method: TMethod, ...args: Parameters<ScaleComponentMethods[TMethod]>): ReturnType<ScaleComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ScaleElement>(property: TProperty, value: ScaleElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ScaleElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ScaleComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ScaleComponent, "mosaik-scale", never, {
    "mode": {
      "alias": "mode";
      "required": false;
      "isSignal": true;
    };
    "factor": {
      "alias": "factor";
      "required": false;
      "isSignal": true;
    };
    "duration": {
      "alias": "duration";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "for": {
      "alias": "for";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on ScaleComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ScaleMethodNames = 'onApplyTemplate' | 'attach' | 'detach';
/**
 * Declares the methods interface for ScaleComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ScaleComponentMethods = MethodMap<ScaleMethodNames>;
/**
 * @public
 */
export declare function provideScaleComponent(config?: Partial<ScaleElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-scale.d.ts.map