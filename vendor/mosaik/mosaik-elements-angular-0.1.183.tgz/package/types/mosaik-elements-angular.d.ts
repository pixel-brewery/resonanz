import { DataTableComponent } from "@pixel-brewery/mosaik-elements-angular/components/data-table";
import { DialogComponent } from "@pixel-brewery/mosaik-elements-angular/components/dialog";
import { DrawerComponent } from "@pixel-brewery/mosaik-elements-angular/components/drawer";
import { ExpandableComponent } from "@pixel-brewery/mosaik-elements-angular/components/expandable";
import { MessageBoxComponent } from "@pixel-brewery/mosaik-elements-angular/components/message-box";
import { SchedulerEventComponent } from "@pixel-brewery/mosaik-elements-angular/components/scheduler";
import { SheetComponent } from "@pixel-brewery/mosaik-elements-angular/components/sheet";
import { ToastComponent } from "@pixel-brewery/mosaik-elements-angular/components/toast";
import * as i0 from "@angular/core";
import { AfterContentInit, AfterViewInit, ChangeDetectorRef, ComponentRef, DestroyRef, DoCheck, ElementRef, EmbeddedViewRef, EnvironmentProviders, InjectionToken, Injector, InputSignal, InputSignalWithTransform, NgZone, OnChanges, OnDestroy, OnInit, PipeTransform, Provider, Renderer2, Signal, SimpleChanges, TemplateRef, Type, ViewContainerRef, WritableSignal } from "@angular/core";
import { AnimationPreset, BreakpointAlias, ComboItemElement, DialogElement, DrawerElement, FlexAlignContent, FlexAlignItems, FlexDirection, FlexJustify, FlexWrap, IAnimationReferenceMetadata, IBreakpoint, IDataListItemDefinition, IDataTableColumnDefinition, IDialogStackBehaviorConfig, IDrawerStackBehaviorConfig, IPromptBoxTool, IResolvedTourStep, IToastStackBehaviorConfig, ITourAnchorTarget, ITourBehavior, ITourCameraBehaviorConfig, ITourDefinition, ITourFailedEventDetail, MessageBoxElement, Nullable, PromptBoxBaseElement, SchedulerEventElement, SelectItemElement, SheetElement, TextFormatter, TextFormatterFn, ToastElement, TourElement, TourEndReason, Variant } from "@pixel-brewery/mosaik-elements-foundation";
import { AnimationPlayer } from "@pixel-brewery/mosaik-elements-foundation/dist/animations/AnimationPlayer";
import { Observable, Subject } from "rxjs";
import { PerspectiveElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/effects/perspective/PerspectiveElement";
import { RippleElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/effects/ripple/RippleElement";
import { ScaleElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/effects/scale/ScaleElement";
import { CssLength, ITheme, ThemeMode, ThemeObserver } from "@pixel-brewery/mosaik-themes";
import { DockSide } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/types/DockSide";
import { AbstractControl, FormGroup, ValidationErrors, ValidatorFn } from "@angular/forms";
import { FieldState, FieldTree, LogicFn, OneOrMany, PathKind, SchemaPath, SchemaPathRules, ValidationError } from "@angular/forms/signals";
import { FormFieldElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/forms/FormFieldElement";
import { FlipElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/flip/FlipElement";
import { Placement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/types/Placement";
import { Trigger } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/types/Trigger";
import { Size } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/types/Size";
import { Spacing } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/types/Spacing";
import { FORM_STATUS_HOST, FormFieldDirective, FormFieldStatusHostDirective, FormStatusHostDirective, IFormField, IFormStatusHost, MethodMap, PortalProjectionDirective, ProxyCmp, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { IIconDefinition, IconInput, IconInput as IconInput$1, IconLoader, IconLoader as IconLoader$1 } from "@pixel-brewery/mosaik-icons";
import { BasePortalOutlet, CdkPortalOutlet, ComponentPortal, DomPortalOutlet, TemplatePortal } from "@angular/cdk/portal";
import { Overlay, OverlayConfig, OverlayPositionBuilder, OverlayRef, PositionStrategy, ScrollStrategy } from "@angular/cdk/overlay";
import { MessageBoxResult } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/types/MessageBoxResult";
import { DateAgoIntl } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/directives/date-ago/intl/DateAgoIntl";
import { filterByMemberPath, orderByMemberPath } from "@pixel-brewery/mosaik-elements";
import { TimeAgoIntl } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/directives/time-ago/intl/TimeAgoIntl";
import { TranslatorService } from "@pixel-brewery/mosaik-elements-foundation/dist/translations/TranslatorService";
export * from "@pixel-brewery/mosaik-elements-angular/components/absolute";
export * from "@pixel-brewery/mosaik-elements-angular/components/actionbar";
export * from "@pixel-brewery/mosaik-elements-angular/components/anchor";
export * from "@pixel-brewery/mosaik-elements-angular/components/shell";
export * from "@pixel-brewery/mosaik-elements-angular/components/chat";
export * from "@pixel-brewery/mosaik-elements-angular/components/audio";
export * from "@pixel-brewery/mosaik-elements-angular/components/auto-complete-box";
export * from "@pixel-brewery/mosaik-elements-angular/components/avatar";
export * from "@pixel-brewery/mosaik-elements-angular/components/backdrop";
export * from "@pixel-brewery/mosaik-elements-angular/components/badge";
export * from "@pixel-brewery/mosaik-elements-angular/components/banner-group";
export * from "@pixel-brewery/mosaik-elements-angular/components/banner";
export * from "@pixel-brewery/mosaik-elements-angular/components/beam";
export * from "@pixel-brewery/mosaik-elements-angular/components/box";
export * from "@pixel-brewery/mosaik-elements-angular/components/breadcrumb";
export * from "@pixel-brewery/mosaik-elements-angular/components/breakpoint-container";
export * from "@pixel-brewery/mosaik-elements-angular/components/bubbles";
export * from "@pixel-brewery/mosaik-elements-angular/components/busy";
export * from "@pixel-brewery/mosaik-elements-angular/components/button";
export * from "@pixel-brewery/mosaik-elements-angular/components/calendar";
export * from "@pixel-brewery/mosaik-elements-angular/components/camera";
export * from "@pixel-brewery/mosaik-elements-angular/components/card";
export * from "@pixel-brewery/mosaik-elements-angular/components/card-stack";
export * from "@pixel-brewery/mosaik-elements-angular/components/carousel";
export * from "@pixel-brewery/mosaik-elements-angular/components/cells";
export * from "@pixel-brewery/mosaik-elements-angular/components/check-box";
export * from "@pixel-brewery/mosaik-elements-angular/components/checkmark";
export * from "@pixel-brewery/mosaik-elements-angular/components/chip";
export * from "@pixel-brewery/mosaik-elements-angular/components/chip-box";
export * from "@pixel-brewery/mosaik-elements-angular/components/choice";
export * from "@pixel-brewery/mosaik-elements-angular/components/clickable";
export * from "@pixel-brewery/mosaik-elements-angular/components/code";
export * from "@pixel-brewery/mosaik-elements-angular/components/color-area";
export * from "@pixel-brewery/mosaik-elements-angular/components/color-editor";
export * from "@pixel-brewery/mosaik-elements-angular/components/color-picker";
export * from "@pixel-brewery/mosaik-elements-angular/components/color-slider";
export * from "@pixel-brewery/mosaik-elements-angular/components/color-swatch";
export * from "@pixel-brewery/mosaik-elements-angular/components/color-thumb";
export * from "@pixel-brewery/mosaik-elements-angular/components/color-box";
export * from "@pixel-brewery/mosaik-elements-angular/components/combo";
export * from "@pixel-brewery/mosaik-elements-angular/components/comment";
export * from "@pixel-brewery/mosaik-elements-angular/components/compound-button";
export * from "@pixel-brewery/mosaik-elements-angular/components/cookie-consent";
export * from "@pixel-brewery/mosaik-elements-angular/components/cursor-effect";
export * from "@pixel-brewery/mosaik-elements-angular/components/data-list";
export * from "@pixel-brewery/mosaik-elements-angular/components/data-table";
export * from "@pixel-brewery/mosaik-elements-angular/components/date-box";
export * from "@pixel-brewery/mosaik-elements-angular/components/date-time-box";
export * from "@pixel-brewery/mosaik-elements-angular/components/designer";
export * from "@pixel-brewery/mosaik-elements-angular/components/dialog";
export * from "@pixel-brewery/mosaik-elements-angular/components/disclosure";
export * from "@pixel-brewery/mosaik-elements-angular/components/dismiss";
export * from "@pixel-brewery/mosaik-elements-angular/components/divider";
export * from "@pixel-brewery/mosaik-elements-angular/components/dock";
export * from "@pixel-brewery/mosaik-elements-angular/components/dot";
export * from "@pixel-brewery/mosaik-elements-angular/components/drawer";
export * from "@pixel-brewery/mosaik-elements-angular/components/drop-zone";
export * from "@pixel-brewery/mosaik-elements-angular/components/dropdown";
export * from "@pixel-brewery/mosaik-elements-angular/components/drop-down-button";
export * from "@pixel-brewery/mosaik-elements-angular/components/duration-box";
export * from "@pixel-brewery/mosaik-elements-angular/components/elevation";
export * from "@pixel-brewery/mosaik-elements-angular/components/emoji";
export * from "@pixel-brewery/mosaik-elements-angular/components/empty";
export * from "@pixel-brewery/mosaik-elements-angular/components/electronic-program-guide";
export * from "@pixel-brewery/mosaik-elements-angular/components/error-state";
export * from "@pixel-brewery/mosaik-elements-angular/components/error";
export * from "@pixel-brewery/mosaik-elements-angular/components/expandable";
export * from "@pixel-brewery/mosaik-elements-angular/components/expander";
export * from "@pixel-brewery/mosaik-elements-angular/components/floating-action-button";
export * from "@pixel-brewery/mosaik-elements-angular/components/file-upload";
export * from "@pixel-brewery/mosaik-elements-angular/components/file-box";
export * from "@pixel-brewery/mosaik-elements-angular/components/flip";
export * from "@pixel-brewery/mosaik-elements-angular/components/floating";
export * from "@pixel-brewery/mosaik-elements-angular/components/flow-board";
export * from "@pixel-brewery/mosaik-elements-angular/components/focus-ring";
export * from "@pixel-brewery/mosaik-elements-angular/components/font-editor";
export * from "@pixel-brewery/mosaik-elements-angular/components/footer";
export * from "@pixel-brewery/mosaik-elements-angular/components/forms";
export * from "@pixel-brewery/mosaik-elements-angular/components/ghost";
export * from "@pixel-brewery/mosaik-elements-angular/components/globe";
export * from "@pixel-brewery/mosaik-elements-angular/components/grid";
export * from "@pixel-brewery/mosaik-elements-angular/components/helmet";
export * from "@pixel-brewery/mosaik-elements-angular/components/hint";
export * from "@pixel-brewery/mosaik-elements-angular/components/icon";
export * from "@pixel-brewery/mosaik-elements-angular/components/illustration";
export * from "@pixel-brewery/mosaik-elements-angular/components/image";
export * from "@pixel-brewery/mosaik-elements-angular/components/indicator";
export * from "@pixel-brewery/mosaik-elements-angular/components/jumbotron";
export * from "@pixel-brewery/mosaik-elements-angular/components/kbd";
export * from "@pixel-brewery/mosaik-elements-angular/components/knob";
export * from "@pixel-brewery/mosaik-elements-angular/components/light-chain";
export * from "@pixel-brewery/mosaik-elements-angular/components/list";
export * from "@pixel-brewery/mosaik-elements-angular/components/listing";
export * from "@pixel-brewery/mosaik-elements-angular/components/marquee";
export * from "@pixel-brewery/mosaik-elements-angular/components/masonry";
export * from "@pixel-brewery/mosaik-elements-angular/components/menu";
export * from "@pixel-brewery/mosaik-elements-angular/components/message-box";
export * from "@pixel-brewery/mosaik-elements-angular/components/message";
export * from "@pixel-brewery/mosaik-elements-angular/components/meter-bar";
export * from "@pixel-brewery/mosaik-elements-angular/components/meter-ring";
export * from "@pixel-brewery/mosaik-elements-angular/components/number";
export * from "@pixel-brewery/mosaik-elements-angular/components/number-ticker";
export * from "@pixel-brewery/mosaik-elements-angular/components/number-box";
export * from "@pixel-brewery/mosaik-elements-angular/components/orbit";
export * from "@pixel-brewery/mosaik-elements-angular/components/page";
export * from "@pixel-brewery/mosaik-elements-angular/components/paginator";
export * from "@pixel-brewery/mosaik-elements-angular/components/parallax";
export * from "@pixel-brewery/mosaik-elements-angular/components/particles";
export * from "@pixel-brewery/mosaik-elements-angular/components/password-box";
export * from "@pixel-brewery/mosaik-elements-angular/components/pattern";
export * from "@pixel-brewery/mosaik-elements-angular/components/persona";
export * from "@pixel-brewery/mosaik-elements-angular/components/perspective";
export * from "@pixel-brewery/mosaik-elements-angular/components/pin-box";
export * from "@pixel-brewery/mosaik-elements-angular/components/pip";
export * from "@pixel-brewery/mosaik-elements-angular/components/placeholder";
export * from "@pixel-brewery/mosaik-elements-angular/components/popup";
export * from "@pixel-brewery/mosaik-elements-angular/components/portal";
export * from "@pixel-brewery/mosaik-elements-angular/components/press-button";
export * from "@pixel-brewery/mosaik-elements-angular/components/progress-bar";
export * from "@pixel-brewery/mosaik-elements-angular/components/progress-ring";
export * from "@pixel-brewery/mosaik-elements-angular/components/prompt-box";
export * from "@pixel-brewery/mosaik-elements-angular/components/pulse";
export * from "@pixel-brewery/mosaik-elements-angular/components/qr-code";
export * from "@pixel-brewery/mosaik-elements-angular/components/radio";
export * from "@pixel-brewery/mosaik-elements-angular/components/rating";
export * from "@pixel-brewery/mosaik-elements-angular/components/region";
export * from "@pixel-brewery/mosaik-elements-angular/components/repeat-button";
export * from "@pixel-brewery/mosaik-elements-angular/components/resize-adorner";
export * from "@pixel-brewery/mosaik-elements-angular/components/resize-thumb";
export * from "@pixel-brewery/mosaik-elements-angular/components/resize";
export * from "@pixel-brewery/mosaik-elements-angular/components/reveal";
export * from "@pixel-brewery/mosaik-elements-angular/components/ribbon";
export * from "@pixel-brewery/mosaik-elements-angular/components/ripple";
export * from "@pixel-brewery/mosaik-elements-angular/components/scale";
export * from "@pixel-brewery/mosaik-elements-angular/components/scheduler";
export * from "@pixel-brewery/mosaik-elements-angular/components/scroll";
export * from "@pixel-brewery/mosaik-elements-angular/components/scrub-slider";
export * from "@pixel-brewery/mosaik-elements-angular/components/search-box";
export * from "@pixel-brewery/mosaik-elements-angular/components/segment-bar";
export * from "@pixel-brewery/mosaik-elements-angular/components/segment";
export * from "@pixel-brewery/mosaik-elements-angular/components/segment-legend";
export * from "@pixel-brewery/mosaik-elements-angular/components/segment-ring";
export * from "@pixel-brewery/mosaik-elements-angular/components/select";
export * from "@pixel-brewery/mosaik-elements-angular/components/sheet";
export * from "@pixel-brewery/mosaik-elements-angular/components/skeleton";
export * from "@pixel-brewery/mosaik-elements-angular/components/slider";
export * from "@pixel-brewery/mosaik-elements-angular/components/slider2";
export * from "@pixel-brewery/mosaik-elements-angular/components/spacer";
export * from "@pixel-brewery/mosaik-elements-angular/components/split-button";
export * from "@pixel-brewery/mosaik-elements-angular/components/split";
export * from "@pixel-brewery/mosaik-elements-angular/components/stack";
export * from "@pixel-brewery/mosaik-elements-angular/components/stepper";
export * from "@pixel-brewery/mosaik-elements-angular/components/sticky";
export * from "@pixel-brewery/mosaik-elements-angular/components/success";
export * from "@pixel-brewery/mosaik-elements-angular/components/text-suggestions";
export * from "@pixel-brewery/mosaik-elements-angular/components/summary";
export * from "@pixel-brewery/mosaik-elements-angular/components/swipe";
export * from "@pixel-brewery/mosaik-elements-angular/components/tab";
export * from "@pixel-brewery/mosaik-elements-angular/components/tab-strip";
export * from "@pixel-brewery/mosaik-elements-angular/components/table";
export * from "@pixel-brewery/mosaik-elements-angular/components/text-effect";
export * from "@pixel-brewery/mosaik-elements-angular/components/text-format";
export * from "@pixel-brewery/mosaik-elements-angular/components/text";
export * from "@pixel-brewery/mosaik-elements-angular/components/text-box";
export * from "@pixel-brewery/mosaik-elements-angular/components/theming";
export * from "@pixel-brewery/mosaik-elements-angular/components/thumb";
export * from "@pixel-brewery/mosaik-elements-angular/components/thumbnail";
export * from "@pixel-brewery/mosaik-elements-angular/components/tick-bar";
export * from "@pixel-brewery/mosaik-elements-angular/components/tile-list";
export * from "@pixel-brewery/mosaik-elements-angular/components/tile-manager";
export * from "@pixel-brewery/mosaik-elements-angular/components/tile";
export * from "@pixel-brewery/mosaik-elements-angular/components/time-box";
export * from "@pixel-brewery/mosaik-elements-angular/components/timeline";
export * from "@pixel-brewery/mosaik-elements-angular/components/toast";
export * from "@pixel-brewery/mosaik-elements-angular/components/toggle-button";
export * from "@pixel-brewery/mosaik-elements-angular/components/toggle-switch";
export * from "@pixel-brewery/mosaik-elements-angular/components/toggletip";
export * from "@pixel-brewery/mosaik-elements-angular/components/toolbar";
export * from "@pixel-brewery/mosaik-elements-angular/components/tooltip";
export * from "@pixel-brewery/mosaik-elements-angular/components/tour";
export * from "@pixel-brewery/mosaik-elements-angular/components/tree";
export * from "@pixel-brewery/mosaik-elements-angular/components/up-down-spinner";
export * from "@pixel-brewery/mosaik-elements-angular/components/video";
export * from "@pixel-brewery/mosaik-elements-angular/components/virtualize";
export * from "@pixel-brewery/mosaik-elements-angular/components/wallet-card";
export * from "@pixel-brewery/mosaik-elements-angular/components/wheel-picker";
export * from "@pixel-brewery/mosaik-elements-angular/components/wizard";
export * from "@pixel-brewery/mosaik-elements-angular/components/wrap";
/**
 * Registry of animations
 *
 * @public
 */
export declare class AnimationRegistry {
  private readonly _animations;
  /**
   * Constructs a new instance of the `AnimationRegistry` class.
   *
   * @public
   */
  constructor();
  /**
   * Gets the registered animations.
   *
   * @public
   * @readonly
   */
  get animations(): Record<AnimationPreset | string, IAnimationReferenceMetadata>;
  /**
   * Registers an animation with the registry.
   *
   * @public
   * @param name The name of the animation.
   * @param animation The animation reference metadata to register.
   */
  register(name: AnimationPreset | string, animation: IAnimationReferenceMetadata): void;
  /**
   * Unregister an animation from the registry.
   *
   * @public
   * @param name The name of the animation to retrieve.
   */
  unregister(name: AnimationPreset | string): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<AnimationRegistry, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
type AnimationTrigger = (cb: () => void) => void;
/**
 * Extended animation options for the directive.
 */
interface IAnimationDirectiveInput {
  name?: AnimationPreset | string;
  initial?: Keyframe;
  steps?: Array<Keyframe>;
  options?: KeyframeAnimationOptions;
  trigger?: AnimationTrigger;
  onFinished?: () => void;
}
/**
 * Structural directive that triggers animations on a element.
 *
 * @public
 */
export declare class AnimateDirective implements OnInit {
  private readonly _animationRegistry;
  private readonly _element;
  private readonly _animationPlayer;
  private readonly _renderer;
  private _wasTriggered;
  private _animate;
  private _options?;
  /**
   * Constructs a new instance of the `AnimateDirective` class.
   *
   * @public
   */
  constructor(animationRegistry?: AnimationRegistry, element?: ElementRef<HTMLElement>, animationPlayer?: AnimationPlayer, renderer?: Renderer2);
  /**
   * @public
   */
  ngOnInit(): void;
  /**
   * @private
   */
  private tryTrigger;
  /**
   * @private
   */
  private resolveAnimation;
  /**
   * @private
   */
  private resolveRegisteredAnimation;
  /**
   * @private
   */
  private mergeOptions;
  /**
   * @private
   */
  private applyInitialStyles;
  /**
   * @private
   */
  private play;
  /**
   * @private
   */
  private isKeyframeMetadataProperty;
  /**
   * Gets or sets the `animate` property.
   *
   * @public
   */
  get animate(): IAnimationDirectiveInput | AnimationPreset | string | undefined;
  set animate(value: IAnimationDirectiveInput | AnimationPreset | string | undefined);
  /**
   * Gets or sets the `options` property.
   *
   * @public
   */
  get options(): KeyframeAnimationOptions | undefined;
  set options(value: KeyframeAnimationOptions | undefined);
  static ɵfac: i0.ɵɵFactoryDeclaration<AnimateDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AnimateDirective, "[mosaikAnimate]", never, {
    "animate": {
      "alias": "mosaikAnimate";
      "required": true;
    };
    "options": {
      "alias": "mosaikAnimateOptions";
      "required": false;
    };
  }, {}, never, never, true, never>;
}
/**
 * Provides the animation infrastructure for the application.
 *
 * @param config - Optional configuration to provide additional custom animations.
 * @returns Environment providers for animations.
 * @public
 */
export declare function provideAnimate(config?: {
  animations: Record<AnimationPreset | string, IAnimationReferenceMetadata>;
}): EnvironmentProviders;
/**
 * Structural directive for detecting breakpoints.
 *
 * @public
 */
export declare class BreakpointDirective implements OnInit, OnDestroy {
  private readonly _vcr;
  private readonly _templateRef;
  private readonly _cdr;
  private readonly _breakpointService;
  private _view;
  private _changedSubscription;
  /**
   * Constructs a new instance of the `BreakpointDirective` class.
   *
   * @public
   */
  constructor();
  /**
   * @public
   */
  ngOnInit(): void;
  /**
   * @public
   */
  ngOnDestroy(): void;
  /**
   * @private
   */
  private invalidate;
  /**
   * @private
   */
  private getImplicitFn;
  /**
   * @private
   */
  private onObserve;
  static ɵfac: i0.ɵɵFactoryDeclaration<BreakpointDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<BreakpointDirective, "[mosaikBreakpoint]", never, {}, {}, never, never, true, never>;
}
/**
 * Registry of 1..n MediaQuery breakpoint ranges
 * This is published as a provider and may be overridden from custom, application-specific ranges
 *
 * @public
 */
export declare class BreakpointRegistry {
  private readonly _items;
  private readonly _findByMap;
  /**
   * Constructs a new instance of the `BreakPointRegistry` class.
   *
   * @public
   */
  constructor();
  /**
   * Get all the breakpoints whose ranges could overlapping `normal` ranges;
   * e.g. gt-sm overlaps md, lg, and xl
   *
   * @public
   * @readonly
   */
  get overlapping(): Array<IBreakpoint>;
  /**
   * Get list of all registered (non-empty) breakpoint aliases
   *
   * @public
   * @readonly
   */
  get aliases(): Array<string>;
  /**
   * Aliases are mapped to properties using suffixes
   * e.g.  'gt-sm' for property 'layout'  uses suffix 'GtSm'
   * for property layoutGtSM.
   *
   * @public
   * @readonly
   */
  get suffixes(): Array<string>;
  /**
   * Register a new breakpoint or array of breakpoints
   *
   * @public
   */
  register(breakpoint: IBreakpoint | Array<IBreakpoint>): void;
  /**
   * Search breakpoints by alias (e.g. gt-xs)
   *
   * @public
   */
  findByAlias(alias: string): IBreakpoint | null;
  /**
   * Search breakpoints by media query (e.g. (min-width: 600px))
   *
   * @public
   */
  findByQuery(query: string): IBreakpoint | null;
  /**
   * Memoized lookup using custom predicate function
   *
   * @private
   */
  private findWithPredicate;
  static ɵfac: i0.ɵɵFactoryDeclaration<BreakpointRegistry, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * Service for observing and querying breakpoint matches.
 *
 * @public
 */
export declare class BreakpointService implements OnDestroy {
  private readonly _breakpointObserver;
  private readonly _breakpointRegistry;
  private readonly _changed;
  private readonly _subscriptions;
  /**
   * Constructs a new instance of the `BreakpointService` class.
   *
   * @public
   */
  constructor();
  /**
   * Emits whenever a watched breakpoint changes.
   *
   * @public
   * @readonly
   */
  get changed(): Observable<void>;
  /**
   * @public
   */
  ngOnDestroy(): void;
  /**
   * Checks whether the given breakpoint alias or aliases are currently matched.
   *
   * @public
   */
  isMatched(alias: BreakpointAlias | string | Array<BreakpointAlias | string>): boolean;
  /**
   * Returns an observable that emits `true` or `false` whenever the match state
   * for the given alias or aliases changes.
   *
   * @public
   */
  observe(alias: BreakpointAlias | string | Array<BreakpointAlias | string>): Observable<boolean>;
  /**
   * Starts observing the given alias or aliases and emits on the `changed` subject
   * whenever the match state changes. Returns a cleanup function to unsubscribe.
   *
   * @public
   */
  watch(alias: BreakpointAlias | string | Array<BreakpointAlias | string>): () => void;
  /**
   * Resolves the given alias or aliases to their corresponding media queries.
   *
   * @private
   */
  private resolveMediaQueries;
  /**
   * Resolves a stable key for a given alias or set of aliases.
   *
   * @private
   */
  private resolveKey;
  static ɵfac: i0.ɵɵFactoryDeclaration<BreakpointService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * @public
 */
export declare function provideBreakpoints(config?: {
  breakpoints: Array<IBreakpoint>;
}): EnvironmentProviders;
/**
 * @public
 */
type CancelReason = 'positive' | 'negative' | 'none';
/**
 * @public
 */
interface ICancel<TResult> {
  readonly reason: CancelReason;
  readonly result?: TResult;
}
/**
 * @public
 */
export declare class Cancel<TResult> implements ICancel<TResult> {
  private readonly _result?;
  private readonly _reason;
  /**
   * Constructs a new instance of the `Cancel` class.
   *
   * @private
   */
  private constructor();
  /**
   * Gets or sets the `reason` property.
   *
   * @public
   * @readonly
   */
  get reason(): CancelReason;
  /**
   * Returns the `result` property.
   *
   * @public
   * @readonly
   */
  get result(): TResult | undefined;
  static positive<TResult>(result?: TResult): ICancel<TResult>;
  static negative<TResult>(result?: TResult): ICancel<TResult>;
  static none<TResult>(result?: TResult): ICancel<TResult>;
}
/**
 * Directive that attaches a `PerspectiveElement` to its host element
 * and updates it reactively based on the configuration input.
 *
 * @example
 * <div [mosaikPerspective]="{ distance: 800, rotation: '45deg' }"></div>
 *
 * @public
 */
export declare class PerspectiveDirective implements OnInit, OnDestroy {
  private readonly _element;
  private readonly _renderer;
  private readonly _config;
  private readonly _perspectiveElement;
  private readonly _cleanup;
  /**
   * Constructs a new instance of the `PerspectiveDirective` class.
   *
   * @public
   */
  constructor();
  /**
   * Configuration input for the perspective behavior.
   *
   * @public
   */
  set config(value: Partial<PerspectiveElement.Props>);
  get config(): Partial<PerspectiveElement.Props>;
  /**
   * @public
   */
  ngOnInit(): void;
  /**
   * @public
   */
  ngOnDestroy(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<PerspectiveDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<PerspectiveDirective, "[mosaikPerspective]", never, {
    "config": {
      "alias": "mosaikPerspective";
      "required": false;
    };
  }, {}, never, never, true, never>;
}
/**
 * Directive that attaches a `RippleElement` to its host element
 * and updates it when input properties change.
 *
 * @example
 * <button [mosaikRipple]="{ disabled: false, centered: true }">Click me</button>
 *
 * @public
 */
export declare class RippleDirective implements OnInit, OnDestroy {
  private readonly _element;
  private readonly _renderer;
  private readonly _config;
  private readonly _rippleElement;
  private readonly _cleanup;
  /**
   * Constructs a new instance of the `RippleDirective` class.
   *
   * @public
   */
  constructor();
  /**
   * Configuration for the ripple behavior.
   *
   * @public
   */
  set config(value: Partial<RippleElement.Props>);
  get config(): Partial<RippleElement.Props>;
  /**
   * @public
   */
  ngOnInit(): void;
  /**
   * @public
   */
  ngOnDestroy(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<RippleDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<RippleDirective, "[mosaikRipple]", never, {
    "config": {
      "alias": "mosaikRipple";
      "required": false;
    };
  }, {}, never, never, true, never>;
}
/**
 * Directive that attaches a `ScaleElement` to its host element
 * and updates it when input properties change.
 *
 * @example
 * <div [mosaikScale]="{ value: 1.2, origin: 'left' }"></div>
 *
 * @public
 */
export declare class ScaleDirective implements OnInit, OnDestroy {
  private readonly _element;
  private readonly _renderer;
  private readonly _config;
  private readonly _scaleElement;
  private readonly _cleanup;
  /**
   * Constructs a new instance of the `ScaleDirective` class.
   *
   * @public
   */
  constructor();
  /**
   * Configuration input for the scale behavior.
   *
   * @public
   */
  get config(): Partial<ScaleElement.Props>;
  set config(value: Partial<ScaleElement.Props>);
  /**
   * @public
   */
  ngOnInit(): void;
  /**
   * @public
   */
  ngOnDestroy(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ScaleDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ScaleDirective, "[mosaikScale]", never, {
    "config": {
      "alias": "mosaikScale";
      "required": false;
    };
  }, {}, never, never, true, never>;
}
/**
 * Flex Directive - A directive to apply flexbox layout styles to an element.
 *
 * @public
 */
export declare class FlexDirective implements OnChanges {
  private readonly _element;
  private readonly _renderer;
  constructor(element: ElementRef<HTMLElement>, renderer: Renderer2);
  justify?: FlexJustify;
  alignItems?: FlexAlignItems;
  alignContent?: FlexAlignContent;
  direction?: FlexDirection;
  wrap?: FlexWrap;
  gap?: CssLength;
  fill?: boolean | number;
  /**
   * @public
   */
  ngOnChanges(_changes: SimpleChanges): void;
  /**
   * @private
   */
  private setStyle;
  /**
   * @private
   */
  private setFillStyle;
  static ɵfac: i0.ɵɵFactoryDeclaration<FlexDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<FlexDirective, "[mosaikFlex]", never, {
    "justify": {
      "alias": "mosaikFlexJustify";
      "required": false;
    };
    "alignItems": {
      "alias": "mosaikFlexAlignItems";
      "required": false;
    };
    "alignContent": {
      "alias": "mosaikFlexAlignContent";
      "required": false;
    };
    "direction": {
      "alias": "mosaikFlexDirection";
      "required": false;
    };
    "wrap": {
      "alias": "mosaikFlexWrap";
      "required": false;
    };
    "gap": {
      "alias": "mosaikFlexGap";
      "required": false;
    };
    "fill": {
      "alias": "mosaikFlexFill";
      "required": false;
    };
  }, {}, never, never, true, never>;
}
export declare class CardIsBusyDirective implements OnChanges {
  private readonly _elementRef;
  private readonly _viewContainerRef;
  private readonly _renderer;
  private _spinner;
  /**
   * Constructs a new instance of the `CardIsBusyDirective` class.
   *
   * @public
   */
  constructor();
  isBusy: boolean;
  ngOnChanges(changes: SimpleChanges): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<CardIsBusyDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<CardIsBusyDirective, "mosaik-card[isBusy]", never, {
    "isBusy": {
      "alias": "isBusy";
      "required": false;
    };
  }, {}, never, never, true, never>;
  static ngAcceptInputType_isBusy: unknown;
}
/**
 * Configures a NumberBox for localized currency input and presentation.
 *
 * @example
 * ```html
 * <mosaik-numberbox mosaikCurrency="EUR" />
 * <mosaik-numberbox mosaikCurrency [mosaikCurrencyStep]="0" />
 * ```
 *
 * @public
 */
export declare class NumberBoxCurrencyDirective {
  private readonly _defaultCurrencyCode;
  private readonly _element;
  private readonly _fallbackLocale;
  private readonly _translateService;
  private readonly _translatedLocale;
  /**
   * Constructs a currency NumberBox directive.
   *
   * @public
   */
  constructor();
  /** Currency code. A bare attribute uses Angular's `DEFAULT_CURRENCY_CODE`. */
  readonly currencyCode: import("@angular/core").InputSignal<string>;
  /** Optional locale override. */
  readonly locale: import("@angular/core").InputSignal<string | undefined>;
  /** Optional fixed number of displayed and stored fraction digits. */
  readonly decimalPlaces: import("@angular/core").InputSignalWithTransform<number | undefined, unknown>;
  /** Optional numeric increment. Zero disables spinner and arrow-key stepping. */
  readonly step: import("@angular/core").InputSignalWithTransform<number | undefined, unknown>;
  private applyConfiguration;
  static ɵfac: i0.ɵɵFactoryDeclaration<NumberBoxCurrencyDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NumberBoxCurrencyDirective, "mosaik-numberbox[mosaikCurrency]", never, {
    "currencyCode": {
      "alias": "mosaikCurrency";
      "required": false;
      "isSignal": true;
    };
    "locale": {
      "alias": "mosaikCurrencyLocale";
      "required": false;
      "isSignal": true;
    };
    "decimalPlaces": {
      "alias": "mosaikCurrencyDecimalPlaces";
      "required": false;
      "isSignal": true;
    };
    "step": {
      "alias": "mosaikCurrencyStep";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * Configures a NumberBox for localized decimal input and presentation.
 *
 * @example
 * ```html
 * <mosaik-numberbox mosaikDecimal [mosaikDecimalPlaces]="3" />
 * ```
 *
 * @public
 */
export declare class NumberBoxDecimalDirective {
  private readonly _element;
  private readonly _fallbackLocale;
  private readonly _translateService;
  private readonly _translatedLocale;
  /**
   * Constructs a decimal NumberBox directive.
   *
   * @public
   */
  constructor();
  /** Optional locale override. */
  readonly locale: import("@angular/core").InputSignal<string | undefined>;
  /** Fixed number of displayed and stored fraction digits. */
  readonly decimalPlaces: import("@angular/core").InputSignalWithTransform<number | undefined, unknown>;
  /** Optional numeric increment. Zero disables stepping. */
  readonly step: import("@angular/core").InputSignalWithTransform<number | undefined, unknown>;
  /** Whether the localized display groups thousands. */
  readonly useGrouping: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  private applyConfiguration;
  static ɵfac: i0.ɵɵFactoryDeclaration<NumberBoxDecimalDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NumberBoxDecimalDirective, "mosaik-numberbox[mosaikDecimal]", never, {
    "locale": {
      "alias": "mosaikDecimalLocale";
      "required": false;
      "isSignal": true;
    };
    "decimalPlaces": {
      "alias": "mosaikDecimalPlaces";
      "required": false;
      "isSignal": true;
    };
    "step": {
      "alias": "mosaikDecimalStep";
      "required": false;
      "isSignal": true;
    };
    "useGrouping": {
      "alias": "mosaikDecimalUseGrouping";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * Configures a NumberBox for localized percentage input and presentation.
 * The model remains fractional: `0.1234` is displayed as `12.34%`.
 *
 * @example
 * ```html
 * <mosaik-numberbox mosaikPercentage />
 * ```
 *
 * @public
 */
export declare class NumberBoxPercentageDirective {
  private readonly _element;
  private readonly _fallbackLocale;
  private readonly _translateService;
  private readonly _translatedLocale;
  /**
   * Constructs a percentage NumberBox directive.
   *
   * @public
   */
  constructor();
  /** Optional locale override. */
  readonly locale: import("@angular/core").InputSignal<string | undefined>;
  /** Number of fraction digits displayed after conversion to percent. */
  readonly decimalPlaces: import("@angular/core").InputSignalWithTransform<number | undefined, unknown>;
  /** Optional fractional-model increment. Zero disables stepping. */
  readonly step: import("@angular/core").InputSignalWithTransform<number | undefined, unknown>;
  private applyConfiguration;
  static ɵfac: i0.ɵɵFactoryDeclaration<NumberBoxPercentageDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<NumberBoxPercentageDirective, "mosaik-numberbox[mosaikPercentage]", never, {
    "locale": {
      "alias": "mosaikPercentageLocale";
      "required": false;
      "isSignal": true;
    };
    "decimalPlaces": {
      "alias": "mosaikPercentageDecimalPlaces";
      "required": false;
      "isSignal": true;
    };
    "step": {
      "alias": "mosaikPercentageStep";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * Directive to manage the docking position of an element in a dock panel.
 */
export declare class DockDirective implements OnChanges {
  private readonly _element;
  private readonly _renderer;
  constructor(element: ElementRef<HTMLElement>, renderer: Renderer2);
  /**
   * The docking position of the element.
   *
   * @public
   */
  dock?: DockSide | null;
  ngOnChanges(_changes: SimpleChanges): void;
  private normalize;
  static ɵfac: i0.ɵɵFactoryDeclaration<DockDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<DockDirective, "[mosaikDock]", never, {
    "dock": {
      "alias": "mosaikDock";
      "required": false;
    };
  }, {}, never, never, true, never>;
}
/**
 * Hybrid Directive supporting both Reactive and Signal Forms for error grouping.
 *
 * @example
 * ```html
 * <mosaik-form-field [fieldState]="form.someField()">
 *   <mosaik-error mosaikErrorGroup [field]="form.someField()">
 *     <mosaik-error kind="required">This field is required.</mosaik-error>
 *     <mosaik-error kind="minlength">Minimum length not met.</mosaik-error>
 *   </mosaik-error>
 * </mosaik-form-field>
 *
 * @public
 */
export declare class ErrorGroupDirective implements AfterViewInit, DoCheck, OnDestroy {
  private readonly _components;
  private readonly _targetInfo;
  private readonly _cdr;
  private readonly _formGroup?;
  private _handler;
  /**
   * Constructs a new instance of the `{@link ErrorGroupDirective}` class.
   *
   * @public
   */
  constructor(cdr?: ChangeDetectorRef);
  field: string | Array<string> | AbstractControl | FieldState<any> | Array<FieldState<any>>;
  ngAfterViewInit(): void;
  ngDoCheck(): void;
  ngOnDestroy(): void;
  private selectHandler;
  static ɵfac: i0.ɵɵFactoryDeclaration<ErrorGroupDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ErrorGroupDirective, "[mosaikErrorGroup]", ["errorGroup"], {
    "field": {
      "alias": "field";
      "required": true;
    };
  }, {}, ["_components"], never, true, never>;
}
/**
 * The directive representing a specific kind of error.
 *
 * @example
 * ```html
 * <mosaik-error text="This field is required."
 *               kind="required"/>
 * <mosaik-error text="Minimum length not met."
 *               kind="minlength"/>
 * ```
 *
 * @public
 */
export declare class ErrorKindDirective {
  private _kind;
  private _hidden;
  /**
   * Constructs a new instance of the `ErrorDirective` class.
   *
   * @public
   */
  constructor();
  /**
   * The kind(s) of error this directive represents.
   *
   * @public
   */
  get kind(): string | Array<string>;
  set kind(value: string | Array<string>);
  get hidden(): boolean;
  set hidden(value: boolean);
  static ɵfac: i0.ɵɵFactoryDeclaration<ErrorKindDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ErrorKindDirective, "mosaik-error[kind]", ["mosaikError"], {
    "kind": {
      "alias": "kind";
      "required": true;
    };
    "hidden": {
      "alias": "hidden";
      "required": false;
    };
  }, {}, never, never, true, never>;
}
/**
 * Attribute-Directive that binds a `FieldState` to `FormFieldElement`.
 * It observes the validation `errors()` and `touched()` state of the field,
 * and automatically updates the Element’s `error` property - always using the **last** validation error (if any) when the field has been touched.
 *
 * @example
 * ```html
 * <mosaik-form-field [fieldState]="form.someField()">
 *   <mosaik-textbox [field]="form.someField" … ></mosaik-textbox>
 * </mosaik-form-field>
 * ```
 *
 * @public
 */
export declare class FormFieldStateDirective {
  private readonly _elementRef;
  constructor(elementRef?: ElementRef<FormFieldElement>);
  /**
   * The FieldState to observe for validation errors.
   *
   * @public
   * @example
   * ```html
   * <mosaik-form-field [fieldState]="form.someField()">
   *   …
   * </mosaik-form-field>
   * ```
   */
  fieldState: InputSignal<FieldState<unknown> | null | undefined>;
  /**
   * Maps the FieldState (errors + touched) to the Element error property.
   * If there is at least one error AND the field has been touched → set error to the
   * last error.message. Otherwise clear the error.
   *
   * @private
   * @param fieldState The current FieldState
   */
  private setError;
  static ɵfac: i0.ɵɵFactoryDeclaration<FormFieldStateDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<FormFieldStateDirective, "mosaik-form-field", ["formFieldState"], {
    "fieldState": {
      "alias": "fieldState";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * Directive to toggle an ExpandableComponent.
 *
 * Can be applied to any element, and will attempt to find a parent ExpandableComponent
 * if an explicit reference is not provided via the `mosaikExpandableToggle` input.
 *
 * @example
 * ```html
 * <mosaik-expandable #expandable>
 *     ...
 * </mosaik-expandable>
 * <mosaik-anchor [mosaikExpandableToggle]="expandable"
 *                #toggle="mosaikExpandableToggle"
 *                [label]="toggle.isExpanded() ? 'Show less' : 'Show more'" />
 * ```
 *
 * @public
 */
export declare class ExpandableToggleDirective {
  private readonly _component;
  /**
   * Constructs a new instance of the `ExpandableToggleDirective` class.
   *
   * @public
   */
  constructor();
  /**
   * Optional explicit reference to the `ExpandableComponent`.
   * When provided, this takes precedence over the auto-injected instance.
   *
   * @example
   * ```html
   * <mosaik-expandable #expandable>
   *     ...
   * </mosaik-expandable>
   * <mosaik-anchor [mosaikExpandableToggle]="expandable"
   *                [label]="'Toggle'" />
   * ```
   *
   * @public
   */
  readonly expandableToggle: import("@angular/core").InputSignal<ExpandableComponent | undefined>;
  /**
   * Whether the expandable is currently expanded.
   *
   * @public
   */
  readonly isExpanded: Signal<boolean>;
  /**
   * @protected
   */
  protected onClick(_event: MouseEvent): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ExpandableToggleDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ExpandableToggleDirective, "[mosaikExpandableToggle]", ["mosaikExpandableToggle"], {
    "expandableToggle": {
      "alias": "mosaikExpandableToggle";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * Directive to flip a FlipComponent to a specific side when the host element is clicked.
 *
 * Can be applied to any element, and will attempt to find a parent FlipComponent
 * if an explicit reference is not provided via the `mosaikFlipTo` input.
 *
 * @example
 * ```html
 * <mosaik-flip #flip>
 *     <div slot="front">Front</div>
 *     <div slot="back">Back</div>
 * </mosaik-flip>
 *
 * <mosaik-button label="Flip to Back"
 *                [mosaikFlipTo]="'back'"
 *                [mosaikFlipToDisabled]="isDisabled"/>
 * <mosaik-button label="Flip to Front"
 *                [mosaikFlipTo]="'front'"
 *                [mosaikFlipToDisabled]="isDisabled"/>
 * ```
 */
export declare class FlipToDirective {
  private readonly _component;
  /**
   * Constructs a new instance of the `FlipToDirective` class.
   *
   * @public
   */
  constructor();
  /**
   * The flip side to which the component will be flipped.
   *
   * @public
   */
  to?: FlipElement['side'];
  isDisabled?: boolean;
  /**
   * @protected
   */
  protected onClick(_event: MouseEvent): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<FlipToDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<FlipToDirective, "[mosaikFlipTo]", ["mosaikFlipTo"], {
    "to": {
      "alias": "mosaikFlipTo";
      "required": true;
    };
    "isDisabled": {
      "alias": "mosaikFlipToDisabled";
      "required": false;
    };
  }, {}, never, never, true, never>;
}
/**
 * Represents the configuration for the `TooltipDirective`.
 *
 * @public
 */
export interface ITooltipDirectiveConfig {
  /**
   * The tooltip text content.
   *
   * @public
   */
  content?: string;
  /**
   * The placement of the tooltip relative to the host element.
   *
   * @public
   */
  placement?: Placement;
  /**
   * The horizontal offset of the tooltip.
   *
   * @public
   */
  horizontalOffset?: number;
  /**
   * The vertical offset of the tooltip.
   *
   * @public
   */
  verticalOffset?: number;
  /**
   * The delay in milliseconds before showing the tooltip.
   *
   * @public
   */
  showDelay?: number;
  /**
   * The delay in milliseconds before hiding the tooltip.
   *
   * @public
   */
  hideDelay?: number;
  /**
   * The trigger mode for the tooltip.
   *
   * @public
   */
  trigger?: Trigger;
  /**
   * Whether the tooltip stays open after the trigger ends.
   *
   * @public
   */
  staysOpen?: boolean;
  /**
   * Whether the tooltip is disabled.
   *
   * @public
   */
  disabled?: boolean;
}
/**
 * Directive that attaches a `TooltipElement` to its host element.
 * Allows adding tooltips to any arbitrary element by using the `[mosaikTooltip]` selector.
 *
 * @example
 * Simple text tooltip:
 * ```html
 * <mosaik-button label="Save"
 *                [mosaikTooltip]="'Save changes'"/>
 * ```
 *
 * @example
 * Tooltip with configuration object:
 * ```html
 * <mosaik-button label="Save"
 *                [mosaikTooltip]="{ content: 'Save changes', placement: 'top', showDelay: 300 }"/>
 * ```
 *
 * @example
 * Tooltip with individual inputs:
 * ```html
 * <mosaik-button label="Settings"
 *                [mosaikTooltip]="'User settings'"
 *                [mosaikTooltipPlacement]="'right'"
 *                [mosaikTooltipShowDelay]="500"/>
 * ```
 *
 * @public
 */
export declare class TooltipDirective implements OnDestroy {
  private readonly _element;
  private readonly _renderer;
  private readonly _config;
  private readonly _placement;
  private readonly _horizontalOffset;
  private readonly _verticalOffset;
  private readonly _showDelay;
  private readonly _hideDelay;
  private readonly _trigger;
  private readonly _staysOpen;
  private readonly _disabled;
  private readonly _tooltipElement;
  private readonly _cleanup;
  /**
   * Constructs a new instance of the `TooltipDirective` class.
   *
   * @public
   */
  constructor();
  /**
   * The tooltip content. Accepts a string or a configuration object.
   * When a string is provided, it is used as the tooltip text content.
   * When a configuration object is provided, all tooltip properties can be set at once.
   *
   * @public
   */
  set config(value: string | ITooltipDirectiveConfig);
  get config(): string | ITooltipDirectiveConfig;
  /**
   * The placement of the tooltip relative to the host element.
   *
   * @public
   */
  set placement(value: Placement);
  get placement(): Placement | undefined;
  /**
   * The horizontal offset of the tooltip.
   *
   * @public
   */
  set horizontalOffset(value: number);
  get horizontalOffset(): number | undefined;
  /**
   * The vertical offset of the tooltip.
   *
   * @public
   */
  set verticalOffset(value: number);
  get verticalOffset(): number | undefined;
  /**
   * The delay in milliseconds before showing the tooltip.
   *
   * @public
   */
  set showDelay(value: number);
  get showDelay(): number | undefined;
  /**
   * The delay in milliseconds before hiding the tooltip.
   *
   * @public
   */
  set hideDelay(value: number);
  get hideDelay(): number | undefined;
  /**
   * The trigger mode for the tooltip.
   *
   * @public
   */
  set trigger(value: Trigger);
  get trigger(): Trigger | undefined;
  /**
   * Whether the tooltip stays open after the trigger ends.
   *
   * @public
   */
  set staysOpen(value: boolean);
  get staysOpen(): boolean | undefined;
  /**
   * Whether the tooltip is disabled.
   *
   * @public
   */
  set disabled(value: boolean);
  get disabled(): boolean | undefined;
  /**
   * @public
   */
  ngOnDestroy(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<TooltipDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<TooltipDirective, "[mosaikTooltip]", never, {
    "config": {
      "alias": "mosaikTooltip";
      "required": false;
    };
    "placement": {
      "alias": "mosaikTooltipPlacement";
      "required": false;
    };
    "horizontalOffset": {
      "alias": "mosaikTooltipHorizontalOffset";
      "required": false;
    };
    "verticalOffset": {
      "alias": "mosaikTooltipVerticalOffset";
      "required": false;
    };
    "showDelay": {
      "alias": "mosaikTooltipShowDelay";
      "required": false;
    };
    "hideDelay": {
      "alias": "mosaikTooltipHideDelay";
      "required": false;
    };
    "trigger": {
      "alias": "mosaikTooltipTrigger";
      "required": false;
    };
    "staysOpen": {
      "alias": "mosaikTooltipStaysOpen";
      "required": false;
    };
    "disabled": {
      "alias": "mosaikTooltipDisabled";
      "required": false;
    };
  }, {}, never, never, true, never>;
}
/**
 * Creates a single DataList item definition with full type inference.
 *
 * @remarks
 * This function acts as a facade over the Foundation-level `IDataListItemDefinition`,
 * so Angular consumers never need to import it directly.
 * Parameter types are derived from the Foundation interface, so any additions
 * to `IDataListItemDefinition` are automatically reflected in `options`.
 *
 * @param key - Identifies the data property for this item.
 * @param title - Item header text.
 * @param options - Additional item options (hidden, etc.).
 * @returns The item definition.
 *
 * @public
 */
export declare function defineItem<TItem = unknown>(key: IDataListItemDefinition<TItem>['key'], title?: IDataListItemDefinition<TItem>['title'], options?: Partial<Omit<IDataListItemDefinition<TItem>, 'key' | 'title'>>): IDataListItemDefinition<TItem>;
/**
 * Creates multiple DataList item definitions.
 *
 * @remarks
 * This function acts as a facade over the Foundation-level
 * `IDataListItemDefinition`, so Angular consumers never need to
 * import it directly. Items are typically created via {@link defineItem}.
 *
 * @param items - The item definitions.
 * @returns The item definitions as an array.
 *
 * @public
 */
export declare function defineItems<TItem = unknown>(...items: IDataListItemDefinition<TItem>[]): IDataListItemDefinition<TItem>[];
/**
 * Describes the template context for `ItemDefDirective`.
 *
 * @remarks
 * The `$implicit` property holds the data item for the current row,
 * accessible via `let item` in the structural directive syntax.
 * The `definition` property provides the item definition metadata.
 *
 * @public
 */
interface IItemDefContext {
  /**
   * The data item for the current row.
   * Accessible via `let item` in the structural directive syntax.
   *
   * @public
   */
  $implicit: unknown;
  /**
   * The item definition for the current field.
   *
   * @public
   */
  definition: IDataListItemDefinition;
}
/**
 * Structural directive that defines a custom item template for a data list item definition.
 *
 * @remarks
 * Use this directive inside an `mosaikItemDef` container to provide a custom
 * template for list items. The template receives the data item via `let item`
 * and the item definition via `let definition = definition`.
 *
 * @example
 * ```html
 * <ng-container mosaikItemDef="status">
 *   <ng-container *mosaikItemCellDef="let item">
 *     <mosaik-badge [text]="item.status"></mosaik-badge>
 *   </ng-container>
 * </ng-container>
 * ```
 *
 * @public
 */
export declare class ItemCellDefDirective {
  private readonly _template;
  constructor();
  /**
   * The template reference for the item content.
   *
   * @public
   * @readonly
   */
  get template(): TemplateRef<IItemDefContext>;
  /**
   * Asserts the correct type for the template context.
   *
   * @public
   * @static
   */
  static ngTemplateContextGuard(_dir: ItemCellDefDirective, _ctx: unknown): _ctx is IItemDefContext;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItemCellDefDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ItemCellDefDirective, "[mosaikItemCellDef]", never, {}, {}, never, never, true, never>;
}
/**
 * Directive that defines a custom item template for a specific data list item definition.
 *
 * @remarks
 * Place this directive on an `ng-container` inside a `mosaik-data-list` component.
 * The directive bridges Angular `ng-template` content to the Lit-based DataList's
 * `itemTemplate` callback, translating `TemplateRef` instances
 * into DOM nodes that the DataList can render.
 *
 * @example
 * ```html
 * <mosaik-data-list [source]="data" [itemDefinitions]="defs">
 *   <ng-container mosaikItemDef="status">
 *     <ng-container *mosaikItemCellDef="let item">
 *       <mosaik-badge [text]="item.status"></mosaik-badge>
 *     </ng-container>
 *   </ng-container>
 *   <ng-container mosaikItemDef="name">
 *     <ng-container *mosaikItemCellDef="let item">
 *       <a [href]="'/users/' + item.id">{{ item.name }}</a>
 *     </ng-container>
 *   </ng-container>
 * </mosaik-data-list>
 * ```
 *
 * @public
 */
export declare class ItemDefDirective implements AfterContentInit, OnDestroy {
  private readonly _dataList;
  private readonly _vcr;
  private readonly _injector;
  private readonly _views;
  private _nativeElement;
  private _cleanupScheduled;
  constructor();
  /**
   * The item definition key that this directive targets.
   * Must match the `key` property of an item definition in `itemDefinitions`.
   *
   * @public
   */
  itemKey: string;
  /**
   * The item cell template directive.
   *
   * @public
   */
  itemCellDef?: ItemCellDefDirective;
  /**
   * @public
   */
  ngAfterContentInit(): void;
  /**
   * @public
   */
  ngOnDestroy(): void;
  /**
   * Builds the template callback and registers it as an override on the native element.
   *
   * @private
   */
  private applyTemplates;
  /**
   * Creates an `itemTemplate` callback that renders an Angular template into a `DocumentFragment`.
   *
   * @private
   */
  private createItemTemplateCallback;
  /**
   * Schedules a deferred cleanup of disconnected views.
   * The cleanup runs after the current Lit render cycle completes via `requestAnimationFrame`,
   * ensuring that newly created DOM nodes have been flushed to the document before checking `isConnected`.
   *
   * @private
   */
  private scheduleViewCleanup;
  /**
   * Destroys embedded views whose DOM nodes are no longer connected to the document.
   * This prevents memory leaks when the DataList re-renders and replaces item content.
   *
   * @private
   */
  private cleanupDisconnectedViews;
  static ɵfac: i0.ɵɵFactoryDeclaration<ItemDefDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ItemDefDirective, "[mosaikItemDef]", never, {
    "itemKey": {
      "alias": "mosaikItemDef";
      "required": true;
    };
  }, {}, ["itemCellDef"], never, true, never>;
}
/**
 * Describes the template context for `CellDefDirective`.
 *
 * @remarks
 * The `$implicit` property holds the data item for the current row,
 * accessible via `let item` in the structural directive syntax.
 * The `column` property provides the column definition metadata.
 *
 * @public
 */
interface ICellDefContext {
  /**
   * The data item for the current row.
   * Accessible via `let item` in the structural directive syntax.
   *
   * @public
   */
  $implicit: unknown;
  /**
   * The column definition for the current column.
   *
   * @public
   */
  column: IDataTableColumnDefinition;
  /**
   * The pre-resolved display value produced by the column's `pathFn`.
   * Accessible via `let value = value` in the structural directive syntax.
   *
   * @public
   */
  value: unknown;
}
/**
 * Structural directive that defines a custom cell template for a data table column.
 *
 * @remarks
 * Use this directive inside a `mosaikColumnDef` container to provide a custom
 * template for body cells. The template receives the data item via `let item`
 * and the column definition via `let column = column`.
 *
 * @example
 * ```html
 * <ng-container mosaikColumnDef="status">
 *   <ng-container *mosaikCellDef="let item">
 *     <mosaik-badge [text]="item.status"></mosaik-badge>
 *   </ng-container>
 * </ng-container>
 * ```
 *
 * @public
 */
export declare class CellDefDirective {
  private readonly _template;
  constructor();
  /**
   * The template reference for the cell content.
   *
   * @public
   * @readonly
   */
  get template(): TemplateRef<ICellDefContext>;
  /**
   * Asserts the correct type for the template context.
   *
   * @public
   * @static
   */
  static ngTemplateContextGuard(_dir: CellDefDirective, _ctx: unknown): _ctx is ICellDefContext;
  static ɵfac: i0.ɵɵFactoryDeclaration<CellDefDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<CellDefDirective, "[mosaikCellDef]", never, {}, {}, never, never, true, never>;
}
/**
 * Describes the template context for `FooterCellDefDirective`.
 *
 * @public
 */
interface IFooterCellDefContext {
  /**
   * The column definition for the current column.
   * Accessible via `let column` in the structural directive syntax.
   *
   * @public
   */
  $implicit: IDataTableColumnDefinition;
}
/**
 * Structural directive that defines a custom footer cell template for a data table column.
 *
 * @remarks
 * Use this directive inside a `mosaikColumnDef` container. The data table renders a
 * footer row as soon as one visible column contains a footer definition and keeps it
 * aligned while columns are hidden, reordered, pinned, or resized.
 *
 * @example
 * ```html
 * <ng-container mosaikColumnDef="amount">
 *   <ng-container *mosaikFooterCellDef>
 *     <strong>Total: 1,234.00 EUR</strong>
 *   </ng-container>
 * </ng-container>
 * ```
 *
 * @public
 */
export declare class FooterCellDefDirective {
  private readonly _template;
  constructor();
  /**
   * The template reference for the footer cell content.
   *
   * @public
   * @readonly
   */
  get template(): TemplateRef<IFooterCellDefContext>;
  /**
   * Asserts the correct type for the template context.
   *
   * @public
   * @static
   */
  static ngTemplateContextGuard(_dir: FooterCellDefDirective, _ctx: unknown): _ctx is IFooterCellDefContext;
  static ɵfac: i0.ɵɵFactoryDeclaration<FooterCellDefDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<FooterCellDefDirective, "[mosaikFooterCellDef]", never, {}, {}, never, never, true, never>;
}
/**
 * Describes the template context for `HeaderCellDefDirective`.
 *
 * @remarks
 * The `$implicit` property holds the column definition,
 * accessible via `let column` in the structural directive syntax.
 *
 * @public
 */
interface IHeaderCellDefContext {
  /**
   * The column definition for the current column.
   * Accessible via `let column` in the structural directive syntax.
   *
   * @public
   */
  $implicit: IDataTableColumnDefinition;
}
/**
 * Structural directive that defines a custom header cell template for a data table column.
 *
 * @remarks
 * Use this directive inside a `mosaikColumnDef` container to provide a custom
 * template for the header cell. The template receives the column definition via `let column`.
 *
 * @example
 * ```html
 * <ng-container mosaikColumnDef="status">
 *   <ng-container *mosaikHeaderCellDef="let column">
 *     <mosaik-icon [data]="statusIcon"></mosaik-icon>
 *     <span>{{ column.title }}</span>
 *   </ng-container>
 * </ng-container>
 * ```
 *
 * @public
 */
export declare class HeaderCellDefDirective {
  private readonly _template;
  constructor();
  /**
   * The template reference for the header cell content.
   *
   * @public
   * @readonly
   */
  get template(): TemplateRef<IHeaderCellDefContext>;
  /**
   * Asserts the correct type for the template context.
   *
   * @public
   * @static
   */
  static ngTemplateContextGuard(_dir: HeaderCellDefDirective, _ctx: unknown): _ctx is IHeaderCellDefContext;
  static ɵfac: i0.ɵɵFactoryDeclaration<HeaderCellDefDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<HeaderCellDefDirective, "[mosaikHeaderCellDef]", never, {}, {}, never, never, true, never>;
}
/**
 * Directive that defines custom body, header, and footer cell templates for a specific data table column.
 *
 * @remarks
 * Place this directive on an `ng-container` inside a `mosaik-data-table` component.
 * The directive bridges Angular `ng-template` content to the Lit-based DataTable's
 * `cellTemplate` / `headerCellTemplate` callbacks, translating `TemplateRef` instances
 * into DOM nodes that the DataTable can render.
 *
 * @example
 * ```html
 * <mosaik-data-table [source]="data" [columnDefinitions]="cols">
 *   <ng-container mosaikColumnDef="status">
 *     <ng-container *mosaikCellDef="let item">
 *       <mosaik-badge [text]="item.status"></mosaik-badge>
 *     </ng-container>
 *   </ng-container>
 *   <ng-container mosaikColumnDef="name">
 *     <ng-container *mosaikHeaderCellDef="let column">
 *       <mosaik-icon data="user-icon"></mosaik-icon>
 *       <span>{{ column.title }}</span>
 *     </ng-container>
 *     <ng-container *mosaikCellDef="let item">
 *       <a [href]="'/users/' + item.id">{{ item.name }}</a>
 *     </ng-container>
 *   </ng-container>
 * </mosaik-data-table>
 * ```
 *
 * @public
 */
export declare class ColumnDefDirective implements AfterContentInit, OnDestroy {
  private readonly _dataTable;
  private readonly _vcr;
  private readonly _injector;
  private readonly _views;
  private _nativeElement;
  private _cleanupScheduled;
  constructor();
  /**
   * The column key that this definition targets.
   * Must match the `key` property of a column in `columnDefinitions`.
   *
   * @public
   */
  columnKey: string;
  /**
   * The cell template directive for body cells.
   *
   * @public
   */
  cellDef?: CellDefDirective;
  /**
   * The header cell template directive.
   *
   * @public
   */
  headerCellDef?: HeaderCellDefDirective;
  /**
   * The footer cell template directive.
   *
   * @public
   */
  footerCellDef?: FooterCellDefDirective;
  /**
   * @public
   */
  ngAfterContentInit(): void;
  /**
   * @public
   */
  ngOnDestroy(): void;
  /**
   * Builds the template callbacks and registers them as overrides on the native element.
   *
   * @private
   */
  private applyTemplates;
  /**
   * Creates a `cellTemplate` callback that renders an Angular template into a `DocumentFragment`.
   *
   * @private
   */
  private createCellTemplateCallback;
  /**
   * Creates a `headerCellTemplate` callback that renders an Angular template into a `DocumentFragment`.
   *
   * @private
   */
  private createHeaderCellTemplateCallback;
  /**
   * Creates a `footerCellTemplate` callback that renders an Angular template into a `DocumentFragment`.
   *
   * @private
   */
  private createFooterCellTemplateCallback;
  /**
   * Schedules a deferred cleanup of disconnected views.
   * The cleanup runs after the current Lit render cycle completes via `requestAnimationFrame`,
   * ensuring that newly created DOM nodes have been flushed to the document before checking `isConnected`.
   *
   * @private
   */
  private scheduleViewCleanup;
  /**
   * Destroys embedded views whose DOM nodes are no longer connected to the document.
   * This prevents memory leaks when the DataTable re-renders and replaces cell content.
   *
   * @private
   */
  private cleanupDisconnectedViews;
  static ɵfac: i0.ɵɵFactoryDeclaration<ColumnDefDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ColumnDefDirective, "[mosaikColumnDef]", never, {
    "columnKey": {
      "alias": "mosaikColumnDef";
      "required": true;
    };
  }, {}, ["cellDef", "headerCellDef", "footerCellDef"], never, true, never>;
}
/**
 * Directive to toggle the column editor of a DataTableComponent.
 *
 * Can be applied to any element, and will attempt to find a parent DataTableComponent
 * if an explicit reference is not provided via the `mosaikDataTableColumnEditorToggle` input.
 *
 * @example
 * ```html
 * <mosaik-data-table #dataTable />
 * <mosaik-button label="Toggle Columns" [mosaikDataTableColumnEditorToggle]="dataTable"></mosaik-button>
 * ```
 *
 * Or with a toggle button reflecting the editor state:
 *
 * @example
 * ```html
 * <mosaik-data-table #dataTable />
 * <mosaik-toggle-button #toggle="mosaikDataTableColumnEditorToggle"
 *                       [isChecked]="toggle.editorOpened()"
 *                       [mosaikDataTableColumnEditorToggle]="dataTable"/>
 * ```
 *
 * @public
 */
export declare class DataTableColumnEditorToggleDirective {
  private readonly _component;
  private readonly _editorChanged;
  /**
   * Constructs a new instance of the `DataTableColumnEditorToggleDirective` class.
   *
   * @public
   */
  constructor();
  /**
   * Optional explicit reference to the `DataTableComponent`.
   * When provided, this takes precedence over the auto-injected instance.
   *
   * @example
   * ```html
   * <mosaik-data-table #dataTable />
   * <mosaik-button label="Toggle Columns" [mosaikDataTableColumnEditorToggle]="dataTable"></mosaik-button>
   * ```
   *
   * @public
   */
  readonly dataTableColumnEditorToggle: import("@angular/core").InputSignal<DataTableComponent | undefined>;
  /**
   * Whether the column editor is currently opened.
   *
   * @public
   */
  readonly editorOpened: Signal<boolean>;
  /**
   * @protected
   */
  protected onClick(_event: MouseEvent): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<DataTableColumnEditorToggleDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<DataTableColumnEditorToggleDirective, "[mosaikDataTableColumnEditorToggle]", ["mosaikDataTableColumnEditorToggle"], {
    "dataTableColumnEditorToggle": {
      "alias": "mosaikDataTableColumnEditorToggle";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * Creates a single DataTable column definition with full type inference.
 *
 * @remarks
 * This function acts as a facade over the Foundation-level `IDataTableColumnDefinition`,
 * so Angular consumers never need to import it directly.
 * Parameter types are derived from the Foundation interface, so any additions
 * to `IDataTableColumnDefinition` are automatically reflected in `options`.
 *
 * @param key - Identifies the data property for this column.
 * @param title - Column header text.
 * @param options - Additional column options (hidden, sortable, etc.).
 * @returns The column definition.
 *
 * @public
 */
export declare function defineColumn<TItem = unknown>(key: IDataTableColumnDefinition<TItem>['key'], title?: IDataTableColumnDefinition<TItem>['title'], options?: Partial<Omit<IDataTableColumnDefinition<TItem>, 'key' | 'title'>>): IDataTableColumnDefinition<TItem>;
/**
 * Creates multiple DataTable column definitions.
 *
 * @remarks
 * This function acts as a facade over the Foundation-level
 * `IDataTableColumnDefinition`, so Angular consumers never need to
 * import it directly. Columns are typically created via {@link defineColumn}.
 *
 * @param columns - The column definitions.
 * @returns The column definitions as an array.
 *
 * @public
 */
export declare function defineColumns<TItem = unknown>(...columns: IDataTableColumnDefinition<TItem>[]): IDataTableColumnDefinition<TItem>[];
/**
 * Template context shared by Select and Combo item visual directives.
 *
 * @public
 */
interface IItemVisualContext<TItem extends HTMLElement> {
  $implicit: TItem;
  mode: 'option' | 'selection';
}
/**
 * Creates independently bound option and selection views from one template.
 *
 * @public
 */
export declare class ComboItemVisualDirective implements OnInit, OnDestroy, DoCheck {
  private readonly _itemComponent;
  private readonly _renderer;
  private readonly _template;
  private readonly _viewContainer;
  private _optionView;
  private _selectionView;
  private _visual;
  constructor();
  ngOnInit(): void;
  ngOnDestroy(): void;
  ngDoCheck(): void;
  static ngTemplateContextGuard(_directive: ComboItemVisualDirective, context: unknown): context is IItemVisualContext<ComboItemElement>;
  /**
   * @private
   */
  private detectChanges;
  static ɵfac: i0.ɵɵFactoryDeclaration<ComboItemVisualDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ComboItemVisualDirective, "ng-template[mosaikComboItemVisual]", never, {}, {}, never, never, true, never>;
}
/**
 * Template context for `mosaikComboTrigger`.
 *
 * @public
 */
interface IComboTriggerContext {
  $implicit: ReadonlyArray<ComboItemElement>;
  selection: ReadonlyArray<ComboItemElement>;
  value: ReadonlyArray<string> | null;
}
/**
 * Projects an Angular template into the Combo trigger slot.
 * The template receives the current selected items and value, allowing a
 * multi-select field to show a concise summary instead of every selected chip.
 *
 * @example
 * ```html
 * <ng-template mosaikComboTrigger let-selection="selection">
 *     {{ selection[0]?.label }}
 *     @if (selection.length > 1) { (+{{ selection.length - 1 }} others) }
 * </ng-template>
 * ```
 *
 * @public
 */
export declare class ComboTriggerDirective implements OnInit, OnDestroy {
  private readonly _anchor;
  private readonly _accessors;
  private readonly _renderer;
  private readonly _subscriptions;
  private readonly _template;
  private readonly _viewContainer;
  private _hostElement;
  private _combo;
  private _view;
  constructor();
  ngOnInit(): void;
  ngOnDestroy(): void;
  static ngTemplateContextGuard(_directive: ComboTriggerDirective, context: unknown): context is IComboTriggerContext;
  /**
   * @private
   */
  private updateContext;
  static ɵfac: i0.ɵɵFactoryDeclaration<ComboTriggerDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ComboTriggerDirective, "ng-template[mosaikComboTrigger]", never, {}, {}, never, never, true, never>;
}
/**
 * Template context for `mosaikSelectTrigger`.
 *
 * @public
 */
interface ISelectTriggerContext {
  $implicit: SelectItemElement | null;
  selection: SelectItemElement | null;
  value: string | null;
}
/**
 * Creates independently bound option and selection views from one template.
 *
 * @example
 * ```html
 * <mosaik-select-item value="de">
 *   <ng-template mosaikSelectItemVisual let-item let-mode="mode">
 *     <mosaik-icon slot="icon" [data]="flag"></mosaik-icon>
 *     <mosaik-text slot="label">{{ item.label }} ({{ mode }})</mosaik-text>
 *   </ng-template>
 * </mosaik-select-item>
 * ```
 *
 * @public
 */
export declare class SelectItemVisualDirective implements OnInit, OnDestroy, DoCheck {
  private readonly _itemComponent;
  private readonly _renderer;
  private readonly _template;
  private readonly _viewContainer;
  private _optionView;
  private _selectionView;
  private _visual;
  constructor();
  ngOnInit(): void;
  ngOnDestroy(): void;
  ngDoCheck(): void;
  static ngTemplateContextGuard(_directive: SelectItemVisualDirective, context: unknown): context is IItemVisualContext<SelectItemElement>;
  /**
   * @private
   */
  private detectChanges;
  static ɵfac: i0.ɵɵFactoryDeclaration<SelectItemVisualDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<SelectItemVisualDirective, "ng-template[mosaikSelectItemVisual]", never, {}, {}, never, never, true, never>;
}
/**
 * Projects an Angular template into the Select trigger slot.
 * The template receives the current selected item and value so the closed
 * field can show application-specific content.
 *
 * @example
 * ```html
 * <ng-template mosaikSelectTrigger let-selection="selection">
 *     {{ selection?.label ?? 'Choose an item' }}
 * </ng-template>
 * ```
 *
 * @public
 */
export declare class SelectTriggerDirective implements OnInit, OnDestroy {
  private readonly _renderer;
  private readonly _anchor;
  private readonly _accessors;
  private readonly _subscriptions;
  private readonly _template;
  private readonly _viewContainer;
  private _hostElement;
  private _select;
  private _view;
  constructor();
  ngOnInit(): void;
  ngOnDestroy(): void;
  static ngTemplateContextGuard(_directive: SelectTriggerDirective, context: unknown): context is ISelectTriggerContext;
  /**
   * @private
   */
  private updateContext;
  static ɵfac: i0.ɵɵFactoryDeclaration<SelectTriggerDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<SelectTriggerDirective, "ng-template[mosaikSelectTrigger]", never, {}, {}, never, never, true, never>;
}
export declare class StepperNextDirective {
  private readonly _component;
  /**
   * Constructs a new instance of the `StepperNextDirective` class.
   *
   * @public
   */
  constructor();
  /**
   * @protected
   */
  protected onClick(_event: MouseEvent): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<StepperNextDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<StepperNextDirective, "[mosaikStepperNext]", never, {}, {}, never, never, true, never>;
}
export declare class StepperPrevDirective {
  private readonly _component;
  /**
   * Constructs a new instance of the `StepperPrevDirective` class.
   *
   * @public
   */
  constructor();
  /**
   * @protected
   */
  protected onClick(_event: MouseEvent): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<StepperPrevDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<StepperPrevDirective, "[mosaikStepperPrev]", never, {}, {}, never, never, true, never>;
}
export declare class WizardNextDirective {
  private readonly _component;
  /**
   * Constructs a new instance of the `WizardNextDirective` class.
   *
   * @public
   */
  constructor();
  /**
   * @protected
   */
  protected onClick(_event: MouseEvent): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<WizardNextDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<WizardNextDirective, "[mosaikWizardNext]", never, {}, {}, never, never, true, never>;
}
export declare class WizardPrevDirective {
  private readonly _component;
  /**
   * Constructs a new instance of the `WizardPrevDirective` class.
   *
   * @public
   */
  constructor();
  /**
   * @protected
   */
  protected onClick(_event: MouseEvent): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<WizardPrevDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<WizardPrevDirective, "[mosaikWizardPrev]", never, {}, {}, never, never, true, never>;
}
/**
 * Represents the options for the `SpacerDirective`.
 *
 * @public
 */
export interface ISpacerDirectiveOptions {
  multiplier?: number;
  size?: Size;
  thickness?: Spacing | Array<Spacing> | null;
  invert?: boolean;
  multiplierValidator?: (multiplier: number) => boolean;
}
/**
 * Spacer Directive - A directive to apply spacing (margins) to an element based on configurable options.
 *
 * @public
 */
export declare class SpacerDirective {
  private readonly _el;
  private readonly _renderer;
  private readonly _multiplier;
  private readonly _size;
  private readonly _thickness;
  private readonly _invert;
  private readonly _multiplierValidator;
  /**
   * Constructs a new instance of the `SpacerDirective` class.
   *
   * @public
   */
  constructor();
  /**
   * The spacing multiplier.
   *
   * @public
   */
  get multiplier(): number | undefined;
  set multiplier(value: number | undefined);
  /**
   * The size of the spacing.
   *
   * @public
   */
  get size(): Size | undefined;
  set size(value: Size | undefined);
  /**
   * The thickness or sides for which the spacer applies.
   *
   * @public
   */
  get thickness(): Spacing | Array<Spacing> | null | undefined;
  set thickness(value: Spacing | Array<Spacing> | null | undefined);
  /**
   * Whether to invert the spacing direction.
   *
   * @public
   */
  get invert(): boolean | undefined;
  set invert(value: boolean | undefined);
  /**
   * Optional custom validator for the multiplier.
   *
   * @public
   */
  get multiplierValidator(): ((multiplier: number) => boolean) | undefined;
  set multiplierValidator(value: ((multiplier: number) => boolean) | undefined);
  static ɵfac: i0.ɵɵFactoryDeclaration<SpacerDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<SpacerDirective, "[mosaikSpacer]", never, {
    "multiplier": {
      "alias": "mosaikSpacerMultiplier";
      "required": false;
    };
    "size": {
      "alias": "mosaikSpacerSize";
      "required": false;
    };
    "thickness": {
      "alias": "mosaikSpacerThickness";
      "required": false;
    };
    "invert": {
      "alias": "mosaikSpacerInvert";
      "required": false;
    };
    "multiplierValidator": {
      "alias": "mosaikSpacerMultiplierValidator";
      "required": false;
    };
  }, {}, never, never, true, never>;
}
/**
 * Text Formatter Directive - A directive to apply text formatting styles to an element.
 *
 * Usage:
 * ```html
 * <p [mosaikTextFormatter]="'richtext'" [mosaikTextFormatterValue]="'~Bold~ and _italic_'"></p>
 * ```
 *
 * @public
 */
export declare class TextFormatterDirective {
  private readonly _element;
  private readonly _renderer;
  private readonly _defaultFormatter;
  private readonly _formatterFn;
  private readonly _formattedText;
  constructor();
  /**
   * The text formatter to apply to the element's content.
   * Can be a function or the name of a predefined formatter.
   *
   * @public
   */
  readonly formatter: InputSignalWithTransform<TextFormatterFn | null, TextFormatter | null>;
  /**
   * The raw text value to format.
   * This should be used instead of placing content inside the element.
   *
   * @public
   */
  readonly value: InputSignal<string>;
  /**
   * Resolves a formatter from a string name or function.
   *
   * @private
   * @param value - The formatter to resolve.
   * @returns The resolved formatter function or null.
   */
  private resolveFormatter;
  static ɵfac: i0.ɵɵFactoryDeclaration<TextFormatterDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<TextFormatterDirective, "[mosaikTextFormatter]", never, {
    "formatter": {
      "alias": "mosaikTextFormatter";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "mosaikTextFormatterValue";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * @public
 */
export declare namespace TextFormatterDirective {
  type Props = {
    formatter: TextFormatter | null;
  };
}
/**
 * The injection token for providing default properties to the TextFormatterDirective.
 *
 * @public
 */
export declare const TEXT_FORMATTER_DEFAULT_PROPS: InjectionToken<Partial<TextFormatterDirective.Props>>;
/**
 * Provides default configuration for the TextFormatterDirective.
 *
 * @public
 * @param config - Partial configuration to apply as defaults.
 * @returns An EnvironmentProviders array to include in your module or component.
 */
export declare function provideTextFormatter(config: Partial<TextFormatterDirective.Props>): EnvironmentProviders;
/**
 * Typography Directive - A directive to apply typography styles to an element.
 *
 * @public
 */
export declare class TypographyDirective {
  private readonly _el;
  private readonly _renderer;
  private readonly _typography;
  private readonly _themeName;
  constructor();
  /**
   * Type of the typography style to apply (e.g., "headline", "body").
   */
  get typography(): string | undefined;
  set typography(type: string | undefined);
  /**
   * Optional theme name override. Falls back to `[document.documentElement].getAttribute('theme')`.
   */
  get themeName(): string | undefined;
  set themeName(value: string | undefined);
  static ɵfac: i0.ɵɵFactoryDeclaration<TypographyDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<TypographyDirective, "[mosaikTypography]", never, {
    "typography": {
      "alias": "mosaikTypography";
      "required": false;
    };
    "themeName": {
      "alias": "mosaikTypographyThemeName";
      "required": false;
    };
  }, {}, never, never, true, never>;
  static ngAcceptInputType_typography: string | undefined;
}
/**
 * Provides access to global DOM primitives in a testable way.
 *
 * Controllers often need `window` or `document` for observers and listeners.
 * This abstraction keeps global access centralized and replaceable in tests.
 *
 * @public
 */
interface IGlobalDomRef {
  /**
   * Returns the current `window` instance.
   *
   * @public
   */
  getWindow(): Window;
}
/**
 * Default implementation of {@link IGlobalDomRef}.
 *
 * @public
 */
export declare class GlobalDomRef implements IGlobalDomRef {
  private readonly _window;
  /**
   * Constructs a new instance of the {@link GlobalDomRef} class.
   *
   * @publicApi
   */
  constructor();
  /**
   * Returns the global `window` instance.
   *
   * @publicApi
   */
  getWindow(): Window;
  static ɵfac: i0.ɵɵFactoryDeclaration<GlobalDomRef, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * @public
 */
export declare function provideGlobalDom(): EnvironmentProviders;
/**
 * @public
 */
export declare function provideForms(): EnvironmentProviders;
/**
 * Represents a validation issue with a fully qualified control path.
 *
 * @public
 */
export interface IReactiveValidationIssue {
  /**
   * Dot/bracket path to the control, e.g. "address.street" or "items[0].name".
   * Empty string denotes group/array level issues at the current node.
   */
  path: string;
  /**
   * Angular validation errors object for this control/group/array.
   */
  errors: ValidationErrors;
}
/**
 * Hooks for reporting validation issues during form traversal.
 *
 * @public
 */
export interface IReactiveValidateHooks<TForm> {
  /**
   * Called once after traversal with all issues found.
   * Use this to build summaries or for aggregate decisions.
   *
   * @public
   * @param issues The array of all validation issues found.
   */
  onErrors?: (issues: Array<IReactiveValidationIssue>) => void;
  /**
   * Called during traversal for each individual issue.
   * Use this for per-field side effects (e.g., highlighting).
   *
   * @public
   * @param issue The validation issue found.
   */
  onEachError?: (issue: IReactiveValidationIssue) => void;
  /**
   * Called when no issues were found (i.e., the form is valid).
   *
   * @public
   * @param raw The raw form value (as returned by `formGroup.getRawValue()`).
   */
  onSuccess?: (raw: TForm) => void;
}
/**
 * Provides utilities to mark Angular forms (touched/pristine) and
 * to collect validation errors. Offers both classic and fluent APIs.
 *
 * Semantics:
 * - `collectErrors` is pure and never changes control state.
 * - `validate`/`pristine` can optionally report errors via callbacks
 *   in the same pass, without conflating "marking" with "causing" errors.
 *
 * @public
 * @deprecated Use `SignalFormValidator` instead for new development.
 */
export declare class ReactiveFormValidator {
  /**
   * Constructs a new instance of the `FormValidator` class.
   *
   * @public
   */
  constructor();
  /**
   * Marks each control as touched and optionally reports validation issues.
   *
   * @public
   * @template TGroup The specific type of the form group (for typed raw value).
   * @param formGroup The form group to validate.
   * @param hooks Optional validation reporting callbacks.
   * @returns The raw form value (as returned by `formGroup.getRawValue()`).
   */
  validate<TGroup extends FormGroup>(formGroup: TGroup, hooks?: IReactiveValidateHooks<ReturnType<TGroup['getRawValue']>>): void;
  /**
   * Marks each control as pristine and optionally reports validation issues.
   *
   * @public
   * @template TGroup The specific type of the form group (for typed raw value).
   * @param formGroup The form group to mark as pristine.
   * @param hooks Optional validation reporting callbacks.
   * @returns The raw form value (as returned by `formGroup.getRawValue()`).
   */
  pristine<TGroup extends FormGroup>(formGroup: TGroup, hooks?: IReactiveValidateHooks<ReturnType<TGroup['getRawValue']>>): void;
  /**
   * Collects all validation issues without mutating any control state.
   *
   * @public
   * @param formGroup The form group to inspect.
   * @returns An array of validation issues.
   */
  collectErrors(formGroup: FormGroup): Array<IReactiveValidationIssue>;
  /**
   * Indicates whether the form is currently valid (pure check).
   *
   * @public
   * @param formGroup The form group to inspect.
   * @returns `true` if no validation issues were found; `false` otherwise.
   */
  isValid(formGroup: FormGroup): boolean;
  /**
   * Builds a map from control path to its errors for quick lookup.
   *
   * @public
   * @param issues The array of validation issues to convert.
   * @returns A map from control path to its validation errors.
   */
  toPathMap(issues: Array<IReactiveValidationIssue>): Record<string, ValidationErrors>;
  /**
   * Starts a fluent validation session.
   *
   * @public
   * @param formGroup The form group to validate.
   * @returns A new `ValidationSession` instance.
   */
  session(formGroup: FormGroup): ReactiveValidationSession;
  /**
   * Internal traversal utility: can mutate state (via `onControl`) and
   * collect/report issues (via `onErrors`) in a single pass.
   *
   * @private
   */
  private traverse;
  static ɵfac: i0.ɵɵFactoryDeclaration<ReactiveFormValidator, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * Fluent validation session with chainable steps.
 *
 * @public
 */
export declare class ReactiveValidationSession {
  private readonly _validator;
  private readonly _root;
  private _touch;
  private _pristine;
  private _onErrors?;
  private _onEachError?;
  private _onSuccess?;
  /**
   * Constructs a new `ValidationSession`.
   *
   * @public
   */
  constructor(validator: ReactiveFormValidator, root: FormGroup);
  /**
   * Mark all controls as touched.
   *
   * @public
   * @returns This validation session (for chaining).
   */
  touch(): this;
  /**
   * Mark all controls as pristine.
   *
   * @public
   * @returns This validation session (for chaining).
   */
  pristine(): this;
  /**
   * Provide a per-issue callback invoked during traversal.
   *
   * @public
   * @param cb The callback to invoke for each issue found.
   * @returns This validation session (for chaining).
   */
  onEachError(cb: (issue: IReactiveValidationIssue) => void): this;
  /**
   * Provide a single callback to receive all issues after traversal.
   *
   * @public
   * @param cb The callback to invoke with all issues found.
   * @returns This validation session (for chaining).
   */
  onErrors(cb: (issues: Array<IReactiveValidationIssue>) => void): this;
  /**
   * Provide a callback that fires when no issues are found.
   *
   * @public
   * @param cb The callback to invoke on success.
   * @returns This validation session (for chaining).
   */
  onSuccess(cb: () => void): this;
  /**
   * Executes the session. Uses single-pass fast paths where possible.
   *
   * @public
   */
  run(): void;
}
/**
 * Represents a validation issue with a fully qualified field path.
 *
 * @public
 */
export interface ISignalValidationIssue {
  /**
   * Dot/bracket path to the field or group, e.g. "address.street" or "items[0].name".
   * An empty string denotes issues at the root level.
   */
  path: string;
  /**
   * Array of error objects returned by the field’s `errors()` signal.
   */
  errors: Array<unknown>;
  /**
   * Optional reference to the underlying FieldState object for further inspection.
   */
  fieldRef?: FieldState<unknown>;
}
/**
 * Hooks for reporting validation issues during form traversal.
 *
 * @public
 */
export interface ISignalValidateHooks<TForm> {
  /**
   * Called during traversal for **each individual issue found**.
   *
   * @param issue The validation issue identified.
   */
  onEachError?: (issue: ISignalValidationIssue) => void;
  /**
   * Called once **after traversal**, with all issues collected.
   *
   * @param issues The array of all validation issues found.
   */
  onErrors?: (issues: Array<ISignalValidationIssue>) => void;
  /**
   * Called when **no issues were found** (i.e., the form is valid).
   *
   * @param raw The raw form value (as returned by the form’s `value`).
   */
  onSuccess?: (raw: TForm) => void;
}
/**
 * Utility class to perform structured validation over a form model created
 * via `@angular/forms/signals`. Provides collection of issues, fluent builders and hook-based callbacks.
 *
 * @public
 */
export declare class SignalFormValidator {
  /**
   * Traverses the form tree, collects validation issues, and triggers the
   * provided hooks accordingly.
   *
   * Afterwards, the form fields are marked as touched.
   * To set the touched state is necessary to ensure that any UI components display validation feedback.
   *
   * @template TForm The type of the form’s value model.
   * @param form   The root FieldTree object representing the form.
   * @param hooks  Optional callbacks for reporting errors or success.
   */
  validate<TForm>(form: FieldTree<TForm>, hooks?: ISignalValidateHooks<TForm>): void;
  /**
   * Collects all validation issues without triggering any callbacks.
   *
   * @template TForm The type of the form’s value model.
   * @param form The root FieldTree object representing the form.
   * @returns An array of validation issues.
   */
  collectErrors<TForm>(form: FieldTree<TForm>): Array<ISignalValidationIssue>;
  /**
   * Checks whether the form is currently valid (i.e., no issues found).
   *
   * @template TForm The type of the form’s value model.
   * @param form The root FieldTree object representing the form.
   * @returns `true` if valid, `false` otherwise.
   */
  isValid<TForm>(form: FieldTree<TForm>): boolean;
  /**
   * Creates a fluent validation builder for the given form.
   *
   * @template TForm The type of the form’s value model.
   * @param form The root FieldTree object representing the form.
   * @returns A `ValidationBuilder` instance with chainable methods.
   */
  build<TForm>(form: FieldTree<TForm>): SignalValidationBuilder<TForm>;
  /**
   * Internal traversal utility: walks the form tree recursively, invoking the callback
   * for each leaf or nested field state.
   *
   * @private
   * @template T The part of the model at the current node.
   * @param tree        The callable FieldTree at the current node.
   * @param currentPath The accumulated path string so far.
   * @param callback    The function to call for each field node.
   */
  private traverse;
  static ɵfac: i0.ɵɵFactoryDeclaration<SignalFormValidator, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * Fluent validation builder with chainable methods.
 *
 * @public
 */
export declare class SignalValidationBuilder<TForm> {
  private readonly _validator;
  private readonly _form;
  private _onEachError?;
  private _onErrors?;
  private _onSuccess?;
  /**
   * Constructs a new instance.
   *
   * @param validator The SignalFormValidator instance to use.
   * @param form The root FieldTree object representing the form.
   */
  constructor(validator: SignalFormValidator, form: FieldTree<TForm>);
  /**
   * Provide a callback to be invoked on each validation error.
   *
   * @param cb The callback function.
   * @returns This builder for chaining.
   */
  onEachError(cb: (issue: ISignalValidationIssue) => void): this;
  /**
   * Provide a callback to be invoked once after traversal with all issues.
   *
   * @param cb The callback function.
   * @returns This builder for chaining.
   */
  onErrors(cb: (issues: Array<ISignalValidationIssue>) => void): this;
  /**
   * Provide a callback to be invoked when no errors were found.
   *
   * @param cb The callback function.
   * @returns This builder for chaining.
   */
  onSuccess(cb: (raw: TForm) => void): this;
  /**
   * Executes the validation builder: runs validation and triggers configured callbacks.
   *
   * @public
   */
  run(): void;
}
/**
 * @public
 * @deprecated Use `SignalFormValidator` instead for new development.
 */
export declare class Validators {
  /**
   * Validator to check if control value is only numeric.
   *
   * Errors:
   * * numeric
   * * actualValue
   *
   * @public
   * @static
   */
  static numeric(): ValidatorFn;
  /**
   * Validator to check the quality between two controls.
   *
   * Errors:
   * * equalsTo
   * * actualValue
   *
   * @public
   * @static
   */
  static equalsTo<T>(other: T | (() => T)): ValidatorFn;
  /**
   * Validator to check if control value is blank string.
   *
   * Errors:
   * *blank
   *
   * @public
   * @static
   */
  static blank(): ValidatorFn;
  /**
   * Validator to check a email with an exact domains.
   *
   * Errors:
   * * emailEndsWithDomain
   *
   * @public
   * @static
   */
  static emailEndsWithDomain(domains: Array<string>): ValidatorFn;
  /**
   * Validator to check a phone number.
   *
   * Errors:
   * * phoneNumber
   *
   * @public
   * @static
   */
  static phoneNumber(): ValidatorFn;
}
/**
 * Validator configuration for validators.
 *
 * @private
 */
type ValidatorConfig<TValue, TPathKind extends PathKind = PathKind.Root> = {
  /** A user-facing error message to include with the error. */
  message?: string | LogicFn<TValue, string, TPathKind>;
  error?: never;
} | {
  /**
   * Custom validation error(s) to report instead of the default,
   * or a function that receives the `FieldContext` and returns custom validation error(s).
   */
  error?: OneOrMany<ValidationError> | LogicFn<TValue, OneOrMany<ValidationError>, TPathKind>;
  message?: never;
};
/**
 * Date value or date-producing logic used by date validators.
 *
 * @private
 */
type DateValidationReference<TPathKind extends PathKind = PathKind.Root> = Date | null | undefined | LogicFn<Date | null, Date | null | undefined, TPathKind>;
/**
 * Validator error for numeric validation.
 *
 * @public
 */
export interface INumericValidationError extends ValidationError {
  kind: 'numeric';
  actualValue: any;
}
/**
 * Validator to check if control value is only numeric.
 *
 * @param path The schema path to validate.
 * @public
 */
export declare function numeric<TPathKind extends PathKind = PathKind.Root>(path: SchemaPath<unknown, SchemaPathRules.Supported, TPathKind>, config?: ValidatorConfig<unknown, TPathKind>): void;
/**
 * Validator error for equalsTo validation.
 *
 * @public
 */
export interface IEqualsToValidationError<T = any> extends ValidationError {
  kind: 'equalsTo';
  actualValue: any;
  other: T;
}
/**
 * Validator to check the equality between control value and another.
 *
 * @param path The schema path to validate.
 * @param other A value or getter function returning the other value.
 * @public
 */
export declare function equalsTo<T, TPathKind extends PathKind = PathKind.Root>(path: SchemaPath<unknown, SchemaPathRules.Supported, TPathKind>, other: T | (() => T), config?: ValidatorConfig<unknown, TPathKind>): void;
/**
 * Validator error for dateNotBefore validation.
 *
 * @public
 */
export interface IDateNotBeforeValidationError extends ValidationError {
  kind: 'dateNotBefore';
  actualValue: Date;
  minDate: Date;
}
/**
 * Validator to check if a date is not before another date.
 *
 * @param path The schema path to validate.
 * @param minDate The earliest allowed date or logic that returns it.
 * @public
 */
export declare function dateNotBefore<TPathKind extends PathKind = PathKind.Root>(path: SchemaPath<Date | null, SchemaPathRules.Supported, TPathKind>, minDate: DateValidationReference<TPathKind>, config?: ValidatorConfig<Date | null, TPathKind>): void;
/**
 * Validator error for dateNotAfter validation.
 *
 * @public
 */
export interface IDateNotAfterValidationError extends ValidationError {
  kind: 'dateNotAfter';
  actualValue: Date;
  maxDate: Date;
}
/**
 * Validator to check if a date is not after another date.
 *
 * @param path The schema path to validate.
 * @param maxDate The latest allowed date or logic that returns it.
 * @public
 */
export declare function dateNotAfter<TPathKind extends PathKind = PathKind.Root>(path: SchemaPath<Date | null, SchemaPathRules.Supported, TPathKind>, maxDate: DateValidationReference<TPathKind>, config?: ValidatorConfig<Date | null, TPathKind>): void;
/**
 * Validator error for blank string validation.
 *
 * @public
 */
export interface IBlankValidationError extends ValidationError {
  kind: 'blank';
  actualValue: any;
}
/**
 * Validator to check if control value is blank (contains whitespace).
 *
 * @param path The schema path to validate.
 * @public
 */
export declare function blank<TPathKind extends PathKind = PathKind.Root>(path: SchemaPath<unknown, SchemaPathRules.Supported, TPathKind>, config?: ValidatorConfig<unknown, TPathKind>): void;
/**
 * Validator error for emailEndsWithDomain validation.
 *
 * @public
 */
export interface IEmailEndsWithDomainValidationError extends ValidationError {
  kind: 'emailEndsWithDomain';
  requiredDomains: Array<string>;
  actualValue: string;
}
/**
 * Validator to check that an email ends with one of the given domains.
 *
 * @param path The schema path to validate.
 * @param domains The list of allowed domains.
 * @public
 */
export declare function emailEndsWithDomain<TPathKind extends PathKind = PathKind.Root>(path: SchemaPath<string, SchemaPathRules.Supported, TPathKind>, domains: Array<string>, config?: ValidatorConfig<string, TPathKind>): void;
/**
 * Validator error for phoneNumber validation.
 *
 * @public
 */
export interface IPhoneNumberValidationError extends ValidationError {
  kind: 'phoneNumber';
  actualValue: string;
}
/**
 * Validator to check if value is a phone number in allowed format.
 *
 * @param path The schema path to validate.
 * @public
 */
export declare function phoneNumber<TPathKind extends PathKind = PathKind.Root>(path: SchemaPath<string, SchemaPathRules.Supported, TPathKind>, config?: ValidatorConfig<string, TPathKind>): void;
/**
 * Compatibility binding for the former `name` input of `mosaik-icon`.
 *
 * @deprecated Bind the registered icon name through the `icon` input instead.
 * @public
 */
export declare class IconDirective implements OnChanges {
  private readonly _element;
  /**
   * The registered icon name.
   *
   * @public
   */
  name?: string;
  /**
   * @public
   */
  ngOnChanges(changes: SimpleChanges): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<IconDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<IconDirective, "mosaik-icon[name]", never, {
    "name": {
      "alias": "name";
      "required": false;
    };
  }, {}, never, never, true, never>;
}
/**
 * Compatibility binding for components that formerly exposed `iconName`.
 *
 * @deprecated Bind the registered icon name through the component's `icon` input instead.
 * @public
 */
export declare class IconNameDirective implements OnChanges {
  private readonly _element;
  /**
   * The registered icon name.
   *
   * @public
   */
  iconName?: string;
  /**
   * @public
   */
  ngOnChanges(changes: SimpleChanges): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<IconNameDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<IconNameDirective, "        mosaik-avatar[iconName],        mosaik-badge[iconName],        mosaik-banner[iconName],        mosaik-busy-state[iconName],        mosaik-button[iconName],        mosaik-chat-marker[iconName],        mosaik-chat-message-avatar[iconName],        mosaik-chip[iconName],        mosaik-choice[iconName],        mosaik-combo-item[iconName],        mosaik-compound-button[iconName],        mosaik-dropdown-button[iconName],        mosaik-empty-state[iconName],        mosaik-error-state[iconName],        mosaik-expander[iconName],        mosaik-fab-group[iconName],        mosaik-fab[iconName],        mosaik-icon[iconName],        mosaik-menu-item[iconName],        mosaik-message-box[iconName],        mosaik-message[iconName],        mosaik-persona[iconName],        mosaik-pip[iconName],        mosaik-press-button[iconName],        mosaik-repeat-button[iconName],        mosaik-ribbon[iconName],        mosaik-segment-item[iconName],        mosaik-select-item[iconName],        mosaik-sheet[iconName],        mosaik-split-button[iconName],        mosaik-stepper-item[iconName],        mosaik-success-state[iconName],        mosaik-tab-item[iconName],        mosaik-tab-strip-item[iconName],        mosaik-timeline-marker[iconName],        mosaik-titlebar[iconName],        mosaik-toast[iconName],        mosaik-toggle-button[iconName],        mosaik-updown-spinner[iconName]    ", never, {
    "iconName": {
      "alias": "iconName";
      "required": false;
    };
  }, {}, never, never, true, never>;
}
/**
 * Resolves a registered icon name to a renderable icon source.
 *
 * @deprecated Pass the registered name directly to icon-capable Mosaik components.
 * @public
 */
export declare class IconPipe implements PipeTransform {
  private readonly _registry;
  /**
   * @public
   */
  transform(value: string | null | undefined): string;
  static ɵfac: i0.ɵɵFactoryDeclaration<IconPipe, never>;
  static ɵpipe: i0.ɵɵPipeDeclaration<IconPipe, "icon", true>;
}
/**
 * The Angular facade over the framework neutral icon registry.
 *
 * There is exactly one registry, owned by `@pixel-brewery/mosaik-icons` and shared by
 * the application, Foundation and Angular through a peer dependency. This class makes
 * that registry injectable; it holds no state of its own.
 *
 * @public
 */
export declare class IconRegistry {
  /**
   * Gets the names of all registered sets.
   *
   * @public
   * @readonly
   */
  get sets(): Array<string>;
  /**
   * Gets the set that unprefixed names resolve against.
   *
   * @public
   */
  get defaultSet(): string;
  /**
   * Registers a set of icons with the registry.
   *
   * @param icons A map of icon name to source.
   * @public
   */
  register(icons: IconInput): void;
  /**
   * Registers icons under a set name, addressable as `set:name`.
   *
   * @param set The set name.
   * @param icons A map of icon name to source.
   * @public
   */
  registerSet(set: string, icons: IconInput): void;
  /**
   * Points every unprefixed name at a set. Every mounted icon re-resolves.
   *
   * @param set The set name.
   * @public
   */
  setDefaultSet(set: string): void;
  /**
   * Installs a resolver for names that are not registered.
   *
   * @param loader The resolver, or `null` to remove the current one.
   * @public
   */
  setLoader(loader: IconLoader | null): void;
  /**
   * Resolves an icon name to a definition.
   *
   * Returns `null` for an unknown name rather than throwing - a typo in one icon
   * must not take a whole view down.
   *
   * @param name The icon name, with or without a set prefix.
   * @public
   */
  resolve(name: string): IIconDefinition | null;
  /**
   * Resolves a registered icon to its renderable body.
   *
   * @deprecated Pass the registered icon name to icon-capable components or use `resolve()`.
   * @param name The registered icon name.
   * @returns The sanitized SVG body.
   * @throws When the name is empty or not registered.
   * @public
   */
  get(name: string): string;
  /**
   * Subscribes to registry changes. The returned function removes the subscription.
   *
   * @param listener The callback invoked after every change.
   * @public
   */
  subscribe(listener: () => void): () => void;
  static ɵfac: i0.ɵɵFactoryDeclaration<IconRegistry, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * Registers icon definitions in the application's active default set.
 *
 * Foundation registers no icon set. A host application must either register every
 * semantic alias it uses with this provider or install a complete preset with
 * `provideIconSet` and `provideDefaultIconSet`.
 *
 * @param icons A map of icon name to source.
 * @public
 *
 * @example
 * ```ts
 * import { provideIcons } from '@pixel-brewery/mosaik-elements-angular';
 * import { lucideCalendar } from '@pixel-brewery/mosaik-icons/lucide';
 *
 * export const appConfig: ApplicationConfig = {
 *     providers: [provideIcons({ calendar: lucideCalendar })]
 * };
 * ```
 *
 * @example
 * ```ts
 * // A single icon from the library's own package, fully tree shaken.
 * import { Calendar } from 'lucide';
 * import { fromNodes, LucideDefaults } from '@pixel-brewery/mosaik-icons';
 *
 * provideIcons({ calendar: fromNodes(Calendar, LucideDefaults)! });
 * ```
 */
export declare function provideIcons(icons: IconInput$1): EnvironmentProviders;
/**
 * Registers application icons through the shared icon registry.
 *
 * @deprecated Use `provideIcons()`.
 * @param config The legacy icon provider configuration.
 * @returns Angular environment providers.
 * @public
 */
export declare function provideIconRegistry(config?: {
  icons: IconInput$1;
}): EnvironmentProviders;
/**
 * Registers icons under a set name, so that they can be addressed as `set:name`
 * and switched to wholesale with `provideDefaultIconSet` or at runtime.
 *
 * @param set The set name.
 * @param icons A map of icon name to source.
 * @public
 *
 * @example
 * ```ts
 * import { LucideAliases } from '@pixel-brewery/mosaik-elements-foundation/icons/lucide';
 * import { TablerIconsAliases } from '@pixel-brewery/mosaik-elements-foundation/icons/tabler-icons';
 *
 * providers: [
 *     provideIconSet('lucide', LucideAliases),
 *     provideIconSet('tabler', TablerIconsAliases),
 *     provideDefaultIconSet('lucide')
 * ]
 * ```
 */
export declare function provideIconSet(set: string, icons: IconInput$1): EnvironmentProviders;
/**
 * Points every unprefixed icon name at a registered set.
 *
 * @param set The set name.
 * @public
 */
export declare function provideDefaultIconSet(set: string): EnvironmentProviders;
/**
 * Installs a resolver for names that are not registered, for the cases where
 * registering a whole set up front is not sensible - an icon picker, a gallery,
 * or icons chosen by data rather than by a template.
 *
 * @param loader The resolver.
 * @public
 *
 * @example
 * ```ts
 * provideIconLoader(async (name) => {
 *     const response = await fetch(`/icons/${name}.svg`);
 *     return response.ok ? response.text() : null;
 * });
 * ```
 */
export declare function provideIconLoader(loader: IconLoader$1): EnvironmentProviders;
/**
 * Applies Angular's configured locale to locale-aware Mosaik elements.
 *
 * @public
 */
export declare class LocaleDirective {
  private readonly _destroyRef;
  private readonly _elementRef;
  private readonly _fallbackLocale;
  private readonly _translateService;
  /**
   * Constructs a new instance of the `LocaleDirective` class.
   *
   * @public
   */
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<LocaleDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<LocaleDirective, "        mosaik-calendar,        mosaik-calendar-days-view,        mosaik-calendar-months-view,        mosaik-calendar-years-view,        mosaik-datebox,        mosaik-datetimebox,        mosaik-epg,        mosaik-epg-channel,        mosaik-epg-program,        mosaik-epg-timeline,        mosaik-scheduler,        mosaik-scheduler-agenda-view,        mosaik-scheduler-datescale,        mosaik-scheduler-month-view,        mosaik-scheduler-time-grid-view,        mosaik-scheduler-timescale,        mosaik-timebox    ", never, {}, {}, never, never, true, never>;
}
/**
 * Projects arbitrary Angular content into the Prompt Box content region.
 *
 * @public
 */
export declare class PromptBoxContentDirective {
  /**
   * Constructs a Prompt Box content directive.
   *
   * @public
   */
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<PromptBoxContentDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<PromptBoxContentDirective, "[mosaikPromptBoxContent]", never, {}, {}, never, never, true, never>;
}
/**
 * Exposes the native Prompt Box API to composed Angular content.
 *
 * @example
 * ```html
 * <mosaik-chat-prompt-box mosaikPromptBox #promptBox="mosaikPromptBox">
 *   <app-task-reference mosaikPromptBoxContent />
 * </mosaik-chat-prompt-box>
 * ```
 *
 * @public
 */
export declare class PromptBoxDirective {
  private readonly _elementRef;
  /**
   * Constructs a Prompt Box directive.
   *
   * @public
   */
  constructor();
  /**
   * Gets the complete native Prompt Box API.
   *
   * @public
   * @readonly
   */
  get element(): PromptBoxBaseElement;
  static ɵfac: i0.ɵɵFactoryDeclaration<PromptBoxDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<PromptBoxDirective, "mosaik-prompt-box[mosaikPromptBox], mosaik-chat-prompt-box[mosaikPromptBox]", ["mosaikPromptBox"], {}, {}, never, never, true, never>;
}
/**
 * Provides the native Prompt Box to Angular content and tool directives.
 *
 * @public
 */
export declare const PROMPT_BOX: InjectionToken<PromptBoxBaseElement>;
/**
 * Registers an Angular object or tool custom element with its parent Prompt Box.
 *
 * Passing a tool object supports Angular components and services. When the
 * directive is used without a value, its native host must implement
 * `IPromptBoxTool`.
 *
 * @example
 * ```html
 * <button [mosaikPromptBoxTool]="taskPicker">Pick task</button>
 * <mosaik-prompt-box-attachment-tool mosaikPromptBoxTool />
 * ```
 *
 * @public
 */
export declare class PromptBoxToolDirective implements OnChanges, OnDestroy {
  private readonly _changeDetectorRef;
  private readonly _elementRef;
  private readonly _onPromptBoxStateChanged;
  private readonly _promptBox;
  private readonly _renderer;
  private _registeredTool?;
  private _unregister?;
  /**
   * Constructs a Prompt Box tool directive.
   *
   * @public
   */
  constructor();
  /**
   * Gets or sets the Angular tool object. A missing value falls back to the host element.
   *
   * @public
   */
  tool?: IPromptBoxTool | '';
  /**
   * Gets the effective disabled state applied to an Angular tool host.
   *
   * @public
   */
  get hostDisabled(): boolean;
  /**
   * Updates the Prompt Box registration when the supplied tool changes.
   *
   * @public
   */
  ngOnChanges(_changes: SimpleChanges): void;
  /**
   * Removes the Prompt Box registration.
   *
   * @public
   */
  ngOnDestroy(): void;
  /**
   * Determines whether a value implements the Prompt Box tool contract.
   *
   * @private
   */
  private isPromptBoxTool;
  static ɵfac: i0.ɵɵFactoryDeclaration<PromptBoxToolDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<PromptBoxToolDirective, "[mosaikPromptBoxTool]", never, {
    "tool": {
      "alias": "mosaikPromptBoxTool";
      "required": false;
    };
  }, {}, never, never, true, never>;
}
/**
 * Represents a size-like object with width and height properties.
 *
 *  @public
 */
interface ISizeLike {
  /**
   * The width of the size.
   *
   * @public
   */
  width: CssLength;
  /**
   * The height of the size.
   *
   * @public
   */
  height: CssLength;
}
/**
 * Represents the interaction that initiated a portal close attempt.
 *
 * @public
 */
type PortalCloseAttemptTrigger = 'outside' | 'escape';
/**
 * Represents a cancellable portal close attempt.
 *
 * @public
 */
interface IPortalCloseAttempt {
  /**
   * Returns the interaction that attempted to close the portal.
   *
   * @public
   * @readonly
   */
  readonly trigger: PortalCloseAttemptTrigger;
  /**
   * Returns whether closing was prevented.
   *
   * @public
   * @readonly
   */
  readonly closePrevented: boolean;
  /**
   * Prevents the portal from closing for this close attempt.
   *
   * @public
   */
  preventClose(): void;
}
/**
 * Default implementation of a cancellable portal close attempt.
 *
 * @public
 */
export declare class PortalCloseAttempt implements IPortalCloseAttempt {
  private readonly _trigger;
  private _closePrevented;
  /**
   * Constructs a new instance of the `PortalCloseAttempt` class.
   *
   * @public
   * @param trigger - Interaction that attempted to close the portal.
   */
  constructor(trigger: PortalCloseAttemptTrigger);
  /**
   * Returns the interaction that attempted to close the portal.
   *
   * @public
   * @readonly
   */
  get trigger(): PortalCloseAttemptTrigger;
  /**
   * Returns whether closing was prevented.
   *
   * @public
   * @readonly
   */
  get closePrevented(): boolean;
  /**
   * Prevents the portal from closing for this close attempt.
   *
   * @public
   */
  preventClose(): void;
}
/**
 * @public
 */
interface IPortalRef<TInstance, TData, TResult> {
  readonly id: string;
  readonly component: TInstance;
  readonly overlayRef: OverlayRef;
  readonly data?: TData;
  readonly closed: Observable<ICancel<TResult>>;
  /**
   * Emits before an implicit outside or escape close attempt is executed.
   *
   * @public
   * @readonly
   */
  readonly closeAttempted: Observable<IPortalCloseAttempt>;
  close(result?: ICancel<TResult>): void;
  /**
   * Requests visual attention for the portal content without closing it.
   *
   * @public
   * @param animation - Optional animation used for this attention request.
   */
  requestAttention(animation?: IAnimationReferenceMetadata | null): Promise<boolean>;
}
/**
 * Represents the `IDialogRef` interface.
 *
 * @public
 */
interface IDialogRef<TData = unknown, TResult = unknown> extends IPortalRef<DialogComponent, TData, TResult> {
  /**
   * Returns the underlying `DialogElement`.
   *
   * @public
   * @readonly
   */
  get element(): DialogElement;
  get positionChanged(): Observable<Partial<{
    top: number | string;
    bottom: number | string;
    left: number | string;
    right: number | string;
  }>>;
  get sizeChanged(): Observable<Partial<{
    width: number | string;
    height: number | string;
  }>>;
  updatePosition(position: Partial<{
    top: number | string;
    bottom: number | string;
    left: number | string;
    right: number | string;
  }>): this;
  updateSize(size: Partial<{
    width: number | string;
    height: number | string;
  }>): this;
}
/**
 * Represents a reactive value that can be of type T, Observable<T>, or Signal<T>.
 *
 * @public
 * @template T - The type of the value.
 */
type ReactiveValue<T> = T | Observable<T> | Signal<T>;
/**
 * Configures how Angular CDK backdrops are created for overlay stacks.
 *
 * @public
 */
interface IOverlayBackdropConfig {
  /**
   * Controls whether consecutive overlays in the same stack share one backdrop.
   *
   * Use `own` when every overlay with `hasBackdrop` should create its own
   * backdrop. Use `shared` to create a backdrop only for the first overlay in a
   * consecutive stack segment.
   *
   * @default 'shared'
   */
  backdropStrategy?: 'own' | 'shared';
}
/**
 * Represents the `IDialogConfig` interface.
 *
 * @public
 */
interface IDialogConfig<TData = unknown> extends Omit<DialogElement.Props, 'header' | 'subheader' | 'isOpen' | 'width' | 'height'>, IOverlayBackdropConfig {
  /**
   * The data passed to the dialog.
   */
  data?: TData;
  size?: Partial<ISizeLike>;
  minSize?: Partial<ISizeLike>;
  maxSize?: Partial<ISizeLike>;
  header?: ReactiveValue<string>;
  subheader?: ReactiveValue<string>;
  actions?: Array<{
    kind?: Extract<Variant, 'primary' | 'secondary'>;
    handler?: () => void;
    label?: ReactiveValue<string>;
    disabled?: ReactiveValue<boolean>;
    visible?: ReactiveValue<boolean>;
  }>;
  id?: string;
  /**
   * Determines whether the dialog is disabled.
   *
   * @default false
   */
  disabled?: boolean;
  /**
   * Determines whether the dialog should focus on open.
   *
   * @default true
   */
  focusOnOpen?: boolean;
  /**
   * Determines whether the dialog should be scrollable.
   *
   * @default false
   */
  scrollable?: boolean;
  /**
   * Determines whether the dialog should close when navigation occurs.
   *
   * @default false
   */
  closeOnNavigation?: boolean;
  /**
   * Detects if only showing one dialog at the same time.
   *
   * @default false
   */
  singleton?: boolean;
}
/**
 * @public
 */
interface IPortalProviderBehavior<TRef, TConfig> {
  /**
   * Configures the behavior with specific configuration.
   *
   * @public
   * @param config - The configuration to apply.
   */
  configure(config: TConfig): void;
  /**
   * Attaches a specific portal reference to the behavior.
   *
   * @public
   * @param ref - The reference to attach.
   * @param portal - The component portal for the reference.
   */
  attach(element: TRef, portal: ComponentPortal<unknown>): void;
  /**
   * Detaches a specific portal reference from the behavior.
   * If ref is not provided, detaches the most recently attached reference.
   *
   * @public
   * @param ref - Optional reference to detach. If omitted, detaches the last attached.
   */
  detach(ref?: TRef): void;
}
/**
 * @public
 */
interface IDialogBehavior extends Omit<IPortalProviderBehavior<IDialogRef, Partial<IDialogConfig>>, 'detach'> {
  /**
   * Detaches a specific dialog from the behavior.
   * If ref is not provided, detaches the most recently attached dialog.
   *
   * @public
   * @param ref - Optional dialog reference to detach.
   */
  detach(ref?: IDialogRef): void;
}
/**
 * @public
 * @abstract
 */
declare abstract class DialogBehavior implements IDialogBehavior {
  private _ref;
  private _attached;
  private _dialogConfig;
  /**
   * Constructs a new instance of the `DialogBehavior` class.
   *
   * @protected
   */
  protected constructor();
  /**
   * Returns the `ref` property.
   *
   * @public
   * @readonly
   */
  get ref(): Nullable<IDialogRef>;
  /**
   * Returns the `config` property.
   *
   * @public
   * @readonly
   */
  get config(): Nullable<IDialogConfig>;
  /**
   * @public
   * @virtual
   */
  configure(config: IDialogConfig): void;
  /**
   * @public
   * @virtual
   */
  attach(element: IDialogRef, _portal: ComponentPortal<unknown>): void;
  /**
   * Detaches a specific dialog from the behavior.
   * If ref is not provided, detaches the most recently attached dialog.
   *
   * @public
   * @virtual
   * @param ref - Optional dialog reference to detach.
   */
  detach(ref?: IDialogRef): void;
}
/**
 * @public
 */
interface IDialogBreakpointBehaviorConfig {
  breakpoints: Array<{
    breakpoint: BreakpointAlias;
    size: ISizeLike;
  }>;
}
/**
 * Injection token for providing dialog breakpoint behavior configuration.
 *
 * @public
 */
export declare const DIALOG_BREAKPOINT_BEHAVIOR_CONFIG: InjectionToken<IDialogBreakpointBehaviorConfig>;
/**
 * Behavior that adjusts dialog size based on viewport breakpoints.
 *
 * @public
 */
export declare class DialogBreakpointBehavior extends DialogBehavior {
  private readonly _breakpointObserver;
  private readonly _breakpointRegistry;
  private readonly _config;
  private readonly _mediaQueryToAliasMap;
  private _subscription;
  /**
   * Constructs a new instance of the `DialogBreakpointBehavior` class.
   *
   * @public
   */
  constructor(config?: IDialogBreakpointBehaviorConfig | null);
  /**
   * Attaches a specific dialog to the behavior.
   *
   * @public
   * @override
   * @param dialogRef - The dialog reference to attach to the behavior.
   * @param portal - The component portal for the dialog content (unused in this behavior).
   */
  attach(dialogRef: IDialogRef, _portal: ComponentPortal<unknown>): void;
  /**
   * Detaches a specific dialog from the behavior.
   * If ref is not provided, detaches the most recently attached dialog.
   *
   * @public
   * @override
   * @param ref - Optional dialog reference to detach (unused in this behavior).
   */
  detach(_ref?: IDialogRef): void;
  /**
   * Handles breakpoint state changes and updates dialog size accordingly.
   *
   * @private
   * @param state - The current breakpoint state from the observer.
   * @param dialogRef - Reference to the dialog being managed.
   * @param config - Optional dialog configuration with default size values.
   */
  private onBreakpoint;
}
/**
 * Injection token for providing dialog stack behavior configuration.
 *
 * @public
 */
export declare const DIALOG_STACK_BEHAVIOR_CONFIG: InjectionToken<IDialogStackBehaviorConfig>;
/**
 * Behavior that manages a stack of dialogs with offset-based positioning.
 *
 * The stacking model:
 * - The topmost (newest) dialog remains centered
 * - Each dialog behind it is offset upward, creating a cascading visual effect
 * - The offset allows users to see that there are dialogs stacked beneath
 *
 * @public
 */
export declare class DialogStackBehavior extends DialogBehavior {
  private readonly _stack;
  private readonly _config;
  /**
   * Constructs a new instance of the `DialogStackBehavior` class.
   *
   * @public
   */
  constructor(config?: IDialogStackBehaviorConfig | null);
  /**
   * Returns the current number of dialogs in the stack.
   *
   * @public
   * @readonly
   */
  get stackSize(): number;
  /**
   * Returns the current stack configuration.
   *
   * @public
   * @readonly
   */
  get stackConfig(): Readonly<IDialogStackBehaviorConfig>;
  /**
   * Attaches a dialog to the stack and applies stack styling.
   *
   * The new dialog is always centered (no offset).
   * Existing dialogs are pushed back and offset upward.
   *
   * @public
   * @param dialogRef - The dialog reference to attach.
   * @param portal - The component portal for the dialog.
   */
  attach(dialogRef: IDialogRef, portal: ComponentPortal<unknown>): void;
  /**
   * Detaches a specific dialog from the stack, or the topmost if not specified.
   * When a dialog in the middle of the stack is removed, all remaining dialogs
   * are recalculated to maintain proper stacking order.
   *
   * @public
   * @override
   * @param ref - Optional dialog reference to detach. If omitted, detaches the topmost dialog.
   */
  detach(ref?: IDialogRef): void;
  /**
   * Calculates the z-index for a dialog at the given stack level.
   *
   * @private
   * @param stackLevel - The zero-based index of the dialog in the stack.
   * @returns The calculated z-index value.
   */
  private calculateZIndex;
  /**
   * Calculates the vertical offset for a dialog based on its distance from the top.
   *
   * @private
   * @param offsetFromTop - Number of dialogs above this one.
   * @returns The calculated offset in pixels (negative for upward movement).
   */
  private calculateOffset;
  /**
   * Applies stack-related CSS variables to a dialog element.
   * Uses requestAnimationFrame to ensure CSS transitions are properly triggered.
   *
   * @private
   * @param dialogRef - The dialog reference containing the element.
   * @param stackLevel - The stack level for this dialog.
   * @param offsetY - The vertical offset in pixels.
   */
  private applyStackStyles;
  /**
   * Updates offsets for all existing dialogs when a new dialog is added.
   * Each existing dialog gets pushed back (higher offset).
   *
   * @private
   */
  private updateStackOffsets;
  /**
   * Recalculates and applies offsets for all remaining dialogs in the stack.
   * After a dialog is closed, we need to restore each dialog to its proper position.
   *
   * @private
   */
  private recalculateStackOffsets;
  /**
   * Applies the stacked CSS class to all dialogs except the topmost one.
   *
   * @private
   */
  private applyStackedClasses;
}
/**
 * @public
 */
declare abstract class PortalComponent extends BasePortalOutlet implements OnInit, OnDestroy {
  private readonly _element;
  private readonly _focusTrapFactory;
  private readonly _document;
  private readonly _overlayRef;
  private _focusTrap;
  private _elementFocusedBeforeOpened;
  /**
   * Constructs a new instance of the `PortalComponent` class.
   *
   * @protected
   */
  protected constructor();
  /**
   * Returns whether this portal owns and restores document focus.
   *
   * @protected
   * @readonly
   */
  protected get managesFocus(): boolean;
  /**
   * Returns the `portal` property.
   *
   * @protected
   * @abstract
   * @readonly
   */
  protected abstract get portal(): CdkPortalOutlet | DomPortalOutlet;
  /**
   * @public
   */
  ngOnInit(): void;
  /**
   * @public
   */
  ngOnDestroy(): void;
  /**
   * Attach a ComponentPortal as content to this dialog container.
   *
   * @public
   * @param portal - Portal to be attached as the dialog content.
   */
  attachComponentPortal<T>(portal: ComponentPortal<T>): ComponentRef<T>;
  /**
   * Attach a TemplatePortal as content to this dialog container.
   *
   * @public
   * @param portal - Portal to be attached as the dialog content.
   */
  attachTemplatePortal<TComponent>(portal: TemplatePortal<TComponent>): EmbeddedViewRef<TComponent>;
  /**
   * @public
   */
  trapFocus(): void;
  /**
   * @public
   */
  restoreFocus(): void;
  /**
   * @private
   */
  private savePreviouslyFocusedElement;
  /**
   * @private
   */
  private focusFirstTabbableDescendant;
  /**
   * @private
   */
  private findFirstTabbableDescendant;
  /**
   * @private
   */
  private isTabbable;
  static ɵfac: i0.ɵɵFactoryDeclaration<PortalComponent, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<PortalComponent, never, never, {}, {}, never, never, true, never>;
}
/**
 * @public
 */
export declare class DialogPortalComponent extends PortalComponent {
  private readonly _portal;
  private readonly _component;
  private readonly _config?;
  private readonly _slots;
  private _warnedHeader;
  private _warnedActions;
  /**
   * Constructs a new instance of the `DialogPortalComponent` class.
   *
   * @public
   */
  constructor();
  /**
   * Returns the `dialog` property.
   *
   * @public
   * @readonly
   */
  get dialog(): DialogComponent;
  /**
   * Returns the `dialogConfig` property.
   *
   * @public
   * @readonly
   */
  get dialogConfig(): Partial<IDialogConfig> | undefined;
  /**
   * Returns the `portal` property.
   *
   * @protected
   * @readonly
   */
  protected get portal(): CdkPortalOutlet;
  /**
   * Exposes an optional custom header template provided by user content.
   *
   * @public
   * @readonly
   */
  get headerTemplate(): TemplateRef<unknown> | null;
  /**
   * Exposes an optional custom actions template provided by user content.
   *
   * @public
   * @readonly
   */
  get actionsTemplate(): TemplateRef<unknown> | null;
  /**
   * Exposes an optional custom footer template provided by user content.
   *
   * @public
   * @readonly
   */
  get footerTemplate(): TemplateRef<unknown> | null;
  /**
   * Exposes an optional custom content template provided by user content.
   *
   * @public
   * @readonly
   */
  get contentTemplate(): TemplateRef<unknown> | null;
  static ɵfac: i0.ɵɵFactoryDeclaration<DialogPortalComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<DialogPortalComponent, "mosaik-dialog-portal", ["mosaikDialogPortal"], {}, {}, never, never, true, never>;
}
/**
 * @public
 */
declare abstract class PortalRef<TInstance, TData, TResult> implements IPortalRef<TInstance, TData, TResult> {
  private readonly _closedSubject;
  private readonly _closeAttemptedSubject;
  private readonly _component;
  private readonly _overlayRef;
  private readonly _id;
  private readonly _data?;
  private _isClosed;
  /**
   * Constructs a new instance of the `ElementProviderRef` class.
   *
   * @protected
   */
  protected constructor(id: string, component: TInstance, overlayRef: OverlayRef, data?: TData);
  /**
   * @public
   * @readonly
   */
  get id(): string;
  /**
   * @public
   * @readonly
   */
  get component(): TInstance;
  /**
   * @public
   * @readonly
   */
  get overlayRef(): OverlayRef;
  /**
   * @public
   * @readonly
   */
  get data(): TData | undefined;
  /**
   * @public
   * @readonly
   */
  get closed(): Observable<ICancel<TResult>>;
  /**
   * @public
   * @readonly
   */
  get closeAttempted(): Observable<IPortalCloseAttempt>;
  /**
   * Requests visual attention for the portal content without closing it.
   *
   * @public
   * @param animation - Optional animation used for this attention request.
   */
  abstract requestAttention(animation?: IAnimationReferenceMetadata | null): Promise<boolean>;
  /**
   * @public
   */
  close(result: ICancel<TResult>): void;
  /**
   * Requests a close from an implicit interaction.
   *
   * @public
   * @param trigger - Interaction that requested the close.
   * @param result - Result emitted when the close attempt is not prevented.
   */
  requestClose(trigger: PortalCloseAttemptTrigger, result: ICancel<TResult>): void;
}
/**
 * @public
 */
export declare class DialogRef<TData, TResult> extends PortalRef<DialogComponent, TData, TResult> implements IDialogRef {
  private readonly _positionChangedSubject;
  private readonly _sizeChangedSubject;
  private readonly _dialogElement;
  /**
   * Constructs a new instance of the `DialogRef` class.
   *
   * @public
   */
  constructor(id: string, component: DialogComponent, overlayRef: OverlayRef, data?: TData);
  /**
   * Returns the underlying `DialogElement`.
   *
   * @public
   * @readonly
   */
  get element(): DialogElement;
  /**
   * Returns the `positionChanged` property.
   *
   * @public
   * @readonly
   */
  get positionChanged(): Observable<Partial<{
    top: string | number;
    bottom: string | number;
    left: string | number;
    right: string | number;
  }>>;
  /**
   * Returns the `sizeChanged` property.
   *
   * @public
   * @readonly
   */
  get sizeChanged(): Observable<Partial<{
    width: string | number;
    height: string | number;
  }>>;
  /**
   * Closes the dialog and emits the `closed` event with the provided result.
   *
   * @public
   * @override
   */
  close(result: ICancel<TResult>): void;
  /**
   * Requests visual attention for the dialog.
   *
   * @public
   * @override
   */
  requestAttention(animation?: IAnimationReferenceMetadata | null): Promise<boolean>;
  /**
   * Updates the dialog's position.
   *
   * @public
   * @param position - New dialog position.
   */
  updatePosition(position: Partial<{
    top: number | string;
    bottom: number | string;
    left: number | string;
    right: number | string;
  }>): this;
  /**
   * Updates the dialog's width and height.
   *
   * @public
   * @param size - New width and height of the dialog.
   */
  updateSize(size: Partial<{
    width: number | string;
    height: number | string;
  }>): this;
  /**
   * @private
   */
  private parseNumber;
}
/**
 * Options used while creating a CDK overlay.
 *
 * @public
 */
interface IPortalOverlayOptions extends IOverlayBackdropConfig {
  /**
   * Identifies the logical overlay stack that may share a backdrop.
   *
   * @public
   */
  backdropStackKey?: string;
  /**
   * Places the complete overlay host in a reserved layer, with its backdrop directly below it.
   *
   * @public
   */
  zIndex?: number;
}
interface IPortalProviderCacheEntry {
  overlay: OverlayRef;
  portal: ComponentPortal<PortalComponent>;
}
/**
 * @public
 */
declare abstract class PortalProvider {
  private readonly _injector;
  private readonly _overlayPositionBuilder;
  private readonly _overlay;
  private readonly _cache;
  private readonly _cacheCountSubject;
  /**
   * Constructs a new instance of the `PortalProvider` class.
   *
   * @protected
   */
  protected constructor();
  /**
   * Returns the `count` property.
   *
   * @public
   * @readonly
   */
  get count(): Observable<number>;
  /**
   * Returns the `overlayPositionBuilder` property.
   *
   * @protected
   * @readonly
   */
  protected get overlayPositionBuilder(): OverlayPositionBuilder;
  /**
   * Returns the `overlay` property.
   *
   * @protected
   * @readonly
   */
  protected get overlay(): Overlay;
  /**
   * Returns the `injector` property.
   *
   * @protected
   * @readonly
   */
  protected get injector(): Injector;
  /**
   * Returns the `cache` property.
   *
   * @protected
   * @readonly
   */
  protected get cache(): ReadonlyArray<IPortalProviderCacheEntry>;
  /**
   * @protected
   */
  protected abstract createId(): string;
  /**
   * @protected
   */
  protected abstract createPortalInjector(config?: unknown): Injector;
  /**
   * @protected
   */
  protected abstract createContentInjector(ref: IPortalRef<unknown, unknown, unknown>, config?: unknown): Injector;
  /**
   * @protected
   */
  protected abstract createPositionStrategy(): PositionStrategy;
  /**
   * @protected
   */
  protected abstract createScrollStrategy(): ScrollStrategy;
  /**
   * @protected
   */
  protected createOverlay(config: OverlayConfig, options?: IPortalOverlayOptions): OverlayRef;
  /**
   * @protected
   */
  protected createPortal<TPortal extends PortalComponent>(component: Type<TPortal>, overlayRef: OverlayRef, config?: unknown): ComponentPortal<TPortal>;
  /**
   * @protected
   */
  protected createComponent<TPortal extends PortalComponent>(portal: ComponentPortal<TPortal>, overlayRef: OverlayRef, _component: Type<TPortal>, _config?: unknown): ComponentRef<TPortal>;
  /**
   * @protected
   */
  protected createContent(componentTypeOrTemplateRef: Type<unknown> | TemplateRef<unknown>, container: PortalComponent, ref: IPortalRef<unknown, unknown, unknown>, config?: unknown): ComponentRef<unknown> | EmbeddedViewRef<unknown>;
  /**
   * @protected
   */
  protected attach<TPortal extends PortalComponent>(overlayRef: OverlayRef, portal: ComponentPortal<TPortal>): void;
  /**
   * @protected
   */
  protected detach(overlayRef: OverlayRef): void;
}
/**
 * @public
 */
export declare class DialogService extends PortalProvider {
  private readonly _behaviors;
  private readonly _defaultConfig;
  private _portalInjector?;
  /**
   * Constructs a new instance of the `DialogService` class.
   *
   * @public
   */
  constructor();
  /**
   * Opens new instance of the dialog, may receive optional config.
   *
   * @public
   */
  show<TData = object, TResult = object>(componentTypeOrTemplateRef: Type<unknown> | TemplateRef<TData>, config?: Partial<IDialogConfig<TData>>): IDialogRef<TData, TResult>;
  /**
   * Closes the dialog.
   *
   * @public
   */
  close(ref: IDialogRef): void;
  /**
   * Checks if the dialog is currently shown.
   *
   * @public
   */
  isShown(ref: IDialogRef): boolean;
  /**
   * Adds a dialog behavior to the service.
   *
   * @public
   */
  withBehavior(type: Type<IDialogBehavior>): Omit<this, 'withBehavior'>;
  /**
   * @protected
   * @override
   */
  protected createId(): string;
  /**
   * @protected
   * @override
   */
  protected createPortalInjector<TData>(config?: Partial<IDialogConfig<TData>>): Injector;
  /**
   * @protected
   * @override
   */
  protected createContentInjector<TData>(ref: IDialogRef, config?: Partial<IDialogConfig<TData>>): Injector;
  /**
   * @protected
   * @override
   */
  protected createPositionStrategy(): PositionStrategy;
  /**
   * @protected
   * @override
   */
  protected createScrollStrategy(): ScrollStrategy;
  /**
   * @protected
   */
  protected createComponent<TPortal extends PortalComponent>(portal: ComponentPortal<TPortal>, overlayRef: OverlayRef, _component: Type<TPortal>, config?: Partial<IDialogConfig>): ComponentRef<TPortal>;
  /**
   * @private
   */
  private prepareComponent;
  /**
   * @private
   */
  private createConfig;
  /**
   * @private
   */
  private hasConfig;
  /**
   * @private
   */
  private mergeSize;
  static ɵfac: i0.ɵɵFactoryDeclaration<DialogService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * @public
 */
export declare const DIALOG_CONFIG: InjectionToken<Partial<IDialogConfig<unknown>>>;
/**
 * @public
 */
export declare const DIALOG_REF: InjectionToken<IDialogRef<unknown, unknown>>;
/**
 * @public
 */
export declare const DIALOG_REF_DATA: InjectionToken<any>;
/**
 * @public
 */
declare const DIALOG_BEHAVIORS: InjectionToken<readonly Type<IDialogBehavior>[]>;
/**
 * @public
 */
interface IDialogFeature {
  id: string;
  behaviorType?: Type<IDialogBehavior>;
  provide(): ReadonlyArray<Provider>;
}
/**
 * Provides the dialog service.
 *
 * @public
 */
export declare function provideDialogs(...withBehaviors: ReadonlyArray<IDialogFeature>): EnvironmentProviders;
/**
 * Provides default dialog configuration for every dialog opened by the service.
 * Values passed directly to `DialogService.show` override these defaults.
 *
 * @public
 */
export declare function withDialogDefaultBehavior(config?: Partial<IDialogConfig>): IDialogFeature;
/**
 * @public
 */
export declare function withDialogBreakpointBehavior(config?: IDialogBreakpointBehaviorConfig): IDialogFeature;
/**
 * @public
 */
export declare function withDialogStackBehavior(config?: Partial<IDialogStackBehaviorConfig>): IDialogFeature;
/**
 * Marks an ng-template inside dialog content as custom actions section.
 * Usage:
 * <ng-template mosaikDialogActions> ... </ng-template>
 *
 * @public
 */
export declare class DialogActionsDirective {
  private readonly _slots;
  /**
   * Constructs a new instance of the `DialogActionsDirective` class.
   *
   * @param template The template reference to register.
   * @public
   */
  constructor(template: TemplateRef<unknown>);
  static ɵfac: i0.ɵɵFactoryDeclaration<DialogActionsDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<DialogActionsDirective, "ng-template[mosaikDialogActions]", never, {}, {}, never, never, true, never>;
}
/**
 * Marks an ng-template inside dialog content as custom content section, replacing the default portal outlet.
 * Usage:
 * <ng-template mosaikDialogContent> ... </ng-template>
 *
 * @public
 */
export declare class DialogContentDirective {
  private readonly _slots;
  /**
   * Constructs a new instance of the `DialogContentDirective` class.
   *
   * @param template The template reference to register.
   * @public
   */
  constructor(template: TemplateRef<unknown>);
  static ɵfac: i0.ɵɵFactoryDeclaration<DialogContentDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<DialogContentDirective, "ng-template[mosaikDialogContent]", never, {}, {}, never, never, true, never>;
}
/**
 * Marks an ng-template inside dialog content as custom footer section.
 * Usage:
 * <ng-template mosaikDialogFooter> ... </ng-template>
 *
 * @public
 */
export declare class DialogFooterDirective {
  private readonly _slots;
  /**
   * Constructs a new instance of the `DialogFooterDirective` class.
   *
   * @param template The template reference to register.
   * @public
   */
  constructor(template: TemplateRef<unknown>);
  static ɵfac: i0.ɵɵFactoryDeclaration<DialogFooterDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<DialogFooterDirective, "ng-template[mosaikDialogFooter]", never, {}, {}, never, never, true, never>;
}
/**
 * Marks an ng-template inside dialog content as custom header.
 * Usage:
 * <ng-template mosaikDialogHeader> ... </ng-template>
 *
 * @public
 */
export declare class DialogHeaderDirective {
  private readonly _slots;
  /**
   * Constructs a new instance of the `DialogHeaderDirective` class.
   *
   * @param template The template reference to register.
   * @public
   */
  constructor(template: TemplateRef<unknown>);
  static ɵfac: i0.ɵɵFactoryDeclaration<DialogHeaderDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<DialogHeaderDirective, "ng-template[mosaikDialogHeader]", never, {}, {}, never, never, true, never>;
}
/**
 * Represents the `IDrawerRef` interface.
 *
 * @public
 */
interface IDrawerRef<TData = unknown, TResult = unknown> extends IPortalRef<DrawerComponent, TData, TResult> {
  /**
   * Returns the underlying DrawerElement.
   *
   * @public
   * @readonly
   */
  get element(): DrawerElement;
  /**
   * Returns an Observable that emits when the drawer position changes.
   *
   * @public
   * @readonly
   */
  get positionChanged(): Observable<Partial<{
    top: number | string;
    bottom: number | string;
    left: number | string;
    right: number | string;
  }>>;
  /**
   * Returns an Observable that emits when the drawer size changes.
   *
   * @public
   * @readonly
   */
  get sizeChanged(): Observable<Partial<{
    width: number | string;
    height: number | string;
  }>>;
  /**
   * Updates the drawer's position.
   *
   * @public
   * @param position - New position values.
   */
  updatePosition(position: Partial<{
    top: number | string;
    bottom: number | string;
    left: number | string;
    right: number | string;
  }>): this;
  /**
   * Updates the drawer's size.
   *
   * @public
   * @param size - New size values.
   */
  updateSize(size: Partial<{
    width: number | string;
    height: number | string;
  }>): this;
}
/**
 * Represents the `IDrawerConfig` interface.
 *
 * @public
 */
interface IDrawerConfig<TData = unknown> extends Omit<DrawerElement.Props, 'header' | 'subheader' | 'isOpen' | 'width' | 'height'>, IOverlayBackdropConfig {
  /**
   * The data passed to the drawer.
   *
   * @default undefined
   */
  data?: TData;
  /**
   * The size of the drawer.
   *
   * @default undefined
   */
  size?: Partial<ISizeLike>;
  /**
   * The minimum size of the drawer.
   *
   * @default undefined
   */
  minSize?: Partial<ISizeLike>;
  /**
   * The maximum size of the drawer.
   *
   * @default undefined
   */
  maxSize?: Partial<ISizeLike>;
  header?: ReactiveValue<string>;
  subheader?: ReactiveValue<string>;
  actions?: Array<{
    kind?: Extract<Variant, 'primary' | 'secondary'>;
    handler?: () => void;
    label?: ReactiveValue<string>;
    disabled?: ReactiveValue<boolean>;
    visible?: ReactiveValue<boolean>;
  }>;
  /**
   * An optional identifier for the drawer.
   *
   * @default undefined
   */
  id?: string;
  /**
   * Determines whether the drawer is disabled.
   *
   * @default false
   */
  disabled?: boolean;
  /**
   * Determines whether the drawer should focus on open.
   *
   * @default true
   */
  focusOnOpen?: boolean;
  /**
   * Determines whether the drawer should be scrollable.
   *
   * @default false
   */
  scrollable?: boolean;
  /**
   * Determines whether the drawer should close when navigation occurs.
   *
   * @default false
   */
  closeOnNavigation?: boolean;
  /**
   * Detects if only showing one drawer at the same time.
   *
   * @default false
   */
  singleton?: boolean;
}
/**
 * @public
 */
interface IDrawerBehavior extends Omit<IPortalProviderBehavior<IDrawerRef, Partial<IDrawerConfig>>, 'attach' | 'detach'> {
  /**
   * Attaches a drawer to the behavior.
   *
   * @public
   * @param ref - The drawer reference to attach.
   * @param portal - The component portal for the drawer.
   * @param config - Optional drawer configuration.
   */
  attach(ref: IDrawerRef, portal: ComponentPortal<unknown>, config?: Partial<IDrawerConfig>): void;
  /**
   * Detaches a specific drawer from the behavior.
   * If ref is not provided, detaches the most recently attached drawer.
   *
   * @public
   * @param ref - Optional drawer reference to detach.
   */
  detach(ref?: IDrawerRef): void;
}
/**
 * @public
 * @abstract
 */
declare abstract class DrawerBehavior implements IDrawerBehavior {
  private _ref;
  private _attached;
  private _drawerConfig;
  /**
   * Constructs a new instance of the `DrawerBehavior` class.
   *
   * @protected
   */
  protected constructor();
  /**
   * Returns the `ref` property.
   *
   * @public
   * @readonly
   */
  get ref(): Nullable<IDrawerRef>;
  /**
   * Returns the `config` property.
   *
   * @public
   * @readonly
   */
  get config(): Nullable<IDrawerConfig>;
  /**
   * @public
   * @virtual
   */
  configure(config: IDrawerConfig): void;
  /**
   * @public
   * @virtual
   */
  attach(element: IDrawerRef, _portal: ComponentPortal<unknown>, config?: Partial<IDrawerConfig>): void;
  /**
   * Detaches a specific drawer from the behavior.
   * If ref is not provided, detaches the most recently attached drawer.
   *
   * @public
   * @virtual
   * @param ref - Optional drawer reference to detach.
   */
  detach(ref?: IDrawerRef): void;
}
/**
 * @public
 */
interface IDrawerBreakpointBehaviorConfig {
  breakpoints: Array<{
    breakpoint: BreakpointAlias;
    size: ISizeLike;
  }>;
}
/**
 * Injection token for providing drawer breakpoint behavior configuration.
 *
 * @public
 */
export declare const DRAWER_BREAKPOINT_BEHAVIOR_CONFIG: InjectionToken<IDrawerBreakpointBehaviorConfig>;
/**
 * Behavior that adjusts drawer size based on viewport breakpoints.
 *
 * @public
 */
export declare class DrawerBreakpointBehavior extends DrawerBehavior {
  private readonly _breakpointObserver;
  private readonly _breakpointRegistry;
  private readonly _config;
  private readonly _mediaQueryToAliasMap;
  private _subscription;
  /**
   * Constructs a new instance of the `DrawerBreakpointBehavior` class.
   *
   * @public
   */
  constructor(config?: IDrawerBreakpointBehaviorConfig | null);
  /**
   * Attaches a specific drawer to the behavior.
   *
   * @public
   * @Override
   * @param drawerRef - The drawer reference to attach to the behavior.
   * @param portal - The component portal for the drawer content (unused in this behavior).
   */
  attach(drawerRef: IDrawerRef, _portal: ComponentPortal<unknown>): void;
  /**
   * Detaches a specific drawer from the behavior.
   * If ref is not provided, detaches the most recently attached drawer.
   *
   * @public
   * @override
   * @param ref - Optional drawer reference to detach (unused in this behavior).
   */
  detach(_ref?: IDrawerRef): void;
  /**
   * Handles breakpoint state changes and updates drawer size accordingly.
   *
   * @private
   * @param state - The current breakpoint state from the observer.
   * @param drawerRef - Reference to the drawer being managed.
   * @param config - Optional drawer configuration with default size values.
   */
  private onBreakpoint;
}
/**
 * Injection token for providing drawer stack behavior configuration.
 *
 * @public
 */
export declare const DRAWER_STACK_BEHAVIOR_CONFIG: InjectionToken<IDrawerStackBehaviorConfig>;
/**
 * Behavior that manages a stack of drawers with decreasing widths.
 * Each drawer in the stack is offset from the previous one, creating
 * a cascading visual effect.
 *
 * @public
 */
export declare class DrawerStackBehavior extends DrawerBehavior {
  private readonly _stack;
  private readonly _behaviorConfig;
  /**
   * Constructs a new instance of the `DrawerStackBehavior` class.
   *
   * @public
   */
  constructor(config?: IDrawerStackBehaviorConfig | null);
  /**
   * Returns the current number of drawers in the stack.
   *
   * @public
   * @readonly
   */
  get stackSize(): number;
  /**
   * Returns the current stack configuration.
   *
   * @public
   * @readonly
   */
  get stackConfig(): Readonly<IDrawerStackBehaviorConfig>;
  /**
   * Attaches a drawer to the stack and applies stack styling.
   *
   * The stacking model is:
   * - The topmost (newest) drawer gets its base width
   * - Each drawer below gets progressively wider by stackThreshold
   * - If a new drawer is larger than existing ones, smaller drawers are grown
   *
   * @public
   * @param drawerRef - The drawer reference to attach.
   * @param portal - The component portal for the drawer.
   * @param config - Optional drawer configuration.
   */
  attach(drawerRef: IDrawerRef, portal: ComponentPortal<unknown>, config?: Partial<IDrawerConfig>): void;
  /**
   * Detaches a specific drawer from the stack, or the topmost if not specified.
   * When a drawer in the middle of the stack is removed, all remaining drawers
   * are recalculated to maintain proper stacking order.
   *
   * @public
   * @override
   * @param ref - Optional drawer reference to detach. If omitted, detaches the topmost drawer.
   */
  detach(ref?: IDrawerRef): void;
  /**
   * Calculates the width for a drawer at the given stack level.
   *
   * @private
   * @param stackLevel - The zero-based index of the drawer in the stack.
   * @param baseWidthOverride - Optional override for the base width.
   * @returns The calculated CSS width string.
   */
  private calculateWidth;
  /**
   * Calculates the z-index for a drawer at the given stack level.
   *
   * @private
   * @param stackLevel - The zero-based index of the drawer in the stack.
   * @returns The calculated z-index value.
   */
  private calculateZIndex;
  /**
   * Applies stack-related CSS variables to a drawer element.
   * Uses requestAnimationFrame to ensure CSS transitions are properly triggered.
   *
   * @private
   * @param drawerRef - The drawer reference containing the element.
   * @param stackLevel - The stack level for this drawer.
   * @param computedWidth - The computed width for this drawer.
   */
  private applyStackStyles;
  /**
   * Recalculates and applies widths for all remaining drawers in the stack.
   * After a drawer is closed, we need to restore each drawer to its proper width
   * based on its new position in the stack.
   *
   * The stacking model:
   * - The topmost drawer (highest index) gets the smallest width (its base width)
   * - Each drawer below gets progressively wider by stackThreshold
   * - If a larger drawer is in the stack, smaller drawers below it are grown to match
   *
   * @private
   */
  private recalculateStackWidths;
  /**
   * Parses a percentage-based width string into a numeric value.
   *
   * @private
   * @param width - The CSS width string (e.g. "50%").
   * @returns The numeric percentage value, or null if not a percentage.
   */
  private parseWidthToPercentage;
  /**
   * Grows existing drawers when a new drawer is added to the stack.
   * Each existing drawer needs to be wider than the new one to create the cascade effect.
   *
   * The new drawer will be at the top with its base width.
   * Each drawer below gets progressively wider by threshold amount.
   *
   * @private
   * @param newDrawerBaseWidth - The base width of the newly opened drawer.
   */
  private growStackForNewDrawer;
  /**
   * Applies the stacked CSS class to all drawers except the topmost one.
   *
   * @private
   */
  private applyStackedClasses;
}
/**
 * @public
 */
export declare class DrawerPortalComponent extends PortalComponent {
  private readonly _portal;
  private readonly _component;
  private readonly _config?;
  private readonly _slots;
  private _warnedHeader;
  private _warnedActions;
  /**
   * Constructs a new instance of the `DrawerPortalComponent` class.
   *
   * @public
   */
  constructor();
  /**
   * Returns the `drawer` property.
   *
   * @public
   * @readonly
   */
  get drawer(): DrawerComponent;
  /**
   * Returns the `drawerRef` property.
   *
   * @public
   * @readonly
   */
  get drawerConfig(): Partial<IDrawerConfig> | undefined;
  /**
   * Returns the `portal` property.
   *
   * @protected
   * @readonly
   */
  protected get portal(): CdkPortalOutlet;
  /**
   * Exposes an optional custom header template provided by user content.
   *
   * @public
   * @readonly
   */
  get headerTemplate(): TemplateRef<unknown> | null;
  /**
   * Exposes an optional custom actions template provided by user content.
   *
   * @public
   * @readonly
   */
  get actionsTemplate(): TemplateRef<unknown> | null;
  /**
   * Exposes an optional custom footer template provided by user content.
   *
   * @public
   * @readonly
   */
  get footerTemplate(): TemplateRef<unknown> | null;
  /**
   * Exposes an optional custom content template provided by user content.
   *
   * @public
   * @readonly
   */
  get contentTemplate(): TemplateRef<unknown> | null;
  /**
   * Exposes an optional custom rail template provided by user content.
   *
   * @public
   * @readonly
   */
  get railTemplate(): TemplateRef<unknown> | null;
  static ɵfac: i0.ɵɵFactoryDeclaration<DrawerPortalComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<DrawerPortalComponent, "mosaik-drawer-portal", ["mosaikDrawerPortal"], {}, {}, never, never, true, never>;
}
/**
 * @public
 */
export declare class DrawerRef<TData, TResult> extends PortalRef<DrawerComponent, TData, TResult> implements IDrawerRef {
  private readonly _positionChangedSubject;
  private readonly _sizeChangedSubject;
  private readonly _drawerElement;
  /**
   * Constructs a new instance of the `DrawerRef` class.
   *
   * @public
   */
  constructor(id: string, component: DrawerComponent, overlayRef: OverlayRef, data?: TData);
  /**
   * Returns the underlying `DrawerElement`.
   *
   * @public
   * @readonly
   */
  get element(): DrawerElement;
  /**
   * Closes the drawer and completes the position and size change subjects.
   *
   * @public
   * @override
   */
  close(result: ICancel<TResult>): void;
  /**
   * Requests visual attention for the drawer.
   *
   * @public
   * @override
   */
  requestAttention(animation?: IAnimationReferenceMetadata | null): Promise<boolean>;
  /**
   * Returns the `positionChanged` property.
   *
   * @public
   * @readonly
   */
  get positionChanged(): Observable<Partial<{
    top: string | number;
    bottom: string | number;
    left: string | number;
    right: string | number;
  }>>;
  /**
   * Returns the `sizeChanged` property.
   *
   * @public
   * @readonly
   */
  get sizeChanged(): Observable<Partial<{
    width: string | number;
    height: string | number;
  }>>;
  /**
   * Updates the bottom sheet's position.
   *
   * @public
   * @param position - New bottom sheet position.
   */
  updatePosition(position: Partial<{
    top: number | string;
    bottom: number | string;
    left: number | string;
    right: number | string;
  }>): this;
  /**
   * Updates the bottom sheet's width and height.
   *
   * @public
   * @param size - New width and height of the bottom sheet.
   */
  updateSize(size: Partial<{
    width: number | string;
    height: number | string;
  }>): this;
  /**
   * @private
   */
  private parseNumber;
}
/**
 * @public
 */
export declare class DrawerService extends PortalProvider {
  private readonly _behaviors;
  private readonly _defaultConfig;
  private _portalInjector?;
  /**
   * Constructs a new instance of the `DrawerService` class.
   *
   * @public
   */
  constructor();
  /**
   * Opens a drawer.
   *
   * @public
   */
  show<TData = object, TResult = object>(componentTypeOrTemplateRef: Type<unknown> | TemplateRef<TData>, config?: Partial<IDrawerConfig<TData>>): IDrawerRef<TData, TResult>;
  /**
   * Closes a drawer.
   *
   * @public
   */
  close(ref: IDrawerRef): void;
  /**
   * Checks if the drawer is currently shown.
   *
   * @public
   */
  isShown(ref: IDrawerRef): boolean;
  /**
   * Adds a drawer behavior to the service.
   *
   * @public
   */
  withBehavior(type: Type<IDrawerBehavior>): Omit<this, 'withBehavior'>;
  /**
   * @protected
   * @override
   */
  protected createId(): string;
  /**
   * @protected
   * @override
   */
  protected createPortalInjector<TData>(config?: Partial<IDrawerConfig<TData>>): Injector;
  /**
   * @protected
   * @override
   */
  protected createContentInjector<TData>(ref: IDrawerRef<TData>, config?: Partial<IDrawerConfig<TData>>): Injector;
  /**
   * @protected
   * @override
   */
  protected createPositionStrategy(): PositionStrategy;
  /**
   * @protected
   * @override
   */
  protected createScrollStrategy(): ScrollStrategy;
  /**
   * @protected
   */
  protected createComponent<TPortal extends PortalComponent>(portal: ComponentPortal<TPortal>, overlayRef: OverlayRef, _component: Type<TPortal>, config?: Partial<IDrawerConfig>): ComponentRef<TPortal>;
  /**
   * @private
   */
  private prepareComponent;
  /**
   * @private
   */
  private createConfig;
  /**
   * @private
   */
  private hasConfig;
  /**
   * @private
   */
  private mergeSize;
  static ɵfac: i0.ɵɵFactoryDeclaration<DrawerService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * @public
 */
export declare const DRAWER_CONFIG: InjectionToken<Partial<IDrawerConfig<unknown>>>;
/**
 * @public
 */
export declare const DRAWER_REF: InjectionToken<IDrawerRef<unknown, unknown>>;
/**
 * @public
 */
export declare const DRAWER_REF_DATA: InjectionToken<unknown>;
/**
 * @public
 */
declare const DRAWER_BEHAVIORS: InjectionToken<readonly Type<IDrawerBehavior>[]>;
/**
 * @public
 */
interface IDrawerFeature {
  id: string;
  behaviorType?: Type<IDrawerBehavior>;
  provide(): ReadonlyArray<Provider>;
}
/**
 * Provides the drawer service.
 *
 * @public
 */
export declare function provideDrawers(...withFeatures: ReadonlyArray<IDrawerFeature>): EnvironmentProviders;
/**
 * Provides default drawer configuration for every drawer opened by the service.
 * Values passed directly to `DrawerService.show` override these defaults.
 *
 * @public
 */
export declare function withDrawerDefaultBehavior(config?: Partial<IDrawerConfig>): IDrawerFeature;
/**
 * @public
 */
export declare function withDrawerBreakpointBehavior(config?: IDrawerBreakpointBehaviorConfig): IDrawerFeature;
/**
 * @public
 */
export declare function withDrawerStackBehavior(config?: Partial<IDrawerStackBehaviorConfig>): IDrawerFeature;
/**
 * Marks an ng-template inside drawer content as custom actions section.
 * Usage:
 * <ng-template mosaikDrawerActions> ... </ng-template>
 *
 * @public
 */
export declare class DrawerActionsDirective {
  private readonly _slots;
  /**
   * Constructs a new instance of the `DrawerActionsDirective` class.
   *
   * @param template The template reference to register.
   * @public
   */
  constructor(template: TemplateRef<unknown>);
  static ɵfac: i0.ɵɵFactoryDeclaration<DrawerActionsDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<DrawerActionsDirective, "ng-template[mosaikDrawerActions]", never, {}, {}, never, never, true, never>;
}
/**
 * Marks an ng-template inside drawer content as custom content section, replacing the default portal outlet.
 * Usage:
 * <ng-template mosaikDrawerContent> ... </ng-template>
 *
 * @public
 */
export declare class DrawerContentDirective {
  private readonly _slots;
  /**
   * Constructs a new instance of the `DrawerContentDirective` class.
   *
   * @param template The template reference to register.
   * @public
   */
  constructor(template: TemplateRef<unknown>);
  static ɵfac: i0.ɵɵFactoryDeclaration<DrawerContentDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<DrawerContentDirective, "ng-template[mosaikDrawerContent]", never, {}, {}, never, never, true, never>;
}
/**
 * Marks an ng-template inside drawer content as custom footer section.
 * Usage:
 * <ng-template mosaikDrawerFooter> ... </ng-template>
 *
 * @public
 */
export declare class DrawerFooterDirective {
  private readonly _slots;
  /**
   * Constructs a new instance of the `DrawerFooterDirective` class.
   *
   * @param template The template reference to register.
   * @public
   */
  constructor(template: TemplateRef<unknown>);
  static ɵfac: i0.ɵɵFactoryDeclaration<DrawerFooterDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<DrawerFooterDirective, "ng-template[mosaikDrawerFooter]", never, {}, {}, never, never, true, never>;
}
/**
 * Marks an ng-template inside drawer content as custom header.
 * Usage:
 * <ng-template mosaikDrawerHeader> ... </ng-template>
 *
 * @public
 */
export declare class DrawerHeaderDirective {
  private readonly _slots;
  /**
   * Constructs a new instance of the `DrawerHeaderDirective` class.
   *
   * @param template The template reference to register.
   * @public
   */
  constructor(template: TemplateRef<unknown>);
  static ɵfac: i0.ɵɵFactoryDeclaration<DrawerHeaderDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<DrawerHeaderDirective, "ng-template[mosaikDrawerHeader]", never, {}, {}, never, never, true, never>;
}
/**
 * Marks an ng-template inside drawer content as a rail displayed beside the primary drawer sections.
 * Usage:
 * <ng-template mosaikDrawerRail> ... </ng-template>
 *
 * @public
 */
export declare class DrawerRailDirective {
  private readonly _slots;
  private readonly _template;
  /**
   * Constructs a new instance of the `DrawerRailDirective` class.
   *
   * @public
   */
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<DrawerRailDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<DrawerRailDirective, "ng-template[mosaikDrawerRail]", never, {}, {}, never, never, true, never>;
}
declare namespace OverlayInteractionBoundaryDirective_d_exports {
  export { MOSAIK_OVERLAY_INTERACTION_BOUNDARY_ATTRIBUTE, OverlayInteractionBoundaryDirective };
}
/**
 * DOM attribute recognized as an external Mosaik overlay interaction boundary.
 *
 * @public
 */
declare const MOSAIK_OVERLAY_INTERACTION_BOUNDARY_ATTRIBUTE = "data-mosaik-overlay-interaction-boundary";
/**
 * Marks an element as an external interaction boundary for Mosaik overlays.
 *
 * Pointer interactions originating inside the marked element do not count as
 * outside interactions for an already open Mosaik dialog, drawer, sheet, or
 * message box. This allows persistent shell affordances to open a higher
 * overlay without implicitly closing the current overlay stack.
 *
 * @public
 */
export declare class OverlayInteractionBoundaryDirective {
  static ɵfac: i0.ɵɵFactoryDeclaration<OverlayInteractionBoundaryDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<OverlayInteractionBoundaryDirective, "[mosaikOverlayInteractionBoundary]", never, {}, {}, never, never, true, never>;
}
/**
 * Represents the `IMessageBoxRef` interface.
 *
 * @public
 */
interface IMessageBoxRef<TData = unknown, TResult = unknown> extends IPortalRef<MessageBoxComponent, TData, TResult> {
  /**
   * Returns the underlying `MessageBoxElement`.
   *
   * @public
   * @readonly
   */
  get element(): MessageBoxElement;
}
/**
 * Represents the `IMessageBoxConfig` interface.
 *
 * @public
 */
interface IMessageBoxConfig<TData = unknown> extends MessageBoxElement.Props, IOverlayBackdropConfig {
  /**
   * The unique identifier for the message box.
   */
  id?: string;
  /**
   * Data to pass to the message box content.
   */
  data?: TData;
  /**
   * Whether to close the message box on navigation.
   */
  closeOnNavigation?: boolean;
  /**
   * Internationalization overrides for button labels.
   * Uses the Foundation's intl type directly.
   */
  intl?: Partial<MessageBoxElement['intl']>;
}
/**
 * @public
 */
export declare class MessageBoxPortalComponent extends PortalComponent {
  private readonly _portal;
  private readonly _component;
  private readonly _config?;
  /**
   * Constructs a new instance of the `MessageBoxPortalComponent` class.
   *
   * @public
   */
  constructor();
  /**
   * Returns the `portal` property.
   *
   * @protected
   * @override
   * @readonly
   */
  protected get portal(): CdkPortalOutlet;
  /**
   * Returns the `messageBox` property.
   *
   * @public
   * @readonly
   */
  get messageBox(): MessageBoxComponent;
  /**
   * Returns the `config` property.
   *
   * @public
   * @readonly
   */
  get config(): IMessageBoxConfig | undefined;
  static ɵfac: i0.ɵɵFactoryDeclaration<MessageBoxPortalComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<MessageBoxPortalComponent, "mosaik-message-box-portal", ["mosaikMessageBoxPortal"], {}, {}, never, never, true, never>;
}
/**
 * Represents the `IMessageBoxBehavior` interface.
 *
 * @public
 */
interface IMessageBoxBehavior {
  /**
   * Configures the behavior with the given config.
   *
   * @public
   */
  configure(config: Partial<IMessageBoxConfig>): void;
  /**
   * Attaches the behavior to the given ref and portal.
   *
   * @public
   */
  attach(ref: IMessageBoxRef, portal: ComponentPortal<MessageBoxPortalComponent>): void;
  /**
   * Detaches the behavior.
   *
   * @public
   */
  detach(): void;
}
/**
 * @public
 */
export declare class MessageBoxRef<TData, TResult> extends PortalRef<MessageBoxComponent, TData, TResult> implements IMessageBoxRef {
  private readonly _messageBoxElement;
  /**
   * Constructs a new instance of the `MessageBoxRef` class.
   *
   * @public
   */
  constructor(id: string, component: MessageBoxComponent, overlayRef: OverlayRef, data?: TData);
  /**
   * Returns the underlying `MessageBoxElement`.
   *
   * @public
   * @readonly
   */
  get element(): MessageBoxElement;
  /**
   * Requests visual attention for the message box.
   *
   * @public
   * @override
   */
  requestAttention(animation?: IAnimationReferenceMetadata | null): Promise<boolean>;
}
/**
 * Angular service for managing message box overlays.
 * Uses Angular CDK Overlay for positioning and lifecycle management.
 * Provides own RxJS-based escape key handling for consistency with other overlay services.
 *
 * @public
 */
export declare class MessageBoxService extends PortalProvider {
  private readonly _messageBoxBehaviors;
  /**
   * Constructs a new instance of the `MessageBoxService` class.
   *
   * @public
   */
  constructor(config?: Partial<IMessageBoxConfig> | null, behaviors?: ReadonlyArray<Type<IMessageBoxBehavior>> | null);
  /**
   * Opens a message box with the given configuration.
   *
   * @public
   */
  show<TData = object>(config?: Partial<IMessageBoxConfig<TData>>): IMessageBoxRef<TData, MessageBoxResult>;
  /**
   * Closes a message box.
   *
   * @public
   */
  close(ref: IMessageBoxRef): void;
  /**
   * Checks if the message box is currently shown.
   *
   * @public
   */
  isShown(ref: IMessageBoxRef): boolean;
  /**
   * Adds a message box behavior to the service.
   *
   * @public
   */
  withBehavior(type: Type<IMessageBoxBehavior>): Omit<this, 'withBehavior'>;
  /**
   * @protected
   * @override
   */
  protected createId(): string;
  /**
   * @protected
   * @override
   */
  protected createPortalInjector<TData>(config?: IMessageBoxConfig<TData>): Injector;
  /**
   * @protected
   * @override
   */
  protected createContentInjector<TData>(ref: IMessageBoxRef<TData>, config?: IMessageBoxConfig<TData>): Injector;
  /**
   * @protected
   * @override
   */
  protected createPositionStrategy(): PositionStrategy;
  /**
   * @protected
   * @override
   */
  protected createScrollStrategy(): ScrollStrategy;
  /**
   * @private
   */
  private prepareComponent;
  static ɵfac: i0.ɵɵFactoryDeclaration<MessageBoxService, [{
    optional: true;
  }, {
    optional: true;
  }]>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * Adds a stable automation identifier to an attached message-box host.
 *
 * The behavior is opt-in and must be registered by the consuming application.
 *
 * @public
 */
export declare class MessageBoxTestIdBehavior implements IMessageBoxBehavior {
  private _element?;
  /**
   * Accepts the message-box configuration required by the behavior contract.
   *
   * @public
   */
  configure(config: Partial<IMessageBoxConfig>): void;
  /**
   * Applies the stable automation identifier to the attached message-box host.
   *
   * @public
   */
  attach(ref: IMessageBoxRef): void;
  /**
   * Removes the automation identifier from the detached message-box host.
   *
   * @public
   */
  detach(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<MessageBoxTestIdBehavior, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * @public
 */
export declare const MESSAGE_BOX_CONFIG: InjectionToken<IMessageBoxConfig<unknown>>;
/**
 * @public
 */
export declare const MESSAGE_BOX_REF: InjectionToken<IMessageBoxRef<unknown, unknown>>;
/**
 * @public
 */
export declare const MESSAGE_BOX_REF_DATA: InjectionToken<unknown>;
/**
 * @public
 */
export declare const MESSAGE_BOX_BEHAVIORS: InjectionToken<readonly Type<IMessageBoxBehavior>[]>;
/**
 * Options for providing the message box service.
 *
 * @public
 */
interface IProvideMessageBoxesOptions {
  /**
   * Default configuration for message boxes.
   */
  config?: Partial<IMessageBoxConfig>;
  /**
   * Behaviors to apply to message boxes.
   */
  behaviors?: ReadonlyArray<Type<IMessageBoxBehavior>>;
}
/**
 * Provides the message box service with optional configuration.
 *
 * @public
 */
export declare function provideMessageBoxes(options?: IProvideMessageBoxesOptions): EnvironmentProviders;
/**
 * Represents the `ISheetRef` interface.
 *
 * @public
 */
interface ISheetRef<TData = any, TResult = any> extends IPortalRef<SheetComponent, TData, TResult> {
  /**
   * Returns the underlying `SheetElement`.
   *
   * @public
   * @readonly
   */
  get element(): SheetElement;
  /**
   * Returns an observable that emits when the position of the sheet changes.
   *
   * @public
   * @readonly
   */
  get positionChanged(): Observable<Partial<{
    top: number | string;
    bottom: number | string;
    left: number | string;
    right: number | string;
  }>>;
  /**
   * Returns an observable that emits when the size of the sheet changes.
   *
   * @public
   * @readonly
   */
  get sizeChanged(): Observable<Partial<{
    width: number | string;
    height: number | string;
  }>>;
  /**
   * Updates the position of the sheet.
   *
   * @public
   */
  updatePosition(position: Partial<{
    top: number | string;
    bottom: number | string;
    left: number | string;
    right: number | string;
  }>): this;
  /**
   * Updates the size of the sheet.
   *
   * @public
   */
  updateSize(size: Partial<{
    width: number | string;
    height: number | string;
  }>): this;
}
/**
 * Represents the `ISheetConfig` interface.
 *
 * @public
 */
interface ISheetConfig<TData = unknown> extends Partial<Omit<SheetElement.Props, 'isOpen' | 'width' | 'height'>>, IOverlayBackdropConfig {
  /**
   * Data to pass to the sheet content.
   */
  data?: TData;
  /**
   * The width of the sheet.
   */
  width?: SheetElement['width'];
  /**
   * The height of the sheet.
   */
  height?: SheetElement['height'];
  /**
   * The header text of the sheet.
   */
  header?: ReactiveValue<string>;
  /**
   * The subheader text of the sheet.
   */
  subheader?: ReactiveValue<string>;
  /**
   * Whether the sheet is closeable.
   */
  closeable?: boolean;
  /**
   * Action buttons to display in the sheet.
   */
  actions?: Array<{
    kind?: Extract<Variant, 'primary' | 'secondary'>;
    handler?: () => void;
    label?: ReactiveValue<string>;
    disabled?: ReactiveValue<boolean>;
    visible?: ReactiveValue<boolean>;
  }>;
  /**
   * The unique identifier for the sheet.
   */
  id?: string;
  /**
   * Whether to close the sheet on navigation.
   */
  closeOnNavigation?: boolean;
  /**
   * Whether to show a backdrop behind the sheet.
   */
  hasBackdrop?: boolean;
  /**
   * Whether to close the sheet when clicking outside.
   */
  clickOutsideToClose?: boolean;
  /**
   * Whether to close the sheet when pressing the escape key.
   */
  pressEscapeToClose?: boolean;
  /**
   * Animation used when the sheet requests visual attention.
   */
  attention?: IAnimationReferenceMetadata | null;
}
/**
 * Represents the `ISheetBehavior` interface.
 *
 * @public
 */
interface ISheetBehavior extends Omit<IPortalProviderBehavior<ISheetRef, Partial<ISheetConfig>>, 'detach'> {
  /**
   * Detaches a specific sheet from the behavior.
   * If ref is not provided, detaches the most recently attached sheet.
   *
   * @public
   * @param ref - Optional sheet reference to detach.
   */
  detach(ref?: ISheetRef): void;
}
/**
 * @public
 * @abstract
 */
declare abstract class SheetBehavior implements ISheetBehavior {
  private _sheetRef;
  private _attached;
  private _sheetConfig;
  /**
   * Constructs a new instance of the `SheetBehavior` class.
   *
   * @protected
   */
  protected constructor();
  /**
   * Returns the `ref` property.
   *
   * @public
   * @readonly
   */
  get ref(): ISheetRef;
  /**
   * Returns the `config` property.
   *
   * @public
   * @readonly
   */
  get config(): Nullable<ISheetConfig>;
  /**
   * Configures the behavior for the next sheet attachment.
   *
   * @public
   * @virtual
   * @param config - The sheet configuration visible to the behavior.
   */
  configure(config: ISheetConfig): void;
  /**
   * Attaches the behavior to a sheet reference.
   *
   * @public
   * @virtual
   * @param ref - The attached sheet reference.
   * @param _portal - The portal containing the sheet content.
   */
  attach(ref: ISheetRef, _portal: ComponentPortal<unknown>): void;
  /**
   * Detaches a specific sheet from the behavior.
   * If ref is not provided, detaches the most recently attached sheet.
   *
   * @public
   * @virtual
   * @param ref - Optional sheet reference to detach.
   */
  detach(ref?: ISheetRef): void;
}
/**
 * Configuration for responsive sheet sizing.
 *
 * @public
 */
interface ISheetBreakpointBehaviorConfig {
  /**
   * The breakpoint aliases and sheet sizes applied while each breakpoint matches.
   */
  breakpoints: Array<{
    breakpoint: BreakpointAlias;
    size: ISizeLike;
  }>;
}
/**
 * Behavior that adjusts sheet size based on viewport breakpoints.
 *
 * @public
 */
export declare class SheetBreakpointBehavior extends SheetBehavior {
  private readonly _breakpointObserver;
  private readonly _breakpointRegistry;
  private readonly _breakpointConfig;
  private readonly _mediaQueryToAliasMap;
  private _subscription;
  /**
   * Constructs a new instance of the `SheetBreakpointBehavior` class.
   *
   * @public
   */
  constructor(config?: ISheetBreakpointBehaviorConfig | null);
  /**
   * Attaches a specific sheet to the behavior.
   *
   * @public
   * @override
   * @param sheetRef - The sheet reference to attach to the behavior.
   * @param portal - The component portal for the sheet content (unused in this behavior).
   */
  attach(sheetRef: ISheetRef, _portal: ComponentPortal<unknown>): void;
  /**
   * Detaches a specific sheet from the behavior.
   * If ref is not provided, detaches the most recently attached sheet.
   *
   * @public
   * @override
   * @param ref - Optional sheet reference to detach (unused in this behavior).
   */
  detach(_ref?: ISheetRef): void;
  /**
   * Handles breakpoint state changes and updates sheet size accordingly.
   *
   * @private
   * @param state - The current breakpoint state from the observer.
   * @param sheetRef - Reference to the sheet being managed.
   * @param config - Optional sheet configuration with the default width and height.
   */
  private onBreakpoint;
}
/**
 * Represents an optional feature installed by `provideSheets`.
 *
 * @public
 */
interface ISheetFeature {
  /**
   * The stable feature identifier.
   */
  id: string;
  /**
   * The optional behavior type instantiated by the sheet service.
   */
  behaviorType?: Type<ISheetBehavior>;
  /**
   * Returns the Angular providers required by the feature.
   *
   * @returns The providers installed with the sheet service.
   */
  provide(): ReadonlyArray<Provider>;
}
/**
 * Provides the sheet service.
 *
 * @public
 */
export declare function provideSheets(...withFeatures: ReadonlyArray<ISheetFeature>): EnvironmentProviders;
/**
 * Provides default sheet configuration for every sheet opened by the service.
 * Values passed directly to `SheetService.show` override these defaults.
 *
 * @public
 */
export declare function withSheetDefaultBehavior(config?: Partial<ISheetConfig>): ISheetFeature;
/**
 * Adds responsive sheet sizing based on registered Mosaik breakpoint aliases.
 *
 * @public
 * @param config - The breakpoint aliases and sheet sizes applied when they match.
 * @returns A feature that installs the sheet breakpoint behavior.
 */
export declare function withSheetBreakpointBehavior(config?: ISheetBreakpointBehaviorConfig): ISheetFeature;
/**
 * @public
 */
export declare class SheetPortalComponent extends PortalComponent {
  private readonly _portal;
  private readonly _component;
  private readonly _config?;
  private readonly _slots;
  private _warnedHeader;
  /**
   * Constructs a new instance of the `SheetPortalComponent` class.
   *
   * @public
   */
  constructor();
  /**
   * Returns the `portal` property.
   *
   * @protected
   * @override
   * @readonly
   */
  protected get portal(): CdkPortalOutlet;
  /**
   * Returns the `sheet` property.
   *
   * @public
   * @readonly
   */
  get sheet(): SheetComponent;
  /**
   * Returns the `sheetConfig` property.
   *
   * @public
   * @readonly
   */
  get sheetConfig(): ISheetConfig | undefined;
  /**
   * Exposes an optional custom header template provided by user content.
   *
   * @public
   * @readonly
   */
  get headerTemplate(): TemplateRef<unknown> | null;
  /**
   * Exposes an optional custom content template provided by user content.
   *
   * @public
   * @readonly
   */
  get contentTemplate(): TemplateRef<unknown> | null;
  /**
   * Exposes an optional custom footer template provided by user content.
   *
   * @public
   * @readonly
   */
  get footerTemplate(): TemplateRef<unknown> | null;
  static ɵfac: i0.ɵɵFactoryDeclaration<SheetPortalComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SheetPortalComponent, "mosaik-sheet-portal", ["mosaikSheetPortal"], {}, {}, never, never, true, never>;
}
/**
 * @public
 */
export declare class SheetRef<TData, TResult> extends PortalRef<SheetComponent, TData, TResult> implements ISheetRef {
  private readonly _positionChangedSubject;
  private readonly _sizeChangedSubject;
  private readonly _sheetElement;
  /**
   * Constructs a new instance of the `SheetRef` class.
   *
   * @public
   */
  constructor(id: string, component: SheetComponent, overlayRef: OverlayRef, data?: TData);
  /**
   * Returns the underlying `SheetElement`.
   *
   * @public
   * @readonly
   */
  get element(): SheetElement;
  /**
   * Closes the sheet and emits the `closed` event.
   *
   * @public
   * @override
   */
  close(result: ICancel<TResult>): void;
  /**
   * Requests visual attention for the sheet.
   *
   * @public
   * @override
   */
  requestAttention(animation?: IAnimationReferenceMetadata | null): Promise<boolean>;
  /**
   * Returns the `positionChanged` property.
   *
   * @public
   * @readonly
   */
  get positionChanged(): Observable<Partial<{
    top: string | number;
    bottom: string | number;
    left: string | number;
    right: string | number;
  }>>;
  /**
   * Returns the `sizeChanged` property.
   *
   * @public
   * @readonly
   */
  get sizeChanged(): Observable<Partial<{
    width: string | number;
    height: string | number;
  }>>;
  /**
   * Updates the bottom sheet's position.
   *
   * @public
   * @param position - New bottom sheet position.
   */
  updatePosition(position: Partial<{
    top: number | string;
    bottom: number | string;
    left: number | string;
    right: number | string;
  }>): this;
  /**
   * Updates the bottom sheet's width and height.
   *
   * @public
   * @param size - New width and height of the bottom sheet.
   */
  updateSize(size: Partial<{
    width: number | string;
    height: number | string;
  }>): this;
  /**
   * @private
   */
  private parseNumber;
}
/**
 * Opens and manages sheet overlays through the Angular CDK overlay infrastructure.
 * Default configuration and optional behaviors are supplied by `provideSheets` features.
 *
 * @public
 */
export declare class SheetService extends PortalProvider {
  private readonly _behaviors;
  private readonly _defaultConfig;
  private _portalInjector?;
  /**
   * Constructs a new instance of the `SheetService` class.
   *
   * @public
   */
  constructor();
  /**
   * Opens a sheet.
   *
   * @public
   */
  show<TData = object, TResult = object>(componentTypeOrTemplateRef: Type<unknown> | TemplateRef<TData>, config?: Partial<ISheetConfig<TData>>): ISheetRef<TData, TResult>;
  /**
   * Closes a sheet.
   *
   * @public
   */
  close(ref: ISheetRef): void;
  /**
   * Checks if the sheet is currently shown.
   *
   * @public
   */
  isShown(ref: ISheetRef): boolean;
  /**
   * Adds a sheet behavior to the service.
   *
   * @public
   */
  withBehavior(type: Type<ISheetBehavior>): Omit<this, 'withBehavior'>;
  /**
   * @protected
   * @override
   */
  protected createId(): string;
  /**
   * @protected
   * @override
   */
  protected createPortalInjector<TData>(config?: Partial<ISheetConfig<TData>>): Injector;
  /**
   * @protected
   * @override
   */
  protected createContentInjector<TData>(ref: ISheetRef<TData>, config?: Partial<ISheetConfig<TData>>): Injector;
  /**
   * @protected
   * @override
   */
  protected createPositionStrategy(): PositionStrategy;
  /**
   * @protected
   * @override
   */
  protected createScrollStrategy(): ScrollStrategy;
  /**
   * @private
   */
  private prepareComponent;
  /**
   * @private
   */
  private createConfig;
  /**
   * @private
   */
  private hasConfig;
  static ɵfac: i0.ɵɵFactoryDeclaration<SheetService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * @public
 */
export declare const SHEET_CONFIG: InjectionToken<ISheetConfig<unknown>>;
/**
 * @public
 */
export declare const SHEET_REF: InjectionToken<ISheetRef<any, any>>;
/**
 * @public
 */
export declare const SHEET_REF_DATA: InjectionToken<unknown>;
/**
 * @public
 */
export declare const SHEET_BEHAVIORS: InjectionToken<readonly Type<ISheetBehavior>[]>;
/**
 * Provides responsive sheet breakpoint configuration.
 *
 * @public
 */
export declare const SHEET_BREAKPOINT_BEHAVIOR_CONFIG: InjectionToken<ISheetBreakpointBehaviorConfig>;
/**
 * Marks an ng-template inside sheet content as custom content section, replacing the default portal outlet.
 * Usage:
 * <ng-template mosaikSheetContent> ... </ng-template>
 *
 * @public
 */
export declare class SheetContentDirective {
  private readonly _slots;
  /**
   * Constructs a new instance of the `SheetContentDirective` class.
   *
   * @param template The template reference to register.
   * @public
   */
  constructor(template: TemplateRef<unknown>);
  static ɵfac: i0.ɵɵFactoryDeclaration<SheetContentDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<SheetContentDirective, "ng-template[mosaikSheetContent]", never, {}, {}, never, never, true, never>;
}
/**
 * Marks an ng-template inside sheet content as custom footer section.
 * Usage:
 * <ng-template mosaikSheetFooter> ... </ng-template>
 *
 * @public
 */
export declare class SheetFooterDirective {
  private readonly _slots;
  /**
   * Constructs a new instance of the `SheetFooterDirective` class.
   *
   * @param template The template reference to register.
   * @public
   */
  constructor(template: TemplateRef<unknown>);
  static ɵfac: i0.ɵɵFactoryDeclaration<SheetFooterDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<SheetFooterDirective, "ng-template[mosaikSheetFooter]", never, {}, {}, never, never, true, never>;
}
/**
 * Marks an ng-template inside sheet content as custom header.
 * Usage:
 * <ng-template mosaikSheetHeader> ... </ng-template>
 *
 * @public
 */
export declare class SheetHeaderDirective {
  private readonly _slots;
  /**
   * Constructs a new instance of the `SheetHeaderDirective` class.
   *
   * @param template The template reference to register.
   * @public
   */
  constructor(template: TemplateRef<unknown>);
  static ɵfac: i0.ɵɵFactoryDeclaration<SheetHeaderDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<SheetHeaderDirective, "ng-template[mosaikSheetHeader]", never, {}, {}, never, never, true, never>;
}
/**
 * Represents the `IToastRef` interface.
 *
 * @public
 */
interface IToastRef<TData = unknown, TResult = unknown> extends IPortalRef<ToastComponent, TData, TResult> {
  /**
   * Returns the underlying `ToastElement`.
   *
   * @public
   * @readonly
   */
  get element(): ToastElement;
}
/**
 * Represents the `IToastConfig` interface.
 *
 * @public
 */
interface IToastConfig<TData = unknown> extends Omit<ToastElement.Props, 'icon'>, IOverlayBackdropConfig {
  /**
   * The unique identifier for the toast.
   */
  id?: string;
  /**
   * Data to pass to the toast content.
   */
  data?: TData;
  /**
   * Whether to close the toast on navigation.
   */
  closeOnNavigation?: boolean;
  /**
   * The name of the icon to display in the toast.
   */
  icon?: ReactiveValue<string>;
  /**
   * The legacy name of the icon to display in the toast.
   *
   * @deprecated Use `icon`.
   */
  iconName?: ReactiveValue<string>;
  /**
   * Action buttons displayed in the toast actions area.
   */
  actions?: Array<{
    kind?: Extract<Variant, 'primary' | 'secondary'>;
    handler?: () => void;
    label?: ReactiveValue<string>;
    disabled?: ReactiveValue<boolean>;
    visible?: ReactiveValue<boolean>;
  }>;
}
/**
 * Represents the `IToastBehavior` interface.
 *
 * @public
 */
interface IToastBehavior extends IPortalProviderBehavior<IToastRef, Partial<IToastConfig>> {}
/**
 * Injection token for providing toast stack behavior configuration.
 *
 * @public
 */
export declare const TOAST_STACK_BEHAVIOR_CONFIG: InjectionToken<Partial<IToastStackBehaviorConfig>>;
/**
 * Behavior that arranges concurrently open toasts into a stack.
 * The newest toast stays in front while the ones behind it step back, shrink
 * and peek out, creating a stacked visual effect.
 *
 * @remarks
 * The arrangement itself is the framework-agnostic `ToastStackBehavior` of the
 * foundation. This class only maps the Angular toast reference onto the shape
 * that stack works on, so both worlds stack identically.
 *
 * @public
 *
 * @example
 * ```typescript
 * provideToasts(withToastStackBehavior());
 * ```
 */
export declare class ToastStackBehavior implements IToastBehavior {
  private readonly _stack;
  /**
   * Constructs a new instance of the `ToastStackBehavior` class.
   *
   * @public
   * @param config - Optional configuration for stack behavior.
   */
  constructor(config?: Partial<IToastStackBehaviorConfig> | null);
  /**
   * Returns the current stack configuration.
   *
   * @public
   * @readonly
   */
  get config(): Readonly<IToastStackBehaviorConfig>;
  /**
   * Returns the number of toasts currently taking part in a stack.
   *
   * @public
   * @readonly
   */
  get stackSize(): number;
  /**
   * @inheritdoc
   */
  configure(_config: Partial<IToastConfig>): void;
  /**
   * @inheritdoc
   */
  attach(ref: IToastRef, _portal: ComponentPortal<unknown>): void;
  /**
   * @inheritdoc
   */
  detach(ref?: IToastRef): void;
  /**
   * Maps an Angular toast reference onto the shape the stack works on.
   *
   * @private
   * @param ref - The reference to map.
   */
  private targetOf;
}
/**
 * Configuration for responsive toast sizing.
 *
 * @public
 */
interface IToastBreakpointBehaviorConfig {
  /**
   * The breakpoint aliases and maximum toast widths applied while each breakpoint matches.
   * When multiple configured breakpoints match, the last matching entry takes precedence.
   */
  breakpoints: Array<{
    breakpoint: BreakpointAlias;
    maxWidth: NonNullable<IToastConfig['maxWidth']>;
  }>;
}
/**
 * Adjusts the maximum width of every open toast based on registered Mosaik breakpoints.
 *
 * @remarks
 * Toasts can be open concurrently. The behavior therefore tracks each toast independently
 * and restores its own configured maximum width when no responsive override matches.
 *
 * @public
 */
export declare class ToastBreakpointBehavior implements IToastBehavior {
  private readonly _breakpointObserver;
  private readonly _breakpointRegistry;
  private readonly _config;
  private readonly _subscriptions;
  /**
   * Constructs a new instance of the `ToastBreakpointBehavior` class.
   *
   * @public
   * @param config - Responsive toast sizing configuration.
   */
  constructor(config?: IToastBreakpointBehaviorConfig | null);
  /**
   * @inheritdoc
   */
  configure(_config: Partial<IToastConfig>): void;
  /**
   * @inheritdoc
   */
  attach(ref: IToastRef, _portal: ComponentPortal<unknown>): void;
  /**
   * @inheritdoc
   */
  detach(ref?: IToastRef): void;
  /**
   * Applies the last matching responsive width or restores the toast's original width.
   *
   * @private
   * @param state - Current media-query matches.
   * @param ref - Toast receiving the responsive width.
   * @param defaultMaxWidth - Maximum width configured when the toast was opened.
   * @param breakpoints - Resolved responsive width entries in precedence order.
   */
  private onBreakpoint;
  /**
   * Resolves configured aliases through the shared Mosaik breakpoint registry.
   *
   * @private
   */
  private resolveBreakpoints;
}
/**
 * Injection token for providing responsive toast sizing configuration.
 *
 * @public
 */
export declare const TOAST_BREAKPOINT_BEHAVIOR_CONFIG: InjectionToken<IToastBreakpointBehaviorConfig>;
/**
 * @public
 */
interface IToastFeature {
  id: string;
  behaviorType?: Type<IToastBehavior>;
  provide(): ReadonlyArray<Provider>;
}
/**
 * Provides the toast service.
 *
 * @public
 */
export declare function provideToasts(...withFeatures: ReadonlyArray<IToastFeature>): EnvironmentProviders;
/**
 * Provides default toast configuration for every toast opened by the service.
 * Values passed directly to `ToastService.show` override these defaults.
 *
 * @example
 * ```typescript
 * provideToasts(withToastDefaultBehavior({ maxWidth: '30dvw' }));
 * ```
 *
 * @public
 */
export declare function withToastDefaultBehavior(config?: Partial<IToastConfig>): IToastFeature;
/**
 * Adds responsive toast sizing based on registered Mosaik breakpoint aliases.
 *
 * @example
 * ```typescript
 * provideToasts(
 *     withToastDefaultBehavior({ maxWidth: '30dvw' }),
 *     withToastBreakpointBehavior({
 *         breakpoints: [{ breakpoint: 'lt-md', maxWidth: '100dvw' }]
 *     })
 * );
 * ```
 *
 * @public
 * @param config - The breakpoint aliases and maximum toast widths applied when they match.
 * @returns A feature that installs the toast breakpoint behavior.
 */
export declare function withToastBreakpointBehavior(config?: IToastBreakpointBehaviorConfig): IToastFeature;
/**
 * @public
 */
export declare function withToastStackBehavior(config?: Partial<IToastStackBehaviorConfig>): IToastFeature;
/**
 * Declares the toast slot registry interface backed by signals.
 *
 * @public
 */
interface IToastSlots {
  actions: Signal<TemplateRef<unknown> | null>;
  setActions(template: TemplateRef<unknown> | null): void;
}
/**
 * Provides a new slots registry instance.
 *
 * @public
 */
export declare function provideToastSlots(): Provider;
/**
 * Marks an ng-template inside toast content as custom actions section.
 * Usage:
 * <ng-template mosaikToastActions> ... </ng-template>
 *
 * @public
 */
export declare class ToastActionsDirective {
  private readonly _slots;
  /**
   * Constructs a new instance of the `ToastActionsDirective` class.
   *
   * @param template The template reference to register.
   * @public
   */
  constructor(template: TemplateRef<unknown>);
  static ɵfac: i0.ɵɵFactoryDeclaration<ToastActionsDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ToastActionsDirective, "ng-template[mosaikToastActions]", never, {}, {}, never, never, true, never>;
}
/**
 * Injection token representing the per-toast slots registry.
 *
 * @public
 */
export declare const TOAST_SLOTS: InjectionToken<IToastSlots>;
/**
 * @public
 */
export declare class ToastPortalComponent extends PortalComponent {
  private readonly _portal;
  private readonly _component;
  private readonly _config?;
  private readonly _slots;
  private _warnedActions;
  /**
   * Constructs a new instance of the `ToastPortalComponent` class.
   *
   * @public
   */
  constructor();
  /**
   * Toasts are non-modal status messages and must not interrupt the user's current interaction.
   *
   * @protected
   * @override
   * @readonly
   */
  protected get managesFocus(): boolean;
  /**
   * Returns the `portal` property.
   *
   * @protected
   * @override
   * @readonly
   */
  protected get portal(): CdkPortalOutlet;
  /**
   * Returns the `toast` property.
   *
   * @public
   * @readonly
   */
  get toast(): ToastComponent;
  /**
   * Returns the `config` property.
   *
   * @public
   * @readonly
   */
  get config(): IToastConfig | undefined;
  /**
   * Returns the actions template if provided via the `mosaikToastActions` directive.
   *
   * @public
   * @readonly
   */
  get actionsTemplate(): TemplateRef<unknown> | null;
  /**
   * Handles an action button click.
   * Executes the action handler and closes the toast.
   *
   * @protected
   * @param handler - The action handler to execute.
   */
  protected onActionClick(handler?: () => void): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ToastPortalComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ToastPortalComponent, "mosaik-toast-portal", ["mosaikToastPortal"], {}, {}, never, never, true, [{
    directive: typeof OverlayInteractionBoundaryDirective;
    inputs: {};
    outputs: {};
  }]>;
}
/**
 * @public
 */
export declare class ToastRef<TData, TResult> extends PortalRef<ToastComponent, TData, TResult> implements IToastRef {
  private readonly _toastElement;
  /**
   * Constructs a new instance of the `ToastRef` class.
   *
   * @public
   */
  constructor(id: string, component: ToastComponent, overlayRef: OverlayRef, data?: TData);
  /**
   * Returns the underlying `ToastElement`.
   *
   * @public
   * @readonly
   */
  get element(): ToastElement;
  /**
   * Requests visual attention for the toast.
   *
   * @public
   * @override
   */
  requestAttention(animation?: IAnimationReferenceMetadata | null): Promise<boolean>;
}
/**
 * Angular service for managing toast notifications.
 * Uses Angular CDK Overlay for positioning and lifecycle management.
 * Provides own RxJS-based escape key handling for consistency with other overlay services.
 *
 * @public
 */
export declare class ToastService extends PortalProvider {
  private readonly _toastBehaviors;
  private readonly _defaultConfig;
  /**
   * Constructs a new instance of the `ToastService` class.
   *
   * @public
   */
  constructor(config?: Partial<IToastConfig> | null, behaviors?: ReadonlyArray<Type<IToastBehavior>> | null);
  /**
   * Opens a toast notification.
   *
   * @public
   */
  show<TData = object, TResult = object>(config?: Partial<IToastConfig<TData>>): IToastRef<TData, TResult>;
  show<TData = object, TResult = object>(componentTypeOrTemplateRef: Type<unknown> | TemplateRef<TData>, config?: Partial<IToastConfig<TData>>): IToastRef<TData, TResult>;
  /**
   * Closes a toast.
   *
   * @public
   */
  close(ref: IToastRef): void;
  /**
   * Checks if the toast is currently shown.
   *
   * @public
   */
  isShown(ref: IToastRef): boolean;
  /**
   * Adds a toast behavior to the service.
   *
   * @public
   */
  withBehavior(type: Type<IToastBehavior>): Omit<this, 'withBehavior'>;
  /**
   * @protected
   * @override
   */
  protected createId(): string;
  /**
   * @protected
   * @override
   */
  protected createPortalInjector<TData>(config?: IToastConfig<TData>): Injector;
  /**
   * @protected
   * @override
   */
  protected createContentInjector<TData>(ref: IToastRef<TData>, config?: IToastConfig<TData>): Injector;
  /**
   * @protected
   * @override
   */
  protected createPositionStrategy(): PositionStrategy;
  /**
   * @protected
   * @override
   */
  protected createScrollStrategy(): ScrollStrategy;
  /**
   * @private
   */
  private prepareComponent;
  /**
   * Merges the configured service defaults with the options of one toast.
   *
   * @private
   * @param config - Per-toast options that take precedence over the defaults.
   */
  private createConfig;
  static ɵfac: i0.ɵɵFactoryDeclaration<ToastService, [{
    optional: true;
  }, {
    optional: true;
  }]>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * @public
 */
export declare const TOAST_CONFIG: InjectionToken<IToastConfig<unknown>>;
/**
 * @public
 */
export declare const TOAST_REF: InjectionToken<IToastRef<unknown, unknown>>;
/**
 * @public
 */
export declare const TOAST_REF_DATA: InjectionToken<unknown>;
/**
 * @public
 */
export declare const TOAST_BEHAVIORS: InjectionToken<readonly Type<IToastBehavior>[]>;
/**
 * Marks an existing Angular host element as a guided-tour anchor.
 *
 * @example
 * ```html
 * <mosaik-form-field
 *     mosaikTourAnchor="subject"
 *     mosaikTourId="newsletter-editor">
 * </mosaik-form-field>
 * ```
 *
 * @public
 */
export declare class TourAnchorDirective {
  private readonly _element;
  private readonly _anchorId;
  private readonly _tourId;
  /**
   * Constructs a new instance of the `TourAnchorDirective` class.
   *
   * @public
   */
  constructor();
  /**
   * Gets or sets the anchor identifier within the tour.
   *
   * @public
   */
  get anchorId(): string;
  set anchorId(value: string);
  /**
   * Gets or sets the tour identifier that owns the anchor.
   *
   * @public
   */
  get tourId(): string;
  set tourId(value: string);
  static ɵfac: i0.ɵɵFactoryDeclaration<TourAnchorDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<TourAnchorDirective, "[mosaikTourAnchor]", never, {
    "anchorId": {
      "alias": "mosaikTourAnchor";
      "required": false;
    };
    "tourId": {
      "alias": "mosaikTourId";
      "required": false;
    };
  }, {}, never, never, true, never>;
  static ngAcceptInputType_anchorId: string | null | undefined;
  static ngAcceptInputType_tourId: string | null | undefined;
}
/**
 * One reactive target exposed by a component to an external tour definition.
 *
 * The element signal supports controls that appear and disappear at runtime.
 * The optional value signal follows Angular Signal Forms: tour fill actions
 * write through the component's real model signal instead of callback-based
 * value-accessor methods or synthetic DOM events.
 *
 * @public
 */
interface ITourAccessorTarget {
  /** Reactive visual element highlighted by the tour. */
  readonly element: Signal<HTMLElement | null>;
  /** Reactive writable value signal used when the target supports fill actions. */
  readonly value?: Signal<WritableSignal<unknown> | null>;
  /** Optional component-owned action used instead of a synthetic DOM click. */
  readonly click?: ITourAnchorTarget['click'];
}
/**
 * Signal-based contract through which a reusable Angular component projects
 * its tour-relevant targets to an external feature.
 *
 * Components expose capabilities only. They do not know a tour id, anchor id,
 * step definition, or copy. The consuming feature maps stable target keys to
 * its own declarative tour through `TourAccessorDirective`.
 *
 * @public
 */
interface ITourAccessor {
  /** Reactive map of stable component target keys to rendered controls. */
  readonly targets: Signal<ReadonlyMap<string, ITourAccessorTarget>>;
}
/**
 * Maps stable accessor target keys to anchor ids owned by one declarative tour.
 * A nullish or blank anchor id leaves the target unregistered.
 *
 * @public
 */
type TourAccessorAnchorMap = Readonly<Record<string, string | null | undefined>>;
/**
 * Maps a component's signal-based tour accessor to one declarative tour.
 *
 * The directive belongs to the feature template. The reusable component only
 * implements `ITourAccessor` and therefore remains independent of tour ids,
 * step definitions, and feature-specific anchor names.
 *
 * @example
 * ```html
 * <feature-compound
 *     [mosaikTourAccessor]="{ add: tourAnchors.contactAdd }"
 *     [mosaikTourId]="tourId">
 * </feature-compound>
 * ```
 *
 * @public
 */
export declare class TourAccessorDirective {
  private readonly _accessor;
  /** Target-key to tour-anchor mapping owned by the consuming feature. */
  readonly anchors: InputSignal<TourAccessorAnchorMap>;
  /** Identifier of the tour receiving the mapped anchors. */
  readonly tourId: InputSignalWithTransform<string, string | null | undefined>;
  /**
   * Constructs the directive and keeps native registrations synchronized
   * with the component's dynamic signal targets.
   *
   * @public
   */
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<TourAccessorDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<TourAccessorDirective, "[mosaikTourAccessor]", never, {
    "anchors": {
      "alias": "mosaikTourAccessor";
      "required": false;
      "isSignal": true;
    };
    "tourId": {
      "alias": "mosaikTourId";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * Same-element token implemented by a reusable component that exposes
 * signal-based tour targets.
 *
 * @public
 */
export declare const TOUR_ACCESSOR: InjectionToken<ITourAccessor>;
/**
 * Creates a type-safe tour target while erasing only the heterogeneous value
 * type required to store multiple control kinds in one accessor map.
 *
 * @param element - Signal resolving the currently rendered target element.
 * @param value - Optional signal resolving the control's writable model signal.
 * @param click - Optional component-owned action for click tour actions.
 * @returns A framework-facing tour accessor target.
 * @public
 */
export declare function createTourAccessorTarget<TValue>(element: Signal<HTMLElement | null>, value?: Signal<WritableSignal<TValue> | null>, click?: ITourAnchorTarget['click']): ITourAccessorTarget;
/**
 * Creates a tour definition inside the Angular injection context.
 *
 * @public
 */
type TourDefinitionFactory<TContext = unknown> = () => ITourDefinition<TContext>;
/**
 * A static or lazily resolved declarative tour definition.
 *
 * @public
 */
type TourDefinitionSource = ITourDefinition<never> | TourDefinitionFactory<never>;
/**
 * Composable Angular feature registered with the guided-tour provider.
 *
 * @public
 */
interface ITourFeature {
  /**
   * Stable feature identifier.
   */
  readonly id: string;
  /**
   * Behavior type resolved from Angular dependency injection.
   */
  readonly behaviorType?: Type<ITourBehavior>;
  /**
   * Creates providers owned by this feature.
   *
   * @returns Angular providers for the feature.
   */
  provide(): ReadonlyArray<Provider>;
}
/**
 * Provides one or more declarative guided tours.
 *
 * Definition factories run lazily in Angular's injection context, allowing
 * localized text and other injectable configuration to stay feature-owned.
 * Multiple calls compose through a multi-provider.
 *
 * @param sources - Static definitions, injectable definition factories, or tour features.
 * @returns Environment providers for the tour service and definitions.
 * @public
 */
export declare function provideTours(...sources: ReadonlyArray<TourDefinitionSource | ITourFeature>): EnvironmentProviders;
/**
 * Provides default behavior for every tour started by the tour service.
 * Values supplied by an individual tour definition override these defaults.
 * A factory runs in Angular's injection context so applications can resolve
 * translated labels and other injectable configuration.
 *
 * @param config - Static defaults or an injectable defaults factory.
 * @returns A feature providing application-wide tour defaults.
 * @public
 */
export declare function withTourDefaultBehavior(config?: Partial<TourElement.Props> | (() => Partial<TourElement.Props>)): ITourFeature;
/**
 * Runs declaratively provided Mosaik tours from Angular applications.
 *
 * The service owns a single framework-neutral `mosaik-tour` element, mounts it
 * in the initial portal scope so existing focus traps include the guide card,
 * and keeps Angular signals synchronized with its typed lifecycle events. The
 * element follows its anchors into other portal scopes on its own.
 *
 * @public
 */
export declare class TourService {
  private readonly _document;
  private readonly _injector;
  private readonly _sources;
  private readonly _behaviors;
  private readonly _defaultProps;
  private readonly _router;
  private readonly _routerEventsSubscription;
  private readonly _stepActivator;
  private readonly _activeTourId;
  private readonly _activeStep;
  private readonly _lastFailure;
  private readonly _isActive;
  private readonly _handleStarted;
  private readonly _handleEnded;
  private readonly _handleStepChanged;
  private readonly _handleFailed;
  private _element;
  private _isStarting;
  private _allowUserInitiatedNavigation;
  private _isTourNavigation;
  private _contextEffect;
  /**
   * Constructs a new instance of the `TourService` class.
   *
   * @public
   */
  constructor();
  /**
   * The active tour identifier.
   *
   * @public
   * @readonly
   */
  get activeTourId(): Signal<string | null>;
  /**
   * The active step.
   *
   * @public
   * @readonly
   */
  get activeStep(): Signal<IResolvedTourStep | null>;
  /**
   * Whether a tour is active.
   *
   * @public
   * @readonly
   */
  get isActive(): Signal<boolean>;
  /**
   * The latest tour failure, if any.
   *
   * @public
   * @readonly
   */
  get lastFailure(): Signal<ITourFailedEventDetail | null>;
  /**
   * Resolves all currently provided tour definitions.
   *
   * @public
   */
  getDefinitions(): ReadonlyArray<ITourDefinition<never>>;
  /**
   * Indicates whether a tour definition is available.
   *
   * @public
   */
  hasTour(tourId: string): boolean;
  /**
   * Starts a provided tour at its first step or at a supplied step identifier.
   *
   * @public
   */
  start<TContext = unknown>(tourId: string, stepId?: string, context?: Signal<TContext>): Promise<boolean>;
  /**
   * Moves to the next available step.
   *
   * @public
   */
  next(): Promise<boolean>;
  /**
   * Moves to the previous available step.
   *
   * @public
   */
  previous(): Promise<boolean>;
  /**
   * Pauses automatic progression of the active timed tour step.
   *
   * @public
   */
  pauseAutoAdvance(): boolean;
  /**
   * Resumes automatic progression from the currently visible tour step.
   *
   * @public
   */
  resumeAutoAdvance(): boolean;
  /**
   * Shows a provided step by identifier.
   *
   * @public
   */
  showStep(stepId: string): Promise<boolean>;
  /**
   * Finishes the active tour.
   *
   * @public
   */
  finish(): Promise<boolean>;
  /**
   * Skips the active tour.
   *
   * @public
   */
  skip(): Promise<boolean>;
  /**
   * Ends the active tour.
   *
   * @public
   */
  end(reason?: TourEndReason): Promise<boolean>;
  /**
   * Starts one tour while the public entry point serializes start requests.
   *
   * @private
   */
  private startCore;
  /**
   * Creates and connects the native tour element once.
   *
   * @private
   */
  private getOrCreateElement;
  /**
   * Applies one declarative definition to the native tour element.
   *
   * @private
   */
  private applyDefinition;
  /**
   * Resolves a definition value before its application default and native fallback.
   *
   * @param definitionValue - Value supplied by the active tour definition.
   * @param defaultValue - Application-wide value supplied through Angular.
   * @param fallback - Native service fallback.
   * @returns The effective value.
   * @private
   */
  private resolveDefault;
  /**
   * Mounts the native guide in the same portal scope as its initial anchor or
   * launch control. This keeps the guide inside an enclosing CDK focus trap;
   * otherwise the trap can refocus its first field after every step render
   * and undo a completed programmatic scroll. The native element itself moves
   * into the portal scope of every later anchor, so a step that opens another
   * overlay keeps the guide above that overlay and inside its focus trap.
   *
   * @private
   */
  private mountElement;
  /**
   * Determines the first context-active step for portal placement. Invalid
   * predicates remain candidates so the native runtime can emit its typed
   * validation failure instead of hiding the error here.
   *
   * @private
   */
  private isStepContextActive;
  /**
   * Synchronizes an Angular signal into the framework-neutral tour context
   * for exactly the lifetime of the active tour.
   *
   * @private
   */
  private bindContext;
  /**
   * Releases the active context signal subscription and optionally clears
   * the last value from the reusable native tour element.
   *
   * @private
   */
  private clearContextBinding;
  /**
   * Resolves the nearest Mosaik portal scope across light and shadow DOM.
   *
   * @private
   */
  private findPortalScope;
  /**
   * Resolves the deepest focused element across nested shadow roots.
   *
   * @private
   */
  private resolveDeepActiveElement;
  /**
   * Activates the route declared by a step and waits for Angular navigation
   * to complete before the native tour starts resolving its anchor.
   *
   * @private
   */
  private activateStep;
  /**
   * Ends the active tour when application navigation was not initiated by
   * the tour and the definition did not opt into preserving it.
   *
   * @private
   */
  private onRouterEvent;
  /**
   * Synchronizes the started lifecycle with Angular signals.
   *
   * @private
   */
  private onStarted;
  /**
   * Synchronizes the ended lifecycle with Angular signals.
   *
   * @private
   */
  private onEnded;
  /**
   * Synchronizes step changes with Angular signals.
   *
   * @private
   */
  private onStepChanged;
  /**
   * Synchronizes failures with Angular signals.
   *
   * @private
   */
  private onFailed;
  /**
   * Releases the owned native tour element.
   *
   * @private
   */
  private destroy;
  static ɵfac: i0.ɵɵFactoryDeclaration<TourService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * Starts a provided guided tour when its host is clicked.
 *
 * @example
 * ```html
 * <button
 *     mosaikTourStart="newsletter-editor"
 *     [mosaikTourContext]="newsletterContext">
 *     Start tour
 * </button>
 * ```
 *
 * @public
 */
export declare class TourStartDirective {
  private readonly _element;
  private readonly _tourService;
  private readonly _handleHostClick;
  private readonly _tourId;
  private readonly _startAt;
  private readonly _context;
  /**
   * Constructs a new instance of the `TourStartDirective` class.
   *
   * @public
   */
  constructor();
  /**
   * Gets or sets the identifier of the tour to start.
   *
   * @public
   */
  get tourId(): string;
  set tourId(value: string);
  /**
   * Gets or sets an optional initial step identifier.
   *
   * @public
   */
  get startAt(): string | undefined;
  set startAt(value: string | undefined);
  /**
   * Gets or sets the signal whose latest value becomes the tour runtime
   * context. The service keeps listening to this signal until the tour ends.
   *
   * @public
   */
  get context(): Signal<unknown> | undefined;
  set context(value: Signal<unknown> | null | undefined);
  /**
   * Starts the configured tour.
   *
   * @public
   */
  onClicked(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<TourStartDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<TourStartDirective, "[mosaikTourStart]", never, {
    "tourId": {
      "alias": "mosaikTourStart";
      "required": false;
    };
    "startAt": {
      "alias": "mosaikTourStartAt";
      "required": false;
    };
    "context": {
      "alias": "mosaikTourContext";
      "required": false;
    };
  }, {}, never, never, true, never>;
  static ngAcceptInputType_tourId: string | null | undefined;
  static ngAcceptInputType_startAt: string | null | undefined;
}
/**
 * Collects declarative tour definitions from independently provided features.
 *
 * @public
 */
export declare const TOUR_DEFINITIONS: InjectionToken<readonly TourDefinitionSource[]>;
/**
 * Collects composable behaviors applied to the native tour runtime.
 *
 * @public
 */
export declare const TOUR_BEHAVIORS: InjectionToken<readonly Type<ITourBehavior>[]>;
/**
 * Adds cinematic pan-and-zoom movement to provided guided tours.
 *
 * @param config - Optional camera behavior configuration.
 * @returns Tour provider feature.
 * @public
 */
export declare function withTourCameraBehavior(config?: Partial<ITourCameraBehaviorConfig>): ITourFeature;
/**
 * Provides shared time update streams to avoid multiple setTimeout calls.
 * All pipes share the same intervals for maximum performance.
 *
 * @public
 */
export declare class TimeUpdateService {
  private readonly _zone;
  private _secondTick;
  private _minuteTick;
  private _hourTick;
  private _midnightTick;
  /**
   * Constructs a new instance of the `TimeUpdateService` class.
   *
   * @public
   */
  constructor(zone: NgZone);
  /**
   * Gets a shared observable that emits every 2 seconds.
   * Used for sub-minute time updates.
   *
   * @public
   * @returns An observable that emits every 2 seconds.
   */
  getSecondTick(): Observable<number>;
  /**
   * Gets a shared observable that emits every 30 seconds.
   * Used for minute-level time updates.
   *
   * @public
   * @returns An observable that emits every 30 seconds.
   */
  getMinuteTick(): Observable<number>;
  /**
   * Gets a shared observable that emits every 5 minutes.
   * Used for hour-level time updates.
   *
   * @public
   * @returns An observable that emits every 5 minutes.
   */
  getHourTick(): Observable<number>;
  /**
   * Gets a shared observable that emits at midnight every day.
   * Used for date-level updates.
   *
   * @public
   * @returns An observable that emits at midnight.
   */
  getMidnightTick(): Observable<number>;
  /**
   * Creates an observable that emits at midnight and then every 24 hours.
   *
   * @private
   * @returns An observable that emits at midnight.
   */
  private createMidnightObservable;
  static ɵfac: i0.ɵɵFactoryDeclaration<TimeUpdateService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * Transforms a `string` date to into a date ago string.
 *
 * @public
 */
export declare class DateAgoPipe implements PipeTransform, OnDestroy {
  private readonly _intl;
  private readonly _changeDetectorRef;
  private readonly _zone;
  private readonly _timeUpdateService;
  private readonly _intlChangesSubscription;
  private readonly _midnightSubscription;
  /**
   * Constructs a new instance of the `DateAgoPipe` class.
   *
   * @public
   */
  constructor(intl: DateAgoPipeIntl, changeDetectorRef: ChangeDetectorRef, zone: NgZone, timeUpdateService: TimeUpdateService);
  /**
   * @public
   */
  transform(value: string | Date): string;
  /**
   * @public
   */
  ngOnDestroy(): void;
  /**
   * Formats the given string with the given arguments.
   *
   * @private
   * @param self The string to format.
   * @param args The arguments to format the string with.
   * @returns The formatted string.
   *
   * @example
   * ```ts
   * const formattedString = this.formatPipe.format('Hello, {0}!', 'World');
   * console.log(formattedString); // Output: 'Hello, World!'
   * ```
   */
  private format;
  static ɵfac: i0.ɵɵFactoryDeclaration<DateAgoPipe, never>;
  static ɵpipe: i0.ɵɵPipeDeclaration<DateAgoPipe, "dateAgo", true>;
}
/**
 * The `DateAgoPipeIntl` class.
 *
 * @public
 */
export declare class DateAgoPipeIntl extends DateAgoIntl {
  private readonly _changesSubject;
  /**
   * Constructs a new instance of the `DateAgoPipeIntl` class.
   *
   * @public
   */
  constructor();
  /**
   * Stream to emit from when labels are changed. Use this to notify components when the labels have
   * changed after initialization.
   *
   * @public
   * @readonly
   */
  get changes(): Subject<void>;
  static ɵfac: i0.ɵɵFactoryDeclaration<DateAgoPipeIntl, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * Provides the `DateAgoPipe` and its internationalization.
 *
 * @public
 * @returns The provider for the `DateAgoPipe`.
 */
export declare function provideDateAgoPipe(): Provider;
/**
 * A thin pipe wrapper delegating its work to the {@link filterByMemberPath} function.
 *
 * @public
 */
export declare class FilterByPipe implements PipeTransform {
  transform<T>(...args: Parameters<typeof filterByMemberPath<T>>): ReturnType<typeof filterByMemberPath<T>>;
  static ɵfac: i0.ɵɵFactoryDeclaration<FilterByPipe, never>;
  static ɵpipe: i0.ɵɵPipeDeclaration<FilterByPipe, "filterBy", true>;
}
/**
 * Transforms a `string` to a formatted `string` where one or more format items in a string with the string representation of a specified object.
 *
 * @public
 */
export declare class FormatPipe implements PipeTransform {
  transform(value: string, ...args: Array<any>): string;
  /**
   * Formats the given string with the given arguments.
   *
   * @private
   * @param self The string to format.
   * @param args The arguments to format the string with.
   * @returns The formatted string.
   *
   * @example
   * ```ts
   * const formattedString = this.formatPipe.format('Hello, {0}!', 'World');
   * console.log(formattedString); // Output: 'Hello, World!'
   * ```
   */
  private format;
  static ɵfac: i0.ɵɵFactoryDeclaration<FormatPipe, never>;
  static ɵpipe: i0.ɵɵPipeDeclaration<FormatPipe, "format", true>;
}
/**
 * Transforms a value to an observable sequence.
 *
 * @public
 */
export declare class OfPipe implements PipeTransform {
  transform<T>(value: unknown): Observable<T>;
  static ɵfac: i0.ɵɵFactoryDeclaration<OfPipe, never>;
  static ɵpipe: i0.ɵɵPipeDeclaration<OfPipe, "of", true>;
}
/**
 * A thin pipe wrapper delegating its work to the {@link orderByMemberPath} function.
 *
 * @public
 */
export declare class OrderByPipe implements PipeTransform {
  transform<T>(...args: Parameters<typeof orderByMemberPath<T>>): ReturnType<typeof orderByMemberPath<T>>;
  static ɵfac: i0.ɵɵFactoryDeclaration<OrderByPipe, never>;
  static ɵpipe: i0.ɵɵPipeDeclaration<OrderByPipe, "orderBy", true>;
}
/**
 * Transforms a `string` date to into a time ago string.
 *
 * @public
 */
export declare class TimeAgoPipe implements PipeTransform, OnDestroy {
  private readonly _intl;
  private readonly _changeDetectorRef;
  private readonly _zone;
  private readonly _timeUpdateService;
  private readonly _intlChangesSubscription;
  private _tickSubscription;
  private _currentTickType;
  /**
   * Constructs a new instance of the `TimeAgoPipe` class.
   *
   * @public
   */
  constructor(intl: TimeAgoPipeIntl, changeDetectorRef: ChangeDetectorRef, zone: NgZone, timeUpdateService: TimeUpdateService);
  /**
   * @public
   */
  transform(value: string | Date): string;
  /**
   * @public
   */
  ngOnDestroy(): void;
  /**
   * Determines the required tick type based on seconds difference.
   *
   * @private
   * @param seconds The number of seconds difference.
   * @returns The required tick type.
   */
  private getRequiredTickType;
  /**
   * Subscribes to the appropriate tick stream.
   *
   * @private
   * @param tickType The type of tick stream to subscribe to.
   */
  private subscribeToTicks;
  /**
   * Unsubscribes from the current tick stream.
   *
   * @private
   */
  private unsubscribeFromTicks;
  /**
   * Formats the given string with the given arguments.
   *
   * @private
   * @param self The string to format.
   * @param args The arguments to format the string with.
   * @returns The formatted string.
   *
   * @example
   * ```ts
   * const formattedString = this.formatPipe.format('Hello, {0}!', 'World');
   * console.log(formattedString); // Output: 'Hello, World!'
   * ```
   */
  private format;
  static ɵfac: i0.ɵɵFactoryDeclaration<TimeAgoPipe, never>;
  static ɵpipe: i0.ɵɵPipeDeclaration<TimeAgoPipe, "timeAgo", true>;
}
/**
 * The `TimeAgoPipeIntl` class.
 *
 * @public
 */
export declare class TimeAgoPipeIntl extends TimeAgoIntl {
  private readonly _changesSubject;
  /**
   * Constructs a new instance of the `TimeAgoPipeIntl` class.
   *
   * @public
   */
  constructor();
  /**
   * Stream to emit from when labels are changed. Use this to notify components when the labels have
   * changed after initialization.
   *
   * @public
   * @readonly
   */
  get changes(): Subject<void>;
  static ɵfac: i0.ɵɵFactoryDeclaration<TimeAgoPipeIntl, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * Provides the `TimeAgoPipe` and its internationalization.
 *
 * @public
 * @returns The provider for the `TimeAgoPipe`.
 */
export declare function provideTimeAgoPipe(): Provider;
/**
 * Provides the TimeUpdateService and related pipes for time-based updates.
 *
 * @public
 * @returns The environment providers for time updates.
 */
export declare function provideTimeUpdates(): EnvironmentProviders;
type DeepPartial<T> = { [P in keyof T]?: T[P] extends Array<infer U> ? Array<DeepPartial<U>> : T[P] extends Map<infer K, infer V> ? Map<K, DeepPartial<V>> : T[P] extends Set<infer U> ? Set<DeepPartial<U>> : T[P] extends object ? T[P] extends Date | RegExp | Function ? T[P] : DeepPartial<T[P]> : T[P]; };
/**
 * A type that represents a theme override.
 *
 * @public
 */
type ThemeOverride = Omit<DeepPartial<ITheme>, 'name'>;
/**
 * Provides the theme functionality.
 *
 * @public
 */
export declare function provideTheme(config: {
  theme: ITheme;
  overrides?: ThemeOverride;
  mode: ThemeMode;
}): EnvironmentProviders;
/**
 * The `ThemeService` class.
 *
 * @public
 */
export declare class ThemeService {
  private readonly _theme;
  private readonly _themeMode;
  private readonly _themeObserver;
  private _themeModeChangedSubscription;
  /**
   * Constructs a new instance of the `{@link ThemeService}` class.
   *
   * @public
   */
  constructor(theme?: Signal<ITheme>, themeMode?: Signal<ThemeMode>, themeObserver?: ThemeObserver, destroyRef?: DestroyRef);
  get schemes(): Array<string>;
  get palettes(): Array<string>;
  /**
   * Initializes the theme service by subscribing to theme changes and applying the initial theme.
   *
   * @public
   */
  initialize(): void;
  /**
   * Applies the specified theme mode to the current theme.
   *
   * @public
   */
  applyTheme(mode: ThemeMode): void;
}
/**
 * @public
 */
export declare const THEME: InjectionToken<Signal<ITheme>>;
/**
 * @public
 */
export declare const THEME_MODE: InjectionToken<Signal<ThemeMode>>;
/**
 * @public
 */
export declare function provideTranslationRegistry(config?: {
  defaultLanguageResolver?: () => string;
  translations?: Record<string, Record<string, string>>;
}): EnvironmentProviders;
/**
 * Provides translations for the application.
 *
 * Accepts either synchronous `Record<string, string>` values per language,
 * or `Promise<Record<string, string>>` for lazy-loaded translations (e.g. via dynamic `import()`).
 *
 * When promises are detected, an `APP_INITIALIZER` is used to ensure translations are
 * available before the application renders. If a promise rejects, the translation key
 * itself is used as fallback (no app crash).
 *
 * @public
 */
export declare function provideTranslations(translations?: Record<string, Record<string, string> | Promise<Record<string, string>>>): EnvironmentProviders;
/**
 * Structural directive for translating text.
 *
 * @public
 */
export declare class TranslateDirective implements OnInit, OnDestroy {
  private readonly _vcr;
  private readonly _templateRef;
  private readonly _cdr;
  private readonly _translate;
  private _view;
  private _scope;
  private _languageChangedSubscription;
  /**
   * Constructs a new instance of the `TranslateDirective` class.
   *
   * @public
   */
  constructor();
  /**
   * Gets or sets the `scope` property.
   *
   * @public
   */
  get scope(): string;
  set scope(value: string);
  /**
   * @public
   */
  ngOnInit(): void;
  /**
   * @public
   */
  ngOnDestroy(): void;
  /**
   * @private
   */
  private onCultureChanged;
  /**
   * @private
   */
  private invalidate;
  /**
   * @private
   */
  private getImplicitFn;
  static ɵfac: i0.ɵɵFactoryDeclaration<TranslateDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<TranslateDirective, "[mosaikTranslate]", never, {
    "scope": {
      "alias": "translateScope";
      "required": false;
    };
  }, {}, never, never, true, never>;
}
/**
 * A pipe that translates a key into a localized string.
 *
 * @public
 */
export declare class TranslatePipe implements PipeTransform, OnDestroy {
  private readonly _translate;
  private readonly _cdr;
  private _lastKey;
  private _lastParams;
  private _lastScope;
  private _lastValue;
  private readonly _languageChangedSubscription;
  /**
   * Constructs a new instance of the `TranslatePipe` class.
   *
   * @public
   */
  constructor();
  /**
   * Translates the specified key into a localized string.
   *
   * @public
   * @param key - The key to translate.
   * @param params - The parameters to use for translation.
   * @param scope - The scope to use for translation.
   * @returns The translated string.
   */
  transform(key: string, params?: Record<string, any>, scope?: string): string;
  /**
   * @public
   */
  ngOnDestroy(): void;
  /**
   * Compares two objects for equality.
   *
   * @private
   * @param obj1 - The first object.
   * @param obj2 - The second object.
   * @returns `true` if the objects are equal, otherwise `false`.
   */
  private isEqual;
  static ɵfac: i0.ɵɵFactoryDeclaration<TranslatePipe, never>;
  static ɵpipe: i0.ɵɵPipeDeclaration<TranslatePipe, "translate", true>;
}
interface ITranslation {
  [key: string]: string | ITranslation;
}
/**
 * A service for translating keys into strings.
 *
 * @public
 */
export declare class TranslateService {
  private readonly _translator;
  private readonly _languageChanged;
  constructor(translator?: TranslatorService);
  /**
   * Gets or sets the current language.
   *
   * @public
   */
  get currentLanguage(): string;
  set currentLanguage(value: string);
  /**
   *  Gets an observable that emits the current language whenever it changes.
   *
   * @public
   * @readonly
   */
  get languageChanged(): Observable<string>;
  /**
   * Adds the given translations for the given language.
   *
   * @public
   */
  addTranslations(lang: string, translations: ITranslation): void;
  /**
   * Translates the given key.
   *
   * @public
   */
  translate(key: string, ...args: Array<unknown>): string;
  static ɵfac: i0.ɵɵFactoryDeclaration<TranslateService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * Predicate function to determine if a view should be active for a given selection.
 *
 * @public
 */
type ViewCanActivateFn<TSelection = unknown> = (selection: TSelection | null) => boolean;
/**
 * Represents the definition for a view that can be registered in a slot.
 *
 * @typeParam TSelection - The type of selection this view expects.
 * @public
 */
interface IViewSlotDefinition<TSelection = unknown> {
  /** Unique identifier for this view within the slot. */
  readonly id: string;
  /** Translation key for the view label/header. */
  readonly labelKey?: string;
  /** The Angular component to render for this view. */
  readonly component?: Type<unknown>;
  /** Lazy loader function for code-splitting. */
  readonly loadComponent?: () => Promise<Type<unknown>>;
  /** Optional icon identifier (e.g., PrimeIcons class). */
  readonly icon?: string;
  /** Sort order for positioning among other views. Lower values appear first. */
  readonly order?: number;
  /** Static visibility predicate based on capabilities/permissions. */
  readonly isVisible?: () => boolean;
  /** Selection-based activation predicate. Re-evaluated when selection changes. */
  readonly canActivate?: ViewCanActivateFn<TSelection>;
  /** Optional badge text, count, or dynamic badge function. */
  readonly badge?: string | number | (() => string | number | null);
}
/**
 * Central registry for managing view registrations across all slots.
 *
 * @public
 */
export declare class ViewSlotRegistry {
  private readonly _injector;
  private readonly _slots;
  /**
   * Gets all views registered to a slot, filtered by visibility.
   *
   * @param slotId - The unique identifier of the slot.
   * @returns Signal containing all visible views, sorted by order.
   *
   * @public
   */
  getViews<TSelection>(slotId: string): Signal<Array<IViewSlotDefinition<TSelection>>>;
  /**
   * Gets views filtered by selection using their `canActivate` predicate.
   *
   * @param slotId - The unique identifier of the slot.
   * @param selection - Signal containing the current selection.
   * @returns Signal containing views that can be activated for the current selection.
   *
   * @public
   */
  getActiveViews<TSelection>(slotId: string, selection: Signal<TSelection | null>): Signal<Array<IViewSlotDefinition<TSelection>>>;
  /**
   * Checks if a slot has any visible views.
   *
   * @param slotId - The unique identifier of the slot.
   * @returns Signal indicating whether views are available.
   *
   * @public
   */
  hasViews(slotId: string): Signal<boolean>;
  /**
   * Checks if a slot has any active views for the current selection.
   *
   * @param slotId - The unique identifier of the slot.
   * @param selection - Signal containing the current selection.
   * @returns Signal indicating whether active views are available.
   *
   * @public
   */
  hasActiveViews<TSelection>(slotId: string, selection: Signal<TSelection | null>): Signal<boolean>;
  /**
   * Dynamically registers a view at runtime.
   *
   * @param slotId - The unique identifier of the slot.
   * @param view - The view definition to register.
   * @param providerId - Optional identifier for the source.
   * @throws Error if a view with the same ID already exists.
   *
   * @public
   */
  register<TSelection>(slotId: string, view: IViewSlotDefinition<TSelection>, providerId?: string): void;
  /**
   * Unregisters a dynamically registered view.
   *
   * @param slotId - The unique identifier of the slot.
   * @param viewId - The ID of the view to unregister.
   * @returns True if the view was found and removed.
   *
   * @public
   */
  unregister<TSelection>(slotId: string, viewId: string): boolean;
  /**
   * Gets a specific view by ID.
   *
   * @param slotId - The unique identifier of the slot.
   * @param viewId - The ID of the view to find.
   * @returns The view definition or undefined.
   *
   * @public
   */
  getViewById<TSelection>(slotId: string, viewId: string): IViewSlotDefinition<TSelection> | undefined;
  private _getOrCreateSlotState;
  private _initializeFromRegistrations;
  private _sortAndFilterViews;
  static ɵfac: i0.ɵɵFactoryDeclaration<ViewSlotRegistry, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * The `ViewSlotOutletComponent` component.
 *
 * Renders all views registered to a given slot. Each view is resolved
 * (eagerly or lazily) and rendered via `NgComponentOutlet`.
 *
 * @example
 * ```html
 * <mosaik-view-slot-outlet slot="profile" />
 * ```
 *
 * @public
 */
export declare class ViewSlotOutletComponent<TSelection = unknown> {
  private readonly _registry;
  private readonly _parentInjector;
  private readonly _selection;
  private readonly _loadedComponents;
  private readonly _loadingViewId;
  private readonly _viewInjectors;
  /**
   * The slot identifier to render views for.
   *
   * @public
   */
  readonly slot: import("@angular/core").InputSignal<string>;
  /**
   * Optional initial view ID to display.
   * If not provided, the first available view will be selected.
   *
   * @public
   */
  readonly initialViewId: import("@angular/core").InputSignal<string | undefined>;
  /**
   * Constructs a new instance of the `ViewSlotOutletComponent` class.
   *
   * @public
   */
  constructor(registry?: ViewSlotRegistry, parentInjector?: Injector);
  /**
   * Updates the current selection.
   * This will filter views based on their `canActivate` predicates.
   *
   * @param selection - The new selection.
   *
   * @public
   */
  setSelection(selection: TSelection | null): void;
  /**
   * Gets the component for a view.
   * Returns null if the component hasn't been loaded yet.
   *
   * @param viewId - The ID of the view.
   * @returns The component type or null.
   *
   * @protected
   */
  protected getComponent(viewId: string): Type<unknown> | null;
  /**
   * Gets a stable injector for a specific view.
   * Injectors are cached per view ID to prevent unnecessary component re-creation.
   *
   * @param viewId - The ID of the view.
   * @returns The injector for the view.
   *
   * @public
   */
  getInjectorForView(viewId: string): Injector;
  /**
   * Gets the view definition for a specific view ID.
   *
   * @param viewId - The ID of the view.
   * @returns The view definition or undefined.
   *
   * @public
   */
  getViewDefinition(viewId: string): IViewSlotDefinition<TSelection> | undefined;
  /**
   * Resolves a badge value from static or dynamic definition.
   *
   * @param badge - The badge definition (static value or function).
   * @returns The resolved badge value or null.
   *
   * @public
   */
  resolveBadge(badge: string | number | (() => string | number | null) | undefined): string | number | null;
  private _isViewLoaded;
  private _loadViewComponent;
  private _addLoadedComponent;
  /**
   * All views available in the slot for the current selection.
   *
   * @public
   */
  readonly views: import("@angular/core").Signal<IViewSlotDefinition<TSelection>[]>;
  /**
   * Whether the outlet is currently loading a component.
   *
   * @public
   */
  readonly isLoading: import("@angular/core").Signal<boolean>;
  /**
   * Signal containing the loading view ID (for UI feedback).
   *
   * @public
   */
  readonly loadingViewId: import("@angular/core").Signal<string | null>;
  /**
   * Whether the outlet has any views available.
   *
   * @public
   */
  readonly hasViews: import("@angular/core").Signal<boolean>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ViewSlotOutletComponent<any>, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ViewSlotOutletComponent<any>, "mosaik-view-slot-outlet", never, {
    "slot": {
      "alias": "slot";
      "required": true;
      "isSignal": true;
    };
    "initialViewId": {
      "alias": "initialViewId";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * Represents the context data passed to view components within a slot.
 *
 * @typeParam TSelection - The type of selection data provided by the slot owner.
 * @public
 */
interface IViewSlotContext<TSelection = unknown> {
  /** Signal containing the current selection from the slot owner. */
  readonly selection: Signal<TSelection | null>;
  /** Signal indicating whether the slot owner is loading data. */
  readonly isLoading: Signal<boolean>;
  /** The unique identifier of the view within the slot. */
  readonly viewId: string;
  /** The slot identifier this view belongs to. */
  readonly slotId: string;
}
/**
 * Injection token for the view slot context.
 *
 * @public
 */
export declare const VIEW_SLOT_CONTEXT: InjectionToken<IViewSlotContext<unknown>>;
/**
 * Represents the provider interface for registering views to a slot with DI support.
 *
 * @typeParam TSelection - The type of selection the views expect.
 * @public
 */
interface IViewSlotProvider<TSelection = unknown> {
  /** Returns the view definitions to be registered in the slot. */
  getViews(): Array<IViewSlotDefinition<TSelection>>;
}
/**
 * Provides views to a named view slot using inline view definitions.
 *
 * @typeParam TSelection - The type of selection data the views expect.
 * @param slotId - The unique identifier of the target slot.
 * @param views - The view definitions to register.
 * @returns Angular environment providers for use in `makeEnvironmentProviders` or `provideX` functions.
 *
 * @example
 * ```typescript
 * provideViewSlot('profile', [
 *   { id: 'general', order: 0, loadComponent: () => import('./GeneralView').then(m => m.GeneralView) }
 * ])
 * ```
 *
 * @public
 */
export declare function provideViewSlot<TSelection = unknown>(slotId: string, views: Array<IViewSlotDefinition<TSelection>>): EnvironmentProviders;
/**
 * Provides views to a named view slot using an injectable provider class with DI support.
 *
 * @typeParam TSelection - The type of selection data the views expect.
 * @param slotId - The unique identifier of the target slot.
 * @param provider - The provider class implementing `IViewSlotProvider`.
 * @returns Angular environment providers for use in `makeEnvironmentProviders` or `provideX` functions.
 *
 * @example
 * ```typescript
 * provideViewSlotFrom('profile', ProfileViewProvider)
 * ```
 *
 * @public
 */
export declare function provideViewSlotFrom<TSelection = unknown>(slotId: string, provider: Type<IViewSlotProvider<TSelection>>): EnvironmentProviders;
/**
 * Typed data and the owning scheduler event exposed to a preview template.
 *
 * @public
 */
interface ISchedulerEventPopupContext<T> {
  $implicit: T;
  readonly event: SchedulerEventElement;
}
/**
 * Supplies a live Angular template for a scheduler event's hover preview.
 * The caller owns all content and layout; Mosaik owns hover and positioning.
 * Only an open preview allocates a view. Close, replacement and destruction
 * release that view. One stable root preserves Angular's dynamic child ownership
 * while the native popup projects the content through its portal.
 *
 * @example
 * ```html
 * <mosaik-scheduler-event [value]="appointment">
 *   <ng-template [mosaikSchedulerEventPopup]="appointment" let-item let-event="event">
 *     <article>{{ item.title }}</article>
 *   </ng-template>
 * </mosaik-scheduler-event>
 * ```
 *
 * @public
 */
export declare class SchedulerEventPopupDirective<T> {
  private readonly _template;
  private readonly _container;
  private readonly _document;
  private _view;
  private _root;
  constructor(_template?: TemplateRef<ISchedulerEventPopupContext<T>>, _container?: ViewContainerRef, _document?: Document, host?: SchedulerEventComponent, destroyRef?: DestroyRef);
  /**
   * The data exposed as `let-item`, inferred from the bound value's type.
   * Updating this input also updates an already open preview.
   *
   * @public
   */
  readonly value: InputSignal<T>;
  /** @public @static */
  static ngTemplateContextGuard<T>(_directive: SchedulerEventPopupDirective<T>, _context: unknown): _context is ISchedulerEventPopupContext<T>;
  private createView;
  private destroyView;
  static ɵfac: i0.ɵɵFactoryDeclaration<SchedulerEventPopupDirective<any>, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<SchedulerEventPopupDirective<any>, "ng-template[mosaikSchedulerEventPopup]", never, {
    "value": {
      "alias": "mosaikSchedulerEventPopup";
      "required": true;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export { type CancelReason, FORM_STATUS_HOST, FormFieldDirective, FormFieldStatusHostDirective, FormStatusHostDirective, type ICancel, type ICellDefContext, type IComboTriggerContext, type IDialogBehavior, type IDialogBreakpointBehaviorConfig, type IDialogConfig, type IDialogFeature, type IDialogRef, type IDrawerBehavior, type IDrawerBreakpointBehaviorConfig, type IDrawerConfig, type IDrawerRef, type IFooterCellDefContext, type IFormField, type IFormStatusHost, type IGlobalDomRef, type IHeaderCellDefContext, type IItemDefContext, type IItemVisualContext, type IMessageBoxBehavior, type IMessageBoxConfig, type IMessageBoxRef, type IOverlayBackdropConfig, type IPortalCloseAttempt, type IPortalOverlayOptions, type IPortalProviderBehavior, type IProvideMessageBoxesOptions, type ISchedulerEventPopupContext, type ISelectTriggerContext, type ISheetBehavior, type ISheetBreakpointBehaviorConfig, type ISheetConfig, type ISheetFeature, type ISheetRef, type IToastBehavior, type IToastBreakpointBehaviorConfig, type IToastConfig, type IToastFeature, type IToastRef, type IToastSlots, type ITourAccessor, type ITourAccessorTarget, type ITourFeature, type IViewSlotContext, type IViewSlotDefinition, type IViewSlotProvider, type IconInput, type IconLoader, type MethodMap, type PortalCloseAttemptTrigger, PortalProjectionDirective, ProxyCmp, type ReactiveValue, type ThemeOverride, type TourAccessorAnchorMap, type TourDefinitionFactory, type TourDefinitionSource, type ViewCanActivateFn, applyDefaults, defineCustomElement, forwardProxyOutputs, invokeElementMethod, invokeProxyMethod };
//# sourceMappingURL=mosaik-elements-angular.d.ts.map