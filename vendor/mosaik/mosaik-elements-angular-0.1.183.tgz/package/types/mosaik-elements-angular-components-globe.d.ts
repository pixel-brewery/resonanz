import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { GlobeElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/illustrations/globe/GlobeElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the GlobeComponent.
 * Use this token to provide default properties for the GlobeComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const GLOBE_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").IGlobeElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class GlobeComponent {
  /**
   * Signal input for the `duration` property.
   *
   * @public
   */
  readonly duration: InputSignal<GlobeElement['duration'] | undefined>;
  /**
   * Signal input for the `tilt` property.
   *
   * @public
   */
  readonly tilt: InputSignal<GlobeElement['tilt'] | undefined>;
  /**
   * Signal input for the `density` property.
   *
   * @public
   */
  readonly density: InputSignal<GlobeElement['density'] | undefined>;
  /**
   * Signal input for the `locations` property.
   *
   * @public
   */
  readonly locations: InputSignal<GlobeElement['locations'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<GlobeElement['themeName'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<GlobeElement['variant'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<GlobeElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<GlobeElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<GlobeElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<GlobeElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<GlobeElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof GlobeElement>(property: TProperty, value: GlobeElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<GlobeElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<GlobeComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<GlobeComponent, "mosaik-globe", never, {
    "duration": {
      "alias": "duration";
      "required": false;
      "isSignal": true;
    };
    "tilt": {
      "alias": "tilt";
      "required": false;
      "isSignal": true;
    };
    "density": {
      "alias": "density";
      "required": false;
      "isSignal": true;
    };
    "locations": {
      "alias": "locations";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on GlobeComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type GlobeMethodNames = never;
/**
 * Declares the methods interface for GlobeComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type GlobeComponentMethods = MethodMap<GlobeMethodNames>;
/**
 * @public
 */
export declare function provideGlobeComponent(config?: Partial<GlobeElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-globe.d.ts.map