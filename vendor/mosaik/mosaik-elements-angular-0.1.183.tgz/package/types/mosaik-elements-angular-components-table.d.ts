import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef, Type } from "@angular/core";
import { TableBodyCellElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/table/TableBodyCellElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { TableBodyRowElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/table/TableBodyRowElement";
import { TableBodyElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/table/TableBodyElement";
import { TableColumnEditorElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/table/editor/TableColumnEditorElement";
import { TableFooterCellElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/table/TableFooterCellElement";
import { TableFooterRowElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/table/TableFooterRowElement";
import { TableFooterElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/table/TableFooterElement";
import { TableHeaderCellElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/table/TableHeaderCellElement";
import { TableHeaderRowElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/table/TableHeaderRowElement";
import { TableHeaderElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/table/TableHeaderElement";
import { TableElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/table/TableElement";
/**
 * @public
 *
 * Injection token for the default properties of the TableBodyCellComponent.
 * Use this token to provide default properties for the TableBodyCellComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const TABLE_BODY_CELL_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/selectors/table/ITableBodyCellElementProps").ITableBodyCellElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class TableBodyCellComponent {
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<TableBodyCellElement['themeName'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<TableBodyCellElement['value'] | undefined>;
  /**
   * Signal input for the `isSelected` property.
   *
   * @public
   */
  readonly isSelected: InputSignal<TableBodyCellElement['isSelected'] | undefined>;
  /**
   * Signal input for the `text` property.
   *
   * @public
   */
  readonly text: InputSignal<TableBodyCellElement['text'] | undefined>;
  /**
   * Signal input for the `columnHidden` property.
   *
   * @public
   */
  readonly columnHidden: InputSignal<TableBodyCellElement['columnHidden'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<TableBodyCellElement['disabled'] | undefined>;
  /**
   * Signal input for the `formatter` property.
   *
   * @public
   */
  readonly formatter: InputSignal<TableBodyCellElement['formatter'] | undefined>;
  /**
   * Signal input for the `textOverflow` property.
   *
   * @public
   */
  readonly textOverflow: InputSignal<TableBodyCellElement['textOverflow'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<TableBodyCellElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<TableBodyCellElement['lang'] | undefined>;
  /**
   * Output signal for the `selected` event.
   *
   * @public
   */
  readonly selected: OutputEmitterRef<ElementEventDetail<TableBodyCellElement, 'selected'>>;
  /**
   * Output signal for the `deselected` event.
   *
   * @public
   */
  readonly deselected: OutputEmitterRef<ElementEventDetail<TableBodyCellElement, 'deselected'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<TableBodyCellElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<TableBodyCellElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<TableBodyCellElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Selects the element.
   *
   * @public
   */
  select(...args: Parameters<TableBodyCellElement['select']>): ReturnType<TableBodyCellElement['select']>;
  /**
   * Deselects the element.
   *
   * @public
   */
  deselect(...args: Parameters<TableBodyCellElement['deselect']>): ReturnType<TableBodyCellElement['deselect']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `select()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends TableBodyCellMethodNames>(method: TMethod, ...args: Parameters<TableBodyCellComponentMethods[TMethod]>): ReturnType<TableBodyCellComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof TableBodyCellElement>(property: TProperty, value: TableBodyCellElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<TableBodyCellElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<TableBodyCellComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<TableBodyCellComponent, "mosaik-table-body-cell", never, {
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "isSelected": {
      "alias": "isSelected";
      "required": false;
      "isSignal": true;
    };
    "text": {
      "alias": "text";
      "required": false;
      "isSignal": true;
    };
    "columnHidden": {
      "alias": "columnHidden";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "formatter": {
      "alias": "formatter";
      "required": false;
      "isSignal": true;
    };
    "textOverflow": {
      "alias": "textOverflow";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "selected": "selected";
    "deselected": "deselected";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on TableBodyCellComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TableBodyCellMethodNames = 'select' | 'deselect';
/**
 * Declares the methods interface for TableBodyCellComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TableBodyCellComponentMethods = MethodMap<TableBodyCellMethodNames>;
/**
 * @public
 */
export declare function provideTableBodyCellComponent(config?: Partial<TableBodyCellElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the TableBodyRowComponent.
 * Use this token to provide default properties for the TableBodyRowComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const TABLE_BODY_ROW_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/selectors/table/ITableBodyRowElementProps").ITableBodyRowElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot for body cells.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class TableBodyRowComponent {
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<TableBodyRowElement['themeName'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<TableBodyRowElement['value'] | undefined>;
  /**
   * Signal input for the `isSelected` property.
   *
   * @public
   */
  readonly isSelected: InputSignal<TableBodyRowElement['isSelected'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<TableBodyRowElement['disabled'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<TableBodyRowElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<TableBodyRowElement['lang'] | undefined>;
  /**
   * Output signal for the `selected` event.
   *
   * @public
   */
  readonly selected: OutputEmitterRef<ElementEventDetail<TableBodyRowElement, 'selected'>>;
  /**
   * Output signal for the `deselected` event.
   *
   * @public
   */
  readonly deselected: OutputEmitterRef<ElementEventDetail<TableBodyRowElement, 'deselected'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<TableBodyRowElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<TableBodyRowElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<TableBodyRowElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Selects the element.
   *
   * @public
   */
  select(...args: Parameters<TableBodyRowElement['select']>): ReturnType<TableBodyRowElement['select']>;
  /**
   * Deselects the element.
   *
   * @public
   */
  deselect(...args: Parameters<TableBodyRowElement['deselect']>): ReturnType<TableBodyRowElement['deselect']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `select()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends TableBodyRowMethodNames>(method: TMethod, ...args: Parameters<TableBodyRowComponentMethods[TMethod]>): ReturnType<TableBodyRowComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof TableBodyRowElement>(property: TProperty, value: TableBodyRowElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<TableBodyRowElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<TableBodyRowComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<TableBodyRowComponent, "mosaik-table-body-row", never, {
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "isSelected": {
      "alias": "isSelected";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "selected": "selected";
    "deselected": "deselected";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on TableBodyRowComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TableBodyRowMethodNames = 'select' | 'deselect';
/**
 * Declares the methods interface for TableBodyRowComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TableBodyRowComponentMethods = MethodMap<TableBodyRowMethodNames>;
/**
 * @public
 */
export declare function provideTableBodyRowComponent(config?: Partial<TableBodyRowElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the TableBodyComponent.
 * Use this token to provide default properties for the TableBodyComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const TABLE_BODY_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/selectors/table/ITableBodyElementProps").ITableBodyElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class TableBodyComponent {
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<TableBodyElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<TableBodyElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<TableBodyElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<TableBodyElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<TableBodyElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<TableBodyElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof TableBodyElement>(property: TProperty, value: TableBodyElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<TableBodyElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<TableBodyComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<TableBodyComponent, "mosaik-table-body", never, {
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on TableBodyComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TableBodyMethodNames = never;
/**
 * Declares the methods interface for TableBodyComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TableBodyComponentMethods = MethodMap<TableBodyMethodNames>;
/**
 * @public
 */
export declare function provideTableBodyComponent(config?: Partial<TableBodyElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the TableColumnEditorComponent.
 * Use this token to provide default properties for the TableColumnEditorComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const TABLE_COLUMN_EDITOR_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/selectors/table/editor/ITableColumnEditorElementProps").ITableColumnEditorElementProps>>;
/**
 * @public
 *
 * Injection token for the intl configuration of the TableColumnEditorComponent.
 * Provide a partial intl object or an injectable class that resolves translations.
 * This allows third-party applications to override the default intl labels
 * globally, per route, or per component via Angular's dependency injection.
 *
 * Merge order: Foundation defaults → DI intl → [intl] input binding.
 */
export declare const TABLE_COLUMN_EDITOR_INTL: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").TableColumnEditorElementIntl>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class TableColumnEditorComponent {
  /**
   * Signal input for the `columns` property.
   *
   * @public
   */
  readonly columns: InputSignal<TableColumnEditorElement['columns'] | undefined>;
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<Partial<TableColumnEditorElement['intl']> | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<TableColumnEditorElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<TableColumnEditorElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<TableColumnEditorElement['lang'] | undefined>;
  /**
   * Output signal for the `tableColumnEditorChanged` event.
   *
   * @public
   */
  readonly tableColumnEditorChanged: OutputEmitterRef<ElementEventDetail<TableColumnEditorElement, 'tableColumnEditorChanged'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<TableColumnEditorElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<TableColumnEditorElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<TableColumnEditorElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Dismisses the column editor by emitting the dismissed event.
   *
   * @public
   */
  dismiss(...args: Parameters<TableColumnEditorElement['dismiss']>): ReturnType<TableColumnEditorElement['dismiss']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `dismiss()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends TableColumnEditorMethodNames>(method: TMethod, ...args: Parameters<TableColumnEditorComponentMethods[TMethod]>): ReturnType<TableColumnEditorComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof TableColumnEditorElement>(property: TProperty, value: TableColumnEditorElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<TableColumnEditorElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<TableColumnEditorComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<TableColumnEditorComponent, "mosaik-table-column-editor", never, {
    "columns": {
      "alias": "columns";
      "required": false;
      "isSignal": true;
    };
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "tableColumnEditorChanged": "tableColumnEditorChanged";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on TableColumnEditorComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TableColumnEditorMethodNames = 'dismiss';
/**
 * Declares the methods interface for TableColumnEditorComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TableColumnEditorComponentMethods = MethodMap<TableColumnEditorMethodNames>;
/**
 * @public
 */
export declare function provideTableColumnEditorComponent(config?: Partial<TableColumnEditorElement.Props>, intl?: Partial<TableColumnEditorElement['intl']> | Type<Partial<TableColumnEditorElement['intl']>>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the TableFooterCellComponent.
 * Use this token to provide default properties for the TableFooterCellComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const TABLE_FOOTER_CELL_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/selectors/table/ITableFooterCellElementProps").ITableFooterCellElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class TableFooterCellComponent {
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<TableFooterCellElement['themeName'] | undefined>;
  /**
   * Signal input for the `text` property.
   *
   * @public
   */
  readonly text: InputSignal<TableFooterCellElement['text'] | undefined>;
  /**
   * Signal input for the `columnHidden` property.
   *
   * @public
   */
  readonly columnHidden: InputSignal<TableFooterCellElement['columnHidden'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<TableFooterCellElement['disabled'] | undefined>;
  /**
   * Signal input for the `formatter` property.
   *
   * @public
   */
  readonly formatter: InputSignal<TableFooterCellElement['formatter'] | undefined>;
  /**
   * Signal input for the `textOverflow` property.
   *
   * @public
   */
  readonly textOverflow: InputSignal<TableFooterCellElement['textOverflow'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<TableFooterCellElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<TableFooterCellElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<TableFooterCellElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<TableFooterCellElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<TableFooterCellElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof TableFooterCellElement>(property: TProperty, value: TableFooterCellElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<TableFooterCellElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<TableFooterCellComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<TableFooterCellComponent, "mosaik-table-footer-cell", never, {
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "text": {
      "alias": "text";
      "required": false;
      "isSignal": true;
    };
    "columnHidden": {
      "alias": "columnHidden";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "formatter": {
      "alias": "formatter";
      "required": false;
      "isSignal": true;
    };
    "textOverflow": {
      "alias": "textOverflow";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on TableFooterCellComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TableFooterCellMethodNames = never;
/**
 * Declares the methods interface for TableFooterCellComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TableFooterCellComponentMethods = MethodMap<TableFooterCellMethodNames>;
/**
 * @public
 */
export declare function provideTableFooterCellComponent(config?: Partial<TableFooterCellElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the TableFooterRowComponent.
 * Use this token to provide default properties for the TableFooterRowComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const TABLE_FOOTER_ROW_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/selectors/table/ITableFooterRowElementProps").ITableFooterRowElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot for footer cells.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class TableFooterRowComponent {
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<TableFooterRowElement['themeName'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<TableFooterRowElement['disabled'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<TableFooterRowElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<TableFooterRowElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<TableFooterRowElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<TableFooterRowElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<TableFooterRowElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof TableFooterRowElement>(property: TProperty, value: TableFooterRowElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<TableFooterRowElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<TableFooterRowComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<TableFooterRowComponent, "mosaik-table-footer-row", never, {
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on TableFooterRowComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TableFooterRowMethodNames = never;
/**
 * Declares the methods interface for TableFooterRowComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TableFooterRowComponentMethods = MethodMap<TableFooterRowMethodNames>;
/**
 * @public
 */
export declare function provideTableFooterRowComponent(config?: Partial<TableFooterRowElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the TableFooterComponent.
 * Use this token to provide default properties for the TableFooterComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const TABLE_FOOTER_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/selectors/table/ITableFooterElementProps").ITableFooterElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class TableFooterComponent {
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<TableFooterElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<TableFooterElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<TableFooterElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<TableFooterElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<TableFooterElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<TableFooterElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof TableFooterElement>(property: TProperty, value: TableFooterElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<TableFooterElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<TableFooterComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<TableFooterComponent, "mosaik-table-footer", never, {
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on TableFooterComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TableFooterMethodNames = never;
/**
 * Declares the methods interface for TableFooterComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TableFooterComponentMethods = MethodMap<TableFooterMethodNames>;
/**
 * @public
 */
export declare function provideTableFooterComponent(config?: Partial<TableFooterElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the TableHeaderCellComponent.
 * Use this token to provide default properties for the TableHeaderCellComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const TABLE_HEADER_CELL_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/selectors/table/ITableHeaderCellElementProps").ITableHeaderCellElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class TableHeaderCellComponent {
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<TableHeaderCellElement['intl'] | undefined>;
  /**
   * Signal input for the `key` property.
   *
   * @public
   */
  readonly key: InputSignal<TableHeaderCellElement['key'] | undefined>;
  /**
   * Signal input for the `sortable` property.
   *
   * @public
   */
  readonly sortable: InputSignal<TableHeaderCellElement['sortable'] | undefined>;
  /**
   * Signal input for the `pinable` property.
   *
   * @public
   */
  readonly pinable: InputSignal<TableHeaderCellElement['pinable'] | undefined>;
  /**
   * Signal input for the `sortDirection` property.
   *
   * @public
   */
  readonly sortDirection: InputSignal<TableHeaderCellElement['sortDirection'] | undefined>;
  /**
   * Signal input for the `resizable` property.
   *
   * @public
   */
  readonly resizable: InputSignal<TableHeaderCellElement['resizable'] | undefined>;
  /**
   * Signal input for the `minWidth` property.
   *
   * @public
   */
  readonly minWidth: InputSignal<TableHeaderCellElement['minWidth'] | undefined>;
  /**
   * Signal input for the `maxWidth` property.
   *
   * @public
   */
  readonly maxWidth: InputSignal<TableHeaderCellElement['maxWidth'] | undefined>;
  /**
   * Signal input for the `pinned` property.
   *
   * @public
   */
  readonly pinned: InputSignal<TableHeaderCellElement['pinned'] | undefined>;
  /**
   * Signal input for the `hideable` property.
   *
   * @public
   */
  readonly hideable: InputSignal<TableHeaderCellElement['hideable'] | undefined>;
  /**
   * Signal input for the `autoSizeable` property.
   *
   * @public
   */
  readonly autoSizeable: InputSignal<TableHeaderCellElement['autoSizeable'] | undefined>;
  /**
   * Signal input for the `columnChoosable` property.
   *
   * @public
   */
  readonly columnChoosable: InputSignal<TableHeaderCellElement['columnChoosable'] | undefined>;
  /**
   * Signal input for the `sortIndex` property.
   *
   * @public
   */
  readonly sortIndex: InputSignal<TableHeaderCellElement['sortIndex'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<TableHeaderCellElement['themeName'] | undefined>;
  /**
   * Signal input for the `text` property.
   *
   * @public
   */
  readonly text: InputSignal<TableHeaderCellElement['text'] | undefined>;
  /**
   * Signal input for the `columnHidden` property.
   *
   * @public
   */
  readonly columnHidden: InputSignal<TableHeaderCellElement['columnHidden'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<TableHeaderCellElement['disabled'] | undefined>;
  /**
   * Signal input for the `formatter` property.
   *
   * @public
   */
  readonly formatter: InputSignal<TableHeaderCellElement['formatter'] | undefined>;
  /**
   * Signal input for the `textOverflow` property.
   *
   * @public
   */
  readonly textOverflow: InputSignal<TableHeaderCellElement['textOverflow'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<TableHeaderCellElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<TableHeaderCellElement['lang'] | undefined>;
  /**
   * Output signal for the `tableSortChanged` event.
   *
   * @public
   */
  readonly tableSortChanged: OutputEmitterRef<ElementEventDetail<TableHeaderCellElement, 'tableSortChanged'>>;
  /**
   * Output signal for the `tableColumnResized` event.
   *
   * @public
   */
  readonly tableColumnResized: OutputEmitterRef<ElementEventDetail<TableHeaderCellElement, 'tableColumnResized'>>;
  /**
   * Output signal for the `tableRequestChooseColumns` event.
   *
   * @public
   */
  readonly tableRequestChooseColumns: OutputEmitterRef<ElementEventDetail<TableHeaderCellElement, 'tableRequestChooseColumns'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<TableHeaderCellElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<TableHeaderCellElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<TableHeaderCellElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sorts the cell in the specified direction.
   *
   * @public
   */
  sort(...args: Parameters<TableHeaderCellElement['sort']>): ReturnType<TableHeaderCellElement['sort']>;
  /**
   * Unsorts the cell.
   *
   * @public
   */
  unsort(...args: Parameters<TableHeaderCellElement['unsort']>): ReturnType<TableHeaderCellElement['unsort']>;
  /**
   * Starts the column resize operation.
   *
   * @public
   */
  startResize(...args: Parameters<TableHeaderCellElement['startResize']>): ReturnType<TableHeaderCellElement['startResize']>;
  /**
   * Sets the pinning position of this column.
   *
   * @public
   */
  pin(...args: Parameters<TableHeaderCellElement['pin']>): ReturnType<TableHeaderCellElement['pin']>;
  /**
   * Auto-sizes this column based on the widest content across header and body cells.
   *
   * @public
   */
  autoSize(...args: Parameters<TableHeaderCellElement['autoSize']>): ReturnType<TableHeaderCellElement['autoSize']>;
  /**
   * Requests the table to open the choose columns editor.
   * Dispatches a bubbling `tableRequestChooseColumns` event
   * that the parent `TableElement` will catch.
   *
   * @public
   */
  requestChooseColumns(...args: Parameters<TableHeaderCellElement['requestChooseColumns']>): ReturnType<TableHeaderCellElement['requestChooseColumns']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `sort()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends TableHeaderCellMethodNames>(method: TMethod, ...args: Parameters<TableHeaderCellComponentMethods[TMethod]>): ReturnType<TableHeaderCellComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof TableHeaderCellElement>(property: TProperty, value: TableHeaderCellElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<TableHeaderCellElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<TableHeaderCellComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<TableHeaderCellComponent, "mosaik-table-header-cell", never, {
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "key": {
      "alias": "key";
      "required": false;
      "isSignal": true;
    };
    "sortable": {
      "alias": "sortable";
      "required": false;
      "isSignal": true;
    };
    "pinable": {
      "alias": "pinable";
      "required": false;
      "isSignal": true;
    };
    "sortDirection": {
      "alias": "sortDirection";
      "required": false;
      "isSignal": true;
    };
    "resizable": {
      "alias": "resizable";
      "required": false;
      "isSignal": true;
    };
    "minWidth": {
      "alias": "minWidth";
      "required": false;
      "isSignal": true;
    };
    "maxWidth": {
      "alias": "maxWidth";
      "required": false;
      "isSignal": true;
    };
    "pinned": {
      "alias": "pinned";
      "required": false;
      "isSignal": true;
    };
    "hideable": {
      "alias": "hideable";
      "required": false;
      "isSignal": true;
    };
    "autoSizeable": {
      "alias": "autoSizeable";
      "required": false;
      "isSignal": true;
    };
    "columnChoosable": {
      "alias": "columnChoosable";
      "required": false;
      "isSignal": true;
    };
    "sortIndex": {
      "alias": "sortIndex";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "text": {
      "alias": "text";
      "required": false;
      "isSignal": true;
    };
    "columnHidden": {
      "alias": "columnHidden";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "formatter": {
      "alias": "formatter";
      "required": false;
      "isSignal": true;
    };
    "textOverflow": {
      "alias": "textOverflow";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "tableSortChanged": "tableSortChanged";
    "tableColumnResized": "tableColumnResized";
    "tableRequestChooseColumns": "tableRequestChooseColumns";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on TableHeaderCellComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TableHeaderCellMethodNames = 'sort' | 'unsort' | 'startResize' | 'pin' | 'autoSize' | 'requestChooseColumns';
/**
 * Declares the methods interface for TableHeaderCellComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TableHeaderCellComponentMethods = MethodMap<TableHeaderCellMethodNames>;
/**
 * @public
 */
export declare function provideTableHeaderCellComponent(config?: Partial<TableHeaderCellElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the TableHeaderRowComponent.
 * Use this token to provide default properties for the TableHeaderRowComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const TABLE_HEADER_ROW_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/selectors/table/ITableHeaderRowElementProps").ITableHeaderRowElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot for header cells.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class TableHeaderRowComponent {
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<TableHeaderRowElement['themeName'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<TableHeaderRowElement['disabled'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<TableHeaderRowElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<TableHeaderRowElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<TableHeaderRowElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<TableHeaderRowElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<TableHeaderRowElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof TableHeaderRowElement>(property: TProperty, value: TableHeaderRowElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<TableHeaderRowElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<TableHeaderRowComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<TableHeaderRowComponent, "mosaik-table-header-row", never, {
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on TableHeaderRowComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TableHeaderRowMethodNames = never;
/**
 * Declares the methods interface for TableHeaderRowComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TableHeaderRowComponentMethods = MethodMap<TableHeaderRowMethodNames>;
/**
 * @public
 */
export declare function provideTableHeaderRowComponent(config?: Partial<TableHeaderRowElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the TableHeaderComponent.
 * Use this token to provide default properties for the TableHeaderComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const TABLE_HEADER_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/selectors/table/ITableHeaderElementProps").ITableHeaderElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class TableHeaderComponent {
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<TableHeaderElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<TableHeaderElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<TableHeaderElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<TableHeaderElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<TableHeaderElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<TableHeaderElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof TableHeaderElement>(property: TProperty, value: TableHeaderElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<TableHeaderElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<TableHeaderComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<TableHeaderComponent, "mosaik-table-header", never, {
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on TableHeaderComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TableHeaderMethodNames = never;
/**
 * Declares the methods interface for TableHeaderComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TableHeaderComponentMethods = MethodMap<TableHeaderMethodNames>;
/**
 * @public
 */
export declare function provideTableHeaderComponent(config?: Partial<TableHeaderElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the TableComponent.
 * Use this token to provide default properties for the TableComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const TABLE_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/selectors/table/ITableElementProps").ITableElementProps>>;
/**
 * @public
 *
 * Injection token for the intl configuration of the TableComponent.
 * Provide a partial intl object or an injectable class that resolves translations.
 * This allows third-party applications to override the default intl labels
 * globally, per route, or per component via Angular's dependency injection.
 *
 * Merge order: Foundation defaults → DI intl → [intl] input binding.
 */
export declare const TABLE_INTL: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").TableElementIntl>>;
/**
 * @public
 *
 * @slot  - The default slot.
 * @slot caption - The caption slot for the table title or description.
 * @slot summary - The summary slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class TableComponent {
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<Partial<TableElement['intl']> | undefined>;
  /**
   * Signal input for the `columns` property.
   *
   * @public
   */
  readonly columns: InputSignal<TableElement['columns'] | undefined>;
  /**
   * Signal input for the `caption` property.
   *
   * @public
   */
  readonly caption: InputSignal<TableElement['caption'] | undefined>;
  /**
   * Signal input for the `alternating` property.
   *
   * @public
   */
  readonly alternating: InputSignal<TableElement['alternating'] | undefined>;
  /**
   * Signal input for the `selectionType` property.
   *
   * @public
   */
  readonly selectionType: InputSignal<TableElement['selectionType'] | undefined>;
  /**
   * Signal input for the `selectionMode` property.
   *
   * @public
   */
  readonly selectionMode: InputSignal<TableElement['selectionMode'] | undefined>;
  /**
   * Signal input for the `resizable` property.
   *
   * @public
   */
  readonly resizable: InputSignal<TableElement['resizable'] | undefined>;
  /**
   * Signal input for the `sortMode` property.
   *
   * @public
   */
  readonly sortMode: InputSignal<TableElement['sortMode'] | undefined>;
  /**
   * Signal input for the `selectionColumn` property.
   *
   * @public
   */
  readonly selectionColumn: InputSignal<TableElement['selectionColumn'] | undefined>;
  /**
   * Signal input for the `rowClickSelects` property.
   *
   * @public
   */
  readonly rowClickSelects: InputSignal<TableElement['rowClickSelects'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<TableElement['themeName'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<TableElement['appearance'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<TableElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<TableElement['lang'] | undefined>;
  /**
   * Output signal for the `columnsChanged` event.
   *
   * @public
   */
  readonly columnsChanged: OutputEmitterRef<ElementEventDetail<TableElement, 'columnsChanged'>>;
  /**
   * Output signal for the `tableSelectionChanged` event.
   *
   * @public
   */
  readonly tableSelectionChanged: OutputEmitterRef<ElementEventDetail<TableElement, 'tableSelectionChanged'>>;
  /**
   * Output signal for the `tableChooseColumns` event.
   *
   * @public
   */
  readonly tableChooseColumns: OutputEmitterRef<ElementEventDetail<TableElement, 'tableChooseColumns'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<TableElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<TableElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<TableElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: TableElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: TableElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Selects every selectable body row.
   *
   * @public
   */
  selectAll(...args: Parameters<TableElement['selectAll']>): ReturnType<TableElement['selectAll']>;
  /**
   * Clears the current row and cell selection.
   *
   * @public
   */
  clearSelection(...args: Parameters<TableElement['clearSelection']>): ReturnType<TableElement['clearSelection']>;
  /**
   * Returns metadata for each column derived from header cells.
   * Used by rows to propagate pinning and hiding to body/footer cells.
   *
   * @public
   */
  getColumnMetadata(...args: Parameters<TableElement['getColumnMetadata']>): ReturnType<TableElement['getColumnMetadata']>;
  /**
   * Auto-sizes a column to fit the widest content across header and body cells.
   * Uses `getContentWidth()` on each cell for accurate measurement that handles
   * truncated text, flex-constrained layouts and shadow DOM content.
   *
   * @public
   */
  autoSizeColumn(...args: Parameters<TableElement['autoSizeColumn']>): ReturnType<TableElement['autoSizeColumn']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<TableElement['assignToSlot']>): ReturnType<TableElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<TableElement['getSlotContent']>): ReturnType<TableElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<TableElement['hasSlotContent']>): ReturnType<TableElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<TableElement['hasSlot']>): ReturnType<TableElement['hasSlot']>;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<TableElement['onSlotChanges']>): ReturnType<TableElement['onSlotChanges']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `selectAll()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends TableMethodNames>(method: TMethod, ...args: Parameters<TableComponentMethods[TMethod]>): ReturnType<TableComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof TableElement>(property: TProperty, value: TableElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<TableElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<TableComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<TableComponent, "mosaik-table", never, {
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "columns": {
      "alias": "columns";
      "required": false;
      "isSignal": true;
    };
    "caption": {
      "alias": "caption";
      "required": false;
      "isSignal": true;
    };
    "alternating": {
      "alias": "alternating";
      "required": false;
      "isSignal": true;
    };
    "selectionType": {
      "alias": "selectionType";
      "required": false;
      "isSignal": true;
    };
    "selectionMode": {
      "alias": "selectionMode";
      "required": false;
      "isSignal": true;
    };
    "resizable": {
      "alias": "resizable";
      "required": false;
      "isSignal": true;
    };
    "sortMode": {
      "alias": "sortMode";
      "required": false;
      "isSignal": true;
    };
    "selectionColumn": {
      "alias": "selectionColumn";
      "required": false;
      "isSignal": true;
    };
    "rowClickSelects": {
      "alias": "rowClickSelects";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "columnsChanged": "columnsChanged";
    "tableSelectionChanged": "tableSelectionChanged";
    "tableChooseColumns": "tableChooseColumns";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on TableComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TableMethodNames = 'selectAll' | 'clearSelection' | 'getColumnMetadata' | 'autoSizeColumn' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges';
/**
 * Declares the methods interface for TableComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TableComponentMethods = MethodMap<TableMethodNames>;
/**
 * @public
 */
export declare function provideTableComponent(config?: Partial<TableElement.Props>, intl?: Partial<TableElement['intl']> | Type<Partial<TableElement['intl']>>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-table.d.ts.map