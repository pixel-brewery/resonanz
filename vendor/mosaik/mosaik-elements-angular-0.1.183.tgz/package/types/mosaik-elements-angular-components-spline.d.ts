import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { SplineElement } from "@pixel-brewery/mosaik-elements-foundation/components/spline";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the SplineComponent.
 * Use this token to provide default properties for the SplineComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const SPLINE_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation/components/spline").ISplineElementProps>>;
/**
 * @public
 *
 * @slot  - A readable description or poster, shown while empty, waiting, loading, static or failed.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class SplineComponent {
  /**
   * Signal input for the `scene` property.
   *
   * @public
   */
  readonly scene: InputSignal<SplineElement['scene'] | undefined>;
  /**
   * Signal input for the `interactive` property.
   *
   * @public
   */
  readonly interactive: InputSignal<SplineElement['interactive'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<SplineElement['themeName'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<SplineElement['variant'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<SplineElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<SplineElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<SplineElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<SplineElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<SplineElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof SplineElement>(property: TProperty, value: SplineElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<SplineElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SplineComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SplineComponent, "mosaik-spline", never, {
    "scene": {
      "alias": "scene";
      "required": false;
      "isSignal": true;
    };
    "interactive": {
      "alias": "interactive";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on SplineComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SplineMethodNames = never;
/**
 * Declares the methods interface for SplineComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SplineComponentMethods = MethodMap<SplineMethodNames>;
/**
 * @public
 */
export declare function provideSplineComponent(config?: Partial<SplineElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-spline.d.ts.map