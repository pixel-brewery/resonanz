import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { GridItemElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/grid/GridItemElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { GridElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/layouts/grid/GridElement";
/**
 * @public
 *
 * Injection token for the default properties of the GridItemComponent.
 * Use this token to provide default properties for the GridItemComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const GRID_ITEM_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/layouts/grid/IGridItemElementProps").IGridItemElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class GridItemComponent {
  /**
   * Signal input for the `column` property.
   *
   * @public
   */
  readonly column: InputSignal<GridItemElement['column'] | undefined>;
  /**
   * Signal input for the `columnSpan` property.
   *
   * @public
   */
  readonly columnSpan: InputSignal<GridItemElement['columnSpan'] | undefined>;
  /**
   * Signal input for the `row` property.
   *
   * @public
   */
  readonly row: InputSignal<GridItemElement['row'] | undefined>;
  /**
   * Signal input for the `rowSpan` property.
   *
   * @public
   */
  readonly rowSpan: InputSignal<GridItemElement['rowSpan'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<GridItemElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<GridItemElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<GridItemElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<GridItemElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<GridItemElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<GridItemElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof GridItemElement>(property: TProperty, value: GridItemElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<GridItemElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<GridItemComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<GridItemComponent, "mosaik-grid-item", never, {
    "column": {
      "alias": "column";
      "required": false;
      "isSignal": true;
    };
    "columnSpan": {
      "alias": "columnSpan";
      "required": false;
      "isSignal": true;
    };
    "row": {
      "alias": "row";
      "required": false;
      "isSignal": true;
    };
    "rowSpan": {
      "alias": "rowSpan";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on GridItemComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type GridItemMethodNames = never;
/**
 * Declares the methods interface for GridItemComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type GridItemComponentMethods = MethodMap<GridItemMethodNames>;
/**
 * @public
 */
export declare function provideGridItemComponent(config?: Partial<GridItemElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the GridComponent.
 * Use this token to provide default properties for the GridComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const GRID_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/layouts/grid/IGridElementProps").IGridElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot for grid items.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class GridComponent {
  /**
   * Signal input for the `rowDefinitions` property.
   *
   * @public
   */
  readonly rowDefinitions: InputSignal<GridElement['rowDefinitions'] | undefined>;
  /**
   * Signal input for the `columnDefinitions` property.
   *
   * @public
   */
  readonly columnDefinitions: InputSignal<GridElement['columnDefinitions'] | undefined>;
  /**
   * Signal input for the `gap` property.
   *
   * @public
   */
  readonly gap: InputSignal<GridElement['gap'] | undefined>;
  /**
   * Signal input for the `horizontalAlignment` property.
   *
   * @public
   */
  readonly horizontalAlignment: InputSignal<GridElement['horizontalAlignment'] | undefined>;
  /**
   * Signal input for the `verticalAlignment` property.
   *
   * @public
   */
  readonly verticalAlignment: InputSignal<GridElement['verticalAlignment'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<GridElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<GridElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<GridElement['lang'] | undefined>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<GridElement, 'changed'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<GridElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<GridElement, 'disconnected'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof GridElement>(property: TProperty, value: GridElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<GridElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<GridComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<GridComponent, "mosaik-grid", never, {
    "rowDefinitions": {
      "alias": "rowDefinitions";
      "required": false;
      "isSignal": true;
    };
    "columnDefinitions": {
      "alias": "columnDefinitions";
      "required": false;
      "isSignal": true;
    };
    "gap": {
      "alias": "gap";
      "required": false;
      "isSignal": true;
    };
    "horizontalAlignment": {
      "alias": "horizontalAlignment";
      "required": false;
      "isSignal": true;
    };
    "verticalAlignment": {
      "alias": "verticalAlignment";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "changed": "changed";
    "connected": "connected";
    "disconnected": "disconnected";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on GridComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type GridMethodNames = never;
/**
 * Declares the methods interface for GridComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type GridComponentMethods = MethodMap<GridMethodNames>;
/**
 * @public
 */
export declare function provideGridComponent(config?: Partial<GridElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-grid.d.ts.map