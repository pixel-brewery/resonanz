import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { BannerGroupElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/grouping/banner-group/BannerGroupElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the BannerGroupComponent.
 * Use this token to provide default properties for the BannerGroupComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const BANNER_GROUP_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/grouping/banner-group/IBannerGroupElementProps").IBannerGroupElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot for banner items.
 * @slot next - Slot for a custom next control.
 * @slot prev - Slot for a custom previous control.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class BannerGroupComponent {
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<BannerGroupElement['intl'] | undefined>;
  /**
   * Signal input for the `index` property.
   *
   * @public
   */
  readonly index: InputSignal<BannerGroupElement['index'] | undefined>;
  /**
   * Signal input for the `loop` property.
   *
   * @public
   */
  readonly loop: InputSignal<BannerGroupElement['loop'] | undefined>;
  /**
   * Signal input for the `pager` property.
   *
   * @public
   */
  readonly pager: InputSignal<BannerGroupElement['pager'] | undefined>;
  /**
   * Signal input for the `maxLength` property.
   *
   * @public
   */
  readonly maxLength: InputSignal<BannerGroupElement['maxLength'] | undefined>;
  /**
   * Signal input for the `dismissBehavior` property.
   *
   * @public
   */
  readonly dismissBehavior: InputSignal<BannerGroupElement['dismissBehavior'] | undefined>;
  /**
   * Signal input for the `stacking` property.
   *
   * @public
   */
  readonly stacking: InputSignal<BannerGroupElement['stacking'] | undefined>;
  /**
   * Signal input for the `reverse` property.
   *
   * @public
   */
  readonly reverse: InputSignal<BannerGroupElement['reverse'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<BannerGroupElement['themeName'] | undefined>;
  /**
   * Signal input for the `orientation` property.
   *
   * @public
   */
  readonly orientation: InputSignal<BannerGroupElement['orientation'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<BannerGroupElement['disabled'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<BannerGroupElement['appearance'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<BannerGroupElement['variant'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<BannerGroupElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<BannerGroupElement['lang'] | undefined>;
  /**
   * Output signal for the `change` event.
   *
   * @public
   */
  readonly change: OutputEmitterRef<ElementEventDetail<BannerGroupElement, 'change'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<BannerGroupElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<BannerGroupElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<BannerGroupElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: BannerGroupElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: BannerGroupElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Navigates to the previous banner.
   *
   * @public
   */
  previous(...args: Parameters<BannerGroupElement['previous']>): ReturnType<BannerGroupElement['previous']>;
  /**
   * Navigates to the next banner.
   *
   * @public
   */
  next(...args: Parameters<BannerGroupElement['next']>): ReturnType<BannerGroupElement['next']>;
  /**
   * Navigates to the first banner.
   *
   * @public
   */
  first(...args: Parameters<BannerGroupElement['first']>): ReturnType<BannerGroupElement['first']>;
  /**
   * Navigates to the last banner.
   *
   * @public
   */
  last(...args: Parameters<BannerGroupElement['last']>): ReturnType<BannerGroupElement['last']>;
  /**
   * Navigates to a specific index.
   *
   * @public
   */
  goTo(...args: Parameters<BannerGroupElement['goTo']>): ReturnType<BannerGroupElement['goTo']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<BannerGroupElement['assignToSlot']>): ReturnType<BannerGroupElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<BannerGroupElement['getSlotContent']>): ReturnType<BannerGroupElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<BannerGroupElement['hasSlotContent']>): ReturnType<BannerGroupElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<BannerGroupElement['hasSlot']>): ReturnType<BannerGroupElement['hasSlot']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `previous()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends BannerGroupMethodNames>(method: TMethod, ...args: Parameters<BannerGroupComponentMethods[TMethod]>): ReturnType<BannerGroupComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof BannerGroupElement>(property: TProperty, value: BannerGroupElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<BannerGroupElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<BannerGroupComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<BannerGroupComponent, "mosaik-banner-group", never, {
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "index": {
      "alias": "index";
      "required": false;
      "isSignal": true;
    };
    "loop": {
      "alias": "loop";
      "required": false;
      "isSignal": true;
    };
    "pager": {
      "alias": "pager";
      "required": false;
      "isSignal": true;
    };
    "maxLength": {
      "alias": "maxLength";
      "required": false;
      "isSignal": true;
    };
    "dismissBehavior": {
      "alias": "dismissBehavior";
      "required": false;
      "isSignal": true;
    };
    "stacking": {
      "alias": "stacking";
      "required": false;
      "isSignal": true;
    };
    "reverse": {
      "alias": "reverse";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "orientation": {
      "alias": "orientation";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "change": "change";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on BannerGroupComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type BannerGroupMethodNames = 'previous' | 'next' | 'first' | 'last' | 'goTo' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot';
/**
 * Declares the methods interface for BannerGroupComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type BannerGroupComponentMethods = MethodMap<BannerGroupMethodNames>;
/**
 * @public
 */
export declare function provideBannerGroupComponent(config?: Partial<BannerGroupElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-banner-group.d.ts.map