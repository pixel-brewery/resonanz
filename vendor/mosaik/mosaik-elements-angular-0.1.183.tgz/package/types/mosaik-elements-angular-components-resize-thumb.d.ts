import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { ResizeThumbElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/resize-thumb/ResizeThumbElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the ResizeThumbComponent.
 * Use this token to provide default properties for the ResizeThumbComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const RESIZE_THUMB_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/primitives/resize-thumb/IResizeThumbElementProps").IResizeThumbElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ResizeThumbComponent {
  /**
   * Signal input for the `direction` property.
   *
   * @public
   */
  readonly direction: InputSignal<ResizeThumbElement['direction'] | undefined>;
  /**
   * Signal input for the `allowedDirections` property.
   *
   * @public
   */
  readonly allowedDirections: InputSignal<ResizeThumbElement['allowedDirections'] | undefined>;
  /**
   * Signal input for the `minWidth` property.
   *
   * @public
   */
  readonly minWidth: InputSignal<ResizeThumbElement['minWidth'] | undefined>;
  /**
   * Signal input for the `minHeight` property.
   *
   * @public
   */
  readonly minHeight: InputSignal<ResizeThumbElement['minHeight'] | undefined>;
  /**
   * Signal input for the `maxWidth` property.
   *
   * @public
   */
  readonly maxWidth: InputSignal<ResizeThumbElement['maxWidth'] | undefined>;
  /**
   * Signal input for the `maxHeight` property.
   *
   * @public
   */
  readonly maxHeight: InputSignal<ResizeThumbElement['maxHeight'] | undefined>;
  /**
   * Signal input for the `autoApply` property.
   *
   * @public
   */
  readonly autoApply: InputSignal<ResizeThumbElement['autoApply'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ResizeThumbElement['themeName'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<ResizeThumbElement['disabled'] | undefined>;
  /**
   * Signal input for the `for` property.
   *
   * @public
   */
  readonly for: InputSignal<ResizeThumbElement['for'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ResizeThumbElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ResizeThumbElement['lang'] | undefined>;
  /**
   * Output signal for the `resizeStart` event.
   *
   * @public
   */
  readonly resizeStart: OutputEmitterRef<ElementEventDetail<ResizeThumbElement, 'resizeStart'>>;
  /**
   * Output signal for the `resizing` event.
   *
   * @public
   */
  readonly resizing: OutputEmitterRef<ElementEventDetail<ResizeThumbElement, 'resizing'>>;
  /**
   * Output signal for the `resizeEnd` event.
   *
   * @public
   */
  readonly resizeEnd: OutputEmitterRef<ElementEventDetail<ResizeThumbElement, 'resizeEnd'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ResizeThumbElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ResizeThumbElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ResizeThumbElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Attaches the element to an interactive control.
   *
   * @public
   */
  attach(...args: Parameters<ResizeThumbElement['attach']>): ReturnType<ResizeThumbElement['attach']>;
  /**
   * Detaches the element from its current control.
   *
   * @public
   */
  detach(...args: Parameters<ResizeThumbElement['detach']>): ReturnType<ResizeThumbElement['detach']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `attach()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends ResizeThumbMethodNames>(method: TMethod, ...args: Parameters<ResizeThumbComponentMethods[TMethod]>): ReturnType<ResizeThumbComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ResizeThumbElement>(property: TProperty, value: ResizeThumbElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ResizeThumbElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ResizeThumbComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ResizeThumbComponent, "mosaik-resize-thumb", never, {
    "direction": {
      "alias": "direction";
      "required": false;
      "isSignal": true;
    };
    "allowedDirections": {
      "alias": "allowedDirections";
      "required": false;
      "isSignal": true;
    };
    "minWidth": {
      "alias": "minWidth";
      "required": false;
      "isSignal": true;
    };
    "minHeight": {
      "alias": "minHeight";
      "required": false;
      "isSignal": true;
    };
    "maxWidth": {
      "alias": "maxWidth";
      "required": false;
      "isSignal": true;
    };
    "maxHeight": {
      "alias": "maxHeight";
      "required": false;
      "isSignal": true;
    };
    "autoApply": {
      "alias": "autoApply";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "for": {
      "alias": "for";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "resizeStart": "resizeStart";
    "resizing": "resizing";
    "resizeEnd": "resizeEnd";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on ResizeThumbComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ResizeThumbMethodNames = 'attach' | 'detach';
/**
 * Declares the methods interface for ResizeThumbComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ResizeThumbComponentMethods = MethodMap<ResizeThumbMethodNames>;
/**
 * @public
 */
export declare function provideResizeThumbComponent(config?: Partial<ResizeThumbElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-resize-thumb.d.ts.map