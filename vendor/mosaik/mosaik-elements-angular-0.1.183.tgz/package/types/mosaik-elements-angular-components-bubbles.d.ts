import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { BubblesElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/illustrations/bubbles/BubblesElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the BubblesComponent.
 * Use this token to provide default properties for the BubblesComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const BUBBLES_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").IBubblesElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class BubblesComponent {
  /**
   * Signal input for the `quantity` property.
   *
   * @public
   */
  readonly quantity: InputSignal<BubblesElement['quantity'] | undefined>;
  /**
   * Signal input for the `text` property.
   *
   * @public
   */
  readonly text: InputSignal<BubblesElement['text'] | undefined>;
  /**
   * Signal input for the `direction` property.
   *
   * @public
   */
  readonly direction: InputSignal<BubblesElement['direction'] | undefined>;
  /**
   * Signal input for the `duration` property.
   *
   * @public
   */
  readonly duration: InputSignal<BubblesElement['duration'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<BubblesElement['themeName'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<BubblesElement['variant'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<BubblesElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<BubblesElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<BubblesElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<BubblesElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<BubblesElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof BubblesElement>(property: TProperty, value: BubblesElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<BubblesElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<BubblesComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<BubblesComponent, "mosaik-bubbles", never, {
    "quantity": {
      "alias": "quantity";
      "required": false;
      "isSignal": true;
    };
    "text": {
      "alias": "text";
      "required": false;
      "isSignal": true;
    };
    "direction": {
      "alias": "direction";
      "required": false;
      "isSignal": true;
    };
    "duration": {
      "alias": "duration";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on BubblesComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type BubblesMethodNames = never;
/**
 * Declares the methods interface for BubblesComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type BubblesComponentMethods = MethodMap<BubblesMethodNames>;
/**
 * @public
 */
export declare function provideBubblesComponent(config?: Partial<BubblesElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-bubbles.d.ts.map