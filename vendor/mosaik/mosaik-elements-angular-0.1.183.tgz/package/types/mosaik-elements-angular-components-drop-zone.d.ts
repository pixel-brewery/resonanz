import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { DropZoneElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/drop-zone/DropZoneElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the DropZoneComponent.
 * Use this token to provide default properties for the DropZoneComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const DROP_ZONE_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/primitives/drop-zone/IDropZoneElementProps").IDropZoneElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot for content displayed inside the drop zone.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class DropZoneComponent {
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<DropZoneElement['themeName'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<DropZoneElement['disabled'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<DropZoneElement['appearance'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<DropZoneElement['variant'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<DropZoneElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<DropZoneElement['lang'] | undefined>;
  /**
   * Output signal for the `dropZoneData` event.
   *
   * @public
   */
  readonly dropZoneData: OutputEmitterRef<ElementEventDetail<DropZoneElement, 'dropZoneData'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<DropZoneElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<DropZoneElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<DropZoneElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof DropZoneElement>(property: TProperty, value: DropZoneElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<DropZoneElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<DropZoneComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<DropZoneComponent, "mosaik-drop-zone", never, {
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "dropZoneData": "dropZoneData";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on DropZoneComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type DropZoneMethodNames = never;
/**
 * Declares the methods interface for DropZoneComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type DropZoneComponentMethods = MethodMap<DropZoneMethodNames>;
/**
 * @public
 */
export declare function provideDropZoneComponent(config?: Partial<DropZoneElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-drop-zone.d.ts.map