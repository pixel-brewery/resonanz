import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { ControlValueAccessor } from "@angular/forms";
import { ToggleButtonGroupElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/buttons/toggle-button/ToggleButtonGroupElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import * as i1 from "@pixel-brewery/mosaik-elements-angular/runtime";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { ToggleButtonElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/buttons/toggle-button/ToggleButtonElement";
/**
 * @public
 *
 * Injection token for the default properties of the ToggleButtonGroupComponent.
 * Use this token to provide default properties for the ToggleButtonGroupComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const TOGGLE_BUTTON_GROUP_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/buttons/toggle-button/IToggleButtonGroupElementProps").IToggleButtonGroupElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot for toggle buttons.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ToggleButtonGroupComponent implements ControlValueAccessor {
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ToggleButtonGroupElement['themeName'] | undefined>;
  /**
   * Signal input for the `invalid` property.
   *
   * @public
   */
  readonly invalid: InputSignal<ToggleButtonGroupElement['invalid'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<ToggleButtonGroupElement['disabled'] | undefined>;
  /**
   * Signal input for the `orientation` property.
   *
   * @public
   */
  readonly orientation: InputSignal<ToggleButtonGroupElement['orientation'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<ToggleButtonGroupElement['value'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<ToggleButtonGroupElement['appearance'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<ToggleButtonGroupElement['variant'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ToggleButtonGroupElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ToggleButtonGroupElement['lang'] | undefined>;
  /**
   * Output signal for the `groupChanged` event.
   *
   * @public
   */
  readonly groupChanged: OutputEmitterRef<ElementEventDetail<ToggleButtonGroupElement, 'groupChanged'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ToggleButtonGroupElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ToggleButtonGroupElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ToggleButtonGroupElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: ToggleButtonGroupElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: ToggleButtonGroupElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  private readonly _accessor;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Applies a value supplied by Angular forms to the native control.
   *
   * @public
   */
  writeValue(obj: unknown): void;
  /**
   * Registers the callback notified when the native control value changes.
   *
   * @public
   */
  registerOnChange(fn: unknown): void;
  /**
   * Registers the callback notified when the native control is touched.
   *
   * @public
   */
  registerOnTouched(fn: unknown): void;
  /**
   * Applies the disabled state supplied by Angular forms.
   *
   * @public
   */
  setDisabledState?(isDisabled: boolean): void;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<ToggleButtonGroupElement['onSlotChanges']>): ReturnType<ToggleButtonGroupElement['onSlotChanges']>;
  /**
   * Returns whether a form will validate when it is submitted, without having to submit it.
   *
   * @public
   */
  checkValidity(...args: Parameters<ToggleButtonGroupElement['checkValidity']>): ReturnType<ToggleButtonGroupElement['checkValidity']>;
  /**
   * Resets the element to its initial state: no toggle button is selected and the value is cleared.
   *
   * @public
   */
  reset(...args: Parameters<ToggleButtonGroupElement['reset']>): ReturnType<ToggleButtonGroupElement['reset']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<ToggleButtonGroupElement['assignToSlot']>): ReturnType<ToggleButtonGroupElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<ToggleButtonGroupElement['getSlotContent']>): ReturnType<ToggleButtonGroupElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<ToggleButtonGroupElement['hasSlotContent']>): ReturnType<ToggleButtonGroupElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<ToggleButtonGroupElement['hasSlot']>): ReturnType<ToggleButtonGroupElement['hasSlot']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `onSlotChanges()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends ToggleButtonGroupMethodNames>(method: TMethod, ...args: Parameters<ToggleButtonGroupComponentMethods[TMethod]>): ReturnType<ToggleButtonGroupComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ToggleButtonGroupElement>(property: TProperty, value: ToggleButtonGroupElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ToggleButtonGroupElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ToggleButtonGroupComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ToggleButtonGroupComponent, "mosaik-toggle-button-group", never, {
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "invalid": {
      "alias": "invalid";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "orientation": {
      "alias": "orientation";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "groupChanged": "groupChanged";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, [{
    directive: typeof i1.FormStatusHostDirective;
    inputs: {};
    outputs: {};
  }, {
    directive: typeof i1.FormFieldStatusHostDirective;
    inputs: {};
    outputs: {};
  }]>;
}
/**
 * Declares the methods available on ToggleButtonGroupComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ToggleButtonGroupMethodNames = 'onSlotChanges' | 'checkValidity' | 'reset' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot';
/**
 * Declares the methods interface for ToggleButtonGroupComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ToggleButtonGroupComponentMethods = MethodMap<ToggleButtonGroupMethodNames>;
/**
 * @public
 */
export declare function provideToggleButtonGroupComponent(config?: Partial<ToggleButtonGroupElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the ToggleButtonComponent.
 * Use this token to provide default properties for the ToggleButtonComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const TOGGLE_BUTTON_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/buttons/toggle-button/IToggleButtonElementProps").IToggleButtonElementProps>>;
/**
 * @public
 *
 * @slot icon - Icon content area for visual state representation and identification
 * @slot label - Text label content area for button identification and description
 * @slot overlay - Overlay content area for badges, notifications, or additional state indicators
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ToggleButtonComponent implements ControlValueAccessor {
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ToggleButtonElement['themeName'] | undefined>;
  /**
   * Signal input for the `reverse` property.
   *
   * @public
   */
  readonly reverse: InputSignal<ToggleButtonElement['reverse'] | undefined>;
  /**
   * Signal input for the `orientation` property.
   *
   * @public
   */
  readonly orientation: InputSignal<ToggleButtonElement['orientation'] | undefined>;
  /**
   * Signal input for the `horizontalContentAlignment` property.
   *
   * @public
   */
  readonly horizontalContentAlignment: InputSignal<ToggleButtonElement['horizontalContentAlignment'] | undefined>;
  /**
   * Signal input for the `verticalContentAlignment` property.
   *
   * @public
   */
  readonly verticalContentAlignment: InputSignal<ToggleButtonElement['verticalContentAlignment'] | undefined>;
  /**
   * Signal input for the `fit` property.
   *
   * @public
   */
  readonly fit: InputSignal<ToggleButtonElement['fit'] | undefined>;
  /**
   * Signal input for the `isBusy` property.
   *
   * @public
   */
  readonly isBusy: InputSignal<ToggleButtonElement['isBusy'] | undefined>;
  /**
   * Signal input for the `isChecked` property.
   *
   * @public
   */
  readonly isChecked: InputSignal<ToggleButtonElement['isChecked'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<ToggleButtonElement['label'] | undefined>;
  /**
   * Signal input for the `icon` property.
   *
   * @public
   */
  readonly icon: InputSignal<ToggleButtonElement['icon'] | undefined>;
  /**
   * Signal input for the `iconPosition` property.
   *
   * @public
   */
  readonly iconPosition: InputSignal<ToggleButtonElement['iconPosition'] | undefined>;
  /**
   * Signal input for the `iconSize` property.
   *
   * @public
   */
  readonly iconSize: InputSignal<ToggleButtonElement['iconSize'] | undefined>;
  /**
   * Signal input for the `type` property.
   *
   * @public
   */
  readonly type: InputSignal<ToggleButtonElement['type'] | undefined>;
  /**
   * Signal input for the `ripple` property.
   *
   * @public
   */
  readonly ripple: InputSignal<ToggleButtonElement['ripple'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<ToggleButtonElement['variant'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<ToggleButtonElement['appearance'] | undefined>;
  /**
   * Signal input for the `size` property.
   *
   * @public
   */
  readonly size: InputSignal<ToggleButtonElement['size'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<ToggleButtonElement['value'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<ToggleButtonElement['disabled'] | undefined>;
  /**
   * Signal input for the `isFocused` property.
   *
   * @public
   */
  readonly isFocused: InputSignal<ToggleButtonElement['isFocused'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ToggleButtonElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ToggleButtonElement['lang'] | undefined>;
  /**
   * Output signal for the `checked` event.
   *
   * @public
   */
  readonly checked: OutputEmitterRef<ElementEventDetail<ToggleButtonElement, 'checked'>>;
  /**
   * Output signal for the `unchecked` event.
   *
   * @public
   */
  readonly unchecked: OutputEmitterRef<ElementEventDetail<ToggleButtonElement, 'unchecked'>>;
  /**
   * Output signal for the `toggled` event.
   *
   * @public
   */
  readonly toggled: OutputEmitterRef<ElementEventDetail<ToggleButtonElement, 'toggled'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ToggleButtonElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ToggleButtonElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ToggleButtonElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  private readonly _accessor;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Applies a value supplied by Angular forms to the native control.
   *
   * @public
   */
  writeValue(obj: unknown): void;
  /**
   * Registers the callback notified when the native control value changes.
   *
   * @public
   */
  registerOnChange(fn: unknown): void;
  /**
   * Registers the callback notified when the native control is touched.
   *
   * @public
   */
  registerOnTouched(fn: unknown): void;
  /**
   * Applies the disabled state supplied by Angular forms.
   *
   * @public
   */
  setDisabledState?(isDisabled: boolean): void;
  /**
   * Resets the element to its initial state.
   *
   * @public
   */
  reset(...args: Parameters<ToggleButtonElement['reset']>): ReturnType<ToggleButtonElement['reset']>;
  /**
   * Checks the element.
   *
   * @public
   */
  check(...args: Parameters<ToggleButtonElement['check']>): ReturnType<ToggleButtonElement['check']>;
  /**
   * Unchecks the element.
   *
   * @public
   */
  uncheck(...args: Parameters<ToggleButtonElement['uncheck']>): ReturnType<ToggleButtonElement['uncheck']>;
  /**
   * Calls `toggle` on the `mosaik-toggle-button` element.
   *
   * @public
   */
  toggle(...args: Parameters<ToggleButtonElement['toggle']>): ReturnType<ToggleButtonElement['toggle']>;
  /**
   * Forwards the standard focus API to this button's native interactive control.
   * Disabled and not-yet-rendered controls keep the current focus unchanged.
   *
   * @public
   * @param args - The arguments of `focus`:
   * - `options` - Standard browser focus options.
   */
  focus(...args: Parameters<ToggleButtonElement['focus']>): ReturnType<ToggleButtonElement['focus']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `reset()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends ToggleButtonMethodNames>(method: TMethod, ...args: Parameters<ToggleButtonComponentMethods[TMethod]>): ReturnType<ToggleButtonComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ToggleButtonElement>(property: TProperty, value: ToggleButtonElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ToggleButtonElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ToggleButtonComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ToggleButtonComponent, "mosaik-toggle-button", never, {
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "reverse": {
      "alias": "reverse";
      "required": false;
      "isSignal": true;
    };
    "orientation": {
      "alias": "orientation";
      "required": false;
      "isSignal": true;
    };
    "horizontalContentAlignment": {
      "alias": "horizontalContentAlignment";
      "required": false;
      "isSignal": true;
    };
    "verticalContentAlignment": {
      "alias": "verticalContentAlignment";
      "required": false;
      "isSignal": true;
    };
    "fit": {
      "alias": "fit";
      "required": false;
      "isSignal": true;
    };
    "isBusy": {
      "alias": "isBusy";
      "required": false;
      "isSignal": true;
    };
    "isChecked": {
      "alias": "isChecked";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "icon": {
      "alias": "icon";
      "required": false;
      "isSignal": true;
    };
    "iconPosition": {
      "alias": "iconPosition";
      "required": false;
      "isSignal": true;
    };
    "iconSize": {
      "alias": "iconSize";
      "required": false;
      "isSignal": true;
    };
    "type": {
      "alias": "type";
      "required": false;
      "isSignal": true;
    };
    "ripple": {
      "alias": "ripple";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "isFocused": {
      "alias": "isFocused";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "checked": "checked";
    "unchecked": "unchecked";
    "toggled": "toggled";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, [{
    directive: typeof i1.FormStatusHostDirective;
    inputs: {};
    outputs: {};
  }, {
    directive: typeof i1.FormFieldStatusHostDirective;
    inputs: {};
    outputs: {};
  }]>;
}
/**
 * Declares the methods available on ToggleButtonComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ToggleButtonMethodNames = 'reset' | 'check' | 'uncheck' | 'toggle' | 'focus';
/**
 * Declares the methods interface for ToggleButtonComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ToggleButtonComponentMethods = MethodMap<ToggleButtonMethodNames>;
/**
 * @public
 */
export declare function provideToggleButtonComponent(config?: Partial<ToggleButtonElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-toggle-button.d.ts.map