import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef, Type } from "@angular/core";
import { CalendarHeaderElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/calendar/CalendarHeaderElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import * as i1 from "@pixel-brewery/mosaik-elements-angular/runtime";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { CalendarItemElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/calendar/CalendarItemElement";
import { CalendarSubHeaderElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/calendar/CalendarSubHeaderElement";
import { ControlValueAccessor } from "@angular/forms";
import { CalendarElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/calendar/CalendarElement";
/**
 * @public
 *
 * Injection token for the default properties of the CalendarHeaderComponent.
 * Use this token to provide default properties for the CalendarHeaderComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const CALENDAR_HEADER_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/inputs/calendar/ICalendarHeaderElementProps").ICalendarHeaderElementProps>>;
/**
 * @public
 *
 * @slot header - The default slot for custom header content
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class CalendarHeaderComponent {
  /**
   * Signal input for the `text` property.
   *
   * @public
   */
  readonly text: InputSignal<CalendarHeaderElement['text'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<CalendarHeaderElement['themeName'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<CalendarHeaderElement['disabled'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<CalendarHeaderElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<CalendarHeaderElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<CalendarHeaderElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<CalendarHeaderElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<CalendarHeaderElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof CalendarHeaderElement>(property: TProperty, value: CalendarHeaderElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<CalendarHeaderElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<CalendarHeaderComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<CalendarHeaderComponent, "mosaik-calendar-header", never, {
    "text": {
      "alias": "text";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on CalendarHeaderComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type CalendarHeaderMethodNames = never;
/**
 * Declares the methods interface for CalendarHeaderComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type CalendarHeaderComponentMethods = MethodMap<CalendarHeaderMethodNames>;
/**
 * @public
 */
export declare function provideCalendarHeaderComponent(config?: Partial<CalendarHeaderElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the CalendarItemComponent.
 * Use this token to provide default properties for the CalendarItemComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const CALENDAR_ITEM_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/inputs/calendar/ICalendarItemElementProps").ICalendarItemElementProps>>;
/**
 * @public
 *
 * @slot content - Additional non-interactive content below the date text. The existing date label, selection target and markers remain available.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class CalendarItemComponent {
  /**
   * Signal input for the `isSelected` property.
   *
   * @public
   */
  readonly isSelected: InputSignal<CalendarItemElement['isSelected'] | undefined>;
  /**
   * Signal input for the `isBlackout` property.
   *
   * @public
   */
  readonly isBlackout: InputSignal<CalendarItemElement['isBlackout'] | undefined>;
  /**
   * Signal input for the `isSpecial` property.
   *
   * @public
   */
  readonly isSpecial: InputSignal<CalendarItemElement['isSpecial'] | undefined>;
  /**
   * Signal input for the `isToday` property.
   *
   * @public
   */
  readonly isToday: InputSignal<CalendarItemElement['isToday'] | undefined>;
  /**
   * Signal input for the `isWeekend` property.
   *
   * @public
   */
  readonly isWeekend: InputSignal<CalendarItemElement['isWeekend'] | undefined>;
  /**
   * Signal input for the `isAdjacent` property.
   *
   * @public
   */
  readonly isAdjacent: InputSignal<CalendarItemElement['isAdjacent'] | undefined>;
  /**
   * Signal input for the `markers` property.
   *
   * @public
   */
  readonly markers: InputSignal<CalendarItemElement['markers'] | undefined>;
  /**
   * Signal input for the `isRangeStart` property.
   *
   * @public
   */
  readonly isRangeStart: InputSignal<CalendarItemElement['isRangeStart'] | undefined>;
  /**
   * Signal input for the `isRangeMiddle` property.
   *
   * @public
   */
  readonly isRangeMiddle: InputSignal<CalendarItemElement['isRangeMiddle'] | undefined>;
  /**
   * Signal input for the `isRangeEnd` property.
   *
   * @public
   */
  readonly isRangeEnd: InputSignal<CalendarItemElement['isRangeEnd'] | undefined>;
  /**
   * Signal input for the `isRangePreview` property.
   *
   * @public
   */
  readonly isRangePreview: InputSignal<CalendarItemElement['isRangePreview'] | undefined>;
  /**
   * Signal input for the `text` property.
   *
   * @public
   */
  readonly text: InputSignal<CalendarItemElement['text'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<CalendarItemElement['themeName'] | undefined>;
  /**
   * Signal input for the `ripple` property.
   *
   * @public
   */
  readonly ripple: InputSignal<CalendarItemElement['ripple'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<CalendarItemElement['appearance'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<CalendarItemElement['variant'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<CalendarItemElement['disabled'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<CalendarItemElement['value'] | undefined>;
  /**
   * Signal input for the `isFocused` property.
   *
   * @public
   */
  readonly isFocused: InputSignal<CalendarItemElement['isFocused'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<CalendarItemElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<CalendarItemElement['lang'] | undefined>;
  /**
   * Output signal for the `click` event.
   *
   * @public
   */
  readonly click: OutputEmitterRef<ElementEventDetail<CalendarItemElement, 'click'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<CalendarItemElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<CalendarItemElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<CalendarItemElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof CalendarItemElement>(property: TProperty, value: CalendarItemElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<CalendarItemElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<CalendarItemComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<CalendarItemComponent, "mosaik-calendar-item", never, {
    "isSelected": {
      "alias": "isSelected";
      "required": false;
      "isSignal": true;
    };
    "isBlackout": {
      "alias": "isBlackout";
      "required": false;
      "isSignal": true;
    };
    "isSpecial": {
      "alias": "isSpecial";
      "required": false;
      "isSignal": true;
    };
    "isToday": {
      "alias": "isToday";
      "required": false;
      "isSignal": true;
    };
    "isWeekend": {
      "alias": "isWeekend";
      "required": false;
      "isSignal": true;
    };
    "isAdjacent": {
      "alias": "isAdjacent";
      "required": false;
      "isSignal": true;
    };
    "markers": {
      "alias": "markers";
      "required": false;
      "isSignal": true;
    };
    "isRangeStart": {
      "alias": "isRangeStart";
      "required": false;
      "isSignal": true;
    };
    "isRangeMiddle": {
      "alias": "isRangeMiddle";
      "required": false;
      "isSignal": true;
    };
    "isRangeEnd": {
      "alias": "isRangeEnd";
      "required": false;
      "isSignal": true;
    };
    "isRangePreview": {
      "alias": "isRangePreview";
      "required": false;
      "isSignal": true;
    };
    "text": {
      "alias": "text";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "ripple": {
      "alias": "ripple";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "isFocused": {
      "alias": "isFocused";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "click": "click";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on CalendarItemComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type CalendarItemMethodNames = never;
/**
 * Declares the methods interface for CalendarItemComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type CalendarItemComponentMethods = MethodMap<CalendarItemMethodNames>;
/**
 * @public
 */
export declare function provideCalendarItemComponent(config?: Partial<CalendarItemElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the CalendarSubHeaderComponent.
 * Use this token to provide default properties for the CalendarSubHeaderComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const CALENDAR_SUB_HEADER_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/inputs/calendar/ICalendarSubHeaderElementProps").ICalendarSubHeaderElementProps>>;
/**
 * @public
 *
 * @slot subHeader - The default slot for custom sub-header content
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class CalendarSubHeaderComponent {
  /**
   * Signal input for the `text` property.
   *
   * @public
   */
  readonly text: InputSignal<CalendarSubHeaderElement['text'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<CalendarSubHeaderElement['themeName'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<CalendarSubHeaderElement['disabled'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<CalendarSubHeaderElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<CalendarSubHeaderElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<CalendarSubHeaderElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<CalendarSubHeaderElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<CalendarSubHeaderElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof CalendarSubHeaderElement>(property: TProperty, value: CalendarSubHeaderElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<CalendarSubHeaderElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<CalendarSubHeaderComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<CalendarSubHeaderComponent, "mosaik-calendar-sub-header", never, {
    "text": {
      "alias": "text";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on CalendarSubHeaderComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type CalendarSubHeaderMethodNames = never;
/**
 * Declares the methods interface for CalendarSubHeaderComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type CalendarSubHeaderComponentMethods = MethodMap<CalendarSubHeaderMethodNames>;
/**
 * @public
 */
export declare function provideCalendarSubHeaderComponent(config?: Partial<CalendarSubHeaderElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the CalendarComponent.
 * Use this token to provide default properties for the CalendarComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const CALENDAR_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/inputs/calendar/ICalendarElementProps").ICalendarElementProps>>;
/**
 * @public
 *
 * Injection token for the intl configuration of the CalendarComponent.
 * Provide a partial intl object or an injectable class that resolves translations.
 * This allows third-party applications to override the default intl labels
 * globally, per route, or per component via Angular's dependency injection.
 *
 * Merge order: Foundation defaults → DI intl → [intl] input binding.
 */
export declare const CALENDAR_INTL: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").CalendarElementIntl>>;
/**
 * @public
 *
 * @slot day-${sheetIndex}-${getDayKey(day)} - Additional content below a day's number. Use a zero-based sheet index and a local ISO date, for example `day-0-2026-07-03`. Each visible copy of an adjacent date has its own sheet slot.
 * @slot footer - The footer slot.
 * @slot header - The header slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class CalendarComponent implements ControlValueAccessor {
  /**
   * Signal input for the `sheets` property.
   *
   * @public
   */
  readonly sheets: InputSignal<CalendarElement['sheets'] | undefined>;
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<Partial<CalendarElement['intl']> | undefined>;
  /**
   * Signal input for the `displayDate` property.
   *
   * @public
   */
  readonly displayDate: InputSignal<CalendarElement['displayDate'] | undefined>;
  /**
   * Signal input for the `displayDateStart` property.
   *
   * @public
   */
  readonly displayDateStart: InputSignal<CalendarElement['displayDateStart'] | undefined>;
  /**
   * Signal input for the `displayDateEnd` property.
   *
   * @public
   */
  readonly displayDateEnd: InputSignal<CalendarElement['displayDateEnd'] | undefined>;
  /**
   * Signal input for the `values` property.
   *
   * @public
   */
  readonly values: InputSignal<CalendarElement['values'] | undefined>;
  /**
   * Signal input for the `view` property.
   *
   * @public
   */
  readonly view: InputSignal<CalendarElement['view'] | undefined>;
  /**
   * Signal input for the `selectionMode` property.
   *
   * @public
   */
  readonly selectionMode: InputSignal<CalendarElement['selectionMode'] | undefined>;
  /**
   * Signal input for the `blackoutDates` property.
   *
   * @public
   */
  readonly blackoutDates: InputSignal<CalendarElement['blackoutDates'] | undefined>;
  /**
   * Signal input for the `specialDates` property.
   *
   * @public
   */
  readonly specialDates: InputSignal<CalendarElement['specialDates'] | undefined>;
  /**
   * Signal input for the `minDate` property.
   *
   * @public
   */
  readonly minDate: InputSignal<CalendarElement['minDate'] | undefined>;
  /**
   * Signal input for the `maxDate` property.
   *
   * @public
   */
  readonly maxDate: InputSignal<CalendarElement['maxDate'] | undefined>;
  /**
   * Signal input for the `firstDayOfWeek` property.
   *
   * @public
   */
  readonly firstDayOfWeek: InputSignal<CalendarElement['firstDayOfWeek'] | undefined>;
  /**
   * Signal input for the `isTodayHighlighted` property.
   *
   * @public
   */
  readonly isTodayHighlighted: InputSignal<CalendarElement['isTodayHighlighted'] | undefined>;
  /**
   * Signal input for the `isWeekendHighlighted` property.
   *
   * @public
   */
  readonly isWeekendHighlighted: InputSignal<CalendarElement['isWeekendHighlighted'] | undefined>;
  /**
   * Signal input for the `showWeekNumbers` property.
   *
   * @public
   */
  readonly showWeekNumbers: InputSignal<CalendarElement['showWeekNumbers'] | undefined>;
  /**
   * Signal input for the `showAdjacent` property.
   *
   * @public
   */
  readonly showAdjacent: InputSignal<CalendarElement['showAdjacent'] | undefined>;
  /**
   * Signal input for the `markerHandler` property.
   *
   * @public
   */
  readonly markerHandler: InputSignal<CalendarElement['markerHandler'] | undefined>;
  /**
   * Signal input for the `allowedViews` property.
   *
   * @public
   */
  readonly allowedViews: InputSignal<CalendarElement['allowedViews'] | undefined>;
  /**
   * Signal input for the `showNavigation` property.
   *
   * @public
   */
  readonly showNavigation: InputSignal<CalendarElement['showNavigation'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<CalendarElement['themeName'] | undefined>;
  /**
   * Signal input for the `locale` property.
   *
   * @public
   */
  readonly locale: InputSignal<CalendarElement['locale'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<CalendarElement['appearance'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<CalendarElement['disabled'] | undefined>;
  /**
   * Signal input for the `invalid` property.
   *
   * @public
   */
  readonly invalid: InputSignal<CalendarElement['invalid'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<CalendarElement['value'] | undefined>;
  /**
   * Signal input for the `orientation` property.
   *
   * @public
   */
  readonly orientation: InputSignal<CalendarElement['orientation'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<CalendarElement['variant'] | undefined>;
  /**
   * Signal input for the `fit` property.
   *
   * @public
   */
  readonly fit: InputSignal<CalendarElement['fit'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<CalendarElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<CalendarElement['lang'] | undefined>;
  /**
   * Output signal for the `dateChanged` event.
   *
   * @public
   */
  readonly dateChanged: OutputEmitterRef<ElementEventDetail<CalendarElement, 'dateChanged'>>;
  /**
   * Output signal for the `displayChanged` event.
   *
   * @public
   */
  readonly displayChanged: OutputEmitterRef<ElementEventDetail<CalendarElement, 'displayChanged'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<CalendarElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<CalendarElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<CalendarElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: CalendarElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: CalendarElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  private readonly _accessor;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Applies a value supplied by Angular forms to the native control.
   *
   * @public
   */
  writeValue(obj: unknown): void;
  /**
   * Registers the callback notified when the native control value changes.
   *
   * @public
   */
  registerOnChange(fn: unknown): void;
  /**
   * Registers the callback notified when the native control is touched.
   *
   * @public
   */
  registerOnTouched(fn: unknown): void;
  /**
   * Applies the disabled state supplied by Angular forms.
   *
   * @public
   */
  setDisabledState?(isDisabled: boolean): void;
  /**
   * Resets the value, all kinds of validation and errors.
   *
   * @public
   */
  reset(...args: Parameters<CalendarElement['reset']>): ReturnType<CalendarElement['reset']>;
  /**
   * Checks the validity of the element and returns `true` if it is valid; otherwise, `false`.
   *
   * @public
   */
  checkValidity(...args: Parameters<CalendarElement['checkValidity']>): ReturnType<CalendarElement['checkValidity']>;
  /**
   * Navigates to the previous displayed period, starting from the current month when no period is set.
   * The selected value remains unchanged.
   *
   * @public
   */
  navigatePrevious(...args: Parameters<CalendarElement['navigatePrevious']>): ReturnType<CalendarElement['navigatePrevious']>;
  /**
   * Navigates to the next displayed period, starting from the current month when no period is set.
   * The selected value remains unchanged.
   *
   * @public
   */
  navigateNext(...args: Parameters<CalendarElement['navigateNext']>): ReturnType<CalendarElement['navigateNext']>;
  /**
   * Navigates to the month of today in the days view, unless that month lies entirely outside `minDate` and `maxDate`.
   *
   * @public
   */
  navigateToday(...args: Parameters<CalendarElement['navigateToday']>): ReturnType<CalendarElement['navigateToday']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<CalendarElement['assignToSlot']>): ReturnType<CalendarElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<CalendarElement['getSlotContent']>): ReturnType<CalendarElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<CalendarElement['hasSlotContent']>): ReturnType<CalendarElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<CalendarElement['hasSlot']>): ReturnType<CalendarElement['hasSlot']>;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<CalendarElement['onSlotChanges']>): ReturnType<CalendarElement['onSlotChanges']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `reset()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends CalendarMethodNames>(method: TMethod, ...args: Parameters<CalendarComponentMethods[TMethod]>): ReturnType<CalendarComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof CalendarElement>(property: TProperty, value: CalendarElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<CalendarElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<CalendarComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<CalendarComponent, "mosaik-calendar", never, {
    "sheets": {
      "alias": "sheets";
      "required": false;
      "isSignal": true;
    };
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "displayDate": {
      "alias": "displayDate";
      "required": false;
      "isSignal": true;
    };
    "displayDateStart": {
      "alias": "displayDateStart";
      "required": false;
      "isSignal": true;
    };
    "displayDateEnd": {
      "alias": "displayDateEnd";
      "required": false;
      "isSignal": true;
    };
    "values": {
      "alias": "values";
      "required": false;
      "isSignal": true;
    };
    "view": {
      "alias": "view";
      "required": false;
      "isSignal": true;
    };
    "selectionMode": {
      "alias": "selectionMode";
      "required": false;
      "isSignal": true;
    };
    "blackoutDates": {
      "alias": "blackoutDates";
      "required": false;
      "isSignal": true;
    };
    "specialDates": {
      "alias": "specialDates";
      "required": false;
      "isSignal": true;
    };
    "minDate": {
      "alias": "minDate";
      "required": false;
      "isSignal": true;
    };
    "maxDate": {
      "alias": "maxDate";
      "required": false;
      "isSignal": true;
    };
    "firstDayOfWeek": {
      "alias": "firstDayOfWeek";
      "required": false;
      "isSignal": true;
    };
    "isTodayHighlighted": {
      "alias": "isTodayHighlighted";
      "required": false;
      "isSignal": true;
    };
    "isWeekendHighlighted": {
      "alias": "isWeekendHighlighted";
      "required": false;
      "isSignal": true;
    };
    "showWeekNumbers": {
      "alias": "showWeekNumbers";
      "required": false;
      "isSignal": true;
    };
    "showAdjacent": {
      "alias": "showAdjacent";
      "required": false;
      "isSignal": true;
    };
    "markerHandler": {
      "alias": "markerHandler";
      "required": false;
      "isSignal": true;
    };
    "allowedViews": {
      "alias": "allowedViews";
      "required": false;
      "isSignal": true;
    };
    "showNavigation": {
      "alias": "showNavigation";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "locale": {
      "alias": "locale";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "invalid": {
      "alias": "invalid";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "orientation": {
      "alias": "orientation";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "fit": {
      "alias": "fit";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "dateChanged": "dateChanged";
    "displayChanged": "displayChanged";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, [{
    directive: typeof i1.FormStatusHostDirective;
    inputs: {};
    outputs: {};
  }, {
    directive: typeof i1.FormFieldStatusHostDirective;
    inputs: {};
    outputs: {};
  }]>;
}
/**
 * Declares the methods available on CalendarComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type CalendarMethodNames = 'reset' | 'checkValidity' | 'navigatePrevious' | 'navigateNext' | 'navigateToday' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges';
/**
 * Declares the methods interface for CalendarComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type CalendarComponentMethods = MethodMap<CalendarMethodNames>;
/**
 * @public
 */
export declare function provideCalendarComponent(config?: Partial<CalendarElement.Props>, intl?: Partial<CalendarElement['intl']> | Type<Partial<CalendarElement['intl']>>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-calendar.d.ts.map