import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef, Type } from "@angular/core";
import { ControlValueAccessor } from "@angular/forms";
import { TextBoxElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/text-box/TextBoxElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import * as i1 from "@pixel-brewery/mosaik-elements-angular/runtime";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the TextBoxComponent.
 * Use this token to provide default properties for the TextBoxComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const TEXT_BOX_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/inputs/text-box/ITextBoxElementProps").ITextBoxElementProps>>;
/**
 * @public
 *
 * Injection token for the intl configuration of the TextBoxComponent.
 * Provide a partial intl object or an injectable class that resolves translations.
 * This allows third-party applications to override the default intl labels
 * globally, per route, or per component via Angular's dependency injection.
 *
 * Merge order: Foundation defaults → DI intl → [intl] input binding.
 */
export declare const TEXT_BOX_INTL: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").TextBoxElementIntl>>;
/**
 * @public
 *
 * @slot prefix - The prefix slot.
 * @slot suffix - The suffix slot.
 * @slot value - Rich value content displayed immediately before the native editor.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class TextBoxComponent implements ControlValueAccessor {
  /**
   * Signal input for the `multiline` property.
   *
   * @public
   */
  readonly multiline: InputSignal<TextBoxElement['multiline'] | undefined>;
  /**
   * Signal input for the `multilineRows` property.
   *
   * @public
   */
  readonly multilineRows: InputSignal<TextBoxElement['multilineRows'] | undefined>;
  /**
   * Signal input for the `multilineMaxRows` property.
   *
   * @public
   */
  readonly multilineMaxRows: InputSignal<TextBoxElement['multilineMaxRows'] | undefined>;
  /**
   * Signal input for the `readonly` property.
   *
   * @public
   */
  readonly readonly: InputSignal<TextBoxElement['readonly'] | undefined>;
  /**
   * Signal input for the `required` property.
   *
   * @public
   */
  readonly required: InputSignal<TextBoxElement['required'] | undefined>;
  /**
   * Signal input for the `autofocus` property.
   *
   * @public
   */
  readonly autofocus: InputSignal<TextBoxElement['autofocus'] | undefined>;
  /**
   * Signal input for the `name` property.
   *
   * @public
   */
  readonly name: InputSignal<TextBoxElement['name'] | undefined>;
  /**
   * Signal input for the `type` property.
   *
   * @public
   */
  readonly type: InputSignal<TextBoxElement['type'] | undefined>;
  /**
   * Signal input for the `pattern` property.
   *
   * @public
   */
  readonly pattern: InputSignal<TextBoxElement['pattern'] | undefined>;
  /**
   * Signal input for the `placeholder` property.
   *
   * @public
   */
  readonly placeholder: InputSignal<TextBoxElement['placeholder'] | undefined>;
  /**
   * Signal input for the `autocomplete` property.
   *
   * @public
   */
  readonly autocomplete: InputSignal<TextBoxElement['autocomplete'] | undefined>;
  /**
   * Signal input for the `keyboard` property.
   *
   * @public
   */
  readonly keyboard: InputSignal<TextBoxElement['keyboard'] | undefined>;
  /**
   * Signal input for the `minlength` property.
   *
   * @public
   */
  readonly minlength: InputSignal<TextBoxElement['minlength'] | undefined>;
  /**
   * Signal input for the `maxlength` property.
   *
   * @public
   */
  readonly maxlength: InputSignal<TextBoxElement['maxlength'] | undefined>;
  /**
   * Signal input for the `resize` property.
   *
   * @public
   */
  readonly resize: InputSignal<TextBoxElement['resize'] | undefined>;
  /**
   * Signal input for the `textAlign` property.
   *
   * @public
   */
  readonly textAlign: InputSignal<TextBoxElement['textAlign'] | undefined>;
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<Partial<TextBoxElement['intl']> | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<TextBoxElement['themeName'] | undefined>;
  /**
   * Signal input for the `isClearable` property.
   *
   * @public
   */
  readonly isClearable: InputSignal<TextBoxElement['isClearable'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<TextBoxElement['appearance'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<TextBoxElement['variant'] | undefined>;
  /**
   * Signal input for the `size` property.
   *
   * @public
   */
  readonly size: InputSignal<TextBoxElement['size'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<TextBoxElement['label'] | undefined>;
  /**
   * Signal input for the `invalid` property.
   *
   * @public
   */
  readonly invalid: InputSignal<TextBoxElement['invalid'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<TextBoxElement['value'] | undefined>;
  /**
   * Signal input for the `isBusy` property.
   *
   * @public
   */
  readonly isBusy: InputSignal<TextBoxElement['isBusy'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<TextBoxElement['disabled'] | undefined>;
  /**
   * Signal input for the `formatter` property.
   *
   * @public
   */
  readonly formatter: InputSignal<TextBoxElement['formatter'] | undefined>;
  /**
   * Signal input for the `parser` property.
   *
   * @public
   */
  readonly parser: InputSignal<TextBoxElement['parser'] | undefined>;
  /**
   * Signal input for the `isFocused` property.
   *
   * @public
   */
  readonly isFocused: InputSignal<TextBoxElement['isFocused'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<TextBoxElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<TextBoxElement['lang'] | undefined>;
  /**
   * Output signal for the `cleared` event.
   *
   * @public
   */
  readonly cleared: OutputEmitterRef<ElementEventDetail<TextBoxElement, 'cleared'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<TextBoxElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<TextBoxElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<TextBoxElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: TextBoxElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: TextBoxElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  private readonly _accessor;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Applies a value supplied by Angular forms to the native control.
   *
   * @public
   */
  writeValue(obj: unknown): void;
  /**
   * Registers the callback notified when the native control value changes.
   *
   * @public
   */
  registerOnChange(fn: unknown): void;
  /**
   * Registers the callback notified when the native control is touched.
   *
   * @public
   */
  registerOnTouched(fn: unknown): void;
  /**
   * Applies the disabled state supplied by Angular forms.
   *
   * @public
   */
  setDisabledState?(isDisabled: boolean): void;
  /**
   * Sets focus to the element.
   *
   * @public
   */
  focus(...args: Parameters<TextBoxElement['focus']>): ReturnType<TextBoxElement['focus']>;
  /**
   * Removes focus from the element.
   *
   * @public
   */
  blur(...args: Parameters<TextBoxElement['blur']>): ReturnType<TextBoxElement['blur']>;
  /**
   * Resets the value, all kinds of validation and errors.
   *
   * @public
   */
  reset(...args: Parameters<TextBoxElement['reset']>): ReturnType<TextBoxElement['reset']>;
  /**
   * Clears the value of the element but not the validation.
   *
   * @public
   */
  clear(...args: Parameters<TextBoxElement['clear']>): ReturnType<TextBoxElement['clear']>;
  /**
   * Checks the validity of the element and returns `true` if it is valid; otherwise, `false`.
   * Read-only fields preserve externally supplied validation because the native editor does not validate them.
   *
   * @public
   */
  checkValidity(...args: Parameters<TextBoxElement['checkValidity']>): ReturnType<TextBoxElement['checkValidity']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<TextBoxElement['assignToSlot']>): ReturnType<TextBoxElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<TextBoxElement['getSlotContent']>): ReturnType<TextBoxElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<TextBoxElement['hasSlotContent']>): ReturnType<TextBoxElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<TextBoxElement['hasSlot']>): ReturnType<TextBoxElement['hasSlot']>;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<TextBoxElement['onSlotChanges']>): ReturnType<TextBoxElement['onSlotChanges']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `focus()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends TextBoxMethodNames>(method: TMethod, ...args: Parameters<TextBoxComponentMethods[TMethod]>): ReturnType<TextBoxComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof TextBoxElement>(property: TProperty, value: TextBoxElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<TextBoxElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<TextBoxComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<TextBoxComponent, "mosaik-textbox", never, {
    "multiline": {
      "alias": "multiline";
      "required": false;
      "isSignal": true;
    };
    "multilineRows": {
      "alias": "multilineRows";
      "required": false;
      "isSignal": true;
    };
    "multilineMaxRows": {
      "alias": "multilineMaxRows";
      "required": false;
      "isSignal": true;
    };
    "readonly": {
      "alias": "readonly";
      "required": false;
      "isSignal": true;
    };
    "required": {
      "alias": "required";
      "required": false;
      "isSignal": true;
    };
    "autofocus": {
      "alias": "autofocus";
      "required": false;
      "isSignal": true;
    };
    "name": {
      "alias": "name";
      "required": false;
      "isSignal": true;
    };
    "type": {
      "alias": "type";
      "required": false;
      "isSignal": true;
    };
    "pattern": {
      "alias": "pattern";
      "required": false;
      "isSignal": true;
    };
    "placeholder": {
      "alias": "placeholder";
      "required": false;
      "isSignal": true;
    };
    "autocomplete": {
      "alias": "autocomplete";
      "required": false;
      "isSignal": true;
    };
    "keyboard": {
      "alias": "keyboard";
      "required": false;
      "isSignal": true;
    };
    "minlength": {
      "alias": "minlength";
      "required": false;
      "isSignal": true;
    };
    "maxlength": {
      "alias": "maxlength";
      "required": false;
      "isSignal": true;
    };
    "resize": {
      "alias": "resize";
      "required": false;
      "isSignal": true;
    };
    "textAlign": {
      "alias": "textAlign";
      "required": false;
      "isSignal": true;
    };
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "isClearable": {
      "alias": "isClearable";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "invalid": {
      "alias": "invalid";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "isBusy": {
      "alias": "isBusy";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "formatter": {
      "alias": "formatter";
      "required": false;
      "isSignal": true;
    };
    "parser": {
      "alias": "parser";
      "required": false;
      "isSignal": true;
    };
    "isFocused": {
      "alias": "isFocused";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "cleared": "cleared";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, [{
    directive: typeof i1.FormStatusHostDirective;
    inputs: {};
    outputs: {};
  }, {
    directive: typeof i1.FormFieldStatusHostDirective;
    inputs: {};
    outputs: {};
  }]>;
}
/**
 * Declares the methods available on TextBoxComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TextBoxMethodNames = 'focus' | 'blur' | 'reset' | 'clear' | 'checkValidity' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges';
/**
 * Declares the methods interface for TextBoxComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TextBoxComponentMethods = MethodMap<TextBoxMethodNames>;
/**
 * @public
 */
export declare function provideTextBoxComponent(config?: Partial<TextBoxElement.Props>, intl?: Partial<TextBoxElement['intl']> | Type<Partial<TextBoxElement['intl']>>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-text-box.d.ts.map