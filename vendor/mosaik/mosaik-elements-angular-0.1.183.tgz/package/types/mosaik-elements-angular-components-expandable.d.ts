import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { ExpandableElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/expandable/ExpandableElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the ExpandableComponent.
 * Use this token to provide default properties for the ExpandableComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const EXPANDABLE_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/primitives/expandable/IExpandableElementProps").IExpandableElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ExpandableComponent {
  /**
   * Signal input for the `direction` property.
   *
   * @public
   */
  readonly direction: InputSignal<ExpandableElement['direction'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ExpandableElement['themeName'] | undefined>;
  /**
   * Signal input for the `isExpanded` property.
   *
   * @public
   */
  readonly isExpanded: InputSignal<ExpandableElement['isExpanded'] | undefined>;
  /**
   * Signal input for the `enter` property.
   *
   * @public
   */
  readonly enter: InputSignal<ExpandableElement['enter'] | undefined>;
  /**
   * Signal input for the `exit` property.
   *
   * @public
   */
  readonly exit: InputSignal<ExpandableElement['exit'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<ExpandableElement['disabled'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ExpandableElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ExpandableElement['lang'] | undefined>;
  /**
   * Output signal for the `expanded` event.
   *
   * @public
   */
  readonly expanded: OutputEmitterRef<ElementEventDetail<ExpandableElement, 'expanded'>>;
  /**
   * Output signal for the `collapsed` event.
   *
   * @public
   */
  readonly collapsed: OutputEmitterRef<ElementEventDetail<ExpandableElement, 'collapsed'>>;
  /**
   * Output signal for the `toggled` event.
   *
   * @public
   */
  readonly toggled: OutputEmitterRef<ElementEventDetail<ExpandableElement, 'toggled'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ExpandableElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ExpandableElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ExpandableElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Expands the element.
   *
   * @public
   */
  expand(...args: Parameters<ExpandableElement['expand']>): ReturnType<ExpandableElement['expand']>;
  /**
   * Collapses the element.
   *
   * @public
   */
  collapse(...args: Parameters<ExpandableElement['collapse']>): ReturnType<ExpandableElement['collapse']>;
  /**
   * Toggles the element between expanded and collapsed states.
   *
   * @public
   */
  toggle(...args: Parameters<ExpandableElement['toggle']>): ReturnType<ExpandableElement['toggle']>;
  /**
   * Executes the animation.
   *
   * @public
   */
  play(...args: Parameters<ExpandableElement['play']>): ReturnType<ExpandableElement['play']>;
  /**
   * A lifecycle hook that is invoked when the element is added to the DOM.
   *
   * @public
   */
  onEnterAnimation(...args: Parameters<NonNullable<ExpandableElement['onEnterAnimation']>>): ReturnType<NonNullable<ExpandableElement['onEnterAnimation']>> | undefined;
  /**
   * A lifecycle hook that is invoked when the element is removed from the DOM.
   *
   * @public
   */
  onExitAnimation(...args: Parameters<NonNullable<ExpandableElement['onExitAnimation']>>): ReturnType<NonNullable<ExpandableElement['onExitAnimation']>> | undefined;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `expand()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends ExpandableMethodNames>(method: TMethod, ...args: Parameters<ExpandableComponentMethods[TMethod]>): ReturnType<ExpandableComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ExpandableElement>(property: TProperty, value: ExpandableElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ExpandableElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ExpandableComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ExpandableComponent, "mosaik-expandable", never, {
    "direction": {
      "alias": "direction";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "isExpanded": {
      "alias": "isExpanded";
      "required": false;
      "isSignal": true;
    };
    "enter": {
      "alias": "enter";
      "required": false;
      "isSignal": true;
    };
    "exit": {
      "alias": "exit";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "expanded": "expanded";
    "collapsed": "collapsed";
    "toggled": "toggled";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on ExpandableComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ExpandableMethodNames = 'expand' | 'collapse' | 'toggle' | 'play' | 'onEnterAnimation' | 'onExitAnimation';
/**
 * Declares the methods interface for ExpandableComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ExpandableComponentMethods = MethodMap<ExpandableMethodNames>;
/**
 * @public
 */
export declare function provideExpandableComponent(config?: Partial<ExpandableElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-expandable.d.ts.map