import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { MarqueeElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/illustrations/marquee/MarqueeElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the MarqueeComponent.
 * Use this token to provide default properties for the MarqueeComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const MARQUEE_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/illustrations/marquee/IMarqueeElementProps").IMarqueeElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot.
 * @slot clone - The clone slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class MarqueeComponent {
  /**
   * Signal input for the `speed` property.
   *
   * @public
   */
  readonly speed: InputSignal<MarqueeElement['speed'] | undefined>;
  /**
   * Signal input for the `fade` property.
   *
   * @public
   */
  readonly fade: InputSignal<MarqueeElement['fade'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<MarqueeElement['themeName'] | undefined>;
  /**
   * Signal input for the `reverse` property.
   *
   * @public
   */
  readonly reverse: InputSignal<MarqueeElement['reverse'] | undefined>;
  /**
   * Signal input for the `orientation` property.
   *
   * @public
   */
  readonly orientation: InputSignal<MarqueeElement['orientation'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<MarqueeElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<MarqueeElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<MarqueeElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<MarqueeElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<MarqueeElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: MarqueeElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: MarqueeElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Returns the items of the run: the element children in the default slot, without the copies.
   *
   * @public
   */
  getItems(...args: Parameters<MarqueeElement['getItems']>): ReturnType<MarqueeElement['getItems']>;
  /**
   * Returns the copies of the items that close the loop (light-DOM children marked with `data-marquee-clone`).
   *
   * @public
   */
  getCopies(...args: Parameters<MarqueeElement['getCopies']>): ReturnType<MarqueeElement['getCopies']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<MarqueeElement['assignToSlot']>): ReturnType<MarqueeElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<MarqueeElement['getSlotContent']>): ReturnType<MarqueeElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<MarqueeElement['hasSlotContent']>): ReturnType<MarqueeElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<MarqueeElement['hasSlot']>): ReturnType<MarqueeElement['hasSlot']>;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<MarqueeElement['onSlotChanges']>): ReturnType<MarqueeElement['onSlotChanges']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `getItems()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends MarqueeMethodNames>(method: TMethod, ...args: Parameters<MarqueeComponentMethods[TMethod]>): ReturnType<MarqueeComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof MarqueeElement>(property: TProperty, value: MarqueeElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<MarqueeElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<MarqueeComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<MarqueeComponent, "mosaik-marquee", never, {
    "speed": {
      "alias": "speed";
      "required": false;
      "isSignal": true;
    };
    "fade": {
      "alias": "fade";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "reverse": {
      "alias": "reverse";
      "required": false;
      "isSignal": true;
    };
    "orientation": {
      "alias": "orientation";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on MarqueeComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type MarqueeMethodNames = 'getItems' | 'getCopies' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges';
/**
 * Declares the methods interface for MarqueeComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type MarqueeComponentMethods = MethodMap<MarqueeMethodNames>;
/**
 * @public
 */
export declare function provideMarqueeComponent(config?: Partial<MarqueeElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-marquee.d.ts.map