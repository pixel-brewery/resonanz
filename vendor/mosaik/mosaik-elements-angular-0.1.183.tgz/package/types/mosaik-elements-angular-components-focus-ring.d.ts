import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { FocusRingElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/focus-ring/FocusRingElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the FocusRingComponent.
 * Use this token to provide default properties for the FocusRingComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const FOCUS_RING_DEFAULT_PROPS: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/focus-ring/FocusRingElement").IFocusRingElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class FocusRingComponent {
  /**
   * Signal input for the `visible` property.
   *
   * @public
   */
  readonly visible: InputSignal<FocusRingElement['visible'] | undefined>;
  /**
   * Signal input for the `inward` property.
   *
   * @public
   */
  readonly inward: InputSignal<FocusRingElement['inward'] | undefined>;
  /**
   * Signal input for the `controlled` property.
   *
   * @public
   */
  readonly controlled: InputSignal<FocusRingElement['controlled'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<FocusRingElement['themeName'] | undefined>;
  /**
   * Signal input for the `for` property.
   *
   * @public
   */
  readonly for: InputSignal<FocusRingElement['for'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<FocusRingElement['variant'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<FocusRingElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<FocusRingElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<FocusRingElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<FocusRingElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<FocusRingElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Attaches the element to an interactive control.
   *
   * @public
   */
  attach(...args: Parameters<FocusRingElement['attach']>): ReturnType<FocusRingElement['attach']>;
  /**
   * Detaches the element from its current control.
   *
   * @public
   */
  detach(...args: Parameters<FocusRingElement['detach']>): ReturnType<FocusRingElement['detach']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `attach()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends FocusRingMethodNames>(method: TMethod, ...args: Parameters<FocusRingComponentMethods[TMethod]>): ReturnType<FocusRingComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof FocusRingElement>(property: TProperty, value: FocusRingElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<FocusRingElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<FocusRingComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<FocusRingComponent, "mosaik-focus-ring", never, {
    "visible": {
      "alias": "visible";
      "required": false;
      "isSignal": true;
    };
    "inward": {
      "alias": "inward";
      "required": false;
      "isSignal": true;
    };
    "controlled": {
      "alias": "controlled";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "for": {
      "alias": "for";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on FocusRingComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FocusRingMethodNames = 'attach' | 'detach';
/**
 * Declares the methods interface for FocusRingComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FocusRingComponentMethods = MethodMap<FocusRingMethodNames>;
/**
 * @public
 */
export declare function provideFocusRingComponent(config?: Partial<FocusRingElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-focus-ring.d.ts.map