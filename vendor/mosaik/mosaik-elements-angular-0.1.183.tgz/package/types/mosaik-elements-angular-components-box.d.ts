import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { BoxElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/box/BoxElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the BoxComponent.
 * Use this token to provide default properties for the BoxComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const BOX_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/primitives/box/IBoxElementProps").IBoxElementProps>>;
/**
 * @public
 *
 * @slot  - Default slot for child elements.
 * @slot dismiss - Slot for dismiss button.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class BoxComponent {
  /**
   * Signal input for the `highlighted` property.
   *
   * @public
   */
  readonly highlighted: InputSignal<BoxElement['highlighted'] | undefined>;
  /**
   * Signal input for the `cornered` property.
   *
   * @public
   */
  readonly cornered: InputSignal<BoxElement['cornered'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<BoxElement['themeName'] | undefined>;
  /**
   * Signal input for the `fit` property.
   *
   * @public
   */
  readonly fit: InputSignal<BoxElement['fit'] | undefined>;
  /**
   * Signal input for the `width` property.
   *
   * @public
   */
  readonly width: InputSignal<BoxElement['width'] | undefined>;
  /**
   * Signal input for the `height` property.
   *
   * @public
   */
  readonly height: InputSignal<BoxElement['height'] | undefined>;
  /**
   * Signal input for the `inset` property.
   *
   * @public
   */
  readonly inset: InputSignal<BoxElement['inset'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<BoxElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<BoxElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<BoxElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<BoxElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<BoxElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof BoxElement>(property: TProperty, value: BoxElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<BoxElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<BoxComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<BoxComponent, "mosaik-box", never, {
    "highlighted": {
      "alias": "highlighted";
      "required": false;
      "isSignal": true;
    };
    "cornered": {
      "alias": "cornered";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "fit": {
      "alias": "fit";
      "required": false;
      "isSignal": true;
    };
    "width": {
      "alias": "width";
      "required": false;
      "isSignal": true;
    };
    "height": {
      "alias": "height";
      "required": false;
      "isSignal": true;
    };
    "inset": {
      "alias": "inset";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on BoxComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type BoxMethodNames = never;
/**
 * Declares the methods interface for BoxComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type BoxComponentMethods = MethodMap<BoxMethodNames>;
/**
 * @public
 */
export declare function provideBoxComponent(config?: Partial<BoxElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-box.d.ts.map