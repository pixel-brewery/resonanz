import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { MeterRingElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/ranges/meter-ring/MeterRingElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the MeterRingComponent.
 * Use this token to provide default properties for the MeterRingComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const METER_RING_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/ranges/meter-ring/IMeterRingElementProps").IMeterRingElementProps>>;
/**
 * @public
 *
 * @slot hint - Secondary text content area for additional meter information or status
 * @slot label - Text label content area for meter description or value display
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class MeterRingComponent {
  /**
   * Signal input for the `radius` property.
   *
   * @public
   */
  readonly radius: InputSignal<MeterRingElement['radius'] | undefined>;
  /**
   * Signal input for the `thickness` property.
   *
   * @public
   */
  readonly thickness: InputSignal<MeterRingElement['thickness'] | undefined>;
  /**
   * Signal input for the `high` property.
   *
   * @public
   */
  readonly high: InputSignal<MeterRingElement['high'] | undefined>;
  /**
   * Signal input for the `low` property.
   *
   * @public
   */
  readonly low: InputSignal<MeterRingElement['low'] | undefined>;
  /**
   * Signal input for the `optimum` property.
   *
   * @public
   */
  readonly optimum: InputSignal<MeterRingElement['optimum'] | undefined>;
  /**
   * Signal input for the `scale` property.
   *
   * @public
   */
  readonly scale: InputSignal<MeterRingElement['scale'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<MeterRingElement['themeName'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<MeterRingElement['variant'] | undefined>;
  /**
   * Signal input for the `orientation` property.
   *
   * @public
   */
  readonly orientation: InputSignal<MeterRingElement['orientation'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<MeterRingElement['disabled'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<MeterRingElement['label'] | undefined>;
  /**
   * Signal input for the `min` property.
   *
   * @public
   */
  readonly min: InputSignal<MeterRingElement['min'] | undefined>;
  /**
   * Signal input for the `max` property.
   *
   * @public
   */
  readonly max: InputSignal<MeterRingElement['max'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<MeterRingElement['value'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<MeterRingElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<MeterRingElement['lang'] | undefined>;
  /**
   * Output signal for the `rangeValueChanged` event.
   *
   * @public
   */
  readonly rangeValueChanged: OutputEmitterRef<ElementEventDetail<MeterRingElement, 'rangeValueChanged'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<MeterRingElement, 'changed'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<MeterRingElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<MeterRingElement, 'disconnected'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof MeterRingElement>(property: TProperty, value: MeterRingElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<MeterRingElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<MeterRingComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<MeterRingComponent, "mosaik-meter-ring", never, {
    "radius": {
      "alias": "radius";
      "required": false;
      "isSignal": true;
    };
    "thickness": {
      "alias": "thickness";
      "required": false;
      "isSignal": true;
    };
    "high": {
      "alias": "high";
      "required": false;
      "isSignal": true;
    };
    "low": {
      "alias": "low";
      "required": false;
      "isSignal": true;
    };
    "optimum": {
      "alias": "optimum";
      "required": false;
      "isSignal": true;
    };
    "scale": {
      "alias": "scale";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "orientation": {
      "alias": "orientation";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "min": {
      "alias": "min";
      "required": false;
      "isSignal": true;
    };
    "max": {
      "alias": "max";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "rangeValueChanged": "rangeValueChanged";
    "changed": "changed";
    "connected": "connected";
    "disconnected": "disconnected";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on MeterRingComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type MeterRingMethodNames = never;
/**
 * Declares the methods interface for MeterRingComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type MeterRingComponentMethods = MethodMap<MeterRingMethodNames>;
/**
 * @public
 */
export declare function provideMeterRingComponent(config?: Partial<MeterRingElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-meter-ring.d.ts.map