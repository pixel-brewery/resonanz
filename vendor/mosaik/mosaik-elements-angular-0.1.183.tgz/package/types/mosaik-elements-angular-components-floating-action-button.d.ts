import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { FloatingActionButtonGroupElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/buttons/floating-action-button/FloatingActionButtonGroupElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { FloatingActionButtonElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/buttons/floating-action-button/FloatingActionButtonElement";
/**
 * @public
 *
 * Injection token for the default properties of the FloatingActionButtonGroupComponent.
 * Use this token to provide default properties for the FloatingActionButtonGroupComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const FLOATING_ACTION_BUTTON_GROUP_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/buttons/floating-action-button/IFloatingActionButtonGroupElementProps").IFloatingActionButtonGroupElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot for FABs.
 * @slot overlay - The overlay slot (useful for badges or additional visual elements).
 * @slot trigger - The trigger slot for initiating the FAB group.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class FloatingActionButtonGroupComponent {
  /**
   * Signal input for the `isOpen` property.
   *
   * @public
   */
  readonly isOpen: InputSignal<FloatingActionButtonGroupElement['isOpen'] | undefined>;
  /**
   * Signal input for the `direction` property.
   *
   * @public
   */
  readonly direction: InputSignal<FloatingActionButtonGroupElement['direction'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<FloatingActionButtonGroupElement['themeName'] | undefined>;
  /**
   * Signal input for the `closeable` property.
   *
   * @public
   */
  readonly closeable: InputSignal<FloatingActionButtonGroupElement['closeable'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<FloatingActionButtonGroupElement['disabled'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<FloatingActionButtonGroupElement['appearance'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<FloatingActionButtonGroupElement['variant'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<FloatingActionButtonGroupElement['label'] | undefined>;
  /**
   * Signal input for the `icon` property.
   *
   * @public
   */
  readonly icon: InputSignal<FloatingActionButtonGroupElement['icon'] | undefined>;
  /**
   * Signal input for the `iconPosition` property.
   *
   * @public
   */
  readonly iconPosition: InputSignal<FloatingActionButtonGroupElement['iconPosition'] | undefined>;
  /**
   * Signal input for the `iconSize` property.
   *
   * @public
   */
  readonly iconSize: InputSignal<FloatingActionButtonGroupElement['iconSize'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<FloatingActionButtonGroupElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<FloatingActionButtonGroupElement['lang'] | undefined>;
  /**
   * Output signal for the `opened` event.
   *
   * @public
   */
  readonly opened: OutputEmitterRef<ElementEventDetail<FloatingActionButtonGroupElement, 'opened'>>;
  /**
   * Output signal for the `closed` event.
   *
   * @public
   */
  readonly closed: OutputEmitterRef<ElementEventDetail<FloatingActionButtonGroupElement, 'closed'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<FloatingActionButtonGroupElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<FloatingActionButtonGroupElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<FloatingActionButtonGroupElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: FloatingActionButtonGroupElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: FloatingActionButtonGroupElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<FloatingActionButtonGroupElement['onSlotChanges']>): ReturnType<FloatingActionButtonGroupElement['onSlotChanges']>;
  /**
   * Opens the FAB group.
   *
   * @public
   */
  open(...args: Parameters<FloatingActionButtonGroupElement['open']>): ReturnType<FloatingActionButtonGroupElement['open']>;
  /**
   * Close the FAB group.
   *
   * @public
   */
  close(...args: Parameters<FloatingActionButtonGroupElement['close']>): ReturnType<FloatingActionButtonGroupElement['close']>;
  /**
   * Toggles the FAB group.
   *
   * @public
   */
  toggle(...args: Parameters<FloatingActionButtonGroupElement['toggle']>): ReturnType<FloatingActionButtonGroupElement['toggle']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<FloatingActionButtonGroupElement['assignToSlot']>): ReturnType<FloatingActionButtonGroupElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<FloatingActionButtonGroupElement['getSlotContent']>): ReturnType<FloatingActionButtonGroupElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<FloatingActionButtonGroupElement['hasSlotContent']>): ReturnType<FloatingActionButtonGroupElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<FloatingActionButtonGroupElement['hasSlot']>): ReturnType<FloatingActionButtonGroupElement['hasSlot']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `onSlotChanges()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends FloatingActionButtonGroupMethodNames>(method: TMethod, ...args: Parameters<FloatingActionButtonGroupComponentMethods[TMethod]>): ReturnType<FloatingActionButtonGroupComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof FloatingActionButtonGroupElement>(property: TProperty, value: FloatingActionButtonGroupElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<FloatingActionButtonGroupElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<FloatingActionButtonGroupComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<FloatingActionButtonGroupComponent, "mosaik-fab-group", never, {
    "isOpen": {
      "alias": "isOpen";
      "required": false;
      "isSignal": true;
    };
    "direction": {
      "alias": "direction";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "closeable": {
      "alias": "closeable";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "icon": {
      "alias": "icon";
      "required": false;
      "isSignal": true;
    };
    "iconPosition": {
      "alias": "iconPosition";
      "required": false;
      "isSignal": true;
    };
    "iconSize": {
      "alias": "iconSize";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "opened": "opened";
    "closed": "closed";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on FloatingActionButtonGroupComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FloatingActionButtonGroupMethodNames = 'onSlotChanges' | 'open' | 'close' | 'toggle' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot';
/**
 * Declares the methods interface for FloatingActionButtonGroupComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FloatingActionButtonGroupComponentMethods = MethodMap<FloatingActionButtonGroupMethodNames>;
/**
 * @public
 */
export declare function provideFloatingActionButtonGroupComponent(config?: Partial<FloatingActionButtonGroupElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the FloatingActionButtonComponent.
 * Use this token to provide default properties for the FloatingActionButtonComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const FLOATING_ACTION_BUTTON_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/buttons/floating-action-button/IFloatingActionButtonElementProps").IFloatingActionButtonElementProps>>;
/**
 * @public
 *
 * @slot icon - Icon content area for the primary visual action indicator
 * @slot label - Optional text label for extended floating action button variations
 * @slot overlay - Overlay content area for badges, notifications, or status indicators
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class FloatingActionButtonComponent {
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<FloatingActionButtonElement['themeName'] | undefined>;
  /**
   * Signal input for the `isBusy` property.
   *
   * @public
   */
  readonly isBusy: InputSignal<FloatingActionButtonElement['isBusy'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<FloatingActionButtonElement['label'] | undefined>;
  /**
   * Signal input for the `icon` property.
   *
   * @public
   */
  readonly icon: InputSignal<FloatingActionButtonElement['icon'] | undefined>;
  /**
   * Signal input for the `iconPosition` property.
   *
   * @public
   */
  readonly iconPosition: InputSignal<FloatingActionButtonElement['iconPosition'] | undefined>;
  /**
   * Signal input for the `iconSize` property.
   *
   * @public
   */
  readonly iconSize: InputSignal<FloatingActionButtonElement['iconSize'] | undefined>;
  /**
   * Signal input for the `type` property.
   *
   * @public
   */
  readonly type: InputSignal<FloatingActionButtonElement['type'] | undefined>;
  /**
   * Signal input for the `ripple` property.
   *
   * @public
   */
  readonly ripple: InputSignal<FloatingActionButtonElement['ripple'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<FloatingActionButtonElement['variant'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<FloatingActionButtonElement['appearance'] | undefined>;
  /**
   * Signal input for the `size` property.
   *
   * @public
   */
  readonly size: InputSignal<FloatingActionButtonElement['size'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<FloatingActionButtonElement['value'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<FloatingActionButtonElement['disabled'] | undefined>;
  /**
   * Signal input for the `isFocused` property.
   *
   * @public
   */
  readonly isFocused: InputSignal<FloatingActionButtonElement['isFocused'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<FloatingActionButtonElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<FloatingActionButtonElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<FloatingActionButtonElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<FloatingActionButtonElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<FloatingActionButtonElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Forwards the standard focus API to this button's native interactive control.
   * Disabled and not-yet-rendered controls keep the current focus unchanged.
   *
   * @public
   * @param args - The arguments of `focus`:
   * - `options` - Standard browser focus options.
   */
  focus(...args: Parameters<FloatingActionButtonElement['focus']>): ReturnType<FloatingActionButtonElement['focus']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `focus()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends FloatingActionButtonMethodNames>(method: TMethod, ...args: Parameters<FloatingActionButtonComponentMethods[TMethod]>): ReturnType<FloatingActionButtonComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof FloatingActionButtonElement>(property: TProperty, value: FloatingActionButtonElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<FloatingActionButtonElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<FloatingActionButtonComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<FloatingActionButtonComponent, "mosaik-fab", never, {
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "isBusy": {
      "alias": "isBusy";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "icon": {
      "alias": "icon";
      "required": false;
      "isSignal": true;
    };
    "iconPosition": {
      "alias": "iconPosition";
      "required": false;
      "isSignal": true;
    };
    "iconSize": {
      "alias": "iconSize";
      "required": false;
      "isSignal": true;
    };
    "type": {
      "alias": "type";
      "required": false;
      "isSignal": true;
    };
    "ripple": {
      "alias": "ripple";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "isFocused": {
      "alias": "isFocused";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on FloatingActionButtonComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FloatingActionButtonMethodNames = 'focus';
/**
 * Declares the methods interface for FloatingActionButtonComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FloatingActionButtonComponentMethods = MethodMap<FloatingActionButtonMethodNames>;
/**
 * @public
 */
export declare function provideFloatingActionButtonComponent(config?: Partial<FloatingActionButtonElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-floating-action-button.d.ts.map