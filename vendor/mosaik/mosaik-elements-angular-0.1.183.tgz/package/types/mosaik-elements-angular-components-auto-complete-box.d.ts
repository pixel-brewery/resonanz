import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef, Type } from "@angular/core";
import { ControlValueAccessor } from "@angular/forms";
import { AutoCompleteBoxElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/auto-complete-box/AutoCompleteBoxElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import * as i1 from "@pixel-brewery/mosaik-elements-angular/runtime";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the AutoCompleteBoxComponent.
 * Use this token to provide default properties for the AutoCompleteBoxComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const AUTO_COMPLETE_BOX_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/inputs/auto-complete-box/IAutoCompleteBoxElementProps").IAutoCompleteBoxElementProps>>;
/**
 * @public
 *
 * Injection token for the intl configuration of the AutoCompleteBoxComponent.
 * Provide a partial intl object or an injectable class that resolves translations.
 * This allows third-party applications to override the default intl labels
 * globally, per route, or per component via Angular's dependency injection.
 *
 * Merge order: Foundation defaults → DI intl → [intl] input binding.
 */
export declare const AUTO_COMPLETE_BOX_INTL: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").AutoCompleteBoxElementIntl>>;
/**
 * @public
 *
 * @slot prefix - Content placed before the input value.
 * @slot suffix - Content placed after the input value.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class AutoCompleteBoxComponent implements ControlValueAccessor {
  /**
   * Signal input for the `text` property.
   *
   * @public
   */
  readonly text: InputSignal<AutoCompleteBoxElement['text'] | undefined>;
  /**
   * Signal input for the `filterText` property.
   *
   * @public
   */
  readonly filterText: InputSignal<AutoCompleteBoxElement['filterText'] | undefined>;
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<Partial<AutoCompleteBoxElement['intl']> | undefined>;
  /**
   * Signal input for the `placeholder` property.
   *
   * @public
   */
  readonly placeholder: InputSignal<AutoCompleteBoxElement['placeholder'] | undefined>;
  /**
   * Signal input for the `filterPlaceholder` property.
   *
   * @public
   */
  readonly filterPlaceholder: InputSignal<AutoCompleteBoxElement['filterPlaceholder'] | undefined>;
  /**
   * Signal input for the `required` property.
   *
   * @public
   */
  readonly required: InputSignal<AutoCompleteBoxElement['required'] | undefined>;
  /**
   * Signal input for the `readonly` property.
   *
   * @public
   */
  readonly readonly: InputSignal<AutoCompleteBoxElement['readonly'] | undefined>;
  /**
   * Signal input for the `textAlign` property.
   *
   * @public
   */
  readonly textAlign: InputSignal<AutoCompleteBoxElement['textAlign'] | undefined>;
  /**
   * Signal input for the `renderItem` property.
   *
   * @public
   */
  readonly renderItem: InputSignal<AutoCompleteBoxElement['renderItem'] | undefined>;
  /**
   * Signal input for the `dropDownSync` property.
   *
   * @public
   */
  readonly dropDownSync: InputSignal<AutoCompleteBoxElement['dropDownSync'] | undefined>;
  /**
   * Signal input for the `dropDownPlacement` property.
   *
   * @public
   */
  readonly dropDownPlacement: InputSignal<AutoCompleteBoxElement['dropDownPlacement'] | undefined>;
  /**
   * Signal input for the `dropDownStrategy` property.
   *
   * @public
   */
  readonly dropDownStrategy: InputSignal<AutoCompleteBoxElement['dropDownStrategy'] | undefined>;
  /**
   * Signal input for the `dropDownDistance` property.
   *
   * @public
   */
  readonly dropDownDistance: InputSignal<AutoCompleteBoxElement['dropDownDistance'] | undefined>;
  /**
   * Signal input for the `dropDownSkidding` property.
   *
   * @public
   */
  readonly dropDownSkidding: InputSignal<AutoCompleteBoxElement['dropDownSkidding'] | undefined>;
  /**
   * Signal input for the `dropDownStaysOpen` property.
   *
   * @public
   */
  readonly dropDownStaysOpen: InputSignal<AutoCompleteBoxElement['dropDownStaysOpen'] | undefined>;
  /**
   * Signal input for the `dropDownMaxHeight` property.
   *
   * @public
   */
  readonly dropDownMaxHeight: InputSignal<AutoCompleteBoxElement['dropDownMaxHeight'] | undefined>;
  /**
   * Signal input for the `dropDownHeight` property.
   *
   * @public
   */
  readonly dropDownHeight: InputSignal<AutoCompleteBoxElement['dropDownHeight'] | undefined>;
  /**
   * Signal input for the `dropDownWidth` property.
   *
   * @public
   */
  readonly dropDownWidth: InputSignal<AutoCompleteBoxElement['dropDownWidth'] | undefined>;
  /**
   * Signal input for the `dropDownMaxWidth` property.
   *
   * @public
   */
  readonly dropDownMaxWidth: InputSignal<AutoCompleteBoxElement['dropDownMaxWidth'] | undefined>;
  /**
   * Signal input for the `isDropDownOpen` property.
   *
   * @public
   */
  readonly isDropDownOpen: InputSignal<AutoCompleteBoxElement['isDropDownOpen'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<AutoCompleteBoxElement['appearance'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<AutoCompleteBoxElement['variant'] | undefined>;
  /**
   * Signal input for the `size` property.
   *
   * @public
   */
  readonly size: InputSignal<AutoCompleteBoxElement['size'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<AutoCompleteBoxElement['label'] | undefined>;
  /**
   * Signal input for the `isClearable` property.
   *
   * @public
   */
  readonly isClearable: InputSignal<AutoCompleteBoxElement['isClearable'] | undefined>;
  /**
   * Signal input for the `invalid` property.
   *
   * @public
   */
  readonly invalid: InputSignal<AutoCompleteBoxElement['invalid'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<AutoCompleteBoxElement['value'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<AutoCompleteBoxElement['themeName'] | undefined>;
  /**
   * Signal input for the `minimumPrefixLength` property.
   *
   * @public
   */
  readonly minimumPrefixLength: InputSignal<AutoCompleteBoxElement['minimumPrefixLength'] | undefined>;
  /**
   * Signal input for the `minimumPopulateDelay` property.
   *
   * @public
   */
  readonly minimumPopulateDelay: InputSignal<AutoCompleteBoxElement['minimumPopulateDelay'] | undefined>;
  /**
   * Signal input for the `isTextCompletionEnabled` property.
   *
   * @public
   */
  readonly isTextCompletionEnabled: InputSignal<AutoCompleteBoxElement['isTextCompletionEnabled'] | undefined>;
  /**
   * Signal input for the `searchMode` property.
   *
   * @public
   */
  readonly searchMode: InputSignal<AutoCompleteBoxElement['searchMode'] | undefined>;
  /**
   * Signal input for the `displayMemberPath` property.
   *
   * @public
   */
  readonly displayMemberPath: InputSignal<AutoCompleteBoxElement['displayMemberPath'] | undefined>;
  /**
   * Signal input for the `valueMemberPath` property.
   *
   * @public
   */
  readonly valueMemberPath: InputSignal<AutoCompleteBoxElement['valueMemberPath'] | undefined>;
  /**
   * Signal input for the `items` property.
   *
   * @public
   */
  readonly items: InputSignal<AutoCompleteBoxElement['items'] | undefined>;
  /**
   * Signal input for the `itemsProvider` property.
   *
   * @public
   */
  readonly itemsProvider: InputSignal<AutoCompleteBoxElement['itemsProvider'] | undefined>;
  /**
   * Signal input for the `populating` property.
   *
   * @public
   */
  readonly populating: InputSignal<AutoCompleteBoxElement['populating'] | undefined>;
  /**
   * Signal input for the `populated` property.
   *
   * @public
   */
  readonly populated: InputSignal<AutoCompleteBoxElement['populated'] | undefined>;
  /**
   * Signal input for the `itemSelected` property.
   *
   * @public
   */
  readonly itemSelected: InputSignal<AutoCompleteBoxElement['itemSelected'] | undefined>;
  /**
   * Signal input for the `filteredItems` property.
   *
   * @public
   */
  readonly filteredItems: InputSignal<AutoCompleteBoxElement['filteredItems'] | undefined>;
  /**
   * Signal input for the `isPopulating` property.
   *
   * @public
   */
  readonly isPopulating: InputSignal<AutoCompleteBoxElement['isPopulating'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<AutoCompleteBoxElement['disabled'] | undefined>;
  /**
   * Signal input for the `formatter` property.
   *
   * @public
   */
  readonly formatter: InputSignal<AutoCompleteBoxElement['formatter'] | undefined>;
  /**
   * Signal input for the `parser` property.
   *
   * @public
   */
  readonly parser: InputSignal<AutoCompleteBoxElement['parser'] | undefined>;
  /**
   * Signal input for the `isFocused` property.
   *
   * @public
   */
  readonly isFocused: InputSignal<AutoCompleteBoxElement['isFocused'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<AutoCompleteBoxElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<AutoCompleteBoxElement['lang'] | undefined>;
  /**
   * Output signal for the `cleared` event.
   *
   * @public
   */
  readonly cleared: OutputEmitterRef<ElementEventDetail<AutoCompleteBoxElement, 'cleared'>>;
  /**
   * Output signal for the `autoCompletePopulating` event.
   *
   * @public
   */
  readonly autoCompletePopulating: OutputEmitterRef<ElementEventDetail<AutoCompleteBoxElement, 'autoCompletePopulating'>>;
  /**
   * Output signal for the `autoCompletePopulated` event.
   *
   * @public
   */
  readonly autoCompletePopulated: OutputEmitterRef<ElementEventDetail<AutoCompleteBoxElement, 'autoCompletePopulated'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<AutoCompleteBoxElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<AutoCompleteBoxElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<AutoCompleteBoxElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: AutoCompleteBoxElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: AutoCompleteBoxElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  private readonly _accessor;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Applies a value supplied by Angular forms to the native control.
   *
   * @public
   */
  writeValue(obj: unknown): void;
  /**
   * Registers the callback notified when the native control value changes.
   *
   * @public
   */
  registerOnChange(fn: unknown): void;
  /**
   * Registers the callback notified when the native control is touched.
   *
   * @public
   */
  registerOnTouched(fn: unknown): void;
  /**
   * Applies the disabled state supplied by Angular forms.
   *
   * @public
   */
  setDisabledState?(isDisabled: boolean): void;
  /**
   * Checks the validity of the element.
   *
   * @public
   */
  checkValidity(...args: Parameters<AutoCompleteBoxElement['checkValidity']>): ReturnType<AutoCompleteBoxElement['checkValidity']>;
  /**
   * Clears the value of the element but not the validation.
   *
   * @public
   */
  clear(...args: Parameters<AutoCompleteBoxElement['clear']>): ReturnType<AutoCompleteBoxElement['clear']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<AutoCompleteBoxElement['assignToSlot']>): ReturnType<AutoCompleteBoxElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<AutoCompleteBoxElement['getSlotContent']>): ReturnType<AutoCompleteBoxElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<AutoCompleteBoxElement['hasSlotContent']>): ReturnType<AutoCompleteBoxElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<AutoCompleteBoxElement['hasSlot']>): ReturnType<AutoCompleteBoxElement['hasSlot']>;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<AutoCompleteBoxElement['onSlotChanges']>): ReturnType<AutoCompleteBoxElement['onSlotChanges']>;
  /**
   * Opens the drop down.
   *
   * @public
   */
  open(...args: Parameters<AutoCompleteBoxElement['open']>): ReturnType<AutoCompleteBoxElement['open']>;
  /**
   * Closes the drop down.
   *
   * @public
   */
  close(...args: Parameters<AutoCompleteBoxElement['close']>): ReturnType<AutoCompleteBoxElement['close']>;
  /**
   * Toggles the drop down.
   *
   * @public
   */
  toggle(...args: Parameters<AutoCompleteBoxElement['toggle']>): ReturnType<AutoCompleteBoxElement['toggle']>;
  /**
   * Resets the value of the element.
   *
   * @public
   */
  reset(...args: Parameters<AutoCompleteBoxElement['reset']>): ReturnType<AutoCompleteBoxElement['reset']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `checkValidity()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends AutoCompleteBoxMethodNames>(method: TMethod, ...args: Parameters<AutoCompleteBoxComponentMethods[TMethod]>): ReturnType<AutoCompleteBoxComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof AutoCompleteBoxElement>(property: TProperty, value: AutoCompleteBoxElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<AutoCompleteBoxElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<AutoCompleteBoxComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AutoCompleteBoxComponent, "mosaik-autocompletebox", never, {
    "text": {
      "alias": "text";
      "required": false;
      "isSignal": true;
    };
    "filterText": {
      "alias": "filterText";
      "required": false;
      "isSignal": true;
    };
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "placeholder": {
      "alias": "placeholder";
      "required": false;
      "isSignal": true;
    };
    "filterPlaceholder": {
      "alias": "filterPlaceholder";
      "required": false;
      "isSignal": true;
    };
    "required": {
      "alias": "required";
      "required": false;
      "isSignal": true;
    };
    "readonly": {
      "alias": "readonly";
      "required": false;
      "isSignal": true;
    };
    "textAlign": {
      "alias": "textAlign";
      "required": false;
      "isSignal": true;
    };
    "renderItem": {
      "alias": "renderItem";
      "required": false;
      "isSignal": true;
    };
    "dropDownSync": {
      "alias": "dropDownSync";
      "required": false;
      "isSignal": true;
    };
    "dropDownPlacement": {
      "alias": "dropDownPlacement";
      "required": false;
      "isSignal": true;
    };
    "dropDownStrategy": {
      "alias": "dropDownStrategy";
      "required": false;
      "isSignal": true;
    };
    "dropDownDistance": {
      "alias": "dropDownDistance";
      "required": false;
      "isSignal": true;
    };
    "dropDownSkidding": {
      "alias": "dropDownSkidding";
      "required": false;
      "isSignal": true;
    };
    "dropDownStaysOpen": {
      "alias": "dropDownStaysOpen";
      "required": false;
      "isSignal": true;
    };
    "dropDownMaxHeight": {
      "alias": "dropDownMaxHeight";
      "required": false;
      "isSignal": true;
    };
    "dropDownHeight": {
      "alias": "dropDownHeight";
      "required": false;
      "isSignal": true;
    };
    "dropDownWidth": {
      "alias": "dropDownWidth";
      "required": false;
      "isSignal": true;
    };
    "dropDownMaxWidth": {
      "alias": "dropDownMaxWidth";
      "required": false;
      "isSignal": true;
    };
    "isDropDownOpen": {
      "alias": "isDropDownOpen";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "isClearable": {
      "alias": "isClearable";
      "required": false;
      "isSignal": true;
    };
    "invalid": {
      "alias": "invalid";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "minimumPrefixLength": {
      "alias": "minimumPrefixLength";
      "required": false;
      "isSignal": true;
    };
    "minimumPopulateDelay": {
      "alias": "minimumPopulateDelay";
      "required": false;
      "isSignal": true;
    };
    "isTextCompletionEnabled": {
      "alias": "isTextCompletionEnabled";
      "required": false;
      "isSignal": true;
    };
    "searchMode": {
      "alias": "searchMode";
      "required": false;
      "isSignal": true;
    };
    "displayMemberPath": {
      "alias": "displayMemberPath";
      "required": false;
      "isSignal": true;
    };
    "valueMemberPath": {
      "alias": "valueMemberPath";
      "required": false;
      "isSignal": true;
    };
    "items": {
      "alias": "items";
      "required": false;
      "isSignal": true;
    };
    "itemsProvider": {
      "alias": "itemsProvider";
      "required": false;
      "isSignal": true;
    };
    "populating": {
      "alias": "populating";
      "required": false;
      "isSignal": true;
    };
    "populated": {
      "alias": "populated";
      "required": false;
      "isSignal": true;
    };
    "itemSelected": {
      "alias": "itemSelected";
      "required": false;
      "isSignal": true;
    };
    "filteredItems": {
      "alias": "filteredItems";
      "required": false;
      "isSignal": true;
    };
    "isPopulating": {
      "alias": "isPopulating";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "formatter": {
      "alias": "formatter";
      "required": false;
      "isSignal": true;
    };
    "parser": {
      "alias": "parser";
      "required": false;
      "isSignal": true;
    };
    "isFocused": {
      "alias": "isFocused";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "cleared": "cleared";
    "autoCompletePopulating": "autoCompletePopulating";
    "autoCompletePopulated": "autoCompletePopulated";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, [{
    directive: typeof i1.FormStatusHostDirective;
    inputs: {};
    outputs: {};
  }, {
    directive: typeof i1.FormFieldStatusHostDirective;
    inputs: {};
    outputs: {};
  }]>;
}
/**
 * Declares the methods available on AutoCompleteBoxComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type AutoCompleteBoxMethodNames = 'checkValidity' | 'clear' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges' | 'open' | 'close' | 'toggle' | 'reset';
/**
 * Declares the methods interface for AutoCompleteBoxComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type AutoCompleteBoxComponentMethods = MethodMap<AutoCompleteBoxMethodNames>;
/**
 * @public
 */
export declare function provideAutoCompleteBoxComponent(config?: Partial<AutoCompleteBoxElement.Props>, intl?: Partial<AutoCompleteBoxElement['intl']> | Type<Partial<AutoCompleteBoxElement['intl']>>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-auto-complete-box.d.ts.map