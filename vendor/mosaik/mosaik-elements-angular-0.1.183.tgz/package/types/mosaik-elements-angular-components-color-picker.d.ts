import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef, Type } from "@angular/core";
import { ColorPickerElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/color-picker/ColorPickerElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the ColorPickerComponent.
 * Use this token to provide default properties for the ColorPickerComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const COLOR_PICKER_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/media/color-picker/IColorPickerElementProps").IColorPickerElementProps>>;
/**
 * @public
 *
 * Injection token for the intl configuration of the ColorPickerComponent.
 * Provide a partial intl object or an injectable class that resolves translations.
 * This allows third-party applications to override the default intl labels
 * globally, per route, or per component via Angular's dependency injection.
 *
 * Merge order: Foundation defaults → DI intl → [intl] input binding.
 */
export declare const COLOR_PICKER_INTL: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").ColorEditorElementIntl>>;
/**
 * @public
 *
 * @slot  - Default slot for custom trigger content.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ColorPickerComponent {
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<Partial<ColorPickerElement['intl']> | undefined>;
  /**
   * Signal input for the `format` property.
   *
   * @public
   */
  readonly format: InputSignal<ColorPickerElement['format'] | undefined>;
  /**
   * Signal input for the `showAlpha` property.
   *
   * @public
   */
  readonly showAlpha: InputSignal<ColorPickerElement['showAlpha'] | undefined>;
  /**
   * Signal input for the `showInputs` property.
   *
   * @public
   */
  readonly showInputs: InputSignal<ColorPickerElement['showInputs'] | undefined>;
  /**
   * Signal input for the `showPalette` property.
   *
   * @public
   */
  readonly showPalette: InputSignal<ColorPickerElement['showPalette'] | undefined>;
  /**
   * Signal input for the `showEyeDropper` property.
   *
   * @public
   */
  readonly showEyeDropper: InputSignal<ColorPickerElement['showEyeDropper'] | undefined>;
  /**
   * Signal input for the `showSwatch` property.
   *
   * @public
   */
  readonly showSwatch: InputSignal<ColorPickerElement['showSwatch'] | undefined>;
  /**
   * Signal input for the `palettes` property.
   *
   * @public
   */
  readonly palettes: InputSignal<ColorPickerElement['palettes'] | undefined>;
  /**
   * Signal input for the `selectedPalette` property.
   *
   * @public
   */
  readonly selectedPalette: InputSignal<ColorPickerElement['selectedPalette'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ColorPickerElement['themeName'] | undefined>;
  /**
   * Signal input for the `dropDownPlacement` property.
   *
   * @public
   */
  readonly dropDownPlacement: InputSignal<ColorPickerElement['dropDownPlacement'] | undefined>;
  /**
   * Signal input for the `dropDownStrategy` property.
   *
   * @public
   */
  readonly dropDownStrategy: InputSignal<ColorPickerElement['dropDownStrategy'] | undefined>;
  /**
   * Signal input for the `dropDownDistance` property.
   *
   * @public
   */
  readonly dropDownDistance: InputSignal<ColorPickerElement['dropDownDistance'] | undefined>;
  /**
   * Signal input for the `dropDownSkidding` property.
   *
   * @public
   */
  readonly dropDownSkidding: InputSignal<ColorPickerElement['dropDownSkidding'] | undefined>;
  /**
   * Signal input for the `dropDownStaysOpen` property.
   *
   * @public
   */
  readonly dropDownStaysOpen: InputSignal<ColorPickerElement['dropDownStaysOpen'] | undefined>;
  /**
   * Signal input for the `dropDownMaxHeight` property.
   *
   * @public
   */
  readonly dropDownMaxHeight: InputSignal<ColorPickerElement['dropDownMaxHeight'] | undefined>;
  /**
   * Signal input for the `dropDownHeight` property.
   *
   * @public
   */
  readonly dropDownHeight: InputSignal<ColorPickerElement['dropDownHeight'] | undefined>;
  /**
   * Signal input for the `dropDownWidth` property.
   *
   * @public
   */
  readonly dropDownWidth: InputSignal<ColorPickerElement['dropDownWidth'] | undefined>;
  /**
   * Signal input for the `dropDownMaxWidth` property.
   *
   * @public
   */
  readonly dropDownMaxWidth: InputSignal<ColorPickerElement['dropDownMaxWidth'] | undefined>;
  /**
   * Signal input for the `isDropDownOpen` property.
   *
   * @public
   */
  readonly isDropDownOpen: InputSignal<ColorPickerElement['isDropDownOpen'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<ColorPickerElement['disabled'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<ColorPickerElement['value'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ColorPickerElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ColorPickerElement['lang'] | undefined>;
  /**
   * Output signal for the `colorChanged` event.
   *
   * @public
   */
  readonly colorChanged: OutputEmitterRef<ElementEventDetail<ColorPickerElement, 'colorChanged'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ColorPickerElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ColorPickerElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ColorPickerElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Opens the drop down.
   *
   * @public
   */
  open(...args: Parameters<ColorPickerElement['open']>): ReturnType<ColorPickerElement['open']>;
  /**
   * Closes the drop down.
   *
   * @public
   */
  close(...args: Parameters<ColorPickerElement['close']>): ReturnType<ColorPickerElement['close']>;
  /**
   * Toggles the drop down.
   *
   * @public
   */
  toggle(...args: Parameters<ColorPickerElement['toggle']>): ReturnType<ColorPickerElement['toggle']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `open()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends ColorPickerMethodNames>(method: TMethod, ...args: Parameters<ColorPickerComponentMethods[TMethod]>): ReturnType<ColorPickerComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ColorPickerElement>(property: TProperty, value: ColorPickerElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ColorPickerElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ColorPickerComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ColorPickerComponent, "mosaik-color-picker", never, {
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "format": {
      "alias": "format";
      "required": false;
      "isSignal": true;
    };
    "showAlpha": {
      "alias": "showAlpha";
      "required": false;
      "isSignal": true;
    };
    "showInputs": {
      "alias": "showInputs";
      "required": false;
      "isSignal": true;
    };
    "showPalette": {
      "alias": "showPalette";
      "required": false;
      "isSignal": true;
    };
    "showEyeDropper": {
      "alias": "showEyeDropper";
      "required": false;
      "isSignal": true;
    };
    "showSwatch": {
      "alias": "showSwatch";
      "required": false;
      "isSignal": true;
    };
    "palettes": {
      "alias": "palettes";
      "required": false;
      "isSignal": true;
    };
    "selectedPalette": {
      "alias": "selectedPalette";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dropDownPlacement": {
      "alias": "dropDownPlacement";
      "required": false;
      "isSignal": true;
    };
    "dropDownStrategy": {
      "alias": "dropDownStrategy";
      "required": false;
      "isSignal": true;
    };
    "dropDownDistance": {
      "alias": "dropDownDistance";
      "required": false;
      "isSignal": true;
    };
    "dropDownSkidding": {
      "alias": "dropDownSkidding";
      "required": false;
      "isSignal": true;
    };
    "dropDownStaysOpen": {
      "alias": "dropDownStaysOpen";
      "required": false;
      "isSignal": true;
    };
    "dropDownMaxHeight": {
      "alias": "dropDownMaxHeight";
      "required": false;
      "isSignal": true;
    };
    "dropDownHeight": {
      "alias": "dropDownHeight";
      "required": false;
      "isSignal": true;
    };
    "dropDownWidth": {
      "alias": "dropDownWidth";
      "required": false;
      "isSignal": true;
    };
    "dropDownMaxWidth": {
      "alias": "dropDownMaxWidth";
      "required": false;
      "isSignal": true;
    };
    "isDropDownOpen": {
      "alias": "isDropDownOpen";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "colorChanged": "colorChanged";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on ColorPickerComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ColorPickerMethodNames = 'open' | 'close' | 'toggle';
/**
 * Declares the methods interface for ColorPickerComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ColorPickerComponentMethods = MethodMap<ColorPickerMethodNames>;
/**
 * @public
 */
export declare function provideColorPickerComponent(config?: Partial<ColorPickerElement.Props>, intl?: Partial<ColorPickerElement['intl']> | Type<Partial<ColorPickerElement['intl']>>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-color-picker.d.ts.map