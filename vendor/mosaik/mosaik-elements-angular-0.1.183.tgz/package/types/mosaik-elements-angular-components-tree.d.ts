import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { TreeItemElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/tree/TreeItemElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import * as i1 from "@pixel-brewery/mosaik-elements-angular/runtime";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { ControlValueAccessor } from "@angular/forms";
import { TreeElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/selectors/tree/TreeElement";
/**
 * @public
 *
 * Injection token for the default properties of the TreeItemComponent.
 * Use this token to provide default properties for the TreeItemComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const TREE_ITEM_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/selectors/tree/ITreeItemElementProps").ITreeItemElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot.
 * @slot prefix - The prefix slot.
 * @slot suffix - The suffix slot.
 * @slot text - The text slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class TreeItemComponent {
  /**
   * Signal input for the `text` property.
   *
   * @public
   */
  readonly text: InputSignal<TreeItemElement['text'] | undefined>;
  /**
   * Signal input for the `isExpanded` property.
   *
   * @public
   */
  readonly isExpanded: InputSignal<TreeItemElement['isExpanded'] | undefined>;
  /**
   * Signal input for the `isChecked` property.
   *
   * @public
   */
  readonly isChecked: InputSignal<TreeItemElement['isChecked'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<TreeItemElement['themeName'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<TreeItemElement['disabled'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<TreeItemElement['variant'] | undefined>;
  /**
   * Signal input for the `isFocused` property.
   *
   * @public
   */
  readonly isFocused: InputSignal<TreeItemElement['isFocused'] | undefined>;
  /**
   * Signal input for the `isBusy` property.
   *
   * @public
   */
  readonly isBusy: InputSignal<TreeItemElement['isBusy'] | undefined>;
  /**
   * Signal input for the `isSelected` property.
   *
   * @public
   */
  readonly isSelected: InputSignal<TreeItemElement['isSelected'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<TreeItemElement['value'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<TreeItemElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<TreeItemElement['lang'] | undefined>;
  /**
   * Output signal for the `selected` event.
   *
   * @public
   */
  readonly selected: OutputEmitterRef<ElementEventDetail<TreeItemElement, 'selected'>>;
  /**
   * Output signal for the `deselected` event.
   *
   * @public
   */
  readonly deselected: OutputEmitterRef<ElementEventDetail<TreeItemElement, 'deselected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<TreeItemElement, 'changed'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<TreeItemElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<TreeItemElement, 'disconnected'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: TreeItemElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: TreeItemElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Expands the tree item.
   *
   * @public
   */
  expand(...args: Parameters<TreeItemElement['expand']>): ReturnType<TreeItemElement['expand']>;
  /**
   * Collapses the tree item.
   *
   * @public
   */
  collapse(...args: Parameters<TreeItemElement['collapse']>): ReturnType<TreeItemElement['collapse']>;
  /**
   * Toggles the expanded state of the tree item.
   *
   * @public
   */
  toggle(...args: Parameters<TreeItemElement['toggle']>): ReturnType<TreeItemElement['toggle']>;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<TreeItemElement['onSlotChanges']>): ReturnType<TreeItemElement['onSlotChanges']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<TreeItemElement['assignToSlot']>): ReturnType<TreeItemElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<TreeItemElement['getSlotContent']>): ReturnType<TreeItemElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<TreeItemElement['hasSlotContent']>): ReturnType<TreeItemElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<TreeItemElement['hasSlot']>): ReturnType<TreeItemElement['hasSlot']>;
  /**
   * Selects the item and fires `selected`. Does nothing when the item is already selected.
   *
   * @public
   * @param args - The arguments of `select`:
   * - `forceUpdate` - When `true`, the parent selector also selects the item.
   */
  select(...args: Parameters<TreeItemElement['select']>): ReturnType<TreeItemElement['select']>;
  /**
   * Deselects the item and fires `deselected`. Does nothing when the item is not selected.
   *
   * @public
   * @param args - The arguments of `deselect`:
   * - `forceUpdate` - When `true`, the parent selector also deselects the item.
   */
  deselect(...args: Parameters<TreeItemElement['deselect']>): ReturnType<TreeItemElement['deselect']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `expand()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends TreeItemMethodNames>(method: TMethod, ...args: Parameters<TreeItemComponentMethods[TMethod]>): ReturnType<TreeItemComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof TreeItemElement>(property: TProperty, value: TreeItemElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<TreeItemElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<TreeItemComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<TreeItemComponent, "mosaik-tree-item", never, {
    "text": {
      "alias": "text";
      "required": false;
      "isSignal": true;
    };
    "isExpanded": {
      "alias": "isExpanded";
      "required": false;
      "isSignal": true;
    };
    "isChecked": {
      "alias": "isChecked";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "isFocused": {
      "alias": "isFocused";
      "required": false;
      "isSignal": true;
    };
    "isBusy": {
      "alias": "isBusy";
      "required": false;
      "isSignal": true;
    };
    "isSelected": {
      "alias": "isSelected";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "selected": "selected";
    "deselected": "deselected";
    "changed": "changed";
    "connected": "connected";
    "disconnected": "disconnected";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on TreeItemComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TreeItemMethodNames = 'expand' | 'collapse' | 'toggle' | 'onSlotChanges' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'select' | 'deselect';
/**
 * Declares the methods interface for TreeItemComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TreeItemComponentMethods = MethodMap<TreeItemMethodNames>;
/**
 * @public
 */
export declare function provideTreeItemComponent(config?: Partial<TreeItemElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the TreeComponent.
 * Use this token to provide default properties for the TreeComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const TREE_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/selectors/tree/ITreeElementProps").ITreeElementProps>>;
/**
 * @public
 *
 * @slot  - The default slot.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class TreeComponent implements ControlValueAccessor {
  /**
   * Signal input for the `selectionMode` property.
   *
   * @public
   */
  readonly selectionMode: InputSignal<TreeElement['selectionMode'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<TreeElement['themeName'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<TreeElement['disabled'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<TreeElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<TreeElement['lang'] | undefined>;
  /**
   * Output signal for the `selectionChanged` event.
   *
   * @public
   */
  readonly selectionChanged: OutputEmitterRef<ElementEventDetail<TreeElement, 'selectionChanged'>>;
  /**
   * Output signal for the `itemsChanged` event.
   *
   * @public
   */
  readonly itemsChanged: OutputEmitterRef<ElementEventDetail<TreeElement, 'itemsChanged'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<TreeElement, 'changed'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<TreeElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<TreeElement, 'disconnected'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: TreeElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: TreeElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  private readonly _accessor;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Applies a value supplied by Angular forms to the native control.
   *
   * @public
   */
  writeValue(obj: unknown): void;
  /**
   * Registers the callback notified when the native control value changes.
   *
   * @public
   */
  registerOnChange(fn: unknown): void;
  /**
   * Registers the callback notified when the native control is touched.
   *
   * @public
   */
  registerOnTouched(fn: unknown): void;
  /**
   * Applies the disabled state supplied by Angular forms.
   *
   * @public
   */
  setDisabledState?(isDisabled: boolean): void;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<TreeElement['assignToSlot']>): ReturnType<TreeElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<TreeElement['getSlotContent']>): ReturnType<TreeElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<TreeElement['hasSlotContent']>): ReturnType<TreeElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<TreeElement['hasSlot']>): ReturnType<TreeElement['hasSlot']>;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<TreeElement['onSlotChanges']>): ReturnType<TreeElement['onSlotChanges']>;
  /**
   * Select the item.
   *
   * @public
   * @param args - The arguments of `select`:
   * - `item` - The element, index or value to select.
   */
  select(...args: Parameters<TreeElement['select']>): ReturnType<TreeElement['select']>;
  /**
   * Deselect the item.
   *
   * @public
   * @param args - The arguments of `deselect`:
   * - `item` - The element or index to deselect.
   */
  deselect(...args: Parameters<TreeElement['deselect']>): ReturnType<TreeElement['deselect']>;
  /**
   * Resets the current selection.
   *
   * @public
   */
  resetSelection(...args: Parameters<TreeElement['resetSelection']>): ReturnType<TreeElement['resetSelection']>;
  /**
   * Select the next item after current selected item/index.
   *
   * @public
   */
  selectNext(...args: Parameters<TreeElement['selectNext']>): ReturnType<TreeElement['selectNext']>;
  /**
   * Select the previous item before current selected item/index.
   *
   * @public
   */
  selectPrevious(...args: Parameters<TreeElement['selectPrevious']>): ReturnType<TreeElement['selectPrevious']>;
  /**
   * Select the first item.
   *
   * @public
   */
  selectFirst(...args: Parameters<TreeElement['selectFirst']>): ReturnType<TreeElement['selectFirst']>;
  /**
   * Select the last item.
   *
   * @public
   */
  selectLast(...args: Parameters<TreeElement['selectLast']>): ReturnType<TreeElement['selectLast']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `assignToSlot()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends TreeMethodNames>(method: TMethod, ...args: Parameters<TreeComponentMethods[TMethod]>): ReturnType<TreeComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof TreeElement>(property: TProperty, value: TreeElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<TreeElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<TreeComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<TreeComponent, "mosaik-tree", never, {
    "selectionMode": {
      "alias": "selectionMode";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "selectionChanged": "selectionChanged";
    "itemsChanged": "itemsChanged";
    "changed": "changed";
    "connected": "connected";
    "disconnected": "disconnected";
  }, never, ["*"], true, [{
    directive: typeof i1.FormStatusHostDirective;
    inputs: {};
    outputs: {};
  }, {
    directive: typeof i1.FormFieldStatusHostDirective;
    inputs: {};
    outputs: {};
  }]>;
}
/**
 * Declares the methods available on TreeComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TreeMethodNames = 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges' | 'select' | 'deselect' | 'resetSelection' | 'selectNext' | 'selectPrevious' | 'selectFirst' | 'selectLast';
/**
 * Declares the methods interface for TreeComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type TreeComponentMethods = MethodMap<TreeMethodNames>;
/**
 * @public
 */
export declare function provideTreeComponent(config?: Partial<TreeElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-tree.d.ts.map