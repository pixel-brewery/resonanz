import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { ControlValueAccessor } from "@angular/forms";
import { SliderElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/ranges/slider/SliderElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import * as i1 from "@pixel-brewery/mosaik-elements-angular/runtime";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the SliderComponent.
 * Use this token to provide default properties for the SliderComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const SLIDER_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/ranges/slider/ISliderElementProps").ISliderElementProps>>;
/**
 * @public
 *
 * @slot prefix - Content displayed before the slider track (e.g., minimum value label or icon)
 * @slot suffix - Content displayed after the slider track (e.g., maximum value label or icon)
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class SliderComponent implements ControlValueAccessor {
  /**
   * Signal input for the `step` property.
   *
   * @public
   */
  readonly step: InputSignal<SliderElement['step'] | undefined>;
  /**
   * Signal input for the `track` property.
   *
   * @public
   */
  readonly track: InputSignal<SliderElement['track'] | undefined>;
  /**
   * Signal input for the `ticks` property.
   *
   * @public
   */
  readonly ticks: InputSignal<SliderElement['ticks'] | undefined>;
  /**
   * Signal input for the `tickPlacement` property.
   *
   * @public
   */
  readonly tickPlacement: InputSignal<SliderElement['tickPlacement'] | undefined>;
  /**
   * Signal input for the `showTickLabels` property.
   *
   * @public
   */
  readonly showTickLabels: InputSignal<SliderElement['showTickLabels'] | undefined>;
  /**
   * Signal input for the `tickLabelAccessor` property.
   *
   * @public
   */
  readonly tickLabelAccessor: InputSignal<SliderElement['tickLabelAccessor'] | undefined>;
  /**
   * Signal input for the `tooltipPlacement` property.
   *
   * @public
   */
  readonly tooltipPlacement: InputSignal<SliderElement['tooltipPlacement'] | undefined>;
  /**
   * Signal input for the `tooltipAccessor` property.
   *
   * @public
   */
  readonly tooltipAccessor: InputSignal<SliderElement['tooltipAccessor'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<SliderElement['themeName'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<SliderElement['label'] | undefined>;
  /**
   * Signal input for the `orientation` property.
   *
   * @public
   */
  readonly orientation: InputSignal<SliderElement['orientation'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<SliderElement['disabled'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<SliderElement['variant'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<SliderElement['appearance'] | undefined>;
  /**
   * Signal input for the `isFocused` property.
   *
   * @public
   */
  readonly isFocused: InputSignal<SliderElement['isFocused'] | undefined>;
  /**
   * Signal input for the `invalid` property.
   *
   * @public
   */
  readonly invalid: InputSignal<SliderElement['invalid'] | undefined>;
  /**
   * Signal input for the `min` property.
   *
   * @public
   */
  readonly min: InputSignal<SliderElement['min'] | undefined>;
  /**
   * Signal input for the `max` property.
   *
   * @public
   */
  readonly max: InputSignal<SliderElement['max'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<SliderElement['value'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<SliderElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<SliderElement['lang'] | undefined>;
  /**
   * Output signal for the `rangeValueChanged` event.
   *
   * @public
   */
  readonly rangeValueChanged: OutputEmitterRef<ElementEventDetail<SliderElement, 'rangeValueChanged'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<SliderElement, 'changed'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<SliderElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<SliderElement, 'disconnected'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  private readonly _accessor;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Applies a value supplied by Angular forms to the native control.
   *
   * @public
   */
  writeValue(obj: unknown): void;
  /**
   * Registers the callback notified when the native control value changes.
   *
   * @public
   */
  registerOnChange(fn: unknown): void;
  /**
   * Registers the callback notified when the native control is touched.
   *
   * @public
   */
  registerOnTouched(fn: unknown): void;
  /**
   * Applies the disabled state supplied by Angular forms.
   *
   * @public
   */
  setDisabledState?(isDisabled: boolean): void;
  /**
   * Decrements the value by the value given by the `Step` property.
   * If the optional parameter is used, it will decrement the step value multiplied by the parameter's value.
   *
   * @public
   * @param args - The arguments of `stepDown`:
   * - `value` - Value to decrement the value by.
   */
  stepDown(...args: Parameters<SliderElement['stepDown']>): ReturnType<SliderElement['stepDown']>;
  /**
   * Increments the value by the value given by the `Step` property.
   * If the optional parameter is used, will increment the step value by that value.
   *
   * @public
   * @param args - The arguments of `stepUp`:
   * - `value` - Value to increment the value by.
   */
  stepUp(...args: Parameters<SliderElement['stepUp']>): ReturnType<SliderElement['stepUp']>;
  /**
   * Checks the validity of the element and returns `true` if it is valid; otherwise, `false`.
   *
   * @public
   */
  checkValidity(...args: Parameters<SliderElement['checkValidity']>): ReturnType<SliderElement['checkValidity']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `stepDown()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends SliderMethodNames>(method: TMethod, ...args: Parameters<SliderComponentMethods[TMethod]>): ReturnType<SliderComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof SliderElement>(property: TProperty, value: SliderElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<SliderElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SliderComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SliderComponent, "mosaik-slider", never, {
    "step": {
      "alias": "step";
      "required": false;
      "isSignal": true;
    };
    "track": {
      "alias": "track";
      "required": false;
      "isSignal": true;
    };
    "ticks": {
      "alias": "ticks";
      "required": false;
      "isSignal": true;
    };
    "tickPlacement": {
      "alias": "tickPlacement";
      "required": false;
      "isSignal": true;
    };
    "showTickLabels": {
      "alias": "showTickLabels";
      "required": false;
      "isSignal": true;
    };
    "tickLabelAccessor": {
      "alias": "tickLabelAccessor";
      "required": false;
      "isSignal": true;
    };
    "tooltipPlacement": {
      "alias": "tooltipPlacement";
      "required": false;
      "isSignal": true;
    };
    "tooltipAccessor": {
      "alias": "tooltipAccessor";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "orientation": {
      "alias": "orientation";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "isFocused": {
      "alias": "isFocused";
      "required": false;
      "isSignal": true;
    };
    "invalid": {
      "alias": "invalid";
      "required": false;
      "isSignal": true;
    };
    "min": {
      "alias": "min";
      "required": false;
      "isSignal": true;
    };
    "max": {
      "alias": "max";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "rangeValueChanged": "rangeValueChanged";
    "changed": "changed";
    "connected": "connected";
    "disconnected": "disconnected";
  }, never, ["*"], true, [{
    directive: typeof i1.FormStatusHostDirective;
    inputs: {};
    outputs: {};
  }, {
    directive: typeof i1.FormFieldStatusHostDirective;
    inputs: {};
    outputs: {};
  }]>;
}
/**
 * Declares the methods available on SliderComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SliderMethodNames = 'stepDown' | 'stepUp' | 'checkValidity';
/**
 * Declares the methods interface for SliderComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type SliderComponentMethods = MethodMap<SliderMethodNames>;
/**
 * @public
 */
export declare function provideSliderComponent(config?: Partial<SliderElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-slider.d.ts.map