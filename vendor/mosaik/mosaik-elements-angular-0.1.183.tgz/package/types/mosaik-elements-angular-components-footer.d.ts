import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { FooterItemGroupElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/footer/FooterItemGroupElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
import { FooterItemElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/footer/FooterItemElement";
import { FooterElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/footer/FooterElement";
/**
 * @public
 *
 * Injection token for the default properties of the FooterItemGroupComponent.
 * Use this token to provide default properties for the FooterItemGroupComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const FOOTER_ITEM_GROUP_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/primitives/footer/IFooterItemGroupElementProps").IFooterItemGroupElementProps>>;
/**
 * @public
 *
 * @slot  - Default slot for FooterItemElement children or other content
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class FooterItemGroupComponent {
  /**
   * Signal input for the `header` property.
   *
   * @public
   */
  readonly header: InputSignal<FooterItemGroupElement['header'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<FooterItemGroupElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<FooterItemGroupElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<FooterItemGroupElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<FooterItemGroupElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<FooterItemGroupElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<FooterItemGroupElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Opens or closes the links of the group (top area on narrow screens).
   *
   * @public
   */
  toggle(...args: Parameters<FooterItemGroupElement['toggle']>): ReturnType<FooterItemGroupElement['toggle']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `toggle()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends FooterItemGroupMethodNames>(method: TMethod, ...args: Parameters<FooterItemGroupComponentMethods[TMethod]>): ReturnType<FooterItemGroupComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof FooterItemGroupElement>(property: TProperty, value: FooterItemGroupElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<FooterItemGroupElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<FooterItemGroupComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<FooterItemGroupComponent, "mosaik-footer-item-group", never, {
    "header": {
      "alias": "header";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on FooterItemGroupComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FooterItemGroupMethodNames = 'toggle';
/**
 * Declares the methods interface for FooterItemGroupComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FooterItemGroupComponentMethods = MethodMap<FooterItemGroupMethodNames>;
/**
 * @public
 */
export declare function provideFooterItemGroupComponent(config?: Partial<FooterItemGroupElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the FooterItemComponent.
 * Use this token to provide default properties for the FooterItemComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const FOOTER_ITEM_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/primitives/footer/IFooterItemElementProps").IFooterItemElementProps>>;
/**
 * @public
 *
 * @slot  - Default slot for link or content (typically an anchor tag)
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class FooterItemComponent {
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<FooterItemElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<FooterItemElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<FooterItemElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<FooterItemElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<FooterItemElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<FooterItemElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof FooterItemElement>(property: TProperty, value: FooterItemElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<FooterItemElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<FooterItemComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<FooterItemComponent, "mosaik-footer-item", never, {
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on FooterItemComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FooterItemMethodNames = never;
/**
 * Declares the methods interface for FooterItemComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FooterItemComponentMethods = MethodMap<FooterItemMethodNames>;
/**
 * @public
 */
export declare function provideFooterItemComponent(config?: Partial<FooterItemElement.Props>): EnvironmentProviders;
/**
 * @public
 *
 * Injection token for the default properties of the FooterComponent.
 * Use this token to provide default properties for the FooterComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const FOOTER_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/primitives/footer/IFooterElementProps").IFooterElementProps>>;
/**
 * @public
 *
 * @slot bottom - Full-width content area below the main footer section
 * @slot brand - The brand slot.
 * @slot end - Right/end column content (additional links, social media, etc.)
 * @slot start - Left/start column content (navigation links, etc.)
 * @slot top - Full-width content area above the main footer section
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class FooterComponent {
  /**
   * Signal input for the `brand` property.
   *
   * @public
   */
  readonly brand: InputSignal<FooterElement['brand'] | undefined>;
  /**
   * Signal input for the `copyright` property.
   *
   * @public
   */
  readonly copyright: InputSignal<FooterElement['copyright'] | undefined>;
  /**
   * Signal input for the `breakpoint` property.
   *
   * @public
   */
  readonly breakpoint: InputSignal<FooterElement['breakpoint'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<FooterElement['themeName'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<FooterElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<FooterElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<FooterElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<FooterElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<FooterElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof FooterElement>(property: TProperty, value: FooterElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<FooterElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<FooterComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<FooterComponent, "mosaik-footer", never, {
    "brand": {
      "alias": "brand";
      "required": false;
      "isSignal": true;
    };
    "copyright": {
      "alias": "copyright";
      "required": false;
      "isSignal": true;
    };
    "breakpoint": {
      "alias": "breakpoint";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on FooterComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FooterMethodNames = never;
/**
 * Declares the methods interface for FooterComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type FooterComponentMethods = MethodMap<FooterMethodNames>;
/**
 * @public
 */
export declare function provideFooterComponent(config?: Partial<FooterElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-footer.d.ts.map