import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { ToggleTipElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/primitives/toggletip/ToggleTipElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the ToggleTipComponent.
 * Use this token to provide default properties for the ToggleTipComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const TOGGLE_TIP_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/primitives/toggletip/IToggleTipElementProps").IToggleTipElementProps>>;
/**
 * @public
 *
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ToggleTipComponent {
  /**
   * Signal input for the `content` property.
   *
   * @public
   */
  readonly content: InputSignal<ToggleTipElement['content'] | undefined>;
  /**
   * Signal input for the `placement` property.
   *
   * @public
   */
  readonly placement: InputSignal<ToggleTipElement['placement'] | undefined>;
  /**
   * Signal input for the `horizontalOffset` property.
   *
   * @public
   */
  readonly horizontalOffset: InputSignal<ToggleTipElement['horizontalOffset'] | undefined>;
  /**
   * Signal input for the `verticalOffset` property.
   *
   * @public
   */
  readonly verticalOffset: InputSignal<ToggleTipElement['verticalOffset'] | undefined>;
  /**
   * Signal input for the `isOpen` property.
   *
   * @public
   */
  readonly isOpen: InputSignal<ToggleTipElement['isOpen'] | undefined>;
  /**
   * Signal input for the `showDelay` property.
   *
   * @public
   */
  readonly showDelay: InputSignal<ToggleTipElement['showDelay'] | undefined>;
  /**
   * Signal input for the `hideDelay` property.
   *
   * @public
   */
  readonly hideDelay: InputSignal<ToggleTipElement['hideDelay'] | undefined>;
  /**
   * Signal input for the `trigger` property.
   *
   * @public
   */
  readonly trigger: InputSignal<ToggleTipElement['trigger'] | undefined>;
  /**
   * Signal input for the `staysOpen` property.
   *
   * @public
   */
  readonly staysOpen: InputSignal<ToggleTipElement['staysOpen'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ToggleTipElement['themeName'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<ToggleTipElement['disabled'] | undefined>;
  /**
   * Signal input for the `size` property.
   *
   * @public
   */
  readonly size: InputSignal<ToggleTipElement['size'] | undefined>;
  /**
   * Signal input for the `formatter` property.
   *
   * @public
   */
  readonly formatter: InputSignal<ToggleTipElement['formatter'] | undefined>;
  /**
   * Signal input for the `width` property.
   *
   * @public
   */
  readonly width: InputSignal<ToggleTipElement['width'] | undefined>;
  /**
   * Signal input for the `height` property.
   *
   * @public
   */
  readonly height: InputSignal<ToggleTipElement['height'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ToggleTipElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ToggleTipElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ToggleTipElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ToggleTipElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ToggleTipElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Calls `open` on the `mosaik-toggletip` element.
   *
   * @public
   */
  open(...args: Parameters<ToggleTipElement['open']>): ReturnType<ToggleTipElement['open']>;
  /**
   * Calls `close` on the `mosaik-toggletip` element.
   *
   * @public
   */
  close(...args: Parameters<ToggleTipElement['close']>): ReturnType<ToggleTipElement['close']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `open()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends ToggleTipMethodNames>(method: TMethod, ...args: Parameters<ToggleTipComponentMethods[TMethod]>): ReturnType<ToggleTipComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ToggleTipElement>(property: TProperty, value: ToggleTipElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ToggleTipElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ToggleTipComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ToggleTipComponent, "mosaik-toggletip", never, {
    "content": {
      "alias": "content";
      "required": false;
      "isSignal": true;
    };
    "placement": {
      "alias": "placement";
      "required": false;
      "isSignal": true;
    };
    "horizontalOffset": {
      "alias": "horizontalOffset";
      "required": false;
      "isSignal": true;
    };
    "verticalOffset": {
      "alias": "verticalOffset";
      "required": false;
      "isSignal": true;
    };
    "isOpen": {
      "alias": "isOpen";
      "required": false;
      "isSignal": true;
    };
    "showDelay": {
      "alias": "showDelay";
      "required": false;
      "isSignal": true;
    };
    "hideDelay": {
      "alias": "hideDelay";
      "required": false;
      "isSignal": true;
    };
    "trigger": {
      "alias": "trigger";
      "required": false;
      "isSignal": true;
    };
    "staysOpen": {
      "alias": "staysOpen";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "formatter": {
      "alias": "formatter";
      "required": false;
      "isSignal": true;
    };
    "width": {
      "alias": "width";
      "required": false;
      "isSignal": true;
    };
    "height": {
      "alias": "height";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on ToggleTipComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ToggleTipMethodNames = 'open' | 'close';
/**
 * Declares the methods interface for ToggleTipComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ToggleTipComponentMethods = MethodMap<ToggleTipMethodNames>;
/**
 * @public
 */
export declare function provideToggleTipComponent(config?: Partial<ToggleTipElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-toggletip.d.ts.map