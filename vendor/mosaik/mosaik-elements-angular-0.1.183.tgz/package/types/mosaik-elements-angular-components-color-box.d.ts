import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef, Type } from "@angular/core";
import { ControlValueAccessor } from "@angular/forms";
import { ColorBoxElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/inputs/color-box/ColorBoxElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import * as i1 from "@pixel-brewery/mosaik-elements-angular/runtime";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the ColorBoxComponent.
 * Use this token to provide default properties for the ColorBoxComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const COLOR_BOX_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/inputs/color-box/IColorBoxElementProps").IColorBoxElementProps>>;
/**
 * @public
 *
 * Injection token for the intl configuration of the ColorBoxComponent.
 * Provide a partial intl object or an injectable class that resolves translations.
 * This allows third-party applications to override the default intl labels
 * globally, per route, or per component via Angular's dependency injection.
 *
 * Merge order: Foundation defaults → DI intl → [intl] input binding.
 */
export declare const COLOR_BOX_INTL: InjectionToken<Partial<import("@pixel-brewery/mosaik-elements-foundation").ColorEditorElementIntl>>;
/**
 * @public
 *
 * @slot prefix - Content placed before the input field.
 * @slot suffix - Content placed after the input field.
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class ColorBoxComponent implements ControlValueAccessor {
  /**
   * Signal input for the `readonly` property.
   *
   * @public
   */
  readonly readonly: InputSignal<ColorBoxElement['readonly'] | undefined>;
  /**
   * Signal input for the `required` property.
   *
   * @public
   */
  readonly required: InputSignal<ColorBoxElement['required'] | undefined>;
  /**
   * Signal input for the `autofocus` property.
   *
   * @public
   */
  readonly autofocus: InputSignal<ColorBoxElement['autofocus'] | undefined>;
  /**
   * Signal input for the `name` property.
   *
   * @public
   */
  readonly name: InputSignal<ColorBoxElement['name'] | undefined>;
  /**
   * Signal input for the `pattern` property.
   *
   * @public
   */
  readonly pattern: InputSignal<ColorBoxElement['pattern'] | undefined>;
  /**
   * Signal input for the `placeholder` property.
   *
   * @public
   */
  readonly placeholder: InputSignal<ColorBoxElement['placeholder'] | undefined>;
  /**
   * Signal input for the `autocomplete` property.
   *
   * @public
   */
  readonly autocomplete: InputSignal<ColorBoxElement['autocomplete'] | undefined>;
  /**
   * Signal input for the `format` property.
   *
   * @public
   */
  readonly format: InputSignal<ColorBoxElement['format'] | undefined>;
  /**
   * Signal input for the `swatches` property.
   *
   * @public
   */
  readonly swatches: InputSignal<ColorBoxElement['swatches'] | undefined>;
  /**
   * Signal input for the `textAlign` property.
   *
   * @public
   */
  readonly textAlign: InputSignal<ColorBoxElement['textAlign'] | undefined>;
  /**
   * Signal input for the `colorPosition` property.
   *
   * @public
   */
  readonly colorPosition: InputSignal<ColorBoxElement['colorPosition'] | undefined>;
  /**
   * Signal input for the `editorFormat` property.
   *
   * @public
   */
  readonly editorFormat: InputSignal<ColorBoxElement['editorFormat'] | undefined>;
  /**
   * Signal input for the `showAlpha` property.
   *
   * @public
   */
  readonly showAlpha: InputSignal<ColorBoxElement['showAlpha'] | undefined>;
  /**
   * Signal input for the `showInputs` property.
   *
   * @public
   */
  readonly showInputs: InputSignal<ColorBoxElement['showInputs'] | undefined>;
  /**
   * Signal input for the `showPalette` property.
   *
   * @public
   */
  readonly showPalette: InputSignal<ColorBoxElement['showPalette'] | undefined>;
  /**
   * Signal input for the `showEyeDropper` property.
   *
   * @public
   */
  readonly showEyeDropper: InputSignal<ColorBoxElement['showEyeDropper'] | undefined>;
  /**
   * Signal input for the `showSwatch` property.
   *
   * @public
   */
  readonly showSwatch: InputSignal<ColorBoxElement['showSwatch'] | undefined>;
  /**
   * Signal input for the `palettes` property.
   *
   * @public
   */
  readonly palettes: InputSignal<ColorBoxElement['palettes'] | undefined>;
  /**
   * Signal input for the `selectedPalette` property.
   *
   * @public
   */
  readonly selectedPalette: InputSignal<ColorBoxElement['selectedPalette'] | undefined>;
  /**
   * Signal input for the `intl` property.
   *
   * @public
   */
  readonly intl: InputSignal<Partial<ColorBoxElement['intl']> | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<ColorBoxElement['themeName'] | undefined>;
  /**
   * Signal input for the `size` property.
   *
   * @public
   */
  readonly size: InputSignal<ColorBoxElement['size'] | undefined>;
  /**
   * Signal input for the `isClearable` property.
   *
   * @public
   */
  readonly isClearable: InputSignal<ColorBoxElement['isClearable'] | undefined>;
  /**
   * Signal input for the `invalid` property.
   *
   * @public
   */
  readonly invalid: InputSignal<ColorBoxElement['invalid'] | undefined>;
  /**
   * Signal input for the `value` property.
   *
   * @public
   */
  readonly value: InputSignal<ColorBoxElement['value'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<ColorBoxElement['variant'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<ColorBoxElement['appearance'] | undefined>;
  /**
   * Signal input for the `dropDownPlacement` property.
   *
   * @public
   */
  readonly dropDownPlacement: InputSignal<ColorBoxElement['dropDownPlacement'] | undefined>;
  /**
   * Signal input for the `dropDownStrategy` property.
   *
   * @public
   */
  readonly dropDownStrategy: InputSignal<ColorBoxElement['dropDownStrategy'] | undefined>;
  /**
   * Signal input for the `dropDownDistance` property.
   *
   * @public
   */
  readonly dropDownDistance: InputSignal<ColorBoxElement['dropDownDistance'] | undefined>;
  /**
   * Signal input for the `dropDownSkidding` property.
   *
   * @public
   */
  readonly dropDownSkidding: InputSignal<ColorBoxElement['dropDownSkidding'] | undefined>;
  /**
   * Signal input for the `dropDownStaysOpen` property.
   *
   * @public
   */
  readonly dropDownStaysOpen: InputSignal<ColorBoxElement['dropDownStaysOpen'] | undefined>;
  /**
   * Signal input for the `dropDownMaxHeight` property.
   *
   * @public
   */
  readonly dropDownMaxHeight: InputSignal<ColorBoxElement['dropDownMaxHeight'] | undefined>;
  /**
   * Signal input for the `dropDownHeight` property.
   *
   * @public
   */
  readonly dropDownHeight: InputSignal<ColorBoxElement['dropDownHeight'] | undefined>;
  /**
   * Signal input for the `dropDownWidth` property.
   *
   * @public
   */
  readonly dropDownWidth: InputSignal<ColorBoxElement['dropDownWidth'] | undefined>;
  /**
   * Signal input for the `dropDownMaxWidth` property.
   *
   * @public
   */
  readonly dropDownMaxWidth: InputSignal<ColorBoxElement['dropDownMaxWidth'] | undefined>;
  /**
   * Signal input for the `isDropDownOpen` property.
   *
   * @public
   */
  readonly isDropDownOpen: InputSignal<ColorBoxElement['isDropDownOpen'] | undefined>;
  /**
   * Signal input for the `label` property.
   *
   * @public
   */
  readonly label: InputSignal<ColorBoxElement['label'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<ColorBoxElement['disabled'] | undefined>;
  /**
   * Signal input for the `formatter` property.
   *
   * @public
   */
  readonly formatter: InputSignal<ColorBoxElement['formatter'] | undefined>;
  /**
   * Signal input for the `parser` property.
   *
   * @public
   */
  readonly parser: InputSignal<ColorBoxElement['parser'] | undefined>;
  /**
   * Signal input for the `isFocused` property.
   *
   * @public
   */
  readonly isFocused: InputSignal<ColorBoxElement['isFocused'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<ColorBoxElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<ColorBoxElement['lang'] | undefined>;
  /**
   * Output signal for the `cleared` event.
   *
   * @public
   */
  readonly cleared: OutputEmitterRef<ElementEventDetail<ColorBoxElement, 'cleared'>>;
  /**
   * Output signal for the `change` event.
   *
   * @public
   */
  readonly change: OutputEmitterRef<ElementEventDetail<ColorBoxElement, 'change'>>;
  /**
   * Output signal for the `input` event.
   *
   * @public
   */
  readonly input: OutputEmitterRef<ElementEventDetail<ColorBoxElement, 'input'>>;
  /**
   * Output signal for the `focus` event.
   *
   * @public
   */
  readonly focus: OutputEmitterRef<ElementEventDetail<ColorBoxElement, 'focus'>>;
  /**
   * Output signal for the `blur` event.
   *
   * @public
   */
  readonly blur: OutputEmitterRef<ElementEventDetail<ColorBoxElement, 'blur'>>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<ColorBoxElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<ColorBoxElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<ColorBoxElement, 'changed'>>;
  /**
   * Returns the assigned elements of a slot.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignments: ColorBoxElement['getSlotAssignments'];
  /**
   * Returns the assigned elements of a slot with a specific element type.
   *
   * The signature is generic or overloaded, which `Parameters` and `ReturnType` cannot reflect.
   * The member is therefore declared with the type of the element method and implemented by `ProxyCmp`.
   *
   * @public
   */
  readonly getSlotAssignmentsOf: ColorBoxElement['getSlotAssignmentsOf'];
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  private readonly _accessor;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Applies a value supplied by Angular forms to the native control.
   *
   * @public
   */
  writeValue(obj: unknown): void;
  /**
   * Registers the callback notified when the native control value changes.
   *
   * @public
   */
  registerOnChange(fn: unknown): void;
  /**
   * Registers the callback notified when the native control is touched.
   *
   * @public
   */
  registerOnTouched(fn: unknown): void;
  /**
   * Applies the disabled state supplied by Angular forms.
   *
   * @public
   */
  setDisabledState?(isDisabled: boolean): void;
  /**
   * Clears the value of the element but not the validation.
   *
   * @public
   */
  clear(...args: Parameters<ColorBoxElement['clear']>): ReturnType<ColorBoxElement['clear']>;
  /**
   * Resets the value, all kinds of validation and errors.
   *
   * @public
   */
  reset(...args: Parameters<ColorBoxElement['reset']>): ReturnType<ColorBoxElement['reset']>;
  /**
   * Checks the validity of the element and returns `true` if it is valid; otherwise, `false`.
   *
   * @public
   */
  checkValidity(...args: Parameters<ColorBoxElement['checkValidity']>): ReturnType<ColorBoxElement['checkValidity']>;
  /**
   * Assigns nodes to a dedicated slot.
   *
   * @public
   */
  assignToSlot(...args: Parameters<ColorBoxElement['assignToSlot']>): ReturnType<ColorBoxElement['assignToSlot']>;
  /**
   * Returns the assigned elements of a slot as string.
   *
   * @public
   * @returns The assigned elements of a slot as string.
   */
  getSlotContent(...args: Parameters<ColorBoxElement['getSlotContent']>): ReturnType<ColorBoxElement['getSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot has content.
   *
   * @public
   * @returns A boolean that indicates if a slot has content.
   */
  hasSlotContent(...args: Parameters<ColorBoxElement['hasSlotContent']>): ReturnType<ColorBoxElement['hasSlotContent']>;
  /**
   * Returns a boolean that indicates if a slot exists.
   *
   * @public
   * @returns A boolean that indicates if a slot exists.
   */
  hasSlot(...args: Parameters<ColorBoxElement['hasSlot']>): ReturnType<ColorBoxElement['hasSlot']>;
  /**
   * Called when the slot changes.
   * This method is a hook that can be overridden.
   *
   * @public
   */
  onSlotChanges(...args: Parameters<ColorBoxElement['onSlotChanges']>): ReturnType<ColorBoxElement['onSlotChanges']>;
  /**
   * Calls `open` on the `mosaik-colorbox` element.
   *
   * @public
   */
  open(...args: Parameters<ColorBoxElement['open']>): ReturnType<ColorBoxElement['open']>;
  /**
   * Calls `close` on the `mosaik-colorbox` element.
   *
   * @public
   */
  close(...args: Parameters<ColorBoxElement['close']>): ReturnType<ColorBoxElement['close']>;
  /**
   * Calls `toggle` on the `mosaik-colorbox` element.
   *
   * @public
   */
  toggle(...args: Parameters<ColorBoxElement['toggle']>): ReturnType<ColorBoxElement['toggle']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `clear()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * `focus`, `blur` share their name with another member of the component and are called on `elementRef.nativeElement` instead.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends ColorBoxMethodNames>(method: TMethod, ...args: Parameters<ColorBoxComponentMethods[TMethod]>): ReturnType<ColorBoxComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof ColorBoxElement>(property: TProperty, value: ColorBoxElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<ColorBoxElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ColorBoxComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ColorBoxComponent, "mosaik-colorbox", never, {
    "readonly": {
      "alias": "readonly";
      "required": false;
      "isSignal": true;
    };
    "required": {
      "alias": "required";
      "required": false;
      "isSignal": true;
    };
    "autofocus": {
      "alias": "autofocus";
      "required": false;
      "isSignal": true;
    };
    "name": {
      "alias": "name";
      "required": false;
      "isSignal": true;
    };
    "pattern": {
      "alias": "pattern";
      "required": false;
      "isSignal": true;
    };
    "placeholder": {
      "alias": "placeholder";
      "required": false;
      "isSignal": true;
    };
    "autocomplete": {
      "alias": "autocomplete";
      "required": false;
      "isSignal": true;
    };
    "format": {
      "alias": "format";
      "required": false;
      "isSignal": true;
    };
    "swatches": {
      "alias": "swatches";
      "required": false;
      "isSignal": true;
    };
    "textAlign": {
      "alias": "textAlign";
      "required": false;
      "isSignal": true;
    };
    "colorPosition": {
      "alias": "colorPosition";
      "required": false;
      "isSignal": true;
    };
    "editorFormat": {
      "alias": "editorFormat";
      "required": false;
      "isSignal": true;
    };
    "showAlpha": {
      "alias": "showAlpha";
      "required": false;
      "isSignal": true;
    };
    "showInputs": {
      "alias": "showInputs";
      "required": false;
      "isSignal": true;
    };
    "showPalette": {
      "alias": "showPalette";
      "required": false;
      "isSignal": true;
    };
    "showEyeDropper": {
      "alias": "showEyeDropper";
      "required": false;
      "isSignal": true;
    };
    "showSwatch": {
      "alias": "showSwatch";
      "required": false;
      "isSignal": true;
    };
    "palettes": {
      "alias": "palettes";
      "required": false;
      "isSignal": true;
    };
    "selectedPalette": {
      "alias": "selectedPalette";
      "required": false;
      "isSignal": true;
    };
    "intl": {
      "alias": "intl";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "isClearable": {
      "alias": "isClearable";
      "required": false;
      "isSignal": true;
    };
    "invalid": {
      "alias": "invalid";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "dropDownPlacement": {
      "alias": "dropDownPlacement";
      "required": false;
      "isSignal": true;
    };
    "dropDownStrategy": {
      "alias": "dropDownStrategy";
      "required": false;
      "isSignal": true;
    };
    "dropDownDistance": {
      "alias": "dropDownDistance";
      "required": false;
      "isSignal": true;
    };
    "dropDownSkidding": {
      "alias": "dropDownSkidding";
      "required": false;
      "isSignal": true;
    };
    "dropDownStaysOpen": {
      "alias": "dropDownStaysOpen";
      "required": false;
      "isSignal": true;
    };
    "dropDownMaxHeight": {
      "alias": "dropDownMaxHeight";
      "required": false;
      "isSignal": true;
    };
    "dropDownHeight": {
      "alias": "dropDownHeight";
      "required": false;
      "isSignal": true;
    };
    "dropDownWidth": {
      "alias": "dropDownWidth";
      "required": false;
      "isSignal": true;
    };
    "dropDownMaxWidth": {
      "alias": "dropDownMaxWidth";
      "required": false;
      "isSignal": true;
    };
    "isDropDownOpen": {
      "alias": "isDropDownOpen";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "formatter": {
      "alias": "formatter";
      "required": false;
      "isSignal": true;
    };
    "parser": {
      "alias": "parser";
      "required": false;
      "isSignal": true;
    };
    "isFocused": {
      "alias": "isFocused";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "cleared": "cleared";
    "change": "change";
    "input": "input";
    "focus": "focus";
    "blur": "blur";
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, [{
    directive: typeof i1.FormStatusHostDirective;
    inputs: {};
    outputs: {};
  }, {
    directive: typeof i1.FormFieldStatusHostDirective;
    inputs: {};
    outputs: {};
  }]>;
}
/**
 * Declares the methods available on ColorBoxComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ColorBoxMethodNames = 'focus' | 'blur' | 'clear' | 'reset' | 'checkValidity' | 'assignToSlot' | 'getSlotAssignments' | 'getSlotAssignmentsOf' | 'getSlotContent' | 'hasSlotContent' | 'hasSlot' | 'onSlotChanges' | 'open' | 'close' | 'toggle';
/**
 * Declares the methods interface for ColorBoxComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type ColorBoxComponentMethods = MethodMap<ColorBoxMethodNames>;
/**
 * @public
 */
export declare function provideColorBoxComponent(config?: Partial<ColorBoxElement.Props>, intl?: Partial<ColorBoxElement['intl']> | Type<Partial<ColorBoxElement['intl']>>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-color-box.d.ts.map