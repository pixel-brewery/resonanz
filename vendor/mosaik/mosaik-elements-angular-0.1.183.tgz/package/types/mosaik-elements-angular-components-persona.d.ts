import * as i0 from "@angular/core";
import { ElementRef, EnvironmentProviders, InjectionToken, InputSignal, OutputEmitterRef } from "@angular/core";
import { PersonaElement } from "@pixel-brewery/mosaik-elements-foundation/dist/controls/components/media/persona/PersonaElement";
import { ElementEventDetail } from "@pixel-brewery/mosaik-elements-foundation";
import { MethodMap } from "@pixel-brewery/mosaik-elements-angular/runtime";
/**
 * @public
 *
 * Injection token for the default properties of the PersonaComponent.
 * Use this token to provide default properties for the PersonaComponent.
 * The properties will be applied to the component when it is created.
 * This is useful for setting default values for properties that are not set by the user.
 */
export declare const PERSONA_DEFAULT_PROPS: InjectionToken<Partial<import("libs/mosaik-elements-foundation/dist/controls/components/media/persona/IPersonaElementProps").IPersonaElementProps>>;
/**
 * @public
 *
 * @slot presence - The presence slot.
 * @slot  - Default content for avatar display (overrides automatic text/icon generation)
 * @slot badge - Status indicator or notification badge positioned on the avatar
 * @slot style - Custom styles injection slot for shadow DOM styling escape hatch
 */
export declare class PersonaComponent {
  /**
   * Signal input for the `primaryText` property.
   *
   * @public
   */
  readonly primaryText: InputSignal<PersonaElement['primaryText'] | undefined>;
  /**
   * Signal input for the `secondaryText` property.
   *
   * @public
   */
  readonly secondaryText: InputSignal<PersonaElement['secondaryText'] | undefined>;
  /**
   * Signal input for the `tertiaryText` property.
   *
   * @public
   */
  readonly tertiaryText: InputSignal<PersonaElement['tertiaryText'] | undefined>;
  /**
   * Signal input for the `quaternaryText` property.
   *
   * @public
   */
  readonly quaternaryText: InputSignal<PersonaElement['quaternaryText'] | undefined>;
  /**
   * Signal input for the `presence` property.
   *
   * @public
   */
  readonly presence: InputSignal<PersonaElement['presence'] | undefined>;
  /**
   * Signal input for the `orientation` property.
   *
   * @public
   */
  readonly orientation: InputSignal<PersonaElement['orientation'] | undefined>;
  /**
   * Signal input for the `horizontalContentAlignment` property.
   *
   * @public
   */
  readonly horizontalContentAlignment: InputSignal<PersonaElement['horizontalContentAlignment'] | undefined>;
  /**
   * Signal input for the `verticalContentAlignment` property.
   *
   * @public
   */
  readonly verticalContentAlignment: InputSignal<PersonaElement['verticalContentAlignment'] | undefined>;
  /**
   * Signal input for the `text` property.
   *
   * @public
   */
  readonly text: InputSignal<PersonaElement['text'] | undefined>;
  /**
   * Signal input for the `textAccessor` property.
   *
   * @public
   */
  readonly textAccessor: InputSignal<PersonaElement['textAccessor'] | undefined>;
  /**
   * Signal input for the `icon` property.
   *
   * @public
   */
  readonly icon: InputSignal<PersonaElement['icon'] | undefined>;
  /**
   * Signal input for the `src` property.
   *
   * @public
   */
  readonly src: InputSignal<PersonaElement['src'] | undefined>;
  /**
   * Signal input for the `themeName` property.
   *
   * @public
   */
  readonly themeName: InputSignal<PersonaElement['themeName'] | undefined>;
  /**
   * Signal input for the `size` property.
   *
   * @public
   */
  readonly size: InputSignal<PersonaElement['size'] | undefined>;
  /**
   * Signal input for the `appearance` property.
   *
   * @public
   */
  readonly appearance: InputSignal<PersonaElement['appearance'] | undefined>;
  /**
   * Signal input for the `variant` property.
   *
   * @public
   */
  readonly variant: InputSignal<PersonaElement['variant'] | undefined>;
  /**
   * Signal input for the `disabled` property.
   *
   * @public
   */
  readonly disabled: InputSignal<PersonaElement['disabled'] | undefined>;
  /**
   * Signal input for the `dir` property.
   *
   * @public
   */
  readonly dir: InputSignal<PersonaElement['dir'] | undefined>;
  /**
   * Signal input for the `lang` property.
   *
   * @public
   */
  readonly lang: InputSignal<PersonaElement['lang'] | undefined>;
  /**
   * Output signal for the `connected` event.
   *
   * @public
   */
  readonly connected: OutputEmitterRef<ElementEventDetail<PersonaElement, 'connected'>>;
  /**
   * Output signal for the `disconnected` event.
   *
   * @public
   */
  readonly disconnected: OutputEmitterRef<ElementEventDetail<PersonaElement, 'disconnected'>>;
  /**
   * Output signal for the `changed` event.
   *
   * @public
   */
  readonly changed: OutputEmitterRef<ElementEventDetail<PersonaElement, 'changed'>>;
  private readonly _elementRef;
  private readonly _destroyRef;
  private readonly _outputSubscriptions;
  /**
   * Connects the native element, injected defaults, form adapter and output subscriptions.
   *
   * @public
   */
  constructor();
  /**
   * Calls `changeTextAccessor` on the `mosaik-persona` element.
   *
   * @public
   */
  changeTextAccessor(...args: Parameters<PersonaElement['changeTextAccessor']>): ReturnType<PersonaElement['changeTextAccessor']>;
  /**
   * Invokes a method on the underlying native element.
   *
   * @public
   * @deprecated Call the method on the component instead, e.g. `changeTextAccessor()`. The component declares the public methods
   * of the element with their own parameters and return type.
   * @param method - The method name to invoke.
   * @param args - The arguments to pass to the method.
   * @returns The return value of the method.
   */
  invoke<TMethod extends PersonaMethodNames>(method: TMethod, ...args: Parameters<PersonaComponentMethods[TMethod]>): ReturnType<PersonaComponentMethods[TMethod]>;
  /**
   * Sets a property value on the underlying native element.
   * This is useful for CDK behaviors and directives that need to modify element properties
   * without going through the signal input (which would cause a one-way binding).
   *
   * @public
   * @param property - The property name to set.
   * @param value - The value to set.
   */
  setInput<TProperty extends keyof PersonaElement>(property: TProperty, value: PersonaElement[TProperty]): void;
  /**
   * Initializes the effect that synchronizes all signal inputs to the native element.
   * Called from constructor after _element is initialized.
   * The effect is automatically cleaned up when the component is destroyed via DestroyRef.
   *
   * @private
   */
  private initInputSyncEffect;
  /**
   * Returns the native Foundation element represented by this Angular component.
   *
   * @public
   * @readonly
   */
  get elementRef(): ElementRef<PersonaElement>;
  static ɵfac: i0.ɵɵFactoryDeclaration<PersonaComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<PersonaComponent, "mosaik-persona", never, {
    "primaryText": {
      "alias": "primaryText";
      "required": false;
      "isSignal": true;
    };
    "secondaryText": {
      "alias": "secondaryText";
      "required": false;
      "isSignal": true;
    };
    "tertiaryText": {
      "alias": "tertiaryText";
      "required": false;
      "isSignal": true;
    };
    "quaternaryText": {
      "alias": "quaternaryText";
      "required": false;
      "isSignal": true;
    };
    "presence": {
      "alias": "presence";
      "required": false;
      "isSignal": true;
    };
    "orientation": {
      "alias": "orientation";
      "required": false;
      "isSignal": true;
    };
    "horizontalContentAlignment": {
      "alias": "horizontalContentAlignment";
      "required": false;
      "isSignal": true;
    };
    "verticalContentAlignment": {
      "alias": "verticalContentAlignment";
      "required": false;
      "isSignal": true;
    };
    "text": {
      "alias": "text";
      "required": false;
      "isSignal": true;
    };
    "textAccessor": {
      "alias": "textAccessor";
      "required": false;
      "isSignal": true;
    };
    "icon": {
      "alias": "icon";
      "required": false;
      "isSignal": true;
    };
    "src": {
      "alias": "src";
      "required": false;
      "isSignal": true;
    };
    "themeName": {
      "alias": "themeName";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "dir": {
      "alias": "dir";
      "required": false;
      "isSignal": true;
    };
    "lang": {
      "alias": "lang";
      "required": false;
      "isSignal": true;
    };
  }, {
    "connected": "connected";
    "disconnected": "disconnected";
    "changed": "changed";
  }, never, ["*"], true, never>;
}
/**
 * Declares the methods available on PersonaComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type PersonaMethodNames = 'changeTextAccessor';
/**
 * Declares the methods interface for PersonaComponent.
 *
 * @deprecated Only describes the deprecated `invoke` method.
 */
export type PersonaComponentMethods = MethodMap<PersonaMethodNames>;
/**
 * @public
 */
export declare function providePersonaComponent(config?: Partial<PersonaElement.Props>): EnvironmentProviders;
//# sourceMappingURL=mosaik-elements-angular-components-persona.d.ts.map